import urlparse,sys,urllib
import xbmcgui,xbmc
import time,os
import time,threading

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
mode = params.get('mode')
fname = params.get('foldername')
ex_link = params.get('ex_link')
page = params.get('page')
dialog = xbmcgui.Dialog()

if mode is None:
    from resources.lib import cdaxonline
    cdaxonline.cdaxonline().root()
elif mode == 'kategorie':
    from resources.lib import cdaxonline
    cdaxonline.cdaxonline().category()
elif mode == 'rok':
    from resources.lib import cdaxonline
    cdaxonline.cdaxonline().getYear()
elif mode == 'content':
    from resources.lib import cdaxonline
    cdaxonline.cdaxonline().content(ex_link)
elif mode.startswith('__page__:'):
    from resources.lib import cdaxonline
    cdaxonline.cdaxonline().page(mode,ex_link)
elif mode.startswith('search'):
    from resources.lib import cdaxonline
    cdaxonline.cdaxonline().search(mode,ex_link)
elif mode == 'playOpenKatalog':
    from resources.lib import cdaxonline
    cdaxonline.cdaxonline().playOpenKatalog(ex_link)
elif mode == 'seriale_seasons':
    from resources.lib import cdaxonline
    cdaxonline.cdaxonline().getSeasons(ex_link)
elif mode == 'seriale_episodes':
    from resources.lib import cdaxonline
    cdaxonline.cdaxonline().getEpisodes(ex_link)