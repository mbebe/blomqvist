# -*- coding: utf-8 -*-
import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin
TIMEOUT = 15
UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'
BRAMKA=''

class cookiez(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response

def getUrlCDAX(url,data=None):
    cj = cookielib.LWPCookieJar()
    if data:
        opener = urllib2.build_opener(cookiez, urllib2.HTTPCookieProcessor(cj))
    else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(cj))
    opener.addheaders = [('User-Agent', UA)]
    try:
        response = opener.open(url,data,TIMEOUT)
        result= response.read()
        response.close()
    except:
        result= wc = e.read()
    return result

def PLchar(txt):
    if isinstance(txt, unicode):
        txt = txt.encode('utf-8')
    txt = txt.replace('&lt;br/&gt;',' ')
    s='JiNcZCs7'
    txt = re.sub(s.decode('base64'),'',txt)
    txt = txt.replace('','').replace('','')
    txt = txt.replace('&nbsp;','')
    txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')
    return txt

url='http://cda-x.pl/jakosc/hd/'
url='http://cda-x.pl/odcinki/'
url='http://cda-x.pl/?s=dom'

class cdaxOnline2:
    @staticmethod
    def getContentCDAX(url):
        content = getUrlCDAX(url)
        outCDAX=[]
        out=[]
        subcontent = re.compile('<article(.*?)</article>',re.DOTALL).findall(content)
        for item in subcontent:
            if 'class="w_item_a"' in item:
                continue
            hrefTitle=re.findall('<h3>\s*<a href="(.*?)">(.+?)</a>',item)
            if not hrefTitle:
                h = re.findall('<a href="(.*?)"',item)
                t = re.findall('<div class="(?:title|data)">.+<h\d.+>(.+?)</h',item,re.DOTALL)
                if not t:
                    t= re.findall('<span class="serie">(.+?)</s',item,re.DOTALL)
                    if not t:
                       t= re.findall('alt="(.+?)"',item)
                if h and t:
                    hrefTitle=[(h[0],t[0].strip())]
            year = re.findall('<span[^>]*>(\d{4})</',item)
            imag = re.findall("""<img src=["'](.+?)["']""",item)
            iconStars = re.findall('<span class="icon-star2">\s*</span>(.+?)</div>',item,re.DOTALL)
            plotCDAX = re.findall('<div class="texto">(.+?)<',item,re.DOTALL)
            if hrefTitle:
                href = hrefTitle[0][0]
                title= PLchar(hrefTitle[0][1])
                imag = imag[0] if imag else ''
                iconStars = iconStars[0].strip() if iconStars else ''
                catTag = re.findall('rel="tag">(.+?)</a>',item)
                catTag = ','.join(catTag) if catTag else ''
                quality = re.findall('<span class="quality">(.*?)</',item)
                durat = re.findall('<span>(\d+)\s+min</span>',item)
                durat = int(durat[0])*60 if durat else ''
                oneCDAX={'href':href,
                    'title':title,
                    'img':imag,
                    'code':iconStars,
                    'year':year[0] if year else '',
                    'plot':PLchar(plotCDAX[0]).strip() if plotCDAX else '',
                    'duration':durat,
                    'genre':catTag,
                }
                if '/seriale/' in href:
                    outCDAX.append(oneCDAX)
                else:
                    out.append(oneCDAX)
        nextPage = re.findall("""<a class=['"]arrow_pag['"] href=['"](.*?)['"]><i class=['"]icon-caret-left['"]>""",content)
        nextPage = nextPage[0] if nextPage else False
        prevPage = re.findall("""<a class=['"]arrow_pag['"] href=['"](.*?)['"]><i class=['"]icon-caret-right['"]>""",content)
        prevPage = prevPage[0] if prevPage else False
        return out,outCDAX,(nextPage,prevPage)

    @staticmethod
    def getEpisodesCDAX(url):
        out = []
        content = getUrlCDAX(url)
        episContent = re.findall('<ul class="episodios">(.*?)</ul',content,re.DOTALL)
        for item2 in episContent:
            episContent2 = re.findall('<li>(.*?)</li>',item2,re.DOTALL)
            for li in episContent2:
                imag = re.findall('<img src="(.*?)"',li)
                numberCDAX = re.findall('<div class="numerando">\s*(\d+)\s*-\s*(\d+)\s*</div>',li)
                hrefTitle = re.findall('<a href="(http.*?)">([^<]+)</a>',li)
                data = re.findall('<span class="date">(.*?)</span>',li)
                if hrefTitle:
                    sesNumb,episNumb = numberCDAX[0] if numberCDAX else ('','')
                    imag = imag[0] if imag else ''
                    out.append({'href':hrefTitle[0][0],'title':hrefTitle[0][1],'img':imag,
                        'season':int(sesNumb),'episode':int(episNumb)})
        return out

    @staticmethod
    def getSesCDAX(out):
        outCDAX={}
        episContent = [x.get('season') for x in out]
        for s in set(episContent):
            outCDAX['Sezon %02d'%s]=[out[i] for i, j in enumerate(episContent) if j == s]
        return outCDAX

    @staticmethod
    def getCatCDAX():
        content = getUrlCDAX('http://cda-x.pl/')
        stuff = re.compile('<a href="(http://cda-x.pl/gatunki/.+?)"\s*[^>]*>(.*?)</a>[\s ]*<i>(.*?)</i>').findall(content)
        out=[]
        for hrefCDAX_, title, titleCDAX2 in stuff:
            out.append({'href':hrefCDAX_,'title':'{} ({})'.format(title,titleCDAX2.replace('&nbsp;',''))})
        return out

    @staticmethod
    def release():
        content = getUrlCDAX('http://cda-x.pl/')
        stuff = re.compile('<li>\s*<a href="(http://cda-x.pl/release/.+?)">(.*?)</a></li>').findall(content)
        out=[]
        for hrefCDAX_, title, in stuff:
            out.append({'href':hrefCDAX_,'title':title})
        return out

    @staticmethod
    def getVideosCDAX(url):
        content = getUrlCDAX(url)
        bodyCont = re.compile('<tbody>(.*?)</tbody>',re.DOTALL).findall(content)
        outLink=[]
        if bodyCont:
            subBodyCont = re.findall('<tr(.*?)</tr>',bodyCont[0],re.DOTALL)
            for xx in subBodyCont:
                LinkCDAX = re.findall('<a href="(http://cdax.online/links/.*?)"',xx)
                host = re.findall('domain=(.+?)"',xx)
                if LinkCDAX:
                    outLink.append({'href':LinkCDAX[0],'title':host[0] if host else '?','resolved':False})
        stuff = re.compile('<iframe(.*?)</ifr',re.I).findall(content)
        if stuff:
            src = re.findall("""src=["'](.*?)["']""",stuff[0],re.I)
            if src:
                title = urlparse(src[0].strip()).netloc
                outLink.append({'href':src[0],'title':title,'resolved':True})
        return outLink

    @staticmethod
    def getSrcs(url):
        a=getUrlCDAX(url)
        src = re.findall('<div class="boton reloading"><a href="(.*?)">',a)
        if src:
            return src[0] if src else ''
        return ''

    @staticmethod
    def getSrcsIframe(url):
        content = getUrlCDAX(url)
        stuff = re.compile('<iframe(.*?)</iframe>',re.I).findall(content)
        if stuff:
            src = re.findall("""src=["'](.*?)["']""",stuff[0],re.I)
            if src:
                return src[0] if src else ''
        return ''
