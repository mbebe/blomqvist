# -*- coding: utf-8 -*-
import xbmcaddon

addonName       = xbmcaddon.Addon().getAddonInfo('name')

class SearchHistory():
    def __init__(self,name=addonName):
        try:
            import StorageServer
        except:
            import storageserverdummy as StorageServer
        self.cache = StorageServer.StorageServer(name)

    def dec_unc(self,t):
        return t.encode('utf-8') if isinstance(t,unicode) else t

    def HistoryLoad(self):
        return self.cache.get('history').split(';')

    def HistoryAdd(self,entry):
        history = self.HistoryLoad()
        if history == ['']:
            history = []
        history.insert(0, self.dec_unc(entry))
        try:
            self.cache.set('history',u';'.join(history[:50]))
        except:
            pass

    def HistoryDel(self,entry):
        history = self.HistoryLoad()
        if history:
            try:
                self.cache.set('history',';'.join(history[:50]))
            except:
                pass
        else:
            self.HistoryClear()

    def HistoryClear(self):
        self.cache.delete('history')
