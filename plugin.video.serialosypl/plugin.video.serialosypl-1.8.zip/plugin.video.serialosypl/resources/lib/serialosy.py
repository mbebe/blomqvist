# -*- coding: utf-8 -*-

import urllib2,urllib
import re,os
import cfcookie,cookielib
from urlparse import urlparse,urljoin
main_url='http://www.serialosy24.pl'
TIMEOUT = 10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'
COOKIEFILE=''
GATE = 'http://www.bramka.proxy.net.pl/index.php?q='
def _getUrl(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)
    if cookies:
        req.add_header('Cookie', cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()
        response.close()
    except:
        link=''
    return link
def getUrl(url,data=None):
    cookies=cfcookie.cookieString(COOKIEFILE)
    content=_getUrl(url,data,cookies)
    if not content:
        cookie=cf_setCookies(main_url,COOKIEFILE)
        cookies=cfcookie.cookieString(COOKIEFILE)
        content=_getUrl(url,data,cookies)
    return content
def cf_setCookies(link,cfile):
    cookie = cookielib.LWPCookieJar()
    cookieJar = cfcookie.createCookie(link,cookie,UA)
    dataPath=os.path.dirname(cfile)
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    if cookie:
        cookie.save(cfile, ignore_discard = True)
    return cookie
def getSeriale(url='http://www.serialosy24.pl',itemSER=''):
    out=[]
    content = getUrl(url)
    match = re.compile('<li class="sublnk"><a href=".*?"><b>(.*?)</b></a>(.*?)</ul>\\s*</li>',re.DOTALL).findall(content)
    for type,items in match:
        if itemSER in type:
            ser = re.compile('<li><a href="(.*?)"><b>(.*?)</b></a></li>').findall(items)
            for s in ser:
                out.append({'title':PLchar(s[1].strip()),'url':s[0]})
            return out
    return out
def scanPage(url='/zagraniczne-seriale/wojna-i-pokoj/',data='dlenewssortby=date&dledirection=desc&set_new_sort=dle_sort_main&set_direction_sort=dle_direction_main'):
    if not url.startswith('http'):
        if url[0]=='/': url = main_url+urllib2.quote(url)
        else: url = urljoin(main_url,url)
    out=[]
    content = getUrl(url,data)
    idx = [(a.start(), a.end()) for a in re.finditer('<div class="base shortstory">', content)]
    idx.append( (-1,-1) )
    out=[]
    for i in range(len(idx[:-1])):
        match = content[ idx[i][1]:idx[i+1][0] ]
        href = re.compile('<h3 class="btl"><a href="(.*?)">(.*?)</a></h3>',re.DOTALL).findall(match)
        info = re.compile('<p class="binfo small">(.*?)<a href=".*?"\\s*>(.*?)</a>(.*?)</p>').findall(match)
        info = ''.join(info[0])+'\n' if info else ''
        imag = re.compile('<img src="(.*?)"').findall(match)
        plot = re.compile('<left>(.*?)</left>').findall(match)
        plot = info+ plot[0] if plot else ''
        if href and info and imag:
            h = href[0][0]
            t = href[0][1]
            i = imag[0]
            out.append({'title':PLchar(t),'url':h,'img':i,'plot':plot})
    prevPage = re.compile('<a href="(.*?)"><span class="thide pprev">Wstecz</span></a>').search(content)
    prevPage = prevPage.group(1) if prevPage else False
    nextPage = re.compile('<a href="(.*?)"><span class="thide pnext">Dalej</span></a>').search(content)
    nextPage = nextPage.group(1) if nextPage else False
    if not out:
        out.append({'title':'[COLOR red]Brak artykułów lub nie masz dostępu do ich oglądania.[/COLOR]','url':'','img':'','plot':''})
        prevPage = False
        nextPage = False
    return out,(prevPage,nextPage)
	
def getVideos(url='http://www.serialosy24.pl/zagraniczne-seriale9/ostatni-okret-the-last-ship/13209-ostatni-okret-the-last-ship-s04e06-eng.html'):
    content = getUrl(url)
    out=[]
    iframeDAT = re.compile('<iframe(.*?)</iframe>',re.DOTALL|re.IGNORECASE).findall(content)
    for srcDAT in iframeDAT:
        src = re.compile('src="(.*?)"',re.DOTALL|re.IGNORECASE).findall(srcDAT)
        if 'playerdrive.com' in src[0]:
            pldrurl='https:'+src[0]
            src=getPlayVid(pldrurl)
            host= urlparse(pldrurl).netloc
            out.append({'url':src,'title':host})
        else:
            host = urlparse(src[0]).netloc
            out.append({'url':src[0],'title':host})
    return out
	
def unpack(source):
    payload, symtab, radix, count = _filterargs(source)
    ranger = [str(x) for x in range(count)]   
    z= zip(ranger, symtab)    
    ch=dict(z)
    out = re.sub('(\d+)', lambda m: ch[m.group()], payload)
    return out

def _filterargs(source):
    juicers = [ (r"}\('(.*)', *(\d+), *(\d+), *'(.*)'\.split\('\|'\), *(\d+), *(.*)\)\)"),
                (r"}\('(.*)', *(\d+), *(\d+), *'(.*)'\.split\('\|'\)"),
                ("\('(.*)', *(\d+), *(\d+), *'(.*)'\.split\('\|'\), *(\d+), *(.*)"),
                ]
    for juicer in juicers:
        args = re.search(juicer, source, re.DOTALL)
        if args:
            a = args.groups()
    return a[0], a[3].split('|'), int(a[1]), int(a[2])

def getPlayVid(pldrurl):
    content = getUrl(pldrurl)
    pack = re.compile("(eval\(function\(p,a,c,k,e,d\).*?)\n",re.DOTALL).findall(content)
    pack=pack[0].decode('string_escape')
    cntx=unpack(pack)
    match = re.compile("""file:["'](.*?\.mp4)["']""",re.DOTALL|re.IGNORECASE).findall(cntx)
    sours=match[0]
    return sours
	
def PLchar(letter):
    letter = letter.replace('&lt;br/&gt;',' ')
    letter = letter.replace('&quot;','"').replace('&amp;quot;','"')
    letter = letter.replace('&oacute;','ó').replace('&Oacute;','Ó')
    letter = letter.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    letter = letter.replace('&amp;','&')
    letter = letter.replace('\u0105','ą').replace('\u0104','Ą')
    letter = letter.replace('\u0107','ć').replace('\u0106','Ć')
    letter = letter.replace('\u0119','ę').replace('\u0118','Ę')
    letter = letter.replace('\u0142','ł').replace('\u0141','Ł')
    letter = letter.replace('\u0144','ń').replace('\u0144','Ń')
    letter = letter.replace('\u00f3','ó').replace('\u00d3','Ó')
    letter = letter.replace('\u015b','ś').replace('\u015a','Ś')
    letter = letter.replace('\u017a','ź').replace('\u0179','Ź')
    letter = letter.replace('\u017c','ż').replace('\u017b','Ż')
    return letter
	
