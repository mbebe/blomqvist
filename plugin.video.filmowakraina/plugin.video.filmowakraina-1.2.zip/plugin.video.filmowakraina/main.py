# -*- coding: UTF-8 -*-
import sys,re,os
import urlparse
from urlparse import parse_qsl
import base64
import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import resolveurl as urlresolver
import cookielib
import json
import decimal

try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
  
cache = StorageServer.StorageServer("fkraina")

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.filmowakraina')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=PATH+'fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )
import cloudflare3
exlink = params.get('url', None)
name= params.get('title', None)
page = params.get('page',[1])[0]

main_url = 'https://filmowakraina.tv/movies'

UA='Mozilla/5.0 (Linux; Android 7.0; PLUS Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36'
TIMEOUT=15

#headers = {'User-Agent': UA,}
COOKIEFILE = os.path.join(RESOURCES,'fkraina.cookie')
sess = requests.Session()

sess.cookies = cookielib.LWPCookieJar(COOKIEFILE)
sess.headers.update({'User-Agent': UA})

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=1,contextmenu=None, hateml=None):
	list_item = xbmcgui.ListItem(label=name)

	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')
		
	if not infoLabels:
		infoLabels={'title': name}
	if contextmenu:
		isp=contextmenu
		list_item.addContextMenuItems(isp, replaceItems=True)
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	
def cfandsave():
	url_test = 'https://filmowakraina.tv'
	check = sess.get(url_test)
	cf = cloudflare3.Cloudflare(url_test,check)
	cookies = {}
	verifyGet = ''
	if cf.is_cloudflare:
		authUrl = cf.get_url()
		makeAuth = sess.get(authUrl)
		getCookies = sess.get(url_test)
		cookies = sess.cookies #.get_dict()	
		if cookies:
			sess.cookies.save()	
	return
	
def home():
	add_item('', 'Filmy', RESOURCES+'Filmy.png', True, "listfilmy",page=1)
	add_item('https://filmowakraina.tv/movies', '    Kategorie', RESOURCES+'Filmy.png', True, "listcateg",page=1)	
	add_item('', 'Seriale', RESOURCES+'Filmy.png', True, "listseries",page=1)
	add_item('https://filmowakraina.tv/series', '    Kategorie', RESOURCES+'Filmy.png', True, "listcateg",page=1)							
	add_item('', '[COLOR lightblue]Szukaj[/COLOR]', RESOURCES+'Filmy.png', True, "Szukaj")		
	xbmcplugin.endOfDirectory(addon_handle)

def ListFilmy(exlink,page):
	page = int(page) if page else 1	
	links, pagin = getFilmy(exlink,page)
	if pagin[0]:
		add_item(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[0])	
	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
	if pagin[1]:
		add_item(name='[COLOR blue]>> Nastepna strona >>>[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[1])
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)

def getFilmy(genr,page=1):	
	html=getUrlReq(main_url)#.replace("\'",'"')
	token=re.findall('token:\s+"(.+?)"',html)[0]
	if not genr:
		genr=''
	url="https://filmowakraina.tv/titles/paginate?_token=%s&perPage=20&page=%d&order=newestLinks&genres[]=%s&type=movie&minRating=&maxRating="%(token,page,genr)
	json=getUrlReqJson(url)
	z=json.get('totalPages','')#[0]
	ilstr=int(decimal.Decimal(z).quantize(decimal.Decimal('1.'), rounding=decimal.ROUND_UP))
	prevpage=False #gr=False
	nextpage=False  # pr=False	

	if page<ilstr:
		nextpage = str(page+1)	
	out=[]
	linkx=''
	items=json.get('items','')
	if items:
		for x in items:
			links = x.get('link', [])

			for linki in links:
				adr=linki.get('url','')  
				adr = 'https:'+adr if adr.startswith('//') else adr
				qual=linki.get('quality','')  
				linkx+='adr:"%s" qua:"%s"'%(adr,qual)
			id=x.get('id', '')  
			title=x.get('title', '')  
			plot=x.get('plot', '')  
			imag=x.get('poster', '')  
			year=x.get('year', '')  
			genre=x.get('genre', '')   	
			href='https://filmowakraina.tv/movies/%s'%id
			out.append({ 'href'  : linkx,'title' : PLchar(title),'mediatype': 'movie','img':imag,'plot':PLchar(plot), 'genre':PLchar(genre), 'year':year})	
			linkx=''
	prevpage = str(page-1) if page>1 else ''
	return (out,(prevpage,nextpage))	

def ListSeries(exlink,page):
	page = int(page) if page else 1	
	links, pagin = getSeries(exlink,page)
	if pagin[0]:
		add_item(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__S', image='', folder=True, page=pagin[0])	
	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listsezons', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	if pagin[1]:
		add_item(name='[COLOR blue]>> Nastepna strona >>>[/COLOR]', url=exlink, mode='__page__S', image='', folder=True, page=pagin[1])
	xbmcplugin.setContent(addon_handle, 'tvshows')	
	xbmcplugin.endOfDirectory(addon_handle)

def getSeries(genr,page=1):	
	html=getUrlReq(main_url)
	token=re.findall('token:\s+"(.+?)"',html)[0]
	if not genr:
		genr=''	
	url="https://filmowakraina.tv/titles/paginate?_token=%s&perPage=20&page=%d&order=newestLinks&genres[]=%s&type=series&minRating=&maxRating="%(token,page,genr)
	json=getUrlReqJson(url)
	z=json.get('totalPages','')
	ilstr=int(decimal.Decimal(z).quantize(decimal.Decimal('1.'), rounding=decimal.ROUND_UP))
	prevpage=False #gr=False
	nextpage=False  # pr=False	

	if page<ilstr:
		nextpage = str(page+1)	
	out=[]
	linkx=''
	items=json.get('items','')
	if items:
		for x in items:
			id=x.get('id', '')  
			title=x.get('title', '')  
			plot=x.get('plot', '')  
			imag=x.get('poster', '')  
			year=x.get('year', '')  
			genre=x.get('genre', '')   	
			href='https://filmowakraina.tv/series/%s'%id
			out.append({ 'href'  : id,'title' : PLchar(title),'mediatype': 'tvshows','img':imag,'plot':PLchar(plot), 'genre':PLchar(genre), 'year':year})	
			linkx=''
	prevpage = str(page-1) if page>1 else ''
	return (out,(prevpage,nextpage))	

def ListSezons(exlink):
	if 'filmid' in exlink:
		exlink=re.findall('"(.+?)"',exlink)[0]
	links = getSezons(exlink)	
	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listepizody', image=f.get('img'), folder=True, infoLabels=f, itemcount=items,hateml=f.get('hateml'))	
	xbmcplugin.setContent(addon_handle, 'tvshows')	
	xbmcplugin.endOfDirectory(addon_handle)

def getSezons(filmid):
	url='https://filmowakraina.tv/series/%s'%filmid
	html=getUrlReq(url)
	genre=re.findall(',"genre":"(.+?)"',html)[0]
	year=int(re.findall('"year":(\d+),',html)[0])
	plot=re.findall('"plot":"(.+?)"',html)[0]
	imag=re.findall('"poster":"(.+?)"',html)[0].replace('\\','')
	sezony=parseDOM(html,'div', attrs={'class': "details-block seasons"})[0]
	sezons = parseDOM(sezony,'a')
	co=1
	out=[]
	for sezon in sezons:
		href = 'url:"https://filmowakraina.tv/series/%s/seasons/%d"'%(filmid,co)
		title = 'Sezon '+str(co) #[1]
		out.append({'title':title,'href':href,'img':imag,'plot':PLchar(plot),'year':year,'genre':PLchar(genre),'season':co,'mediatype': 'season'})	
		co+=1		
	return out

def ListEpizody(exlink):
	dane=re.findall('\/series\/(\d+)/seasons/\d+"',exlink)
	url=re.findall('url:"(.+?)"',exlink)[0]
	links=getEpizody(url,dane)
	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinksSeries', image=f.get('img'), folder=False, infoLabels=f, itemcount=items,hateml=f.get('hateml'))	
	xbmcplugin.setContent(addon_handle, 'episodes')	
	xbmcplugin.endOfDirectory(addon_handle)	
	
def getEpizody(url,dane):
	html=getUrlReq(url)
	filmid=dane[0]
	result=parseDOM(html,'ul', attrs={'id': "episode-list"})[0]
	sezepiz=re.findall('"col-sm-3" href="https://filmowakraina.tv/series/.+?/seasons/(\d+)/episodes/(\d+)">',result)
	url='https://filmowakraina.tv/series/%s'%filmid
	html=getUrlReq(url)
	orgtitle=re.findall('"original_title":"(.+?)"',html)[0]
	genre=re.findall(',"genre":"(.+?)"',html)[0]
	year=int(re.findall('"year":(\d+),',html)[0])
	plot=re.findall('"plot":"(.+?)"',html)[0]
	imag=re.findall('"poster":"(.+?)"',html)[0].replace('\\','')
	out=[]
	
	for sez,epiz in sezepiz:
		href="href='https://filmowakraina.tv/series/%s' sezon='%s' epizod='%s'"%(filmid,sez,epiz)
		title = 'Sezon '+sez+' Odcinek '+epiz
		out.append({'title':title,'href':href,'img':imag,'plot':PLchar(plot),'year':year,'genre':PLchar(genre),'season':int(sez),'episode':int(epiz),'mediatype': 'episode','originaltitle':orgtitle})			
	return out	

def getUrlReq(url):
	if os.path.isfile(COOKIEFILE):
		sess.cookies.load()

	content=sess.get(url,verify=False).content
	return content.replace("\'",'"')

def getUrlReqJson(url):
	if os.path.isfile(COOKIEFILE):
		sess.cookies.load()
	sess.headers= {
	'User-Agent': 'Mozilla/5.0 (Linux; Android 7.0; PLUS Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36',
	'Accept': 'application/json, text/javascript, */*; q=0.01',
	'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
	'Referer': 'https://filmowakraina.tv/movies',
	'X-Requested-With': 'XMLHttpRequest',
	'Connection': 'keep-alive',
	'TE': 'Trailers',}
	content=sess.get(url,verify=False).json()
	return content
	
def getVevio(url):
	r=requests.get(url,headers=headers,verify=False)
	html=r.content
	id=re.findall('{"video_code":"(.+?)"}',html)[0]
	headers2 = {
    'User-Agent': UA,
    'Accept': 'application/json',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': url,
    'Content-Type': 'application/json;charset=utf-8',
    'referrer': url,
    'Connection': 'keep-alive',
    'TE': 'Trailers',}
	data = '{}'
	posturl='https://vev.io/api/serve/video/%s'%id
	response = requests.post(posturl, headers=headers2, data=data)
	html=response.text
	links=getVevioVids(html)
	if len(links)>1:
		linksAllb = [x.get('host') for x in links]
		s = xbmcgui.Dialog().select('Wybierz jakość',linksAllb)	
	else:
		s=0
	hrefs=links[s].get('href') if s>-1 else ''
	host=links[s].get('host') if s>-1 else ''
	return hrefs

def getLinksSeries(exlink):
	stream=''
	stream_url=''
	url=re.findall("href='(.+?)'",exlink)[0]
	links=[]
	sezepiz=re.findall("sezon='(.+?)' epizod='(.+?)'",exlink)[0]
	sez= int(sezepiz[0])
	epiz=int(sezepiz[1])	
	html=getUrlReq(url)	
	app=re.findall('"link":(\[.+?\])',html,re.DOTALL)[0]
	items=json.loads(app)
	for a in items:
		
		if a['season']==sez and a['episode']==epiz:
			href=a['url']
			qual=a['quality']
			label=a['label']
			film = {'href' : href,'host' : label+' ('+qual+')',}
			links.append(film)	
	
	if links:
		if len(links)>1:
			linksAllb = [x.get('host') for x in links]
			s = xbmcgui.Dialog().select('Linki',linksAllb)	
		else:
			s=0
		hrefs=links[s].get('href') if s>-1 else ''
		host=links[s].get('host') if s>-1 else ''	
		stream=hrefs	
		xbmc.sleep(250)		
		if stream:
			try:				
				stream_url = urlresolver.resolve(stream)
			except Exception,e:
				stream_url=''
				s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link bedzie działał?','ERROR: %s'%str(e))	
		if stream_url:	
			play_item = xbmcgui.ListItem(path=stream_url)
			xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
		else:
			play_item = xbmcgui.ListItem(path='')
			xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)	
	else:
		s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak linków')		

def getLinks(exlink):
	stream=''
	stream_url=''
	links=[]
	if 'filmid' in exlink:
		nxt=re.findall('"(.+?)"',exlink)[0]
		url='https://filmowakraina.tv/movies/%s'%nxt
		html=getUrlReq(url)
		app=re.findall('"link":(\[.+?\])',html,re.DOTALL)[0]
		linki=re.findall('"url":"(.+?)".+?"quality":"(.+?)"',app)		
	else:
		linki=re.findall('adr:"(.+?)" qua:"(.+?)"',exlink)
	for href,qual in linki:
		href = href.replace('\\','')
		host = (urlparse.urlsplit(href).netloc).lower()
		film = {'href' : href,'host' : host+' ('+qual+')',}
		links.append(film)			
	if links:
		if len(links)>1:
			linksAllb = [x.get('host') for x in links]
			s = xbmcgui.Dialog().select('Linki',linksAllb)	
		else:
			s=0
		hrefs=links[s].get('href') if s>-1 else ''
		host=links[s].get('host') if s>-1 else ''	
		#if 'vev.io' in hrefs:	
		#	stream_url=getVevio(hrefs)
		#else:
		stream=hrefs	
		if stream:
			try:
				stream_url = urlresolver.resolve(stream)
			except Exception,e:
				stream_url=''
				s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link bedzie działał?','ERROR: %s'%str(e))	
		if stream_url:	
			play_item = xbmcgui.ListItem(path=stream_url)
			xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
		else:
			play_item = xbmcgui.ListItem(path='')
			xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)	
	else:
		s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak linków')

def getVevioVids(content):
	out=[]
	qualhref=re.findall('"(\d+p)":"(.+?)"',content)
	for qual,href in qualhref:
		try:
			film = {'href' : href,'host' : qual,}
			out.append(film)
		except:
			pass
	return out	
	
def getGatunek(exlink):
	out=[]
	html=getUrlReq(exlink)
	result = parseDOM(html, 'div', attrs={'class': 'genre-box'})#[0]
	if result:
		links = parseDOM(result[0],'div', attrs={'class': 'checkbox'}) 
		for link in links:	
			
			url = parseDOM(link,'input', attrs={'value': '.+?'},ret='value')[0] 
			genre = PLchar(re.findall(">(.+?)<\/label>",link)[0])
			out.append((PLchar(genre), url))	
	return out	

def getHistory():
    return cache.get('history').split(';')

def setHistory(entry):
    history = getHistory()
    if history == ['']:
        history = []
    history.insert(0, entry)
    cache.set('history',';'.join(history[:50]))

def remCache(entry):
    history = getHistory()
    if history:
        cache.set('history',';'.join(history[:50]))
    else:
        delHistory()

def delHistory():
    cache.delete('history')
	
def ListSearch(exlink,page):
	links,serials = search(exlink)	
	itemz=links
	items = len(links)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
	itemz=serials
	items = len(serials)

	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listsezons', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)		
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)

def search(q):
	url='https://filmowakraina.tv/typeahead/%s'%q
	jsons=getUrlReq(url)
	items=json.loads(jsons)
	out=[]
	serout=[]
	for item in items:
		plot= item['plot']
		title=item['title']
		imag= item['poster']
		filmid= item['id']
		genr= item['genre']
		typ=  item['type']
		href='filmid:"%s"'%filmid
		film = {'href': href,'title': PLchar(title),'img': imag,'genre':PLchar(genr),'plot':PLchar(plot)}
		
		if typ=='movie':
			out.append(film)	
		else:
			serout.append(film)
	return out,serout				

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&nbsp;',".").replace('&amp;','&')
	return char	

if __name__ == '__main__':
	mode = params.get('mode', None)
	
	if not mode:
		home()
		cfandsave()		
	elif mode == 'listfilmy':
		ListFilmy(exlink,page)
		
	elif mode == 'listseries':
		ListSeries(exlink,page)	
		
	elif mode == 'listsezons':
		ListSezons(exlink)	
		
	elif mode == 'listepizody':
		ListEpizody(exlink)			
		
	elif mode == 'getLinks':
		getLinks(exlink)	
		
	elif mode == 'getLinksSeries':
		getLinksSeries(exlink)			

	elif mode == 'listsearch':
		ListSearch(exlink,page)
		
	elif mode == '__page__M':
		url = build_url({'mode': 'listfilmy', 'foldername': name, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
		xbmcplugin.endOfDirectory(addon_handle)
	elif mode == '__page__S':
		url = build_url({'mode': 'listseries', 'foldername': name, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
		xbmcplugin.endOfDirectory(addon_handle)
	elif mode == 'listcateg':
		data = getGatunek(exlink)
		if data:
			label = [x[0].strip() for x in data]
			url = [x[1].strip() for x in data]
			s = xbmcgui.Dialog().select('Wybierz kategorię',label)
			if s>-1:
				pass
				aa=url[s]
				if '/movies' in exlink:
					url = build_url({'mode': 'listfilmy', 'foldername': name, 'url' : url[s]})
					xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)	
				else:
					ListSeries(aa,page)
					url = build_url({'mode': 'listseries', 'foldername': name, 'url' : url[s]})
					xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)		
		xbmcplugin.endOfDirectory(addon_handle)				
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			links,serials=search(query.replace(' ','+'))
			itemz=links
			items = len(links)
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
			itemz=serials
			items = len(serials)
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode='listepisodes', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)				
		xbmcplugin.setContent(addon_handle, 'movies')
		xbmcplugin.endOfDirectory(addon_handle)
		
	elif mode =='Szukaj':
		add_item('', '[COLOR green]Nowe Szukanie[/COLOR]', '', True, "SzukajNowe")	
		history = getHistory()
		if not history == ['']:
			for entry in history:
				contextmenu = []
				contextmenu.append((u'Usun', 'XBMC.Container.Refresh(%s)'% build_url({'mode': 'SzukajUsun', 'ex_link' : entry})),)
				contextmenu.append((u'Usun cała historie', 'XBMC.Container.Update(%s)' % build_url({'mode': 'SzukajUsunAll'})),)
				add_item(entry,entry, '', True, 'listsearch', contextmenu=contextmenu)				
		xbmcplugin.setContent(addon_handle, 'movies')				
		xbmcplugin.endOfDirectory(addon_handle)
		
	elif mode =='SzukajNowe':
		d = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu/serialu', type=xbmcgui.INPUT_ALPHANUM)
		if d:
			setHistory(d)
			ex_link=d.replace(' ','+')
			ListSearch(ex_link,page)
			xbmcplugin.setContent(addon_handle, 'movies')		
			
	elif mode =='SzukajUsun':
		remCache(ex_link)
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))
	
	elif mode == 'SzukajUsunAll':
		delHistory()
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))
xbmcplugin.endOfDirectory(addon_handle)