# -*- coding: utf-8 -*-

import sys
import urllib2,urllib
import os
import re
import base64,json
import cookielib
import l11l11l11_ef_ #cfcookie
import random
import unpackstd as jsunpack
import unpackstd	
import control
try:
    import l11ll11ll_ef_ #recaptcha
except:
    pass
BASEURL='http://www.efilmy.tv/'
TIMEOUT = 10
l1lllll111_ef_=''
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'
BRAMKA  = 'http://bramka.proxy.net.pl/index.php'
header={
    'User-Agent':UA,
    'Host':'www.efilmy.tv',
    'Upgrade-Insecure-Requests':'1',
    'Connection': 'keep-alive',
    'Accept':'text/html,application/xhtml+xml,application/',
    }
#COOKIEFILE="c:\users\ramic\appdata\roaming\kodi\addons\plugin.video.efilmy\cookie"
def getProksy():
    proksy = None
    if control.setting('proxy') == "true":
        try:
            proksy = control.setting('proxy_ip')
            if not proksy:
                proksy = None  
        except:
            proksy = None
	return proksy
	
def _getUrl(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)
    if cookies:
        req.add_header('Cookie', cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        content = response.read()
        response.close()
    except:
        content=''
    return content
	
def getUrl(url,data=None,header=None):
    cookies=l11l11l11_ef_.l11l1l1ll_ef_(COOKIEFILE)
    content=_getUrl(url,data,cookies)
    if not content:
        cj=cf_setCookies(BASEURL,COOKIEFILE)
        cookies=l11l11l11_ef_.l11l1l1ll_ef_(COOKIEFILE)
        content=_getUrl(url,data,cookies)
        if not content and BRAMKA:
            content = getUrlh(url,data,cookies)
            content = urllib.unquote(content)
    return content
	
def getUrlh(url, data = None, cookies = None):
    proksy=getProksy()
    proxies = {"https": proksy}
    header = {'User-Agent': UA, 'Cookie': cookies}
    print 'GATE in USE'
    import requests
    content = requests.get(url, headers=header, proxies=proxies).content
    return content
	
def cf_setCookies(content,cfile):
    cj = cookielib.LWPCookieJar()
    content=BASEURL
    cookieJar = l11l11l11_ef_.l11l111ll_ef_(content,cj,UA)
    dataPath=os.path.dirname(cfile)
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    if cj:
        cj.save(cfile, ignore_discard = True)
    return cj
	
def l1llll1_ef_(url,data=None):
    out=[]
    nextPage=''
    prevPage=''
    header['Referer']=url,
    url=url.replace('efilmy.net/','efilmy.tv/')
    content = getUrl(url,data)
    items = re.compile('<div class="list-item">(.*?)</div>',re.DOTALL).findall(content)
    len(items)
    for item in items:
        href = re.compile('<a title=".*?" href="(.*?)" class="title_pl">(.*?)</a>').findall(item)
        href = re.compile('href="(.*?)" class="title_pl">(.*?)</a>').findall(item)
        en_title = re.compile('class="title_en">(.*?)</a>').findall(item)
        dtek = re.compile('<span class="dst">Kategoria: <a title=".*?" href=".*?">(.*?)</a>').findall(item)
        plot = re.compile('<p>(.*?)</p>').findall(item)
        image = re.compile('<img class="poster" src="(.*?)"').findall(item)
        if href and image:
            h= BASEURL+href[0][0]
            t= href[0][1]
            i= 'http://www.efilmy.tv/'+image[0].replace('/small/','/big/')
            d= dtek[0] if dtek else ''
            o= plot[0] if plot else ''
            year=''
            lektorEN=''
            tytul=''
            if en_title:
                year,lektorEN = en_title[0].split('|')[-1].split(',')
                tytul=en_title[0].split('|')[0].strip()
                year = year.strip()
                lektorEN = '[COLOR green] %s [/COLOR]'%lektorEN.strip()
            out.append({'title':charPL(t),'title_en':charPL(tytul),'audio':lektorEN,'url':h,'img':i,'year':year,'plot':o})
    pagination = re.compile('<div class="pagin">(.*?)</div>',re.DOTALL).findall(content)
    if pagination:
        nextPage=re.compile('<a href="(.*?)".*?>\&laquo;</a>').findall(pagination[0])
        prevPage=re.compile('<a href="(.*?)"').findall(pagination[0])
        if nextPage:
            nextPage = BASEURL + nextPage[0]
        if prevPage:
            prevPage = BASEURL + prevPage[-1]
    return (out, (nextPage,prevPage))
	
def l1l1111l_ef_(l1l1l1l_ef_='year'):
    out=[]
    url='http://www.efilmy.tv/filmy.html'
    header['Referer']=url
    content = getUrl(url)
    l1lllllll1_ef_ = re.compile('<ul class="movie-%s">(.*?)</ul>'%l1l1l1l_ef_,re.DOTALL).findall(content)
    if l1lllllll1_ef_:
        if l1l1l1l_ef_=='cat':
            l111111l1_ef_ = re.compile('<a title=".*?" href="(.*?)">(.*?)</a><span>(.*?)</span>').findall(l1lllllll1_ef_[0])
            for k in l111111l1_ef_:
                out.append( (' '.join(k[1:]),BASEURL+k[0]) )
        else:
            l111111l1_ef_ = re.compile('<a title="(.*?)" href="(.*?)">').findall(l1lllllll1_ef_[0])
            for k in l111111l1_ef_:
                out.append((k[0],BASEURL+k[1]))
    return out
	
def l111l1_ef_(page=0):
    out=[]
    url='http://www.efilmy.tv//seriale.php?cmd=slist&page=%d'%page
    content = getUrl(url)
    items= re.compile('<a title=".*?" href="(.*?)">(.*?)</a>').findall(content)
    for item in items:
        out.append({'title':charPL(item[1]),'url':BASEURL+item[0]})
    return out
	
def l1l1ll11_ef_(url):
    out=[]
    content = getUrl(url)
    idx = content.find('<div class="holder">')
    l1lll1l_ef_ = re.compile('<li>(.*?)</li>',re.DOTALL).findall(content[idx:])
    len(l1lll1l_ef_)
    for e in l1lll1l_ef_:
        href=re.compile('href="(.*?)"').findall(e)
        title=re.compile('>(.*?)<').findall(e)
        if href and title:
            h= BASEURL+href[0]
            t=''.join(title).replace('-->','').strip()
            out.append({'title':charPL(t),'url':h})
    return out
	
def l1l1l1l1_ef_(url):
    out=[]
    content = getUrl(url)
    l1llllll11_ef_= re.compile('(<div class=.*?</div>)',re.DOTALL).findall(content)
    for item in l1llllll11_ef_:
        href = re.compile('href="(.*?)" class="pl">(.*?)</a>').findall(item)
        en_title = re.compile('class="en">(.*?)</a>').findall(item)
        dtek = re.compile('<span class="(cat|dsc)">.*?<a title=".*?" href=".*?">(.*?)</a>(.*?)<').findall(item)
        plot = re.compile('<p>(.*?)</p>').findall(item)
        image = re.compile('src="(.*?)"').findall(item)
        one={}
        if href :
            one['url']= BASEURL+href[0][0]
            one['title']= charPL(href[0][1])
            one['img']= 'http://www.efilmy.tv/'+image[0].replace('/small/','/big/') if image else ''
            one['year']=''
            if dtek:
                if len(dtek[0])==3:
                    one['genre']= dtek[0][1] if dtek else ''
                    try:
                        lektorEN,year = dtek[0][-1].split('|')[-1].split(',')
                        one['year'] = year.strip()
                        one['audio'] = ' [COLOR green] %s [/COLOR]'%lektorEN.strip()
                    except:
                        pass
            one['plot']= plot[0] if plot else ''
            if len(en_title)==2:
                one['title'] += ' [COLOR lightblue]%s[/COLOR]' %(' '.join(en_title))
            out.append(one)
    return out
	
def search(letter='teoria wielkiego'):
    url='http://www.efilmy.tv/szukaj.html'
    data='word=%s&as_values_movie_title=hidden' % (letter.replace(' ','+'))
    l111ll1ll_ef_=[]
    l111l11ll_ef_=[]
    l111ll1ll_ef_, pagination = l1llll1_ef_(url,data)
    return l111ll1ll_ef_, pagination
	
def l1l111_ef_(url='http://streamin.to/embed-vz5xqczivdb8.html'):

    import jsunpack as jsunpack
    content=getUrl(url)
    l1llll1l11_ef_ = re.compile('eval(.*?\)\)\))',re.DOTALL).findall(content)
    for l1111llll_ef_ in l1llll1l11_ef_:
        l1111llll_ef_=re.sub('  ',' ',l1111llll_ef_)
        l1111llll_ef_=re.sub('','',l1111llll_ef_)
        try:
            l11111lll_ef_ = jsunpack.unpack(l1111llll_ef_)
        except:
            l11111lll_ef_=''
        if l11111lll_ef_:
            l1111l11l_ef_=l11111lll_ef_
            try:
                stream_url = re.compile("""file\s*:\s*['|"](http.+?)['|"]""").findall(l1111l11l_ef_)[0]
                r = urllib2.Request(stream_url, headers={'User-Agent': UA})
                r = urllib2.urlopen(r, timeout=15).headers['Content-Length']
                return stream_url
            except:
                pass
            try:
                l111l1l1l_ef_ = re.search('streamer:\s*"([^"]+)",', l1111l11l_ef_).group(1).replace(':1935', '')
                l111l1ll1_ef_ = re.search('file:\s*"([^"]+)",', l1111l11l_ef_).group(1).replace('.flv', '')
                return '%s playpath=%s' % (l111l1l1l_ef_, l111l1ll1_ef_)
            except:
                pass
    return ''
def l1l1llll_ef_(url):   #serialLinks

    l111l1111_ef_=[]
    a={}
    content = getUrl(url)
    l1llll1l1l_ef_ = re.compile('Odtwarzacz <em>(.*?)</em>').findall(content)
    wersja = re.compile('Wersja: <em>(.*?)</em>').findall(content)
    l1111ll11_ef_ = re.compile('name="ur_k" value="(.*?)"').findall(content)
    l111lll11_ef_='filmy.php'
    if l1111ll11_ef_:
        l111lll11_ef_ = base64.b64decode(l1111ll11_ef_[0])
        l111lll11_ef_ = l111lll11_ef_.split('?')[0]
    l111lll1l_ef_ = re.compile('<div id="(.*?)" alt="n" class="embedbg">').findall(content)
    for id,l1lllll11l_ef_,wersja in zip(l111lll1l_ef_,l1llll1l1l_ef_,wersja):
        content = 'http://www.efilmy.tv/%s?cmd=show_regular&id=%s'%(l111lll11_ef_,id)
        data = getUrl(content)
        if 'vidzer' in l1lllll11l_ef_:
            href =re.compile('<a href="(.*?)".*?id="player">').search(data).group(1)
            if href:
                l1111l111_ef_ = href +'|Referer=http://www.vidzer.net/media/flowplayer/flowplayer.commercial-3.2.18.swf'
                l111l1111_ef_.append({'href':l1111l111_ef_,'player':l1lllll11l_ef_,'cmd':'regular','msg': '%s (regular)' %l1lllll11l_ef_})
        else:
            if 'streamin.to' in l1lllll11l_ef_:
                href = re.compile('<a href="(.*?)" target="_blank">(.*?)</a>').findall(data)
                if href:
                    href = href[0]
                    if 'www.vidzer' in href[0] and  href[1].islower():
                        l1111l111_ef_='http://%s/embed-%s.html'%(l1lllll11l_ef_,href[1])
                        l111l1111_ef_.append({'href':l1111l111_ef_,'player':l1lllll11l_ef_,'cmd':'regular','msg': '%s [%s] (regular)' %(l1lllll11l_ef_,wersja)})
            l111l1111_ef_.append({'href':'','player':l1lllll11l_ef_,'cmd':'show','id':id,'typfs':l111lll11_ef_,'msg': '%s [%s] ([COLOR red]captcha to solve[/COLOR])' %(l1lllll11l_ef_,wersja)})
    return l111l1111_ef_
def l1111l1ll_ef_(content,cfile):
    cj = cookielib.LWPCookieJar()
    cookieJar = l11l11l11_ef_.l11l111ll_ef_(content.replace('efilmy.net/','efilmy.tv/'),cj,UA)
    dataPath=os.path.dirname(cfile)
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    if cookieJar:
        cookieJar.save(cfile, ignore_discard = True)
    return cj
def _1111ll1l_ef_(data):  #movieLinks
    l1111l111_ef_=''
    bs= re.compile("""document.write\(Base64.decode\("(.*?)"\)""").findall(data)
    if not bs:
        l1111llll_ef_ = re.compile("""eval(.*?)\{\}\)\)""",re.DOTALL).findall(data)
        try:
            l11111lll_ef_ = unpackstd.unpack(l1111llll_ef_[0])			
			
        except:
            l11111lll_ef_ = ''
        bs= re.compile("""document.write\(Base64.decode\("(.*?)"\)""").findall(l11111lll_ef_)
    if bs:
        a = bs[0].replace("\\\\x","").decode("hex") if "\\x" in bs[0] else bs[0]
        src = base64.b64decode(a)
        href = re.compile("""["'](http.*?)["']""").findall(src)
        if href:
            l1111l111_ef_=href[0]
    return l1111l111_ef_
def l1llll11_ef_(l111lll11_ef_,id,l1lllll11l_ef_,**args):
    l1111l111_ef_=''
    bs=[]
    content = 'http://www.efilmy.tv//%s?cmd=show_player&id=%s'%(l111lll11_ef_,id)
    l11111ll1_ef_ = l11l11l11_ef_.l11l1l1ll_ef_(COOKIEFILE)
    if l11111ll1_ef_:
        header['Accept']='text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        header['Cookie']=l11111ll1_ef_
        header['Referer']=content
    data = getUrl(content,header=header)
    l1111l111_ef_=_1111ll1l_ef_(data)
    if not l1111l111_ef_:
        cj=l1111l1ll_ef_(content,COOKIEFILE)
        l111111ll_ef_ = l11l11l11_ef_.l11l1l1ll_ef_(COOKIEFILE)
        header['Accept']='image/webp,image/*,*/*;q=0.8'
        header['Cookie']=l111111ll_ef_
        url='http://www.efilmy.tv/mirrory.php?cmd=generate_captcha&time=%f'%random.random()
        data = getUrl(url,header=header)
        r=l11ll11ll_ef_.l11ll11l1_ef_(data)
        print r
        header['Accept']='text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        header['Cookie']=l111111ll_ef_
        content = 'http://www.efilmy.tv//mirrory.php?cmd=check_captcha'
        l111l11l1_ef_=id.split('_')[0]
        mode = 's' if '_s' in id else 'f'
        l11111l1l_ef_ = 'captcha=%s&id=%s&mode=%s'%(r,l111l11l1_ef_,mode)
        data = getUrl(content,l11111l1l_ef_,header=header)
        l1111l111_ef_=_1111ll1l_ef_(data)
    return l1111l111_ef_
def charPL(letter):
    if type(letter) is not str:
        letter=letter.encode('utf-8')
    letter = letter.replace('&lt;br/&gt;',' ')
    letter = letter.replace('&quot;','"').replace('&amp;quot;','"')
    letter = letter.replace('&oacute;','ó').replace('&Oacute;','Ó')
    letter = letter.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    letter = letter.replace('&amp;','&')
    letter = letter.replace('\u0105','ą').replace('\u0104','Ą')
    letter = letter.replace('\u0107','ć').replace('\u0106','Ć')
    letter = letter.replace('\u0119','ę').replace('\u0118','Ę')
    letter = letter.replace('\u0142','ł').replace('\u0141','Ł')
    letter = letter.replace('\u0144','ń').replace('\u0144','Ń')
    letter = letter.replace('\u00f3','ó').replace('\u00d3','Ó')
    letter = letter.replace('\u015b','ś').replace('\u015a','Ś')
    letter = letter.replace('\u017a','ź').replace('\u0179','Ź')
    letter = letter.replace('\u017c','ż').replace('\u017b','Ż')
    return letter