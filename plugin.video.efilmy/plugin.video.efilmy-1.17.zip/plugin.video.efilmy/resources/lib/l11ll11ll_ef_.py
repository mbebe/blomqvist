# -*- coding: utf-8 -*-
import sys
import os,re,urllib
import xbmc,xbmcaddon,xbmcgui,xbmcvfs
l11ll1ll1_ef_    = xbmcaddon.Addon().getAddonInfo
l11ll1lll_ef_     = xbmcvfs.File
l11l1llll_ef_   = xbmcvfs.delete
dataPath     = xbmc.translatePath(l11ll1ll1_ef_('profile')).decode('utf-8')
l11ll1l1l_ef_        = xbmcgui.ControlImage
l11ll1111_ef_ = xbmcgui.WindowDialog()
l11ll111l_ef_     = xbmc.Keyboard
def l11ll11l1_ef_(response):
    i = os.path.join(dataPath,'captcha.png')
    f = l11ll1lll_ef_(i, 'w')
    f.write(response)
    f.close()
    f = l11ll1l1l_ef_(450,5,375,115, i)
    d = l11ll1111_ef_
    d.addControl(f)
    l11l1llll_ef_(i)
    d.show()
    k = xbmc.Keyboard('', '')
    k.doModal()
    c = k.getText() if k.isConfirmed() else None
    if c == '': c = None
    d.removeControl(f)
    d.close()
    return c