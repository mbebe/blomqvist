# -*- coding: utf-8 -*-
import sys
import urllib
import urllib2
import hashlib
import json
import re
sslurl = 'https://ssl.filmweb.pl/api?';
hash = 'qjcGhW2JnvGT9dfCt3uT_jozR3s';
baseurl = 'http://www.filmweb.pl';
VERSION = '2.2';
syst = 'android';
liveurl = 'http://www.filmweb.pl/search/live?q=';
slashC = '\\c';
slashA = '\\a';
imgurl = 'http://1.fwcdn.pl/po'
TIMEOUT=10
def _getUrl(url):
    '\n    Get Url contnetnt\n    return: string\n    '
    headers = {'User-Agent': 'Mozilla/5.0 (Linux; Android 4.1.1; Galaxy Nexus Build/JRO03C) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Mobile Safari/535.19',
            }
    req = urllib2.Request(url, None, headers)
    response = urllib2.urlopen(req,timeout=TIMEOUT)
    content = response.read()
    response.close()
    return content
def _1llll111l_ef_(method):
    signat = method + '\n' + syst + hash;
    signat = VERSION + ',' + hashlib.md5(signat).hexdigest();
    return signat;
def _1lll1l1ll_ef_(method):
    signat = _1llll111l_ef_(method);
    method += '\n';
    qs={    'methods':method,
            'signature':signat,
            'version':VERSION,
            'appId':syst}
    return urllib.urlencode(qs)
def _1lll1l1l1_ef_(response,_1lll1llll_ef_):
    _1lll111l1_ef_ = response.split(' t:')[0].split('\n')
    status = _1lll111l1_ef_[0]
    data = _1lll111l1_ef_[1]
    out={}
    if data=='null':
        pass
    else:
        l1ll1ll11l_ef_=json.loads(data)
        N=len(l1ll1ll11l_ef_)
        for k,v in _1lll1llll_ef_.iteritems():
            if l1ll1ll11l_ef_[k]==None:
                l1ll1ll11l_ef_[k]=''
            if N>= k: out[v]=l1ll1ll11l_ef_[k]
    return out
def getFilmInfoFull(filmID='185632'):
    method = 'getFilmInfoFull [' + filmID + ']'
    _1lll1llll_ef_ ={
        0 :  'title',
        1 :  'originaltitle',
        2 :  'rating',
        3 :  'votes',
        4 :  'genre',
        5 :  'year',
        6 :  'duration',
        7 :  'commentsCount',
        8 :  'forumUrl',
        9 :  'hasReview',
        10 :  'hasDescription',
        11 :  'img',
        12 :  'video',
        13 :  'premiereWorld',
        14 :  'date',
        15 :  'filmType',
        16 :  'seasonsCount',
        17 :  'episodesCount',
        18 :  'studio',
        19 :  'plot'
    }
    response = _getUrl( sslurl + _1lll1l1ll_ef_(method))
    out = {}
    if response[:2]=='ok':
        out =_1lll1l1l1_ef_(response,_1lll1llll_ef_)
        out['filmweb']=filmID
        if out.get('video'):
            videox = [ x for x in out.get('video') if 'mp4' in str(x) ]
            pattern = ['.360p.', '.480p.', '.720p.']
            l1ll1l111l_ef_ = videox[0]
            for p in pattern:
                for t in videox:
                    if p in t:
                        l1ll1l111l_ef_ = t
            out['trailer']=l1ll1l111l_ef_
        if out.get('img'):
            out['img']=imgurl + out.get('img').replace('.2.','.3.')
        if out.get('duration'):
            out['duration'] = float(out.get('duration'))*60
    return out
def l1lll1ll1l_ef_(filmID='594357'):
    method = 'getFilmsInfoShort [[' + filmID + ']]'
    _1lll1llll_ef_ = {
        0 :  'title',
        1 :  'year',
        2 :  'rating',
        3 :  '_',
        4 :  'duration',
        5 :  'img',
        6 :  'id'}
    response = _getUrl( sslurl + _1lll1l1ll_ef_(method))
    out = {}
    if response[:2]=='ok':
        out =_1lll1l1l1_ef_(response.replace('[[','[').replace(']]',']'),_1lll1llll_ef_)
    return out
def l1lll11ll1_ef_(filmID='594357', t='actors'):
    l1ll1ll1l1_ef_ = { 'directors': '1', 'scenarists': '2', 'musics': '3', 'photos': '4', 'actors': '6', 'producers': '9' }
    l1lll11l11_ef_ = ['id', 'role', 'role_type', 'name', 'img']
    l1lll1l11l_ef_ = {}
    if t in l1ll1ll1l1_ef_.keys():
        method = 'getFilmPersons [' + str(filmID) + ', ' + l1ll1ll1l1_ef_[t] + ', 0, 50]'
        response = _getUrl( sslurl + _1lll1l1ll_ef_(method))
        l1ll1lllll_ef_ = re.search('(\\[.*\\])', response)
        l1lll11l1l_ef_ = json.loads(l1ll1lllll_ef_.group(1))
        for data in l1lll11l1l_ef_:
            l1lll1l11l_ef_[data[0]] = {}
            for i in range(0, len(l1lll11l11_ef_)):
                if l1lll11l11_ef_[i] == 'img':
                    l1lll1l11l_ef_[data[0]][l1lll11l11_ef_[i]] = '' if data[i] == None else 'http://1.fwcdn.pl/p' + data[i].encode('utf-8').replace('.1.jpg', '.3.jpg')
                else:
                    l1lll1l11l_ef_[data[0]][l1lll11l11_ef_[i]] = data[i].encode('utf-8') if type(data[i]) == unicode else data[i]
    return l1lll1l11l_ef_
def l1lll1l111_ef_(filmID='1'):
    method = 'getFilmDescription [' + filmID + ']'
    _1lll1llll_ef_ = {0 :  'description'}
    response = _getUrl( sslurl + _1lll1l1ll_ef_(method))
    out = {}
    if response[:2]=='ok':
        out =_1lll1l1l1_ef_(response,_1lll1llll_ef_)
    return out
def _1lll11lll_ef_(result):
    l1ll1l11ll_ef_ = result.split(slashA);
    print '\tFound %d entries' %len(l1ll1l11ll_ef_)
    element=l1ll1l11ll_ef_[0]
    l1llll1111_ef_=[]
    for element in l1ll1l11ll_ef_:
        l1llllll1l_ef_=_1lll1ll11_ef_(element)
        if l1llllll1l_ef_: l1llll1111_ef_.append(l1llllll1l_ef_)
    return l1llll1111_ef_
def _1lll1ll11_ef_(element):
    l1lll1111l_ef_ = element.split(slashC);
    type = l1lll1111l_ef_[0]
    if type == 'f' or type == 's':
        result = _1lll11111_ef_(l1lll1111l_ef_);
    elif type == 'p':
        result=None
    else :
        result=None
    return result
def _1lll11111_ef_(l1lll1111l_ef_):
    item={}
    if len(l1lll1111l_ef_):
        item['type'] = l1lll1111l_ef_[0]
        item['id'] = l1lll1111l_ef_[1]
        item['img'] = imgurl + l1lll1111l_ef_[2]
        item['title_f'] = l1lll1111l_ef_[3]
        item['title_p'] = l1lll1111l_ef_[4]
        item['title_e'] = l1lll1111l_ef_[5]
        item['year'] = l1lll1111l_ef_[6]
        item['cast'] = l1lll1111l_ef_[7]
    return item
def l1lll111ll_ef_(param='stra\\u017cnicy galaktyki'):
    result = _getUrl( liveurl + urllib.quote_plus(param.encode('utf-8').lower()) )
    out = _1lll11lll_ef_(result)
    return out
def searchFilmweb(title='',year='',itemType='f'):
    "\n    Szuka informacji o filmie\n    itemType = 'f' - Film\n    itemType = 's' - Serial\n    "
    l1ll1l1l11_ef_={}
    search = '%s' % title.strip()
    search += ' %s' % year if year else ''
    out= l1lll111ll_ef_(search)
    if out:
        if len(out)==1:
            l1ll1l1l11_ef_ = out[0]
        else:
            for l1llllll1l_ef_ in sorted(out, key=lambda k: k['year'],reverse=True):
                if l1llllll1l_ef_.get('year','') in ['2017','2018','2019','2020']:
                    continue
                if l1llllll1l_ef_.get('type') == itemType:
                    l1ll1l1l11_ef_ = l1llllll1l_ef_
                    break
        return getFilmInfoFull(l1ll1l1l11_ef_.get('id',''))
    else:
        return l1ll1l1l11_ef_
if __name__=='__main__':
    pass
