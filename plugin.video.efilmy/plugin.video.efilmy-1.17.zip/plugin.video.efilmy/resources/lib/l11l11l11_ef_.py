# coding: UTF-8
import sys
import urlparse,cookielib,urllib2,urllib
import time,re,os
url='http://www.efilmy.tv/'
cj= cookielib.LWPCookieJar()
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'
def l11l111ll_ef_(url,cj=None,l11l1l111_ef_=UA):
    l11l11111_ef_=''
    try:
        class l11l11l1l_ef_(urllib2.HTTPErrorProcessor):
            def http_response(self, request, response):
                return response
        def l11l1111l_ef_(s):
            try:
                offset=1 if s[0]=='+' else 0
                val = int(eval(s.replace('!+[]','1').replace('!![]','1').replace('[]','0').replace('(','str(')[offset:]))
                return val
            except:
                pass
        if cj==None:
            cj = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(l11l11l1l_ef_, urllib2.HTTPCookieProcessor(cj))
        opener.addheaders = [('User-Agent', l11l1l111_ef_)]
        response = opener.open(url)
        result=l11l11111_ef_ = response.read()
        response.close()
        l11l1ll1l_ef_ = re.compile('name="jschl_vc" value="(.+?)"/>').findall(result)[0]
        init = re.compile('setTimeout\(function\(\){\s*.*?.*:(.*?)};').findall(result)[0]
        l11l1ll11_ef_ = re.compile("challenge-form'\);\s*(.*)a.v").findall(result)[0]
        l11l1l11l_ef_ = l11l1111l_ef_(init)
        lines = l11l1ll11_ef_.split(';')
        for line in lines:
            if len(line)>0 and '=' in line:
                l11l1l1l1_ef_=line.split('=')
                l111lllll_ef_ = l11l1111l_ef_(l11l1l1l1_ef_[1])
                l11l1l11l_ef_ = int(eval(str(l11l1l11l_ef_)+l11l1l1l1_ef_[0][-1]+str(l111lllll_ef_)))
        l11l111l1_ef_ = l11l1l11l_ef_ + len(urlparse.urlparse(url).netloc)
        u='/'.join(url.split('/')[:-1])
        query = '%s/cdn-cgi/l/chk_jschl?jschl_vc=%s&jschl_answer=%s' % (u, l11l1ll1l_ef_, l11l111l1_ef_)
        if 'type="hidden" name="pass"' in result:
            l11l11lll_ef_=re.compile('name="pass" value="(.*?)"').findall(result)[0]
            query = '%s/cdn-cgi/l/chk_jschl?pass=%s&jschl_vc=%s&jschl_answer=%s' % (u,urllib.quote_plus(l11l11lll_ef_), l11l1ll1l_ef_, l11l111l1_ef_)
            time.sleep(5)
        response = opener.open(query)
        response.close()
        opener = urllib2.build_opener(l11l11l1l_ef_,urllib2.HTTPCookieProcessor(cj))
        opener.addheaders = [('User-Agent', l11l1l111_ef_)]
        response = opener.open(url)
        response.close()
        return cj
    except:
        return None
def l11l1l1ll_ef_(COOKIEFILE):
    l11l11ll1_ef_=''
    if os.path.isfile(COOKIEFILE):
        cj = cookielib.LWPCookieJar()
        cj.load(COOKIEFILE)
        for c in cj:
            l11l11ll1_ef_+='%s=%s;'%(c.name, c.value)
    return l11l11ll1_ef_