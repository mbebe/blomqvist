# -*- coding: utf-8 -*-

import urllib2,urllib
import re,os,json
import cfcookie,cookielib
from urlparse import urlparse
import jsunpack
import requests

BASEURL='http://cda-hd.cc/'
BASEURL2='http://vod-share.com'
TIMEOUT = 10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'
COOKIEFILE=os.path.join(os.getcwd(),'cookie.cda')

BRAMKA = ''
packer = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)')
def _getUrl(url,data=None,cookies=''):
	req = urllib2.Request(url,data)
	req.add_header('User-Agent', UA)
	if cookies:
		req.add_header('Cookie', cookies)
	try:
		response = urllib2.urlopen(req,timeout=TIMEOUT)
		link = response.read()
		response.close()
	except:
		link=''
	return link

def getUrl(url,data=None):
	cookies=cfcookie.cookieString(COOKIEFILE)
	content=_getUrl(url,data,cookies)	

	if not content:
		cj=setCookies(BASEURL,COOKIEFILE)
		cookies=cfcookie.cookieString(COOKIEFILE)
		content=_getUrl(url,data,cookies)
	return content

def setCookies(link,cfile):
	cj = cookielib.LWPCookieJar()
	cookieJar = cfcookie.createCookie(link,cj,UA)
	cookiePath=os.path.dirname(cfile)
	if not os.path.exists(cookiePath):
		os.makedirs(cookiePath)
	if cj:
		cj.save(cfile,  True, True)
	return cj
def getPlot(href):
	content = getUrl(href)
	plot=re.findall('itemprop="description" content="(.+?)"',content,re.DOTALL)[0]
	return PLchar(plot)
def scanMainPage(url,page=1,group='<h3>Nowe od',opis=False):
	plot=''
	if '?s=' in url:
		url = url.replace('?s=','page/%d/?s=' %page)
	else:
		url += '/' if url[-1] != '/' else ''
		url = url + 'page/%d/' %page
	content = getUrl(url)
	out=[]
	nextPage=False
	prevPage=False
	ids = []
	if group:
		idx = [(m.start(0), m.end(0)) for m in re.finditer('<div id="slid\d+">', content,re.IGNORECASE) ]
		idx.append( (content.find('Ostatnio dodane'),content.find('Ostatnio dodane')) )
		for i in range(len(idx[:-1])):
			subset1=content[ idx[i][0]:idx[i+1][0] ]
			if group in subset1:
				content = subset1
				ids = [(a.start(), a.end()) for a in re.finditer('<div class="item"', content)]
				ids.append( (-1,-1) )
				break
		for i in range(len(ids[:-1])):
			subset2 = content[ ids[i][1]:ids[i+1][0] ]
			href = re.compile('<a href="(.*?)">',re.DOTALL).search(subset2)
			title = re.compile('<span class="ttps">(.*?)<',re.DOTALL).search(subset2)
			imag = re.compile('<img src="(.*?)"',re.DOTALL).search(subset2)
			rating_ = re.compile('</b>\s*(\d\.\d)</span>',re.DOTALL).search(subset2)
			year =  re.compile('<span class="ytps">(.*?)</span>',re.DOTALL).search(subset2)
			if href and title:
				imag = imag.group(1) if imag else ''
				if opis:
					try:
						plot=getPlot(href.group(1))
					except:
						plot=''
				if imag.startswith('//'):
					imag = 'http:'+imag
				one = {'href'   : href.group(1),
					'title'  : PLchar(title.group(1)),
					'img'	: imag,
					'rating' : rating_.group(1) if rating_ else '',
					'year'   : year.group(1) if year else '',
					'plot'	:	plot,
						}
				out.append(one)
	else:
		pagination = re.compile("""<div class=["']paginado["']>(.*?)</div>""",re.DOTALL).findall(content)
		pagination = urllib.unquote(pagination[0]) if pagination else content
		nextPage=False
		pager_=url.replace('page/%d/'%page,'page/%d' %(page+1))
		if pagination.find(pager_.split('//')[-1])>-1:
			nextPage = page+1
		ids = [(a.start(), a.end()) for a in re.finditer('<div id="mt.*" class="item">', content)]
		ids.append( (-1,-1) )
		for i in range(len(ids[:-1])):
			subset2 = content[ ids[i][1]:ids[i+1][0] ]
			href = re.compile('<div class="boxinfo">[\s]+<a href="(.*?)">',re.DOTALL).search(subset2)
			title = re.compile('<span class="tt">(.*?)<',re.DOTALL).search(subset2)
			plotCXT = re.compile('<span class="ttx">(.*?)(?:<div class="degradado"></div>){0,1}[\s]*</span>[\s]*',re.DOTALL).search(subset2)
			imag = re.compile('<div class="image">[\s]+<img src="(.*?)"',re.DOTALL).search(subset2)
			rating_ = re.compile('<span class="imdbs">(.*?)</span>',re.DOTALL).search(subset2)
			year =  re.compile('<span class="year">(.*?)</span>',re.DOTALL).search(subset2)
			quality = re.compile('<span class="calidad2">(.*?)</span>',re.DOTALL).search(subset2)
			votes_ = re.compile('<b>.+?</b> <b>(.*? głosów)</b>').search(subset2)
			if href and title:
				imag = imag.group(1) if imag else ''
				if imag.startswith('//'):
					imag = 'http:'+imag
				one = {'href'   : href.group(1),
					'title'  : PLchar(title.group(1)),
					'plot'   : PLchar(plotCXT.group(1)) if plotCXT else '',
					'img'	: imag,
					'rating' : rating_.group(1) if rating_ else '',
					'year'   : year.group(1) if year else '',
					'votes'  : votes_.group(1) if votes_ else '',
					'code'  : quality.group(1) if quality else '',
						}
				out.append(one)
		prevPage = page-1 if page>1 else False
	return (out, (prevPage,nextPage))

def getToken(url):		#brak
	content = getUrl(url)
	token = re.search('name="_token" type="hidden" value="(.*?)">',content).group(1)
	sitekey_ = re.search('sitekey: "(.*?)"',content).group(1)
	params = {'_token':'MgZMB1Wf4UBGphYF1i63mO467wxG8S5k5ckp4MOj',
			'g-recaptcha-response':'03AHJ_VuvwwkKF1I9LNhURRsPJsQO5_SlHqGqV9borBaUWqmnqNDfqH1pTIPymqUwLLkj4xh6nWgAmBnwVcZBVugmMJiVcpL6-T2cJGu5fDKmEsxaZs1OQGQxp8tOr2YpaVcAVpePetQlBV0yA8gTCQcpmnfYdOScQkxU9o_s5Q4sjP4Hov2QbbhGV9SI4O8a-VRAVXrUzpf6xyuevYsuX3HxHa_BsYQC9U7DX0jfjBJDmilJab6UDRdVCleG-jFw7RKp75UUhlzXALOFoh3IWaZW9jLe0F3mVemVTQ-13p0OAynwuoATZWFthEL8C0NKMUbdVg5d-_628k_BwD1R6Kd4XjuA9flQCEMgU5hzLm8R_K3FKaFkPpiuUS3mr-tXz7vstL9BIPXjQw68Y1umk_7rQvKJgIQA2Nfb5waTADF1gaCusYM4d14NH9F52kE4lrdbaY2US9uiNCqEfYhAczXyFgxxqBJ58B6PPz0k3M7-XqZStPzaMP4MDRFr4yuJ1An7don4im69cO8pC0yvgayWxsalM8JLCDiT7VmSka78GYd0BdwS_dC1TxTikhV8cH9adJXY5AtCJCI2ejtAccyY5iycie-zvNZejvaC8GYIfwKNeYA3Vi60gYNgIev2a5UMIQZfY4zWf_pjs8T7wDLqr08kRHtR7hybmmKsvYwGFkiDMveeqQx-vzVD4c9te79ZpOuRSmAN8ii2ArdYHWb_M69a0HffagzPtU8MCc6Lwu8T65w1xq7ILnQRoccppMwC9B8T8lzdIqS2yLCsgKxzcLFOeqpt_QAIdNgibyF3q7DZecl41r2hxNkHp6mT1kjkC8gwzCbgvJAoq7zuZUXvoQCuEEUNAucItHM9UcMDQ4iMYPwBWbsUfezABiOWne0F7QQcE_KVY4yE4RFSEntWl9nyyX9O2OY6hEi2e1G5BAeXD_1yiL9s-s68plikFF_lBrQY0vcaPnM69QSfnrUAnF5h7BGwlTkqBglw62uOw5Pn2ktygRP-BTTpgUxVa0fthxEjR_31VCUvBmD3nwviOOARBkNxwzNLvzB-LHQ4Iwt8RWVj1HD22QYAWjFTHUZNMYog3rFR11Xi2_7FUcUcOGFMzzkCmIofpX813lk5deDmHiVzoNXg2uRiaDJqdDgltT78AhMSFMZhoMimJUvHluuB09IFCkE0M_6dzPyi23gidZRjYod8pqV20G4Y1bC6ZzttlDbcRccDfKadcJu9EpGMcVLQnnBzseTS0CGm8N1NluDcjMhwnzm8teTJIegesipsH7QZ8UyfgcyFPd0-8cOkkmKgleEUDVXCtAkZSbYT03S-tUqKxikQ7QxJOEVrHM0Y5wVjLNTs0TWFUEDEo5iXv-6qw98zu6yiWiQ2pFb7SbxvfmXhK3qFWvkUClxjgBh7kVu5tkkDN011SB5ReoCJuLdfHLtOh2FqZ2w7PhGKBjevdAL2fCREhX1JtYN8yAUiPNjxkABtAbmyL7s-Kp2WbvvRqL4357tT6mNXCqg-fnM1iQ9oYAtPimJodvD8ZCKY5B9mc3aOuDIQzv6LT_opevVa97oF0lediU8gO63Euqm6gI5K0j5VPeVvpc0zyaYVXF9tx5QzFKtOEAC_KaTh-Su7UJnW4QbHUi9PlsggQP0JA56_ghTO8BjPY2u8K99HDh_dp4Eb1E0T9A1xtzrbX3ZgF05wCEJe5Lm2qX0UdZXy_AVuq7S3EM3MjhJIZ-Kbje7PofqlxGm09IhJxRcdE4jXZgrld7aPhv0BT1Q91DXrR8lLtY6NRBsZfkh9N'
		   }
	data=urllib.urlencode(params)
	a=getUrl('http://ouo.io/go/Fkbcu',data)

def getHostUrl(url,host=''):		#brak
	out='' 
	if url.startswith('http'):
		if 'linki.online' in url:
			content = getUrl(url)
			streams = re.compile("""top.location = ['"](.*?)['"];""").search(content)
			if streams:
				out = streams.group(1)
		if 'ouo.io' in url:
			out = url
		else:
			req = urllib2.Request(url)
			req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36')
			try:
				response = urllib2.urlopen(req)
				if response:
					out=response.url
					if out==url:
						content=response.read()
						streams = re.compile('<a href="(.*)" class').findall(content)
						for l in streams:
							if host in l:
								out = l
								break
					response.close()
			except:
				pass
	return out

def getContent_(url,content=None):
	if not content:
		content = getUrl(url)
	out  =[]
	movieData = re.compile('<div class="movieplay">(.*?)</div>',re.DOTALL|re.I).findall(content)
	names = re.compile('<ul class="idTabs">(.*?)</ul>',re.DOTALL).findall(content)
	if names:
		names = [x.strip() for x in re.compile('>(.*?)<',re.DOTALL).findall(names[0]) if x.strip()]
	else:
		names=[]
	for zz in movieData:
		href = re.compile('src="(.*?)"',re.DOTALL|re.I).search(zz)
		if href:
			hrefUrl = 'http'+ urllib.unquote(href.group(1)).split('http')[-1]
			if hrefUrl.startswith('http') and not 'youtube' in hrefUrl and not 'facebook' in hrefUrl:
				if 'goo.gl' in hrefUrl:
					hrefUrl=getGooGL(hrefUrl)
				host = urlparse(hrefUrl).netloc
				one = {'url' : hrefUrl,
					'title': '[%s]' %(host),
					'host': host	}
				out.append(one)
	if len(names)==len(out):
		for one,name in zip(out,names):
			one['title'] += ' [B]%s[/B]'%name
	return out
def getGoUnlim(url):
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:56.0) Gecko/20100101 Firefox/56.0',}
	content=requests.get(url,headers=headers,verify=False).content
	packed = packer.findall(content)
	unpacked = jsunpack.unpack(packed[0])	
	src=re.findall("""sources:\[['"](.+?)['"]""",unpacked)[0]
	return src
def getGooGL(url):
	headers = {'User-Agent': 'Mozilla/5.0 (Linux; Android 7.0; PLUS Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36',}
	content=requests.get(url,headers=headers,verify=False, allow_redirects=False).content	
	src=re.findall('<A HREF="(.+?)"',content)[0]
	return src	
def getVideos_(url):
	content = getUrl(url)
	
	ids = [(a.start(), a.end()) for a in re.finditer('<li class="elemento">', content)]
	ids.append( (-1,-1) )
	out=getContent_(url,content)
	for i in range(len(ids[:-1])):
		subset2 = content[ ids[i][1]:ids[i+1][0] ]
		href = re.compile('<a href="(.*?)"',re.DOTALL).search(subset2)
		host = re.compile('<img src="(?:.*?)" alt="(.*?)">[\s]+(.*?)</span>').search(subset2)
		j2_ = re.compile('<span class="c">(.*?)</span>',re.DOTALL).search(subset2)
		q2_ =re.compile('<span class="d">(.*?)</span>',re.DOTALL).search(subset2)
		if href and host:
			j= j2_.group(1) if j2_ else ''
			q= q2_.group(1) if q2_ else ''
			host = host.groups()[-1]
			hrefUrl = 'http'+ urllib.unquote(href.group(1)).split('http')[-1]
			link = hrefUrl.replace('http://cda-online.pl?','')
			if host:
				msg =''
				if 'ouo.io' in link:
					msg = '[COLOR red] ouo.io not supported[/COLOR]'
				one = {'url' : urllib.unquote(link),
					'title': '[%s] %s, %s %s' %(host,j,q,msg),
					'host': host	}
				out.append(one)
	return out

def scanEpisodes(url):
	content = getUrl(url)
	imag = re.compile('background-image:url\((.*?)\)').findall(content)
	imag = imag[-1] if imag else ''
	ids = [(a.start(), a.end()) for a in re.finditer('<div class="numerando">', content)]
	ids.append( (-1,-1) )
	out=[]
	for i in range(len(ids[:-1])):
		subset2 = content[ ids[i][1]:ids[i+1][0] ]
		href_ = re.compile('<a href="(.*?)">[\s]+(.*?)</a>',re.DOTALL).search(subset2)
		date = re.compile('<span class="date">(.*?)</span>').search(subset2)
		cyfra_ = re.compile('(\d+?) x (\d+?)</div>').findall(subset2)
		if href_:
			d= date.group(1) if date else ''
			t= href_.group(2)
			liczba_ ='x'.join(cyfra_[0]) if cyfra_ else ''
			t= liczba_+' '+t
			one = {'href'  : href_.group(1),
				'plot': PLchar(t.strip()),
				'title' : PLchar(t.strip()),
				'img':imag,
				'season': int(cyfra_[0][0]) if cyfra_ else '',
				'episode': int(cyfra_[0][1]) if cyfra_ else '',
				'aired' : d}
			out.append(one)
	return out

def splitToSeasons(out):
	out_s={}
	seasons = [x.get('season') for x in out]
	for s in set(seasons):
		out_s['Sezon %02d'%s]=[out[i] for i, j in enumerate(seasons) if j == s]
	return out_s

def l11111l11ll11l1_cdhd_(m):  #brak
	return 'href="'+urllib.unquote(m.group(1))
def genreYearFilter(catFS='film',typFS='gatunek'):

	content = getUrl(BASEURL)
	selected = []
	if catFS=='film':
		if typFS=='gatunek':
			
			selected = re.compile('><a href="(https://cda-hd.cc/gatunki/.+?)">(.+?)</a> <span>(.+?)<').findall(content)
		elif typFS=='rok':
			selected = re.compile('><a href="(https://cda-hd.cc/release-year/\d{4}[^"]*)">(\d{4})<').findall(content)
	elif catFS=='serial':
		if typFS=='gatunek':
			selected = re.compile('><a href="(https://cda-hd.cc/tvshows-genre/.+?)">(.+?)</a> <span>(.+?)<').findall(content)
		elif typFS=='rok':
			selected = re.compile('><a href="(https://cda-hd.cc/tvshows-release-year/\d{4}[^"]*)">(\d{4})<').findall(content)
	if selected:
		outx = [x[0] for x in selected]
		outz = [PLchar(' '.join(x[1:])) for x in selected]
		return (outz,outx)
	return False

def PLchar(letter):
	if isinstance(letter, unicode):
		letter = letter.encode('utf-8')
	letter = letter.replace('&lt;br/&gt;',' ')
	letter = letter.replace('&nbsp;','')
	s='JiNcZCs7'
	letter = re.sub(s.decode('base64'),'',letter)
	letter = letter.replace('&quot;','"').replace('&amp;quot;','"')
	letter = letter.replace('&oacute;','ó').replace('&Oacute;','Ó')
	letter = letter.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
	letter = letter.replace('&amp;','&')
	letter = letter.replace('\u0105','ą').replace('\u0104','Ą')
	letter = letter.replace('\u0107','ć').replace('\u0106','Ć')
	letter = letter.replace('\u0119','ę').replace('\u0118','Ę')
	letter = letter.replace('\u0142','ł').replace('\u0141','Ł')
	letter = letter.replace('\u0144','ń').replace('\u0144','Ń')
	letter = letter.replace('\u00f3','ó').replace('\u00d3','Ó')
	letter = letter.replace('\u015b','ś').replace('\u015a','Ś')
	letter = letter.replace('\u017a','ź').replace('\u0179','Ź')
	letter = letter.replace('\u017c','ż').replace('\u017b','Ż')
	return letter

def search(letter='indiana'):
	headerS = {
		'Origin': 'http://cda-hd.cc',
		'Accept-Encoding': 'gzip, deflate',
		'Accept-Language': 'en-US,en;q=0.8',
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36',
		'Accept': 'application/json, text/javascript, */*; q=0.01',
		'Referer': 'http://cda-hd.cc/wyszukiwarka/',
		'Connection': 'keep-alive',}
	url='http://api.searchiq.co/api/search/results?q=%s&engineKey=59344ef44ca3ca07a4bbbeb7b6ee6b38&page=0&itemsPerPage=8&group=0&autocomplete=1'
	try:
		import requests
   #	 req = urllib2.Request(url%letter.replace(' ','%20'),headers=headerS)
		response = requests.get(url%letter.replace(' ','%20'), headers=headerS)
	#	response = urllib2.urlopen(req,timeout=10)
		dd = json.loads(response.text)
	#	dd = json.loads(response.read)
	except:
		dd={}
	data = dd.get('main',{}).get('records',[])
	out_F=[]
	out_S=[]
	for item in data:
		href = item.get('url','')
		title = item.get('title','')
		title = re.sub('<[/]*em>',' ',title)
		plotCXT = item.get('body','')
		imag = item.get('image',[''])
		imag = imag[-1] if imag else ''
		if href and title:
			year = re.search('\d{4}',title)
		one = {'href' : href,
			'title' : PLchar(title),
			'plot' : PLchar(plotCXT) if plotCXT else '',
			'img' : imag,
			'year' : year.group() if year else '',
				}
		if '/tvshows/' in one['href']:
			out_S.append(one)
		else:
			out_F.append(one)
	return out_F,out_S
