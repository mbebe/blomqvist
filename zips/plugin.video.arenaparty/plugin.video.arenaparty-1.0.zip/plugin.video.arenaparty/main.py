# -*- coding: utf-8 -*-

import urlparse,sys,urllib
params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
mode = params.get('mode')
fname = params.get('foldername')
ex_link = params.get('ex_link')
page = params.get('page')
import xbmcgui,xbmc
import time,os
dialog = xbmcgui.Dialog()

if mode is None:
    from resources.lib import default
    default.arenaparty().root()
elif mode.startswith('_info_')  :
    from resources.lib import default
    default.arenaparty().info()
elif mode == 'popular_genres':
    from resources.lib import default
    default.arenaparty().Popular_Genres()
elif mode == 'genres_artists':
    from resources.lib import default
    default.arenaparty().Genres_Artists(ex_link)
elif mode == 'artist_content':
    from resources.lib import default
    default.arenaparty().Artist_Content(ex_link)
elif mode.startswith('__page__:'):
    from resources.lib import default
    default.arenaparty()._page(mode,ex_link)
elif mode == 'popular_albums':
    from resources.lib import default
    default.arenaparty().Popular_Albums()
elif mode == 'top_50':
    from resources.lib import default
    default.arenaparty().Top_50()
elif mode == 'new_releases':
    from resources.lib import default
    default.arenaparty().New_Releases()
elif mode == 'popular_albums_tracks':
    from resources.lib import default
    if ex_link.startswith('http'):
        traksy=ex_link
    else:
        from json import loads
        traksy = loads(ex_link)
    default.arenaparty().getTracks(traksy)
elif mode == 'user_content':
    from resources.lib import default
    default.arenaparty().User_Content(ex_link)
elif mode == 'AddToLibrary':
    from resources.lib import default
    default.arenaparty().AddToLibrary(ex_link)
elif mode == 'playYT':
    from resources.lib import default
    default.arenaparty().PlayYT(ex_link)
elif mode == 'playYTAll':
    from resources.lib import default
    default.arenaparty().PlayYTAll(ex_link)
elif mode.startswith('search'):
    from resources.lib import default
    default.arenaparty().Search(mode,ex_link)


