# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import json
import urllib
import urllib2

import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM

import urlparse

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.3filmy')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'

napisyVTT = xbmc.translatePath('special://temp/napisyVTT.txt')

FANART=RESOURCES+'../fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('name', None)
page = params.get('page','')
mcount= params.get('moviescount', None)
movie= params.get('movie', None)
rys= params.get('image', None)

katv = addon.getSetting('katV')
if not katv:
	addon.setSetting('katV','')
katn = addon.getSetting('katN') if katv else 'Wszystkie'

rokv = addon.getSetting('rokV')
if not rokv:
	addon.setSetting('rokV','')
rokn = addon.getSetting('rokN') if rokv else 'Wszystkie'


skatv = addon.getSetting('skatV')
if not skatv:
	addon.setSetting('skatV','')
skatn = addon.getSetting('skatN') if skatv else 'Wszystkie'

srokv = addon.getSetting('srokV')
if not srokv:
	addon.setSetting('srokV','')
srokn = addon.getSetting('srokN') if srokv else 'Wszystkie'

verv = addon.getSetting('verV')
if not verv:
	addon.setSetting('verV','')
vern = addon.getSetting('verN') if verv else 'Wszystkie'

alfv = addon.getSetting('alfV')
if not alfv:
	addon.setSetting('alfV','')
alfn = addon.getSetting('alfN') if alfv else 'Wszystkie'

UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'
TIMEOUT=15
sess  = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=1,fanart=FANART,moviescount=0):
	list_item = xbmcgui.ListItem(label=name)

	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')
	if not infoLabels:
		infoLabels={'title': name,'plot':name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': FANART})
	ok=xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page, 'moviescount' : moviescount,'movie':movie,'name':name,'image':image}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %P, %Y")
	return ok

def home():
	log=setcookies()
	usr= addon.getSetting('username')
	#if log:
	add_item('', "[B]Zalogowano - %s[/B]"%usr,'DefaultAddonService.png', " ", folder=False) if log else add_item('', "[B]Zaloguj[/B]",'DefaultAddonService.png', "settings", folder=False)

	add_item('', "[I][COLOR violet][B]Reset filtrów[/COLOR][/I][/B]",'DefaultAddonService.png', "resetfil", folder=False)	
	add_item('film', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "listFilmy3filmy", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', "-        [COLOR lime]Rok produkcji:[/COLOR] [B]"+rokn+"[/B]",'DefaultRecentlyAddedMovies.png', "film:rok", folder=False)	
	add_item('', "-        [COLOR lime]Kategorie:[/COLOR] [B]"+katn+"[/B]",'DefaultRecentlyAddedMovies.png', "film:kateg", folder=False)
	add_item('', "-        [COLOR lime]Wersja językowa:[/COLOR] [B]"+vern+"[/B]",'DefaultRecentlyAddedMovies.png', "film:jezyk", folder=False)
	add_item('serial', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "listFilmy3filmy", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', "-        [COLOR lime]Rok produkcji:[/COLOR] [B]"+srokn+"[/B]",'DefaultRecentlyAddedMovies.png', "serial:srok", folder=False)	
	add_item('', "-        [COLOR lime]Kategorie:[/COLOR] [B]"+skatn+"[/B]",'DefaultRecentlyAddedMovies.png', "serial:skateg", folder=False)
	add_item('', "-        [COLOR lime]Nazwy:[/COLOR] [B]"+alfn+"[/B]",'DefaultRecentlyAddedMovies.png', "serial:alfabet", folder=False)
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "listSearch", folder=True,fanart=RESOURCES+'fanart.png')
	
def setcookies():
	pwd = addon.getSetting('password')
	usr = addon.getSetting('username')
	loguj = addon.getSetting('logowanie')
	headers = {
		'Host': '3filmy.com',
		'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
		'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'upgrade-insecure-requests': '1',
		'te': 'trailers',
	}
	if loguj=='true' and pwd and usr:

		
		response = sess.get('https://3filmy.com', headers=headers,verify=False)
	
		headers = {
			'Host': '3filmy.com',
			'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
			'accept': '*/*',
			'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'x-requested-with': 'XMLHttpRequest',
			'origin': 'https://3filmy.com',
			'dnt': '1',
			'referer': 'https://3filmy.com/seriale/',
			'te': 'trailers',
		}
		
		data = 'a=signin-modal'
		
		response = sess.post('https://3filmy.com/ajax/modal', headers=headers, data=data,verify=False).content

		#expir,has=re.findall("""expires['"]\s*value=['"](.+?)['"].+?hash_['"]\s*value=['"](.+?)['"]""",response)[0]
		headers = {
			'Host': '3filmy.com',
			'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
			'accept': 'application/json, text/javascript, */*; q=0.01',
			'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'x-requested-with': 'XMLHttpRequest',
			'origin': 'https://3filmy.com',
			'referer': 'https://3filmy.com/seriale/',
			'te': 'trailers',
		}
		
		#data = 'expires=%s&hash_=%s&username=%s&password=%s&remember_me=ON'%(expir,has,usr,pwd)
		data = {k: v for k, v in re.findall('type="hidden"\s*name="([^"]+)"\s*value\s*=\s*"([^"]+)"', response)}
		data['password']=pwd
		data['nickname']=usr
		data['remember_me']='ON'
		response = sess.post('https://3filmy.com/ajax/login', headers=headers, data=data,verify=False)

		content = response.json()
		if content.has_key('success'):
			log = True
		else:
			xbmcgui.Dialog().notification('[B]Logowanie[/B]', 'Błędne dane logowania.',xbmcgui.NOTIFICATION_INFO, 6000,False)		
			log = False

	else:
		response = sess.get('https://3filmy.com/', headers=headers,verify=False)
		log = False
	sc=''.join(['%s=%s;'%(c.name, c.value) for c in sess.cookies])
	addon.setSetting('kukiz',sc)
	return log

	
def ListSerial(url):
	seasons=getSerial(url)	
	items = len(seasons)
	for i in sorted(seasons.keys()):
		add_item(name=name+' - '+i, url=urllib.quote(str(seasons[i])), mode='getEpisodes', image=rys, folder=True,  infoLabels=i, itemcount=items)	
	xbmcplugin.endOfDirectory(addon_handle)	
	

def getSerial(url):
	kukz = addon.getSetting('kukiz')
	headers = {
		'Host': '3filmy.com',
		'cookie':kukz,
		'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
		'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'upgrade-insecure-requests': '1',
		'te': 'trailers',
	}
	
	response = sess.get(url, headers=headers,verify=False).text
	plot = parseDOM(response, 'p')[0]
	cod = parseDOM(response, 'p')[1]
	hash=parseDOM(response, 'div', ret='data-hash')[0]
	links=parseDOM(response, 'div', attrs={'class':'se-c'})
	episodes=[]
	for link in links:
		ses = parseDOM(link, 'span', attrs={'class':'se-t\s*'})[0]
		eps = re.findall('id(.+?)<\/li>',link)
		for ep in eps:
			href = re.findall('data-id="(.+?)"',ep)[0]
			href = 'idhash:%s|%s'%(hash,href)
			tyt = re.findall('data-title="(.+?)"',ep)[0]
			tyt = name+' - '+tyt
			jak = parseDOM(ep,'i',ret='title')
			jak = ','.join([re.findall('^(.+?)\.',i)[0] for i in jak])
			try:
			
				epis = re.findall('epNo">(\d+)<',ep)[-1]
			except:
				epis = re.findall('epNo">(\d+)<',ep)[-1]
			episodes.append({'title':tyt,'href':href,'img':rys,'code':jak,'plot':plot,'season':int(ses),'episode':int(epis)})
	seasons = splitToSeasons(episodes)
	return seasons
	
def splitToSeasons(input):
    out={}
    seasons = [x.get('season') for x in input]
    for s in set(seasons):
        out['Sezon %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
	
def getEpisodes(seasons):
	episodes = eval(urllib.unquote(seasons))[::-1]
	items=len(episodes)

	for f in episodes: 
		ses=f.get('season')
		epp=f.get('episode')
		tyt=f.get('title').split('Season')[0]
		tyt2 = '%s - odc.%02d'%(name,epp)
		add_item(name=tyt2, url=f.get('href'), mode='play3Filmy', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)
	xbmcplugin.setContent(addon_handle, 'videos')	
	xbmcplugin.endOfDirectory(addon_handle)	
	
def ListFilmy3filmy(url,pg,katv,rokv,skatv,srokv,verv,alfv):
	page = int(pg)
	links, pagin=getFilmy3filmy(url,page,katv,rokv,skatv,srokv,verv,alfv)
	if links:
		itemz=links
		items = len(links)
		fold=False
		mud='play3Filmy'
		if 'serial' in url:
			fold=True
			mud='listSerial'
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, infoLabels=f, itemcount=items)	
		if pagin:
			for f in pagin:	
				add_item(name=f.get('title'), url=f.get('href'), mode='listFilmy3filmy', image=f.get('img'), folder=True,page=f.get('page'))	
		if 'film' in url:
			xbmcplugin.setContent(addon_handle, 'videos')	
		xbmcplugin.endOfDirectory(addon_handle)		
	else:
		xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Brak materiałów do wyświetlenia.',xbmcgui.NOTIFICATION_INFO, 6000)
	
def getFilmy3filmy(url,page,katg,rokg,skatg,srokg,verg,alfg):
	out=[]
	npout=[]
	kukz = addon.getSetting('kukiz')
	
	headers = {
			'Host': '3filmy.com',
		'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
		'accept': '*/*',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
		'x-requested-with': 'XMLHttpRequest',
		'dnt': '1',
		'cookie':kukz,
		'te': 'trailers',
	}
	
	typ='0'
	co='film'
	kolej = addon.getSetting('sortuj')
	spsort='wszystkie'
	if kolej=='ost.zaktualizowane':
		spsort='aktualizacja'
	elif kolej=='najlepsze':
		spsort='najlepsze'
	dane='{"a":[],"m":["%s"],"g":[%s],"y":[%s],"v":[%s]}'%(spsort,katg,rokg,verg)
	if 'serial' in url:
		typ='1'
		co='serial'
		dane='{"a":[%s],"m":["%s"],"g":[%s],"y":[%s],"v":[]}'%(alfg,spsort,skatg,srokg)
	dane=urllib.quote(dane)
	data = 'load=%s&page=%s&type=%s'%(dane,page,typ)
	html = sess.post('https://3filmy.com/ajax/load.videos', headers=headers, data=data,verify=False).content
	nxtpage=re.findall('^(\d+)<div',html)#[0]
	if nxtpage:
		if nxtpage[0]!='0':
			npout.append({'title':'Następna strona','href':co,'img':RESOURCES+'nextpage.png','plot':'','page':page+1}) 
		
		items=parseDOM(html, 'div', attrs={'class':'col-xs-\d+ mbox'})
		
		for item in items:
			img=parseDOM(item,'img',ret='src')[0]
			href=parseDOM(item,'a',ret='href')[0]
			href='https://3filmy.com'+href
			title=parseDOM(item, 'a', attrs={'class':'title-truncate video-title'})[0]
			opis=parseDOM(item, 'span', attrs={'style':'font-size:.+?'})[0]
			yeargenre=parseDOM(item, 'small', attrs={'class':'title-truncate.+?'})[0]#e
			jak=parseDOM(item,'i',ret='title')#[0]
			jak=','.join([re.findall('^(.+?)\.',i)[0] for i in jak])
			title = title+' (%s)'%yeargenre.split('|')[0] if 'serial' in url else title
			out.append({'title':PLchar(title),'href':href,'img':img,'plot':PLchar(opis),'year':yeargenre.split('|')[0],'genre':yeargenre.split('|')[1],'code':jak})
	return out,npout
	
def Play3Filmy(url):
	kukz = addon.getSetting('kukiz')
	
	if 'idhash' not in url:
		headers = {
			'Host': '3filmy.com',
			'cookie':kukz,
			'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
			'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
			'upgrade-insecure-requests': '1',
			'te': 'trailers',
		}
		
		response = sess.get(url, headers=headers,verify=False).text
		opis=re.findall('"description" content="(.+?)"',response)
		opis = opis[0] if opis else ''
		idhash=re.findall('"player-ajax" data-type="0" data-id="(.+?)" data-hash="(.+?)">',response)[0]
		
		headers = {
			'Host': '3filmy.com',
			'cookie':kukz,
			'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
			'accept': 'application/json, text/javascript, */*; q=0.01',
			'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'x-requested-with': 'XMLHttpRequest',
			'te': 'trailers',
		}
		
		data = 'id=%s&hash=%s&d=-1&q=-1&w=-1'%(idhash[0],idhash[1])
		aa = sess.post('https://3filmy.com/ajax/video.details', headers=headers, data=data,verify=False).text
		#xbmc.log('@#@CHANNEL-VIDEO-LINK: %s' % str(aa), xbmc.LOGNOTICE)
		qual=max(eval(re.findall('q_avb":(\[.+?\])',aa)[0]))
		rodzaje=re.findall('\[(\d+),"(.+?)",".+?"\]',aa)
		if rodzaje:
			if len(rodzaje)>1:
				url = [x[0].strip() for x in rodzaje]
				label = [x[1].strip() for x in rodzaje]
				s = xbmcgui.Dialog().select('Wybierz wersję',label)
				if s>-1:
					d=url[s]
					co=label[s]
				else:
					quit()	
			else:
				
				d=rodzaje[0][0]
				co=rodzaje[0][1]
			data = 'id=%s&hash=%s&d=%s&q=%s&w=-1'%(idhash[0],idhash[1],d,qual)
	else:
		hash,id=(re.findall(':(.+?)$',url)[0]).split('|')
		opis=''
		
		
		headers = {
			'Host': '3filmy.com',
			'cookie':kukz,
			'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
			'accept': 'application/json, text/javascript, */*; q=0.01',
			'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'x-requested-with': 'XMLHttpRequest',
			'te': 'trailers',
		}
		
		data = 'id=%s&hash=%s&d=-1&q=-1&w=-1&ep=true'%(id,hash)
		
		aa = sess.post('https://3filmy.com/ajax/video.details', headers=headers, data=data,verify=False).text
	
		qual=max(eval(re.findall('q_avb":(\[.+?\])',aa)[0]))
		rodzaje=re.findall('\[(\d+),"(.+?)",".+?"\]',aa)
		if rodzaje:
			if len(rodzaje)>1:
				url = [x[0].strip() for x in rodzaje]
				label = [x[1].strip() for x in rodzaje]
				s = xbmcgui.Dialog().select('Wybierz wersję',label)
				if s>-1:
					d=url[s]
					co=label[s]
				else:
					quit()	
			else:
				
				d=rodzaje[0][0]
				co=rodzaje[0][1]
			data = 'id=%s&hash=%s&d=%s&q=%s&w=-1&ep=true'%(id,hash,d,qual)	
	aa = sess.post('https://3filmy.com/ajax/video.details', headers=headers, data=data,verify=False).json()
	id=aa['id']
	
	link=urllib.unquote(aa['link'])
	h = [hex(ord(i)) for i in link]
	x = [hex(int(i, 16) ^ 0x5d) for i in h]
	stream_url = ''.join([chr(int(i, 16)) for i in x])
	sturl=stream_url+'|auth=SSL/TLS&verifypeer=false'
	play_item = xbmcgui.ListItem(path=sturl)#
	
	if 'napisy' in co.lower():
		co=(re.findall('napisy (\w+)',co,re.I)[0]).lower()
		import urlparse
		host = urlparse.urlsplit(stream_url).netloc
		nap='https://%s/cc/%s_%s.vtt'%(host,id,co)
		content = requests.get(nap,verify=False).content
		open(napisyVTT, 'w').write(content)	
		play_item.setSubtitles([napisyVTT])
	play_item.setInfo(type="Video", infoLabels={"title": name,'plot':opis})
	
	play_item.setArt({'thumb': rys, 'poster': rys, 'banner': rys, 'fanart': FANART})
	
	play_item.setProperty("IsPlayable", "true")
	Player = xbmc.Player()
	Player.play(stream_url, play_item)

def ListSearch():
	d = xbmcgui.Dialog().input(u'Szukaj...', type=xbmcgui.INPUT_ALPHANUM)
	if d:
		kukz = addon.getSetting('kukiz')
		headers = {
			'Host': '3filmy.com',
			'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
			'accept': 'application/json, text/javascript, */*; q=0.01',
			'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
			'x-requested-with': 'XMLHttpRequest',
			'cookie':kukz,
			'te': 'trailers',
		}
		
		params = (
			('q', d),
		)
		
		response = sess.get('https://3filmy.com/ajax/search', headers=headers, params=params, verify=False).json()
		if response:
			for link in response:
				url=link['link']
				
				tyt=link['t']
				img=link['img']
				fold=False
				mud='play3Filmy'
				if '/serial/' in url:
					fold=True
					mud='listSerial'
				add_item(name=PLchar(tyt), url='https://3filmy.com'+url, mode=mud, image=img, folder=fold, infoLabels=False)	
			xbmcplugin.endOfDirectory(addon_handle)	
		else:
			xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Nic nie znaleziono.',xbmcgui.NOTIFICATION_INFO, 6000)

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&#039;',"'")
	char = char.replace('&quot;','"').replace('&oacute;','ó').replace('&rsquo;',"'")
	char = char.replace('&nbsp;',".").replace('&amp;','&').replace('&eacute;','e')
	return char	

def router(paramstring):
	params = dict(parse_qsl(paramstring))
	if params:
		mode = params.get('mode', None)
		
		if mode == 'listFilmy3filmy':
			ListFilmy3filmy	(exlink,page,katv,rokv,skatv,srokv,verv,alfv)
		
		elif mode == 'listSerial':
			ListSerial(exlink)
			
		elif mode == 'getEpisodes':	
			getEpisodes(exlink)
		
		elif mode == 'listSeriale':
			ListSeriale(exlink,page)
				
		elif mode == 'listSearch':
			ListSearch()			

		elif mode == 'resetfil':
			n='Wszystkie'
			v=''
			addon.setSetting('katV',v)
			addon.setSetting('skatV',v)
			addon.setSetting('alfV',v)
			addon.setSetting('verV',v)
			addon.setSetting('rokV',v)
			addon.setSetting('srokV',v)
			
			addon.setSetting('katN',n)
			addon.setSetting('skatN',n)
			addon.setSetting('alfN',n)
			addon.setSetting('nerN',n)
			addon.setSetting('rokN',n)
			addon.setSetting('srokN',n)	
			xbmc.executebuiltin("Container.Refresh") 
		
		elif 'kateg' in mode:
			if 'film' in mode:
				myMode = 'kat'
			else:
				myMode = 'skat'
			
			label =['Wszystkie','Akcja','Animacja','Biograficzny','Detektywistyczny','Dokumentalny','Dramat','Familijny','Fantasy','Film-Noir','Historyczny','Horror','Katastroficzny','Komedia','Kostiumowy','Kryminał','Krótkometrażowy','Musical','Muzyczny','Obyczajowy','Przygodowy','Romans','Sci-Fi','Sensacyjny','Sport','Thriller','Western','Wojenny']
			value = ['','akcja','animacja','biograficzny','detektywistyczny','dokumentalny','dramat','familijny','fantasy','film-noir','historyczny','horror','katastroficzny','komedia','kostiumowy','kryminał','krótkometrażowy','musical','muzyczny','obyczajowy','przygodowy','romans','sci-fi','sensacyjny','sport','thriller','western','wojenny']
			msg = 'kategorie'
			
			try:
				sel = xbmcgui.Dialog().multiselect('Wybierz '+msg,label)
			except:
				sel = xbmcgui.Dialog().select('Wybierz '+msg,label)
			if not sel: sel=quit()
			if isinstance(sel,list):

				n = '%s'%','.join( [ label[i] for i in sel]) if sel[0]>-1 else ''			
				v= ','.join('"{0}"'.format(value[i]) for i in sel) if sel[0]>-1 else ''
				if 'Wszystkie' in n:	
					n='Wszystkie'
					v=''

			else:
				sel = sel if sel>-1 else quit()
				v = '%s'%(value[sel])
				n = '%s'%(label[sel])

			addon.setSetting(myMode+'V',v)
			addon.setSetting(myMode+'N',n)		
			xbmc.executebuiltin("Container.Refresh") 	
			
		elif 'alfabet' in mode:
			value = ['','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','1','2','9']
			label =['Wszystkie','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','1','2','9']
			msg = 'literę/litery'
			myMode = 'alf'
			try:
				sel = xbmcgui.Dialog().multiselect('Wybierz '+msg,label)
			except:
				sel = xbmcgui.Dialog().select('Wybierz '+msg,label)
			if not sel: sel=quit()
			if isinstance(sel,list):
				n = '%s'%','.join( [ label[i] for i in sel]) if sel[0]>-1 else ''							
				v= ','.join('"{0}"'.format(value[i]) for i in sel) if sel[0]>-1 else ''

				if 'Wszystkie' in n:	
					n='Wszystkie'
					v=''
			else:
				sel = sel if sel>-1 else quit()
				v = '%s'%(value[sel])
				n = '%s'%(label[sel])
			addon.setSetting(myMode+'V',v)
			addon.setSetting(myMode+'N',n)		
			xbmc.executebuiltin("Container.Refresh") 
			
			
		elif 'jezyk' in mode:
			value = ['','6','1','5','0','4','3']
			label =['Wszystkie','Polski','Lektor','Dubbing','Napisy PL','Napisy EN','ENG']
		
			msg = 'wersję językową'
			myMode = 'ver'
			try:
				sel = xbmcgui.Dialog().multiselect('Wybierz '+msg,label)
			except:
				sel = xbmcgui.Dialog().select('Wybierz '+msg,label)
			if not sel: sel=quit()
			if isinstance(sel,list):
				n = '%s'%','.join( [ label[i] for i in sel]) if sel[0]>-1 else ''		
				v= ','.join('"{0}"'.format(value[i]) for i in sel) if sel[0]>-1 else ''
				if 'Wszystkie' in n:	
					n='Wszystkie'
					v=''
			else:
				sel = sel if sel>-1 else quit()
				v = '%s'%(value[sel])
				n = '%s'%(label[sel])
			addon.setSetting(myMode+'V',v)
			addon.setSetting(myMode+'N',n)		
			xbmc.executebuiltin("Container.Refresh") 
			
		elif 'rok' in mode:
			if 'film' in mode:
				myMode = 'rok'
			else:
				myMode = 'srok'

			label = ['Wszystkie','2020','2019','2018','2017', '2016', '2015', '2014', '2013', '2012', '2011', '2010', '2009', '2008', '2007', '2006', '2005', '2004', '2003', '2002', '2001', '2000', '1999', '1998', '1997', '1996', '1995', '1994', '1993', '1992', '1991', '1990', '1989', '1988', '1987', '1986', '1985', '1984', '1983', '1982', '1981', '1980', '1979', '1978', '1977', '1976', '1975', '1974', '1973', '1972', '1971', '1970', '1969', '1968', '1967', '1966', '1965', '1964', '1963', '1962', '1961', '1960', '1959', '1958', '1957', '1956', '1955', '1954', '1953', '1952', '1951', '1950', '1949', '1948', '1947', '1946', '1945', '1944', '1943', '1942', '1941', '1940', '1939', '1938', '1937', '1936', '1935', '1934', '1933', '1932', '1931', '1930', '1929', '1928', '1927', '1926', '1925', '1924', '1923', '1922', '1921', '1920', '1919', '1918', '1917', '1916', '1915', '1914', '1911', '1908', '1902']
			value=['','2020','2019','2018','2017', '2016', '2015', '2014', '2013', '2012', '2011', '2010', '2009', '2008', '2007', '2006', '2005', '2004', '2003', '2002', '2001', '2000', '1999', '1998', '1997', '1996', '1995', '1994', '1993', '1992', '1991', '1990', '1989', '1988', '1987', '1986', '1985', '1984', '1983', '1982', '1981', '1980', '1979', '1978', '1977', '1976', '1975', '1974', '1973', '1972', '1971', '1970', '1969', '1968', '1967', '1966', '1965', '1964', '1963', '1962', '1961', '1960', '1959', '1958', '1957', '1956', '1955', '1954', '1953', '1952', '1951', '1950', '1949', '1948', '1947', '1946', '1945', '1944', '1943', '1942', '1941', '1940', '1939', '1938', '1937', '1936', '1935', '1934', '1933', '1932', '1931', '1930', '1929', '1928', '1927', '1926', '1925', '1924', '1923', '1922', '1921', '1920', '1919', '1918', '1917', '1916', '1915', '1914', '1911', '1908', '1902']
			ex_link='year'
			msg = 'rok/lata produkcji'
			
			try:
				sel = xbmcgui.Dialog().multiselect('Wybierz '+msg,label)
			except:
				sel = xbmcgui.Dialog().select('Wybierz '+msg,label)
			if not sel: sel=quit()
			if isinstance(sel,list):
				n = '%s'%','.join( [ label[i] for i in sel]) if sel[0]>-1 else ''				
				v= ','.join('"{0}"'.format(value[i]) for i in sel) if sel[0]>-1 else ''

				if 'Wszystkie' in n:	
					n='Wszystkie'
					v=''
			else:
				sel = sel if sel>-1 else quit()
				v = '%s'%(value[sel])
				n = '%s'%(label[sel])
			addon.setSetting(myMode+'V',v)
			addon.setSetting(myMode+'N',n)		
			xbmc.executebuiltin("Container.Refresh") 	
			
		elif mode == 'play3Filmy':	
			Play3Filmy(exlink)
		elif mode == 'settings':
			addon.openSettings()
			xbmc.executebuiltin('XBMC.Container.Refresh()')
	else:
		home()
		xbmcplugin.endOfDirectory(addon_handle)	
if __name__ == '__main__':
    router(sys.argv[2][1:])
