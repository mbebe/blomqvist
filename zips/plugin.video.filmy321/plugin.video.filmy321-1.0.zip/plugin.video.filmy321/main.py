# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import base64
import urllib
import urllib2
#import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import json
import cookielib
import traceback
import urlparse
import resolveurl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.filmy321')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'

FANART=RESOURCES+'fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('name', None)
page = params.get('page','')
mcount= params.get('moviescount', None)
movie= params.get('movie', None)
rys= params.get('image', None)

kukz=''

sortv = addon.getSetting('sortV')
sortn = addon.getSetting('sortN') if sortv else 'Ostatnio dodane'

katv = addon.getSetting('katV')
katn = addon.getSetting('katN') if katv else 'Wszystkie'

werv = addon.getSetting('werV')
wern = addon.getSetting('werN') if werv else 'Wszystkie'

UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'
TIMEOUT=15
MAIN_URL='https://www.filmy321.pl'
s = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=0,fanart=FANART,moviescount=0):
	list_item = xbmcgui.ListItem(label=name)

	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')
	if not infoLabels:
		infoLabels={'title': name,'plot':name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	
	art_keys = ['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
	art = dict(zip(art_keys,[image for x in art_keys]))
	art['landscape'] = fanart if fanart else art['landscape']
	art['fanart'] = fanart if fanart else art['landscape']
	list_item.setArt(art)
	if 'Następna strona' not in infoLabels.get('title',''):
		isp = []
		isp.append(('Informacja', 'XBMC.Action(Info)'),)
		list_item.addContextMenuItems(isp, replaceItems=False)
	
	
	ok=xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page, 'moviescount' : moviescount,'movie':movie,'name':name,'image':image}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	return ok

def home():

	add_item('', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "listmovies", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', "[COLOR lightblue]Sortowanie:[/COLOR] [B]"+sortn+"[/B]",'DefaultRecentlyAddedMovies.png', "filtr:sort", folder=False)	
	add_item('', "[COLOR lightblue]Kategoria:[/COLOR] [B]"+katn+"[/B]",'DefaultRecentlyAddedMovies.png', "filtr:kateg", folder=False)
	add_item('', "[COLOR lightblue]Wersja:[/COLOR] [B]"+wern+"[/B]",'DefaultRecentlyAddedMovies.png', "filtr:wersja", folder=False)
	add_item('1', '[B][COLOR khaki]Premiery filmowe[/COLOR][/B]', 'DefaultMovies.png', "listpopular", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('2', '[B][COLOR khaki]Ostatnio dodane[/COLOR][/B]', 'DefaultMovies.png', "listpopular", folder=True,fanart=RESOURCES+'fanart.png')

	
	add_item(' ', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "listSearch", folder=True,fanart=RESOURCES+'fanart.png')

def getRequests(url,data={},ref=None):
	headers = {
		'User-Agent': UA,
		'Accept': 'text/html, */*; q=0.01',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Connection': 'keep-alive',}
	if data:
		headers = {
			'User-Agent': UA,
			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
			'Referer': 'https://www.filmy321.pl/',
			'Content-Type': 'application/x-www-form-urlencoded',
			'Connection': 'keep-alive',
			'Upgrade-Insecure-Requests': '1',
			'TE': 'Trailers',}

		content=s.post(url,headers=headers,data=data,verify=False).content
	else:
		if ref:
			ab=s.get(ref,headers=headers)
			headersx = {
				'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0',
				'Accept': 'text/html, */*; q=0.01',
				'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
				'Referer': ref,
				'X-Requested-With': 'XMLHttpRequest',
				'Connection': 'keep-alive',
				'TE': 'Trailers',
			}
			headers=headersx
		
		content=s.get(url,headers=headers,cookies=s.cookies).content
	return content

def PlayVids(exlink):
	vidurl='https://www.filmy321.pl/player.php'
	
	html=getRequests(vidurl,ref=exlink)

	if 'e obci' in html:
		
		play_item = xbmcgui.ListItem(path=None)
		play_item.setProperty('IsPlayable', 'false')
		xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)
		xbmc.executebuiltin('Notification(Problem, ' + 'Zbyt duże obiążenie' + ', 1200)')
		return
	else:

		vid_url=re.findall('src="([^"]+)"',html)#[0]
		if vid_url:
			try:
				stream_url = resolveurl.resolve(vid_url[0])
			except Exception,e:
				stream_url=''
				play_item = xbmcgui.ListItem(path=None)

				xbmc.executebuiltin('Notification(Problem, ' + str(e) + ', 1200)')
				return
	
			if stream_url:
				play_item = xbmcgui.ListItem(path=stream_url)
				xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

		else:
			xbmc.executebuiltin('Notification(Problem, ' + 'Brak źródeł' + ', 1200)')
			return
			
def ListPopular(ids):
	id=int(ids)
	links=getPopular(id)
	itemz=links
	items = len(links)
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='playVids', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
	xbmcplugin.setContent(addon_handle, 'videos')	
	xbmcplugin.endOfDirectory(addon_handle)	
	
def getPopular(id):
	html=getRequests(MAIN_URL)
	out=[]
	result = parseDOM(html, 'div', attrs={'class': "main_container"})[id]
	links = parseDOM(result, 'div', attrs={'class': "movie_info"})
	for link in links:
		href = parseDOM(link, 'a', ret='href')[0]
		imag = parseDOM(link, 'img', ret='src')[0]
		
		if id==1:
			tyt = (parseDOM(link, 'h2')[0]).strip()
		else:
			tyt = (re.findall('class="movie_infot">([^>]+)<br',link)[0]).strip()
		cod = parseDOM(link, 'strong')[0]
		href = MAIN_URL+href if href.startswith('/') else href
		imag = MAIN_URL+imag if imag.startswith('/') else imag
		out.append({'title':PLchar(tyt),'href':href,'img':imag,'code':cod,'plot':PLchar(tyt)})
	return out

def ListMovies(url,pg,katv,sortv,werv):
	page = int(pg)
	links, pagin=getMovies(url,page,katv,sortv,werv)
	itemz=links
	items = len(links)
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='playVids', image=f.get('img'), folder=False, infoLabels=f, itemcount=items, IsPlayable=True)	
	if pagin:
		for f in pagin:	
			add_item(name=f.get('title'), url=f.get('href'), mode='listmovies', image='', folder=True,page=f.get('page'))	
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)		
	
def getMovies(url,page,katg,sortv,wersja):
	out=[]
	npout=[]
	url='https://www.filmy321.pl/%s/%s/%s/%s'%(sortv,katg,wersja,page)
	html=getRequests(url)
	if html.find('<div class="next_site">Nast')>0:
		npout.append({'title':'Następna strona','href':'','img':'','plot':'','page':page+1}) 
	links = parseDOM(html, 'div', attrs={'class': "movie_info"})

	for link in links:
		href = parseDOM(link, 'a', ret='href')[0]
		imag = parseDOM(link, 'img', ret='src')[0]
		tyt = (re.findall('class="movie_infot">([^>]+)<br',link)[0]).strip()
		cod = parseDOM(link, 'strong')[0]
		href = MAIN_URL+href if href.startswith('/') else href
		imag = MAIN_URL+imag if imag.startswith('/') else imag
		out.append({'title':PLchar(tyt),'href':href,'img':imag,'code':cod,'plot':PLchar(tyt)})

	return out,npout

def ListSearch(pg):
	d = xbmcgui.Dialog().input(u'Szukaj...', type=xbmcgui.INPUT_ALPHANUM)
	if d:

		movies=getSearch(d)
		if movies:
			itemz=movies
			items = len(movies)
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode='playVids', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)
			xbmcplugin.setContent(addon_handle, 'videos')	
			xbmcplugin.endOfDirectory(addon_handle)	
		
def getSearch(d):
	data = {'search': d,'wyslij_szuk': 'Szukaj filmu'}
	url='https://www.filmy321.pl/pokaz_film'

	out=[]
	html=getRequests(url,data)
	links = parseDOM(html, 'div', attrs={'class': "movie_info"})

	for link in links:
		href = parseDOM(link, 'a', ret='href')[0]
		imag = parseDOM(link, 'img', ret='src')[0]
		tyt = (re.findall('class="movie_infot">([^>]+)<br',link)[0]).strip()
		cod = parseDOM(link, 'strong')[0]

		href = MAIN_URL+href if href.startswith('/') else href
		imag = MAIN_URL+imag if imag.startswith('/') else imag
		out.append({'title':PLchar(tyt),'href':href,'img':imag,'code':cod,'plot':PLchar(tyt)})
	return out

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&#039;',"'")
	char = char.replace('&quot;','"')
	char = char.replace('&nbsp;',".").replace('&amp;','&').replace('&prime;',"'")
	return char	
	
if __name__ == '__main__':
	mode = params.get('mode', None)
	
	if not mode:
		home()

		xbmcplugin.endOfDirectory(addon_handle)		

	elif mode == 'listSearch':
		ListSearch(page)	
	
	elif mode == 'listmovies':
		ListMovies(exlink,page,katv,sortv,werv)			
	
	elif mode == 'listpopular':
		ListPopular(exlink)	
	
	
	elif 'kateg' in mode:
	
		myMode = 'kat'

		label=["Wszystkie",  "Akcja","Animowane","Biografie","Dokumentalne","Dramat","Familijne","Fantasty","Historyczne","Horror","Katastroficzne","Komedia","Kostiumowe","Musical","Obyczajowe","Polskie","Przygodowe","Romans","Sci-Fi","Wojenne","Sensacyjne","Sport","Thriller","Western","Wojenne"]
		value=["Wszystkie",  "Akcja","Animowane","Biografie","Dokumentalne","Dramat","Familijne","Fantasty","Historyczne","Horror","Katastroficzne","Komedia","Kostiumowe","Musical","Obyczajowe","Polskie","Przygodowe","Romans","Sci-Fi","Wojenne","Sensacyjne","Sport","Thriller","Western","Wojenne"]

		msg = 'Kategorie'
		sel = xbmcgui.Dialog().select(msg,label)
		if sel>-1:
		
			addon.setSetting(myMode+'V',value[sel])
			addon.setSetting(myMode+'N',label[sel])
			
			xbmc.executebuiltin("Container.Refresh") 
		else:
			pass	
	
	
	
	elif 'sort' in mode:
	
		myMode = 'sort'	
		
		label=["Ostatnio dodane"	,"Alfabetycznie","Najstarsze"	,"Najnowsze"]	
		value=["1"					,"2"			,"3"			,"4"]
	
		msg = 'Sortowanie'
		sel = xbmcgui.Dialog().select(msg,label)
		if sel>-1:
		
			addon.setSetting(myMode+'V',value[sel])
			addon.setSetting(myMode+'N',label[sel])		
			xbmc.executebuiltin("Container.Refresh") 
		else:
			pass	

			
	elif 'wersja' in mode:
	
		myMode = 'wer'	
		
		label=["Wszystkie"	,"Lektor PL","Bez lektora"]
		value=["2"			,"0"		,"1"]
	
		msg = 'Wersja'
		sel = xbmcgui.Dialog().select(msg,label)
		if sel>-1:
		
			addon.setSetting(myMode+'V',value[sel])
			addon.setSetting(myMode+'N',label[sel])		
			xbmc.executebuiltin("Container.Refresh") 
		else:
			pass
	elif 'playVids' in mode:
		PlayVids(exlink)
