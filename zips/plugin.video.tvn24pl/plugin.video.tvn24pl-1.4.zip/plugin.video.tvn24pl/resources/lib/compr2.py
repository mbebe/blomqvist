def compr2(N):
	Yz = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-$'
	W = 6
	Ne = {}
	We = {}
	Ke = ''
	xe = ''
	st = ''
	lt = 2
	pt = 3
	vt = 2
	mt = []
	yt = 0
	_t = 0
	#N = 'https://tvn24.pl/polska/koronawirus-w-polsce-kary-za-brak-maseczek-dane-komendy-glownej-policji-4710522/nuviArticle?playlist&ap=1&statsPwa=browser&id=4702903&r=tvn24-polska-story'
	
	
	#N="https://fakty.tvn24.pl/"
	
	def Y(bb):
		return Yz[bb]
		
	
	for J in range(len(N)):
		Ke = N[J]
		
		if  not Ke in Ne:#.has_key(Ke):
			
			Ne[Ke] = pt
			pt+=1
			We[Ke] = True        
	
		else:
			xe = st + Ke
		xe = st + Ke    
		b= xe in Ne#:#.has_key(xe)
		if  b:
			st=xe
			
		else:
			c = st in We
				
			if c:
	
				co = ord(st[0])
				if co<256:
					for q in range(vt):
						
						yt <<= 1
						if _t==W-1:
							_t = 0
							mt.append(Y(yt))
							yt = 0
						else:
							_t+=1
							
					K = ord(st[0])
					
					for q in range(8):
						yt = yt << 1 | 1 & K
						if yt==6:
							vv=''
						if _t==W-1:
							_t = 0
							if K==7:
								bbbb=''
						#	print 'K='+str(K)+', yt='+str(Y(yt))
							mt.append(Y(yt))
							yt = 0
						else:
							_t+=1
						K >>= 1
						
				else:
					
					K = 1
					for q in range(vt):
	
						yt = yt << 1 | K
						
						if _t == W - 1:
							_t = 0
							mt.append(Y(yt))
							yt = 0
							
						else:
							_t+=1
						K = 0
						
					K = ord(st[0])
					for q in range(16):
						a = yt << 1
						b =  1 & K
						yt = a|b
						
						if _t == W - 1:
							_t = 0
							mt.append(Y(yt))
							yt = 0
							
						else:
							_t+=1
						K >>= 1
						
				lt-=1
				if lt==0:
					lt = 2**vt 
					vt+=1
	
				del We[st]    
		
			else:
				K = Ne[st]
				for q in range(vt):
					yt = yt << 1 | 1 & K
	
					if _t == W - 1:
						_t = 0
						mt.append(Y(yt))
						yt = 0
					else:
						_t+=1
					K >>= 1     
			
	
			lt-=1
			if 0 == lt:
				
				lt = 2**vt 
				vt+=1
				
	
			Ne[xe] = pt
			pt+=1   
			st = str(Ke)
			
	if "" != st:
		c = st in We
			
		if c:
			co = ord(st[0])
			if co<256:
				for q in range(vt):
					
					yt <<= 1
					if _t==W-1:
						_t = 0
						mt.append(Y(yt))
						yt = 0
					else:
						_t+=1
						
						
				K = ord(st[0])
				
				for q in range(8):
	
					yt = yt << 1 | 1 & K
	
					if _t==W-1:
						_t = 0
						mt.append(Y(yt))
						yt = 0
					else:
						_t+=1
					K >>= 1  
			else:
				K = 1
				for q in range(vt):
			
					yt = yt << 1 | K
			
					if _t == W - 1:
						_t = 0
						mt.append(Y(yt))
						yt = 0
			
					else:
						_t+=1
					K = 0
			
				K = ord(st[0])
				for q in range(16):
					a = yt << 1
					b =  1 & K
					yt = a|b
			
					if _t == W - 1:
						_t = 0
						mt.append(Y(yt))
						yt = 0
			
					else:
						_t+=1
					K >>= 1
						
			lt-=1
			if lt==0:
				lt = 2**vt 
				vt+=1
			
			del We[st]    
	
	
	
		else:
			K = Ne[st]
			for q in range(vt):
				yt = yt << 1 | 1 & K
				if _t == W - 1:
					_t = 0
					mt.append(Y(yt))
					yt = 0
				else:
					_t+=1
				K >>= 1    
					
		lt-=1
		if lt==0:
			lt = 2**vt 
			vt+=1
	K = 2
	for q in range(vt):
		yt = yt << 1 | 1 & K
		if _t == W - 1:
			_t = 0
			mt.append(Y(yt))
			yt = 0 
		else:
			_t+=1
		K >>= 1  
		
	yt <<= 1
	while True:
		if _t == W - 1:
			mt.append(Y(yt))
			break
		else:
			_t+=1
	return ''.join(x for x in mt)
#print Ne
#print ''.join(x for x in mt)