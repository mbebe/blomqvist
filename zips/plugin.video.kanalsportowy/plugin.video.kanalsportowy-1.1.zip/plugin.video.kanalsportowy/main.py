# -*- coding: UTF-8 -*-

from resources.lib.kanalsportowy import KanalSportowy

if __name__ == '__main__':
    KanalSportowy()