# -*- coding: UTF-8 -*-

from resources.lib.magentatv import MagentaTV

if __name__ == '__main__':
    MagentaTV()