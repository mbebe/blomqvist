# -*- coding: utf-8 -*-


import threading

import requests,re


try:  # Python 3
    from http.server import BaseHTTPRequestHandler
except ImportError:  # Python 2
    from BaseHTTPServer import BaseHTTPRequestHandler

try:  # Python 3
    from socketserver import TCPServer
except ImportError:  # Python 2
    from SocketServer import TCPServer


import xbmcaddon, xbmc
addon = xbmcaddon.Addon('plugin.video.magentatv')

class Proxy(BaseHTTPRequestHandler):

    server_inst = None

    @staticmethod
    def start():
        """ Start the Proxy. """

        def start_proxy():
            """ Start the Proxy. """
            Proxy.server_inst = TCPServer(('127.0.0.1', 0), Proxy)

            port = Proxy.server_inst.socket.getsockname()[1]
            addon.setSetting('proxyport', str(port))

            Proxy.server_inst.serve_forever()

        thread = threading.Thread(target=start_proxy)
        thread.start()

        return thread

    @staticmethod
    def stop():
        """ Stop the Proxy. """
        if Proxy.server_inst:
            Proxy.server_inst.shutdown()
    def do_HEAD(self):

        self.send_response(200)
        self.end_headers()
    def do_GET(self):  

        path = self.path 
        return
    def do_POST(self):
        """Handle http post requests, used for license"""
        path = self.path  # Path with parameters received from request e.g. "/license?id=234324"
        return