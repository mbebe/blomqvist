# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import base64
import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import resolveurl as urlresolver

import json
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.subsmovies')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'rolka.png'
napisy = xbmc.translatePath('special://temp/napisy.txt')


sys.path.append( os.path.join( RESOURCES, "lib" ) )
exlink = params.get('url', None)
name= params.get('title', None)

page = params.get('page',[1])[0]

MAIN_URL ='https://isubsmovies.com'  #https://isubsmovies.com/movies

UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0'
TIMEOUT=15

headers = {'User-Agent': UA,}
sess = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)
    liz = xbmcgui.ListItem(name, iconImage=image, thumbnailImage=image)
def add_item(url, name, image, mode, infoLabels=False, itemcount=1, page=1,fanart=FANART,contextmenu=None,IsPlayable=False, folder=False):
	list_item = xbmcgui.ListItem(label=name)
	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')	
	if not infoLabels:
		infoLabels={'title': name}	
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': fanart})
	
	if contextmenu:
		out=contextmenu
		list_item.addContextMenuItems(out, replaceItems=True)
	else:
		out = []
		out.append(('Informacja', 'XBMC.Action(Info)'),)
		list_item.addContextMenuItems(out, replaceItems=False)

	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page, 'title':name}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	
def home():
	add_item(MAIN_URL+'/movies', 'All movies', RESOURCES+'videoz.png', "listsubsmov",fanart=FANART, folder=True)	
	add_item('https://isubsmovies.com', ' Categories', RESOURCES+'videoz.png', "listcateg",fanart=FANART, folder=True)
	add_item(MAIN_URL+'/tvseries', 'TV Series', RESOURCES+'videoz.png', "listsubsmov",fanart=FANART, folder=True)		
	add_item('', '[COLOR lightblue]Search[/COLOR]', RESOURCES+'search2.png', "search", folder=True)	

def ListSubsMov(exlink,page):
	page = int(page) if page else 1	
	filmy,pagination=getSubsMov(exlink,page)
	
	itemz=filmy
	items = len(filmy)

	for f in itemz:
		modemy='getLinks'
		isplay=True
		fold=False
		if 'tvserie/' in f.get('href'):
			if 'true' in addon.getSetting('groupEpisodes'):
				modemy='listseasons'
				isplay=False
				fold=True
			else:
				modemy='listepisodes'
				isplay=False
				fold=True
		add_item(name=f.get('title'), url=f.get('href'), mode=modemy, image=f.get('img'), infoLabels=f, itemcount=items,folder=fold, IsPlayable=isplay)	
	
	if pagination:
		add_item(name='[COLOR blue]>> next page >>[/COLOR]', url=exlink, mode='listsubsmov', image=RESOURCES+'right.png', page=pagination,fanart=FANART, folder=True)		
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	xbmcplugin.endOfDirectory(addon_handle)
def getSubsMov(url,page):

	url = url + '/page/%d' %page	
	out=[]

	html=getUrlReqOk(url)
	result = parseDOM(html,'div', attrs={'class': "movies grid"})[0]  #<div class="movies grid">
	
	links = parseDOM(result,'div', attrs={'class': "col-md-2.+?col-xs-6"})#[0]  #<div class="movies grid">
	if '/tvserie' in url:
		links = parseDOM(result,'div', attrs={'class': "col-md-2 col-xs-6"})
	
	for link in links:
		href = parseDOM(link,'a', ret="href")[0]
		imag = parseDOM(link,'img', ret="src")[0]
		href = MAIN_URL + href if href.startswith('/') else href
		imag = MAIN_URL + imag if imag.startswith('/') else imag
		tyt = parseDOM(link,'h2')[0]
		year = parseDOM(link,'span', attrs={'class': "year"})#[0]

		genr = parseDOM(link,'span', attrs={'class': "genre"})#[0]
		try:
			year = int(year[0]) if year else ''
		except:
			year =''
		genr = str(genr[0]) if genr else ''
		genr = (genr.lower()).replace(' ',', ')

		ftitle=tyt.strip()
		plot=ftitle
		out.append({'title':ftitle,'href':href,'img':imag,'year':year,'plot':plot,'genre':genr})
	prevpage=False #gr=False
	nextpage=False  # pr=False	
	ktora=False

	if html.find(' title="Next Page"')>1:
		nextpage=page+1

	return out,nextpage
	
def ListSeasons(exlink,org_tit):

	episodes =  getEpisodes(exlink)
	#
	imag=episodes[0].get('img')
	seasons =  splitToSeasons(episodes)
	
	for i in sorted(seasons.keys()):
		aa=urllib.quote(str(seasons[i]))
		add_item(name=i, url=urllib.quote(str(seasons[i])), mode='listEpisodes2', image=imag, infoLabels={'plot':org_tit}, folder=True)	
	xbmcplugin.endOfDirectory(addon_handle)
	
def splitToSeasons(input):
    out={}
    seasons = [x.get('season') for x in input]
    for s in set(seasons):
        out['Season %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
    return out
def ListEpisodes2(exlink):
	episodes = eval(urllib.unquote(exlink))
	itemz=episodes
	items = len(episodes)
	
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items, IsPlayable=True)	
	xbmcplugin.setContent(addon_handle, 'episodes')	
	xbmcplugin.endOfDirectory(addon_handle)
	
def ListEpisodes(exlink):
	episodes = getEpisodes(exlink)
	itemz=episodes
	items = len(episodes)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items, IsPlayable=True)		
	xbmcplugin.setContent(addon_handle, 'episodes')
	xbmcplugin.endOfDirectory(addon_handle)
	
def getEpisodes(url):
	

	html = getUrlReqOk(url)
	out=[]
	dane = re.findall(r'ld\+json">([^>]+)</script>',html,re.DOTALL)

	imag = None
	plot = None
	genr = None
	if dane:
		#xxx = 
		try:
			dane=json.loads(json.loads(json.dumps(dane[0])))

			plot = dane.get('description','')
			imag = dane.get('image','')
			tyt = dane.get('name','')
			
			genres = dane.get('genre','')
			try:
				genr = ','.join(genres)
			except:
				genr = ''
		except:
			plot = parseDOM(html,'div', attrs={'class': "description col-md-9"})   # <div class="description col-md-9">
			plot = plot [0] if plot else None
			dane2  = parseDOM(html,'div', attrs={'class': "container movie-header"})[0]#<div class="container movie-header">
			imag = re.findall('img src="([^"]+)"',dane2)[0]
			imag = MAIN_URL+imag
			genredane  = parseDOM(html,'div', attrs={'class': "categories col-md-9 text-center"})[0] #<div class="categories col-md-9 text-center">
			genres = re.findall('title="([^"]+)">',genredane)
			genr = ','.join(genres)
			pass

	plot = plot if plot else ''
	imag = imag if imag else ''
	genr = genr if genr else ''

	sezons=parseDOM(html,'div', attrs={'class': "subtitles col-md-.+?"}) 
	for sezon in sezons:
		try:
			ses = re.findall('S(\d+)</th>',sezon,re.DOTALL)[0]
			hreftit=re.findall('href="([^"]+)">([^>]+)<',sezon,re.DOTALL)
			for href,tyt in hreftit:
				href=MAIN_URL+href
				ftitle=tyt.strip()
				
				epis=re.findall(' E(\d+)',ftitle,re.DOTALL)

				jaki = ' - S%02dE%02d'%(int(ses),int(epis[0]))

				tyt = re.sub(' E\d+',jaki,ftitle)
				out.append({'title':tyt,'href':href,'img':imag,'plot':plot,'genre':genr, 'season' : int(ses),'episode' : int(epis[0]) if epis else '',})
		except:
			continue
	return out	
def ListCateg(url):
	categs=getCateg(url)
	itemz=categs
	items = len(categs)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listsubsmov', image=RESOURCES+'videoz.png', folder=True, infoLabels=f, itemcount=items)	
	xbmcplugin.setContent(addon_handle, 'videos')
	xbmcplugin.endOfDirectory(addon_handle)	
	
def getCateg(url):
	out=[]
	html=getUrlReqOk(url)
	
	
	
	result=parseDOM(html,'div', attrs={'class': "dropdown suggest menu"})[0]
	hrefcat=re.findall('<a href="([^"]+)".+?>([^>]+)</a>',result,re.DOTALL)
	for href,cat in hrefcat:

		href = MAIN_URL+href
		ftitle=cat.strip()
		out.append({'title':ftitle,'href':href,'img':'','plot':ftitle})
	return out

def getPost(ref=''):
	headersok = {
    'User-Agent': UA,
    'Accept': '*/*',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': ref,
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    'TE': 'Trailers',}
	content = sess.post('https://isubsmovies.com/dbquery.php?action=loadPlayer', headers=headersok).json() #https://isubsmovies.com/dbquery.php?action=loadPlayer
	return content
	
def getUrlReqOk(url,ref=''):	

	headersok = {
	'User-Agent': UA,
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
	'Connection': 'keep-alive',
	'Upgrade-Insecure-Requests': '1',
	'Referer': ref,
	'TE': 'Trailers',}
	content=sess.get(url, headers=headersok,verify=False).text	
	return content.replace("\'",'"')	

def PlayVid(exlink):
	
	subt=exlink.split('|')
	try:
		if subt[1]:
			r = requests.get(subt[0], allow_redirects=True)
			content=r.content
				
			open(napisy, 'w').write(content)
			play_item = xbmcgui.ListItem(path=subt[1])
			play_item.setSubtitles([napisy])
			xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)	
	except:
		play_item = xbmcgui.ListItem(path=subt[0])
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)	
def getLinksZZ(exlink):

	exlink = 'https:'+exlink if exlink.startswith('//') else exlink	
	stream_url=''
	if 'subsmov' in exlink:
	
		links=getVideosSubs(exlink)
		if links:
			itemz=links
			items = len(links)
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode='PlayVid', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)			
			xbmcplugin.setContent(addon_handle, 'tvshows')	
			xbmcplugin.endOfDirectory(addon_handle)	
		else:
			xbmcgui.Dialog().notification('[COLOR red][B]Problem[/COLOR][/B]', "[COLOR red][B]File doesn't exist.[/COLOR][/B]", xbmcgui.NOTIFICATION_INFO, 6000)
			quit()

def getUrlReqCF(url,ref):
	import cloudflare3x
	sess.headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0','Referer':ref})
	check = sess.get(url,verify=False)
	cf = cloudflare3x.Cloudflare(url,check)
	if cf.is_cloudflare:
		authUrl = cf.get_url()
		makeAuth = sess.get(authUrl,verify=False)
	html = sess.get(url,verify=False).content
	return html
def getLinks(url):

	jdata =getPost(url)
	html = jdata.get('Data','').get('Player','')

	href = parseDOM(html, 'iframe', ret='data-src')[0]
	
	html=getUrlReqOk(href,url)

	link =re.findall('file: "([^"]+)',html)
	#link = parseDOM(html, 'source', ret='src')#[0]
	
	if link:
		headersy = {
			'User-Agent': UA,
			'Accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
			'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
			'Referer': href+'&user_choosed_player=html5',
			'Range': 'bytes=0-',
			'Connection': 'keep-alive',
			'TE': 'Trailers',
		}	
		link = 'http:'+link[0] if link[0].startswith('//') else link[0]
		r=requests.get(link,headers=headersy,allow_redirects=False)
		link= r.headers['Location']	+'|User-Agent='+urllib.quote(UA)+'X-Requested-With=ShockwaveFlash/28.0.0.126'
		subs=re.findall('srclang=".+?" label="(.+?)" src="(.+?)"',html,re.DOTALL)
		subout=[]
		napisys =re.findall('JSON.parse\("(\[.+?\])',html)
		if napisys:
			napisys = json.loads(napisys[0])
			

		for napisy1 in napisys:

			src = napisy1['file']
			lab = napisy1['label']

			subout.append({'href':src,'label':lab})
		if subout:
			napLab = [x.get('label') for x in subout]
			s = xbmcgui.Dialog().select('Subtitles',napLab)
			
			adresNap=subout[s].get('href') if s > -1 else ''
			adresNap = 'https://jwplayer.flowyourvideo.com'+adresNap if adresNap.startswith('/') else adresNap

			if adresNap:

				content = sess.get(adresNap, allow_redirects=True).content

				open(napisy, 'w').write(content)
				play_item = xbmcgui.ListItem(path=link)

				play_item.setSubtitles([napisy])
				xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)	
			else:
				play_item = xbmcgui.ListItem(path=link)

				xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)	

	else:
		xbmcgui.Dialog().notification('[COLOR red][B]Error[/B][/COLOR]', "[COLOR red][B]This video doesn't exists in our servers or has been deleted.[/B][/COLOR]", xbmcgui.NOTIFICATION_INFO, 5000)

def PLchar(char):
	char=char.replace("\xb9","ą").replace("\xa5","Ą").replace("\xe6","ć").replace("\xc6","Ć")
	char=char.replace("\xea","ę").replace("\xca","Ę").replace("\xb3","ł").replace("\xa3","Ł")
	char=char.replace("\xf3","ó").replace("\xd3","Ó").replace("\x9c","ś").replace("\x8c","Ś")
	char=char.replace("\x9f","ź").replace("\xaf","Ż").replace("\xbf","ż").replace("\xac","Ź")
	char=char.replace("\xf1","ń").replace("\xd1","Ń").replace("\x8f","Ź");
	return char	
	
if __name__ == '__main__':
	mode = params.get('mode', None)
	
	if not mode:
		home()
	
		xbmcplugin.endOfDirectory(addon_handle)			
	elif mode == 'getLinks':
		getLinks(exlink)
	elif mode == 'PlayVid':
		PlayVid(exlink)	
	elif mode == 'listsubsmov':
		ListSubsMov(exlink,page)	
	elif mode == 'listseasons':

		ListSeasons(exlink,name)
	elif mode == 'listEpisodes2':
		ListEpisodes2(exlink)
	elif mode == 'listcateg':
		ListCateg(exlink)
	elif mode == 'listepisodes':
		ListEpisodes(exlink)	
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Search...', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			ListSubsMov('https://isubsmovies.com/search/'+query,1)
		else:
			pass
