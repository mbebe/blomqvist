# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import base64
import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import resolveurl as urlresolver

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.subsmovies')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'rolka.png'
napisy = xbmc.translatePath('special://temp/napisy.txt')


sys.path.append( os.path.join( RESOURCES, "lib" ) )
exlink = params.get('url', None)
name= params.get('title', None)
#fn = params.get('title', None)
page = params.get('page',[1])[0]
kukz=''


UA= 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
TIMEOUT=15

headers = {'User-Agent': UA,}
s = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)
    liz = xbmcgui.ListItem(name, iconImage=image, thumbnailImage=image)
def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=1,fanart=FANART):
	list_item = xbmcgui.ListItem(label=name)
	
	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')		
	if not infoLabels:
		infoLabels={'title': name}	
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': fanart})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page,'mbebe':kukz}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	
def home():
	add_item('https://www1.subsmovies.nz/featured', 'All movies', RESOURCES+'videoz.png', True, "listsubsmov",fanart=FANART)	
	add_item('https://www1.subsmovies.nz/featured', ' Categories', RESOURCES+'videoz.png', True, "listcateg",fanart=FANART)	
	add_item('https://www1.subsmovies.nz/tv_serie', 'TV Series', RESOURCES+'videoz.png', True, "listsubsmov",fanart=FANART)			
	add_item('', '[COLOR lightblue]Search[/COLOR]', RESOURCES+'search2.png', True, "search")		

def ListSubsMov(exlink,page):
	page = int(page) if page else 1	
	filmy,pagination=getSubsMov(exlink,page)
	if pagination[0]:
		ktora=pagination[0]
	else:
		ktora=''
	itemz=filmy
	items = len(filmy)
	modemy='getLinks'
	for f in itemz:
		if 'tv_serie' in f.get('href'):
			if 'true' in addon.getSetting('groupEpisodes'):
				modemy='listseasons'
			else:
				modemy='listepisodes'
		add_item(name=f.get('title'), url=f.get('href'), mode=modemy, image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	if pagination[1]:
		add_item(name='[COLOR blue]>> next page %s >>[/COLOR]'%ktora, url=exlink, mode='listsubsmov', image=RESOURCES+'right.png', folder=True, page=pagination[1],fanart=FANART)		
	xbmcplugin.setContent(addon_handle, 'videos')	
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	xbmcplugin.endOfDirectory(addon_handle)
def getSubsMov(url,page):
	if 'category=' in url:
		url = url + '&page=%d' %page	
	else:
		url = url + '?page=%d' %page
	out=[]
	html=getUrlReqOk(url)
	result=parseDOM(html,'div', attrs={'class': "content_body"})[0] 
	links=re.findall('<a(.+?)</a',result,re.DOTALL)
	for link in links:
		hrefimgtit=re.findall('href="(.+?)".+?img src="(.+?)".+?album_holder_title">(.+?)<',link,re.DOTALL)
		if hrefimgtit:
			href='https://www1.subsmovies.nz/'+hrefimgtit[0][0]
			imag='https://www1.subsmovies.nz/'+hrefimgtit[0][1]
			tyt=hrefimgtit[0][2]
			year=re.findall('\((\d+)\)',tyt)
			if year:
				year=year[0]
			else:
				year=''
		else:
			continue
		ftitle=tyt.strip()
		plot=ftitle
		out.append({'title':ftitle,'href':href,'img':imag,'year':year,'plot':plot})
	prevpage=False #gr=False
	nextpage=False  # pr=False	
	ktora=False
	pagination=re.findall('pages_number_info">(.+?</span>)',html,re.DOTALL)
	if pagination:
		pagination=pagination[0]
		sumpag=re.findall('(\d+)<',pagination)[0]
		nextpage=page+1 if page<int(sumpag) else False
		if nextpage:
			ktora='(%s of %d)'%(str(nextpage),int(sumpag))
		else:
			ktora=False
	return (out,(ktora,nextpage))
	
def ListSeasons(exlink):
	episodes =  getEpisodes(exlink)
	imag=episodes[0].get('img')
	seasons =  splitToSeasons(episodes)
	
	for i in sorted(seasons.keys()):
		aa=urllib.quote(str(seasons[i]))
		add_item(name=i, url=urllib.quote(str(seasons[i])), mode='listEpisodes2', image=imag, folder=True)	
	xbmcplugin.setContent(addon_handle, 'season')	
	xbmcplugin.endOfDirectory(addon_handle)
	
def splitToSeasons(input):
    out={}
    seasons = [x.get('season') for x in input]
    for s in set(seasons):
        out['Season %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
    return out
def ListEpisodes2(exlink):
	episodes = eval(urllib.unquote(exlink))
	itemz=episodes
	items = len(episodes)
	
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	xbmcplugin.setContent(addon_handle, 'episodes')	
	xbmcplugin.endOfDirectory(addon_handle)
	
def ListEpisodes(exlink):
	episodes = getEpisodes(exlink)
	itemz=episodes
	items = len(episodes)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	xbmcplugin.setContent(addon_handle, 'episodes')
	xbmcplugin.endOfDirectory(addon_handle)
	
def getEpisodes(url):
	html = getUrlReqOk(url)
	out=[]
	plot=re.findall('Description:</span>(.+?)</span>',html,re.DOTALL)
	if plot:
		plot=plot[0]
	else:
		plot=''
	sezons=parseDOM(html,'section', attrs={'class': "specific_movie_other_source"})
	for sezon in sezons:
		try:
			sez=parseDOM(sezon,'div', attrs={'class': "movie_links_help"})[0]
			ses=re.findall('son\s+(\d+)',sez,re.DOTALL)[0]
			hrefimgtit=re.findall('href="(.+?)".+?img src="(.+?)".+?album_holder_title">(.+?)<',sezon,re.DOTALL)
			for href,imag,tyt in hrefimgtit:
				href='https://www1.subsmovies.nz/'+href
				imag='https://www1.subsmovies.nz/'+imag
				ftitle=tyt.strip()
				epis=re.findall('pisode\s+(\d+)\)',ftitle,re.DOTALL)
				out.append({'title':ftitle,'href':href,'img':imag,'plot':plot,'season' : int(ses),'episode' : int(epis[0]) if epis else '',})
		except:
			continue
	return out	
def ListCateg(url):
	categs=getCateg(url)
	itemz=categs
	items = len(categs)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listsubsmov', image=RESOURCES+'videoz.png', folder=True, infoLabels=f, itemcount=items)	
	xbmcplugin.setContent(addon_handle, 'videos')
	xbmcplugin.endOfDirectory(addon_handle)	
	
def getCateg(url):
	out=[]
	html=getUrlReqOk(url)
	result=parseDOM(html,'ul', attrs={'class': "nav_header_ul"})[0]
	hrefcat=re.findall('<a href="(.+?)">(.+?)</a>',result,re.DOTALL)
	for href,cat in hrefcat:
		if '/tv_series' in href or '/upcoming' in href or '/home' in href:
			continue
		href='https://www1.subsmovies.nz'+href
		ftitle=cat.strip()
		out.append({'title':ftitle,'href':href,'img':'','plot':ftitle})
	return out

def getUrlReqOk(url):	
	headersok = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'TE': 'Trailers',}
	content=requests.get(url, headers=headersok,verify=False).text	
	return content.replace("\'",'"')	

def PlayVid(exlink):
	subt=exlink.split('|')
	try:
		if subt[1]:
			r = requests.get(subt[0], allow_redirects=True)
			content=r.content
				
			open(napisy, 'w').write(content)
			play_item = xbmcgui.ListItem(path=subt[1])
			play_item.setSubtitles([napisy])
			xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)	
	except:
		play_item = xbmcgui.ListItem(path=subt[0])
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)	
def getLinks(exlink):
	exlink = 'https:'+exlink if exlink.startswith('//') else exlink	
	stream_url=''
	if 'subsmov' in exlink:
		links=getVideosSubs(exlink)
		if links:
			itemz=links
			items = len(links)
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode='PlayVid', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)			
			xbmcplugin.setContent(addon_handle, 'tvshows')	
			xbmcplugin.endOfDirectory(addon_handle)	
		else:
			xbmcgui.Dialog().notification('[COLOR red][B]Problem[/COLOR][/B]', "[COLOR red][B]File doesn't exist.[/COLOR][/B]", xbmcgui.NOTIFICATION_INFO, 6000)
			quit()

def getUrlReqCF(url,ref):
	import cloudflare3x
	s.headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0','Referer':ref})
	check = s.get(url,verify=False)
	cf = cloudflare3x.Cloudflare(url,check)
	if cf.is_cloudflare:
		authUrl = cf.get_url()
		makeAuth = s.get(authUrl,verify=False)
	html = s.get(url,verify=False).content
	return html

def getVideosSubs(url):
	html=getUrlReqOk(url)	
	out=[]
	
	result = parseDOM(html, 'div', attrs={'class': "content_body"})[0]
	imag = re.findall('img src="(.+?)"',result,re.DOTALL)
	if imag:
		imag='https://www1.subsmovies.nz/'+imag[0]
	else:
		imag=''
	title = re.findall('<h1>(.+?)</h1>',result,re.DOTALL)
	if title:
		title=title[0].strip()
	else:
		title='Full movie'
	plot=re.findall('Description:</span>(.+?)</span>',result,re.DOTALL)
	if plot:
		plot=plot[0]
	else:
		plot=''
	href = parseDOM(html, 'iframe', ret='data-src')[0]
	href = 'https:'+href if href.startswith('//') else href
	html=getUrlReqCF(href,url)
	link = parseDOM(html, 'source', ret='src')#[0]
	if link:
		headersy = {
			'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:64.0) Gecko/20100101 Firefox/64.0',
			'Accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
			'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
			'Referer': href+'&user_choosed_player=html5',
			'Range': 'bytes=0-',
			'Connection': 'keep-alive',
			'TE': 'Trailers',
		}	
		link = 'http:'+link[0] if link[0].startswith('//') else link[0]
		r=requests.get(link,headers=headersy,allow_redirects=False)
		link= r.headers['Location']	
		film = { 'href'  : link,'img': imag,'plot':plot,'mediatype': 'tvshows','title' : title}
		out.append(film)
	subs=re.findall('srclang=".+?" label="(.+?)" src="(.+?)"',html,re.DOTALL)
	for label,href in subs:
		href = 'http://www.flowyourvideo.com'+href if href.startswith('/') else href
	
		tyt=title
		subtit='[COLOR khaki](subtitle: %s)[/COLOR]'%label
		film = { 'href'  : href+'|'+link,'img': imag,'plot':plot,'mediatype': 'tvshows','title' : tyt,'code':subtit}
		out.append(film)	
	return out	
	
def PLchar(char):
	char=char.replace("\xb9","ą").replace("\xa5","Ą").replace("\xe6","ć").replace("\xc6","Ć")
	char=char.replace("\xea","ę").replace("\xca","Ę").replace("\xb3","ł").replace("\xa3","Ł")
	char=char.replace("\xf3","ó").replace("\xd3","Ó").replace("\x9c","ś").replace("\x8c","Ś")
	char=char.replace("\x9f","ź").replace("\xaf","Ż").replace("\xbf","ż").replace("\xac","Ź")
	char=char.replace("\xf1","ń").replace("\xd1","Ń").replace("\x8f","Ź");
	return char	
	
if __name__ == '__main__':
	mode = params.get('mode', None)
	
	if not mode:
		home()
		xbmcplugin.setContent(addon_handle, 'files')	
		xbmcplugin.endOfDirectory(addon_handle)			
	elif mode == 'getLinks':
		getLinks(exlink)
	elif mode == 'PlayVid':
		PlayVid(exlink)	
	elif mode == 'listsubsmov':
		ListSubsMov(exlink,page)	
	elif mode == 'listseasons':
		ListSeasons(exlink)
	elif mode == 'listEpisodes2':
		ListEpisodes2(exlink)
	elif mode == 'listcateg':
		ListCateg(exlink)
	elif mode == 'listepisodes':
		ListEpisodes(exlink)	
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Search...', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			ListSubsMov('https://www1.subsmovies.nz/search/'+query,1)
		else:
			pass
