# -*- coding: UTF-8 -*-
import sys,re,os
import urlparse
from urlparse import parse_qsl
import hashlib
import base64
import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import resolveurl #as urlresolver

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.alantvsport')
dalej=''
PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=PATH+'fanart.jpg'
blad=PATH+'error.png'
spiece=RESOURCES+'spiece.png'
jfooty=RESOURCES+'jfooty.png'
alanimg=RESOURCES+'alan.png'
sys.path.append( os.path.join( RESOURCES, "lib" ) )
import pyaes
import mydecode
exlink = params.get('url', None)
name= params.get('title', None)
licz= params.get('licz', None)
page = params.get('page',[1])[0]
UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0'
headersok = {
	'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
	'Connection': 'keep-alive',
	'Upgrade-Insecure-Requests': '1',}
	
main_url='https://www.alantvsport.com/'
s = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=1, licz=1):
	list_item = xbmcgui.ListItem(label=name)

	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')
		
	if not infoLabels:
		infoLabels={'title': name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page,'licz':licz}),			
		listitem=list_item,
		isFolder=folder)

	
def home():	
	add_item('https://www.alantvsport.com/', '[COLOR red][B] LIVE [/B][COLOR lightblue]All events[/COLOR]', alanimg, True, "alantv")	
	add_item('https://www.alantvsport.com/', '[COLOR red][B] LIVE [/B][COLOR lightblue]Events[/COLOR]', alanimg, True, "alanevents")	
	add_item('https://www.alantvsport.com/', '[COLOR red][B] LIVE [/B][COLOR lightblue]Search[/COLOR]', alanimg, True, "search")	
	add_item('https://www.sportpiece.com/', '[COLOR lightblue]Sports highlights[/COLOR]', spiece, True, "highlights")	
	add_item('https://www.javafooty.com/', '[COLOR lightblue]Football highlights[/COLOR]', jfooty, True, "foothighlights")	
	xbmcplugin.endOfDirectory(addon_handle)
	
def __bytes_to_key(password, salt, output=48):
	try:
		seed = hashlib.md5(password + salt).digest()
		key = seed
	
		while len(key) < output:
			seed = hashlib.md5(seed + (password + salt)).digest()
			key += seed
	
		return key[:output]
	
	except Exception:
		return

def decryptaes(encrypt):
	encrypted=re.findall(r'(.+?)\,',encrypt)[0]
	password=re.findall(r'\,(.*$)',encrypt)[0]
	encrypted=urllib.unquote(encrypted).replace('"','')
	password=urllib.unquote(password).replace('"','')	
	password=str(password)
	try:
		encrypted = base64.b64decode(encrypted)
		salt = encrypted[8:16]
		key_iv = __bytes_to_key(password, salt)
		key = key_iv[:32]
		iv = key_iv[32:]
		decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(key, iv = iv))
		plaintext = decrypter.feed(encrypted[16:])
		plaintext += decrypter.feed()	
		return plaintext	
	except Exception:
		return

def ListEvents(exlink):
	links = getListEvents(exlink)
	itemz=links
	if itemz:
		items = len(links)
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='alantv', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)	
	
def getListEvents(url):
	html=getUrlReqok(url)	
	out=[]	
	result=parseDOM(html,'div', attrs={'class': "layout-inner"})[0] 
	links = parseDOM(result, 'li') 
	out=[]
	for link in links:
		link= link.replace('&nbsp;','')
		href = parseDOM(link, 'a', ret='href')[0] 
		title= re.findall('</i>(.+?)</div>',link)[0]
		if 'All Event' in title or 'Sports Highlights' in title:
			pass
		else:
			out.append({'title':title,'href':href})	
	return out	
	
def ListHighlights(exlink):
	links = getHighlights(exlink)
	itemz=links
	if itemz:
		add_item('https://www.sportpiece.com/', '[COLOR orange][B]Search (club/team)[/COLOR][/B]', spiece, True, "searchhigh")
		add_item('https://www.sportpiece.com/', '[COLOR orange][B]Search by date[/COLOR][/B]', spiece, True, "searchdate")
		items = len(links)
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='sportpieces', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)	
	
def getHighlights(url):
	html=getUrlReqok(url)	
	out=[]	
	result=parseDOM(html,'div', attrs={'class': "layout-inner"})[0] 
	links = parseDOM(result, 'li') 
	out=[]
	for link in links:
		link= link.replace('&nbsp;','')
		href = parseDOM(link, 'a', ret='href')[0] 
		title= parseDOM(link, 'div')[0] 
		out.append({'title':title,'href':href})	
	return out		

def ListFoothighlights(exlink):
	links = getFoothighlights(exlink)
	itemz=links
	if itemz:
		add_item('https://www.javafooty.com/', '[COLOR orange][B]Search (club/team)[/COLOR][/B]', jfooty, True, "searchhigh")
		add_item('https://www.javafooty.com/', '[COLOR orange][B]Search by date[/COLOR][/B]', jfooty, True, "searchdate")
		items = len(links)
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='sportpieces', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	xbmcplugin.setContent(addon_handle, 'files')	
	xbmcplugin.endOfDirectory(addon_handle)	
	
def getFoothighlights(url):
	html=getUrlReqok(url)	
	out=[]	
	result=parseDOM(html,'div', attrs={'class': "layout-inner"})[0] 
	links = parseDOM(result, 'li', attrs={'class': "sidenav-item"})#[0] 
	out=[]
	for link in links:
		link= link.replace('&nbsp;','')
		href = parseDOM(link, 'a', ret='href')[0] 
		title= parseDOM(link, 'div')[0] 
		out.append({'title':title,'href':href})	
	return out	

def ListSportpieces(exlink):
	links = getSportpieces(exlink)
	itemz=links
	if itemz:
		items = len(links)
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%P, %G")
	xbmcplugin.setContent(addon_handle, 'files')	
	xbmcplugin.endOfDirectory(addon_handle)
	
def getSportpiecesSearchDate(html,url):
	out=[]	
	result=parseDOM(html,'tbody')[0]
	trs=parseDOM(result,'tr')#[0]
	for tr in trs:
		if 'font color' in tr:
			
			if 'javafoot' in url:
				title=parseDOM(tr,'font')[0]
				title='[COLOR khaki]'+title+'[/COLOR]'
				continue
			else:
				title=parseDOM(tr,'font')[0]
				title='[COLOR khaki]'+title+'[/COLOR]'
				continue
		try:
			data = parseDOM(tr, 'td')[1]
			imag = ''
			href = parseDOM(tr, 'a', ret='href')[0]   
			titlem=parseDOM(tr,'td')[2]  		
			titlem = '[COLOR blue]%s[/COLOR]'%titlem
			plot='[COLOR khaki]'+title+'[CR][COLOR blue]'+titlem+'[/COLOR][CR]'+data			
		except:
			pass
		out.append({'title':titlem,'href':href,'img':imag,'code':title, 'plot':plot,'genre':data})
	return out
		
def getSportpiecesSearch(html,url):	
	out=[]
	result=parseDOM(html,'div', attrs={'class': "table-responsive"})[0] 
	links = parseDOM(result, 'tr') 
	for link in links:	
		try:
			if 'javafooty' in url:
				resulty=parseDOM(html,'div', attrs={'class': "text-muted mt-1"})[0]
				categ = parseDOM(link, 'td')[1].upper()
				href = parseDOM(link, 'a', ret='href')[0] 	
				title=parseDOM(link,'td')[3]
				data = parseDOM(link, 'td')[2]				
			else:
				categ= parseDOM(link, 'font')[0] .upper()
				href = parseDOM(link, 'a', ret='href')[2] 
				title=parseDOM(link,'td')[3]
				data = parseDOM(link, 'td')[4]
			imag = ''
			title1 = '[COLOR blue]%s[/COLOR]'%title
			plot='[COLOR khaki]'+categ+'[CR][COLOR blue]'+title+'[/COLOR][CR]'+data
			out.append({'title':title1,'href':href,'img':imag,'code':'[COLOR khaki]'+categ+'[/COLOR]', 'plot':plot,'genre':data})
		except:
			pass
	return out	
	
def getSportpieces(url):
	html=getUrlReqok(url)	
	out=[]
	result=parseDOM(html,'div', attrs={'class': "table-responsive"})[0] 
	links = parseDOM(result, 'tr') 
	for link in links:	
		try:
			if 'javafooty' in url:
				resulty=parseDOM(html,'div', attrs={'class': "text-muted mt-1"})[0]
				categ= parseDOM(resulty, 'font')[0] .upper()
				href = parseDOM(link, 'a', ret='href')[0] 	
				title=parseDOM(link,'td')[2]				
			else:
				categ= parseDOM(link, 'font')[0] .upper()
				href = parseDOM(link, 'a', ret='href')[1] 
				title=parseDOM(link,'td')[3]
			data = parseDOM(link, 'td')[1]
			imag = ''
			title1 = '[COLOR blue]%s[/COLOR]'%title
			plot='[COLOR khaki]'+categ+'[CR][COLOR blue]'+title+'[/COLOR][CR]'+data
			out.append({'title':title1,'href':href,'img':imag,'code':'[COLOR khaki]'+categ+'[/COLOR]', 'plot':plot,'genre':data})
		except:
			pass
	return out
	
def ListAlan(exlink):
	links = getAlan(exlink)
	itemz=links
	if itemz:
		items = len(links)
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	

	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%G, %P")
	xbmcplugin.setContent(addon_handle, 'files')	

def getAlan(url):
	html=getUrlReqok(url)	
	out=[]
	result=parseDOM(html,'div', attrs={'class': "table-responsive"})[0] 
	links = parseDOM(result, 'tr', attrs={'class':"panel-default .+?"}) 
	for link in links:	
		categ=re.findall('sportIcon sportIcon--(.+?)"',link)[0].upper()
		imag = ''
		href = parseDOM(link, 'a', ret='href')[3]   
		title1=parseDOM(link,'font')[0]
		title2=parseDOM(link,'font')[1].replace('Vs','vs')
		czas=parseDOM(link,'td')[1].replace('CET','')
		title = '%s: [COLOR blue]%s[/COLOR] %s'%(czas,title2,title1)
		plot='[B][COLOR khaki]'+title1+'[CR]'+title2+'[/B][/COLOR][CR]'+czas
		out.append({'title':title,'href':href,'img':imag,'code':categ, 'plot':plot})	
	return out

def ListSearch(query):	
	links= getSearch(query)
	itemz=links
	items = len(links)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)		
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%G, %P")
	xbmcplugin.setContent(addon_handle, 'movies')		
	xbmcplugin.endOfDirectory(addon_handle)	
def getSearch(query):
	
	html=getUrlReqok(main_url)	
	out=[]
	result=parseDOM(html,'div', attrs={'class': "table-responsive"})[0] 
	links = parseDOM(result, 'tr', attrs={'class':"panel-default .+?"}) 
	for link in links:		
		match = re.compile('<font color=.+?>(.+?)<.+?<font color=.+?>(.+?)<').findall(link)
		print match[0][0]
		if len(match) > 0:
			for i in range(len(match)):
				if query.lower() in match[i][0].lower() or query.lower() in match[i][1].lower():
					categ=re.findall('sportIcon sportIcon--(.+?)"',link)[0].upper()
					imag = ''
					href = parseDOM(link, 'a', ret='href')[3]   
					title1=parseDOM(link,'font')[0]
					title2=parseDOM(link,'font')[1].replace('Vs','vs')
					czas=parseDOM(link,'td')[1].replace('CET','')
					title = '%s: [COLOR blue]%s[/COLOR] %s'%(czas,title2,title1)
					plot='[B][COLOR khaki]'+title1+'[CR]'+title2+'[/B][/COLOR][CR]'+czas
					out.append({'title':title,'href':href,'img':imag,'code':categ, 'plot':plot})
				else:
					continue	
	return out		
	
def Listdate(url,query):
	query=(str(query).replace(' ','0')).split('/')
	data='%s/%s/%s'%(query[1],query[0],query[2])
	typ=False
	html=postUrlReq(url,data,typ)
	links = getSportpiecesSearchDate(html,url)
	itemz=links
	if itemz:
		items = len(links)
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%P, %G")
	xbmcplugin.setContent(addon_handle, 'files')	
	xbmcplugin.endOfDirectory(addon_handle)		

def Listsearchhigh(url,query):
	query=query.replace(' ','+')
	typ=True
	html=postUrlReq(url,query,typ)
	links = getSportpiecesSearch(html,url)
	itemz=links
	if itemz:
		items = len(links)
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%P, %G")
	xbmcplugin.setContent(addon_handle, 'files')	
	xbmcplugin.endOfDirectory(addon_handle)	
	return	
	
def getUrlReqok(url):
	headers = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Connection': 'keep-alive',
		'Upgrade-Insecure-Requests': '1',}
	content=s.get(url,headers=headers, verify=False).text	
	return content	
	
def getUrlReq(url):
	headers = {
		'Connection': 'keep-alive',
		'Cache-Control': 'max-age=0',
		'Upgrade-Insecure-Requests': '1',
		'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 8_0_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12A366 Safari/600.1.4',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
		'Accept-Encoding': 'gzip, deflate',
		'Accept-Language': 'en-US,en;q=0.9',
		'Referer': url,
	}
	content=s.get(url,headers=headers, verify=False).text	
	return content	
def postUrlReq(url,data,typ):

	headerspo = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
		'Content-Type': 'application/x-www-form-urlencoded',
		'Upgrade-Insecure-Requests': '1',}
	if typ:
		data = {
		'inpsearch': data,
		'submit2': 'Submit'}
	else:
		data = {
		'datematchsport': data,
		'submit1': 'Submit'}
	response = s.post(url, data=data,headers=headerspo).text
	return response
	
def decodeAlan(alantvcom_streaminglive,data):
	if not data:	
		if alantvcom_streaminglive.find('_sportpiececom_highlights_goals_video_online_')>0:
			ex1 = alantvcom_streaminglive.split('_sportpiececom_highlights_goals_video_online_');
		else:
			ex1 = alantvcom_streaminglive.split('_javafooty_football_highlights_goals_video_');
	else:
		ex1 = alantvcom_streaminglive.split('_alantvcom_livestreamsport_');
	p = ex1[1].split('_');
	t0 = int(p[0]);
	t1 = int(p[0]) + int(p[1]);
	aaa=p[2]
	abac=t1+int(aaa)
	t2 = int(p[0]) + int(p[1]) + int(p[2]);
	j0 = ex1[0][0: int(t0)];
	j0 = ex1[0][0: int(t0)];
	k0 = int(ex1[0][int(t0) - 1]) + 1;
	j1 = ex1[0][int(t0): int(t0)+int(p[1])];
	k1 = int(ex1[0][int(t1) - 1]) + 1;
	j2 = ex1[0][int(t1):int(t1)+ int(p[2])];
	k2 = int(ex1[0][int(t2) - 1]) + 1;
	a = '';
	s0 = urllib.unquote(j0[0: len(j0) - k0]);
	abacad=int(len(j0)-k0)
	t = '';
	abacada=int(j0[len(j0)-k0:abacad+1])
	for i in range(0, len(s0)):
		t += chr(ord(s0[i])-abacada	)
	z = urllib.unquote(t);
	a0 = '';
	for ii in range(0, len(z)):
		qq=len(z) - ii
		a0 += z[len(z) - ii: qq+1];
	a = a + a0;
	s1 = urllib.unquote(j1[0: len(j1) - k1]);
	t = '';
	for i in range(0, len(s1)):
		abacad=int(len(j1) - k1)
		abacada=int(j1[len(j1) - k1:abacad+1])
		t += chr(ord(s1[i])-abacada	)
	z = urllib.unquote(t);
	a1 = '';
	for ii in range(0, len(z)):
		a1 += z[len(z) - ii:(len(z) - ii)+ 1];
	a = a + urllib.quote(a1);
	s2 = urllib.unquote(j2[0: len(j2) - k2]);
	t = '';
	for i in range(0, len(s2)):
		abacad=int(len(j2) - k2)
		abacada=int(j2[len(j2) - k2:abacad+1])
		t += chr(ord(s2[i])-abacada	)   
	z = urllib.unquote(t);
	a2 = '';
	for ii in range(0, len(z)):
		a2 += z[len(z) - ii:(len(z) - ii)+ 1];
	a = a + a2;
	return a	

def getJSlink5(url):
	html=getUrlReq(url)
	out=[]
	out2=[]
	try:
		result=parseDOM(html,'div', attrs={'id': "link-in"})[0]  #<div class="tab-pane fade" id="link-out">		
		alstr=re.findall("""var alantvcom_streaminglive.+?['"](.+?)['"]""",result)[0]		
		counter=0
		decoded=decodeAlan(alstr,True)
		decoded= urllib.unquote(decoded)
		aespass=re.findall("decrypt\((.+?)\)",decoded) 	
		if aespass:	
			decoded=decryptaes(aespass[0])				
		hreftit=re.findall('data-link="(.+?)".+?>(.+?)<\/a>',decoded)			
		for href,title in hreftit:
			out.append({'title':title,'href':href})	
	except:
		pass
	try:
		
		result2=parseDOM(html,'div', attrs={'id': "link-out"})[0]  #<div class="tab-pane fade" id="link-out">
		alstr2=re.findall("""var\s+alantvcom_streaminglive.+?['"](.+?)['"]""",result2)[0]
		counter=0
		decoded=decodeAlan(alstr2)
		decoded= urllib.unquote(decoded)
		aespass=re.findall("decrypt\((.+?)\)",decoded) 	
		if aespass:	
			decoded=decryptaes(aespass[0])	
			
			nxt=re.findall('href="(.+?outvid.+?)"',decoded)
			co=1
			for nx in nxt:
				tit='(Alt link %d)'%co	
				out.append({'title':str(tit),'href':nx})	
				co+=1			
	except:
		pass
	return out	
	
	
def getJSlink4(url):
	html=getUrlReq(url)
	out=[]	
	try:
		result=parseDOM(html,'div', attrs={'class': "card mb-4"})[0]  #<div class="tab-pane fade" id="link-out">	
		try:
			alstr=re.findall("""var wwwsportpiececom.+?['"](.+?)['"]""",result)[0]	
		except:
			alstr=re.findall("""var wwwjavafootycom.+?['"](.+?)['"]""",result)[0]				
		counter=0
		decoded=decodeAlan(alstr,False)
		decoded= urllib.unquote(decoded)
		aespass=re.findall("decrypt\((.+?)\)",decoded) 		
		if aespass:	
			decoded=(decryptaes(aespass[0])).replace("\'",'"')
		results=parseDOM(decoded,'span')
		for result in results:
			title=parseDOM(result,'font')[0]
			href=parseDOM(result,'iframe',ret='src')#[0]
			if href:
				href=href[0]
			else:
				href=parseDOM(result,'a',ret='href')[0]
			href = 'https:'+href if href.startswith('//') else href
			if 'tinyurl' in href:
				r=s.get(href,headers=headersok,allow_redirects=False)
				href= r.headers['Location']	
			out.append({'title':title,'href':href})
		return out

	except:
		return out

def getJSlink3(url):
	html=getUrlReq(url)
	out=[]
	out2=[]
	try:
		result=parseDOM(html,'div', attrs={'id': "link-in"})[0]  #<div class="tab-pane fade" id="link-out">		
		alstr=re.findall("""var alantvcom_streaminglive.+?['"](.+?)['"]""",result)[0]		
		counter=0
		decoded=decodeAlan(alstr,True)
		decoded= urllib.unquote(decoded)
		aespass=re.findall("decrypt\((.+?)\)",decoded) 	
		if aespass:	
			decoded=decryptaes(aespass[0])				
		hreftit=re.findall('data-link="(.+?)".+?>(.+?)<\/a>',decoded)			
		for href,title in hreftit:
			out.append({'title':title,'href':href})		
	except:
		pass
	try:
		result2=parseDOM(html,'div', attrs={'id': "link-out"})[0]  #<div class="tab-pane fade" id="link-out">
		alstr2=re.findall("""var\s+alantvcom_streaminglive.+?['"](.+?)['"]""",result2)[0]
		counter=0
		decoded=decodeAlan(alstr2,True)
		decoded= urllib.unquote(decoded)
		aespass=re.findall("decrypt\((.+?)\)",decoded) 	
		if aespass:	
			decoded=decryptaes(aespass[0])	
			
			nxt=re.findall('href="(.+?outvid.+?)"',decoded)
			co=1
			for nx in nxt:
				tit='(Alt link %d)'%co	
				out.append({'title':str(tit),'href':nx})	
				co+=1			
	except:
		pass
	return out

def getLinks(url):
	if 'sportpiece' in url or 'javafooty' in url:
		out=getJSlink4(url)
	else:
		out=getJSlink3(url)
	vido_url=''
	if out:
		linkstr=''

		if len(out)>1:
			select = xbmcgui.Dialog().select('Źródła', [ x.get('title') for x in out])	
		else:
			select=0	
		if select>-1:
		
			linkstr = out[select].get('href')
		else: return
		nextlink=getUrlReq(linkstr)	
		
		if 'sportpiece' in url or 'javafooty' in url:
			
			if 'emb.aplayer1.me/' in linkstr:
				vido_url=re.findall("file:.+?'(htt.+?),",nextlink)[0]
			elif 'mycujoo' in linkstr:
				vido_url=re.findall('"file".+?"(ht.+?m3u.+?)"',nextlink)[0]
				vido_url=vido_url.split('master')[0]+'480p/playlist.m3u8'
				vido_url+='|User-Agent='+UA+'&Referer='+linkstr
			else:
				try:
					vido_url = resolveurl.resolve(linkstr)
				except Exception,e:
					xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))
			print ''
		else:
			try:
				result=parseDOM(nextlink,'p', attrs={'id': "embvide"})[0]
				alstr=re.findall("""var alantvcom_streaminglive.+?['"](.+?)['"]""",result)[0]
				decoded=decodeAlan(alstr,True)
				decoded= urllib.unquote(decoded)	
				aespass=re.findall("decrypt\((.+?)\)",decoded) 			
				if aespass:	
					nextlink=decryptaes(aespass[0])	
			except:
				pass
			
			try:
				url = parseDOM(nextlink, 'iframe', ret='src')[0]
			except:
				url=re.compile('src=["\']\\s*((?:http|//).*?)["\']',re.DOTALL+re.IGNORECASE).findall(nextlink)[0]
			url=url.replace("socolive.netch",'socolive.net/ch').replace('superhd.me//update/channel-','superhd.me/Channel/channel')	
			query=getUrlReq(url)
			vido_url = mydecode.decode(url,query)
			if vido_url:
				vido_url = 'http:'+vido_url if vido_url.startswith('//') else vido_url
	else:
		s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak linków')
	if vido_url:
		xbmc.sleep(1000)
		xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=vido_url))
	else:
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',"Can't resolve or no links")
		xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86') #E9
	char = char.replace('\\u00e9','\xc3\xa9').replace('\\u00C9','\xc3\x89') #E9	
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&nbsp;',".").replace('&amp;','&')
	return char	

if __name__ == '__main__':
	mode = params.get('mode', None)
	if not mode:
		home()	
	elif mode == 'getLinks':
		getLinks(exlink)				
	elif mode == 'alanevents':
		ListEvents(exlink)		
	elif mode == 'highlights':
		ListHighlights(exlink)			
	elif mode == 'foothighlights':
		ListFoothighlights(exlink)		
	elif mode == 'alantv':
		ListAlan(exlink)
		xbmcplugin.endOfDirectory(addon_handle)
	elif mode == 'sportpieces':
		ListSportpieces(exlink)
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Search... ', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			ListSearch(query)	
	elif mode=='searchdate':
		query = xbmcgui.Dialog().input(u'Enter date', type=xbmcgui.INPUT_DATE)	
		if query:			
			Listdate(exlink,query)
	elif mode=='searchhigh':
		query = xbmcgui.Dialog().input(u'Search... ', type=xbmcgui.INPUT_ALPHANUM,)
		if query:  	
			Listsearchhigh(exlink,query)