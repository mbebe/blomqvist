# -*- coding: utf-8 -*-

import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin

base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_handle        = xbmcaddon.Addon()
FANART=''
BASEURL='https://ninateka.pl'
TIMEOUT = 15
UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'

def getUrl(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)
    req.add_header('Referer', BASEURL)
    if cookies:
        req.add_header('Cookie', cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        content = response.read()
    except:
        content=''
    return content
	
def PLchar(letter):
    if isinstance(letter, unicode):
        letter = letter.encode('utf-8')
    letter = letter.replace('&lt;br/&gt;',' ')
    letter = letter.replace('&nbsp;','')
    s='JiNcZCs7'
    letter = re.sub(s.decode('base64'),'',letter)
    letter = letter.replace('&quot;','"').replace('&amp;quot;','"')
    letter = letter.replace('&oacute;','ó').replace('&Oacute;','Ó')
    letter = letter.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    letter = letter.replace('&amp;','&')
    letter = letter.replace('\u0105','ą').replace('\u0104','Ą')
    letter = letter.replace('\u0107','ć').replace('\u0106','Ć')
    letter = letter.replace('\u0119','ę').replace('\u0118','Ę')
    letter = letter.replace('\u0142','ł').replace('\u0141','Ł')
    letter = letter.replace('\u0144','ń').replace('\u0144','Ń')
    letter = letter.replace('\u00f3','ó').replace('\u00d3','Ó')
    letter = letter.replace('\u015b','ś').replace('\u015a','Ś')
    letter = letter.replace('\u017a','ź').replace('\u0179','Ź')
    letter = letter.replace('\u017c','ż').replace('\u017b','Ż')
    return letter
	
def scanMain(url):
    if BASEURL not in url:
        url = urlparse.urljoin(BASEURL,url)
    content = getUrl(url)
    out=[]

    nextPage = re.compile('<a href="(.*?)" class="nextPage">').search(content)
    nextPage = nextPage.group(1) if nextPage else False
    prevPage = re.compile('<a href="(.*?)" class="prevPage">').search(content)
    prevPage = prevPage.group(1) if prevPage else False
    subset = re.compile('<li>(.*?)</li>',re.DOTALL).findall(content)
    for subitems in subset:
        href = re.compile('<a href="(.*?)" class="image').findall(subitems)
        imag = re.compile('<img alt=".*?" src="(.*?)"').findall(subitems)
        title=re.compile('class="title"[^>]*>(.*?)<').findall(subitems)
        plot= re.compile('<span class="text">(.*?)</span>').findall(subitems)
        code = re.compile('<span aria-hidden="true">(.*?)</span>').findall(subitems)
        if href and title:
            one={
                'href':BASEURL+href[0],
                'img':imag[0].split('?')[0] if imag else '',
                'title': PLchar(title[0]),
                'plot':PLchar(plot[0]) if plot else '',
                'code' : code[0].replace('JiMzOTs='.decode('base64'),"'") if code else ''
                }
            out.append(one)
    print out
    print (prevPage,nextPage)
    return out,(prevPage,nextPage)
	
def decode(a,e):
    out=[]
    for s in a.get('sources',[]):
        s['url'] = ''.join([chr(int(e)^ord(i)) for i in s.get('src','')] )
        s['label'] = s['url'].split('/')[-1].split('.')[-1]
        if s['label'] in ['m3u8','mp4','m3u']:
            out.append({'url':s['url'],'label':s['label']})
    return out
	
def getVideoLink(url):
    if BASEURL not in url: url = urljoin(BASEURL,url)
    content = getUrl(url)
    dec_sources=[]
    sources = re.compile('playerOptionsWithMainSource\\s*=\\s*(.*?});',re.DOTALL).findall(content)
    code = re.compile('\\(playerOptionsWithMainSource,\\s*(\\d+)\\)').findall(content)
    if sources and code:
        sources = eval(sources[0].replace('false','False').replace('true','True'))
        dec_sources = decode(sources,code[0])
    elif '<div class="niedostepny">' in content:
        dec_sources=[{'url':'','label':'Ten materia\xc5\x82 wideo/audio jest niedost\xc4\x99pny poza granicami Polski'},
               {'url':'','label':'This content is availabe in Poland only'}]
    return dec_sources
	
def getData():
    data = ' <li data-codename="film"><a href="/filmy/film">film</a> <ul> <li data-codename="animacje"><a href="/filmy/film,animacje">animacje</a></li> <li data-codename="bajki"><a href="/filmy/film,bajki">bajki</a></li> <li data-codename="dokumenty"><a href="/filmy/film,dokumenty">dokumenty</a></li> <li data-codename="eksperymenty"><a href="/filmy/film,eksperymenty">eksperymenty</a></li> <li data-codename="fabuly"><a href="/filmy/film,fabuly">fabuły</a></li> <li data-codename="o-filmie"><a href="/filmy/film,o-filmie">o filmie</a></li> </ul> </li> <li data-codename="teatr"><a href="/filmy/teatr">teatr</a> <ul> <li data-codename="spektakle"><a href="/filmy/teatr,spektakle">spektakle</a></li> <li data-codename="opera"><a href="/filmy/teatr,opera">opera</a></li> <li data-codename="sluchowiska"><a href="/filmy/teatr,sluchowiska">słuchowiska</a></li> <li data-codename="taniec"><a href="/filmy/teatr,taniec">taniec</a></li> <li data-codename="o-teatrze"><a href="/filmy/teatr,o-teatrze">o teatrze</a></li> </ul> </li> <li data-codename="muzyka"><a href="/filmy/muzyka">muzyka</a> <ul> <li data-codename="o-muzyce"><a href="/filmy/muzyka,o-muzyce">o muzyce</a></li> <li data-codename="koncerty"><a href="/filmy/muzyka,koncerty">koncerty</a></li> <li data-codename="muzykotekaszkolna"><a href="/filmy/muzyka,muzykotekaszkolna">Muzykoteka Szkolna</a></li> <li data-codename="powazna"><a href="/filmy/muzyka,powazna">poważna</a></li> <li data-codename="ludowa"><a href="/filmy/muzyka,ludowa">ludowa</a></li> <li data-codename="popularna"><a href="/filmy/muzyka,popularna">popularna</a></li> </ul> </li> <li data-codename="sztuka"><a href="/filmy/sztuka">sztuka</a> <ul> <li data-codename="architektura"><a href="/filmy/sztuka,architektura">architektura</a></li> <li data-codename="fotografia"><a href="/filmy/sztuka,fotografia">fotografia</a></li> <li data-codename="performans"><a href="/filmy/sztuka,performans">performans</a></li> <li data-codename="wideo-art"><a href="/filmy/sztuka,wideo-art">wideo-art</a></li> <li data-codename="wystawy"><a href="/filmy/sztuka,wystawy">wystawy</a></li> <li data-codename="o-sztuce"><a href="/filmy/sztuka,o-sztuce">o sztuce</a></li> </ul> </li> <li data-codename="literatura"><a href="/filmy/literatura">literatura</a> <ul> <li data-codename="sluchowiska"><a href="/filmy/literatura,sluchowiska">słuchowiska</a></li> <li data-codename="poezja"><a href="/filmy/literatura,poezja">poezja</a></li> <li data-codename="proza"><a href="/filmy/literatura,proza">proza</a></li> <li data-codename="o-literaturze"><a href="/filmy/literatura,o-literaturze">o literaturze</a></li> <li data-codename="dramat-1"><a href="/filmy/literatura,dramat-1">dramat</a></li> </ul> </li> <li data-codename="publicystyka"><a href="/filmy/publicystyka">publicystyka</a> <ul> <li data-codename="audycje-radiowe"><a href="/filmy/publicystyka,audycje-radiowe">audycje radiowe</a></li> <li data-codename="debaty-i-konferencje"><a href="/filmy/publicystyka,debaty-i-konferencje">debaty i konferencje</a></li> <li data-codename="historia-i-polityka"><a href="/filmy/publicystyka,historia-i-polityka">historia i polityka</a></li> <li data-codename="rozmowy"><a href="/filmy/publicystyka,rozmowy">rozmowy</a></li> <li data-codename="wydarzenia"><a href="/filmy/publicystyka,wydarzenia">wydarzenia</a></li> <li data-codename="program-tv"><a href="/filmy/publicystyka,program-tv">program tv</a></li> </ul> </li> <li data-codename="media-i-technologie"><a href="/filmy/media-i-technologie">media i technologie</a> <ul> <li data-codename="kultura-20"><a href="/filmy/media-i-technologie,kultura-20">kultura 2.0</a></li> <li data-codename="digitalizacja"><a href="/filmy/media-i-technologie,digitalizacja">digitalizacja</a></li> <li data-codename="archiwa-prywatne"><a href="/filmy/media-i-technologie,archiwa-prywatne">archiwa prywatne</a></li> <li data-codename="tutorial"><a href="/filmy/media-i-technologie,tutorial">tutoriale</a></li> </ul> </li> </ul>'
    items = re.compile('<a href="(.*?)">(.*?)</a>',).findall(data)
    return items
	
def addLinkItem(name, url, mode, page=1, iconimage=None, infoLabels=False, IsPlayable=True, isFolder = False, fanart=FANART,contextmenu=1):
    u = buildUrl({'mode': mode, 'foldername': name, 'ex_link' : url, 'page':page})
    if iconimage==None:
        iconimage='DefaultFolder.png'
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art=dict(zip(art_keys,[iconimage for x in art_keys]))
    liz.setArt(art)
    if not infoLabels:
        infoLabels={'title': name}
    liz.setInfo(type='video', infoLabels=infoLabels)
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')
    if fanart:
        liz.setProperty('fanart_image',fanart)
    outX = []
    outX.append(('Informacja', 'XBMC.Action(Info)'))
    liz.addContextMenuItems(outX, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=isFolder,totalItems=contextmenu)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = '%R, %Y, %P')
    return ok
	
def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        out_dict[k] = v
    return out_dict
	
def buildUrl(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))
mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
page = args.get('page',[1])[0]
if mode is None:
    for href,title in getData():
        title = '   '+title if ',' in href else '[COLOR blue]%s[/COLOR]'%title
        addLinkItem(title, url=href, mode='getContent', page=1, IsPlayable=False, isFolder=True, fanart='http://nina.files.e51-po.insyscd.net/tlo-na-strone-glowna-ninateki/tlo7.jpg')
elif mode[0]=='getContent':
    items,pagination =  scanMain(ex_link)
    if pagination[0]:addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=pagination[0], mode='__page:getContent', page=1, IsPlayable=False)
    for f in items: addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,contextmenu=len(items))
    if pagination[1]: addLinkItem(name='[COLOR blue]>> nastepna strona >>[/COLOR]', url=pagination[1], mode='__page:getContent', page=1, IsPlayable=False)
elif mode[0].startswith('__page:'):
    url = buildUrl({'mode': mode[0].split(':')[-1], 'foldername': '', 'ex_link' : ex_link, 'page': page})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
elif mode[0] == 'getLinks':
    link = getVideoLink(ex_link)
    stream_url=''
    t = [ x.get('label') for x in link]
    s = xbmcgui.Dialog().select('Linki', t)
    if s>-1: stream_url = link[s].get('url')
    print stream_url
    if stream_url: xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
    else: xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
else:
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
xbmcplugin.endOfDirectory(addon_handle)
