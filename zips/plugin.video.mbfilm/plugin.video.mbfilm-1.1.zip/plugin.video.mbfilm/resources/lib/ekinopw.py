# -*- coding: UTF-8 -*-
import sys,re,os
import geturl as gethtml
import requests
from cmf2 import parseDOM
from cmf2 import replaceHTMLCodes
import web_pdb
basurl='https://ekino.pw/'

def getFilmy(page):
	url=basurl+'filmy/'
	url = url + 'page/%s/' %page
	#web_pdb.set_trace()
	html,kuks = gethtml.getRequests(url)
	out=[]
	#web_pdb.set_trace()
	#<div data-movie-id="3679" class="ml-item">
	links = parseDOM(html,'div', attrs={'data-movie-id': ".+?",'class':"ml-item"})
	npage=[]
	if '/filmy/page/%s/'%str(int(page)+1) in  html:
		npage.append({'title':'Następna strona','url':'','image':'','plot':'','page':int(page)+1}) 
		#npage.append({'title':PLchar(tytul),'href':href,'img':imag,'plot':PLchar(opis),'year':year,'genre':genre,'code':jak})
	#/filmy/page/4/
	for link in links:
		href = parseDOM(link, 'a', ret='href')[0] 
		imag = parseDOM(link, 'img', ret='data-original')[0] #img data-original
		imag = re.sub('p\/w(\d+)','p/w500',imag)
		tytul = parseDOM(link,'div', attrs={'class':"qtip-title"})[0]
		opis = parseDOM(link,'p')[0]# #parseDOM(link, 'a', ret='href')[0] class="qtip-title"
		dane = parseDOM(link,'div', attrs={'class':"jt-info"})#[0]#<div class="jt-info">
		year=''
		for dan in dane:
			year = re.findall('rel="tag">(.+?)<',dan)#[0]
			if year:
				year=year[0]
		jak = parseDOM(link,'div', attrs={'class':"jtip-quality"})#<div class="jtip-quality">
		jak = jak[0] if jak else ''
		year = re.findall('rel="tag">(.+?)<',link)#[0]
		year = year[0] if year else ''
		genre = re.findall('rel="category tag">([^>]+)<',link)
		kateg = ','.join([(x.strip()).lower() for x in genre]) if genre else ''
		out.append({'title':PLchar(tytul),'url':href,'image':imag,'plot':PLchar(opis),'year':year,'genre':genre,'code':jak})
	return out,npage
def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&#039;',"'")
	char = char.replace('&quot;','"').replace('&oacute;','ó').replace('&rsquo;',"'")
	char = char.replace('&nbsp;',".").replace('&amp;','&').replace('&eacute;','e')
	return char	
#def import_mod(s):
#    mod = {}
#	if   s == 'livenet'     import livenet     as mod
#	elif s == 'ekinopw'     import ekinopw     as mod
#	elif s == 'wizjerpl'    import wizjerpl    as mod
#	elif s == 'cdaonline'   import cdaonline   as mod
#	elif s == 'rodzinne'    import rodzinne    as mod
#	elif s == 'watchmovies' import watchmovies as mod
#	elif s == 'filmweb4u2'  import filmweb4u2  as mod
#	elif s == 'znetlive'    import znetlive    as mod
#	elif s == 'filmeriaco'  import filmeriaco  as mod
#    return mod
#	
#def router(paramstring):
#	params = dict(parse_qsl(paramstring))
#	if params:
#		mode = params.get('mode', None)
#		
#		if 'mainp' in mode:#mode == 'listFilmy3filmy':
#			mode2 = mode.split(':')
#			mod = import_mod(mode2)
#			items = mod.getMain()
#				
##			
##			ListFilmy3filmy	(exlink,page,katv,rokv,skatv,srokv,verv,alfv)
##		
##		elif mode == 'listSerial':
##			ListSerial(exlink)
##			
##		elif mode == 'getEpisodes':	
##			getEpisodes(exlink)
##		
##		elif mode == 'listSeriale':
##			ListSeriale(exlink,page)
##				
##		elif mode == 'listSearch':
##			ListSearch()			
##
##		elif mode == 'resetfil':
##			n='Wszystkie'
##			v=''
##			addon.setSetting('katV',v)
##			addon.setSetting('skatV',v)
##			addon.setSetting('alfV',v)
##			addon.setSetting('verV',v)
##			addon.setSetting('rokV',v)
##			addon.setSetting('srokV',v)
##			
##			addon.setSetting('katN',n)
##			addon.setSetting('skatN',n)
##			addon.setSetting('alfN',n)
##			addon.setSetting('nerN',n)
##			addon.setSetting('rokN',n)
##			addon.setSetting('srokN',n)	
##			xbmc.executebuiltin("Container.Refresh") 
##		
##		elif 'kateg' in mode:
##			if 'film' in mode:
##				myMode = 'kat'
##			else:
##				myMode = 'skat'
##			
##			label =['Wszystkie','Akcja','Animacja','Biograficzny','Detektywistyczny','Dokumentalny','Dramat','Familijny','Fantasy','Film-Noir','Historyczny','Horror','Katastroficzny','Komedia','Kostiumowy','Kryminał','Krótkometrażowy','Musical','Muzyczny','Obyczajowy','Przygodowy','Romans','Sci-Fi','Sensacyjny','Sport','Thriller','Western','Wojenny']
##			value = ['','akcja','animacja','biograficzny','detektywistyczny','dokumentalny','dramat','familijny','fantasy','film-noir','historyczny','horror','katastroficzny','komedia','kostiumowy','kryminał','krótkometrażowy','musical','muzyczny','obyczajowy','przygodowy','romans','sci-fi','sensacyjny','sport','thriller','western','wojenny']
##			msg = 'kategorie'
##			
##			try:
##				sel = xbmcgui.Dialog().multiselect('Wybierz '+msg,label)
##			except:
##				sel = xbmcgui.Dialog().select('Wybierz '+msg,label)
##			if not sel: sel=quit()
##			if isinstance(sel,list):
##
##				n = '%s'%','.join( [ label[i] for i in sel]) if sel[0]>-1 else ''			
##				v= ','.join('"{0}"'.format(value[i]) for i in sel) if sel[0]>-1 else ''
##				if 'Wszystkie' in n:	
##					n='Wszystkie'
##					v=''
##
##			else:
##				sel = sel if sel>-1 else quit()
##				v = '%s'%(value[sel])
##				n = '%s'%(label[sel])
##
##			addon.setSetting(myMode+'V',v)
##			addon.setSetting(myMode+'N',n)		
##			xbmc.executebuiltin("Container.Refresh") 	
##			
##		elif 'alfabet' in mode:
##			value = ['','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','1','2','9']
##			label =['Wszystkie','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','1','2','9']
##			msg = 'literę/litery'
##			myMode = 'alf'
##			try:
##				sel = xbmcgui.Dialog().multiselect('Wybierz '+msg,label)
##			except:
##				sel = xbmcgui.Dialog().select('Wybierz '+msg,label)
##			if not sel: sel=quit()
##			if isinstance(sel,list):
##				n = '%s'%','.join( [ label[i] for i in sel]) if sel[0]>-1 else ''							
##				v= ','.join('"{0}"'.format(value[i]) for i in sel) if sel[0]>-1 else ''
##
##				if 'Wszystkie' in n:	
##					n='Wszystkie'
##					v=''
##			else:
##				sel = sel if sel>-1 else quit()
##				v = '%s'%(value[sel])
##				n = '%s'%(label[sel])
##			addon.setSetting(myMode+'V',v)
##			addon.setSetting(myMode+'N',n)		
##			xbmc.executebuiltin("Container.Refresh") 
##			
##			
##		elif 'jezyk' in mode:
##			value = ['','6','1','5','0','4','3']
##			label =['Wszystkie','Polski','Lektor','Dubbing','Napisy PL','Napisy EN','ENG']
##		
##			msg = 'wersję językową'
##			myMode = 'ver'
##			try:
##				sel = xbmcgui.Dialog().multiselect('Wybierz '+msg,label)
##			except:
##				sel = xbmcgui.Dialog().select('Wybierz '+msg,label)
##			if not sel: sel=quit()
##			if isinstance(sel,list):
##				n = '%s'%','.join( [ label[i] for i in sel]) if sel[0]>-1 else ''		
##				v= ','.join('"{0}"'.format(value[i]) for i in sel) if sel[0]>-1 else ''
##				if 'Wszystkie' in n:	
##					n='Wszystkie'
##					v=''
##			else:
##				sel = sel if sel>-1 else quit()
##				v = '%s'%(value[sel])
##				n = '%s'%(label[sel])
##			addon.setSetting(myMode+'V',v)
##			addon.setSetting(myMode+'N',n)		
##			xbmc.executebuiltin("Container.Refresh") 
##			
##		elif 'rok' in mode:
##			if 'film' in mode:
##				myMode = 'rok'
##			else:
##				myMode = 'srok'
##
##			label = ['Wszystkie','2020','2019','2018','2017', '2016', '2015', '2014', '2013', '2012', '2011', '2010', '2009', '2008', '2007', '2006', '2005', '2004', '2003', '2002', '2001', '2000', '1999', '1998', '1997', '1996', '1995', '1994', '1993', '1992', '1991', '1990', '1989', '1988', '1987', '1986', '1985', '1984', '1983', '1982', '1981', '1980', '1979', '1978', '1977', '1976', '1975', '1974', '1973', '1972', '1971', '1970', '1969', '1968', '1967', '1966', '1965', '1964', '1963', '1962', '1961', '1960', '1959', '1958', '1957', '1956', '1955', '1954', '1953', '1952', '1951', '1950', '1949', '1948', '1947', '1946', '1945', '1944', '1943', '1942', '1941', '1940', '1939', '1938', '1937', '1936', '1935', '1934', '1933', '1932', '1931', '1930', '1929', '1928', '1927', '1926', '1925', '1924', '1923', '1922', '1921', '1920', '1919', '1918', '1917', '1916', '1915', '1914', '1911', '1908', '1902']
##			value=['','2020','2019','2018','2017', '2016', '2015', '2014', '2013', '2012', '2011', '2010', '2009', '2008', '2007', '2006', '2005', '2004', '2003', '2002', '2001', '2000', '1999', '1998', '1997', '1996', '1995', '1994', '1993', '1992', '1991', '1990', '1989', '1988', '1987', '1986', '1985', '1984', '1983', '1982', '1981', '1980', '1979', '1978', '1977', '1976', '1975', '1974', '1973', '1972', '1971', '1970', '1969', '1968', '1967', '1966', '1965', '1964', '1963', '1962', '1961', '1960', '1959', '1958', '1957', '1956', '1955', '1954', '1953', '1952', '1951', '1950', '1949', '1948', '1947', '1946', '1945', '1944', '1943', '1942', '1941', '1940', '1939', '1938', '1937', '1936', '1935', '1934', '1933', '1932', '1931', '1930', '1929', '1928', '1927', '1926', '1925', '1924', '1923', '1922', '1921', '1920', '1919', '1918', '1917', '1916', '1915', '1914', '1911', '1908', '1902']
##			ex_link='year'
##			msg = 'rok/lata produkcji'
##			
##			try:
##				sel = xbmcgui.Dialog().multiselect('Wybierz '+msg,label)
##			except:
##				sel = xbmcgui.Dialog().select('Wybierz '+msg,label)
##			if not sel: sel=quit()
##			if isinstance(sel,list):
##				n = '%s'%','.join( [ label[i] for i in sel]) if sel[0]>-1 else ''				
##				v= ','.join('"{0}"'.format(value[i]) for i in sel) if sel[0]>-1 else ''
##
##				if 'Wszystkie' in n:	
##					n='Wszystkie'
##					v=''
##			else:
##				sel = sel if sel>-1 else quit()
##				v = '%s'%(value[sel])
##				n = '%s'%(label[sel])
##			addon.setSetting(myMode+'V',v)
##			addon.setSetting(myMode+'N',n)		
##			xbmc.executebuiltin("Container.Refresh") 	
##			
##		elif mode == 'play3Filmy':	
##			Play3Filmy(exlink)
##		elif mode == 'settings':
##			addon.openSettings()
##			xbmc.executebuiltin('XBMC.Container.Refresh()')
#	else:
#		home()
#		xbmcplugin.endOfDirectory(addon_handle)	
#if __name__ == '__main__':
#    router(sys.argv[2][1:])
#