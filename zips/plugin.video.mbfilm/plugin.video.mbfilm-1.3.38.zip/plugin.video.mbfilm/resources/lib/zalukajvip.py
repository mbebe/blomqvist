# -*- coding: UTF-8 -*-
import sys,re,os
import resources.lib.geturl as gethtml
from resources.lib.geturl import PLchar #as PLchar

if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus
    import urllib.parse as urlparse
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse

basurl='https://zalukaj.vip/'
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'

def ListContent(url,page):
    if '/page/' in url:
        nturl = re.sub('page\/\\d+','page/%d'%(int(page)+1),url)
        url = re.sub('page\/\\d+','page/%d'%int(page),url)
    else:
        nturl = url + 'page/%d' %(int(page)+1)
        url = url + 'page/%d' %int(page)
        
        
        
    
    regex = r"post\-.+?"
    movs= "movies__inner"
    if 'tv-shows-2' in url or 'xxserial' in url:
        regex = "tv-show post\-.+?"#
        url = url.split('|')[0]
        movs='xxx'
    html,kuks = gethtml.getRequests(url)
    npage=[]
    fout=[]
    sout=[]
    
    try:
        pagination = parseDOM(html,'ul', attrs={'class': "page-numbers"})[0]
        if pagination.find( '/page/%d' %(int(page)+1))>-1:
            npage.append({'title':'Następna strona','url':nturl,'image':'','plot':'','page':int(page)+1})
    except:
        pass
    result = parseDOM(html,'div', attrs={'class': movs})
    result =result[0] if result else html    
    links = parseDOM(result,'div', attrs={'class': regex})
    
    for link in links:
        href = parseDOM(link, 'a', ret='href')[0]
        imag = parseDOM(link, 'img', ret='src')[0]
        try:
            tytul = (parseDOM(link, 'h4')[0]).strip(' ')
        except:
            tytul = (parseDOM(link, 'h3')[0]).strip(' ')
        if '<h2>' in tytul:
            tytul = (tytul.split('<h2>')[0]).strip(' ')
        opis = parseDOM(link,'div', attrs={'class': "texto"})
        opis = opis[0] if opis else tytul
        jako = re.findall('poster-badges">(.*?)<\/div>',link)
        jako = jako[0]. strip() if jako else ''
        metad = parseDOM(link,'div', attrs={'class': "movie__meta"})
        if metad:
            year = parseDOM(metad[0],'span', attrs={'class': ".+?release-year"})
            year =year[0] if year else ''
            genre = re.findall('rel="tag">([^>]+)<',metad[0])
            kateg = ','.join([(x.strip()).lower() for x in genre]) if genre else ''

        else:
            year = parseDOM(link,'span', attrs={'class': ".+?release-year"})
            year =year[0] if year else ''
            genre = re.findall('rel="tag">([^>]+)<',link)
            kateg = ','.join([(x.strip()).lower() for x in genre]) if genre else ''

        if '/movie/' in     href:
            fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'code':PLchar(jako),'year':year,'genre':PLchar(kateg)})    
        else:
            sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'code':PLchar(jako),'year':year,'genre':PLchar(kateg)})

    return fout,sout,npage

def SelectList(typ):
    if 'gatunek' in typ:
        label =["Wszystkie","Akcja","Animowany","Biograficzny","Dokumentalny","Dramat","Erotyczny","Familijny","Fantasy","Historyczny","Hity filmowe","Horror","Komedia","Kryminał","Melodramat","Muzyczny","Ostatnio dodane filmy","Polskie","Premiera z napisami","Premiery ekskluzywne","Przygodowy","Romans","Sci-fi","Sportowy","Thriller","Western","Wojenny"]
        value =["https://zalukaj.vip/movies/page/1/","https://zalukaj.vip/movies/page/1/?filter_genre=akcja&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=animowany&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=biograficzny&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=dokumentalny&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=dramat&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=erotyczny&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=familijny&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=fantasy&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=historyczny&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=hity-filmowe&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=horror&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=komedia&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=kryminal&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=melodramat&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=muzyczny&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=ostatnio-dodane-filmy&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=polskie&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=premiera-z-napisami&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=premiery-ekskluzywne&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=przygodowy&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=romans&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=sci-fi&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=sportowy&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=thriller&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=western&query_type_genre=or","https://zalukaj.vip/movies/page/1/?filter_genre=wojenny&query_type_genre=or"]
        nazwa = "Wybierz gatunek"

    elif 'rok' in typ:
        label =["2021", "2020","2019","2018","2017","2016","2015","2014","2013","2012","2011","2010","2009","2008","2007","2006","2005","2004","2003","2002","2001","2000"]
        value =["https://zalukaj.vip/movies/page/1/?year_filter=2021", "https://zalukaj.vip/movies/page/1/?year_filter=2020","https://zalukaj.vip/movies/page/1/?year_filter=2019","https://zalukaj.vip/movies/page/1/?year_filter=2018","https://zalukaj.vip/movies/page/1/?year_filter=2017","https://zalukaj.vip/movies/page/1/?year_filter=2016","https://zalukaj.vip/movies/page/1/?year_filter=2015","https://zalukaj.vip/movies/page/1/?year_filter=2014","https://zalukaj.vip/movies/page/1/?year_filter=2013","https://zalukaj.vip/movies/page/1/?year_filter=2012","https://zalukaj.vip/movies/page/1/?year_filter=2011","https://zalukaj.vip/movies/page/1/?year_filter=2010","https://zalukaj.vip/movies/page/1/?year_filter=2009","https://zalukaj.vip/movies/page/1/?year_filter=2008","https://zalukaj.vip/movies/page/1/?year_filter=2007","https://zalukaj.vip/movies/page/1/?year_filter=2006","https://zalukaj.vip/movies/page/1/?year_filter=2005","https://zalukaj.vip/movies/page/1/?year_filter=2004","https://zalukaj.vip/movies/page/1/?year_filter=2003","https://zalukaj.vip/movies/page/1/?year_filter=2002","https://zalukaj.vip/movies/page/1/?year_filter=2001","https://zalukaj.vip/movies/page/1/?year_filter=2000"]
        nazwa = "Wybierz rok"

    sel = gethtml.selectDialog(nazwa, label)
    if sel>-1:
        kategoria = value[sel]
        return kategoria
    else:
        quit()

def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out    
    
def getSerial(url):

    html,kuks = gethtml.getRequests(url)
    resultmain = parseDOM(html,'div', attrs={'class': "summary entry-summary"})[0]
    tytul = parseDOM(resultmain,'h1')[0]#'lll'
    metad = parseDOM(resultmain,'div', attrs={'class': "tv-show__meta"})#[0]

    year=''
    kateg =''
    if metad:
        genre = re.findall('rel="tag">([^>]+)<',metad[0])
        kateg = ','.join([(x.strip()).lower() for x in genre]) if genre else ''
        
        year = parseDOM(metad[0],'span', attrs={'class': "tv-show__meta--release-year"})
        year = year[0] if year else ''
    
    widinfo = parseDOM(html,'div', attrs={'class': "tv-show__description"})[0] 

    opis = parseDOM(widinfo,'p')
    opis = opis[0] if opis else ''

    resultsez = parseDOM(html,'div', attrs={'class': "masvideos-tabs"})[0]
    sezonow = parseDOM(resultsez,'ul', attrs={'class': "nav"})[0]
    tabsez = re.findall('href=(.+?)\s+.+?">([^>]+)<',sezonow)

    episodes=[]
    for tab,sez in tabsez:
        sez = (sez.replace('\n','')).strip(' ')
        tab = tab.replace('#','')
        ses = re.findall('(\d+)',sez,re.IGNORECASE)
        ses = ses[0] if ses else '0'
        sezyk = parseDOM(resultsez,'div', attrs={'id': tab})
        for sezy in sezyk:
            eps = parseDOM(sezy,'div', attrs={'class': "post-.+?"})
            for ep in eps:
                tyt2 = parseDOM(ep, 'h3')[0] 
                href = parseDOM(ep, 'a', ret='href')[0]  
                epis = re.findall('sezon.+?[episod|odcinek]\-(\d+)',href)[0]
                rys = parseDOM(ep, 'img', ret='src')[0]  
                tyt1 = 'S%02dE%02d'%(int(ses),int(epis[0]))
                tyt = '%s - (%s) %s'%(tytul,tyt1,tyt2)
                episodes.append({'title':PLchar(tyt),'url':PLchar(href),'image':PLchar(rys),'plot':PLchar(opis),'genre':PLchar(kateg),'season':int(ses),'episode':int(epis[0])})
            
    seasons = splitToSeasons(episodes)
    return seasons

def getVideo(url):
    out=[]
    vipcuk= gethtml.get_setting('vipkuk')
    if vipcuk:
        headers={'user-agent': UA, 'cookie':vipcuk}
    else:
        headers={'user-agent': UA}
    html,kuks = gethtml.getRequests(url,headers=headers)

    stream_url=''
    regex = "movie__player"
    if '/episode/' in url:
        regex = "episode__player"
    result = parseDOM(html,'div', attrs={'class': regex}) 

    if result:
        result=result[0]
        if '">zaloguj si' in result:
            result=ZalogujSie(url,kuks)
        stream_url = parseDOM(result, 'iframe', ret='src')# [0]
        if stream_url:
            return stream_url[0],True
        else:

            stream_url = re.findall('source\s*src\s*=\s*"([^"]+)',result)
            napisy = re.findall('track\s*src\s*=\s*"([^"]+)',result)

            if stream_url:
                if napisy:
                    st_url = stream_url[0]+'|napisy|'+napisy[0]
                else:
                    st_url = stream_url[0]
                return st_url,False
            else:
                return '',True

    else:
        return '',False

def ListSerieContent(url):
    html,kuks = gethtml.getRequests('https://zalukaj.vip/serie-filmowe/')
    out=[]
    series = parseDOM(html,'section', attrs={'id': "section-movies.+?"})#[0]
    for serie in series:
        if not url in serie:
            continue
        else:
            links = parseDOM(serie,'div', attrs={'class': "post\-.+?"})
            
            for link in links:
                href = parseDOM(link, 'a', ret='href')[0]
                imag = parseDOM(link, 'img', ret='src')[0]
                try:
                    tytul = (parseDOM(link, 'h4')[0]).strip(' ')
                except:
                    tytul = (parseDOM(link, 'h3')[0]).strip(' ')
                if '<h2>' in tytul:
                    tytul = (tytul.split('<h2>')[0]).strip(' ')
                opis = parseDOM(link,'div', attrs={'class': "texto"})
                opis = opis[0] if opis else tytul
                metad = parseDOM(link,'div', attrs={'class': "movie__meta"})
                if metad:
                    year = parseDOM(metad[0],'span', attrs={'class': ".+?release-year"})
                    year =year[0] if year else ''
                    genre = re.findall('rel="tag">([^>]+)<',metad[0])
                    kateg = ','.join([(x.strip()).lower() for x in genre]) if genre else ''
        
                else:
                    year = parseDOM(link,'span', attrs={'class': ".+?release-year"})
                    year =year[0] if year else ''
                    genre = re.findall('rel="tag">([^>]+)<',link)
                    kateg = ','.join([(x.strip()).lower() for x in genre]) if genre else ''
        
                #if '/movie/' in     href:
                out.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'genre':PLchar(kateg)})    
            break
    return out
def getSerieF (url):
    html,kuks = gethtml.getRequests(url)

    out=[]
    series = parseDOM(html,'section', attrs={'id': "section-movies.+?"})#[0]
    for serie in series:
        tytul = parseDOM(serie,'h2', attrs={'class': "home-section__title"})[0]
        tytul=re.findall('br>(.+?)$',tytul)
        tytul = tytul[0].strip(' ') if tytul else tytul[0]
        imag = parseDOM(serie, 'img', ret='src') [0]
        out.append({'title':PLchar(tytul),'url':PLchar(tytul),'image':PLchar(imag),'plot':PLchar(tytul)})
    return out
    
def zaloguj():
    vipcuk= gethtml.get_setting('vipkuk')
    if vipcuk:
        headers={'user-agent': UA, 'cookie':vipcuk}
    else:
        headers={'user-agent': UA}
    html,kuks = gethtml.getRequests('https://zalukaj.vip',headers=headers)
    usr = gethtml.get_setting("username")
    pwd = gethtml.get_setting("password")
    if usr and pwd:
        headers = {
        'Host': 'zalukaj.vip',
        'user-agent': UA,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
        'referer': 'https://zalukaj.vip/wp-login.php',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://zalukaj.vip',
        'dnt': '1',
        'cookie':kuks+'wordpress_test_cookie=WP+Cookie+check',
        'upgrade-insecure-requests': '1',
        'te': 'trailers',}
        
    
        data = 'log='+usr+'&pwd='+pwd+'&wp-submit=Zaloguj+si%C4%99&redirect_to=https%3A%2F%2Fzalukaj.vip%2Fwp-admin%2F&testcookie=1'
        data = {
            'log': usr,
            'pwd': pwd,
            'wp-submit': 'Zaloguj si\u0119',
            'redirect_to': 'https://zalukaj.vip/wp-admin/',
            'testcookie': '1'}
        
    
        html,kuk = gethtml.getRequests('https://zalukaj.vip/wp-login.php', data=data, headers=headers)
        if 'panel-uzytkownika' in html:
            headers = {
            'Host': 'zalukaj.vip',
            'user-agent': UA,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
            'referer': 'https://zalukaj.vip/',
    
            'origin': 'https://zalukaj.vip',
            'dnt': '1',
            'cookie':kuk,
            'upgrade-insecure-requests': '1',
            'te': 'trailers',}
            url = 'https://zalukaj.vip/panel-uzytkownika-v2/'
            html,kuk = gethtml.getRequests(url, headers=headers)
            wygasax = ''
            if 'premium ważny do' in html:
                wygasax = re.findall('aktywna do\:(.+?)<',html.lower())[0].strip()
                gethtml.set_setting('vipkuk',kuk)
                prem = True
            else:

                prem = False
            wygasa = 'Premium '+wygasax if prem else 'konto darmowe'    
            return True, wygasa

        else:
            return False, 'niepoprawne dane logowania'
 
        return True, wygasa
    else:

        gethtml.set_setting('vipkuk','')
        return False, 'brak danych logowania'

def ZalogujSie(url,kuks):
    
    usr = gethtml.get_setting("username")
    pwd = gethtml.get_setting("password")
    if usr and pwd:
        headers = {
        'Host': 'zalukaj.vip',
        'user-agent': UA,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
        'referer': 'https://zalukaj.vip/wp-login.php',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://zalukaj.vip',
        'dnt': '1',
        'cookie':kuks+'wordpress_test_cookie=WP+Cookie+check',
        'upgrade-insecure-requests': '1',
        'te': 'trailers',}
        

        data = 'log='+usr+'&pwd='+pwd+'&wp-submit=Zaloguj+si%C4%99&redirect_to=https%3A%2F%2Fzalukaj.vip%2Fwp-admin%2F&testcookie=1'
        data = {
            'log': usr,
            'pwd': pwd,
            'wp-submit': 'Zaloguj si\u0119',
            'redirect_to': 'https://zalukaj.vip/wp-admin/',
            'testcookie': '1'}
        

        html,kuk = gethtml.getRequests('https://zalukaj.vip/wp-login.php', data=data, headers=headers)

        if 'panel-uzytkownika' in html:
            headers = {
            'Host': 'zalukaj.vip',
            'user-agent': UA,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
            'referer': 'https://zalukaj.vip/',

            'origin': 'https://zalukaj.vip',
            'dnt': '1',
            'cookie':kuk,
            'upgrade-insecure-requests': '1',
            'te': 'trailers',}

            html,kuk = gethtml.getRequests(url, headers=headers)
            
            if 'Twoja subskrypcja jest nieaktywna' in html:
                gethtml.notificationDialog(r'Uwaga', 'Twoja subskrypcja jest nieaktywna')
                gethtml.set_setting('vipkuk','')
                quit()    
            else:
                gethtml.set_setting('vipkuk',kuk)
                regex = "movie__player"
                if '/episode/' in url:
                    regex = "episode__player"
                result = parseDOM(html,'div', attrs={'class': regex}) 
                return result[0]
        else:
            gethtml.notificationDialog(r'Uwaga', 'Niepoprawne dane logowania')
            quit()    
    else:
        gethtml.set_setting('vipkuk','')
        gethtml.notificationDialog(r'Uwaga', 'Brak danych logowania')
        quit()    
    #response = requests.post('https://zalukaj.vip/wp-login.php', headers=headers, cookies=cookies, data=data)
def Loguj(ref):
    usr = gethtml.get_setting("username")
    pwd = gethtml.get_setting("password")
    if usr and pwd:
        headers = {
            'Host': 'upvideo.xyz',
            'user-agent': UA,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
            'referer': ref,
            'upgrade-insecure-requests': '1',
            'te': 'trailers',
        }
        
        html,kuks = gethtml.getRequests('https://upvideo.xyz/embed/login', headers=headers)
        csrf = re.findall('csrf-token"\s*content="([^"]+)',html)[0]
        headers = {
            'Host': 'upvideo.xyz',
            'user-agent': UA,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://upvideo.xyz',
            'referer': 'https://upvideo.xyz/embed/login',
            'upgrade-insecure-requests': '1',
            'te': 'trailers',
        }
        
        data = '_token='+csrf+'&email='+usr+'&password='+pwd
        
        html,kuk = gethtml.getRequests('https://upvideo.xyz/login', data=data, headers=headers)
        if not 'embed/login"' in html:
            gethtml.set_setting('vipkuk',kuk)
            return html,kuk
        else:
            gethtml.set_setting('vipkuk','')
            gethtml.notificationDialog(r'Uwaga', 'Niepoprawne dane logowania')
            quit()
    else:
        gethtml.set_setting('vipkuk','')
        gethtml.notificationDialog(r'Uwaga', 'Brak danych logowania')
        quit()
def getUpvideocc(url):

    vipcuk= gethtml.get_setting('vipkuk')
    if vipcuk:
        headers={'user-agent': UA, 'cookie':vipcuk}
    else:
        headers={'user-agent': UA}
    html,kuks = gethtml.getRequests(url,headers=headers)
    if 'embed/login"' in html:
        html,kuk=Loguj(url)

        
    stream_url=''
    try:
        stream_url = parseDOM(html, 'source', ret='src') [0]
        wybor = gethtml.get_setting('matqual')
        if wybor!='auto':
            html,kuks = gethtml.getRequests(stream_url)
        
            out=[]
            bandjakhref = re.findall('BANDWIDTH=(.+?),RESOLUTION=(.+?),.+?(http.+?index.+?m3u8)',html,re.IGNORECASE+re.DOTALL)
            for band,jak,href in bandjakhref:
                host = '%s (%s)'%(jak,band)
        
                out.append({'href':href,'host':host})
        
            if len(out)>1:
        
                u = [ x.get('href') for x in  out]
                h = [ x.get('host') for x in  out]
                sel = gethtml.selectDialog("Wybierz jakość", h)
                stream_url = out[sel].get('href') if sel>-1 else 'quit'
            else:
                stream_url = out[0].get('href')
        else:
            stream_url=stream_url
        dod = '|User-Agent='+quote(UA)+'&Referer='+url+'&Cookie='+quote(kuks)
        stream_url+=dod if stream_url else stream_url
    except:
        pass
    return stream_url
def ListSearch(url,page):    
    fout=[]
    sout=[]
    npage=[]
    
    nazwa='filmy'
    
    
    if 'serial' in url:
        nazwa='seriale'
    d = gethtml.inputDialog('Szukaj '+nazwa)
    if d:
        nturl = 'https://zalukaj.vip/page/1/?s='+d+'&post_type[]=movie&post_type[]=tv_show'
        if 'serial' in url:
            nturl = 'https://zalukaj.vip/page/1/?s='+d+'&post_type[]=movie&post_type[]=tv_show|xxserial'    
        fout,sout,npage=ListContent(nturl,page)
    return fout,sout,npage
