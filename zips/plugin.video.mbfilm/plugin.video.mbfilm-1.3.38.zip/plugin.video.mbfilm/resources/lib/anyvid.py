# -*- coding: UTF-8 -*-
import sys,re,os
import resources.lib.geturl as gethtml
from resources.lib.geturl import PLchar 

import xbmc, xbmcaddon, xbmcvfs

if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus
    import urllib.parse as urlparse

else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse

basurl='https://anyvideo.org'
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0'

headersc = {
    
        'Referer':basurl,
        'user-agent': UA,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
    }

def ListContent(url,page):
    if '/page/' in url:
        nturl = re.sub('page\/\\d+','page/%d'%(int(page)+1),url)
        url = re.sub('page\/\\d+','page/%d'%int(page),url)
    else:
    
        nturl = url + 'page/%d' %(int(page)+1)
        url = url + 'page/%d' %int(page)

    html,kuks = gethtml.getRequests(url,headers=headersc)
    npage=[]
    fout=[]
    sout=[]
    if html.find(nturl)>-1:
        npage.append({'title':'Następna strona','url':nturl,'image':'','plot':'','page':int(page)+1})
    links = parseDOM(html,'div', attrs={'class': "hentry.+?"}) 
            
    for link in links:        

        href = parseDOM(link, 'a', ret='href')[0]
        tt  = parseDOM(link,'h2', attrs={'class': "entry-title"})[0] 
        tyt = parseDOM(tt, 'a')[0]
        imag = parseDOM(link, 'img', ret='src')[0]
        opis = ''

        fout.append({'title':PLchar(tyt),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':'','code':'','genre':'', 'duration':'', 'mode2':'dudaplayer'})

            
    return fout,sout,npage

def ListLista(url,page):
    if '/page/' in url:
        nturl = re.sub('page\/\\d+','page/%d'%(int(page)+1),url)
        url = re.sub('page\/\\d+','page/%d'%int(page),url)
    else:
        nturl = url + 'page/%d' %(int(page)+1)
        url = url + 'page/%d' %int(page)

    html,kuks = gethtml.getRequests(url,headers=headersc)
    npage=[]
    fout=[]
    sout=[]
    links = parseDOM(html,'div', attrs={'class': "category-bar"}) 
            
    for link in links:        

        href = parseDOM(link, 'a', ret='href')[0]

        t1 = parseDOM(link,'span', attrs={'class': "category-name"})[0]  
        odc = parseDOM(link, 'strong')[0] #<strong>
        tyt = t1 +'['+str(odc)+']'
        imag = ''
        opis = ''

        sout.append({'title':PLchar(tyt),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':'','code':'','genre':'', 'duration':'', 'mode2':'dudaplayer'})

            
    return fout,sout,npage
    

def ListContentSearch(query,page):

    headersc.update({'Content-Type': 'application/x-www-form-urlencoded'})
    dt = {'wyszukiwarka': query}
    url = 'http://filmyhd.biz/page/1'

    html,kuks = gethtml.getRequests(url,data=dt,headers=headersc)
    npage=[]
    fout=[]
    sout=[]
    result = parseDOM(html,'div', attrs={'class': "box"})[0] 
    dd=re.findall('a href="(.+?)">(.+?)<',result,re.DOTALL)
    for href, tyt in dd:

        fout.append({'title':PLchar(tyt),'url':PLchar(href),'image':'DefaultMovies.png','plot':'','year':'','code':'','genre':'', 'duration':'', 'mode2':'dudaplayer'})
    return fout,sout,npage
    

def getVideo(url):
    out=[]

    html,kuks = gethtml.getRequests(url,headers=headersc)
    stream_url=''

    stream_url = parseDOM(html.replace('\\"','"'), 'iframe', ret='src')#[0]
    stream_url2 = parseDOM(html.replace('\\"','"'), 'IFRAME', ret='SRC')#[0]

    if stream_url or stream_url2:
        stream_url = stream_url[0] if stream_url else stream_url2[0]
        stream_url = 'https:'+ stream_url if stream_url.startswith('//') else stream_url

        return stream_url,True
    else:
        return '','quit'

def szukcd(d):
    page=1
    fout=[]
    sout=[]
    url='https://anyvideo.org/page/1/?s='+d

    fout,sout,npage=ListContent(url,page)
    return fout,sout,npage
    
def ListSearch(url,page):    
    d = gethtml.inputDialog(u'Szukaj...')
    fout=[]
    sout=[]
    npage=[]

    if d:
        d= d.replace(' ','+')
        fout,sout,npage=szukcd(d)

    return fout,sout,npage
