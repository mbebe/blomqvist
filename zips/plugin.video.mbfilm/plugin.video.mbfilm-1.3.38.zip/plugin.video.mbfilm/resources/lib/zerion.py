# -*- coding: UTF-8 -*-
import sys,re,os
import resources.lib.geturl as gethtml
from resources.lib.geturl import PLchar 

import xbmc, xbmcaddon, xbmcvfs
import requests
addon = xbmcaddon.Addon(id='plugin.video.mbfilm')

PATH            = addon.getAddonInfo('path')

if sys.version_info >= (3,0,0):
    DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
else:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')

sess=requests.Session()

if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus
    import urllib.parse as urlparse
    import http.cookiejar as cookielib

else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse
    import cookielib

basurl='https://zerion.cc/seriale'
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0'

COOKIEFILEzerion = os.path.join(DATAPATH,'zerion.cookie')

sess.cookies = cookielib.LWPCookieJar(COOKIEFILEzerion)
cj = sess.cookies

headersc = {
    
        'Referer':basurl,
        'user-agent': UA,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
    }
def pocz(url):
    hh = sess.get(url,headers=headersc,verify=False)
    cj.save(COOKIEFILEzerion, ignore_discard = True)
    
def ListContent(url,page):

    if '?page=' in url:
        nturl = re.sub('\?page=\\d+','?page=%d'%(int(page)+1),url)
        url = re.sub('\?page=\\d+','?page=%d'%int(page),url)
    else:
        nturl = url + '?page=%d' %(int(page)+1)
        url = url + '?page=%d' %int(page)
    
    #nturl = re.sub('\/page\d+','=%d'%(int(page)+1),url)
    #url = re.sub('=\d+','=%d'%int(page),url)

    html,kuks = gethtml.getRequests(url,headers=headersc)
    npage=[]
    fout=[]
    sout=[]
    if html.find(nturl)>-1:
        npage.append({'title':'Następna strona','url':nturl,'image':'','plot':'','page':int(page)+1})
    result = parseDOM(html,'ul', attrs={'id': "list"})[0]
    links = parseDOM(result,'li')#, attrs={'id': "list"})  #<ul id="list">
            
    for link in links:        

        href = parseDOM(link, 'a', ret='href')[0]
        tyt  = parseDOM(link,'h2')[0]#, attrs={'class': "entry-title"})[0] 
        #tyt  = parseDOM(tt, 'a')[0]
        imag = parseDOM(link, 'img', ret='src')[0]
        imag = 'https://zerion.cc'+imag if imag.startswith('/') else imag
        
        opis = parseDOM(link, 'p')#0]
        opis = opis[0] if opis else ''
        sout.append({'title':PLchar(tyt),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':'','code':'','genre':'', 'duration':'', 'mode2':'dudaplayer'})

            
    return fout,sout,npage

def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out    
    
def getSerial(url):

    html,kuks = gethtml.getRequests(url)

    sezony = parseDOM(html,'div', attrs={'class': "season"}) 
    inf = parseDOM(html,'div', attrs={'class': "info"})[0] 
    tytul = parseDOM(inf, 'h2')[0] 
    opis = parseDOM(inf, 'p')
    opis = opis[0] if opis else ''
    year=''
    kateg =''
    grs = parseDOM(inf,'div', attrs={'class': "genres"})[0] 
    #if metad:
    genre = re.findall('">([^>]+)<',grs)
    kateg = ','.join([(x.strip()).lower() for x in genre]) if genre else ''
    data = parseDOM(inf,'div', attrs={'class': "date"})[0]      
    year = parseDOM(data,'span')
    year = year[0] if year else ''
    episodes=[]
    for sezy in sezony:
        eps = parseDOM(sezy,'li')
        for ep in eps:
            tyt2 = parseDOM(ep, 'h4')[0] 
            href = parseDOM(ep, 'a', ret='href')[0] 
            nzw = parseDOM(ep, 'img', ret='alt')[0] 
            ses,epis = re.findall('s(\d+)e(\d+)',nzw)[0]
            rys = parseDOM(ep, 'img', ret='src')[0]  
            rys = 'https://zerion.cc'+rys if rys.startswith('/') else rys
            tyt1 = 'S%02dE%02d'%(int(ses),int(epis))
            tyt2 = re.sub('(s\d+e\d+)','',tyt2)
            tyt = '%s - (%s) %s'%(tytul,tyt1,tyt2)
            episodes.append({'title':PLchar(tyt),'url':PLchar(href),'image':PLchar(rys),'plot':PLchar(opis),'genre':PLchar(kateg),'season':int(ses),'episode':int(epis)})
            
    seasons = splitToSeasons(episodes)
    return seasons
    
def getVideo(url):

    parsed_url = urlparse.urlparse(url)
    pth = parsed_url.path


    pocz(url)
    out=[]
    cj.load(COOKIEFILEzerion)
    
    html,kuks = gethtml.getRequests4(url,headers=headersc, cookies=cj)
    csrf = re.findall('var _csrf\s*=\s*"(.+?)"',html,re.DOTALL)[0]

    vidlist = parseDOM(html,'div', attrs={'class': "video-list"})[0]
    ff = re.findall('type"\s*data\-key="(.+?)"',vidlist,re.DOTALL)
    for f in ff:
        srcs = re.findall('table data-key="%s"(.*?)<\/table>'%(f),vidlist,re.DOTALL)[0]

        tbody = parseDOM(srcs,'tbody')[0]
        opis = re.findall('<td>([^>]+)<',tbody,re.DOTALL)
        host = '|'.join([(x.strip()).lower() for x in opis]) if opis else ''
        href = re.findall('data-id="(.+?)"',tbody,re.DOTALL)[0]

        out.append({'href':href,'host':host})
    stream_url=''
    if out:
        if len(out) > 1:
            u = [ x.get('href') for x in  out]
            h = [ x.get('host') for x in  out]
            sel = gethtml.selectDialog("Źródło", h)
            id = out[sel].get('href') if sel>-1 else ''
            host= out[sel].get('host') if sel>-1 else ''
        else:
            id = out[0].get('href')
        kk=re.findall('_csrf=(.+?);',kuks,re.DOTALL)[0]
        
        headers = {
            'Host': 'zerion.cc',
            'user-agent': UA,
            'accept': '*/*',
            'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
            'referer': url,
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://zerion.cc',
            'dnt': '1',
            'te': 'trailers',}

        data={'_csrf':csrf,'lang':'PL','path':pth}
        response,kk1 = gethtml.getRequests4('https://zerion.cc/api/ping', headers=headers, cookies=cj, data=data)
        

        response,kk1 = gethtml.getRequests4('https://zerion.cc/api/ping', headers=headers, cookies=cj, data=data)

        data = {
        '_csrf': csrf,
        'id': id
        }

        html,kuks = gethtml.getRequests4('https://zerion.cc/api/series/get-embed',headers=headers,data = data, cookies=cj)

        stream_url = re.findall('"url":"(.+?)"',html,re.DOTALL)
        stream_url    = stream_url[0] if stream_url else ''

    return stream_url,True
        

        
def ListContentSearch(url):
    html,kuks = gethtml.getRequests4(url,headers=headersc, cookies=cj)
    npage=[]
    fout=[]
    sout=[]
    result = parseDOM(html,'ul', attrs={'id': "list"})[0]  
    links = parseDOM(result,'li') 

    for link in links:
        href = parseDOM(link, 'a', ret='href')#[0]
        if href:
            href = href[0]
            imag = parseDOM(link, 'img', ret='src')[0]

            imag = 'https://zerion.cc'+imag if imag.startswith('/') else imag
            tytul = parseDOM(link, 'h2')[0]

            tyt =''
            year =''
            opis =''
            jak =''
            kateg =''
            trwa =''

            sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'code':PLchar(jak),'genre':PLchar(kateg), 'duration':trwa, 'mode2':'dudaplayer'})
    return fout,sout,npage
        
def szukcd(d):
    page=1
    fout=[]
    sout=[]
    url='https://zerion.cc/szukaj?query='+d

    fout,sout,npage=ListContentSearch(url)
    return fout,sout,npage
    
def ListSearch(url,page):    
    d = gethtml.inputDialog(u'Szukaj...')
    fout=[]
    sout=[]
    npage=[]

    if d:
        d= d.replace(' ','+')
        fout,sout,npage=szukcd(d)

    return fout,sout,npage
