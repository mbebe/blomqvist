# -*- coding: UTF-8 -*-
import sys,re,os
import resources.lib.geturl as gethtml
from resources.lib.geturl import PLchar 

import xbmc, xbmcaddon, xbmcvfs
import requests
addon = xbmcaddon.Addon(id='plugin.video.mbfilm')

PATH            = addon.getAddonInfo('path')

if sys.version_info >= (3,0,0):
    DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
else:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')



if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus
    import urllib.parse as urlparse
    import http.cookiejar as cookielib

else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse
    import cookielib

basurl='https://serialx.tk/'
lchost = 'serialx.tk'
api_key = gethtml.get_setting('apikey')
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0'



headersc = {
    
        'Referer':basurl,
        'user-agent': UA,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',}
    
headersok = {
    'Host': 'serialx.tk',
    'user-agent': UA,
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
    'referer': basurl,
    'te': 'trailers',}


    
def pocz():

    html,kuks = gethtml.getRequests(basurl,headers=headersc)
    src=re.findall('script src="(.+?)"',html,re.DOTALL)[0]
    src = basurl+src if src.startswith('/') else src
    html,kuks = gethtml.getRequests(src,headers=headersc)
    apikey = re.findall('apiKey:"(.+?)"',html,re.DOTALL)
    apikey = apikey[0] if apikey else ''

    gethtml.set_setting('apikey',apikey)
    return

def ListContent(categ,page):
    fout=[]
    sout=[]
    npage=[]
    if 'search=' in categ: 
        url = 'https://serialx.tk/api.php?type=tv&%s&api_key=%s&language=pl&page=%s'%(categ,api_key,str(page))
    else:
    
        url = 'https://serialx.tk/api.php?type=tv&category=%s&api_key=%s&language=pl&page=%s'%(categ,api_key,str(page))

    html,kuks = gethtml.getRequestsJson(url,data={},headers=headersok)
    maindata = html.get('data',None)
    links = maindata.get('data',None)
    if maindata.get('next_page_url',None):
        npage.append({'title':'Następna strona','url':categ,'image':'','plot':'','page':int(page)+1})

    
    for link in links:
        tyt = link.get('title',None)
        imag = link.get('poster_path',None)
        imag = imag if imag else ''
        imag = 'https://image.tmdb.org/t/p/w500'+imag if imag.startswith('/') else imag
        href = str(link.get('id',None))
        year = link.get('year',None)
        year = year if year else ''
        opis = tyt
        sout.append({'title':PLchar(tyt),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'code':'','genre':'', 'duration':'', 'mode2':'dudaplayer'})
       
    return fout,sout,npage

def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out    
    
def getSerial(id):
    episodes=[]
    url ='https://serialx.tk/api.php?type=tv&show=%s?api_key=%s&language=pl'%(id,api_key)
    
    html,kuks = gethtml.getRequestsJson(url,data={},headers=headersok)

    maindata = html.get('data',None)
    tytul = maindata.get('title',None)
    rys = maindata.get('poster_path',None)
    rys = rys if rys else ''
    rys = 'https://image.tmdb.org/t/p/w500'+rys if rys.startswith('/') else rys
    opis = maindata.get('overview',None)
    opis = opis if opis else ''
    
    eps = maindata.get('episodes',None)
    for ep in eps:
        href = str(ep.get('id',None))
        ses = ep.get('season',None)
        epis = ep.get('number',None)

        tyt1 = 'S%02dE%02d'%(int(ses),int(epis))

        tyt = '%s - (%s)'%(tytul,tyt1)
        episodes.append({'title':PLchar(tyt),'url':PLchar(href),'image':PLchar(rys),'plot':PLchar(opis),'genre':'','season':int(ses),'episode':int(epis)})
    
    seasons = splitToSeasons(episodes)
    return seasons
    
def getVideo(id):
    out = []

    url = 'https://serialx.tk/api.php?type=tv&sources=%s'%(id)
    html,kuks = gethtml.getRequestsJson(url,data={},headers=headersok)

    a=''
    for f in html.get('data',None):
        href = f.get('link',None)
        tp = f.get('type',None)
        tp = tp if tp else ''
        hst = f.get('hosting',None)
        hst = hst if hst else ''
        host = tp + ' - [B]'+hst+'[/B]'
        out.append({'href':href,'host':host})

    stream_url=''
    if out:
        if len(out) > 1:
            u = [ x.get('href') for x in  out]
            h = [ x.get('host') for x in  out]
            sel = gethtml.selectDialog("Źródło", h)
            stream_url = out[sel].get('href') if sel>-1 else ''
            host= out[sel].get('host') if sel>-1 else ''
        else:
            stream_url = out[0].get('href')

    return stream_url,True
        

        
def ListContentSearch(url):
    html,kuks = gethtml.getRequests4(url,headers=headersc, cookies=cj)
    npage=[]
    fout=[]
    sout=[]
    result = parseDOM(html,'ul', attrs={'id': "list"})[0]  
    links = parseDOM(result,'li') 

    for link in links:
        href = parseDOM(link, 'a', ret='href')#[0]
        if href:
            href = href[0]
            imag = parseDOM(link, 'img', ret='src')[0]

            imag = 'https://zerion.cc'+imag if imag.startswith('/') else imag
            tytul = parseDOM(link, 'h2')[0]

            tyt =''
            year =''
            opis =''
            jak =''
            kateg =''
            trwa =''

            sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'code':PLchar(jak),'genre':PLchar(kateg), 'duration':trwa, 'mode2':'dudaplayer'})
    return fout,sout,npage
        
def szukcd(d):
    page=1
    fout=[]
    sout=[]
    
    fout,sout,npage=ListContent(d,page)
    return fout,sout,npage
    
def ListSearch(url,page):    
    d = gethtml.inputDialog(u'Szukaj...')
    fout=[]
    sout=[]
    npage=[]
    
    if d:
        d= d.replace(' ','+')
        d = 'search='+d
        fout,sout,npage=szukcd(d)
    
    return fout,sout,npage
