# -*- coding: UTF-8 -*-
import sys,re,os
import geturl as gethtml
from geturl import PLchar as PLchar
import urllib
from cmf2 import parseDOM
from cmf2 import replaceHTMLCodes

basurl='https://filmninja.ws/'
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'

def ListContent(url,page):
	if '?page=' in url:
		url = re.sub(r'\?page=\d+', '?page=%d'%int(page),   url)  
	else:
		url = url + '?page=%d' %int(page)
	html,kuks = gethtml.getRequests(url)
	npage=[]
	fout=[]
	sout=[]
	
	try:
		if html.find( 'paginator__item--next')>-1: 
			nturl  = re.sub(r'\?page=\d+', '?page=%d'%(int(page)+1),   url) 
			npage.append({'title':'[COLOR violet]Następna strona[/COLOR]','url':nturl,'image':'','plot':'','page':int(page)+1})
	except:
		pass
	
	result = parseDOM(html,'div', attrs={'class': "catalog"})
	result =result[0] if result else html
	links = parseDOM(result,'div', attrs={'class': "col-\d+ col-sm-\d+ col-lg-\d+"}) #<div class="col-6 col-sm-12 col-lg-6">col-\d+ col-sm-\d+ col-lg-\d+
	
	for link in links:
		cardtit = parseDOM(link,'h3', attrs={'class': "card__title"})[0]#<h3 class="card__title">
		href = parseDOM(cardtit, 'a', ret='href')[0]
		tytul = parseDOM(cardtit, 'a')[0]
		imag = parseDOM(link, 'img', ret='src')[0]
		opis = parseDOM(link,'p')
		opis = opis[0] if opis else tytul
		yearcard = parseDOM(link,'span', attrs={'class': "card__category"})[0]
		year = parseDOM(yearcard, 'a')
		year = year[0] if year else ''

		if '/film/' in 	href:
			fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year})	
		else:
			sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year})

	return fout,sout,npage

def SelectList(typ):
	if 'gatunek' in typ:
	
		label =["Akcja","Akcja i Przygoda","Animacja","Dokumentalny","Dramat","Familijny","Fantasy","film TV","Historyczny","Horror","Komedia","Kryminał","Muzyczny","Przygodowy","Romans","Sci-Fi","Sci-Fi &amp; Fantasy","Tajemnica","Thriller","Western","Wojenny"]
		value =["https://watch-movies.pl/genre/akcja/page/1","https://watch-movies.pl/genre/akcja-i-przygoda/page/1","https://watch-movies.pl/genre/animacja/page/1","https://watch-movies.pl/genre/dokumentalny/page/1","https://watch-movies.pl/genre/dramat/page/1","https://watch-movies.pl/genre/familijny/page/1","https://watch-movies.pl/genre/fantasy/page/1","https://watch-movies.pl/genre/film-tv/page/1","https://watch-movies.pl/genre/historyczny/page/1","https://watch-movies.pl/genre/horror/page/1","https://watch-movies.pl/genre/komedia/page/1","https://watch-movies.pl/genre/kryminal/page/1","https://watch-movies.pl/genre/muzyczny/page/1","https://watch-movies.pl/genre/przygodowy/page/1","https://watch-movies.pl/genre/romans/page/1","https://watch-movies.pl/genre/sci-fi/page/1","https://watch-movies.pl/genre/sci-fi-fantasy/page/1","https://watch-movies.pl/genre/tajemnica/page/1","https://watch-movies.pl/genre/thriller/page/1","https://watch-movies.pl/genre/western/page/1","https://watch-movies.pl/genre/wojenny/page/1"]
		nazwa = "Wybierz gatunek"
		
	elif 'rok' in typ:
		label =["2020","2019","2018","2017","2016","2015","2014","2013","2012","2011","2010","2009","2008","2007","2006","2005","2004","2003","2002","2001","2000","1999","1998","1997","1996","1995","1994","1993","1992","1991","1990","1989","1988","1987","1985","1984","1983","1982","1981","1980","1979","1978","1977","1976","1975","1974","1973","1971","1969","1967"]
		value =["https://watch-movies.pl/release/2020/page/1","https://watch-movies.pl/release/2019/page/1","https://watch-movies.pl/release/2018/page/1","https://watch-movies.pl/release/2017/page/1","https://watch-movies.pl/release/2016/page/1","https://watch-movies.pl/release/2015/page/1","https://watch-movies.pl/release/2014/page/1","https://watch-movies.pl/release/2013/page/1","https://watch-movies.pl/release/2012/page/1","https://watch-movies.pl/release/2011/page/1","https://watch-movies.pl/release/2010/page/1","https://watch-movies.pl/release/2009/page/1","https://watch-movies.pl/release/2008/page/1","https://watch-movies.pl/release/2007/page/1","https://watch-movies.pl/release/2006/page/1","https://watch-movies.pl/release/2005/page/1","https://watch-movies.pl/release/2004/page/1","https://watch-movies.pl/release/2003/page/1","https://watch-movies.pl/release/2002/page/1","https://watch-movies.pl/release/2001/page/1","https://watch-movies.pl/release/2000/page/1","https://watch-movies.pl/release/1999/page/1","https://watch-movies.pl/release/1998/page/1","https://watch-movies.pl/release/1997/page/1","https://watch-movies.pl/release/1996/page/1","https://watch-movies.pl/release/1995/page/1","https://watch-movies.pl/release/1994/page/1","https://watch-movies.pl/release/1993/page/1","https://watch-movies.pl/release/1992/page/1","https://watch-movies.pl/release/1991/page/1","https://watch-movies.pl/release/1990/page/1","https://watch-movies.pl/release/1989/page/1","https://watch-movies.pl/release/1988/page/1","https://watch-movies.pl/release/1987/page/1","https://watch-movies.pl/release/1985/page/1","https://watch-movies.pl/release/1984/page/1","https://watch-movies.pl/release/1983/page/1","https://watch-movies.pl/release/1982/page/1","https://watch-movies.pl/release/1981/page/1","https://watch-movies.pl/release/1980/page/1","https://watch-movies.pl/release/1979/page/1","https://watch-movies.pl/release/1978/page/1","https://watch-movies.pl/release/1977/page/1","https://watch-movies.pl/release/1976/page/1","https://watch-movies.pl/release/1975/page/1","https://watch-movies.pl/release/1974/page/1","https://watch-movies.pl/release/1973/page/1","https://watch-movies.pl/release/1971/page/1","https://watch-movies.pl/release/1969/page/1","https://watch-movies.pl/release/1967/page/1"]
		nazwa = "Wybierz rok"

	sel = gethtml.selectDialog(nazwa, label)
	kategoria = value[sel] if sel>-1 else ''
	return kategoria

def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
def getSerial(url):

	html,kuks = gethtml.getRequests(url)
	
	result = parseDOM(html,'div', attrs={'class': "season-box"})#[0]
	result = result[0] if result else html
	sezony = re.findall('class="season">(.+?)<\/ul>',result,re.DOTALL+re.IGNORECASE)
	
	tytul = parseDOM(html,'h1')[0]
	opis = parseDOM(html,'td', attrs={'class': "table-desc"})#<td class="table-desc">
	opis = opis[0] if opis else ''
	pict = parseDOM(html,'div', attrs={'class': "card__cover.+?"})[0]# div class="card__cover arisa-series">
	rys = parseDOM(pict, 'img', ret='src')[0] 

	episodes=[]
	for sezon in sezony:

		ses = re.findall('sezon\s*(\d+)',sezon,re.IGNORECASE)
		ses = ses[0] if ses else '0'
		eps = parseDOM(sezon,'li', attrs={'class': "episode"})
		for ep in eps:
			tyt2 = parseDOM(ep, 'a')[0] 
			href = parseDOM(ep, 'a', ret='href')[0]  
			epis = re.findall('odcinek\s*(\d+)',ep,re.IGNORECASE) 
			tyt1 = 'S%02dE%02d'%(int(ses),int(epis[0]))
			tyt = '%s - (%s) %s'%(tytul,tyt1,tyt2)
			episodes.append({'title':PLchar(tyt),'url':PLchar(href),'image':rys,'plot':PLchar(opis),'season':int(ses),'episode':int(epis[0])})
			
	seasons = splitToSeasons(episodes)
	return seasons

def getPlaytube(stream_url,nturl):
	headers = {
		'User-Agent': UA,
		'Accept': '*/*',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Connection': 'keep-alive',
		'Referer': nturl}

	sources = re.findall('sources:\s*\[(.+?)\]',html)
	if sources:
		str_url=re.findall('"(.+?)"',sources[0])[0]
		str_url += '|User-Agent='+urllib.quote(UA)+'&Referer='+stream_url+'&Cookie='+urllib.quote(kuks)
	return str_url

def PlayTv(url):
	
	html,kuks = gethtml.getRequests(url)
	str_url=re.findall('"file": "([^"]+)"',html)
	str_url=str_url[0]
	str_url+= '|User-Agent='+urllib.quote(UA)+'&Referer='+url+'&Cookie='+urllib.quote(kuks)
	return str_url,False
	
def getTV(url):
	out=[]
	
	html,kuks = gethtml.getRequests(url)
	links = parseDOM(html,'div', attrs={'class': "card tv-channels"})#<div class="card tv-channels">
	for link in links:
		tytul  = parseDOM(link, 'img', ret='alt')[0]
		imag  = parseDOM(link, 'img', ret='src')[0]
		href = parseDOM(link, 'a', ret='href')[0]
		out.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag)})#,'plot':PLchar(opis),'year':year})
	return out
def getVideo(url):
	out=[]
	html,kuks = gethtml.getRequests(url)
	stream_url=''
	
	links = parseDOM(html,'td', attrs={'class': "link-to-video"})
	for link in links:
		nturl = parseDOM(link, 'a', ret='href')#[0]
		
		if nturl and not 'premium' in link.lower():
			nturl = nturl[0]
			break
	headers = {
		'User-Agent': UA,
		'Accept': '*/*',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Connection': 'keep-alive',
		'Referer': url}
		
	
	html,kuks = gethtml.getRequests(nturl,headers=headers)
	stream_url = parseDOM(html, 'iframe', ret='src')
	stream_url = stream_url[0] if stream_url else ''
	if 'playtube' in stream_url:
		stream_url = getPlaytube(stream_url,nturl)
		return stream_url,False
	else:
		return stream_url,True

def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]

	if d:
		url=basurl+'wyszukiwarka?phrase='+d
		html,kuks = gethtml.getRequests(url)
		
		result = parseDOM(html,'div', attrs={'class': "catalog"})[0]
		links = parseDOM(result,'div', attrs={'class': "card"})
		for link in links:
			cardtit = parseDOM(link,'h3', attrs={'class': "card__title"})[0]
			href = parseDOM(cardtit, 'a', ret='href')[0]
			tytul = parseDOM(cardtit, 'a')[0]
			imag = parseDOM(link, 'img', ret='src')[0]
			opis = parseDOM(link,'p')
			opis = opis[0] if opis else tytul
			yearcard = parseDOM(link,'span', attrs={'class': "card__category"})[0]
			year = parseDOM(yearcard, 'a')
			year = year[0] if year else ''
	
			if '/film/' in 	href:
				fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year})	
			else:
				sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year})

	return fout,sout,npage

