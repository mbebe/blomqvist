# -*- coding: UTF-8 -*-
import sys,re,os
import geturl as gethtml
from geturl import PLchar as PLchar

import requests
from cmf2 import parseDOM
from cmf2 import replaceHTMLCodes

basurl='http://z-net.live/index.php/'
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'

def getFilmy(url,page):
	url=basurl+'filmy/'
	html,kuks = gethtml.getRequests(url)
	out=[]
	links = parseDOM(html,'div', attrs={'class': "post\-.+?"})
	npage=[]
	for link in links:
		href = parseDOM(link, 'a', ret='href')[0] 
		imag = parseDOM(link, 'img', ret='src')[0]
		tytul = parseDOM(link,'h3')[0]
		year = re.findall('release-year">(.+?)<',link)
		year = year[0] if year else ''
		genre = re.findall('rel="tag">([^>]+)<',link)
		kateg = ','.join([(x.strip()).lower() for x in genre]) if genre else ''
		opis = '%s[CR]%s,%s'%(tytul, year, kateg)
		out.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'genre':PLchar(kateg)})
	return out,npage

def ListSeriale(url,page):
	url=basurl+'seriale/'
	html,kuks = gethtml.getRequests(url)
	out=[]
	links = parseDOM(html,'div', attrs={'class': "tv-show post\-.+?"})
	npage=[]
	for link in links:
		href = parseDOM(link, 'a', ret='href')[0] 
		imag = parseDOM(link, 'img', ret='src')[0]
		tytul = parseDOM(link,'h3')[0]
		out.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(tytul)})
	return out,npage
	
def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
def getSerial(url):
	html,kuks = gethtml.getRequests(url)
	links = parseDOM(html,'div', attrs={'id': "tab\-.+?"})
	episodes=[]
	tytul = parseDOM(html,'h1')[0]#

	for link in links:
		ses = re.findall('number">S(\d+)E.+?<',link)
		if not ses:
			ses = re.findall('number">sezon\s*(\d+)<',link,re.IGNORECASE)
		if ses:
			eps = parseDOM(link,'div', attrs={'class': "post\-.+?"})
			for ep in eps:
				tyt1 = re.findall('number">(.+?)<',ep)[0]
				href = parseDOM(ep, 'a', ret='href')[0] 
				rys = parseDOM(ep, 'img', ret='src')[0] 
				epis = re.findall('S\d+E(\d+)',tyt1)
				if not epis:
					epis = re.findall('odcinek\s*(\d+)',tyt1,re.IGNORECASE)#[0]
				tyt2 = parseDOM(ep,'h3')[0]
				tyt = '%s - (%s) %s'%(tytul,tyt1,tyt2)
				episodes.append({'title':PLchar(tyt),'url':PLchar(href),'image':rys,'season':int(ses[0]),'episode':int(epis[0])})
	seasons = splitToSeasons(episodes)
	return seasons

def getVideo(url):
	html,kuks = gethtml.getRequests(url)
	player = parseDOM(html,'div', attrs={'class': ".+?__player"})[0]
	src = parseDOM(player, 'a', ret='href')[0] 
	return src+'|User-Agent='+UA, False
	
#def PLchar(char):
#	if type(char) is not str:
#		char=char.encode('utf-8')
#	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
#	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
#	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
#	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
#	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
#	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
#	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
#	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
#	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
#	char = char.replace('&#8217;',"'")
#	char = char.replace('&#8211;',"-")	
#	char = char.replace('&#8230;',"...")	
#	char = char.replace('&#8222;','"').replace('&#8221;','"')	
#	char = char.replace('[&hellip;]',"...")
#	char = char.replace('&#038;',"&")	
#	char = char.replace('&#039;',"'")
#	char = char.replace('&quot;','"').replace('&oacute;','ó').replace('&rsquo;',"'")
#	char = char.replace('&nbsp;',".").replace('&amp;','&').replace('&eacute;','e')
#	return char	
#