# -*- coding: UTF-8 -*-
import sys,re,os
import requests
from cloudscraper import cloudscraper

import cfscr
_cfscrape = cfscr.create_scraper()
PY3 = sys.version_info >= (3,0,0)
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'
_cfscrapex = cloudscraper.create_scraper(interpreter='native', browser={'custom': UA})


TIMEOUT=15
sess  = requests.Session()
headers = {
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'DNT': '1',
    'Upgrade-Insecure-Requests': '1',}
	
def getRequestsccc(url,data={},ref=None):
	kukz =  addon.getSetting('cfCookies')
	#UA=addon.getSetting('uaCF')
	if os.path.isfile(COOKIEFILE):
		scraper.cookies.load()	
	
	#web_pdb.set_trace()
	
	content = scraper.get(url).content
	
	
	
	
	
	headers = {
		'User-Agent': UA,
		'Accept': 'text/html, */*; q=0.01',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Cookie':kukz,
		'Connection': 'keep-alive',}
	if data:
		headers = {
			'User-Agent': UA,
			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
			'Referer': 'https://www.filmy321.pl/',
			'Content-Type': 'application/x-www-form-urlencoded',
			'Connection': 'keep-alive',
			'Upgrade-Insecure-Requests': '1',
			'TE': 'Trailers',}

		content=requests.post(url,headers=headers,data=data,verify=False).content
	else:
		if ref:
			ab=requests.get(ref,headers=headers)
			headersx = {
				'User-Agent': UA,
				'Accept': 'text/html, */*; q=0.01',
				'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
				'Referer': ref,
				'X-Requested-With': 'XMLHttpRequest',
				'Connection': 'keep-alive',
				'TE': 'Trailers',
			}
			headers=headersx
		
		content=requests.get(url,headers=headers).content
	return content
	
	
def getRequests(url,data={}):
	if not data:
		resp = sess.get(url, headers = headers, verify=False)
		kuks =''.join(['%s=%s;'%(c.name, c.value) for c in sess.cookies])
		if resp.status_code == 503:
			resp = _cfscrape.get(url, headers = headers)
			kuks =''.join(['%s=%s;'%(c.name, c.value) for c in _cfscrape.cookies])
		html = resp.content
		html = html.replace("\'",'"')
	else:
		resp = sess.post(url, headers = headers, data=data,verify=False)
		kuks =''.join(['%s=%s;'%(c.name, c.value) for c in sess.cookies])
		if resp.status_code == 503:
			resp = _cfscrape.post(url, headers = headers, data=data)
			kuks =''.join(['%s=%s;'%(c.name, c.value) for c in _cfscrape.cookies])
		html = resp.content
		html = html.replace("\'",'"')
	if PY3:
		html = html.decode(encoding='utf-8', errors='strict')
		html = html.replace("\'",'"')
	return html,kuks
