# -*- coding: UTF-8 -*-
import sys,re,os

import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc

PY3 = sys.version_info >= (3,0,0)

try:
    # For Python 3.0 and later
	from urllib.parse import parse_qsl, quote, urlencode

except ImportError:
    # Python 2
    from urlparse import parse_qsl
    from urllib import unquote, quote, urlencode

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.mbfilm')

xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LASTPLAYED, label2Mask = "%R, %P, %Y")

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile'))

if isinstance(DATAPATH, bytes):
    DATAPATH = DATAPATH.decode('utf-8')
if isinstance(PATH, bytes):
    PATH = PATH.decode('utf-8')
    
RESOURCES       = PATH+'/resources/'

FANART=RESOURCES+'../fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('name', None)
page = params.get('page','')
mcount= params.get('moviescount', None)
movie= params.get('movie', None)
rys= params.get('image', None)
try:
	opisb = eval(params.get('opisb', None))
except:
	opisb = params.get('opisb', None)
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'

def build_url(query):
    return base_url + '?' + urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=1,fanart=FANART,moviescount=0):
	list_item = xbmcgui.ListItem(label=name)

	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')
	#else:
	#	list_item.setProperty("IsPlayable", 'False')
	if not infoLabels:
		infoLabels={'title': name,'plot':name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': FANART})
	ok=xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page, 'moviescount' : moviescount,'movie':movie,'name':name,'image':image,'opisb':infoLabels}),			
		listitem=list_item,
		isFolder=folder)
	return ok

def home():
	#add_item('film', '[B][COLOR khaki]Przeszukaj wszystko[/COLOR][/B]', 'DefaultMovies.png', "szukajwszystko", folder=True,fanart=RESOURCES+'fanart.png')



	#add_item('film', '[B][COLOR khaki]cda-filmy.online[/COLOR][/B]', 'DefaultMovies.png', "menu:cdaonline", folder=True,fanart=RESOURCES+'fanart.png')

#	add_item('film', '[B][COLOR khaki]livenet.online[/COLOR][/B]', 'DefaultMovies.png', "menu:livenet", folder=True,fanart=RESOURCES+'fanart.png')
#	add_item('film', '[B][COLOR khaki]ekino.pw[/COLOR][/B]', 'DefaultMovies.png', "menu:ekinopw", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film', '[B][COLOR khaki]vizjer.pl[/COLOR][/B]', 'DefaultMovies.png', "menu:vizjerpl", folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('film', '[B][COLOR khaki]cda-filmy.online[/COLOR][/B]', 'DefaultMovies.png', "menu:cdaonline", folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('film', '[B][COLOR khaki]rodzinnekino.com[/COLOR][/B]', 'DefaultMovies.png', "menu:rodzinne", folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('film', '[B][COLOR khaki]film.web4u2.pl[/COLOR][/B]', 'DefaultMovies.png', "menu:filmweb4u2", folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('film', '[B][COLOR khaki]watch-movies.pl[/COLOR][/B]', 'DefaultMovies.png', "menu:watchmovies", folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('film', '[B][COLOR khaki]z-net.live[/COLOR][/B]', 'DefaultMovies.png', "menu:znetlive", folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('film', '[B][COLOR khaki]filmeria.co[/COLOR][/B]', 'DefaultMovies.png', "menu:filmeriaco", folder=True,fanart=RESOURCES+'fanart.png')	
	add_item('film', '[B][COLOR khaki]mojseansik.pl (filmninja.ws)[/COLOR][/B]', 'DefaultMovies.png', "menu:seansik", folder=True,fanart=RESOURCES+'fanart.png')	

	
	#add_item('film', '[B][COLOR khaki]filmninja.ws[/COLOR][/B]', 'DefaultMovies.png', "menu:filmninja", folder=True,fanart=RESOURCES+'fanart.png')	
	add_item('film', '[B][COLOR khaki]zalukaj.vip[/COLOR][/B]', 'DefaultMovies.png', "menu:zalukajvip", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film', '[B][COLOR khaki]wideo.site[/COLOR][/B]', 'DefaultMovies.png', "menu:wideosite", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film', '[B][COLOR khaki]ogladaj.to[/COLOR][/B]', 'DefaultMovies.png', "menu:ogladajto", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film', '[B][COLOR khaki]dudeplayer.com[/COLOR][/B]', 'DefaultMovies.png', "menu:dudeplayer", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film', '[B][COLOR khaki]filmynadzis.pl[/COLOR][/B]', 'DefaultMovies.png', "menu:nadzis", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film', '[B][COLOR khaki]zaluknij.xyz[/COLOR][/B]', 'DefaultMovies.png', "menu:zaluknij", folder=True,fanart=RESOURCES+'fanart.png')
def splitToSeasons(input):
    out={}
    seasons = [x.get('season') for x in input]
    for s in set(seasons):
        out['Sezon %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
    return out	

def getEpisodes(seasons,mode2):
	episodes = eval(unquote(seasons))#[::-1]
	items=len(episodes)
	for f in episodes: 
		ses=f.get('season')
		epp=f.get('episode')
		tyt=f.get('title').split('Season')#[0]
		tyt2 = '%s - odc.%02d'%(name,epp)
		tyt = tyt[0] if tyt else tyt2
		add_item(name=tyt, url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot')}, itemcount=items)
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)	
	
def PlayVid(stream_url,adaptive=False):

	play_item = xbmcgui.ListItem(path=stream_url)
	try:
		play_item.setInfo(type="Video", infoLabels={"title": name,'plot':opisb['plot']})
		
		play_item.setArt({'thumb': rys, 'poster': rys, 'banner': rys, 'fanart': FANART})
	except:
		pass
	play_item.setProperty("IsPlayable", "true")
	if adaptive:
		play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
		play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
		play_item.setMimeType('application/vnd.apple.mpegurl')
		play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
		#play_item.setContentLookup(False)
	
	Player = xbmc.Player()
	Player.play(stream_url, play_item)

def import_mod(s):
	mod = {}
	if   s == 'livenet': import livenet     as mod
	elif s == 'ekinopw': import ekinopw     as mod
	elif s == 'vizjerpl': import vizjerpl    as mod
	elif s == 'cdaonline': import cdaonline   as mod
	elif s == 'rodzinne': import rodzinne    as mod
	elif s == 'watchmovies': import watchmovies as mod
	elif s == 'filmweb4u2': import filmweb4u2  as mod
	elif s == 'znetlive': import znetlive    as mod
	elif s == 'filmeriaco': import filmeriaco  as mod
	elif s == 'filmninja': import filmninja  as mod
	elif s == 'seansik': import seansik  as mod
	
	elif s == 'zalukajvip': import zalukajvip  as mod
	elif s == 'wideosite': import wideosite  as mod
	elif s == 'ogladajto': import ogladajto  as mod
	elif s == 'dudeplayer': import dudeplayer  as mod
	elif s == 'nadzis': import nadzis  as mod
	elif s == 'zaluknij': import zaluknij  as mod
	
	return mod
def import_menu(s):
	mod = {}
	if   s == 'livenet': import livenet     as mod
	elif s == 'ekinopw': mod = ekinopwMenu(s)
	elif s == 'vizjerpl': mod = vizjerplMenu(s)
	elif s == 'cdaonline': mod = cdaonlineMenu(s)
	elif s == 'rodzinne': mod = rodzinneMenu(s)
	elif s == 'zalukajvip': mod = zalukajvipMenu(s)
	elif s == 'watchmovies': mod = watchmoviesMenu(s)
	elif s == 'filmweb4u2': import filmweb4u2  as mod
	elif s == 'znetlive':   mod = znetliveMenu(s)
	elif s == 'filmeriaco': mod = filmeriacoMenu(s)
	elif s == 'filmninja': mod = filmninjaMenu(s)
	elif s == 'seansik': mod = filmninjaMenu2(s)
	elif s == 'wideosite': mod = wideositeMenu(s)
	elif s == 'ogladajto': mod = ogladajtoMenu(s)
	elif s == 'dudeplayer': mod = dudeplayerMenu(s)
	elif s == 'nadzis': mod = nadzisMenu(s)
	elif s == 'zaluknij': mod = zaluknijMenu(s) #import zaluknij  as mod
	
	return mod
	
def zaluknijMenu(str):
	import kurw
	url = 'https://zaluknij.xyz/'
	hostx = 'zaluknij'
	kurw.bps_dguardx(url,hostx)
	
	add_item('https://zaluknij.xyz/movies/page/1/', '[B][COLOR khaki]Wszystkie filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zaluknij.xyz/|gatunek', '[B][COLOR khaki]-   gatunek[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zaluknij.xyz/|rok', '[B][COLOR khaki]-   rok[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Filmy w wersji PL[/COLOR][/B]', 'DefaultMovies.png', "ListSubMenuZaluknij", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zaluknij.xyz/quality/filmy-w-wersji-eng/page/1/', '[B][COLOR khaki]Filmy w wersji ENG[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultMovies.png', "ListSubMenuZaluknij2", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zaluknij.xyz/rok/2020/page/1/', '[B][COLOR khaki]Nowości (2020)[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	
def zaluknijSubMenu():
	add_item('', '[B][COLOR lightgreen]=#=#= Filmy w wersji PL =#=#=[/COLOR][/B]', 'DefaultMovies.png', " ", folder=False,fanart=RESOURCES+'fanart.png')



	add_item('https://zaluknij.xyz/quality/filmy-w-wersji-pl/page/1/', '[B][COLOR khaki]- wszystkie[/COLOR][/B]', 'DefaultMovies.png', "ListContent:zaluknij", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zaluknij.xyz/quality/Film-Polski/page/1/', '[B][COLOR khaki]- filmy polskie[/COLOR][/B]', 'DefaultMovies.png', "ListContent:zaluknij", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zaluknij.xyz/quality/Dubbing/page/1/', '[B][COLOR khaki]- filmy z dubbingiem[/COLOR][/B]', 'DefaultMovies.png', "ListContent:zaluknij", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zaluknij.xyz/quality/lektor/page/1/', '[B][COLOR khaki]- filmy z lektorem[/COLOR][/B]', 'DefaultMovies.png', "ListContent:zaluknij", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zaluknij.xyz/quality/Napisy-PL/page/1/', '[B][COLOR khaki]- filmy z napisami PL[/COLOR][/B]', 'DefaultMovies.png', "ListContent:zaluknij", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zaluknij.xyz/quality/lektor-ivo/page/1/', '[B][COLOR khaki]- lektor IVO[/COLOR][/B]', 'DefaultMovies.png', "ListContent:zaluknij", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zaluknij.xyz/quality/web-cam-napisy-pl/page/1/', '[B][COLOR khaki]- web cam (napisy PL)[/COLOR][/B]', 'DefaultMovies.png', "ListContent:zaluknij", folder=True,fanart=RESOURCES+'fanart.png')
	xbmcplugin.endOfDirectory(addon_handle)	
def zaluknijSubMenu2():
	add_item('', '[B][COLOR lightgreen]=#=#= Seriale =#=#=[/COLOR][/B]', 'DefaultMovies.png', " ", folder=False,fanart=RESOURCES+'fanart.png')
	add_item('https://zaluknij.xyz/tvshows/page/1/', '[B][COLOR khaki]- wszystkie[/COLOR][/B]', 'DefaultMovies.png', "ListContent:zaluknij", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zaluknij.xyz/seasons/page/1/', '[B][COLOR khaki]- sezony[/COLOR][/B]', 'DefaultMovies.png', "ListContent:zaluknij", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zaluknij.xyz/episodes/page/1/', '[B][COLOR khaki]- odcinki[/COLOR][/B]', 'DefaultMovies.png', "ListContent:zaluknij", folder=True,fanart=RESOURCES+'fanart.png')
	xbmcplugin.endOfDirectory(addon_handle)	

	
def nadzisMenu(str):
	add_item('https://filmynadzis.pl/wszystkie-filmy/page/1/', '[B][COLOR khaki]Filmy (wszystkie)[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filmynadzis.pl/popularne', '[B][COLOR khaki]Filmy (popularne)[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filmynadzis.pl/category/swiat-grozy/page/1/', '[B][COLOR khaki]-   świat grozy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filmynadzis.pl/category/przygoda/page/1/', '[B][COLOR khaki]-   przygoda[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filmynadzis.pl/category/dynamicznie/page/1/', '[B][COLOR khaki]-   dynamicznie[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filmynadzis.pl/category/komediowo/page/1/', '[B][COLOR khaki]-   komediowo[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filmynadzis.pl/category/refleksyjnie/page/1/', '[B][COLOR khaki]-   refleksyjnie[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filmynadzis.pl/category/romantycznie/page/1/', '[B][COLOR khaki]-   romantycznie[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filmynadzis.pl/category/kryminalnie/page/1/', '[B][COLOR khaki]-   kryminalnie[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filmynadzis.pl/category/junior/page/1/', '[B][COLOR khaki]-   junior[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	

def cdaonlineMenu(str):
	add_item('https://cda-filmy.online/filmy-online/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film', '[B][COLOR khaki]-   gatunek[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://cda-filmy.online/seriale-online/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('serial', '[B][COLOR khaki]-   gatunek[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	
def dudeplayerMenu(str):
	add_item('https://dudeplayer.com/movies/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://dudeplayer.com/movies/|movies', '[B][COLOR khaki]Filmy - lista alfabetyczna[/COLOR][/B]', 'DefaultMovies.png', "ListAlfabet2", folder=True,fanart=RESOURCES+'fanart.png')

	#add_item('https://dudeplayer.com/movies/|gatunek', '[B][COLOR khaki]-   gatunek[/COLOR][/B]', 'DefaultMovies.png', "ListGatRok", folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('https://dudeplayer.com/movies/|rok', '[B][COLOR khaki]-   rok produkcji[/COLOR][/B]', 'DefaultMovies.png', "ListGatRok", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://dudeplayer.com/tvshows/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://dudeplayer.com/tvshows/|tvshows', '[B][COLOR khaki]Serial - lista alfabetyczna[/COLOR][/B]', 'DefaultTVShows.png', "ListAlfabet2", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://dudeplayer.com/trending/', '[B][COLOR khaki]Top 10[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

	add_item('https://dudeplayer.com/tvshows/|gatunek', '[B][COLOR khaki]Gatunek[/COLOR][/B]', 'DefaultTVShows.png', "ListGatRok", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://dudeplayer.com/tvshows/|rok', '[B][COLOR khaki]Rok produkcji[/COLOR][/B]', 'DefaultTVShows.png', "ListGatRok", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
		
def ekinopwMenu(str):
	add_item('', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "SimplelistFilmy:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "SimplelistSeriale:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

def filmninjaMenu2(str):	
	import kurw
	url = 'https://mojseansik.pl/'
	hostx = 'seansik'
	kurw.bps_dguardx(url,hostx)
	add_item('https://mojseansik.pl/filmy-online/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "SimplelistFilmy:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
#	add_item('', '[B][COLOR khaki]-   Kategorie[/COLOR][/B]', 'DefaultMovies.png', "listCategoryfilm:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
#	add_item('alfabet', '[B][COLOR khaki]-   Spis alfabetyczny[/COLOR][/B]', 'DefaultMovies.png', "listCategoryfilm:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://mojseansik.pl/seriale-online/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "SimplelistSeriale:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://mojseansik.pl/dla-dzieci/', '[B][COLOR khaki]Dla dzieci[/COLOR][/B]', 'DefaultTVShows.png', "SimplelistFilmy:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('', '[B][COLOR khaki]-   Kategorie[/COLOR][/B]', 'DefaultMovies.png', "listCategoryserial:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
#	add_item('alfabet', '[B][COLOR khaki]-   Spis alfabetyczny[/COLOR][/B]', 'DefaultMovies.png', "listCategoryserial:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	

	
def filmninjaMenu(str):	
	#try:
	#	import kurw
	#	kurw.abc()
	#except:
	#	pass
	import kurw
	kurw.bps_dguard()
	add_item('https://filmninja.ws/filmy-online/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filmninja.ws/seriale-online/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filmninja.ws/dla-dzieci/', '[B][COLOR khaki]Dla dzieci[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filmninja.ws/darmowa-telewizja-online', '[B][COLOR khaki]Telewizja[/COLOR][/B]', 'DefaultTVShows.png', "ListTV", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

def watchmoviesMenu(str):
	add_item('https://watch-movies.pl/?post_type=movies', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://watch-movies.pl/?post_type=tvshows', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('gatunek', '[B][COLOR khaki]-   gatunek[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('rok', '[B][COLOR khaki]-   rok wydania[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

def ogladajtoMenu(str):

	add_item('https://www.ogladaj.to/polecane/', '[B][COLOR khaki]Polecane[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

	add_item('https://www.ogladaj.to/filmy/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://www.ogladaj.to/seriale/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
#	add_item('https://www.ogladaj.to/seriale/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://www.ogladaj.to/gatunek/dla-dzieci/', '[B][COLOR khaki]Dla dzieci[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('kategorie', '[B][COLOR khaki]-   gatunek[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
#	add_item('rok', '[B][COLOR khaki]-   rok wydania[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	


	
def vizjerplMenu(str):
	try:
		import kurw
		url = 'https://vizjer.pl'
		hostx = 'vizjer'
		kurw.bps_dguardx(url,hostx)
	except:
		pass
	add_item('https://vizjer.pl/filmy-online/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "SimplelistFilmy:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
#	add_item('', '[B][COLOR khaki]-   Kategorie[/COLOR][/B]', 'DefaultMovies.png', "listCategoryfilm:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
#	add_item('alfabet', '[B][COLOR khaki]-   Spis alfabetyczny[/COLOR][/B]', 'DefaultMovies.png', "listCategoryfilm:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://vizjer.pl/seriale-online/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "SimplelistSeriale:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://vizjer.pl/dla-dzieci/', '[B][COLOR khaki]Dla dzieci[/COLOR][/B]', 'DefaultTVShows.png', "SimplelistFilmy:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('', '[B][COLOR khaki]-   Kategorie[/COLOR][/B]', 'DefaultMovies.png', "listCategoryserial:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
#	add_item('alfabet', '[B][COLOR khaki]-   Spis alfabetyczny[/COLOR][/B]', 'DefaultMovies.png', "listCategoryserial:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
		
def znetliveMenu(str):
	add_item('', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "SimplelistFilmy:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "SimplelistSeriale:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	
def filmeriacoMenu(str):
	add_item('', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "SimplelistFilmy:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "SimplelistSeriale:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')


def rodzinneMenu(str):
	add_item('https://rodzinnekino.com/film/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://rodzinnekino.com/seriale/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://rodzinnekino.com/kraj/polska/', '[B][COLOR khaki]Polska[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('gatunek', '[B][COLOR khaki]-   gatunek[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('kraj', '[B][COLOR khaki]-   kraj[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('wersja', '[B][COLOR khaki]-   wersja[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('rok', '[B][COLOR khaki]-   rok wydania[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

def zalukajvipMenu(str):
	add_item('https://zalukaj.vip/movies/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('filmy', '[B][COLOR khaki]Szukaj filmów[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('gatunek', '[B][COLOR khaki]-   gatunek[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('rok', '[B][COLOR khaki]-   rok wydania[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zalukaj.vip/serie-filmowe/', '[B][COLOR khaki]Serie filmowe[/COLOR][/B]', 'DefaultMovies.png', "ListSerieF1", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zalukaj.vip/tv-shows-2/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('seriale', '[B][COLOR khaki]Szukaj seriali[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	
def wideositeMenu(str):
	add_item('Premiery', '[B][COLOR khaki]Premiery[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('Nowe sezony', '[B][COLOR khaki]Nowe sezony[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('Popularne', '[B][COLOR khaki]Popularne[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://wideo.site/shows.html', '[B][COLOR khaki]Lista alfabetyczna[/COLOR][/B]', 'DefaultTVShows.png', "ListAlfabet", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('seriale', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	
def busy():

    if float(xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')[:4]) > 17.6:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    else:
        xbmc.executebuiltin('ActivateWindow(busydialog)')	
def idle():

    if float(xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')[:4]) > 17.6:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    else:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
def SzukajWszystko():
	import szukaj
	flinks,slinks = szukaj.Przeszukuj()
	return flinks,slinks
def router(paramstring):
	params = dict(parse_qsl(paramstring))
	if params:
		typv='videos'
		mode = params.get('mode', None)
		
		if 'SimplelistFilmy' in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			
			links,pagin = mod.getFilmy(exlink,page)
			items = len(links)
			for f in links:
				
				add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items)
			if pagin:
				for f in pagin:	
					add_item(name=f.get('title'), url=f.get('url'), mode='SimplelistFilmy:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))		
			if addon.getSetting('auto-view') == 'true':
				typv='movies'		
			xbmcplugin.setContent(addon_handle, typv)		
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif 'SimplelistSeriale' in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			links,pagin = mod.ListSeriale(exlink,page)
			items = len(links)
			mud = 'getSimpleSeasons:%s'%mode2
			if mode2=='filmeriaco':
				mud = 'getLinksfilmeriaco'
				
			for f in links:
				
				add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items)
			if pagin:
				for f in pagin:	
					add_item(name=f.get('title'), url=f.get('url'), mode='SimplelistSeriale:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))			
			if addon.getSetting('auto-view') == 'true':
				typv='tvshows'		
			xbmcplugin.setContent(addon_handle, typv)				
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif 'listCategory' in mode:
			mode2 = mode.split(':')[1]
			co='film' if 'film' in mode else 'serial'
			mod = import_mod(mode2)
			kategoria = mod.ListCateg(co,exlink)
			if co=='serial':
			
			
				links,pagin = mod.ListSeriale(kategoria,page)
				items = len(links)
				mud = 'getSimpleSeasons:%s'%mode2
				for f in links:
					
					add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items)
				if pagin:
					for f in pagin:	
						add_item(name=f.get('title'), url=f.get('url'), mode='SimplelistSeriale:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))	
				if addon.getSetting('auto-view') == 'true':
					typv='tvshows'		
				xbmcplugin.setContent(addon_handle, typv)			
			#	xbmcplugin.setContent(addon_handle, 'tvshows')	
			else:
				links,pagin = mod.getFilmy(kategoria,page)
				items = len(links)
				for f in links:
					
					add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=True, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items)
				if pagin:
					for f in pagin:	
						add_item(name=f.get('title'), url=f.get('url'), mode='SimplelistFilmy:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))	
				if addon.getSetting('auto-view') == 'true':
					typv='movies'		
				xbmcplugin.setContent(addon_handle, typv)			
			#	xbmcplugin.setContent(addon_handle, 'movies')		
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif 'SimplelistSearch' in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			flinks,slinks,pagin = mod.ListSearch(exlink,page)
			if flinks or slinks:
				items1 = len(flinks)
				items2 = len(slinks)
				mud = 'getSimpleSeasons:%s'%mode2
				if mode2=='filmeriaco':
					mud = 'getLinksfilmeriaco'
				if slinks:
					for f in slinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items2)
					if addon.getSetting('auto-view') == 'true':
						typv='tvshows'		
					xbmcplugin.setContent(addon_handle, typv)	
					#xbmcplugin.setContent(addon_handle, 'tvshows')	
				if flinks:
					for f in flinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1)
					if addon.getSetting('auto-view') == 'true':
						typv='movies'		
					xbmcplugin.setContent(addon_handle, typv)	
					#xbmcplugin.setContent(addon_handle, 'movies')
				if pagin:

					for f in pagin:	
						mud2 = 'SimplelistSeriale:%s'%mode2
						if 'cda-filmy' in f.get('url') or 'zalukaj' in f.get('url') :
							mud2 = 'ListContent:%s'%mode2
						elif 'dudeplayer' in f.get('url'):
							mud2 = 'ListContent3'
						add_item(name=f.get('title'), url=f.get('url'), mode=mud2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
					
				xbmcplugin.endOfDirectory(addon_handle)
			elif not flinks and not slinks:
				return
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)

		elif 'getSimpleSeasons'in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			seasons=mod.getSerial(exlink)	
			if seasons:
				items = len(seasons)
				for i in sorted(seasons.keys()):
					opis=(seasons[i])[0].get('plot')
					add_item(name=name+' - '+i, url=quote(str(seasons[i])), mode='getEpisodes:%s'%mode2, image=rys, folder=True,  infoLabels={'plot':opis}, itemcount=items)	
				if addon.getSetting('auto-view') == 'true':
					typv='tvshows'		
				xbmcplugin.setContent(addon_handle, typv)	
				#xbmcplugin.setContent(addon_handle, 'tvshows')
				xbmcplugin.endOfDirectory(addon_handle)	
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak odcinków do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
		elif 'getEpisodes'in mode:
			mode2 = mode.split(':')[1]
			getEpisodes(exlink,mode2)
			
		elif 'menu' in mode:
			mode2 = mode.split(':')[1]
			mod = import_menu(mode2)
			mod
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif 'getVid' in mode:
			#busy()
			
			adapt=False
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			#idle()
			stream_url,resolve = mod.getVideo(exlink)

			if resolve and stream_url:
				import cdapl 
				if 'cda.pl' in stream_url:
					stream_url = cdapl.getLinkCda(stream_url)
					if len(stream_url)==1:
						stream_url = stream_url[0][0]
					else:
						if type(stream_url) is list:
							qual = [x[1] for x in stream_url]
							select = xbmcgui.Dialog().select('Wybierz jakość (cda)', qual)
							
							if select>-1:
								stream_url = stream_url[select][0]
							else:
								
								stream_url=''
								quit()
				else:
					import resolveurl
					if 'hqq.' in stream_url or 'waaw.' in stream_url:
						import ekinopw
						stream_url=ekinopw.getHqq(stream_url)
					elif 'upvideo.cc' in stream_url or 'upvideo.x' in stream_url :
						import zalukajvip
						stream_url=zalukajvip.getUpvideocc(stream_url)
						if stream_url=='quit':
							
							quit()
						adapt=False
					else:
						try:
							stream_url = resolveurl.resolve(stream_url)
						except Exception as e:
							stream_url=''
				
			if stream_url:
				PlayVid(stream_url,adapt)
			else:
				if resolve=='quit':
					xbmcgui.Dialog().notification('[B]Link nie działa[/B]', 'Spróbuj inny',xbmcgui.NOTIFICATION_INFO, 6000,False)
					quit()
				else:
					xbmcgui.Dialog().notification('[B]Link nie działa[/B]', 'Spróbuj inny',xbmcgui.NOTIFICATION_INFO, 6000,False)
			
		elif mode == 'getLinksfilmeriaco':
			import filmeriaco  as mod
			links,pags= mod.getLinks(exlink)
			items = len(links)
			for f in links:
				add_item(name=f.get('title'), url=f.get('url'), mode='getVid:filmeriaco', image=f.get('image'), folder=False, IsPlayable=True, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('jak')}, itemcount=items)
			xbmcplugin.setContent(addon_handle, 'videos')		
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif mode == 'ListGatRok':
			import dudeplayer
			litery = dudeplayer.getLitery2(exlink)
			items = len(litery)
			if items>1:
				for f in litery:
					add_item(name=f.get('title'), url=f.get('url'), mode='ListContent:dudeplayer', image='', folder=True)
				xbmcplugin.setContent(addon_handle, 'videos')		
				xbmcplugin.endOfDirectory(addon_handle)
		
		elif mode == 'ListContent3':
			import dudeplayer
			#flinks,slinks,npage = dudeplayer.ListContent3(exlink) #flinks,slinks,pagin = mod.ListContent(exlink,page)
			flinks,slinks,pagin = dudeplayer.ListContent3(exlink,page)
			if flinks or slinks:
				items1 = len(flinks)
				items2 = len(slinks)
				mud = 'getSimpleSeasons:dudeplayer'
				if slinks:
					for f in slinks:
						dd=f.get('plot') if f.get('plot') else f.get('title')
						add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':dd,'title': f.get('title')}, itemcount=items2)
					if addon.getSetting('auto-view') == 'true':
						typv='tvshows'		
					xbmcplugin.setContent(addon_handle, typv)	
				#	xbmcplugin.setContent(addon_handle, 'tvshows')	
				if flinks:
					for f in flinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode='getVid:dudeplayer', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code'),'duration':f.get('duration')}, itemcount=items1)
					if addon.getSetting('auto-view') == 'true':
						typv='movies'		
					xbmcplugin.setContent(addon_handle, typv)	
				#	xbmcplugin.setContent(addon_handle, 'movies')
				if pagin:
					for f in pagin:	
						add_item(name=f.get('title'), url=f.get('url'), mode='ListContent3', image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
					
				xbmcplugin.endOfDirectory(addon_handle)
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
		#	= dudeplayer.getLitery(exlink)

		elif mode == 'ListFilmyZaluknij':
			import dudeplayer
			litery = dudeplayer.getLitery(exlink)
			items = len(litery)
			if items>1:
				for f in litery:
					add_item(name=f.get('title'), url=f.get('url'), mode='ListContent2', image='', folder=True)
				xbmcplugin.setContent(addon_handle, 'videos')		
				xbmcplugin.endOfDirectory(addon_handle)


		elif mode == 'ListAlfabet2':
			import dudeplayer
			litery = dudeplayer.getLitery(exlink)
			items = len(litery)
			if items>1:
				for f in litery:
					add_item(name=f.get('title'), url=f.get('url'), mode='ListContent2', image='', folder=True)
				xbmcplugin.setContent(addon_handle, 'videos')		
				xbmcplugin.endOfDirectory(addon_handle)
			

			
			
			
		elif mode == 'ListContent2':
			import dudeplayer
			flinks=[]
			slinks=[]

			flinks,slinks = dudeplayer.ListContent2(exlink)
			if flinks or slinks:
				items1 = len(flinks)
				items2 = len(slinks)
				mud = 'getSimpleSeasons:dudeplayer'
				if slinks:
					for f in slinks:
						dd=f.get('plot') if f.get('plot') else f.get('title')
						add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':dd,'title': f.get('title')}, itemcount=items2)
					xbmcplugin.setContent(addon_handle, 'tvshows')	
				if flinks:
					for f in flinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode='getVid:dudeplayer', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code'),'duration':f.get('duration')}, itemcount=items1)
					#	if addon.getSetting('auto-view') == 'true':
					#		typv='movies'	
					#	xbmcplugin.setContent(addon_handle, typv)	
					if addon.getSetting('auto-view') == 'true':
						typv='movies'	
					xbmcplugin.setContent(addon_handle, typv)	
					#xbmcplugin.setContent(addon_handle, 'movies')

				xbmcplugin.endOfDirectory(addon_handle)
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
		elif mode == 'ListAlfabet':
			import wideosite
			litery = wideosite.getLitery(exlink)
			items = len(litery)
			if items>1:
				for f in litery:
					add_item(name=f.get('title'), url=f.get('url'), mode='ListContent:wideosite', image='', folder=True)
				xbmcplugin.setContent(addon_handle, 'videos')		
				xbmcplugin.endOfDirectory(addon_handle)
		elif mode == 'ListSerieF1':
			import zalukajvip
			series = zalukajvip.getSerieF(exlink)
			items = len(series)
			if items>1:
				for f in series:
					add_item(name=f.get('title'), url=f.get('url'), mode='ListSerieContent', image=f.get('image'), folder=True)
				xbmcplugin.setContent(addon_handle, 'videos')		
				xbmcplugin.endOfDirectory(addon_handle)

		elif mode == 'ListSerieContent':
			import zalukajvip
			links = zalukajvip.ListSerieContent(exlink)
			items = len(links)
			if items>1:
				for f in links:
					add_item(name=f.get('title'), url=f.get('url'), mode='getVid:zalukajvip', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('jak')}, itemcount=items)
				xbmcplugin.setContent(addon_handle, 'videos')		
				xbmcplugin.endOfDirectory(addon_handle)

				
		elif mode == 'ListTV':
			import filmninja  as mod
			links = mod.getTV(exlink)
			items = len(links)
			for f in links:
				add_item(name=f.get('title'), url=f.get('url'), mode='PlayTv', image=f.get('image'), folder=False, IsPlayable=False, infoLabels=False, itemcount=items)
			if addon.getSetting('auto-view') == 'true':
				typv='movies'	
			xbmcplugin.setContent(addon_handle, typv)	
			#xbmcplugin.setContent(addon_handle, 'movies')
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif mode == 'PlayTv':
			import filmninja  as mod
			stream_url,resol = mod.PlayTv(exlink)
			if stream_url:
				PlayVid(stream_url)
			else:
				xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Brak działającego linka.',xbmcgui.NOTIFICATION_INFO, 6000,False)
				
		elif 'SelectList' in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			#flinks =''
			#slinks =''
			url = mod.SelectList(exlink)
			if url:
				flinks,slinks,pagin = mod.ListContent(url,page)
				if flinks or slinks:
					items1 = len(flinks)
					items2 = len(slinks)
					mud = 'getSimpleSeasons:%s'%mode2
					if slinks:
						for f in slinks:
							
							add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items2)
						if addon.getSetting('auto-view') == 'true':
							typv='tvshows'
						xbmcplugin.setContent(addon_handle, typv)	
					#	xbmcplugin.setContent(addon_handle, 'tvshows')	
					if flinks:
						for f in flinks:
							
							add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1)
						if addon.getSetting('auto-view') == 'true':
							typv='movies'
						xbmcplugin.setContent(addon_handle, typv)	
						#xbmcplugin.setContent(addon_handle, 'movies')
					if pagin:
						for f in pagin:	
							add_item(name=f.get('title'), url=f.get('url'), mode='ListContent:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
						
					xbmcplugin.endOfDirectory(addon_handle)
				else:
					xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)

		elif 'ListContent' in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			flinks=[]
			slinks=[]
			pagin=[]
			flinks,slinks,pagin = mod.ListContent(exlink,page)
			if flinks or slinks:
				items1 = len(flinks)
				items2 = len(slinks)
				if 'xyz/seasons/' in exlink:
					mud = 'Listepisodesxyz'
				else:

					mud = 'getSimpleSeasons:%s'%mode2
				if slinks:
					for f in slinks:
						dd=f.get('plot') if f.get('plot') else f.get('title')
						add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':dd,'title': f.get('title')}, itemcount=items2)
					
						
					if 'zaluknij' in exlink:
						xbmcplugin.setContent(addon_handle, 'videos')	
					else:
						if addon.getSetting('auto-view') == 'true':
							typv='tvshows'
						xbmcplugin.setContent(addon_handle, typv)
						#xbmcplugin.setContent(addon_handle, 'tvshows')
				if flinks:
					for f in flinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code'),'duration':f.get('duration')}, itemcount=items1)
					if 'zaluknij' in exlink:
						xbmcplugin.setContent(addon_handle, 'videos')	
					else:
						if addon.getSetting('auto-view') == 'true':
							typv='movies'
						xbmcplugin.setContent(addon_handle, typv)
						#xbmcplugin.setContent(addon_handle, 'movies')
						
					
				if pagin:
					for f in pagin:	
						add_item(name=f.get('title'), url=f.get('url'), mode='ListContent:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
					
				xbmcplugin.endOfDirectory(addon_handle)
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
		elif mode == "szukajwszystko":
			import szukaj
			flinks,slinks=szukaj.Przeszukuj()
			if flinks or slinks:
				items1 = len(flinks)
				items2 = len(slinks)
				if slinks:
					for f in slinks:
						
						mud = 'getSimpleSeasons:%s'%(f.get('mode2'))
						dd=f.get('plot') if f.get('plot') else f.get('title')
						add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':dd,'title': f.get('title')}, itemcount=items2)
					if addon.getSetting('auto-view') == 'true':
						typv='tvshows'
					xbmcplugin.setContent(addon_handle, typv)
				#	xbmcplugin.setContent(addon_handle, 'tvshows')	
				if flinks:
					for f in flinks:
						mode2 = f.get('mode2')
						add_item(name=f.get('title')+' - [COLOR red] '+mode2+'[/COLOR]', url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1)
					if addon.getSetting('auto-view') == 'true':
						typv='movies'
					xbmcplugin.setContent(addon_handle, typv)
					#xbmcplugin.setContent(addon_handle, 'movies')
				xbmcplugin.endOfDirectory(addon_handle)
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
				
		elif mode == "ListSubMenuZaluknij":
			zaluknijSubMenu()
		elif mode == "ListSubMenuZaluknij2":
			zaluknijSubMenu2()
		elif mode == 'Listepisodesxyz':
			import zaluknij
			links = zaluknij.Listepisodesxyz(exlink)
			items = len(links)
			if items>1:
				for f in links:
					add_item(name=f.get('title'), url=f.get('url'), mode='getVid:zaluknij', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('jak')}, itemcount=items)
				if addon.getSetting('auto-view') == 'true':
					typv='movies'
				xbmcplugin.setContent(addon_handle, typv)
				#xbmcplugin.setContent(addon_handle, 'movies')		
				xbmcplugin.endOfDirectory(addon_handle)
			
			
			
			
	else:
		home()
		xbmcplugin.endOfDirectory(addon_handle)	
if __name__ == '__main__':
    router(sys.argv[2][1:])
