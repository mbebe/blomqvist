# -*- coding: UTF-8 -*-
import sys,re,os
import geturl as gethtml
from geturl import PLchar as PLchar

if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus
    import urllib.parse as urlparse
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse

basurl='https://filmy-2019.blogspot.com'
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0'


headersc = {
    
        'Referer':basurl,
        'user-agent': UA,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
    }

def ListContent(url,page):

    html,kuks = gethtml.getRequests(url,headers=headersc)
    npage=[]
    fout=[]
    sout=[]

    result = parseDOM(html,'div', attrs={'class': "main section"}) [0]
    pages = parseDOM(html,'div', attrs={'class': "blog-pager container"}) #[0] #<div class='blog-pager container'
    if pages:
        nturl = re.findall("""href=['"](.+?)['"]""", pages[0], re.DOTALL)#[0]#nturl.split('?')[1]

        if nturl:
            npage.append({'title':'Następna strona','url':nturl[0],'image':'','plot':'','page':int(page)+1})

        
    links = parseDOM(result,'div', attrs={'class': "jump-link flat-button ripple"}) # <div class="jump-link flat-button ripple">    
    for link in links:
        href = parseDOM(link, 'a', ret='href')[0]
        tyt = parseDOM(link, 'a', ret='title')[0]

        fout.append({'title':PLchar(tyt),'url':PLchar(href),'image':'DefaultMovies.png','plot':PLchar(tyt),'year':'','code':'','genre':'', 'duration':'', 'mode2':'dudaplayer'})

            
    return fout,sout,npage

def ListContent2(url,page):

    html,kuks = gethtml.getRequests(url,headers=headersc)
    npage=[]
    fout=[]
    sout=[]

    result = parseDOM(html,'div', attrs={'class': "box"}) [0]

    
    rgx=re.findall('a href="(.+?)">(.+?)<\/a><\/h3>(.+?)<',result,re.DOTALL)
    for href,tyt,opis in rgx:

        opis = re.sub("<[^>]*>","",opis)

        href = 'http://maxfilms.eu'+ href if href.startswith('?') else href
        fout.append({'title':PLchar(tyt),'url':PLchar(href),'image':'DefaultMovies.png','plot':PLchar(opis),'year':'','code':'','genre':'', 'duration':'', 'mode2':'dudaplayer'})

            
    return fout,sout,npage
    
def ListContentSearch(query,page):

    headersc.update({'Content-Type': 'application/x-www-form-urlencoded'})
    dt = {'wyszukiwarka': query}
    url = 'http://maxfilms.eu/page/1'

    html,kuks = gethtml.getRequests(url,data=dt,headers=headersc)
    npage=[]
    fout=[]
    sout=[]
    result = parseDOM(html,'div', attrs={'class': "box"})[0] 
    dd=re.findall('a href="(.+?)">(.+?)<',result,re.DOTALL)
    for href, tyt in dd:

        fout.append({'title':PLchar(tyt),'url':PLchar(href),'image':'DefaultMovies.png','plot':'','year':'','code':'','genre':'', 'duration':'', 'mode2':'dudaplayer'})
    return fout,sout,npage

def getVideo(url):
    out=[]

    html,kuks = gethtml.getRequests(url,headers=headersc)
    stream_url=''
    stream_urlx = parseDOM(html, 'iframe', ret='src')[0]

    if stream_urlx:
        if 'protonvid' in stream_urlx:#[0]:
            idi = stream_urlx.split('/')[-2]
            

            headers = {
                'Host': 'api.protonvideo.to',
                'User-Agent': UA,
                'Accept': '*/*',
                'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
                'Referer': 'https://protonvideo.to/',
                'Content-Type': 'text/plain;charset=UTF-8',
                'Origin': 'https://protonvideo.to',
                'DNT': '1',
            }
            
            data = '{"idi":"'+idi+'"}'

            a = gethtml.getRequestsJson('https://api.protonvideo.to/api/v4/player',data=data,headers=headers)

            stream_url = re.findall('(http.*?)$',a[0].get('file'))
            stream_url = stream_url[0] if stream_url else ''

            if ' or ' in stream_url:
                stream_url = stream_url.split(' or ')[0]
            dod = '|User-Agent='+quote(UA)+'&Referer='+stream_urlx+'&Cookie='+quote(kuks)
            stream_url+=dod# if stream_url else stream_url
        return stream_url,False
    else:
        return '','quit'

def szukcd(d):
    page=1
    fout=[]
    sout=[]
    url='https://filmy-2019.blogspot.com/search?q='+d#.replace(

    fout,sout,npage=ListContent(url,page)
    return fout,sout,npage
    
def ListSearch(url,page):    
    d = gethtml.inputDialog(u'Szukaj...')
    fout=[]
    sout=[]
    npage=[]

    if d:
        fout,sout,npage=szukcd(d)

    return fout,sout,npage
