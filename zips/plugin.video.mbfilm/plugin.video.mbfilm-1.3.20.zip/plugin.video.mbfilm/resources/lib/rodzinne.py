# -*- coding: UTF-8 -*-
import sys,re,os
import geturl as gethtml
from geturl import PLchar as PLchar

if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus
    import urllib.parse as urlparse
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse

basurl='https://rodzinnekino.com/'
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'

def ListContent(url,page):
	if '/page/' in url:
		nturl = re.sub('page\/\\d+','page/%d'%(int(page)+1),url)
		url = re.sub('page\/\\d+','page/%d'%int(page),url)
	else:
		nturl = url + 'page/%d' %(int(page)+1)
		url = url + 'page/%d' %int(page)
		
	html,kuks = gethtml.getRequests(url)
	npage=[]
	fout=[]
	sout=[]
	
	try:
		pagination = parseDOM(html,'div', attrs={'class': "pagination"})[0]
		if pagination.find( '/page/%d' %(int(page)+1))>-1:
			npage.append({'title':'Następna strona','url':nturl,'image':'','plot':'','page':int(page)+1})
	except:
		pass
	result = parseDOM(html,'div', attrs={'id': "archive-content"})
	result =result[0] if result else html
	links = parseDOM(result,'article', attrs={'id': "post\-.+?"})
	
	for link in links:
		href = parseDOM(link, 'a', ret='href')[0]
		imag = parseDOM(link, 'img', ret='src')[0]
		try:
			tytul = (parseDOM(link, 'h4')[0]).strip(' ')
		except:
			tytul = (parseDOM(link, 'h3')[0]).strip(' ')
		if '<h2>' in tytul:
			tytul = (tytul.split('<h2>')[0]).strip(' ')
		opis = parseDOM(link,'div', attrs={'class': "texto"})
		opis = opis[0] if opis else tytul
		genre = re.findall('rel="tag">([^>]+)<',link)
		kateg = ','.join([(x.strip()).lower() for x in genre]) if genre else ''
		metad = parseDOM(link,'div', attrs={'class': "metadata"})
		if metad:
			try:
				if'IMDb:' in metad[0]:
					if '/film/' in 	href:
						imdb,year,czas,wysw = re.findall('>([^<]+)<\/span>',metad[0])#[0]
					else:
						imdb,year,wysw = re.findall('>([^<]+)<\/span>',metad[0])#[0]
				else:
					if '/film/' in 	href:
						year,czas,wysw = re.findall('>([^<]+)<\/span>',metad[0])#[0]
					else:
						year,wysw = re.findall('>([^<]+)<\/span>',metad[0])#[0]
			except:
				imdb=''
				year=''
				czas=''
				wysw=''
		else:
			year=''
			try:
				year = re.findall('<span>(.+?)<\/span><\/div>',link)[0]
			except:
				year = '' 
			imdb=''
			czas=''
			wysw=''
		if '/film/' in 	href:
			fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'genre':PLchar(kateg)})	
		else:
			sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'genre':PLchar(kateg)})

	return fout,sout,npage

def SelectList(typ):
	if 'gatunek' in typ:
		label =["Akcja","Akcja i Przygoda","Animacja","Biograficzny","Dokumentalny","Dramat","Familijny","Fantasy","film TV","Historyczny","Horror","Komedia","Kryminał","Muzyczny","News","Remont","Przygodowy","Reality","Romans","Sci-Fi","Sci-Fi & Fantasy","Soap","Tajemnica","Talk","Thriller","Wojenny & Polityczny","Wojenny","Western"]
		value =["https://rodzinnekino.com/gatunek/akcja/page/1","https://rodzinnekino.com/gatunek/akcja-i-przygoda/page/1","https://rodzinnekino.com/gatunek/animacja/page/1","https://rodzinnekino.com/gatunek/biograficzny/page/1","https://rodzinnekino.com/gatunek/dokumentalny/page/1","https://rodzinnekino.com/gatunek/dramat/page/1","https://rodzinnekino.com/gatunek/familijny-1/page/1","https://rodzinnekino.com/gatunek/fantasy/page/1","https://rodzinnekino.com/gatunek/film-tv/page/1","https://rodzinnekino.com/gatunek/historyczny/page/1","https://rodzinnekino.com/gatunek/horror/page/1","https://rodzinnekino.com/gatunek/komedia/page/1","https://rodzinnekino.com/gatunek/kryminal/page/1","https://rodzinnekino.com/gatunek/muzyczny/page/1","https://rodzinnekino.com/gatunek/news/page/1","https://rodzinnekino.com/gatunek/remont/page/1","https://rodzinnekino.com/gatunek/przygodowy/page/1","https://rodzinnekino.com/gatunek/reality/page/1","https://rodzinnekino.com/gatunek/romans/page/1","https://rodzinnekino.com/gatunek/sci-fi/page/1","https://rodzinnekino.com/gatunek/sci-fi-fantasy/page/1","https://rodzinnekino.com/gatunek/soap/page/1","https://rodzinnekino.com/gatunek/tajemnica/page/1","https://rodzinnekino.com/gatunek/talk/page/1","https://rodzinnekino.com/gatunek/thriller/page/1","https://rodzinnekino.com/gatunek/war-politics/page/1","https://rodzinnekino.com/gatunek/wojenny/page/1","https://rodzinnekino.com/gatunek/western/page/1"]
		nazwa = "Wybierz gatunek"
	elif 'kraj' in typ:
		label =["EUROPA","AMERYKA PN","AZJA","USA","Kanada","Wielka Brytania","Francja","Polska","Niemcy","Belgia","Australia","Chiny","Japonia"]
		value =["https://rodzinnekino.com/kraj/europa/page/1","https://rodzinnekino.com/kraj/ameryka-pn/page/1","https://rodzinnekino.com/kraj/azja/page/1","https://rodzinnekino.com/kraj/ameryka-pn/usa/page/1","https://rodzinnekino.com/kraj/ameryka-pn/kanadapage/1","https://rodzinnekino.com/kraj/europa/wielka-brytaniapage/1","https://rodzinnekino.com/kraj/europa/francjapage/1","https://rodzinnekino.com/kraj/europa/polska/page/1","https://rodzinnekino.com/kraj/europa/niemcypage/1","https://rodzinnekino.com/kraj/europa/belgiapage/1","https://rodzinnekino.com/kraj/australia-i-oceania/australia/page/1","https://rodzinnekino.com/kraj/azja/chiny/page/1","https://rodzinnekino.com/kraj/azja/japonia/page/1"]
		nazwa = "Wybierz region"
	elif 'wersja' in typ:
		label =["Lektor","Napisy","Polski","Dubbling","Oryginalny"]
		value =["https://rodzinnekino.com/wersja/lektor/page/1","https://rodzinnekino.com/wersja/napisy/page/1","https://rodzinnekino.com/wersja/polski-pl/page/1","https://rodzinnekino.com/wersja/dubbling/page/1","https://rodzinnekino.com/wersja/oryginalny/page/1"]
		nazwa = "Wybierz wersję"
	
	elif 'rok' in typ:
		label =["2020","2019","2018","2017","2016","2015","2014","2013","2012","2011","2010","2009","2008","2007","2006","2005","2004","2003","2002","2001","2000","1999","1998","1997","1996","1995","1994","1993","1992","1991","1990","1989","1988","1987","1986","1985","1984","1983","1982","1981","1980","1979","1978","1977","1976","1975","1974","1973","1972","1971"]
		value =["https://rodzinnekino.com/premiera/2020/page/1","https://rodzinnekino.com/premiera/2019/page/1","https://rodzinnekino.com/premiera/2018/page/1","https://rodzinnekino.com/premiera/2017/page/1","https://rodzinnekino.com/premiera/2016/page/1","https://rodzinnekino.com/premiera/2015/page/1","https://rodzinnekino.com/premiera/2014/page/1","https://rodzinnekino.com/premiera/2013/page/1","https://rodzinnekino.com/premiera/2012/page/1","https://rodzinnekino.com/premiera/2011/page/1","https://rodzinnekino.com/premiera/2010/page/1","https://rodzinnekino.com/premiera/2009/page/1","https://rodzinnekino.com/premiera/2008/page/1","https://rodzinnekino.com/premiera/2007/page/1","https://rodzinnekino.com/premiera/2006/page/1","https://rodzinnekino.com/premiera/2005/page/1","https://rodzinnekino.com/premiera/2004/page/1","https://rodzinnekino.com/premiera/2003/page/1","https://rodzinnekino.com/premiera/2002/page/1","https://rodzinnekino.com/premiera/2001/page/1","https://rodzinnekino.com/premiera/2000/page/1","https://rodzinnekino.com/premiera/1999/page/1","https://rodzinnekino.com/premiera/1998/page/1","https://rodzinnekino.com/premiera/1997/page/1","https://rodzinnekino.com/premiera/1996/page/1","https://rodzinnekino.com/premiera/1995/page/1","https://rodzinnekino.com/premiera/1994/page/1","https://rodzinnekino.com/premiera/1993/page/1","https://rodzinnekino.com/premiera/1992/page/1","https://rodzinnekino.com/premiera/1991/page/1","https://rodzinnekino.com/premiera/1990/page/1","https://rodzinnekino.com/premiera/1989/page/1","https://rodzinnekino.com/premiera/1988/page/1","https://rodzinnekino.com/premiera/1987/page/1","https://rodzinnekino.com/premiera/1986/page/1","https://rodzinnekino.com/premiera/1985/page/1","https://rodzinnekino.com/premiera/1984/page/1","https://rodzinnekino.com/premiera/1983/page/1","https://rodzinnekino.com/premiera/1982/page/1","https://rodzinnekino.com/premiera/1981/page/1","https://rodzinnekino.com/premiera/1980/page/1","https://rodzinnekino.com/premiera/1979/page/1","https://rodzinnekino.com/premiera/1978/page/1","https://rodzinnekino.com/premiera/1977/page/1","https://rodzinnekino.com/premiera/1976/page/1","https://rodzinnekino.com/premiera/1975/page/1","https://rodzinnekino.com/premiera/1974/page/1","https://rodzinnekino.com/premiera/1973/page/1","https://rodzinnekino.com/premiera/1972/page/1","https://rodzinnekino.com/premiera/1971/page/1"]
		nazwa = "Wybierz rok"

	sel = gethtml.selectDialog(nazwa, label)
	if sel>-1:
		kategoria = value[sel]# if sel>-1 else ''
		return kategoria
	else:
		quit()
	
	
	
	#kategoria = value[sel] if sel>-1 else ''
	#return kategoria

def getFilmy(url,page):
	url=basurl+'filmy-online/page/%s/'%(str(page))
	html,kuks = gethtml.getRequests(url)
	out=[]
	links = parseDOM(html,'div', attrs={'class': "movie big.+?"})
	npage=[]
	if html.find('http://filmeria.co/filmy-online/page/%s/'%str(int(page)+1))>0:
		npage.append({'title':'Następna strona','url':'','image':'','plot':'','page':int(page)+1})
	for link in links:
		href,tit=re.findall('href="(.+?)\s*"\s*title="(.+?)"',link)[0]
		tytul = re.findall('^(.+?)online o',tit)[0]
		imag = (parseDOM(link, 'img', ret='src')[0]).strip()
		imag+='|User-Agent='+quote(UA)+'&Cookie='+quote(kuks)
		imag = 'http:'+ imag if imag.startswith('//') else imag
		out.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(tytul)})
	return out,npage

def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
def getSerial(url):

	html,kuks = gethtml.getRequests(url)
	resultmain = parseDOM(html,'div', attrs={'class': "content"})[0]
	tytul = parseDOM(resultmain,'h1')[0]#'lll'
	
	genros = parseDOM(resultmain,'div', attrs={'class': "sgeneros"})[0]
	genre = re.findall('rel="tag">([^>]+)<',genros)
	kateg = ','.join([(x.strip()).lower() for x in genre]) if genre else ''
	
	widinfo = parseDOM(html,'div', attrs={'id': "info"})[0]

	opis = parseDOM(widinfo,'p')
	opis = opis[0] if opis else ''

	result = parseDOM(html,'div', attrs={'id': "seasons"})[0]

	sezony = parseDOM(result,'div', attrs={'class': "se\-c"})
	episodes=[]

	for sezon in sezony:
		tytsez = parseDOM(sezon,'span', attrs={'class': "title"})
		ses = re.findall('sezon\s*(\d+)',tytsez[0],re.IGNORECASE)
		ses = ses[0] if ses else '0'
		eps = parseDOM(sezon,'li', attrs={'class': "mark\-.+?"})
		for ep in eps:
		
			tyt2 = parseDOM(ep, 'a')[0] 
			href = parseDOM(ep, 'a', ret='href')[0]  
			episd = parseDOM(ep,'div', attrs={'class': "numerando"})
			epis = re.findall('\-\s*(\d+)',episd[0])
			rys = parseDOM(ep, 'img', ret='src')[0]  
			tyt1 = 'S%02dE%02d'%(int(ses),int(epis[0]))
			tyt = '%s - (%s) %s'%(tytul,tyt1,tyt2)
			episodes.append({'title':PLchar(tyt),'url':PLchar(href),'image':rys,'plot':PLchar(opis),'genre':PLchar(kateg),'season':int(ses),'episode':int(epis[0])})
			
	seasons = splitToSeasons(episodes)
	return seasons

def getVideo(url):
	out=[]
	html,kuks = gethtml.getRequests(url)
	stream_url=''

	result = parseDOM(html,'div', attrs={'id': "playeroptions"})
	if result:
		result=result[0]
		videos = re.findall("<li id=(.+?)<\/li",result,re.DOTALL+re.IGNORECASE)
		for vid in videos:
			dpost = re.findall('data\-post="([^"]+)',vid)[0]
			dtype = re.findall('data\-type="([^"]+)',vid)[0]
			dnume = re.findall('data\-nume="([^"]+)',vid)[0]
			host = re.findall('"server">([^<]+)<',vid)[0]
			data = 'action=doo_player_ajax&post=%s&nume=%s&type=%s'%(dpost,dnume,dtype)
			out.append({'href':data,'host':host})
	
		if out:
			if len(out) > 1:
				u = [ x.get('href') for x in  out]
				h = [ x.get('host') for x in  out]
				sel = gethtml.selectDialog("Źródło", h)
				data = out[sel].get('href') if sel>-1 else ''
			else:
				data = out[0].get('href')
			if data:
				headers = {
					'Host': 'rodzinnekino.com',
					'user-agent': UA,
					'accept': '*/*',
					'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
					'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
					'x-requested-with': 'XMLHttpRequest',
					'origin': 'https://rodzinnekino.com',
					'referer': url,
					'te': 'trailers',}
				posturl = 'https://rodzinnekino.com/wp-admin/admin-ajax.php'
				html,kuks = gethtml.getRequests(posturl,data=data,headers=headers)
				
				stream_url = parseDOM(html, 'iframe', ret='src') 
				stream_url = stream_url[0] if stream_url else ''
			else:
				return stream_url,'quit'
	return stream_url,True
def szukcd(d):
	fout=[]
	sout=[]
	url=basurl+'?s='+d
	html,kuks = gethtml.getRequests(url)
	
	links = parseDOM(html,'div', attrs={'class': "result\-item"})
	for link in links:
		tytdane = parseDOM(link,'div', attrs={'class': "title"})[0]
		tytul = parseDOM(tytdane, 'a')[0]
		href = parseDOM(link, 'a', ret='href')[0]
		imag = parseDOM(link, 'img', ret='src')[0]
		year = parseDOM(link,'span', attrs={'class': "year"})
		year = year[0] if year else ''
		opis = parseDOM(link, 'p')
		opis = opis[0] if opis else tytul
		if '/seriale/' in href:
			sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'mode2':'rodzinne'})
		else:
			fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'mode2':'rodzinne'})
	return fout,sout
def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]

	if d:
		fout,sout=szukcd(d)
	return fout,sout,npage
