# -*- coding: UTF-8 -*-
import sys,re,os
import geturl as gethtml
from geturl import PLchar as PLchar

if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus
    import urllib.parse as urlparse
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse

basurl='http://filmeria.co/'
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'

def getFilmy(url,page):
	url=basurl+'filmy-online/page/%s/'%(str(page))
	html,kuks = gethtml.getRequests(url)
	out=[]
	links = parseDOM(html,'div', attrs={'class': "movie big.+?"})
	npage=[]
	if html.find('http://filmeria.co/filmy-online/page/%s/'%str(int(page)+1))>0:
		npage.append({'title':'Następna strona','url':'','image':'','plot':'','page':int(page)+1})
	for link in links:
		href,tit=re.findall('href="(.+?)\s*"\s*title="(.+?)"',link)[0]
		tytul = re.findall('^(.+?)online o',tit)[0]
		imag = (parseDOM(link, 'img', ret='src')[0]).strip()
		imag+='|User-Agent='+quote(UA)+'&Cookie='+quote(kuks)
		imag = 'http:'+ imag if imag.startswith('//') else imag
		out.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(tytul)})
	return out,npage

def getLinks(url):
	html,kuks = gethtml.getRequests(url)
	out=[]

	imgdiv = parseDOM(html,'div', attrs={'class': "entry\-content.+?"})[0]
	imag = (parseDOM(imgdiv, 'img', ret='src')[0]).strip()
	imag+='|User-Agent='+quote(UA)+'&Cookie='+quote(kuks)
	imag = 'http:'+ imag if imag.startswith('//') else imag

	result = parseDOM(html,'div', attrs={'id': "tab.+?",'class': "tab.+?"})[0]
	tyt = parseDOM(result,'h4')[0]
	tytul = re.findall('serial(.+?)online za',tyt)[0].strip(" ")
	links = parseDOM(result,'p')
	npage=[]
	
	for link in links:
		tyt2 = parseDOM(link, 'a')[0]
		hrefs = re.findall('a href ="(.+?)"',link)
		href = '|'.join([(x.strip()).lower() for x in hrefs]) if hrefs else ''
		tytul2 = '%s - %s'%(tytul,tyt2.replace('#',''))

		out.append({'title':PLchar(tytul2),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(tytul)})	
	return out,npage
	
def ListSeriale(url,page):
	url=basurl+'seriale-online/'
	html,kuks = gethtml.getRequests(url)
	out=[]
	links = parseDOM(html,'div', attrs={'class': "movie big.+?"})
	npage=[]
	for link in links:
		href,tit=re.findall('href="(.+?)\s*"\s*title="(.+?)"',link)[0]
		tytul = re.findall('^(.+?)online o',tit)[0]
		imag = (parseDOM(link, 'img', ret='src')[0]).strip()
		imag+='|User-Agent='+quote(UA)+'&Cookie='+quote(kuks)
		imag = 'http:'+ imag if imag.startswith('//') else imag
		out.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(tytul)})
	return out,npage
	
def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
def getSerial(url):
	html,kuks = gethtml.getRequests(url)
	links = parseDOM(html,'div', attrs={'id': "tab\-.+?"})
	episodes=[]
	tytul = parseDOM(html,'h1')[0]#

	for link in links:
		ses = re.findall('number">S(\d+)E.+?<',link)
		if not ses:
			ses = re.findall('number">sezon\s*(\d+)<',link,re.IGNORECASE)
		if ses:
			eps = parseDOM(link,'div', attrs={'class': "post\-.+?"})
			for ep in eps:
				tyt1 = re.findall('number">(.+?)<',ep)[0]
				href = parseDOM(ep, 'a', ret='href')[0] 
				rys = parseDOM(ep, 'img', ret='src')[0] 
				epis = re.findall('S\d+E(\d+)',tyt1)
				if not epis:
					epis = re.findall('odcinek\s*(\d+)',tyt1,re.IGNORECASE)#[0]
				tyt2 = parseDOM(ep,'h3')[0]
				tyt = '%s - (%s) %s'%(tytul,tyt1,tyt2)
				episodes.append({'title':PLchar(tyt),'url':PLchar(href),'image':rys,'season':int(ses[0]),'episode':int(epis[0])})
	seasons = splitToSeasons(episodes)
	return seasons

def getVideo(url):
	out=[]

	if'/seriale-online/' in url:
	
		urls = url.split('|')
		for href in urls:
			href = 'https:' + href if href.startswith('//') else href
			host  = urlparse.urlparse(href).netloc
			out.append({'href':href,'host':host})
	else:
		html,kuks = gethtml.getRequests(url)	
		result = parseDOM(html,'div', attrs={'id': "tab.+?",'class': "tab.+?"})[0]
		links = parseDOM(result,'p')
		for link in links:
			try:
				href = re.findall('a href ="(.+?)"',link)[0]
				href = 'https:' + href if href.startswith('//') else href
				host  = urlparse.urlparse(href).netloc
				out.append({'href':href,'host':host})
			except:
				pass
	if out:

		u = [ x.get('href') for x in  out]
		h = [ x.get('host') for x in  out]
		sel = gethtml.selectDialog("Źródło", h)
		stream_url = out[sel].get('href') if sel>-1 else ''
	
	return stream_url,True
	
def szukcd(d):
	fout=[]
	sout=[]
	url=basurl+'?s='+d
	html,kuks = gethtml.getRequests(url)
	links = parseDOM(html,'div', attrs={'class': "movie big.+?"})
	for link in links:
		href,tit=re.findall('a href="([^"]+)".+?title">([^<]+)<',link)[0]
		tytul = re.findall('^(.+?)online',tit)[0]
		imag = (parseDOM(link, 'img', ret='src')[0]).strip()
		imag+='|User-Agent='+quote(UA)+'&Cookie='+quote(kuks)
		imag = 'http:'+ imag if imag.startswith('//') else imag
		if 'seriale-online' in href:
			sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(tytul),'mode2':'filmeriaco'})
		else:
			fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(tytul),'mode2':'filmeriaco'})
	return fout,sout
def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]

	if d:
		fout,sout=szukcd(d)

	return fout,sout,npage
