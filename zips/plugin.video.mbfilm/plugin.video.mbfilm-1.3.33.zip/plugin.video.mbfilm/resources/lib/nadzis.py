# -*- coding: UTF-8 -*-
import sys,re,os
import resources.lib.geturl as gethtml
from resources.lib.geturl import PLchar #as PLchar

if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus
    import urllib.parse as urlparse
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse

basurl='https://filmynadzis.pl'
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'
import xbmc
def ListContent(url,page):
	if not '/popularne' in url:
		if '/page/' in url:
			nturl = re.sub('page\/\\d+','page/%d'%(int(page)+1),url)
			url = re.sub('page\/\\d+','page/%d'%int(page),url)
		else:
			nturl = url + 'page/%d' %(int(page)+1)
			url = url + 'page/%d' %int(page)
	else:
	
		
		if '/?s=' in url:
			url = url
		else:
			url = 'https://filmynadzis.pl'	
		nturl ='xyzrty'
	if '/?s=' in url:
		url = re.sub('page\/\\d+','',url)

	html,kuks = gethtml.getRequests(url)
	npage=[]
	fout=[]
	sout=[]
	if html.find(nturl)>-1:
		npage.append({'title':'Następna strona','url':nturl,'image':'','plot':'','page':int(page)+1})

	result = parseDOM(html,'div', attrs={'class': "main-cont.+?"})
	if not 'page' in url:
		result = parseDOM(html,'div', attrs={'class': "main-bottom.+?"})[0]
	else:
		result = result[0]
	if '/?s=' in url:
		result = parseDOM(html,'div', attrs={'class': "main-cont.+?"})[0]

	links = parseDOM(result,'div', attrs={'class': "entry-content"}) 

	for link in links:
		href = parseDOM(link, 'a', ret='href')[0]
		imag = parseDOM(link, 'img', ret='src')[0]
		tytul = parseDOM(link, 'a', ret='title')[0]
		
		imag = 'https:'+ imag if imag.startswith('//') else imag

		opis = parseDOM(link,'div', attrs={'class': "exce.+?"})
		opis = opis[0] if opis else tytul
		genre=''
		kateg =''
		jak=''
		trwa=''
		year = re.findall('\((\d+)\)',tytul)
		year = year[0] if year else ''

		fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'code':PLchar(jak),'genre':PLchar(kateg), 'duration':trwa, 'mode2':'dudaplayer'})

	return fout,sout,npage

def SelectList(urltyp):
	out=[]
	url,typ = urltyp.split('|')
	html,kuks = gethtml.getRequests(url)
	result = parseDOM(html,'nav', attrs={'class': "genres"})
	if typ == 'rok':
		result = parseDOM(html,'nav', attrs={'class': "releases"})
	if result:
		if typ == 'rok':
			for href,dan in re.findall('a href="(.+?)">(.+?)<',result[0]):
				out.append({'href':href,'host':dan})
		else:
			for href,dan,ilo in re.findall('a href="(.+?)">(.+?)</a>\s*<i>(.+?)<',result[0]):
				dan+=' '+ilo
				out.append({'href':href,'host':dan})

	if out:
		if len(out) > 1:
			u = [ x.get('href') for x in  out]
			h = [ x.get('host') for x in  out]
			sel = gethtml.selectDialog("Źródło", h)
			nturl = out[sel].get('href') if sel>-1 else ''




	label =["Akcja","Animacja","Dokumentalny","Dramat","Familijny","Fantasy","film TV","Historyczny","Horror","Komedia","Krótkometrażowy","Kryminał","Muzyczny","Premiery","Przygodowy","Romans","Sci-Fi","Sci-Fi &amp; Fantasy","Tajemnica","Thriller","Western","Wojenny"]
	value =["https://cda-filmy.online/gatunek/akcja/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/animacja/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/dokumentalny/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/dramat/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/familijny/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/fantasy/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/film-tv/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/historyczny/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/horror/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/komedia/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/krotkometrazowy/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/kryminal/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/muzyczny/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/premiery/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/przygodowy/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/romans/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/sci-fi/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/sci-fi-fantasy/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/tajemnica/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/thriller/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/western/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/wojenny/page/1/?tr_post_type="]
	nazwa = "Wybierz gatunek"

	sel = gethtml.selectDialog(nazwa, label)
	if sel>-1:
		dod='2' if 'ser' in typ else '1'
		kategoria = value[sel]+dod
		return kategoria
	else:
		quit()
		
def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
def getSerial(url):
	html,kuks = gethtml.getRequests(url)
	resultmain = parseDOM(html,'div', attrs={'class': "content right"})[0] 
	tytul = parseDOM(resultmain,'h1')[0]

	opis = parseDOM(resultmain,'p')
	opis = opis[0] if opis else ''
	sezony = parseDOM(html,'div', attrs={'class': "se-c"})
	episodes=[]
	#
	for sezon in sezony:

		ses = parseDOM(sezon,'span', attrs={'class': "se\-.*?"})

		ses = ses[0] if ses else '0'

		eps = parseDOM(sezon,'li', attrs={'class': "mark\-\d+"}) 

		
		for ep in eps:
			numerando = parseDOM(ep,'div', attrs={'class': "numerando"})[0]

			hrefy = parseDOM(ep,'div', attrs={'class': "episodiotitle"}) 
			if hrefy:
				href = parseDOM(hrefy, 'a', ret='href')[0]  
				tyt2 = parseDOM(hrefy, 'a')[0]  

				epis = re.findall('\d+\s*\-\s*(\d+)',numerando)[0]
				rys = parseDOM(ep, 'img', ret='src')[0] 
				rys  = re.sub('\-\d+x\d+','',rys )				
				rys = 'https:'+ rys if rys.startswith('//') else rys
				tyt1 = 'S%02dE%02d'%(int(ses),int(epis))
				tyt = '%s - [COLOR lightblue](%s)[/COLOR] [COLOR gold](%s)[/COLOR]'%(tytul,tyt1,tyt2)
				episodes.append({'title':PLchar(tyt),'url':PLchar(href),'image':rys,'plot':PLchar(opis),'season':int(ses),'episode':int(epis)})
			else:
				continue
	seasons = splitToSeasons(episodes)
	return seasons

def getVideo(url):
	out=[]
	html,kuks = gethtml.getRequests(url)
	stream_url=''

	stream_url = re.findall('a href="([^"]+)" class="link"',html)
	stream_url = stream_url[0] if stream_url else ''

	if stream_url:
		return stream_url,True
	return stream_url,'quit'
	

def ListContent2(url):
	fout=[]
	sout=[]
	headers = {
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Connection': 'keep-alive',
		'Upgrade-Insecure-Requests': '1',
		'TE': 'Trailers',}
	html,kuks = gethtml.getRequestsJson(url,headers=headers)

	for key, value in html.items():
		try:
			tytul = value.get('title','')
			imag = value.get('img',None)
			
			imag = re.sub('\-\d+x\d+','',imag)
			
			#
			year = value.get('year',None)
			href = value.get('url',None)
			if 'movies' in 	url:
				fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(tytul),'year':year,'genre':'', 'duration':'', 'mode2':'dudaplayer'})
			else:
				sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(tytul),'year':year,'code':'','genre':'', 'mode2':'dudaplayer'})
		except:
			pass
	return fout,sout

def ListContent3(url,page):
	fout=[]
	sout=[]
	npage=[]
	headers = {
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Connection': 'keep-alive',
		'Upgrade-Insecure-Requests': '1',
		'TE': 'Trailers',}
	if '/page/' in url:
		nturl = re.sub('page\/\\d+','page/%d'%(int(page)+1),url)
		url = re.sub('page\/\\d+','page/%d'%int(page),url)
	html,kuks = gethtml.getRequests(url,headers=headers)
	if html.find(nturl)>0:
		npage.append({'title':'Następna strona','url':nturl,'image':'','plot':'','page':int(page)+1})
	links = parseDOM(html,'div', attrs={'class': "result-item"})
	for link in links:
		href = parseDOM(link, 'a', ret='href')[0]
		imag = parseDOM(link, 'img', ret='src')[0]
		imag = 'https:'+ imag if imag.startswith('//') else imag
		tyt = parseDOM(link,'div', attrs={'class': "title"}) 
		if tyt:
			tytul = (parseDOM(tyt[0], 'a')[0])
		else:
			continue
		year = parseDOM(link,'span', attrs={'class': "year"})
		year = year[0] if year else ''

		opis = parseDOM(link,'p')
		opis = opis[0] if opis else tytul
		genre=''
		kateg=''
		trwa=''
		jak=''

		imag  = re.sub('\-\d+x\d+','',imag )
		if '/movies/' in 	href:
			fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'code':PLchar(jak),'genre':PLchar(kateg), 'duration':trwa, 'mode2':'dudaplayer'})
		else:
			sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'code':PLchar(jak),'genre':PLchar(kateg), 'mode2':'dudaplayer'})

	return fout,sout,npage
	
	
def getLitery(urltyp):

	url,typ = urltyp.split('|')
	html,kuks = gethtml.getRequests(url)
	out=[]
	nonc = re.findall('"nonce":"(.+?)"',html,re.DOTALL)[0]
	for term,litera in re.findall('data-type="%s" data-glossary="(.+?)">(.+?)<'%typ,html):
	#for litera in litery:
		k='https://dudeplayer.com/wp-json/dooplay/glossary/?term=%s&nonce=%s&type=%s'%(term,nonc,typ)
		out.append({'url':k, 'title':litera})
	return out
	
def getLitery2(urltyp):

	url,typ = urltyp.split('|')
	html,kuks = gethtml.getRequests(url)
	out=[]
	result = parseDOM(html,'nav', attrs={'class': "genres"})
	if typ == 'rok':
		result = parseDOM(html,'nav', attrs={'class': "releases"})
	if result:
		if typ == 'rok':
			for href,dan in re.findall('a href="(.+?)">(.+?)<',result[0]):
				href = href+'/' if not href.endswith('/') else href
				out.append({'url':href,'title':dan})
		else:
			for href,dan,ilo in re.findall('a href="(.+?)">(.+?)</a>\s*<i>(.+?)<',result[0]):
				dan+=' '+ilo
				href = href+'/' if not href.endswith('/') else href
				out.append({'url':href,'title':dan})

	return out	
def decodeDoodTo(stream_url,url):

	import math
	import random
	import time

	t="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
	def dood_decode(data):
		return data+''.join([t[int(math.floor(random.random() * 62))] for _ in range(10)])

	headersx = {
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Connection': 'keep-alive',
		'Referer': url,
		'Upgrade-Insecure-Requests': '1',
		'TE': 'Trailers',}
	html,kuks = gethtml.getRequests(stream_url,headers=headersx)
	matchx = re.findall("""['"](/pass_md5/.+?)['"]""",html)
	if matchx:
		url = 'https://dood.watch'+matchx[0]
	else:
		return ''
	match = re.search(r'''function\s*makePlay.+?return[^?]+([^"]+)[^/]+([^']+)''', html)

	token = match.group(1)

	headersx.update({'Referer': stream_url})

	html,kukz = gethtml.getRequests(url,headers=headersx) 

	hea= '&'.join(['%s=%s' % (name, value) for (name, value) in headersx.items()])	
	url=dood_decode(html) + token + str(int(time.time() * 1000))+'|'+hea
	return url
	
def szukcd(d):
	page=1
	fout=[]
	sout=[]
	url=basurl+'/?s='+d

	fout,sout,npage=ListContent(url,page)
	return fout,sout,npage
	
def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]

	if d:
		fout,sout,npage=szukcd(d)

	return fout,sout,npage
