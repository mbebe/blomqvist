# -*- coding: UTF-8 -*-
import sys,re,os
import geturl as gethtml
from geturl import PLchar as PLchar

if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus
    import urllib.parse as urlparse
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse

basurl='https://vizjer.pl/'
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'

def getFilmy(url,page):
	out=[]
	npage=[]
	try:
		if not url:
			url=basurl+'index.php'
		html,kuks = gethtml.getRequests(url)
	
		
		result = parseDOM(html,'td', attrs={'bgcolor': "#181818"})[2]
		links = parseDOM(result,'tbody')
		
		for link in links:
			dane=re.findall('<font size=".+?" color=".+?">([^<]+)<',link)
			href = parseDOM(link, 'a', ret='href')
			if href:
				href = href[0]
			else:
				continue
			src = parseDOM(link, 'img', ret='src')[0]
			imag = basurl+src
			href = basurl+href
			tyt = dane[0]
			rok,genre=dane[1].split('|')
			opis = dane[2]
			rodz = dane[6]
			out.append({'title':PLchar(tyt),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':rok,'code':rodz,'genre':genre,'mode2':'vizjerpl'})
	except:
		pass
	
	return out,npage

def ListCateg(co,rodz):

	label =["Akcja","Animowane","Biografie","Dokumentalne","Dramat","Familijne","Fantasy","Historyczne","Horror","Katastroficzne","Komedia","Kryminał","Muzyczne","Obyczajowy","Polskie","Przygodowe","Sci-Fi","Sensacyjne","Sport","Thriller","Wojenne"]
	value =["search.php?gatunek=Akcja&tabela=","search.php?gatunek=Animowane&tabela=","search.php?gatunek=Biografie&tabela=","search.php?gatunek=Dokumentalne&tabela=","search.php?gatunek=Dramat&tabela=","search.php?gatunek=Familijne&tabela=","search.php?gatunek=Fantasy&tabela=","search.php?gatunek=Historyczne&tabela=","search.php?gatunek=Horror&tabela=","search.php?gatunek=Katastroficzne&tabela=","search.php?gatunek=Komedia&tabela=","search.php?gatunek=Kryminał&tabela=","search.php?gatunek=Muzyczny&tabela=","search.php?gatunek=Obyczajowy&tabela=","search.php?gatunek=Polski&tabela=","search.php?gatunek=Przygodowe&tabela=","search.php?gatunek=Sci-Fi&tabela=","search.php?gatunek=Sensacyjne&tabela=","search.php?gatunek=Sport&tabela=","search.php?gatunek=Thriller&tabela=","search.php?gatunek=Wojenne&tabela="]
	nazwa = "Wybierz kategorię"
	if rodz=='alfabet':
		label =["0-9","A","B","C","D","E","F","G","H","I","J","K","L","Ł","M","N","O","P","R","S","T","U","V","W","Y","Z","Ż","Ź"]
		value =["searcha.php?litera=liczba&tabela=","searcha.php?litera=A&tabela=","searcha.php?litera=B&tabela=","searcha.php?litera=C&tabela=","searcha.php?litera=D&tabela=","searcha.php?litera=E&tabela=","searcha.php?litera=F&tabela=","searcha.php?litera=G&tabela=","searcha.php?litera=H&tabela=","searcha.php?litera=I&tabela=","searcha.php?litera=J&tabela=","searcha.php?litera=K&tabela=","searcha.php?litera=L&tabela=","searcha.php?litera=Ł&tabela=","searcha.php?litera=M&tabela=","searcha.php?litera=N&tabela=","searcha.php?litera=O&tabela=","searcha.php?litera=P&tabela=","searcha.php?litera=R&tabela=","searcha.php?litera=S&tabela=","searcha.php?litera=T&tabela=","searcha.php?litera=U&tabela=","searcha.php?litera=U&tabela=","searcha.php?litera=W&tabela=","searcha.php?litera=Y&tabela=","searcha.php?litera=Z&tabela=","searcha.php?litera=Ż&tabela=","searcha.php?litera=Ź&tabela="]
		nazwa=  "Wybierz literę"
	sel = gethtml.selectDialog(nazwa, label)
	if sel>-1:
		kategoria = basurl+value[sel]+co# if sel>-1 else ''
		return kategoria
	else:
		quit()
	
def getLinks(url):
	html,kuks = gethtml.getRequests(url)
	out=[]
	imgdiv = parseDOM(html,'div', attrs={'class': "entry\-content.+?"})[0]
	imag = (parseDOM(imgdiv, 'img', ret='src')[0]).strip()
	imag+='|User-Agent='+quote(UA)+'&Cookie='+quote(kuks)
	imag = 'http:'+ imag if imag.startswith('//') else imag
	result = parseDOM(html,'div', attrs={'id': "tab.+?",'class': "tab.+?"})[0]
	tyt = parseDOM(result,'h4')[0]
	tytul = re.findall('serial(.+?)online za',tyt)[0].strip(" ")
	links = parseDOM(result,'p')
	
	npage=[]
	for link in links:
		tyt2 = parseDOM(link, 'a')[0]
		hrefs = re.findall('a href ="(.+?)"',link)
		href = '|'.join([(x.strip()).lower() for x in hrefs]) if hrefs else ''
		tytul2 = '%s - %s'%(tytul,tyt2.replace('#',''))
		out.append({'title':PLchar(tytul2),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(tytul)})
	
	return out,npage
	
def ListSeriale(url,page):
	out=[]
	npage=[]
	try:
		if not url:
			url=basurl+'seriale.php'
		html,kuks = gethtml.getRequests(url)
	
		
		result = parseDOM(html,'td', attrs={'bgcolor': "#181818"})[2]
		links = parseDOM(result,'tbody')
		#npage=[]
	
		for link in links:
			dane=re.findall('<font size=".+?" color=".+?">([^<]+)<',link)
			href = parseDOM(link, 'a', ret='href')
			if href:
				href = href[0]
			else:
				continue
			src = parseDOM(link, 'img', ret='src')[0]
			imag = basurl+src
			href = basurl+href
			tyt = dane[0]
			genre=dane[1]
			opis = dane[2]
			rok = re.findall('(\d+)',tyt)
			rok = rok[-1] if rok else ''
			out.append({'title':PLchar(tyt),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':rok,'genre':genre})
	except:
		pass
	return out,npage

def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
def getSerial(url):

	html,kuks = gethtml.getRequests(url)
	danex = parseDOM(html,'td', attrs={'bgcolor': "#181818"})[2]
	dane=re.findall('<font size=".+?" color=".+?">([^<]+)<',danex)
	src = parseDOM(danex , 'img', ret='src')[0]
	imag = basurl+src
	tytul = dane[0]
	genre=dane[1]
	opis = dane[2]
	rok = re.findall('(\d+)',tytul)
	rok = rok[-1] if rok else ''
	episodes=[]
	result = re.findall('glosnie=(.+?)$',html,re.DOTALL)[0]
	result2 = parseDOM(result,'td')[0]
	
	links = parseDOM(result2,'tr')

	npage=[]
	for link in links:
		ses,href,epis=re.findall('>sezon\s*(\d+).+?href="([^"]+)".+?>odcinek\s*(\d+)',link,re.DOTALL+re.IGNORECASE)[0]
		href = basurl+href
		tyt = '%s - S%02dE%02d'%(tytul,int(ses),int(epis))
		episodes.append({'title':PLchar(tyt),'url':PLchar(href),'image':imag,'plot':PLchar(opis),'year':rok,'genre':genre,'season':int(ses[0]),'episode':int(epis[0]),'mode2':'vizjerpl'})
	seasons = splitToSeasons(episodes)
	return seasons
def szukcd(d):
	fout=[]
	sout=[]
	np1=[]
	np2=[]
	url=basurl+'searchf.php?szukaj='+d
	fout,np1=getFilmy(url,1)
	url=basurl+'searchs.php?szukaj='+d
	sout,np2=ListSeriale(url,1)
	return fout,sout
	
def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]
	if d:
		fout,sout = szukcd(d)
		#url=basurl+'searchf.php?szukaj='+d
		#fout,np1=getFilmy(url,1)
		#url=basurl+'searchs.php?szukaj='+d
		#sout,np2=ListSeriale(url,1)
	return fout,sout,npage

def getVideo(url):

	html,kuks = gethtml.getRequests(url)	
	stream_url = parseDOM(html, 'iframe', ret='src')#[0] 
	stream_url = stream_url[0] if stream_url else ''
	return stream_url,True
