# -*- coding: UTF-8 -*-
import sys,re,os
import geturl as gethtml
from geturl import PLchar as PLchar
import jsunpack

if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus
    import urllib.parse as urlparse
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse

basurl='https://cda-filmy.online/'
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'

def getLitery(url):
	html,kuks = gethtml.getRequests(url)
	out=[]

	for k, v in re.findall("""href=['"]([^"]+)['"]>([^<]+)<\/a><\/li>""", html,re.DOTALL):
		out.append({'url':k, 'title':v})# for k, v in re.findall("""href=['"](.+?)['"]>(.*?)<\a><""", html)})
	return out

def ListContent(url,page):
	npage=[]
	sout=[]
	fout=[]
	if 'Premiery' in url:
		dane = url
		url='https://wideo.site/'
	elif 'Popularne' in url:
		dane = url
		url='https://wideo.site/'
	elif 'Nowe sezony' in url:
		dane = url
		url='https://wideo.site/'
	else:
		url=url
		dane=''
	html,kuks = gethtml.getRequests(url)
	if dane:
		results = parseDOM(html,'section', attrs={'class': "section"})
		for result in results:
			if dane in result:
				links = parseDOM(result,'div', attrs={'class': "col\-\d+ col\-sm\-\d+ col\-md\-\d+ col\-lg\-\d+"})
				for link in links:
					href = parseDOM(link, 'a', ret='href')[0]
					tytul = parseDOM(link, 'a', ret='title')[0].replace('&amp;nbsp;',' ')
					imag = re.findall("""url\(['"](.+?)['"]""",link,re.DOTALL)[0]
					sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag)})	
				break
			else:
				continue
	else:
		links = parseDOM(html,'div', attrs={'class': "col\-\d+ col\-sm\-\d+ col\-md\-\d+ col\-lg\-\d+"})
		for link in links:
			href = parseDOM(link, 'a', ret='href')[0]

			tytul = parseDOM(link, 'a', ret='title')[0].replace('&amp;nbsp;',' ')
			imag = re.findall("""url\(['"](.+?)['"]""",link,re.DOTALL)[0]
			sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag)})	

	return fout,sout,npage

def SelectList(typ):

	label =["Akcja","Animacja","Dokumentalny","Dramat","Familijny","Fantasy","film TV","Historyczny","Horror","Komedia","Krótkometrażowy","Kryminał","Muzyczny","Premiery","Przygodowy","Romans","Sci-Fi","Sci-Fi &amp; Fantasy","Tajemnica","Thriller","Western","Wojenny"]
	value =["https://cda-filmy.online/gatunek/akcja/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/animacja/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/dokumentalny/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/dramat/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/familijny/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/fantasy/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/film-tv/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/historyczny/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/horror/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/komedia/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/krotkometrazowy/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/kryminal/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/muzyczny/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/premiery/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/przygodowy/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/romans/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/sci-fi/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/sci-fi-fantasy/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/tajemnica/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/thriller/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/western/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/wojenny/page/1/?tr_post_type="]
	nazwa = "Wybierz gatunek"

	sel = gethtml.selectDialog(nazwa, label)
	if sel>-1:
		dod='2' if 'ser' in typ else '1'
		kategoria = value[sel]+dod
		return kategoria
	else:
		quit()
		
def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
def getSerial(url):
	html,kuks = gethtml.getRequests(url)
	resultmain = parseDOM(html,'div', attrs={'class': "card-body"})[0]
	rys = parseDOM(resultmain, 'img', ret='src')[0]  
	rys = 'https:'+ rys if rys.startswith('//') else rys
	tytul = parseDOM(html,'h1')[0].replace("\n",' ')
	try:
		tytul=re.findall('i>(.+?)$',tytul,re.DOTALL)[0].strip()
	except:
		pass
	opis = parseDOM(resultmain,'p')
	opis = opis[0] if opis else ''

	sezony = parseDOM(html,'div', attrs={'class': "accordion"})
	episodes=[]
	for sezon in sezony:
		ses = re.findall('(\d+)',parseDOM(sezon,'h4')[0])
		ses = ses[0] if ses else '0'
		eps = re.findall('(<a.+?<\/a>)',sezon,re.DOTALL)
		for ep in eps:
			href = parseDOM(ep, 'a', ret='href')[0]  
			tyt2 = parseDOM(ep, 'a')[0].strip() 
			epis = re.findall('S\d+E(\d+)',tyt2,re.DOTALL)[0]
			tyt1 = 'S%02dE%02d'%(int(ses),int(epis))
			tyt = '%s - %s'%(tytul,tyt2)
			opis2 = parseDOM(ep, 'a', ret='title')
			if opis2:
				if not tyt1 in opis2[0]:
					opis = opis2[0]

			episodes.append({'title':PLchar(tyt),'url':PLchar(href),'image':rys,'plot':PLchar(opis),'season':int(ses),'episode':int(epis)})

	seasons = splitToSeasons(episodes)
	return seasons

def getVideo(url):
	out=[]
	html,kuks = gethtml.getRequests(url)
	stream_url=''
	typy = parseDOM(html,'li', attrs={'class': "nav-item dropdown list-inline-item"})#[0]
	for typ in typy:
		rodz = parseDOM(typ,'a')[0]
		strimy = re.findall('(<a.+?<\/a>)',typ,re.DOTALL)
		for strim in strimy:
			href = parseDOM(strim,'a', ret='data-src')#[0]
			if href:
				host = re.findall('\?domain\=(.+?)"',strim)[0]
				host='%s - %s'%(host,rodz)
				out.append({'href':href[0],'host':host})
			else:
				continue
	stream_url=''
	if out:
		if len(out) > 1:
			u = [ x.get('href') for x in  out]
			h = [ x.get('host') for x in  out]
			sel = gethtml.selectDialog("Źródło", h)
			nturl = out[sel].get('href') if sel>-1 else ''
			host= out[sel].get('host') if sel>-1 else ''#sources: ["
		else:
			nturl = out[0].get('href')
		if nturl:
			headers = {
				'User-Agent': UA,
				'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
				'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
				'Connection': 'keep-alive',
				'Referer': url,
				'Upgrade-Insecure-Requests': '1',
				'TE': 'Trailers',}
			html,kuks = gethtml.getRequests2(nturl,headers=headers)
			packer = re.compile(r'(eval\(function\(p,a,c,k,e,(?:r|d).*)')

			packed = packer.findall(html)
			ff=''
			if packed:
				packed =packed[0]

				html+= jsunpack.unpack(packed)

			html=html.replace("\\\'",'"')

			if 'clipwatching' in host or 'gounlim' in host:
				stream_url=re.findall('src:\s*"(.+?)"',html)
			elif 'vidspac' in host:
				sources=re.findall('sources:\s*\[(.+?)\]',html)
				stream_url=re.findall('"(.+?.mp4)"',sources[0])
			elif 'supervideo' in host or 'upstream' in host:
				sources=re.findall('sources:\s*\[(.+?)\]',html)
				stream_url=re.findall('file:"([^"]+)',sources[0])

			stream_url = stream_url[0] if stream_url else ''
			if 'm3u8' in stream_url or 'mp4' in stream_url:
				return stream_url,False
		else:
			return stream_url,'quit'
	return stream_url,True

def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]
	import json
	if d:
		if len(d)>=3:
			query = d[0:3]
			url='https://wideo.site/ajax/shows/data.json'
			datas,kuks=gethtml.getRequestsJson(url)
			for dt in sorted(datas, key = lambda dt: dt['title']):
				a='%s / %s (%s)'%(dt.values()[4],dt.values()[2],dt.values()[1])
				if query.lower() in a.lower():
					href ='https://wideo.site/shows/' + dt.values()[3] + '/' + dt.values()[0] + '.html'
					sout.append({'title':PLchar(a),'url':PLchar(href),'image':''})
		else:
			gethtml.notificationDialog(r'Uwaga', 'Powinny być min. 3 znaki')
	return fout,sout,npage

def szukcd(d):
	fout=[]
	sout=[]
	npage=[]
	if len(d)>=3:
		query = d[0:3]
		url='https://wideo.site/ajax/shows/data.json'
		datas,kuks=gethtml.getRequestsJson(url)
		for dt in sorted(datas, key = lambda dt: dt['title']):
			a='%s / %s (%s)'%(dt.values()[4],dt.values()[2],dt.values()[1])
			if query.lower() in a.lower():
				href ='https://wideo.site/shows/' + dt.values()[3] + '/' + dt.values()[0] + '.html'
				sout.append({'title':PLchar(a),'url':PLchar(href),'image':''})
	else:
		gethtml.notificationDialog(r'Uwaga', 'Powinny być min. 3 znaki')
	return fout,sout
def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]
	import json
	if d:
		fout,sout=szukcd(d)

	return fout,sout,npage
	
	
	