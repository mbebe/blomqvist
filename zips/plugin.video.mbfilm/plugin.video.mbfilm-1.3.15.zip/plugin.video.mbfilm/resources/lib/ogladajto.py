# -*- coding: UTF-8 -*-
import sys,re,os
import geturl as gethtml
from geturl import PLchar as PLchar

if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus
    import urllib.parse as urlparse
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse

basurl='https://www.ogladaj.to/'
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'

def ListContent(url,page):

	if '/strona' in url:
		nturl = re.sub('\/strona\d+','/strona%d'%(int(page)+1),url)
		url = re.sub('\/strona\d+','/strona%d'%int(page),url)
	else:
		nturl = url + '/strona%d' %(int(page)+1)
		url = url + '/strona%d' %int(page)	
	html,kuks = gethtml.getRequests(url)
	npage=[]
	fout=[]
	sout=[]

	try:
		pagination = parseDOM(html,'div', attrs={'class': "pagination"})[0]
		if pagination.find( '"strona%d"' %(int(page)+1))>-1:
			npage.append({'title':'Następna strona','url':nturl,'image':'','plot':'','page':int(page)+1})
	except:
		pass

	result = parseDOM(html,'div', attrs={'class': "item\-box"})
	result =result[0] if result else html
	links = parseDOM(result,'div', attrs={'class': "item\-col"})

	for link in links:
		link=link.replace('\r','').replace('\n','').replace('\t','')#\t\t\t\t\t\t
		href = parseDOM(link, 'a', ret='href')[0]
		opis = parseDOM(link, 'a', ret='data-tooltip')#[0]

		imag = parseDOM(link, 'img', ret='data-src')#[0]
		imag = imag[0] if imag else parseDOM(link, 'img', ret='src')[0]
		try:
			tytul = (parseDOM(link, 'h2')[0]).strip(' ')
		except:
			tytul = (parseDOM(link, 'h3')[0]).strip(' ')
		opis = opis[0] if opis else tytul

		year=re.findall('"year">(.+?)<',link)
		year=year[0] if year else ''
		
		genre = re.findall('category"><ul><li>([^>]+)<',link)
		kateg = genre[0] if genre else ''#','.join([(x.strip()).lower() for x in genre]) if genre else ''

		if '/serial' in 	href:
			sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'genre':PLchar(kateg)})

		else:
			fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'genre':PLchar(kateg)})	

	return fout,sout,npage

def SelectList(typ):

	label =["wszystkie","Akcja","Animowane","Biografie","Dla dzieci","Dokumentalne","Dramat","Erotyczne","Familijne","Fantastyka","Historyczne","Horror","Katastroficzne","Komedia","Kostiumowe","Kr�tkometra�owe","Kryminalne","Muzyczne","Obyczajowy","Polskie","Przygodowe","Romanse","Sci-Fi","Sensacyjne","Spektakle telewizyjne","Sport","Thriller","Western","Wojenne"]
	
	value =["https://www.ogladaj.to/filmy/strona1","https://www.ogladaj.to/gatunek/akcja/strona1","https://www.ogladaj.to/gatunek/animowane/strona1","https://www.ogladaj.to/gatunek/biografie/strona1","https://www.ogladaj.to/gatunek/dla-dzieci/strona1","https://www.ogladaj.to/gatunek/dokumentalne/strona1","https://www.ogladaj.to/gatunek/dramat/strona1","https://www.ogladaj.to/gatunek/erotyczne/strona1","https://www.ogladaj.to/gatunek/familijne/strona1","https://www.ogladaj.to/gatunek/fantastyka/strona1","https://www.ogladaj.to/gatunek/historyczne/strona1","https://www.ogladaj.to/gatunek/horror/strona1","https://www.ogladaj.to/gatunek/katastroficzne/strona1","https://www.ogladaj.to/gatunek/komedia/strona1","https://www.ogladaj.to/gatunek/kostiumowe/strona1","https://www.ogladaj.to/gatunek/krotkometrazowy/strona1","https://www.ogladaj.to/gatunek/kryminalne/strona1","https://www.ogladaj.to/gatunek/musical/strona1","https://www.ogladaj.to/gatunek/obyczajowy/strona1","https://www.ogladaj.to/gatunek/polskie/strona1","https://www.ogladaj.to/gatunek/przygodowe/strona1","https://www.ogladaj.to/gatunek/romanse/strona1","https://www.ogladaj.to/gatunek/sci-fi/strona1","https://www.ogladaj.to/gatunek/sensacyjne/strona1","https://www.ogladaj.to/gatunek/spektakle-telewizyjne/strona1","https://www.ogladaj.to/gatunek/sport/strona1","https://www.ogladaj.to/gatunek/thriller/strona1","https://www.ogladaj.to/gatunek/western/strona1","https://www.ogladaj.to/gatunek/wojenne/strona1"]
	
	nazwa = "Wybierz gatunek"

	sel = gethtml.selectDialog(nazwa, label)
	if sel>-1:
		kategoria = value[sel]# if sel>-1 else ''
		return kategoria
	else:
		quit()
def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
def getSerial(url):

	html,kuks = gethtml.getRequests(url)
	resultmain = parseDOM(html,'div', attrs={'class': "video__info-text"})[0]
	tytul = parseDOM(resultmain,'h1')[0]

	opis = parseDOM(resultmain,'p')
	opis = opis[0] if opis else ''

	sezony = parseDOM(html,'section', attrs={'class': "content-sec\s*\-six"})
	episodes=[]
	for sezon in sezony:
		try:
			tytsez = parseDOM(sezon,'h1', attrs={'class': "title"})
			ses = re.findall('Se(?:as|z)on\s*(\d+)',tytsez[0],re.IGNORECASE)
			ses = ses[0] if ses else '0'
			eps = parseDOM(sezon,'div', attrs={'class': "item-col"}) 
			for ep in eps:
				tyt2 = parseDOM(ep, 'h2')[0] 
				href = parseDOM(ep, 'a', ret='href')[0]  
				epis = re.findall('E(\d+)',tyt2,re.IGNORECASE)
				rys = parseDOM(ep, 'img', ret='data-src')#[0]
				rys = rys[0] if rys else parseDOM(ep, 'img', ret='src')[0]
				tyt1 = 'S%02dE%02d'%(int(ses),int(epis[0]))
				tyt = '%s - (%s) %s'%(tytul,tyt1,tyt2)
				episodes.append({'title':PLchar(tyt),'url':PLchar(href),'image':rys,'plot':PLchar(opis),'season':int(ses),'episode':int(epis[0])})
		except:
			pass
	seasons = splitToSeasons(episodes)
	return seasons

def getUploadit(url,ref):
	headers = {
			'User-Agent': UA,
			'X-Requested-With': 'XMLHttpRequest',
			'Connection': 'keep-alive',
			'Referer': ref,}

	html,kuks = gethtml.getRequests(url,headers=headers)

	src=re.findall('source src="([^"]+)',html)
	src =src[0] if src else ""
	src+='|User-Agent='+quote(UA)+'&Cookie='+quote(kuks) if src else ""
	return src
	
def getVideo(url):
	out=[]
	html,kuks = gethtml.getRequests(url)
	stream_url=''

	result = parseDOM(html,'div', attrs={'class': "video__inner-stage"}) 
	if result:
		result=result[0]
		stream_url = parseDOM(html, 'iframe', ret='src')
		stream_url = stream_url[0] if stream_url else ''
		if 'uploadit.' in stream_url:
			stream_url=getUploadit(stream_url,url)
	if 'mp4' in stream_url or 'm3u8' in stream_url:
		return stream_url,False
	else:
		return stream_url,True
def szukcd(d):
	fout=[]
	sout=[]
	np1=[]
	url='https://www.ogladaj.to/wyszukaj/'+d+'/strona1'
	fout,sout,np1=ListContent(url,1)

	return fout,sout
def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]

	if d:
		fout,sout=szukcd(d)
	return fout,sout,npage
