# -*- coding: UTF-8 -*-
import sys,re,os

import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc

PY3 = sys.version_info >= (3,0,0)

try:
    # For Python 3.0 and later
	from urllib.parse import parse_qsl, quote, urlencode

except ImportError:
    # Python 2
    from urlparse import parse_qsl
    from urllib import unquote, quote, urlencode

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.mbfilm')

xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LASTPLAYED, label2Mask = "%R, %P, %Y")

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile'))

if isinstance(DATAPATH, bytes):
    DATAPATH = DATAPATH.decode('utf-8')
if isinstance(PATH, bytes):
    PATH = PATH.decode('utf-8')
    
RESOURCES       = PATH+'/resources/'

FANART=RESOURCES+'../fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('name', None)
page = params.get('page','')
mcount= params.get('moviescount', None)
movie= params.get('movie', None)
rys= params.get('image', None)
try:
	opisb = eval(params.get('opisb', None))
except:
	opisb = params.get('opisb', None)
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'

def build_url(query):
    return base_url + '?' + urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=1,fanart=FANART,moviescount=0):
	list_item = xbmcgui.ListItem(label=name)

	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')
	#else:
	#	list_item.setProperty("IsPlayable", 'False')
	if not infoLabels:
		infoLabels={'title': name,'plot':name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': FANART})
	ok=xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page, 'moviescount' : moviescount,'movie':movie,'name':name,'image':image,'opisb':infoLabels}),			
		listitem=list_item,
		isFolder=folder)
	return ok

def home():
	add_item('film', '[B][COLOR khaki]cda-filmy.online[/COLOR][/B]', 'DefaultMovies.png', "menu:cdaonline", folder=True,fanart=RESOURCES+'fanart.png')

#	add_item('film', '[B][COLOR khaki]livenet.online[/COLOR][/B]', 'DefaultMovies.png', "menu:livenet", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film', '[B][COLOR khaki]ekino.pw[/COLOR][/B]', 'DefaultMovies.png', "menu:ekinopw", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film', '[B][COLOR khaki]vizjer.pl[/COLOR][/B]', 'DefaultMovies.png', "menu:vizjerpl", folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('film', '[B][COLOR khaki]cda-filmy.online[/COLOR][/B]', 'DefaultMovies.png', "menu:cdaonline", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film', '[B][COLOR khaki]rodzinnekino.com[/COLOR][/B]', 'DefaultMovies.png', "menu:rodzinne", folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('film', '[B][COLOR khaki]film.web4u2.pl[/COLOR][/B]', 'DefaultMovies.png', "menu:filmweb4u2", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film', '[B][COLOR khaki]watch-movies.pl[/COLOR][/B]', 'DefaultMovies.png', "menu:watchmovies", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film', '[B][COLOR khaki]z-net.live[/COLOR][/B]', 'DefaultMovies.png', "menu:znetlive", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film', '[B][COLOR khaki]filmeria.co[/COLOR][/B]', 'DefaultMovies.png', "menu:filmeriaco", folder=True,fanart=RESOURCES+'fanart.png')	
	add_item('film', '[B][COLOR khaki]filmninja.ws[/COLOR][/B]', 'DefaultMovies.png', "menu:filmninja", folder=True,fanart=RESOURCES+'fanart.png')	
	add_item('film', '[B][COLOR khaki]zalukaj.vip[/COLOR][/B]', 'DefaultMovies.png', "menu:zalukajvip", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film', '[B][COLOR khaki]wideo.site[/COLOR][/B]', 'DefaultMovies.png', "menu:wideosite", folder=True,fanart=RESOURCES+'fanart.png')
def splitToSeasons(input):
    out={}
    seasons = [x.get('season') for x in input]
    for s in set(seasons):
        out['Sezon %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
    return out	

def getEpisodes(seasons,mode2):
	episodes = eval(unquote(seasons))#[::-1]
	items=len(episodes)
	for f in episodes: 
		ses=f.get('season')
		epp=f.get('episode')
		tyt=f.get('title').split('Season')#[0]
		tyt2 = '%s - odc.%02d'%(name,epp)
		tyt = tyt[0] if tyt else tyt2
		add_item(name=tyt, url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot')}, itemcount=items)
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)	
	
def PlayVid(stream_url,adaptive=False):

	play_item = xbmcgui.ListItem(path=stream_url)
	play_item.setInfo(type="Video", infoLabels={"title": name,'plot':opisb['plot']})
	
	play_item.setArt({'thumb': rys, 'poster': rys, 'banner': rys, 'fanart': FANART})
	
	play_item.setProperty("IsPlayable", "true")
	if adaptive:
		play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
		play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
		play_item.setMimeType('application/vnd.apple.mpegurl')
		play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
		#play_item.setContentLookup(False)

	Player = xbmc.Player()
	Player.play(stream_url, play_item)

def import_mod(s):
	mod = {}
	if   s == 'livenet': import livenet     as mod
	elif s == 'ekinopw': import ekinopw     as mod
	elif s == 'vizjerpl': import vizjerpl    as mod
	elif s == 'cdaonline': import cdaonline   as mod
	elif s == 'rodzinne': import rodzinne    as mod
	elif s == 'watchmovies': import watchmovies as mod
	elif s == 'filmweb4u2': import filmweb4u2  as mod
	elif s == 'znetlive': import znetlive    as mod
	elif s == 'filmeriaco': import filmeriaco  as mod
	elif s == 'filmninja': import filmninja  as mod
	elif s == 'zalukajvip': import zalukajvip  as mod
	elif s == 'wideosite': import wideosite  as mod
	
	return mod
def import_menu(s):
	mod = {}
	if   s == 'livenet': import livenet     as mod
	elif s == 'ekinopw': mod = ekinopwMenu(s)
	elif s == 'vizjerpl': mod = vizjerplMenu(s)
	elif s == 'cdaonline': mod = cdaonlineMenu(s)
	elif s == 'rodzinne': mod = rodzinneMenu(s)
	elif s == 'zalukajvip': mod = zalukajvipMenu(s)
	elif s == 'watchmovies': mod = watchmoviesMenu(s)
	elif s == 'filmweb4u2': import filmweb4u2  as mod
	elif s == 'znetlive':   mod = znetliveMenu(s)
	elif s == 'filmeriaco': mod = filmeriacoMenu(s)
	elif s == 'filmninja': mod = filmninjaMenu(s)
	elif s == 'wideosite': mod = wideositeMenu(s)

	return mod
	
def cdaonlineMenu(str):
	add_item('https://cda-filmy.online/filmy-online/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film', '[B][COLOR khaki]-   gatunek[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://cda-filmy.online/seriale-online/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('serial', '[B][COLOR khaki]-   gatunek[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	
	
def ekinopwMenu(str):
	add_item('', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "SimplelistFilmy:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "SimplelistSeriale:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	
def filmninjaMenu(str):	
	import kurw
	kurw.abc()
	add_item('https://filmninja.ws/filmy-online/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filmninja.ws/seriale-online/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filmninja.ws/dla-dzieci/', '[B][COLOR khaki]Dla dzieci[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filmninja.ws/darmowa-telewizja-online', '[B][COLOR khaki]Telewizja[/COLOR][/B]', 'DefaultTVShows.png', "ListTV", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

def watchmoviesMenu(str):
	add_item('https://watch-movies.pl/movies/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://watch-movies.pl/tvshows/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('gatunek', '[B][COLOR khaki]-   gatunek[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('rok', '[B][COLOR khaki]-   rok wydania[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	
def vizjerplMenu(str):
	add_item('', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "SimplelistFilmy:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]-   Kategorie[/COLOR][/B]', 'DefaultMovies.png', "listCategoryfilm:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('alfabet', '[B][COLOR khaki]-   Spis alfabetyczny[/COLOR][/B]', 'DefaultMovies.png', "listCategoryfilm:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "SimplelistSeriale:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]-   Kategorie[/COLOR][/B]', 'DefaultMovies.png', "listCategoryserial:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('alfabet', '[B][COLOR khaki]-   Spis alfabetyczny[/COLOR][/B]', 'DefaultMovies.png', "listCategoryserial:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
		
def znetliveMenu(str):
	add_item('', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "SimplelistFilmy:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "SimplelistSeriale:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	
def filmeriacoMenu(str):
	add_item('', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "SimplelistFilmy:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "SimplelistSeriale:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')


def rodzinneMenu(str):
	add_item('https://rodzinnekino.com/film/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://rodzinnekino.com/seriale/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://rodzinnekino.com/kraj/polska/', '[B][COLOR khaki]Polska[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('gatunek', '[B][COLOR khaki]-   gatunek[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('kraj', '[B][COLOR khaki]-   kraj[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('wersja', '[B][COLOR khaki]-   wersja[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('rok', '[B][COLOR khaki]-   rok wydania[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

def zalukajvipMenu(str):
	add_item('https://zalukaj.vip/movies/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('filmy', '[B][COLOR khaki]Szukaj filmów[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('gatunek', '[B][COLOR khaki]-   gatunek[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('rok', '[B][COLOR khaki]-   rok wydania[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zalukaj.vip/serie-filmowe/', '[B][COLOR khaki]Serie filmowe[/COLOR][/B]', 'DefaultMovies.png', "ListSerieF1", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zalukaj.vip/tv-shows-2/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('seriale', '[B][COLOR khaki]Szukaj seriali[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	
def wideositeMenu(str):
	add_item('Premiery', '[B][COLOR khaki]Premiery[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('Nowe sezony', '[B][COLOR khaki]Nowe sezony[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('Popularne', '[B][COLOR khaki]Popularne[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://wideo.site/shows.html', '[B][COLOR khaki]Lista alfabetyczna[/COLOR][/B]', 'DefaultTVShows.png', "ListAlfabet", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('seriale', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	
def busy():

    if float(xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')[:4]) > 17.6:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    else:
        xbmc.executebuiltin('ActivateWindow(busydialog)')	
def idle():

    if float(xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')[:4]) > 17.6:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    else:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
def router(paramstring):
	params = dict(parse_qsl(paramstring))
	if params:
		mode = params.get('mode', None)
		
		if 'SimplelistFilmy' in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			
			links,pagin = mod.getFilmy(exlink,page)
			items = len(links)
			for f in links:
				
				add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items)
			if pagin:
				for f in pagin:	
					add_item(name=f.get('title'), url=f.get('url'), mode='SimplelistFilmy:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
			xbmcplugin.setContent(addon_handle, 'movies')		
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif 'SimplelistSeriale' in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			links,pagin = mod.ListSeriale(exlink,page)
			items = len(links)
			mud = 'getSimpleSeasons:%s'%mode2
			if mode2=='filmeriaco':
				mud = 'getLinksfilmeriaco'
				
			for f in links:
				
				add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items)
			if pagin:
				for f in pagin:	
					add_item(name=f.get('title'), url=f.get('url'), mode='SimplelistSeriale:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
			xbmcplugin.setContent(addon_handle, 'tvshows')		
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif 'listCategory' in mode:
			mode2 = mode.split(':')[1]
			co='film' if 'film' in mode else 'serial'
			mod = import_mod(mode2)
			kategoria = mod.ListCateg(co,exlink)
			if co=='serial':
			
			
				links,pagin = mod.ListSeriale(kategoria,page)
				items = len(links)
				mud = 'getSimpleSeasons:%s'%mode2
				for f in links:
					
					add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items)
				if pagin:
					for f in pagin:	
						add_item(name=f.get('title'), url=f.get('url'), mode='SimplelistSeriale:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
				xbmcplugin.setContent(addon_handle, 'tvshows')	
			else:
				links,pagin = mod.getFilmy(kategoria,page)
				items = len(links)
				for f in links:
					
					add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=True, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items)
				if pagin:
					for f in pagin:	
						add_item(name=f.get('title'), url=f.get('url'), mode='SimplelistFilmy:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
				xbmcplugin.setContent(addon_handle, 'movies')		
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif 'SimplelistSearch' in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			flinks,slinks,pagin = mod.ListSearch(exlink,page)
			if flinks or slinks:
				items1 = len(flinks)
				items2 = len(slinks)
				mud = 'getSimpleSeasons:%s'%mode2
				if mode2=='filmeriaco':
					mud = 'getLinksfilmeriaco'
				if slinks:
					for f in slinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items2)
					xbmcplugin.setContent(addon_handle, 'tvshows')	
				if flinks:
					for f in flinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1)
					xbmcplugin.setContent(addon_handle, 'movies')
				if pagin:

					for f in pagin:	
						mud2 = 'SimplelistSeriale:%s'%mode2
						if 'cda-filmy' in f.get('url') or 'zalukaj' in f.get('url') :
							mud2 = 'ListContent:%s'%mode2
						add_item(name=f.get('title'), url=f.get('url'), mode=mud2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
					
				xbmcplugin.endOfDirectory(addon_handle)
			elif not flinks and not slinks:
				return
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)

		elif 'getSimpleSeasons'in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			seasons=mod.getSerial(exlink)	
			if seasons:
				items = len(seasons)
				for i in sorted(seasons.keys()):
					opis=(seasons[i])[0].get('plot')
					add_item(name=name+' - '+i, url=quote(str(seasons[i])), mode='getEpisodes:%s'%mode2, image=rys, folder=True,  infoLabels={'plot':opis}, itemcount=items)	

				xbmcplugin.setContent(addon_handle, 'tvshows')
				xbmcplugin.endOfDirectory(addon_handle)	
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak odcinków do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
		elif 'getEpisodes'in mode:
			mode2 = mode.split(':')[1]
			getEpisodes(exlink,mode2)
			
		elif 'menu' in mode:
			mode2 = mode.split(':')[1]
			mod = import_menu(mode2)
			mod
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif 'getVid' in mode:
			#busy()
			
			adapt=False
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			#idle()
			stream_url,resolve = mod.getVideo(exlink)

			if resolve and stream_url:
				import cdapl 
				if 'cda.pl' in stream_url:
					stream_url = cdapl.getLinkCda(stream_url)
					if len(stream_url)==1:
						stream_url = stream_url[0][0]
					else:
						if type(stream_url) is list:
							qual = [x[1] for x in stream_url]
							select = xbmcgui.Dialog().select('Wybierz jakość (cda)', qual)
							
							if select>-1:
								stream_url = stream_url[select][0]
							else:
								
								stream_url=''
								quit()
				else:
					import resolveurl
					if 'hqq.' in stream_url or 'waaw.' in stream_url:
						import ekinopw
						stream_url=ekinopw.getHqq(stream_url)
					elif 'upvideo.cc' in stream_url:
						import zalukajvip
						stream_url=zalukajvip.getUpvideocc(stream_url)
						if stream_url=='quit':
							quit()
						adapt=False
					else:
						try:
							stream_url = resolveurl.resolve(stream_url)

						except Exception as e:
							stream_url=''
				
			if stream_url:
				PlayVid(stream_url,adapt)
			else:
				if resolve=='quit':
					quit()
				else:
					xbmcgui.Dialog().notification('[B]Link nie działa[/B]', 'Spróbuj inny',xbmcgui.NOTIFICATION_INFO, 6000,False)
			
		elif mode == 'getLinksfilmeriaco':
			import filmeriaco  as mod
			links,pags= mod.getLinks(exlink)
			items = len(links)
			for f in links:
				add_item(name=f.get('title'), url=f.get('url'), mode='getVid:filmeriaco', image=f.get('image'), folder=False, IsPlayable=True, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('jak')}, itemcount=items)
			xbmcplugin.setContent(addon_handle, 'videos')		
			xbmcplugin.endOfDirectory(addon_handle)
			
			
		elif mode == 'ListAlfabet':
			import wideosite
			litery = wideosite.getLitery(exlink)
			items = len(litery)
			if items>1:
				for f in litery:
					add_item(name=f.get('title'), url=f.get('url'), mode='ListContent:wideosite', image='', folder=True)
				xbmcplugin.setContent(addon_handle, 'videos')		
				xbmcplugin.endOfDirectory(addon_handle)
		elif mode == 'ListSerieF1':
			import zalukajvip
			series = zalukajvip.getSerieF(exlink)
			items = len(series)
			if items>1:
				for f in series:
					add_item(name=f.get('title'), url=f.get('url'), mode='ListSerieContent', image=f.get('image'), folder=True)
				xbmcplugin.setContent(addon_handle, 'videos')		
				xbmcplugin.endOfDirectory(addon_handle)

		elif mode == 'ListSerieContent':
			import zalukajvip
			links = zalukajvip.ListSerieContent(exlink)
			items = len(links)
			if items>1:
				for f in links:
					add_item(name=f.get('title'), url=f.get('url'), mode='getVid:zalukajvip', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('jak')}, itemcount=items)
				xbmcplugin.setContent(addon_handle, 'videos')		
				xbmcplugin.endOfDirectory(addon_handle)

				
		elif mode == 'ListTV':
			import filmninja  as mod
			links = mod.getTV(exlink)
			items = len(links)
			for f in links:
				add_item(name=f.get('title'), url=f.get('url'), mode='PlayTv', image=f.get('image'), folder=False, IsPlayable=False, infoLabels=False, itemcount=items)
			xbmcplugin.setContent(addon_handle, 'movies')
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif mode == 'PlayTv':
			busy()
			import filmninja  as mod
			stream_url,resol = mod.PlayTv(exlink)
			idle()
			if stream_url:
				PlayVid(stream_url)
			else:
				xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Brak działającego linka.',xbmcgui.NOTIFICATION_INFO, 6000,False)
				
		elif 'SelectList' in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			url = mod.SelectList(exlink)
			if url:
				flinks,slinks,pagin = mod.ListContent(url,page)
			if flinks or slinks:
				items1 = len(flinks)
				items2 = len(slinks)
				mud = 'getSimpleSeasons:%s'%mode2
				if slinks:
					for f in slinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items2)
					xbmcplugin.setContent(addon_handle, 'tvshows')	
				if flinks:
					for f in flinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1)
					xbmcplugin.setContent(addon_handle, 'movies')
				if pagin:
					for f in pagin:	
						add_item(name=f.get('title'), url=f.get('url'), mode='ListContent:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
					
				xbmcplugin.endOfDirectory(addon_handle)
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)

		elif 'ListContent' in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			flinks=[]
			slinks=[]
			pagin=[]
			flinks,slinks,pagin = mod.ListContent(exlink,page)
			if flinks or slinks:
				items1 = len(flinks)
				items2 = len(slinks)
				mud = 'getSimpleSeasons:%s'%mode2
				if slinks:
					for f in slinks:
						dd=f.get('plot') if f.get('plot') else f.get('title')
						add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':dd,'title': f.get('title')}, itemcount=items2)
					xbmcplugin.setContent(addon_handle, 'tvshows')	
				if flinks:
					for f in flinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1)
					xbmcplugin.setContent(addon_handle, 'movies')
				if pagin:
					for f in pagin:	
						add_item(name=f.get('title'), url=f.get('url'), mode='ListContent:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
					
				xbmcplugin.endOfDirectory(addon_handle)
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)

	else:
		home()
		xbmcplugin.endOfDirectory(addon_handle)	
if __name__ == '__main__':
    router(sys.argv[2][1:])
