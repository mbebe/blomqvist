# -*- coding: UTF-8 -*-
import sys,re,os
import geturl as gethtml
from geturl import PLchar as PLchar

if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus
    import urllib.parse as urlparse
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse

basurl='https://cda-filmy.online/'
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'

def ListContent(url,page):
	
	if '/page/' in url:
		nturl = re.sub('page\/\\d+','page/%d'%(int(page)+1),url)
		url = re.sub('page\/\\d+','page/%d'%int(page),url)
	else:
		nturl = url + 'page/%d' %(int(page)+1)
		url = url + 'page/%d' %int(page)
		
	html,kuks = gethtml.getRequests(url)
	npage=[]
	fout=[]
	sout=[]
	if html.find(nturl)>-1:
		npage.append({'title':'Następna strona','url':nturl,'image':'','plot':'','page':int(page)+1})

	result = parseDOM(html,'div', attrs={'id': "archive-content"})
	result =result[0] if result else html
	links = parseDOM(result,'article', attrs={'id': "post\-.+?"})
	if 'seriale-online' in url:
		links = parseDOM(result,'article', attrs={'class': ".+?ost C"})
	for link in links:
		href = parseDOM(link, 'a', ret='href')[0]
		imag = parseDOM(link, 'img', ret='src')[0]
		imag = 'https:'+ imag if imag.startswith('//') else imag
		try:
			tytul = (parseDOM(link, 'h4')[0]).strip(' ')
		except:
			tytul = (parseDOM(link, 'h3')[0]).strip(' ')
		
		if '<h2>' in tytul:
			tytul = (tytul.split('<h2>')[0]).strip(' ')
		opis = parseDOM(link,'div', attrs={'class': "Description"})
		opis = parseDOM(opis[0], 'p')[0] if opis else tytul
		year = parseDOM(link,'span', attrs={'class': "Year"})
		year = year[0] if year else ''
		genre = re.findall('rel="tag">([^>]+)<',link)
		kateg = ','.join([(x.strip()).lower() for x in genre]) if genre else ''
		jak = parseDOM(link,'span', attrs={'class': "Qlty"})
		jak = jak[0] if jak else ''
		if '/film/' in 	href:
			fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'code':PLchar(jak)})	
		else:
			sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'code':PLchar(jak)})

	return fout,sout,npage

def SelectList(typ):

	label =["Akcja","Animacja","Dokumentalny","Dramat","Familijny","Fantasy","film TV","Historyczny","Horror","Komedia","Krótkometrażowy","Kryminał","Muzyczny","Premiery","Przygodowy","Romans","Sci-Fi","Sci-Fi &amp; Fantasy","Tajemnica","Thriller","Western","Wojenny"]
	value =["https://cda-filmy.online/gatunek/akcja/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/animacja/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/dokumentalny/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/dramat/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/familijny/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/fantasy/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/film-tv/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/historyczny/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/horror/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/komedia/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/krotkometrazowy/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/kryminal/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/muzyczny/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/premiery/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/przygodowy/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/romans/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/sci-fi/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/sci-fi-fantasy/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/tajemnica/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/thriller/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/western/page/1/?tr_post_type=","https://cda-filmy.online/gatunek/wojenny/page/1/?tr_post_type="]
	nazwa = "Wybierz gatunek"

	sel = gethtml.selectDialog(nazwa, label)
	if sel>-1:
		dod='2' if 'ser' in typ else '1'
		kategoria = value[sel]+dod
		return kategoria
	else:
		quit()
		
def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
def getSerial(url):
	html,kuks = gethtml.getRequests(url)
	resultmain = parseDOM(html,'article', attrs={'class': "TPost Single"})[0]
	tytul = parseDOM(resultmain,'h1')[0]
	opisy = parseDOM(html,'div', attrs={'class': "Description"})[0]
	opis = parseDOM(opisy,'p')
	opis = opis[0] if opis else ''
	sezony = parseDOM(html,'div', attrs={'class': "Wdgt AABox"})
	episodes=[]
	for sezon in sezony:

		ses= parseDOM(sezon,'div', attrs={'class': "Title AA-Seas.+?","data-tab":"\d+"},ret="data-tab")
		ses = ses[0] if ses else '0'
		eps = parseDOM(sezon,'tr')
		for ep in eps:
			ep = ep.replace('&lt;','<').replace('&quot;','"').replace('&gt;','>')
			hrefy = parseDOM(ep,'td', attrs={'class': "MvTbTtl"})
			if hrefy:
				href = parseDOM(hrefy, 'a', ret='href')[0]  
				tyt2 = parseDOM(hrefy, 'a')[0]  
				epis = parseDOM(ep,'span', attrs={'class': "Num"})[0]
				rys = parseDOM(ep, 'img', ret='src')[0]  
				rys = 'https:'+ rys if rys.startswith('//') else rys
				tyt1 = 'S%02dE%02d'%(int(ses),int(epis[0]))
				tyt = '%s - (%s) %s'%(tytul,tyt1,tyt2)
				episodes.append({'title':PLchar(tyt),'url':PLchar(href),'image':rys,'plot':PLchar(opis),'season':int(ses),'episode':int(epis[0])})
			else:
				continue
	seasons = splitToSeasons(episodes)
	return seasons

def getVideo(url):
	out=[]
	html,kuks = gethtml.getRequests(url)
	stream_url=''
	typy = parseDOM(html,'ul', attrs={'class': "TPlayerNv"})[0]
	player = parseDOM(html,'div', attrs={'class': "TPlayer"})[0]#<div class="TPlayer">
	player = player.replace('&lt;','<').replace('&quot;','"').replace('&gt;','>').replace('&amp;','&').replace('#038;','')

	dane = re.findall('data-tplayer.+?="([^"]+)"><span>.+?</span><span>(.+?)<\/span><\/li>',typy)

	for d1, d2 in dane:
		href = re.findall('"'+d1+'".+?src="([^"]+)"',player)[0]
		out.append({'href':href,'host':d2})
	stream_url=''
	if out:
		if len(out) > 1:
			u = [ x.get('href') for x in  out]
			h = [ x.get('host') for x in  out]
			sel = gethtml.selectDialog("Źródło", h)
			nturl = out[sel].get('href') if sel>-1 else ''
		else:
			nturl = out[0].get('href')
		if nturl:
			headers = {
				'User-Agent': UA,
				'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
				'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
				'Connection': 'keep-alive',
				'Referer': url,
				'Upgrade-Insecure-Requests': '1',
				'TE': 'Trailers',}
			html,kuks = gethtml.getRequests(nturl,headers=headers)

			stream_url = parseDOM(html, 'iframe', ret='src')
			stream_url = stream_url[0] if stream_url else ''
		else:
			return stream_url,'quit'
	return stream_url,True

def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]

	if d:
		url=basurl+'page/1/?s='+d
		fout,sout,npage=ListContent(url,page)

	return fout,sout,npage
