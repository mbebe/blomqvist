# -*- coding: utf-8 -*-

#'\nCreated on Thu Feb 11 18:47:43 2016\n\n@author: ramic\n'
import requests
import re
import jsunpack as jsunpack
import sys
import string

if sys.version_info >= (3,0,0):
# for Python 3
    from urllib.parse import unquote
    import urllib.parse as urlparse
else:
    # for Python 2
    from urllib import unquote


BASEURL='https://www.cda.pl'
TIMEOUT = 5
PY3 = sys.version_info[0] == 3
if PY3:
    rot13 = str.maketrans(
        "ABCDEFGHIJKLMabcdefghijklmNOPQRSTUVWXYZnopqrstuvwxyz",
        "NOPQRSTUVWXYZnopqrstuvwxyzABCDEFGHIJKLMabcdefghijklm")
else:
    rot13 = string.maketrans(
        "ABCDEFGHIJKLMabcdefghijklmNOPQRSTUVWXYZnopqrstuvwxyz",
        "NOPQRSTUVWXYZnopqrstuvwxyzABCDEFGHIJKLMabcdefghijklm")

def getUrl(url,data=None,cookies=None):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',}
    link=requests.get(url,verify=False,headers=headers).content
    if PY3:
        link = link.decode(encoding='utf-8', errors='strict')
    return link
def _videoLink(content):
	src =''
	evals = re.compile('eval(.*?)\\{\\}\\)\\)',re.DOTALL).findall(content)
	if evals:
		for eval in evals:
			eval=re.sub('  ',' ',eval)
			eval=re.sub('\n','',eval)
			try:
				unp = jsunpack.unpack(eval)
			except:
				unp=''
			if unp:
				unp=re.sub('\\\\','',unp)
				match = re.compile('["\']*file["\']*\\s*:\\s*["\'](.+?)["\'],',  re.DOTALL).search(content)
				match2 = re.compile('["\']file["\']:["\'](.*?\\.mp4)["\']',  re.DOTALL).search(content)
				if match:   src = match.group(1)
				elif match2: src = match2.group(1)
				if src:
					break
	else:
		match = re.compile('["\']*file["\']*\\s*:\\s*["\'](.+?)["\'],',  re.DOTALL).search(content)
		match2 = re.compile('["\']file["\']:["\'](.*?\\.mp4)["\']',  re.DOTALL).search(content)
		if match:   src = match.group(1)
		elif match2: src = match2.group(1)
	return src

def getLinkCda(url):
#  "\n	returns \n		- ulr http://....\n		- or list of [('720p', 'http://www.cda.pl/video/1946991f?wersja=720p'),...]\n		 \n	"
	added='|Cookie=PHPSESSID=1&Referer=http://static.cda.pl/flowplayer/flash/flowplayer.commercial-3.2.18.swf'
	url=url.split('?wersja=')
	try:
		ab=url[0].replace('http://www.cda','https://www.cda')
	except:
		ab=''
	content = getUrl(ab)
	out=[]
	def cdadecode(videofile):
		a = videofile
		cc =len(a)
		linkvid=''
		for e in range(cc):
			f = ord(a[e])
			if f >=33 or f <=126:
				b=chr(33 + (f + 14) % 94)
			else:
				b=chr(f)
			linkvid+=b
		linkvid=linkvid[:-4]
		if not linkvid.endswith('.mp4'):
			linkvid += '.mp4'
			linkvid = linkvid.replace("0)sss.mp4", ".mp4")  
			linkvid = linkvid.replace(".cda.mp4", "").replace(".cda.mp4", "").replace(".2cda.pl", ".cda.pl").replace(".3cda.pl", ".cda.pl");
		
		if not linkvid.startswith('http'):
			linkvid = 'https://'+linkvid
		return linkvid
	if not'Trwa konwersja wgranego' in content and not 'ten link zosta' in content:
		qua = re.compile('a data-quality="(.*?)"(.*?)</div>', re.DOTALL).findall(content)
		if qua:
			srce = re.compile('href="(.*?)"', re.DOTALL).findall(qua[0][1])[::-1]
			for h1 in srce:
				h1=BASEURL+h1 if not h1.startswith('http') else h1
				content2 = getUrl(h1)	
				
				un=_videoLink(content2)
	
				un = cdadecode(unquote(un))		
				un+=added
				h1=h1.split('wersja=')				
				out.append((un,h1[1]))
		else:
			un=_videoLink(content)
			
			un = cdadecode(unquote(un))		
			un+=added
			h1=('max','max')#.split('wersja=')				
			out.append((un,h1[1]))
	else:
		out='trwa konwersja'
	return out
