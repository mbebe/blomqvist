# -*- coding: UTF-8 -*-
import sys,re,os
import geturl as gethtml
from geturl import PLchar as PLchar
#import web_pdb
pliki =['cdaonline','rodzinne','vizjerpl','ekinopw','filmeriaco','watchmovies','videosite']
pliki =['rodzinne','vizjerpl','filmeriaco','watchmovies','videosite','znetlive']
if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus
    import urllib.parse as urlparse
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse

	
def import_mod(s):
	mod = {}
	if   s == 'livenet': import livenet     as mod
	elif s == 'ekinopw': import ekinopw     as mod
	elif s == 'vizjerpl': import vizjerpl    as mod
	elif s == 'cdaonline': import cdaonline   as mod
	elif s == 'rodzinne': import rodzinne    as mod
	elif s == 'watchmovies': import watchmovies as mod
	elif s == 'filmweb4u2': import filmweb4u2  as mod
	elif s == 'znetlive': import znetlive    as mod
	elif s == 'filmeriaco': import filmeriaco  as mod
	elif s == 'filmninja': import filmninja  as mod
	elif s == 'zalukajvip': import zalukajvip  as mod
	elif s == 'wideosite': import wideosite  as mod
	
	return mod
	
	
def Przeszukuj():
	outf1=[]
	outs1=[]
	pp=[]
	
	d = gethtml.inputDialog(b'Szukaj...')
	if d:
		for host in pliki:
			mod = import_mod(host)
			try:
				outf,outs = mod.szukcd(d)
				for of1 in outf:
					outf1.append(of1)
				for os1 in outs:
					outs1.append(os1) 
			except:
				pass
	return outf1,outs1
