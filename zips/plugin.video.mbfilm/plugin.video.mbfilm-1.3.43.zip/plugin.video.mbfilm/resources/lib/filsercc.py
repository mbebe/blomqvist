# -*- coding: UTF-8 -*-

import sys,re,os
import geturl as gethtml
from geturl import PLchar as PLchar
import xbmc, xbmcaddon, xbmcvfs
import json
addon = xbmcaddon.Addon(id='plugin.video.mbfilm')

PATH            = addon.getAddonInfo('path')
RESOURCES	   = PATH+'/resources/'

icona=RESOURCES+'../fanart.jpg'


#icona=RESOURCES+'../icon.png'
if sys.version_info >= (3,0,0):
	DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
else:
	DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')



if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus

    import http.cookiejar as cookielib
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus

    import cookielib

from requests.compat import urlparse

basurl='https://zenu.cc'
UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0'

def checkNpage(url,typ, page):
	head = {
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer':url
	
	}
	html,kuks = gethtml.getRequestsJson(url, headers = head)
	
	#web_pdb.set_trace()
	jsdata = html.get('full', None)
	if jsdata:
		return [{'title':'Następna strona','url':typ,'image':'','plot':'','page':int(page)+1}]
	else:
		return []
def ListContent(url, page):
	head = {
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer':url
	
	}
	data = addon.getSetting('fdata') if 'filmy' in url else addon.getSetting('sdata')	
	urlmain = 'https://filser.cc/api/search/'+ data #f =  addon.getSetting('fdata')	
	#web_pdb.set_trace()
	page = int(page)-1
	if '&page=' in urlmain:
		nturl = re.sub('\&page\=\d+','&page=%d'%(int(page)+1),urlmain)
		urlmain = re.sub('\&page\=\d+','&page=%d'%int(page),urlmain)
	#else:
	#	nturl = url + 'page/%d' %(int(page)+1)
	#	url = url + 'page/%d' %int(page)
	
	
	
	npage=checkNpage(nturl, url, page)#[]
	fout=[]
	sout=[]

	html,kuks = gethtml.getRequestsJson(urlmain, headers = head)
	
	
	jsdata = html.get('full', None)
	for link in jsdata:
		try:
			tytul = link.get('title_name', None)
			href = link.get('title_id', None)
			imag = link.get('img_boxart', None)
			imag = imag if imag else icona
			opis = link.get('title_desc', None)
			opis = opis if opis else tytul
			year = link.get('inf_year', None)
			durat = link.get('inf_duration', None)
			durat = durat if durat else '0'
			quality = link.get('quality', None)
			quality = quality if quality else ''
			inf_type = link.get('inf_type', None)
			if 'movie' in inf_type:
				fout.append({'title':tytul,'url':PLchar(href),'image':PLchar(imag),'plot':opis,'year':year, 'duration':int(durat), 'code':quality})
			else:
				sout.append({'title':tytul,'url':PLchar(href),'image':PLchar(imag),'plot':opis,'year':year, 'duration':int(durat), 'code':quality})
		except:
			#web_pdb.set_trace()
			pass
	#if html.find(nturl)>-1:
	#	npage.append({'title':'Następna strona','url':nturlx,'image':'','plot':'','page':int(page)+1})
	
#	result = parseDOM(html,'div', attrs={'class': "items"})#[0]
#	result = result[0] if result else html
#	ids = [(a.start(), a.end()) for a in re.finditer('<article', result)]
#	ids.append( (-1,-1) )
#
#	
#	for i in range(len(ids[:-1])):
#		subset = result[ ids[i][1]:ids[i+1][0]]
#		imag = parseDOM(subset, 'img', ret='src')[0]
#		imag = basurl+ imag if imag.startswith('/') else imag
#		dt = parseDOM(subset,'div', attrs={'class': "data"})[0]
#		href = parseDOM(dt, 'a', ret='href')[0]
#		href = basurl+ href if href.startswith('/') else href
#		tytul = parseDOM(dt, 'a')[0]
#
#		try:
#			tytul=tytul.encode('Latin_1')
#		except:
#			pass
#
#		year = parseDOM(dt, 'span')
#		year = year[0] if year else ''
#
#		sout.append({'title':tytul,'url':PLchar(href),'image':PLchar(imag),'plot':tytul,'year':year})
#
	
	return fout,sout,npage

def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	

def getSerial(id):

	url='https://filser.cc/api/watch/'+id
	head = {
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer':url
	
	}
	html,kuks = gethtml.getRequestsJson(url, headers = head)
	#web_pdb.set_trace()
	for it, val in html.items():
		ac=''
	html,kuks = gethtml.getRequests(url)

	resultmain = parseDOM(html,'div', attrs={'class': "sheader"})[0]
	tytul = parseDOM(resultmain,'h1')[0]
	try:
		tytul = tytul.encode('Latin_1').decode('utf-8')
	except:
		pass
	imag  = parseDOM(resultmain, 'img', ret='src')[0]
	imag = basurl+ imag if imag.startswith('/') else imag

	opis = parseDOM(resultmain,'span', attrs={'class': "tagline"})
	opis = opis[0] if opis else tytul
	try:
		opis = opis.encode('Latin_1').decode('utf-8')
	except:
		pass
	sezony = parseDOM(html,'div', attrs={'class': "se\-c"})

	episodes=[]

	for sezon in sezony:

		sesx = parseDOM(sezon,'span')
		if sesx:
			ses = re.findall('(\d+)',sesx[0],re.DOTALL)#[0]
			ses = ses[0] if ses else '0'

		eps = parseDOM(sezon,'li')

		
		for ep in eps:

			t1 = parseDOM(ep, 'a', ret='href')[0]  
			href = mainurl+t1
			tyt2 = parseDOM(ep, 'a')[0]  
			epis = re.findall('s\d+e(\d+)',t1,re.DOTALL+re.I)[0]

			tyt = '%s - [COLOR lightblue](%s)[/COLOR] [COLOR gold](%s)[/COLOR]'%(tytul,t1,tyt2)
			try:
				tyt = tyt.encode('Latin_1').decode('utf-8')
			except:
				pass
			episodes.append({'title':tyt,'url':PLchar(href),'image':imag,'plot':opis,'season':int(ses),'episode':int(epis)})

	seasons = splitToSeasons(episodes)
	return seasons

def getVideo(id):

	out=[]
	url='https://filser.cc/api/watch/'+id
	head = {
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer':url
	
	}
	html,kuks = gethtml.getRequestsJson(url, headers = head)

	stream_url=''

	for iframe in parseDOM(html, 'iframe', ret='src'):
		host = urlparse(iframe).netloc

		out.append({'href':iframe,'host':host})

	if out:
		if len(out) > 1:
			u = [ x.get('href') for x in  out]
			h = [ x.get('host') for x in  out]
			sel = gethtml.selectDialog("Źródło", h)
			href = out[sel].get('href') if sel>-1 else quit()
		else:
			href = out[0].get('href')
		if href:
			headers = {
	
				'user-agent': UA,
				'accept': '*/*',
				'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
				'x-requested-with': 'XMLHttpRequest',
				'referer': url,
				'te': 'trailers',}
			stream_url,kuks =gethtml.getRequestsRedirUrl(href,headers=headers)
		else:
			return stream_url,'quit'
	return stream_url,True

def szukcd(d):
	page=1
	fout=[]
	sout=[]
	npage=[]
	html,kuks = gethtml.getRequests('https://zenu.cc/szukaj')
	ids = [(a.start(), a.end()) for a in re.finditer('<article', html)]
	ids.append( (-1,-1) )

	for i in range(len(ids[:-1])):
		subset = html[ ids[i][1]:ids[i+1][0]]

		if d in (parseDOM(subset,'div', attrs={'class': "data"}))[0].lower():
			tytul = parseDOM(parseDOM(subset,'div', attrs={'class': "data"})[0],'a')[0]
			href = parseDOM(parseDOM(subset,'div', attrs={'class': "data"})[0], 'a', ret='href')[0]
			href = basurl+ href if href.startswith('/') else href
			imag  = parseDOM(subset, 'img', ret='src')[0]
			imag = basurl+ imag if imag.startswith('/') else imag
			try:
				tytul = tytul.encode('Latin_1').decode('utf-8')
			except:
				pass
			opis = tytul
			sout.append({'title':tytul,'url':PLchar(href),'image':PLchar(imag),'plot':opis})

	return fout,sout,npage
def getYear():
	d = gethtml.numericDialog(u'Podaj rok...')
	if d:
		d = '1800' if int(d)>2030 else d
		return str(d)
	else:
		return '1800'
def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]

	if d:
		fout,sout,npage=szukcd(d.lower())

	return fout,sout,npage
