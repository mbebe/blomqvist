# -*- coding: UTF-8 -*-
import sys,re,os, json
import geturl as gethtml
from geturl import PLchar as PLchar

if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus, unquote_plus
    import urllib.parse as urlparse
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus, unquote_plus
    import urlparse

basurl='https://filevids.cc'
UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0'

def getWpsearch():
	html,kuks = gethtml.getRequests('https://filevids.cc/movies/')
	wps = re.findall('toronites.*?"nonce"\:"([^"]+)"',html,re.DOTALL)
	wps = wps[0] if wps else None
	return wps
	
def ListContent(url,page):
	headers = {
		'Host': 'filevids.cc',
		'user-agent': UA,
		'accept': '*/*',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',

		'origin': 'https://filevids.cc',
		'dnt': '1',
		'sec-fetch-dest': 'empty',
		'sec-fetch-mode': 'cors',
		'sec-fetch-site': 'same-origin',
	}

	#if '/movies/' in url:
	wps = getWpsearch()
	
	if wps:
		tt = "movies" if '/movies/' in url else "series"
		data = {
			'action': 'action_search',
			'vars': '{"_wpsearch":"'+wps+'","taxonomy":"none","search":"none","term":"none","type":"'+tt+'","genres":[],"years":[],"sort":"1","page":'+str(page)+'}',
			}
		html,kuks = gethtml.getRequests('https://filevids.cc/wp-admin/admin-ajax.php',data=data, headers=headers)
		jsdata = json.loads(html)

	npage=[]
	fout=[]
	sout=[]
	if jsdata.get('next'):
		npage.append({'title':'Następna strona','url':url,'image':'','plot':'','page':int(page)+1})
	html = jsdata.get('html', None)
	for vid in parseDOM(html,'li'):
		href = parseDOM(vid, 'a', ret='href')[0]
		imag = parseDOM(vid, 'img', ret='src')[0]
		tytul = parseDOM(vid,'div', attrs={'class': "entry\-title"})[0]
		year = re.findall('year">(.+?)<',vid,re.DOTALL)
		year = year[0] if year else ''
		jak = re.findall('quality">(.+?)<',vid,re.DOTALL)
		jak = jak[0] if jak else ''
		opis = parseDOM(vid,'div', attrs={'class': "entry-content"})
		opis = re.sub("<[^>]*>","",opis[0].strip())
		imag = basurl+ imag if imag.startswith('/') else imag
		if '/movies/' in 	href:
			fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year})	
		else:
			sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year})

	return fout,sout,npage

def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
def getSerial(url):

	html,kuks = gethtml.getRequests(url)
	tytul = parseDOM(html,'h1', attrs={'class': "entry\-title"})[0]
	episodes=[]
	for seas in parseDOM(html,'div', attrs={'class': "seasons\-bx"}): 
		dt = parseDOM(seas,'p')[0]# <p>
		dt = re.sub("<[^>]*>","",parseDOM(seas,'p')[0])
		ses = re.findall('(\d+)',dt,re.DOTALL)[0]
		for ep in parseDOM(seas,'li'):
			img = parseDOM(ep, 'img', ret='src')[0] 
			img = basurl+ img if img.startswith('/') else img

			href = parseDOM(ep, 'a', ret='href') 
			if href:
				href = href[0]
				tyt2 = re.sub("<[^>]*>","",parseDOM(ep,'h3', attrs={'class': "title"})[0]) 
				epis = re.findall('s\d+\-e(\d+)',tyt2,re.DOTALL+re.I)[0]

				tyt = '%s - [COLOR lightblue](%s)[/COLOR]'%(tytul,tyt2)
				opis = tyt

				episodes.append({'title':PLchar(tyt),'url':PLchar(href),'image':img,'plot':PLchar(opis),'season':int(ses),'episode':int(epis)})

	seasons = splitToSeasons(episodes)
	return seasons

def getVideo(url):

	out=[]
	html,kuks = gethtml.getRequests(url)
	stream_url=''

	result = parseDOM(html,'div', attrs={'class': "player\s*movie\s*dfxb"})[0]
	
	iframes = parseDOM(html, 'iframe', ret='src')
	stream_url =''

	for i, iframe in enumerate(iframes,1):

		out.append({'href':iframe,'host':'Link '+str(i)})

		if out:
			if len(out) > 1:
				u = [ x.get('href') for x in  out]
				h = [ x.get('host') for x in  out]
				sel = gethtml.selectDialog("Źródło", h)
				href = out[sel].get('href') if sel>-1 else quit()
			else:
				href = out[0].get('href')
			if href:

				headers = {

					'user-agent': UA,
					'accept': '*/*',
					'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
					'x-requested-with': 'XMLHttpRequest',
					'referer': url,
					'te': 'trailers',}
				html,kuks =gethtml.getRequests(href,headers=headers)
				stream_url = parseDOM(html, 'iframe', ret='src')[0]

	if stream_url:
		return stream_url,True
	else:
		return stream_url,'quit'

def szukcd(dt={}):
	import ast
	dt = ast.literal_eval(unquote_plus(dt))

	d = re.findall('"type"\:"(.+?)"',dt.get('vars', None),re.DOTALL)[0]
	pg = re.findall('"page"\:(\d+)',dt.get('vars', None),re.DOTALL)[0]
	wps = re.findall('"_wpsearch"\:"(.+?)"',dt.get('vars', None),re.DOTALL)[0]
	fout=[]
	sout=[]
	npagex=[]
	headers = {
		'Host': 'filevids.cc',
		'user-agent': UA,
		'accept': '*/*',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',

		'origin': 'https://filevids.cc',
		'dnt': '1',
		'sec-fetch-dest': 'empty',
		'sec-fetch-mode': 'cors',
		'sec-fetch-site': 'same-origin',
	}

	html,kuks = gethtml.getRequests('https://filevids.cc/wp-admin/admin-ajax.php',data=dt, headers=headers)
	jsdata = json.loads(html)

	
	npage=[]
	fout=[]
	sout=[]
	if jsdata.get('next'):

		dtx = {
			'action': 'action_search',
			'vars': '{"_wpsearch":"'+wps+'","taxonomy":"none","search":"man","term":"none","type":"'+d+'","genres":[],"years":[],"sort":"1","page":'+str(int(pg)+1)+'}',
		}
		dtx = quote_plus(str(dtx))
		npage.append({'title':'Następna strona','url':dtx,'image':'','plot':'','page':int(pg)+1})
	html = jsdata.get('html', None)
	for vid in parseDOM(html,'li'):
		href = parseDOM(vid, 'a', ret='href')[0]
		imag = parseDOM(vid, 'img', ret='src')[0]
		tytul = parseDOM(vid,'div', attrs={'class': "entry\-title"})[0]
		year = re.findall('year">(.+?)<',vid,re.DOTALL)
		year = year[0] if year else ''
		jak = re.findall('quality">(.+?)<',vid,re.DOTALL)
		jak = jak[0] if jak else ''
		opis = parseDOM(vid,'div', attrs={'class': "entry-content"})
		opis = re.sub("<[^>]*>","",opis[0].strip())
		imag = basurl+ imag if imag.startswith('/') else imag
		if '/movies/' in 	href:
			fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year})	
		else:
			sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year})

	return fout,sout,npage
	

def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]

	if d:

		wps = getWpsearch()
		dt = {
			'action': 'action_search',
			'vars': '{"_wpsearch":"'+wps+'","taxonomy":"none","search":"man","term":"none","type":"'+d.replace(' ','+')+'","genres":[],"years":[],"sort":"1","page":'+str(page)+'}',
		}
		
		dt = quote_plus(str(dt))
		fout,sout,npage=szukcd(dt)

	return fout,sout,npage
