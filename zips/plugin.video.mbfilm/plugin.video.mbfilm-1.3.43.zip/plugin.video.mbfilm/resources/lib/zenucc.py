# -*- coding: UTF-8 -*-

import sys,re,os
import geturl as gethtml
from geturl import PLchar as PLchar
import xbmc, xbmcaddon, xbmcvfs

addon = xbmcaddon.Addon(id='plugin.video.mbfilm')

PATH            = addon.getAddonInfo('path')

if sys.version_info >= (3,0,0):
	DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
else:
	DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')



if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus

    import http.cookiejar as cookielib
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus

    import cookielib

from requests.compat import urlparse

basurl='https://zenu.cc'
UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0'

def ListContent(url,page):
	head = {
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer':url
	
	}
	if '/katalog-' in url:
		nturl = 'katalog-2"'
		nturl = re.sub('katalog\-\d+','katalog-%d'%(int(page)+1),nturl)
		nturlx = re.sub('katalog\-\d+','katalog-%d'%(int(page)+1),url)
		url = re.sub('katalog\-\d+','katalog-%d'%int(page),url)
	else:
		nturl = 'katalog-2"'
		nturlx = 'https://zenu.cc/katalog-2'
	npage=[]
	fout=[]
	sout=[]

	html,kuks = gethtml.getRequests(url, headers = head)
	
	if html.find(nturl)>-1:
		npage.append({'title':'Następna strona','url':nturlx,'image':'','plot':'','page':int(page)+1})
	
	result = parseDOM(html,'div', attrs={'class': "items"})#[0]
	result = result[0] if result else html
	ids = [(a.start(), a.end()) for a in re.finditer('<article', result)]
	ids.append( (-1,-1) )

	
	for i in range(len(ids[:-1])):
		subset = result[ ids[i][1]:ids[i+1][0]]
		imag = parseDOM(subset, 'img', ret='src')[0]
		imag = basurl+ imag if imag.startswith('/') else imag
		dt = parseDOM(subset,'div', attrs={'class': "data"})[0]
		href = parseDOM(dt, 'a', ret='href')[0]
		href = basurl+ href if href.startswith('/') else href
		tytul = parseDOM(dt, 'a')[0]

		try:
			tytul=tytul.encode('Latin_1')
		except:
			pass

		year = parseDOM(dt, 'span')
		year = year[0] if year else ''

		sout.append({'title':tytul,'url':PLchar(href),'image':PLchar(imag),'plot':tytul,'year':year})

	return fout,sout,npage

def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	

def getSerial(url):
	mainurl = url.replace('/index','/')
	html,kuks = gethtml.getRequests(url)

	resultmain = parseDOM(html,'div', attrs={'class': "sheader"})[0]
	tytul = parseDOM(resultmain,'h1')[0]
	try:
		tytul = tytul.encode('Latin_1').decode('utf-8')
	except:
		pass
	imag  = parseDOM(resultmain, 'img', ret='src')[0]
	imag = basurl+ imag if imag.startswith('/') else imag

	opis = parseDOM(resultmain,'span', attrs={'class': "tagline"})
	opis = opis[0] if opis else tytul
	try:
		opis = opis.encode('Latin_1').decode('utf-8')
	except:
		pass
	sezony = parseDOM(html,'div', attrs={'class': "se\-c"})

	episodes=[]

	for sezon in sezony:

		sesx = parseDOM(sezon,'span')
		if sesx:
			ses = re.findall('(\d+)',sesx[0],re.DOTALL)#[0]
			ses = ses[0] if ses else '0'

		eps = parseDOM(sezon,'li')

		
		for ep in eps:

			t1 = parseDOM(ep, 'a', ret='href')[0]  
			href = mainurl+t1
			tyt2 = parseDOM(ep, 'a')[0]  
			epis = re.findall('s\d+e(\d+)',t1,re.DOTALL+re.I)[0]

			tyt = '%s - [COLOR lightblue](%s)[/COLOR] [COLOR gold](%s)[/COLOR]'%(tytul,t1,tyt2)
			try:
				tyt = tyt.encode('Latin_1').decode('utf-8')
			except:
				pass
			episodes.append({'title':tyt,'url':PLchar(href),'image':imag,'plot':opis,'season':int(ses),'episode':int(epis)})

	seasons = splitToSeasons(episodes)
	return seasons

def getVideo(url):

	out=[]
	html,kuks = gethtml.getRequests(url)
	stream_url=''

	for iframe in parseDOM(html, 'iframe', ret='src'):
		host = urlparse(iframe).netloc

		out.append({'href':iframe,'host':host})

	if out:
		if len(out) > 1:
			u = [ x.get('href') for x in  out]
			h = [ x.get('host') for x in  out]
			sel = gethtml.selectDialog("Źródło", h)
			href = out[sel].get('href') if sel>-1 else quit()
		else:
			href = out[0].get('href')
		if href:
			headers = {
	
				'user-agent': UA,
				'accept': '*/*',
				'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
				'x-requested-with': 'XMLHttpRequest',
				'referer': url,
				'te': 'trailers',}
			stream_url,kuks =gethtml.getRequestsRedirUrl(href,headers=headers)
		else:
			return stream_url,'quit'
	return stream_url,True

def szukcd(d):
	page=1
	fout=[]
	sout=[]
	npage=[]
	html,kuks = gethtml.getRequests('https://zenu.cc/szukaj')
	ids = [(a.start(), a.end()) for a in re.finditer('<article', html)]
	ids.append( (-1,-1) )

	for i in range(len(ids[:-1])):
		subset = html[ ids[i][1]:ids[i+1][0]]

		if d in (parseDOM(subset,'div', attrs={'class': "data"}))[0].lower():
			tytul = parseDOM(parseDOM(subset,'div', attrs={'class': "data"})[0],'a')[0]
			href = parseDOM(parseDOM(subset,'div', attrs={'class': "data"})[0], 'a', ret='href')[0]
			href = basurl+ href if href.startswith('/') else href
			imag  = parseDOM(subset, 'img', ret='src')[0]
			imag = basurl+ imag if imag.startswith('/') else imag
			try:
				tytul = tytul.encode('Latin_1').decode('utf-8')
			except:
				pass
			opis = tytul
			sout.append({'title':tytul,'url':PLchar(href),'image':PLchar(imag),'plot':opis})

	return fout,sout,npage
	
def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]

	if d:
		fout,sout,npage=szukcd(d.lower())

	return fout,sout,npage
