# -*- coding: UTF-8 -*-
import sys,re,os

import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc, xbmcvfs
import six
from six.moves import urllib_parse

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict( urllib_parse.parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.mbfilm')

xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LASTPLAYED, label2Mask = "%R, %P, %Y")

PATH			= addon.getAddonInfo('path')

if sys.version_info >= (3,0,0):
	DATAPATH		= xbmcvfs.translatePath(addon.getAddonInfo('profile'))
else:
	DATAPATH		= xbmc.translatePath(addon.getAddonInfo('profile'))

if isinstance(DATAPATH, bytes):
	DATAPATH = DATAPATH.decode('utf-8')
if isinstance(PATH, bytes):
	PATH = PATH.decode('utf-8')
	
RESOURCES	   = PATH+'/resources/'
napisy = os.path.join(DATAPATH,'napisy')

FANART=RESOURCES+'../fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('name', None)
page = params.get('page','')
mcount= params.get('moviescount', None)
movie= params.get('movie', None)
rys= params.get('image', None)

fsortv = addon.getSetting('fsortV')
fsortn = addon.getSetting('fsortN') if fsortv else 'losowo'

fkatv = addon.getSetting('fkatV')
fkatn = addon.getSetting('fkatN') if fkatv else 'wszystkie'

fkrajv = addon.getSetting('fkrajV')
fkrajn = addon.getSetting('fkrajN') if fkrajv else 'wszystkie'

frokv = addon.getSetting('frokV')
frokn = addon.getSetting('frokN') if frokv else 'od początku'

ssortv = addon.getSetting('ssortV')
ssortn = addon.getSetting('ssortN') if ssortv else 'losowo'

skatv = addon.getSetting('skatV')
skatn = addon.getSetting('skatN') if skatv else 'wszystkie'

skrajv = addon.getSetting('skrajV')
skrajn = addon.getSetting('skrajN') if skrajv else 'wszystkie'

srokv = addon.getSetting('srokV')
srokn = addon.getSetting('srokN') if srokv else 'od początku'

ftagv = addon.getSetting('ftagV')
stagv = addon.getSetting('stagV')

dataf =  addon.getSetting('fdata')	
datas =  addon.getSetting('sdata')	


try:
	opisb = eval(params.get('opisb', None))
except:
	opisb = params.get('opisb', None)
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'

def build_url(query):
	return base_url + '?' + urllib_parse.urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=1,fanart=FANART,moviescount=0):
	list_item = xbmcgui.ListItem(label=name)

	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')
	#else:
	#	list_item.setProperty("IsPlayable", 'False')
	if not infoLabels:
		infoLabels={'title': name,'plot':name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': FANART})
	ok=xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page, 'moviescount' : moviescount,'movie':movie,'name':name,'image':image,'opisb':infoLabels}),			
		listitem=list_item,
		isFolder=folder)
	return ok

def home():

	add_item('film', '[B][COLOR khaki]vizjer.pl[/COLOR][/B]', 'DefaultMovies.png', "menu:vizjerpl", folder=True,fanart=RESOURCES+'fanart.png')

	add_item('film', '[B][COLOR khaki]ogladaj.to[/COLOR][/B]', 'DefaultMovies.png', "menu:ogladajto", folder=True,fanart=RESOURCES+'fanart.png')


	add_item('film', '[B][COLOR khaki]zerion.cc[/COLOR][/B]', 'DefaultMovies.png', "menu:zerion", folder=True,fanart=RESOURCES+'fanart.png')

	add_item('film', '[B][COLOR khaki]zaluknij.cc[/COLOR][/B]', 'DefaultMovies.png', "menu:zaluknij", folder=True,fanart=RESOURCES+'fanart.png')
	
	add_item('film', '[B][COLOR khaki]kinomoc.com[/COLOR][/B]', 'DefaultMovies.png', "menu:kinomoc", folder=True,fanart=RESOURCES+'fanart.png')
	
	add_item('film', '[B][COLOR khaki]filevids.cc[/COLOR][/B]', 'DefaultMovies.png', "menu:filevids", folder=True,fanart=RESOURCES+'fanart.png')
	
	add_item('film', '[B][COLOR khaki]zenu.cc[/COLOR][/B]', 'DefaultMovies.png', "menu:zenucc", folder=True,fanart=RESOURCES+'fanart.png')
	
	#add_item('film', '[B][COLOR khaki]filser.cc[/COLOR][/B]', 'DefaultMovies.png', "menu:filsercc", folder=True,fanart=RESOURCES+'fanart.png')
	
def splitToSeasons(input):
	out={}
	seasons = [x.get('season') for x in input]
	for s in set(seasons):
		out['Sezon %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
	return out	

def getEpisodes(seasons,mode2):
	import ast
	episodes = eval(urllib_parse.unquote_plus(seasons))
	items=len(episodes)

	for f in episodes: 
		ses=f.get('season')
		epp=f.get('episode')
		tyt=f.get('title').split('Season')#[0]

		tyt2 = '%s - odc.%02d'%(name,epp)
		tyt = tyt[0] if tyt else tyt2
		try:
			tyt = tyt.encode('Latin_1')#.decode('utf-8')
		except:
			pass

		add_item(name=tyt, url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot')}, itemcount=items)
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)	
def dec(chra):

	try:	
		if sys.version_info >= (3,0,0):
			chra =repr(chra.encode('utf-8'))
			chra = chra.replace('\\xc3\\xaa','ę').replace('\\xc3\\x8a','Ę')
			chra = chra.replace('\\xc3\\xa6','ć').replace('\\xc3\\x86','Ć')
			chra = chra.replace('\\xc2\\xbf','ż').replace('\\xc2\\x9f','Ż')
			chra = chra.replace('\\xc2\\xb9','ą').replace('\\xc2\\x99','Ą')
			
			chra = chra.replace('\\xc5\\x93','ś').replace('\\xc5\\x92','Ś')
			chra = chra.replace('\\xc3\\xb3','ó').replace('\\xc3\\x93','Ó')
			
			chra = chra.replace('\\xc5\\xb8','ź').replace('\\xc5\\xb7','Ź')
			
			chra = chra.replace('\\xc2\\xb3','ł').replace('\\xc2\\x93','Ł')
			
			chra = chra.replace('\\xc3\\xb1','ń').replace('\\xc3\\x91','Ń')
			chra = chra .replace("b\'",'')

			chra = chra .replace("\\n",'\n').replace("\\r",'\r') 
			chra = chra .replace("\\'","'")

		else:

			chra = chra.replace('\xc3\xaa','ę').replace('\xc3\x8a','Ę')
			chra = chra.replace('\xc3\xa6','ć').replace('\xc3\x86','Ć')
			chra = chra.replace('\xc2\xbf','ż').replace('\xc2\x9f','Ż')
			chra = chra.replace('\xc2\xb9','ą').replace('\xc2\x99','Ą')
			
			chra = chra.replace('\xc5\x93','ś').replace('\xc5\x92','Ś')
			chra = chra.replace('\xc3\xb3','ó').replace('\xc3\x93','Ó')
			
			chra = chra.replace('\xc5\xb8','ź').replace('\xc5\xb7','Ź')
			
			chra = chra.replace('\xc2\xb3','ł').replace('\xc2\x93','Ł')
			
			chra = chra.replace('\xc3\xb1','ń').replace('\xc3\x91','Ń')



	except:
		pass
		
	return chra
	
def transPolish(subtlink):

	try:
		response = sess.get(subtlink, headers=headers, verify=False)#.content

		if sys.version_info >= (3,0,0):
		
			response  = response.text
		else:
			response  = response.content
		gg=dec(response)

		open(napisy, 'w').write(gg)

		return True
	except:
		return False
		
def PlayVid(stream_url,adaptive=False):

	subt = None
	if '|napisy|' in stream_url:
		stream_url,subt = stream_url.split('|napisy|')#[0]

	play_item = xbmcgui.ListItem(path=stream_url)
	if subt:
		transPolish(subt)
		play_item.setSubtitles([subt])
	try:
		play_item.setInfo(type="Video", infoLabels={"title": name,'plot':opisb['plot']})
		
		play_item.setArt({'thumb': rys, 'poster': rys, 'banner': rys, 'fanart': FANART})
	except:
		pass
	play_item.setProperty("IsPlayable", "true")
	if adaptive:
		if six.PY2:
			play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
		else:
			play_item.setProperty('inputstream', 'inputstream.adaptive')
		play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
		play_item.setMimeType('application/vnd.apple.mpegurl')
		play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
	Player = xbmc.Player()
	Player.play(stream_url, play_item)
		#play_item.setContentLookup(False)
	#else:
	#		#play_item = xbmcgui.ListItem(path=stream_url,label=tytul)
	#		#play_item.setInfo(type="Video", infoLabels={"title": tytul,'plot':tytul})
	#		#
	#		#if '.mp4' in stream_url:
	#	play_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
	#	play_item.setProperty('inputstream.ffmpegdirect.mime_type', 'video/mp4')
	#	play_item.setContentLookup(False)
	#	play_item.setMimeType('video/mp4')
	#	play_item.setProperty('mimetype', 'video/mp4')
	#	play_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
	#	play_item.setProperty('inputstream.ffmpegdirect.mime_type', 'video/mp4')
	#	play_item.setContentLookup(False)
  #	# xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
		


def import_mod(s):
	mod = {}
	if   s == 'livenet': import livenet	 as mod
	elif s == 'ekinopw': import ekinopw	 as mod
	elif s == 'vizjerpl': import vizjerpl	as mod
	elif s == 'cdaonline': import cdaonline   as mod
	elif s == 'rodzinne': import rodzinne	as mod
	elif s == 'watchmovies': import watchmovies as mod
	elif s == 'filmweb4u2': import filmweb4u2  as mod
	elif s == 'znetlive': import znetlive	as mod
	elif s == 'filmeriaco': import filmeriaco  as mod
	elif s == 'filmninja': import filmninja  as mod
	elif s == 'seansik': import seansik  as mod
	
	elif s == 'zalukajvip': import zalukajvip  as mod
	elif s == 'wideosite': import wideosite  as mod
	elif s == 'ogladajto': import ogladajto  as mod
	elif s == 'dudeplayer': import dudeplayer  as mod
	elif s == 'nadzis': import nadzis  as mod
	elif s == 'zaluknij': import zaluknij  as mod
	elif s == 'maxfilm': import maxfilm  as mod

	elif s == 'fblogspot': import fblogspot  as mod
	elif s == 'anyvid': import anyvid  as mod
	elif s == 'zerion': import zerion  as mod
	elif s == 'serialxtk': import serialxtk  as mod
	elif s == 'kinomoc': import kinomoc  as mod
	elif s == 'filevids': import filevids  as mod
	elif s == 'zenucc': import zenucc  as mod
	elif s == 'filsercc': import filsercc  as mod
	
	return mod
def import_menu(s):
	mod = {}
	if   s == 'livenet': import livenet	 as mod
	elif s == 'ekinopw': mod = ekinopwMenu(s)
	elif s == 'vizjerpl': mod = vizjerplMenu(s)
	elif s == 'cdaonline': mod = cdaonlineMenu(s)
	elif s == 'rodzinne': mod = rodzinneMenu(s)
	elif s == 'zalukajvip': mod = zalukajvipMenu(s)
	elif s == 'watchmovies': mod = watchmoviesMenu(s)
	elif s == 'filmweb4u2': import filmweb4u2  as mod
	elif s == 'znetlive':   mod = znetliveMenu(s)
	elif s == 'filmeriaco': mod = filmeriacoMenu(s)
	elif s == 'filmninja': mod = filmninjaMenu(s)
	elif s == 'seansik': mod = filmninjaMenu2(s)
	elif s == 'wideosite': mod = wideositeMenu(s)
	elif s == 'ogladajto': mod = ogladajtoMenu(s)
	elif s == 'dudeplayer': mod = dudeplayerMenu(s)
	elif s == 'nadzis': mod = nadzisMenu(s)
	elif s == 'zaluknij': mod = zaluknijMenu(s) 
	
	elif s == 'maxfilm': mod = maxfilmMenu(s) 
	elif s == 'fblogspot': mod = fblogspotMenu(s) 
	elif s == 'anyvid': mod = anyvidMenu(s) 
	elif s == 'zerion': mod = zerionMenu(s) 
	elif s == 'serialxtk': mod = serialxtkMenu(s) 
	elif s == 'kinomoc': mod = kinomocMenu(s) 
	elif s == 'filevids': mod = filevidsMenu(s) 
	elif s == 'zenucc': mod = zenuccMenu(s) 
	elif s == 'filsercc': mod = filserccMenu(s) 
	
	
	
	#flisercc
	return mod
	
def filserccMenu(str):
	add_item('filmy', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "submfilsercc", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('seriale', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "submfilsercc", folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('https://rodzinnekino.com/kraj/polska/', '[B][COLOR khaki]Polska[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('gatunek', '[B][COLOR khaki]-   gatunek[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('kraj', '[B][COLOR khaki]-   kraj[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('wersja', '[B][COLOR khaki]-   wersja[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	#add_item('rok', '[B][COLOR khaki]-   rok wydania[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

def filserccSubMenu(typ):
	if 'filmy' in typ:
		sortx = fsortn
		rodz = 'f'
		kraj = fkrajn
		kat = fkatn
		rok = frokn
	else:
		sortx = ssortn
		rodz = 's'
		kraj = skrajn
		kat = skatn
		rok = srokn
	add_item('', "-	  [COLOR lightblue]sortowanie:[/COLOR] [B]"+fsortn+'[/B]','DefaultRecentlyAddedMovies.png', 'filtr:'+rodz+'sort', folder=False,fanart=RESOURCES+'fanart.png')
	add_item('', "-	  [COLOR lightblue]kraj:[/COLOR] [B]"+kraj+'[/B]','DefaultRecentlyAddedMovies.png', 'filtr:'+rodz+'kraj', folder=False,fanart=RESOURCES+'fanart.png')
	add_item('', "-	  [COLOR lightblue]gatunki,tagi:[/COLOR] [B]"+kat+'[/B]','DefaultRecentlyAddedMovies.png', 'filtr:'+rodz+'kat', folder=False,fanart=RESOURCES+'fanart.png')
	add_item('', "-	  [COLOR lightblue]rok:[/COLOR] [B]"+rok+'[/B]','DefaultRecentlyAddedMovies.png', 'filtr:'+rodz+'rok', folder=False,fanart=RESOURCES+'fanart.png')
	#add_item('', "-	  [COLOR lightblue]quality:[/COLOR] [B]"+fwern+'[/B]','DefaultRecentlyAddedMovies.png', 'filtr:'+rodz+'wer', folder=False,fanart=RESOURCES+'fanart.png')
	#add_item('', "-	  [COLOR lightblue]subtitles:[/COLOR] [B]"+fnapn+'[/B]','DefaultRecentlyAddedMovies.png', 'filtr:'+rodz+'nap', folder=False,fanart=RESOURCES+'fanart.png')
	
	
	add_item('s', "[I][COLOR violet][B]Reset all filters[/COLOR][/I][/B]",'DefaultAddonService.png', "resetfil", folder=False)
	add_item(typ, '[B][COLOR khaki]Wyświetl materiały (%s)[/COLOR][/B]'%str(typ), 'DefaultMovies.png', "ListContent:filsercc", folder=True,fanart=RESOURCES+'fanart.png')
	
def ogladajtoMenu(str):
    import ogladajto

    logged,dane = ogladajto.zaloguj()

    if logged:
        add_item('https://www.ogladaj.to/polecane/', '[B][COLOR gold]Zalogowano - %s[/COLOR][/B]'%(dane), 'DefaultMovies.png', "noth", folder=False, IsPlayable=False, fanart=RESOURCES+'fanart.png')
    

    
    
    else:
        add_item('https://www.ogladaj.to/polecane/', '[B][COLOR orangered]%s[/COLOR][/B]'%(dane), 'DefaultMovies.png', "noth", folder=False, IsPlayable=False,fanart=RESOURCES+'fanart.png')
    add_item('https://www.ogladaj.to/polecane/', '[B]Opcje[/B]', 'DefaultMovies.png', "opcje", folder=False, IsPlayable=False,fanart=RESOURCES+'fanart.png')

    add_item('https://www.ogladaj.to/polecane/', '[B][COLOR khaki]Polecane[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
    
    add_item('https://www.ogladaj.to/filmy/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
    add_item('https://www.ogladaj.to/seriale/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
    #    add_item('https://www.ogladaj.to/seriale/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
    add_item('https://www.ogladaj.to/gatunek/dla-dzieci/', '[B][COLOR khaki]Dla dzieci[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
    add_item('kategorie', '[B][COLOR khaki]-   gatunek[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
    #    add_item('rok', '[B][COLOR khaki]-   rok wydania[/COLOR][/B]', 'DefaultMovies.png', "SelectList:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
    add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
    
def zenuccMenu(str):
	add_item('https://zenu.cc/seriale', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zenu.cc/nowosci', '[B][COLOR khaki]Nowości[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

def filevidsMenu(str):

	add_item('https://filevids.cc/movies/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://filevids.cc/series/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

def kinomocMenu(str):
	add_item('https://kinomoc.com/filmy/page/1/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://kinomoc.com/serials/page/1/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

	
	

def zerionMenu(str):
	add_item('https://zerion.cc/seriale?page=1', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

	  
	
def zaluknijMenu(str):
	import kurw
	url = 'https://zaluknij.cc/'
	hostx = 'zaluknij'
	kurw.bps_dguardx(url,hostx)
	
	add_item('https://zaluknij.cc/filmy-online/?page=1', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zaluknij.cc/dla-dzieci/?page=1', '[B][COLOR khaki]Dla dzieci[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://zaluknij.cc/series/index/', '[B][COLOR khaki]Seriale (lista)[/COLOR][/B]', 'DefaultMovies.png', "ListContent:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	
def vizjerplMenu(str):
	import kurw
	url = 'https://vizjer.pl'
	hostx = 'vizjer'
	kurw.bps_dguardx(url,hostx)
	add_item('https://vizjer.pl/filmy-online/', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "SimplelistFilmy:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://vizjer.pl/series/index/', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "SimplelistSeriale:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://vizjer.pl/dla-dzieci/', '[B][COLOR khaki]Dla dzieci[/COLOR][/B]', 'DefaultTVShows.png', "SimplelistFilmy:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:%s"%str, folder=True,fanart=RESOURCES+'fanart.png')

	

def busy():

	if float(xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')[:4]) > 17.6:
		xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
	else:
		xbmc.executebuiltin('ActivateWindow(busydialog)')	
def idle():

	if float(xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')[:4]) > 17.6:
		xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
	else:
		xbmc.executebuiltin('Dialog.Close(busydialog)')
def SzukajWszystko():
	import szukaj
	flinks,slinks = szukaj.Przeszukuj()
	return flinks,slinks
def router(paramstring):
	params = dict( urllib_parse.parse_qsl(paramstring))
	if params:
		typv='videos'
		mode = params.get('mode', None)
		
		if 'SimplelistFilmy' in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			
			links,pagin = mod.getFilmy(exlink,page)
			items = len(links)
			for f in links:
				
				add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items)
			if pagin:
				for f in pagin:	
					add_item(name=f.get('title'), url=f.get('url'), mode='SimplelistFilmy:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))		
			if addon.getSetting('auto-view') == 'true':
				typv='movies'		
			xbmcplugin.setContent(addon_handle, typv)		
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif 'SimplelistSeriale' in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			links,pagin = mod.ListSeriale(exlink,page)
			items = len(links)
			mud = 'getSimpleSeasons:%s'%mode2
			if mode2=='filmeriaco':
				mud = 'getLinksfilmeriaco'
				
			for f in links:
				
				add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items)
			if pagin:
				for f in pagin:	
					add_item(name=f.get('title'), url=f.get('url'), mode='SimplelistSeriale:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))			
			if addon.getSetting('auto-view') == 'true':
				typv='tvshows'		
			xbmcplugin.setContent(addon_handle, typv)				
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif 'listCategory' in mode:
			mode2 = mode.split(':')[1]
			co='film' if 'film' in mode else 'serial'
			mod = import_mod(mode2)
			kategoria = mod.ListCateg(co,exlink)
			if co=='serial':
			
			
				links,pagin = mod.ListSeriale(kategoria,page)
				items = len(links)
				mud = 'getSimpleSeasons:%s'%mode2
				for f in links:
					
					add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items)
				if pagin:
					for f in pagin:	
						add_item(name=f.get('title'), url=f.get('url'), mode='SimplelistSeriale:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))	
				if addon.getSetting('auto-view') == 'true':
					typv='tvshows'		
				xbmcplugin.setContent(addon_handle, typv)			
			#	xbmcplugin.setContent(addon_handle, 'tvshows')	
			else:
				links,pagin = mod.getFilmy(kategoria,page)
				items = len(links)
				for f in links:
					
					add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=True, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items)
				if pagin:
					for f in pagin:	
						add_item(name=f.get('title'), url=f.get('url'), mode='SimplelistFilmy:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))	
				if addon.getSetting('auto-view') == 'true':
					typv='movies'		
				xbmcplugin.setContent(addon_handle, typv)			
			#	xbmcplugin.setContent(addon_handle, 'movies')		
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif 'SimplelistSearch' in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			
			flinks,slinks,pagin = mod.ListSearch(exlink,page)

			if flinks or slinks:
				items1 = len(flinks)
				items2 = len(slinks)
				mud = 'getSimpleSeasons:%s'%mode2
				
				if mode2=='filmeriaco':
					mud = 'getLinksfilmeriaco'
				
				elif mode2 =='kinomoc':
					mud = 'Listepisodeskinomoc'
				if slinks:
					for f in slinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items2)
					if addon.getSetting('auto-view') == 'true':
						typv='tvshows'		
					xbmcplugin.setContent(addon_handle, typv)	
					#xbmcplugin.setContent(addon_handle, 'tvshows')	
				if flinks:
					for f in flinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1)
					if addon.getSetting('auto-view') == 'true':
						typv='movies'		
					xbmcplugin.setContent(addon_handle, typv)	

				if pagin:

					for f in pagin:	

						mud2 = 'SimplelistSeriale:%s'%mode2
						if 'cda-filmy' in f.get('url') or 'zalukaj' in f.get('url') or 'anyvideo.org' in f.get('url'):
							mud2 = 'ListContent:%s'%mode2
						elif 'dudeplayer' in f.get('url'):
							mud2 = 'ListContent3'
						elif 'result_from' in f.get('url') and 'search_start' in f.get('url'):
							mud2 = 'listsearchkino'
						elif '_wpsearch' in f.get('url') and 'taxonomy' in f.get('url'):
							mud2 = 'listsearchfilevids'
						add_item(name=f.get('title'), url=f.get('url'), mode=mud2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
					
				xbmcplugin.endOfDirectory(addon_handle)
			elif not flinks and not slinks:
				return
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
				
		elif mode == 'listsearchfilevids':
			import filevids
			flinks,slinks,pagin = filevids.szukcd(exlink)
			if flinks or slinks:
				items1 = len(flinks)
				items2 = len(slinks)
				mud = 'getSimpleSeasons:filevids'#

				if slinks:
					for f in slinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items2)
					if addon.getSetting('auto-view') == 'true':
						typv='tvshows'		
					xbmcplugin.setContent(addon_handle, typv)	

				if flinks:
					for f in flinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode='getVid:filevids', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1)
					if addon.getSetting('auto-view') == 'true':
						typv='movies'		
					xbmcplugin.setContent(addon_handle, typv)	
				if pagin:

					for f in pagin:	
						mud2 = 'listsearchfilevids'
						add_item(name=f.get('title'), url=f.get('url'), mode=mud2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
					
				xbmcplugin.endOfDirectory(addon_handle)
			elif not flinks and not slinks:
				return
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
				
				
				
				
				
		elif mode == 'listsearchkino':
			import kinomoc
			flinks,slinks,pagin = kinomoc.szukcd(exlink)

			if flinks or slinks:
				items1 = len(flinks)
				items2 = len(slinks)
				mud = 'Listepisodeskinomoc'


				if slinks:
					for f in slinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items2)
					if addon.getSetting('auto-view') == 'true':
						typv='tvshows'		
					xbmcplugin.setContent(addon_handle, typv)	

				if flinks:
					for f in flinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode='getVid:kinomoc', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1)
					if addon.getSetting('auto-view') == 'true':
						typv='movies'		
					xbmcplugin.setContent(addon_handle, typv)	

				if pagin:

					for f in pagin:	
						mud2 = 'ListContent3'
						if 'dudeplayer' in f.get('url'):
							mud2 = 'ListContent3'
						elif 'result_from' in f.get('url') and 'search_start' in f.get('url'):
							mud2 = 'listsearchkino'
						elif 'result_from' in f.get('url') and 'search_start' in f.get('url'):
							mud2 = 'listsearchkino'
						add_item(name=f.get('title'), url=f.get('url'), mode=mud2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
					
				xbmcplugin.endOfDirectory(addon_handle)
			elif not flinks and not slinks:
				return
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
		elif 'getSimpleSeasons'in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			seasons=mod.getSerial(exlink)	
			if seasons:
				items = len(seasons)
				for i in sorted(seasons.keys()):
					opis=(seasons[i])[0].get('plot')
					add_item(name=name+' - '+i, url=urllib_parse.quote_plus(str(seasons[i])), mode='getEpisodes:%s'%mode2, image=rys, folder=True,  infoLabels={'plot':opis}, itemcount=items)	
				if addon.getSetting('auto-view') == 'true':
					typv='tvshows'		
				xbmcplugin.setContent(addon_handle, typv)	
				#xbmcplugin.setContent(addon_handle, 'tvshows')
				xbmcplugin.endOfDirectory(addon_handle)	
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak odcinków do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
		elif 'getEpisodes'in mode:
			mode2 = mode.split(':')[1]
			getEpisodes(exlink,mode2)
			
		elif 'menu' in mode:
			mode2 = mode.split(':')[1]
			mod = import_menu(mode2)
			mod
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif 'getVid' in mode:
			#busy()

			adapt=False
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			#idle()
			stream_url,resolve = mod.getVideo(exlink)

			if resolve and stream_url:
				import cdapl 
				if 'cda.pl' in stream_url:
					stream_url = cdapl.getLinkCda(stream_url)
					if len(stream_url)==1:
						stream_url = stream_url[0][0]
					else:
						if type(stream_url) is list:
							qual = [x[1] for x in stream_url]
							select = xbmcgui.Dialog().select('Wybierz jakość (cda)', qual)
							
							if select>-1:
								stream_url = stream_url[select][0]
							else:
								
								stream_url=''
								quit()
				else:
					import resolveurl
					if 'hqq.' in stream_url or 'waaw.' in stream_url:
						import ekinopw
						stream_url=ekinopw.getHqq(stream_url)
					elif 'upvideo.cc' in stream_url or 'upvideo.x' in stream_url :
						import zalukajvip
						stream_url=zalukajvip.getUpvideocc(stream_url)
						if stream_url=='quit':
							
							quit()
						adapt=False
					else:
						try:
							stream_url = resolveurl.resolve(stream_url)
						except Exception as e:
							stream_url=''
				
			if stream_url:
				adapt = True if '.m3u8' in stream_url else False
				PlayVid(stream_url,adapt)
			else:
				if resolve=='quit':
					xbmcgui.Dialog().notification('[B]Link nie działa[/B]', 'Spróbuj inny',xbmcgui.NOTIFICATION_INFO, 6000,False)
					quit()
				else:
					xbmcgui.Dialog().notification('[B]Link nie działa[/B]', 'Spróbuj inny',xbmcgui.NOTIFICATION_INFO, 6000,False)
			
		elif mode == 'getLinksfilmeriaco':
			import filmeriaco  as mod
			links,pags= mod.getLinks(exlink)
			items = len(links)
			for f in links:
				add_item(name=f.get('title'), url=f.get('url'), mode='getVid:filmeriaco', image=f.get('image'), folder=False, IsPlayable=True, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('jak')}, itemcount=items)
			xbmcplugin.setContent(addon_handle, 'videos')		
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif mode == 'ListGatRok':
			import dudeplayer
			litery = dudeplayer.getLitery2(exlink)
			items = len(litery)
			if items>1:
				for f in litery:
					add_item(name=f.get('title'), url=f.get('url'), mode='ListContent:dudeplayer', image='', folder=True)
				xbmcplugin.setContent(addon_handle, 'videos')		
				xbmcplugin.endOfDirectory(addon_handle)
		
		elif mode == 'ListContent3':
			import dudeplayer
			#flinks,slinks,npage = dudeplayer.ListContent3(exlink) #flinks,slinks,pagin = mod.ListContent(exlink,page)
			flinks,slinks,pagin = dudeplayer.ListContent3(exlink,page)
			if flinks or slinks:
				items1 = len(flinks)
				items2 = len(slinks)
				mud = 'getSimpleSeasons:dudeplayer'
				if slinks:
					for f in slinks:
						dd=f.get('plot') if f.get('plot') else f.get('title')
						add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':dd,'title': f.get('title')}, itemcount=items2)
					if addon.getSetting('auto-view') == 'true':
						typv='tvshows'		
					xbmcplugin.setContent(addon_handle, typv)	
				#	xbmcplugin.setContent(addon_handle, 'tvshows')	
				if flinks:
					for f in flinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode='getVid:dudeplayer', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code'),'duration':f.get('duration')}, itemcount=items1)
					if addon.getSetting('auto-view') == 'true':
						typv='movies'		
					xbmcplugin.setContent(addon_handle, typv)	
				#	xbmcplugin.setContent(addon_handle, 'movies')
				if pagin:
					for f in pagin:	
						add_item(name=f.get('title'), url=f.get('url'), mode='ListContent3', image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
					
				xbmcplugin.endOfDirectory(addon_handle)
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
		#	= dudeplayer.getLitery(exlink)

		elif mode == 'ListFilmyZaluknij':
			import dudeplayer
			litery = dudeplayer.getLitery(exlink)
			items = len(litery)
			if items>1:
				for f in litery:
					add_item(name=f.get('title'), url=f.get('url'), mode='ListContent2', image='', folder=True)
				xbmcplugin.setContent(addon_handle, 'videos')		
				xbmcplugin.endOfDirectory(addon_handle)


		elif mode == 'ListAlfabet2':
			import dudeplayer
			litery = dudeplayer.getLitery(exlink)
			items = len(litery)
			if items>1:
				for f in litery:
					add_item(name=f.get('title'), url=f.get('url'), mode='ListContent2', image='', folder=True)
				xbmcplugin.setContent(addon_handle, 'videos')		
				xbmcplugin.endOfDirectory(addon_handle)
			

			
			
			
		elif mode == 'ListContent2':
			import dudeplayer
			flinks=[]
			slinks=[]

			flinks,slinks = dudeplayer.ListContent2(exlink)
			if flinks or slinks:
				items1 = len(flinks)
				items2 = len(slinks)
				mud = 'getSimpleSeasons:dudeplayer'
				if slinks:
					for f in slinks:
						dd=f.get('plot') if f.get('plot') else f.get('title')
						add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':dd,'title': f.get('title')}, itemcount=items2)
					xbmcplugin.setContent(addon_handle, 'tvshows')	
				if flinks:
					for f in flinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode='getVid:dudeplayer', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code'),'duration':f.get('duration')}, itemcount=items1)
					#	if addon.getSetting('auto-view') == 'true':
					#		typv='movies'	
					#	xbmcplugin.setContent(addon_handle, typv)	
					if addon.getSetting('auto-view') == 'true':
						typv='movies'	
					xbmcplugin.setContent(addon_handle, typv)	
					#xbmcplugin.setContent(addon_handle, 'movies')

				xbmcplugin.endOfDirectory(addon_handle)
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
		elif mode == 'ListAlfabet':
			import wideosite
			litery = wideosite.getLitery(exlink)
			items = len(litery)
			if items>1:
				for f in litery:
					add_item(name=f.get('title'), url=f.get('url'), mode='ListContent:wideosite', image='', folder=True)
				xbmcplugin.setContent(addon_handle, 'videos')		
				xbmcplugin.endOfDirectory(addon_handle)
		elif mode == 'ListSerieF1':
			import zalukajvip
			series = zalukajvip.getSerieF(exlink)
			items = len(series)
			if items>1:
				for f in series:
					add_item(name=f.get('title'), url=f.get('url'), mode='ListSerieContent', image=f.get('image'), folder=True)
				xbmcplugin.setContent(addon_handle, 'videos')		
				xbmcplugin.endOfDirectory(addon_handle)

		elif mode == 'ListSerieContent':
			import zalukajvip
			links = zalukajvip.ListSerieContent(exlink)
			items = len(links)
			if items>1:
				for f in links:
					add_item(name=f.get('title'), url=f.get('url'), mode='getVid:zalukajvip', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('jak')}, itemcount=items)
				xbmcplugin.setContent(addon_handle, 'videos')		
				xbmcplugin.endOfDirectory(addon_handle)

				
		elif mode == 'ListTV':
			import filmninja  as mod
			links = mod.getTV(exlink)
			items = len(links)
			for f in links:
				add_item(name=f.get('title'), url=f.get('url'), mode='PlayTv', image=f.get('image'), folder=False, IsPlayable=False, infoLabels=False, itemcount=items)
			if addon.getSetting('auto-view') == 'true':
				typv='movies'	
			xbmcplugin.setContent(addon_handle, typv)	
			#xbmcplugin.setContent(addon_handle, 'movies')
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif mode == 'PlayTv':
			import filmninja  as mod
			stream_url,resol = mod.PlayTv(exlink)
			if stream_url:
				PlayVid(stream_url)
			else:
				xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Brak działającego linka.',xbmcgui.NOTIFICATION_INFO, 6000,False)
				
		elif 'SelectList' in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			#flinks =''
			#slinks =''
			url = mod.SelectList(exlink)
			if url:
				flinks,slinks,pagin = mod.ListContent(url,page)
				if flinks or slinks:
					items1 = len(flinks)
					items2 = len(slinks)
					mud = 'getSimpleSeasons:%s'%mode2
					if slinks:
						for f in slinks:
							
							add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items2)
						if addon.getSetting('auto-view') == 'true':
							typv='tvshows'
						xbmcplugin.setContent(addon_handle, typv)	
					#	xbmcplugin.setContent(addon_handle, 'tvshows')	
					if flinks:
						for f in flinks:
							
							add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1)
						if addon.getSetting('auto-view') == 'true':
							typv='movies'
						xbmcplugin.setContent(addon_handle, typv)	
						#xbmcplugin.setContent(addon_handle, 'movies')
					if pagin:
						for f in pagin:	
							add_item(name=f.get('title'), url=f.get('url'), mode='ListContent:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
						
					xbmcplugin.endOfDirectory(addon_handle)
				else:
					xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
		elif 'ListLista' in mode:
			mode2 = mode.split(':')[1]
			mod = import_mod(mode2)
			flinks,slinks,npage = mod.ListLista(exlink,page)
			mud = 'ListContent:%s'%mode2
			if slinks:
				items2 = len(slinks)
				for f in slinks:
					dd=f.get('plot') if f.get('plot') else f.get('title')
					add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':dd,'title': f.get('title')}, itemcount=items2)
					
			xbmcplugin.endOfDirectory(addon_handle)
		elif 'ListContent' in mode:
			mode2 = mode.split(':')[1]

			mod = import_mod(mode2)
			flinks=[]
			slinks=[]
			pagin=[]
			flinks,slinks,pagin = mod.ListContent(exlink,page)
			if flinks or slinks:
				items1 = len(flinks)
				items2 = len(slinks)
				if 'xyz/seasons/' in exlink:
					mud = 'Listepisodesxyz'
				elif 'kinomoc' in exlink:	
					mud = 'Listepisodeskinomoc'
				else:

					mud = 'getSimpleSeasons:%s'%mode2
				if slinks:
					for f in slinks:
						dd=f.get('plot') if f.get('plot') else f.get('title')
						add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':dd,'title': f.get('title')}, itemcount=items2)
					
						
					if 'zaluknij' in exlink:
						xbmcplugin.setContent(addon_handle, 'videos')	
					else:
						if addon.getSetting('auto-view') == 'true':
							typv='tvshows'
						xbmcplugin.setContent(addon_handle, typv)
						#xbmcplugin.setContent(addon_handle, 'tvshows')
				if flinks:
					for f in flinks:
						
						add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code'),'duration':f.get('duration')}, itemcount=items1)
					if 'zaluknij' in exlink:
						xbmcplugin.setContent(addon_handle, 'videos')	
					else:
						if addon.getSetting('auto-view') == 'true':
							typv='movies'
						xbmcplugin.setContent(addon_handle, typv)
						#xbmcplugin.setContent(addon_handle, 'movies')
						
					
				if pagin:
					for f in pagin:	
						add_item(name=f.get('title'), url=f.get('url'), mode='ListContent:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
					
				xbmcplugin.endOfDirectory(addon_handle)
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
		elif mode == "szukajwszystko":
			import szukaj
			flinks,slinks=szukaj.Przeszukuj()
			if flinks or slinks:
				items1 = len(flinks)
				items2 = len(slinks)
				if slinks:
					for f in slinks:
						
						mud = 'getSimpleSeasons:%s'%(f.get('mode2'))
						dd=f.get('plot') if f.get('plot') else f.get('title')
						add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':dd,'title': f.get('title')}, itemcount=items2)
					if addon.getSetting('auto-view') == 'true':
						typv='tvshows'
					xbmcplugin.setContent(addon_handle, typv)
				#	xbmcplugin.setContent(addon_handle, 'tvshows')	
				if flinks:
					for f in flinks:
						mode2 = f.get('mode2')
						add_item(name=f.get('title')+' - [COLOR red] '+mode2+'[/COLOR]', url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1)
					if addon.getSetting('auto-view') == 'true':
						typv='movies'
					xbmcplugin.setContent(addon_handle, typv)
					#xbmcplugin.setContent(addon_handle, 'movies')
				xbmcplugin.endOfDirectory(addon_handle)
			else:
				xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
				
		elif mode == "ListSubMenuZaluknij":
			zaluknijSubMenu()
		elif mode == "ListSubMenuZaluknij2":
			zaluknijSubMenu2()
		elif mode == 'Listepisodesxyz':
			import zaluknij
			links = zaluknij.Listepisodesxyz(exlink)
			items = len(links)
			if items>1:
				for f in links:
					add_item(name=f.get('title'), url=f.get('url'), mode='getVid:zaluknij', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('jak')}, itemcount=items)
				if addon.getSetting('auto-view') == 'true':
					typv='movies'
				xbmcplugin.setContent(addon_handle, typv)
				#xbmcplugin.setContent(addon_handle, 'movies')		
				xbmcplugin.endOfDirectory(addon_handle)
		elif mode == 'Listepisodeskinomoc':
			import kinomoc
			links = kinomoc.getSerial(exlink)
			items = len(links)
			if items>1:
				for f in links:
					add_item(name=f.get('title'), url=f.get('url'), mode='getVid:kinomoc', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('jak')}, itemcount=items)
				if addon.getSetting('auto-view') == 'true':
					typv='movies'
				xbmcplugin.setContent(addon_handle, typv)
				#xbmcplugin.setContent(addon_handle, 'movies')		
				xbmcplugin.endOfDirectory(addon_handle)
		elif mode == 'opcje':
			addon.openSettings()
			xbmc.executebuiltin('Container.Refresh') 
			
		elif mode == 'submfilsercc':
			filserccSubMenu(exlink)
			xbmcplugin.endOfDirectory(addon_handle)
			
		elif 'filtr:' in mode:
			import filsercc 

			
			#else:
			ff = mode.split(':')[1]
			if 'rok' in ff:
				rok = filsercc.getYear()

				addon.setSetting(ff[:1]+'rokV',rok)
				addon.setSetting(ff[:1]+'rokN',rok)
				fsortv = addon.getSetting('fsortV')
				fkatv = addon.getSetting('fkatV')
				fkrajv = addon.getSetting('fkrajV')
				frokv = addon.getSetting('frokV')
				ssortv = addon.getSetting('ssortV')
				skatv = addon.getSetting('skatV')
				skrajv = addon.getSetting('skrajV')
				srokv = addon.getSetting('srokV')
				
				
				dataf='?type=movie&tags='+fkatv+'&sort='+fsortv+'&year_to=2050&year_from='+frokv+'&page=0'
				datas='?type=show&tags='+skatv+'&sort='+ssortv+'&year_to=2050&year_from='+srokv+'&page=0'
				#dataf=fkatv+fnapv+fwerv+fsortv+frokv+fkrajv
				#datas=skatv+snapv+swerv+ssortv+srokv+skrajv
				
				addon.setSetting('fdata',dataf)
				addon.setSetting('sdata',datas)
				
				
				#addon.setSetting(ff+'N',n)
				xbmc.executebuiltin('Container.Refresh')
			else:
				if 'kraj' in ff:
					dd='kraj: '
					label = ["wszystkie","australia","belgia","chiny","czechy","dania","francja","hiszpania","hongkong","indie","japonia","kanada","korea poludniowa","niemcy","norwegia","polska","rosja","szwecja","usa","wielka brytania","wlochy"]
					value = ["","australia","belgia","chiny","czechy","dania","francja","hiszpania","hongkong","indie","japonia","kanada","korea poludniowa","niemcy","norwegia","polska","rosja","szwecja","usa","wielka brytania","wlochy"]
	
					#value, label = filsercc.getFiltry(ff)
				elif 'sort' in ff:
					dd='sortowanie: '
					label = ["losowo","najlepiej oceniane","najwięcej ocen","alfabetycznie a-z","alfabetycznie z-a"]
					value = ["","rate","ratecount","asc","desc"]
					
					
					#value, label = filsercc.getFiltry(ff)
				elif 'kat' in ff:
					dd='gatunek, tagi: '
					label = ["wszystkie","akcja","animacja","animacja dla doroslych","anime","basn","biograficzny","czarna komedia","dla dzieci","dla mlodziezy","dokumentalizowany","dokumentalny","dramat","dramat historyczny","dramat obyczajowy","dramat sadowy","erotyczny","familijny","fantasy","gangsterski","historyczny","horror","komedia","komedia kryminalna","komedia obycz.","komedia rom.","kostiumowy","krotkometrazowy","kryminal","melodramat","musical","muzyczny","obyczajowy","polityczny","przygodowy","psychologiczny","religijny","romans","satyra","sci-fi","sensacyjny","sportowy","surrealistyczny","swiateczny","szpiegowski","sztuki walki","thriller","western","wojenny","xxx"]
					value = ["","akcja","animacja","animacja dla doroslych","anime","basn","biograficzny","czarna komedia","dla dzieci","dla mlodziezy","dokumentalizowany","dokumentalny","dramat","dramat historyczny","dramat obyczajowy","dramat sadowy","erotyczny","familijny","fantasy","gangsterski","historyczny","horror","komedia","komedia kryminalna","komedia obycz.","komedia rom.","kostiumowy","krotkometrazowy","kryminal","melodramat","musical","muzyczny","obyczajowy","polityczny","przygodowy","psychologiczny","religijny","romans","satyra","sci-fi","sensacyjny","sportowy","surrealistyczny","swiateczny","szpiegowski","sztuki walki","thriller","western","wojenny","xxx"]
	
					
					#value, label = filsercc.getFiltry(ff)
					#value=['',"country[]=2","country[]=8","country[]=181861","country[]=11","country[]=181873","country[]=36","country[]=181851","country[]=181857","country[]=18","country[]=181871","country[]=2630","country[]=108","country[]=181862","country[]=79","country[]=34","country[]=181849","country[]=181855","country[]=181883","country[]=181847","country[]=181848","country[]=181850","country[]=181901","country[]=181852","country[]=181869","country[]=181882","country[]=181859","country[]=181867","country[]=181860","country[]=181863","country[]=181876","country[]=181880","country[]=181877","country[]=181887","country[]=181895","country[]=181878","country[]=94","country[]=1434"]
					#label=['all',"United States","United Kingdom","Canada","France","West Germany","Japan","Australia","Italy","International","Spain","Hong Kong","China","Ireland","Korea","India","Belgium","Denmark","Sweden","New Zealand","Netherlands","South Africa","Norway","Mexico","Switzerland","Austria","Czech Republic","Brazil","Russia","Argentina","Hungary","Poland","Finland","Israel","Romania","Luxembourg","Thailand","Taiwan"]
				#if 'sort' in ff or 'kraj' in ff or 'rok' in ff:
				#	sel = xbmcgui.Dialog().select('Select '+dd,label)
				#else:
				if 'kat' in ff or 'kraj' in ff:
					sel = xbmcgui.Dialog().multiselect('Wybierz '+dd,label)
				else:
					sel = xbmcgui.Dialog().select('Wybierz '+dd,label)
	
				if sel:

					if isinstance(sel,list):
						
						if 0 in sel: sel=[0]
						if len(sel)>1:
							v = ','+'%s'%(','.join( [ value[i] for i in sel])) if sel[0]!=0 else ''
	
							n = ', '.join( [ label[i] for i in sel])
						else:
							v = ','+'%s'%value[sel[0]] if value[sel[0]] else ''
							n = label[sel[0]]
					else:
						sel = sel if sel>-1 else quit()
						v = ''+'%s'%value[sel] if value[sel] else ''
						n = label[sel]
	
					addon.setSetting(ff+'V',v)
					addon.setSetting(ff+'N',n)
					fsortv = addon.getSetting('fsortV')
					fkatv = addon.getSetting('fkatV')
					fkrajv = addon.getSetting('fkrajV')
					frokv = addon.getSetting('frokV')
					ssortv = addon.getSetting('ssortV')
					skatv = addon.getSetting('skatV')
					skrajv = addon.getSetting('skrajV')
					srokv = addon.getSetting('srokV')
					if 'kraj' in ff or 'kat' in ff:
						v = addon.getSetting(ff[:1]+'katV')+addon.getSetting(ff[:1]+'krajV')

						xx = v[1:] if v.startswith(',') else v
						addon.setSetting(ff[:1]+'tagV',xx)
					ftagv = addon.getSetting('ftagV')
					stagv = addon.getSetting('stagV')	
					fkatv = addon.getSetting('fkatV')
					skatv = addon.getSetting('skatV')
					dataf='?type=movie&tags='+ftagv+'&sort='+fsortv+'&year_to=2050&year_from='+frokv+'&page=0'
					datas='?type=show&tags='+stagv+'&sort='+ssortv+'&year_to=2050&year_from='+srokv+'&page=0'

					addon.setSetting('fdata',dataf)
					addon.setSetting('sdata',datas)
					
					
					#addon.setSetting(ff+'N',n)
					xbmc.executebuiltin('Container.Refresh')
				else:
					quit()
	else:
		home()
		xbmcplugin.endOfDirectory(addon_handle)	
if __name__ == '__main__':
	router(sys.argv[2][1:])
