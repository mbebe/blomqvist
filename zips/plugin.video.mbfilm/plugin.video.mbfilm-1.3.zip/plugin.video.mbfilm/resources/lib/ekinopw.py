# -*- coding: UTF-8 -*-
import sys,re,os
import geturl as gethtml
from geturl import PLchar as PLchar
import requests

if sys.version_info >= (3,0,0):
# for Python 3
	from cmf3 import parseDOM
	from cmf3 import replaceHTMLCodes
	from urllib.parse import parse_qs, quote, urlencode, quote_plus
else:
    # for Python 2
	from cmf2 import parseDOM
	from cmf2 import replaceHTMLCodes
	from urllib import unquote, quote, urlencode, quote_plus

basurl='https://ekino.pw/'
sess = requests.Session()
def getFilmy(url,page):
	url=basurl+'filmy/'
	url = url + 'page/%s/' %page

	html,kuks = gethtml.getRequests(url)
	out=[]
	links = parseDOM(html,'div', attrs={'data-movie-id': ".+?",'class':"ml-item"})
	npage=[]
	if '/filmy/page/%s/'%str(int(page)+1) in  html:
		npage.append({'title':'Następna strona','url':'','image':'','plot':'','page':int(page)+1}) 

	for link in links:
		href = parseDOM(link, 'a', ret='href')[0] 
		imag = parseDOM(link, 'img', ret='data-original')[0] 
		imag = re.sub('p\/w(\d+)','p/w500',imag)
		tytul = parseDOM(link,'div', attrs={'class':"qtip-title"})[0]
		opis = parseDOM(link,'p')[0]
		dane = parseDOM(link,'div', attrs={'class':"jt-info"})
		year=''
		for dan in dane:
			year = re.findall('rel="tag">(.+?)<',dan)
			if year:
				year=year[0]
		jak = parseDOM(link,'div', attrs={'class':"jtip-quality"})
		jak = jak[0] if jak else ''
		year = re.findall('rel="tag">(.+?)<',link)
		year = year[0] if year else ''
		genre = re.findall('rel="category tag">([^>]+)<',link)
		kateg = ','.join([(x.strip()).lower() for x in genre]) if genre else ''
		out.append({'title':PLchar(tytul),'url':href,'image':imag,'plot':PLchar(opis),'year':year,'genre':PLchar(kateg),'code':jak})
	return out,npage
	
def ListSeriale(url,page):
	url=basurl+'series/'
	url = url + 'page/%s/' %page
	html,kuks = gethtml.getRequests(url)
	out=[]

	links = parseDOM(html,'div', attrs={'data-movie-id': ".+?",'class':"ml-item"})
	npage=[]
	if '/series/page/%s/'%str(int(page)+1) in  html:
		npage.append({'title':'Następna strona','url':'','image':'','plot':'','page':int(page)+1}) 

	for link in links:
		href = parseDOM(link, 'a', ret='href')[0] 
		imag = parseDOM(link, 'img', ret='data-original')[0]
		imag = re.sub('p\/w(\d+)','p/w500',imag)
		tytul = parseDOM(link,'div', attrs={'class':"qtip-title"})[0]
		opis = parseDOM(link,'p')[0]
		dane = parseDOM(link,'div', attrs={'class':"jt-info"})
		year=''
		for dan in dane:
			year = re.findall('rel="tag">(.+?)<',dan)
			if year:
				year=year[0]
		jak = parseDOM(link,'div', attrs={'class':"jtip-quality"})
		jak = jak[0] if jak else ''
		year = re.findall('rel="tag">(.+?)<',link)
		year = year[0] if year else ''
		genre = re.findall('rel="category tag">([^>]+)<',link)
		kateg = ','.join([(x.strip()).lower() for x in genre]) if genre else ''
		out.append({'title':PLchar(tytul),'url':href,'image':imag,'plot':PLchar(opis),'year':year,'genre':kateg,'code':jak})
	return out,npage

def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
def getSerial(url):
	html,kuks = gethtml.getRequests(url)

	opisy = parseDOM(html,'div', attrs={'class': "mvic-desc"})[0]
	episodes=[]
	tytul = parseDOM(opisy,'h3')[0]#
	opis = parseDOM(opisy,'p', attrs={'class': "f-desc"})[0]
	genre = re.findall('rel="category tag">([^>]+)<',opisy)
	kateg = ','.join([(x.strip()).lower() for x in genre]) if genre else ''
	imgs = parseDOM(html,'div', attrs={'class': "thumb mvic-thumb"})[0]
	img = parseDOM(imgs, 'img', ret='src')[0] 
	rys = re.sub('p\/w(\d+)','p/w500',img)
	
	links = parseDOM(html,'div', attrs={'class': "tvseason"})
	for link in links:
		ses = re.findall('Sezon (\d+)',link)
		if ses:
			eps = re.findall('a href="(.+?)">(.+?)</a>',link)
			for href,ep in eps:
				epis = re.findall('(\d+)',ep)
				tyt1 = 'S%02dE%02d'%(int(ses[0]),int(epis[0]))
				tyt = '%s - (%s)'%(tytul,tyt1)
				episodes.append({'title':PLchar(tyt),'url':PLchar(href),'image':rys,'season':int(ses[0]),'plot':PLchar(opis),'genre':PLchar(kateg),'episode':int(epis[0])})
	seasons = splitToSeasons(episodes)
	return seasons

def getVideo(url):
	out=[]
	html,kuks = gethtml.getRequests(url)
	iframe = parseDOM(html, 'iframe', ret='src')[0] 
	return iframe,True

def getHqq(iframe):
	strimid = re.findall('v=(.+?)$',iframe)[0]
	
	headers = {
		'Host': 'hqq.tv',
		'user-agent': 'Dalvik/1.6.0 (Linux; Android 9; SM-G950F Build/PPR1.180610.011; wv)',
		'accept': '*/*, */*',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'x-requested-with': 'XMLHttpRequest',
		'dnt': '1',
		'te': 'trailers',
	}

	params = (
		('ver', '0'),
		('secure', '0'),
		('adb', '0/'),
		('v', strimid),
		('token', ''),
		('gt', ''),
	)

	response = sess.get('https://hqq.tv/player/get_md5.php', headers=headers, params=params, cookies=sess.cookies,verify=False)
	
	sc=''.join(['%s=%s;'%(c.name, c.value) for c in sess.cookies])

	hea= '&'.join(['%s=%s' % (name, value) for (name, value) in headers.items()])	

	uax='Dalvik/1.6.0 (Linux; Android 9; SM-G950F Build/PPR1.180610.011; wv)'
	stream_url =response.url+'.mp4.m3u8'+'|User-Agent='+quote(uax)+'&Cookie='+sc
	return stream_url#,True
	
def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]

	if d:
		url=basurl+'?s='+d
		html,kuks = gethtml.getRequests(url)
		links = parseDOM(html,'div', attrs={'data-movie-id': ".+?",'class':"ml-item"})
		for link in links:
			href = parseDOM(link, 'a', ret='href')[0]
			tytul = parseDOM(link, 'h2')[0]
			imag = (parseDOM(link, 'img', ret='data-original')[0]).strip()
			imag = 'http:'+ imag if imag.startswith('//') else imag
			jak  = parseDOM(link,'div', attrs={'class':"jtip-quality"})
			jak = jak[0] if jak else ''
			opisy  = parseDOM(link,'p', attrs={'class':"f-desc"})
			opis  = parseDOM(opisy,'p')[0] if opisy else ''
			genre = re.findall('rel="category tag">([^>]+)<',link)
			kateg = ','.join([(x.strip()).lower() for x in genre]) if genre else ''
			year = re.findall('rel="tag">(\d+)<',link)
			year = year[0] if year else ''
			if '/series/' in href:
				sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'genre':PLchar(kateg),'code':jak})
			else:
				fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'genre':PLchar(kateg),'code':jak})
	return fout,sout,npage