# -*- coding: UTF-8 -*-
import sys,re,os, cookielib
import geturl as gethtml
from geturl import PLchar as PLchar
import xbmc, xbmcaddon

addon = xbmcaddon.Addon(id='plugin.video.mbfilm')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')

COOKIEFILEzaluknij = os.path.join(DATAPATH,'zaluknij.cookie')

cj = cookielib.LWPCookieJar(COOKIEFILEzaluknij)
cj.load()
kuksy2=''.join(['%s=%s;'%(c.name, c.value) for c in cj])
if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus
    import urllib.parse as urlparse
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse

basurl='http://maxfilms.eu'
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0'

cuk = gethtml.get_setting('dguardkukzaluknij')

headersc = {
	
		'Referer':basurl,
		'user-agent': UA,
		'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
	}

def ListContent(url,page):

	nturl = re.sub('/\\d+','/%d'%(int(page)+1),url)
	url = re.sub('\/\\d+','/%d'%int(page),url)

	html,kuks = gethtml.getRequests(url,headers=headersc)
	npage=[]
	fout=[]
	sout=[]

	pages = parseDOM(html,'div', attrs={'class': "pages"}) 
	if pages:
		nturl2 = nturl.split('?')[1]
		if pages[0].find(nturl2+'"')>-1:

			npage.append({'title':'Następna strona','url':nturl,'image':'','plot':'','page':int(page)+1})

	rgx=re.findall('newsBar">.*?img src="(.+?)".*?a href="(.+?)"><h3>(.+?)<.*?<div id=tekscik>(.+?)<',html,re.DOTALL)
	for imag,href,tyt,opis in rgx:

		opis = re.sub("<[^>]*>","",opis)
		imag = 'http://maxfilms.eu/'+ imag if imag.startswith('img') else imag
		href = 'http://maxfilms.eu'+ href if href.startswith('?') else href
		fout.append({'title':PLchar(tyt),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':'','code':'','genre':'', 'duration':'', 'mode2':'dudaplayer'})

			
	return fout,sout,npage

def ListContent2(url,page):

	html,kuks = gethtml.getRequests(url,headers=headersc)
	npage=[]
	fout=[]
	sout=[]

	result = parseDOM(html,'div', attrs={'class': "box"}) [0]

	
	rgx=re.findall('a href="(.+?)">(.+?)<\/a><\/h3>(.+?)<',result,re.DOTALL)
	for href,tyt,opis in rgx:

		opis = re.sub("<[^>]*>","",opis)

		href = 'http://maxfilms.eu'+ href if href.startswith('?') else href
		fout.append({'title':PLchar(tyt),'url':PLchar(href),'image':'DefaultMovies.png','plot':PLchar(opis),'year':'','code':'','genre':'', 'duration':'', 'mode2':'dudaplayer'})

			
	return fout,sout,npage
	
def ListContentSearch(query,page):

	headersc.update({'Content-Type': 'application/x-www-form-urlencoded'})
	dt = {'wyszukiwarka': query}
	url = 'http://maxfilms.eu/page/1'

	html,kuks = gethtml.getRequests(url,data=dt,headers=headersc)
	npage=[]
	fout=[]
	sout=[]
	result = parseDOM(html,'div', attrs={'class': "box"})[0] 
	dd=re.findall('a href="(.+?)">(.+?)<',result,re.DOTALL)
	for href, tyt in dd:

		fout.append({'title':PLchar(tyt),'url':PLchar(href),'image':'DefaultMovies.png','plot':'','year':'','code':'','genre':'', 'duration':'', 'mode2':'dudaplayer'})
	return fout,sout,npage
	
def SelectList(url):
	out=[]

	url = 'http://maxfilms.eu/?go=tags'
	html,kuks = gethtml.getRequests(url,headers=headersc)

	labs = 'tag'
	result = parseDOM(html,'div', attrs={'class': "box",'id': "tagcloud"})[0] # <div class="box" id="tagcloud">
	for href, dan in re.findall('<a href="(.+?)".*?">(.+?)<\/a>',result):
		href = 'http://maxfilms.eu'+ href if href.startswith('?') else href

		out.append({'href':href,'host':PLchar(dan)})

	if out:
		if len(out) > 1:
			u = [ x.get('href') for x in  out]
			h = [ x.get('host') for x in  out]
			sel = gethtml.selectDialog("Wybierz %s:"%labs, h)
			nturl = out[sel].get('href') if sel>-1 else ''
		else:
			nturl = out[0].get('href')
	return nturl 

def getVideo(url):
	out=[]

	html,kuks = gethtml.getRequests(url,headers=headersc)
	stream_url=''
	stream_url = parseDOM(html, 'iframe', ret='src')#[0]

	if stream_url:
		stream_url = 'https:'+ stream_url[0] if stream_url[0].startswith('//') else stream_url[0]

		return stream_url,True
	else:
		return '','quit'

def szukcd(d):
	page=1
	fout=[]
	sout=[]
	url=d

	fout,sout,npage=ListContentSearch(url,page)
	return fout,sout,npage
	
def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]

	if d:
		fout,sout,npage=szukcd(d)

	return fout,sout,npage
