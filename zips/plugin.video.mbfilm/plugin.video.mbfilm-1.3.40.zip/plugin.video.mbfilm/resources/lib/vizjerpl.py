# -*- coding: UTF-8 -*-
import sys,re,os
import geturl as gethtml
from geturl import PLchar as PLchar

if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus
    import urllib.parse as urlparse
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse

basurl='https://vizjer.pl/'
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'

cuk = gethtml.get_setting('dguardkukvizjer')
headers2 = {
    'Host': 'vizjer.pl',
    'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0',
    'accept': '*/*',
	'cookie':cuk,
    'accept-language': 'pl,en-US;q=0.7,en;q=0.3',} 

def getFilmy(url,page):
	out=[]
	npage=[]
	if '?page=' in url:
		nturl = re.sub('\?page=\\d+','?page=%d'%(int(page)+1),url)
		url = re.sub('\?page=\\d+','?page=%d'%int(page),url)
	else:
		nturl = url + '?page=%d' %(int(page)+1)
		url = url + '?page=%d' %int(page)
	
	
	
	try:
		html,kuks = gethtml.getRequests(url,headers=headers2)
		try:
			if html.find('"?page=%d"'%(int(page)+1))>0:
				npage.append({'title':'Następna strona','url':nturl,'image':'','plot':'','page':int(page)+1})
		except:
			pass

		links = parseDOM(html,'div', attrs={'class': "col-xs-\d+ col-sm-\d+ col-lg-\d+"})
		

		for link in links:

			href = parseDOM(link, 'a', ret='href')
			if href:
				href = href[0]
			else:
				continue
			imag = parseDOM(link, 'img', ret='src')[0]
			imag += '|Cookie='+cuk
			imag = 'https://vizjer.pl'+ imag if imag.startswith('/') else imag
			href = 'https://vizjer.pl'+ href if href.startswith('/') else href
			#href = basurl+href
			
			tyt = parseDOM(link, 'a', ret='title')[0] 
			rok = parseDOM(link,'div', attrs={'class': "year"}) 
			rok = rok[0] if rok else ''

			opis = tyt
			rodz = ''
			genre=''
			out.append({'title':PLchar(tyt),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':rok,'code':rodz,'genre':genre,'mode2':'vizjerpl'})
	except:
		pass
	
	return out,npage


	
def ListCateg(co,rodz):

	label =["Akcja","Animowane","Biografie","Dokumentalne","Dramat","Familijne","Fantasy","Historyczne","Horror","Katastroficzne","Komedia","Kryminał","Muzyczne","Obyczajowy","Polskie","Przygodowe","Sci-Fi","Sensacyjne","Sport","Thriller","Wojenne"]
	value =["search.php?gatunek=Akcja&tabela=","search.php?gatunek=Animowane&tabela=","search.php?gatunek=Biografie&tabela=","search.php?gatunek=Dokumentalne&tabela=","search.php?gatunek=Dramat&tabela=","search.php?gatunek=Familijne&tabela=","search.php?gatunek=Fantasy&tabela=","search.php?gatunek=Historyczne&tabela=","search.php?gatunek=Horror&tabela=","search.php?gatunek=Katastroficzne&tabela=","search.php?gatunek=Komedia&tabela=","search.php?gatunek=Kryminał&tabela=","search.php?gatunek=Muzyczny&tabela=","search.php?gatunek=Obyczajowy&tabela=","search.php?gatunek=Polski&tabela=","search.php?gatunek=Przygodowe&tabela=","search.php?gatunek=Sci-Fi&tabela=","search.php?gatunek=Sensacyjne&tabela=","search.php?gatunek=Sport&tabela=","search.php?gatunek=Thriller&tabela=","search.php?gatunek=Wojenne&tabela="]
	nazwa = "Wybierz kategorię"
	if rodz=='alfabet':
		label =["0-9","A","B","C","D","E","F","G","H","I","J","K","L","Ł","M","N","O","P","R","S","T","U","V","W","Y","Z","Ż","Ź"]
		value =["searcha.php?litera=liczba&tabela=","searcha.php?litera=A&tabela=","searcha.php?litera=B&tabela=","searcha.php?litera=C&tabela=","searcha.php?litera=D&tabela=","searcha.php?litera=E&tabela=","searcha.php?litera=F&tabela=","searcha.php?litera=G&tabela=","searcha.php?litera=H&tabela=","searcha.php?litera=I&tabela=","searcha.php?litera=J&tabela=","searcha.php?litera=K&tabela=","searcha.php?litera=L&tabela=","searcha.php?litera=Ł&tabela=","searcha.php?litera=M&tabela=","searcha.php?litera=N&tabela=","searcha.php?litera=O&tabela=","searcha.php?litera=P&tabela=","searcha.php?litera=R&tabela=","searcha.php?litera=S&tabela=","searcha.php?litera=T&tabela=","searcha.php?litera=U&tabela=","searcha.php?litera=U&tabela=","searcha.php?litera=W&tabela=","searcha.php?litera=Y&tabela=","searcha.php?litera=Z&tabela=","searcha.php?litera=Ż&tabela=","searcha.php?litera=Ź&tabela="]
		nazwa=  "Wybierz literę"
	sel = gethtml.selectDialog(nazwa, label)
	if sel>-1:
		kategoria = basurl+value[sel]+co# if sel>-1 else ''
		return kategoria
	else:
		quit()
	
def getLinks(url):

	html,kuks = gethtml.getRequests(url)
	out=[]
	imgdiv = parseDOM(html,'div', attrs={'class': "entry\-content.+?"})[0]
	imag = (parseDOM(imgdiv, 'img', ret='src')[0]).strip()
	imag+='|User-Agent='+quote(UA)+'&Cookie='+quote(kuks)
	imag = 'http:'+ imag if imag.startswith('//') else imag
	result = parseDOM(html,'div', attrs={'id': "tab.+?",'class': "tab.+?"})[0]
	tyt = parseDOM(result,'h4')[0]
	tytul = re.findall('serial(.+?)online za',tyt)[0].strip(" ")
	links = parseDOM(result,'p')
	
	npage=[]
	for link in links:
		tyt2 = parseDOM(link, 'a')[0]
		hrefs = re.findall('a href ="(.+?)"',link)
		href = '|'.join([(x.strip()).lower() for x in hrefs]) if hrefs else ''
		tytul2 = '%s - %s'%(tytul,tyt2.replace('#',''))
		out.append({'title':PLchar(tytul2),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(tytul)})
	
	return out,npage
	
def ListSeriale(url,page):
	out=[]
	npage=[]
	if '?page=' in url:
		nturl = re.sub('\?page=\\d+','?page=%d'%(int(page)+1),url)
		url = re.sub('\?page=\\d+','?page=%d'%int(page),url)
	else:
		nturl = url + '?page=%d' %(int(page)+1)
		url = url + '?page=%d' %int(page)
	try:

		html,kuks = gethtml.getRequests(url,headers=headers2)
		try:
			if html.find('"?page=%d"'%(int(page)+1))>0:
				npage.append({'title':'Następna strona','url':nturl,'image':'','plot':'','page':int(page)+1})
		except:
			pass

		links = parseDOM(html,'div', attrs={'class': "col-xs-\d+ col-sm-\d+ col-lg-\d+"})
		

		for link in links:

			href = parseDOM(link, 'a', ret='href')
			if href:
				href = href[0]
			else:
				continue
			imag = parseDOM(link, 'img', ret='src')[0]
			imag += '|Cookie='+cuk
			imag = 'https://vizjer.pl'+ imag if imag.startswith('/') else imag
			href = 'https://vizjer.pl'+ href if href.startswith('/') else href
			#href = basurl+href
			
			tyt = parseDOM(link, 'a', ret='title')[0] 
			rok = parseDOM(html,'div', attrs={'class': "year"}) 
			rok = rok[0] if rok else ''
			opis = parseDOM(link, 'a', ret='data-text')# data-text
			opis = opis[0] if opis else tyt
			rodz = ''
			genre=''
			out.append({'title':PLchar(tyt),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':rok,'code':rodz,'genre':genre,'mode2':'vizjerpl'})
	except:
		pass
	
	return out,npage

def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
def getSerial(url):

	html,kuks = gethtml.getRequests(url,headers=headers2)

	imig = parseDOM(html,'div', attrs={'id':'single-poster', 'class': "col\-sm\-\d+"})
	imig = imig[0] if imig else html
	imag = parseDOM(imig , 'img', ret='src')[0]

	imag += '|Cookie='+cuk
	imag = 'https://vizjer.pl'+ imag if imag.startswith('/') else imag
	
	tytul = parseDOM(html,'div', attrs={'class': "col\-sm\-offset\-\d+ col\-sm\-\d+"})[0]

	genre=''
	opis = parseDOM(html,'p', attrs={'class': "description"})
	opis =opis[0] if opis else tytul
	
	rok = ''
	episodes=[]

	src = re.compile('<ul id="episode-list">(.*?)</ul>').findall(html)
	src = src[-1] if src else ''
	episodes=[]
	odcinki = html.find('Odcinki')
	odcinek = html.find('Dodaj odcinek')
	gdzie = parseDOM(html,'ul', attrs={'id': "episode-list"})[0] 
	if 'ten serial nie posiada' in gdzie:
		return episodes
	links = re.compile('<a href="(.*?)">(.*?)</a>',re.DOTALL).findall(gdzie)
	imgsrc = re.compile('class="col-sm-3">(.+?)<div',re.DOTALL).findall(html)	
	imgsrc = imgsrc[1] if imgsrc else ''
	imgsrc = re.compile('<img src="(.*?)"',re.DOTALL).findall(imgsrc)
	imgsrc = imgsrc[-1]+'|Cookie='+cuk if imgsrc else ''
	for h,t in links:
		t= PLchar(t.strip())
		t=re.sub(' +',' ',t)
		data = re.compile('[sS](\d+)[Ee](\d+)').findall(t)
		episodes.append({'title':PLchar(t),'url':PLchar(h.strip()),'image':imag,'plot':PLchar(opis),'year':rok,'genre':genre,'season':int(data[0][0]) if data else '','episode':int(data[0][1]) if data else '','mode2':'vizjerpl'})

	seasons = splitToSeasons(episodes)
	return seasons

def szukcd(d):
	fout=[]
	sout=[]
	url='https://vizjer.pl/wyszukaj?phrase='+d
	html,kuks = gethtml.getRequests(url,headers=headers2)
	result=parseDOM(html,'div', attrs={'id': "advanced-search"})[0]
	links=parseDOM(result,'div', attrs={'class': "col-sm-4"})

	for link in links:
		imag = parseDOM(link, 'img', ret='src')[0]
		imag = imag.replace('thumb','big')
		imag += '|Cookie='+cuk
		imag = 'https://vizjer.pl'+ imag if imag.startswith('/') else imag
	
		href = parseDOM(link, 'a', ret='href')[0]   
		title = parseDOM(link,'div', attrs={'class': "title"})[0] 
		opis = parseDOM(link,'div', attrs={'class': "description text-justify"})#[0]  
		opis = opis[0] if opis else title
		year=''

		if '/serial-onlin' in href:
			sout.append({'title':PLchar(title),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'mode2':'rodzinne'})
		else:
			fout.append({'title':PLchar(title),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'mode2':'rodzinne'})
	return fout,sout
	

def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]
	if d:
		fout,sout = szukcd(d)
		#url=basurl+'searchf.php?szukaj='+d
		#fout,np1=getFilmy(url,1)
		#url=basurl+'searchs.php?szukaj='+d
		#sout,np2=ListSeriale(url,1)
	return fout,sout,npage

def getVideo(url):
	import base64
	import json
	out=[]
	
	html,kuks = gethtml.getRequests(url,headers=headers2)	
	videolinks = parseDOM(html,'td', attrs={'class': "link-to-video"})

	for vidlink in videolinks:
		href = parseDOM(vidlink,'a', ret='data-iframe')
		href = json.loads(base64.b64decode(href[0]))
		href = href['src']
		host = urlparse.urlsplit(href).netloc
		out.append({'href':href,'host':host})
	stream_url=''
	if out:
		if len(out) > 1:
			u = [ x.get('href') for x in  out]
			h = [ x.get('host') for x in  out]
			sel = gethtml.selectDialog("Źródło", h)
			nturl = out[sel].get('href') if sel>-1 else ''
			host= out[sel].get('host') if sel>-1 else ''
		else:
			nturl = out[0].get('href')

		if 'playtube' in nturl or 'mintload' in nturl:
    	
			import filmninja
			stream_url,resol = filmninja.getPlaytube(nturl,url)
		else:
			stream_url = nturl
	return stream_url,True

