# -*- coding: utf-8 -*-

import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import resolveurl as urlresolver

try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
cache = StorageServer.StorageServer('segos')
import resources.lib.segos as segos #segos
import resources.lib.cdapl as cdapl #cdapl
base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonId     = my_addon.getAddonInfo('id')
addonName       = my_addon.getAddonInfo('name')
PATH        = my_addon.getAddonInfo('path')
DATAPATH    = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES   = PATH+'/resources/'
FANART      = None

def addLinkItem(name, url, mode, page=1, iconimage=None, infoLabels=False, IsPlayable=True,fanart=FANART,itemcount=1):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'page':page})
    if iconimage==None:
        iconimage='DefaultFolder.png'
    li = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    li.setArt({ 'poster': iconimage, 'thumb' : iconimage, 'icon' : iconimage ,'fanart':fanart,'banner':iconimage})
    if not infoLabels:
        infoLabels={'title': name}
    li.setInfo(type='video', infoLabels=infoLabels)
    if IsPlayable:
        li.setProperty('IsPlayable', 'true')
    if fanart:
        li.setProperty('fanart_image',fanart)
    isp = []
    if infoLabels.get('trailer',''):
        isp.append(('Zwiastun', 'RunPlugin(plugin://%s?mode=zwiastun&ex_link=%s)'%(addonId,infoLabels.get('trailer'))))
    li.addContextMenuItems(isp, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=li,isFolder=False,totalItems=itemcount)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = '%R, %Y, %P')
    return ok
def addDir(name,ex_link=None, page=0, mode='folder',iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART,contextmenu=None,itemcount=1):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'page' : page})
    li = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    if infoLabels:
        li.setInfo(type='video', infoLabels=infoLabels)
    if fanart:
        li.setProperty('fanart_image', fanart )
    if contextmenu:
        isp=contextmenu
        li.addContextMenuItems(isp, replaceItems=True)
    else:
        isp = []
        isp.append(('Informacja', 'XBMC.Action(Info)'),)
        li.addContextMenuItems(isp, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True,totalItems=itemcount)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = '%P')
    return ok

def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        out_dict[k] = v
    return out_dict
def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))
	
def ListSerials(ex_link,page):
	items,pagination = segos.scanPageSer(ex_link,int(page))
	infoTab = True if 'true' in my_addon.getSetting('infoTab') else False
	infoTab = False
	if pagination[0]:
		addLinkItem(name='[COLOR blue]<< Poprzednia strona <<[/COLOR]', url=ex_link, page=pagination[0], mode='__page__S', IsPlayable=False)
	item=len(items)
	for f in items:
		f.update(segos.getMovieInfo(f.get('url'),infoTab))
		addDir(f.get('title'),ex_link=f.get('url'),mode='epizody',infoLabels=f,iconImage=f.get('img'))
	if pagination[1]:
		addLinkItem(name='[COLOR blue]>> Nast\xc4\x99pna strona >>[/COLOR]', url=ex_link, page=pagination[1], mode='__page__S', IsPlayable=False)
	xbmcplugin.endOfDirectory(addon_handle)	
def ListMovies(ex_link,page):
	items,pagination = segos.scanPage(ex_link,int(page))
	infoTab = True if 'true' in my_addon.getSetting('infoTab') else False
	infoTab = False
	if pagination[0]:
		addLinkItem(name='[COLOR blue]<< Poprzednia strona <<[/COLOR]', url=ex_link, page=pagination[0], mode='__page__M', IsPlayable=False)
	item=len(items)
	for f in items:
		f.update(segos.getMovieInfo(f.get('url'),infoTab))
		url=f.get('url')
		if '?page=seriale' in url:
			addDir('[B][COLOR blue]Serial [/B][/COLOR]'+f.get('title'),ex_link=f.get('url'),mode='epizody',infoLabels=f,iconImage=f.get('img'))	
		else:			
			addLinkItem(name=f.get('title'), url=f.get('url'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,itemcount=item)
	if pagination[1]:
		addLinkItem(name='[COLOR blue]>> Nast\xc4\x99pna strona >>[/COLOR]', url=ex_link, page=pagination[1], mode='__page__M', IsPlayable=False)
	xbmcplugin.endOfDirectory(addon_handle)	
	
def ListMoviesKAT(ex_link,page):
	items,pagination = segos.scanPage(ex_link,int(page))
	infoTab = True if 'true' in my_addon.getSetting('infoTab') else False
	infoTab = False
	if pagination[0]:
		addLinkItem(name='[COLOR blue]<< Poprzednia strona <<[/COLOR]', url=ex_link, page=pagination[0], mode='__page__MK', IsPlayable=False)
	item=len(items)
	for f in items:
		f.update(segos.getMovieInfo(f.get('url'),infoTab))
		url=f.get('url')
		if '?page=seriale' in url:
			addDir('[B][COLOR blue]Serial [/B][/COLOR]'+f.get('title'),ex_link=f.get('url'),mode='epizody',infoLabels=f,iconImage=f.get('img'))	
		else:			
			addLinkItem(name=f.get('title'), url=f.get('url'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,itemcount=item)
	if pagination[1]:
		addLinkItem(name='[COLOR blue]>> Nast\xc4\x99pna strona >>[/COLOR]', url=ex_link, page=pagination[1], mode='__page__MK', IsPlayable=False)
	xbmcplugin.endOfDirectory(addon_handle)		
	
	
def ListEpisodes(ex_link):
	items = segos.getSeasons(ex_link)
	item=len(items)
	for f in items:
		addLinkItem(name=f.get('title'), url=f.get('url'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,itemcount=item)
	xbmcplugin.endOfDirectory(addon_handle)	
def getLinks(ex_link):
	links = segos.getVideoLinks(ex_link)		
	stream_url=''
	if len(links):
		if len(links)>1:
			linksSEG = [x.get('host') for x in links]
			s = xbmcgui.Dialog().select('Linki',linksSEG)
		else:
			s=0
		hrefSEG=links[s].get('href') if s>-1 else ''
		host=links[s].get('host') if s>-1 else ''
		if 'segos.es' in hrefSEG:
			hrefSEG = segos.getSegosVid(hrefSEG)
		elif 'segos' in hrefSEG or 'mp4' in hrefSEG:
			stream_url = hrefSEG
		else:
			stream_url=''
		if 'cda.pl' in hrefSEG:
			stream_url = cdapl.getLinkCda(hrefSEG)
			
			if type(stream_url) is list:
				qual = [x[1] for x in stream_url]
				select = xbmcgui.Dialog().select('Wybierz jakość (cda)', qual)
				if select>-1:
					stream_url = stream_url[select][0]
				else:

					stream_url=''
		elif 'rapidvideo' in hrefSEG or 'raptu' in hrefSEG:
			import resources.lib.vidsources as vidsrc
			stream_url = vidsrc.getVideo(hrefSEG)
			if type(stream_url) is list:
				if len(stream_url)==1:
					stream_url = stream_url[0][0]
				else:
					qual = [x[1] for x in stream_url]
					select = xbmcgui.Dialog().select('Wybierz jakość (raptu, rapidvideo)', qual)
					if select>-1:
						stream_url = stream_url[select][0]
					else:
						try:stream_url = urlresolver.resolve(hrefSEG)
						except: stream_url=''
		else:#if not stream_url and hrefSEG:
			try:
				stream_url = urlresolver.resolve(hrefSEG)
			except Exception,e:
				stream_url=''
				s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))
				#quit()
	if stream_url:
		xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
	else:
		pass
	return	#xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
def login():
    u = my_addon.getSetting('user')
    p = my_addon.getSetting('pass')
    logged=False
    if u and p:
        logged =  segos.getLogin(u,p)
    if logged:
        addLinkItem('[B]Segos.es (%s)[/B]'%u,'',mode=' ',iconimage='',IsPlayable=False)
    else:
        addLinkItem('[B]Zaloguj[/B]','',mode='settings',iconimage='',IsPlayable=False)
segos.COOKIEFILE=os.path.join(DATAPATH,'segos.cookie')
def search():
    return cache.get('history').split(';')
def setHistory(entry):
    history = search()
    if history == ['']:
        history = []
    history.insert(0, entry)
    cache.set('history',';'.join(history[:50]))
def delOne(entry):
    history = search()
    if history:
        cache.set('history',';'.join(history[:50]))
    else:
        delAll()
def delAll():
    cache.delete('history')
xbmcplugin.setContent(addon_handle, 'movies')
mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
page = args.get('page',[1])[0]
fsortv = my_addon.getSetting('FsortV')
fsortn = my_addon.getSetting('FsortN') if fsortv else 'Domyslnie'
if mode is None:
	login()
	addDir(name='Top 10 odwiedzanych',ex_link='Top 10 odwiedzanych', mode='ListTop',page=1,iconImage='DefaultFolder.png',fanart=FANART)
	addDir(name='Top 10 ocenionych',ex_link='Top 10 ocenionych', mode='ListTop',page=1,iconImage='DefaultFolder.png',fanart=FANART)
	addDir(name='Ostatnie 10 dodanych',ex_link='Ostatnio dodane</h3>', mode='ListTop',page=1,iconImage='DefaultFolder.png',fanart=FANART)
	addLinkItem('[COLOR blue]Filtr:[/COLOR] [B]'+fsortn+'[/B]','',mode='filtr:Fsort',iconimage='',IsPlayable=False)
	addDir(name='[B][COLOR blue]Filmy[/B][/COLOR]',ex_link='http://segos.es/?page=filmy', mode='ListMovies',page=1,iconImage='DefaultFolder.png',fanart=FANART)
	addDir(name='  Kategorie',ex_link='cat', mode='GatunekRok',iconImage='DefaultFolder.png',fanart=FANART)
	addDir(name='[B][COLOR blue]Seriale[/B][/COLOR]',ex_link='http://segos.es/?page=seriale', mode='ListSerials',page=1,iconImage='DefaultFolder.png',fanart=FANART)
	addDir(name='Bajki',ex_link='http://segos.es/?page=bajki', mode='ListMovies',page=1,iconImage='DefaultFolder.png',fanart=FANART)
	addDir('Szukaj','',mode='Szukaj')
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'settings':
    my_addon.openSettings()
    xbmc.executebuiltin('XBMC.Container.Refresh()')
elif mode[0] == 'ListTop':
	items = segos.ListTop(ex_link)
	for f in items:
		url=f.get('url')
		if '?page=seriale' in url:
			addDir('[B][COLOR blue]Serial [/B][/COLOR]'+f.get('title'),ex_link=f.get('url'),mode='epizody',infoLabels=f,iconImage=f.get('img'))	
		else:		
			addLinkItem(name=f.get('title'), url=f.get('url'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,itemcount=10)
	xbmcplugin.endOfDirectory(addon_handle)
elif 'filtr' in mode[0]:
    _my_mode = mode[0].split(':')[-1]
    if _my_mode=='Fsort':
        msg = 'Sortowanie'
    elif _my_mode=='Bsort':
        msg = 'Sortowanie'
    label=['Domyslnie','Tyty\xc5\x82 (rosn\xc4\x85co)','Rok (rosnaco)','Data (rosnaco)','Tyty\xc5\x82 (malej\xc4\x85co)','Rok (malej\xc4\x85co)','Data (malej\xc4\x85co)']
    value=['','&sortby=title&according=asc&category=','&sortby=year&according=asc&category=','&sortby=date&according=asc&category=','&sortby=title&according=desc&category=','&sortby=year&according=desc&category=','&sortby=date&according=desc&category=']
    s = xbmcgui.Dialog().select(msg,label)
    s = s if s>-1 else 0	
    my_addon.setSetting(_my_mode+'V',value[s])
    my_addon.setSetting(_my_mode+'N',label[s])
    xbmc.executebuiltin('XBMC.Container.Refresh')
elif mode[0] == 'Opcje':
    my_addon.openSettings()
elif mode[0] == '__page__M':
    url = build_url({'mode': 'ListMovies', 'foldername': '', 'ex_link' : ex_link ,'page':page})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
elif mode[0] == '__page__MK':
    url = build_url({'mode': 'ListMoviesKat', 'foldername': '', 'ex_link' : ex_link ,'page':page})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
elif mode[0] == '__page__S':
    url = build_url({'mode': 'ListSerials', 'foldername': '', 'ex_link' : ex_link ,'page':page})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
elif mode[0] == 'ListMovies':
    ListMovies(ex_link+fsortv,page)
elif mode[0] == 'ListMoviesKat':
    ListMoviesKAT(ex_link,page)
elif mode[0] == 'ListSerials':
    ListSerials(ex_link+fsortv,page)
elif mode[0] == 'epizody':
    ListEpisodes(ex_link)
elif mode[0] == 'getLinks':
    getLinks(ex_link)
elif mode[0] == 'ListSearch':	
    ListMovies(ex_link,int(1))
elif mode[0] == 'GatunekRok':
	data = segos.GatunekRok()
	if data:     
		genres = [x[1].strip() for x in data]
		hrefs = [x[0].strip() for x in data]
		for label,url in zip(genres,hrefs):
			genr=url.split('&category=')#[-1]
			if fsortv:
				linkx=genr[0]+fsortv+genr[-1]
			else:
				linkx=url
			addDir(name=label,ex_link=linkx, mode='ListMoviesKat',page=1,iconImage='DefaultFolder.png',fanart=FANART)
		xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] =='Szukaj':
	addDir('[COLOR lightgreen]Nowe Szukanie[/COLOR]','',mode='SzukajNowe')
	entries = search()
	if not entries == ['']:
		for entry in entries:
			contextmenu = []
			contextmenu.append(('Usu\xc5\x84', 'XBMC.Container.Refresh(%s)'% build_url({'mode': 'SzukajUsun', 'ex_link' : entry})),)
			contextmenu.append(('Usu\xc5\x84 ca\xc5\x82\xc4\x85 histori\xc4\x99', 'XBMC.Container.Update(%s)' % build_url({'mode': 'SzukajUsunAll'})),)
			addDir(name=entry, ex_link='http://segos.es/?search='+urllib.quote_plus(entry), mode='ListSearch', page=1, fanart=None, contextmenu=contextmenu)
	xbmcplugin.endOfDirectory(addon_handle)	
	#else:
	#	quit()
elif mode[0] =='SzukajNowe':
	d = xbmcgui.Dialog().input('Szukaj, Podaj tytu\xc5\x82', type=xbmcgui.INPUT_ALPHANUM)
	if d:
		setHistory(d)
		ListMovies('http://segos.es/?search='+urllib.quote_plus(d),int(1))
	else:
		quit()
elif mode[0] =='SzukajUsun':
    delOne(ex_link)
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))
elif mode[0] == 'SzukajUsunAll':
    delAll()
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))
elif mode[0] == 'zwiastun':
    id=ex_link.split('/')[-1].split('=')[-1]
    mediaPath = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % id
    xbmc.executebuiltin('xbmc.PlayMedia('+mediaPath+')')
elif mode[0] == 'folder':
    pass
else:
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))




