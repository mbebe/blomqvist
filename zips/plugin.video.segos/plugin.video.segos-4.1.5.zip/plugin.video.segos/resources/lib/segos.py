# -*- coding: utf-8 -*-

import urllib2,urllib
import os,re
import urlparse
import cookielib
import requests
from CommonFunctions import parseDOM
import cfdeco7
import xbmc,xbmcgui,xbmcaddon

my_addon	 = xbmcaddon.Addon()
DATAPATH	 = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
COOKIEFILE = os.path.join(DATAPATH,'segos.cookie')


UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0'

sess = cfdeco7.create_scraper()
sess.cookies = cookielib.LWPCookieJar(COOKIEFILE)
BASEURL='http://segos.es/'

TIMEOUT = 10

dataf =  my_addon.getSetting('fdata')	
datas =  my_addon.getSetting('sdata')	
datab = my_addon.getSetting('bdata')	


def getUrlReq(url,kuk=''):
	if os.path.isfile(COOKIEFILE):
		sess.cookies.load()
	aa=sess.cookies
	my_cookies = requests.utils.dict_from_cookiejar(sess.cookies)
	found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]

	kukz= ';'.join(found)	

	content=sess.get(url,verify=False).text	
	return content,kukz

def getUrlJson(url,kuk=''):
	if os.path.isfile(COOKIEFILE):
		sess.cookies.load()
	aa=sess.cookies
	my_cookies = requests.utils.dict_from_cookiejar(sess.cookies)
	found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]

	kukz= ';'.join(found)	

	content=sess.get(url,verify=False).json()
	return content,kukz
def getPost(url,data):
	if os.path.isfile(COOKIEFILE):
		sess.cookies.load()
	my_cookies = requests.utils.dict_from_cookiejar(sess.cookies)
	found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]
	
	kukz= ';'.join(found)
	tok  = my_addon.getSetting('token')	
	
	headersok={'User-Agent': UA,'Content-Type': 'application/x-www-form-urlencoded','X-Requested-With': 'XMLHttpRequest'}
	if data:
		datax='_token='+tok+data
	else:
		datax='_token='+tok	
	content=sess.post(url,data=datax,headers=headersok,verify=False).json()
	if 'top-filmy' in url:
		return content['options'],kukz
	else:
		return content['content'],kukz

	
def getUrlReqPost(data):
	if os.path.isfile(COOKIEFILE):
		sess.cookies.load()
	aa=sess.cookies
	my_cookies = requests.utils.dict_from_cookiejar(sess.cookies)
	found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]
	
	kukz= ';'.join(found)	

	content=sess.post('https://segos.es/?page=needtosee',data=data,verify=False).text	
	return content,kukz

def getLogin(u='',p=''):
	dataPath=os.path.dirname(COOKIEFILE)
	if not os.path.exists(dataPath):
		os.makedirs(dataPath)
	try:

		url ='https://segos.es/login'
		try:
			aa=sess.get(url,verify=False).content

		except Exception,e:
			xbmc.log('@#@bledy: %s' % e, xbmc.LOGNOTICE)	
		
		tok=re.findall("""['"]csrf-token['"]\s*content=['"](.+?)['"]""",aa)
		if tok:
			my_addon.setSetting('token', tok[0])
		data = '_token=%s&previous=https://segos.es/&email=%s&password=%s'%(tok[0],urllib.quote(u),p)
		sess.headers.update({'content-type': 'application/x-www-form-urlencoded',})
		response = sess.post('https://segos.es/login-s',data=data,allow_redirects=False,verify=False)
		kkk=sess.cookies
		sess.cookies.save()
		
		content=sess.get(BASEURL,verify=False).text
		aa=sess.cookies
		my_cookies = requests.utils.dict_from_cookiejar(sess.cookies)
		found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]
		
		kukz= ';'.join(found)	
		my_addon.setSetting('kukis', kukz)
		my_addon.setSetting('kukis2', str(my_cookies))
	except:
		content=''
	out = True if content.find('Wyloguj')>0 else False
	kon = parseDOM(content,'span',ret='data-date')
	kon = 'premium do %s'%(kon[0]) if kon else 'darmowe'
	return out,kon
def ListPopular(top):
	
	out=[]
	if top=='popularf':
		data='&v_type=1'
	elif top=='populars':
		data='&v_type=3'
	elif top=='popularb':
		data='&v_type=2'
	url='https://segos.es/top-filmy'
	
	content,kuk = getPost(url,data)
	results = parseDOM(content,'div',attrs = {'class':'elements-slider__item'})#[0]

	for result in results:
		imag=re.findall('image: url\((.+?)\)',result)
		imag = imag[0] if imag else ''
		qual = re.findall('fifty--quality">(.+?)<',result)
		qual = qual[0] if qual else ''
		wer = re.findall('fifty--type">(.+?)<',result)
		wer = wer[0] if wer else ''
		tytul=(re.findall('slider__title">(.+?)<\/div>',result)[0]).replace('<b>','').replace('</b>','')
		plot = re.findall('slider__description">(.+?)<',result)
		plot = PLchar(plot[0]) if plot else ''
		href = re.findall('<a href="(.+?)" class=".+?" title="Odtw',result)[0] #a href="seriale/13-posterunek-1997-802235/S1-E3#player" class="play-button" title="Odtw
		href = BASEURL+href
		one = {'url'   : href,
			'title'  : PLchar(tytul),
			'plot'   : plot,
			'img'	: imag,
			'rating' : '',
			'genre' : '',
			'year'   : '',
			'code'  : wer,
			'trailer' : '',
			'mediatype': 'movie'
				}

		out.append(one)
	return out

def ListTop(top):
	out=[]
	if top=='dodanef':
		dane = '>Ostatnio dodane<'
	elif top=='dodanes':
		dane ='>Ostatnio dodane odcinki<'
		
	elif top=='ocenaf':
		dane='>Najlepiej Oceniane<'
	content,kuk = getUrlReq(BASEURL)

	results = parseDOM(content,'section',attrs = {'class':'section section--list.+?'})#[0]
	
	for result in results:
		if dane in result:

			results2 = parseDOM(result,'div',attrs = {'class':"elements-slider__item"})
			for result2 in results2:
				imag=re.findall('image: url\((.+?)\)',result2)
				imag = imag[0] if imag else ''
				qual = re.findall('fifty--quality">(.+?)<',result2)
				qual = qual[0] if qual else ''
				wer = re.findall('fifty--type">(.+?)<',result2)
				wer = wer[0] if wer else ''
				
				if top=='dodanes':
					tit = parseDOM(result2,'div',attrs = {'class':'elements-slider__title'})[0]#<div class="elements-slider__title">
					tit2 = parseDOM(tit,'div',attrs = {'class':'elements-slider__view.+?'})#[0] #<div class="elements-slider__views">
					tytul = (' '.join(tit2)).replace('<b>','').replace('</b>','')
				else:
					tytul=(re.findall('slider__title">(.+?)<\/div>',result2)[0]).replace('<b>','').replace('</b>','')
				plot = re.findall('slider__description">(.+?)<',result2)
				plot = PLchar(plot[0]) if plot else ''
				href = re.findall('<a href="(.+?)" class=".+?" title="Odtw',result2)[0]
				href = BASEURL+href
				one = {'url'   : href,
					'title'  : PLchar(tytul),
					'plot'   : plot,
					'img'	: imag,
					'rating' : '',
					'genre' : '',
					'year'   : '',
					'code'  : wer,
					'trailer' : '',
					'mediatype': 'movie'
						}

				out.append(one)

		else:
			continue
	return out

def scanPageSer(url,page=1):

	if '?page=' in url:
		url = re.sub('page=\\d+','page=%d'%int(page),url)
	else:
		url = url + '?page=%d' %page				
	my_mode = True 
	IsPlayable = False 
	
	content,kuk = getUrlReq(url)
	nextPage=False
	
	segUrl=url.replace(BASEURL,'').replace('page=%d'%page,'page=%d' %(page+1))
	if content.find(segUrl.split('/')[-1])>-1:
		nextPage = page+1
	ids = [(a.start(), a.end()) for a in re.finditer('<div class="col-lg-\\d+ col-md-\\d+', content)]
	ids.append( (-1,-1) )
	out=[]
	for i in range(len(ids[:-1])):
		tops = content[ ids[i][1]:ids[i+1][0] ]
		hrefTitle = re.compile('<a href="(.*?view.*?)"\\s*>(.*?)</a>').findall(tops)
		imag = re.compile('<img class="img-responsive" src="(.*?)"').findall(tops)
		categ = re.compile('category=[^"]+">(.*?)</a>').findall(tops)
		plot= re.compile('<b>Opis</b>(.*?)<',re.DOTALL).findall(tops)
		lang =  re.compile('src="/images/langs/(.*?).png">').findall(tops)
		quality = ' HD' if tops.find('src="/images/hd.')>-1 else ''
		trail = re.compile('class="embed-responsive-item" src="(.*?)"').findall(tops)
		imag = imag[0] if imag else ''
		if imag.startswith('/'):
			imag=BASEURL[:-1]+imag+'|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuk)
		elif imag.startswith('../'):
			imag=imag.replace('..',BASEURL)
		elif imag.startswith('obrazki'):
			imag=BASEURL+'/'+imag
		code = lang[0] if lang else ''
		code += quality if quality else ''
		if hrefTitle and imag:
			title = hrefTitle[0][1]
			year = re.search('\\((\\d{4})\\)',title)			
			one = {'url'   : BASEURL+hrefTitle[0][0],
				'title'  : PLchar(title),
				'plot'   : PLchar(plot[0].strip(': ')) if plot else '',
				'img'	: imag,
				'isFolder': my_mode,
				'IsPlayable':IsPlayable,
				'rating' : '',
				'genre' : ','.join(categ) if categ else '',
				'year'   : year.group(1) if year else '',
				'code'  : code.strip(),
				'trailer' : trail[0] if trail else '',
				'mediatype': 'movie'
					}
			out.append(one)
	prevPage = page-1 if page>1 else False
	return (out, (prevPage,nextPage))
	
def scanPageKat(gen,page=1):
	token  = my_addon.getSetting('token')

	urlnxt='https://segos.es/filmy/search'

	data = gen

	if page==1:
		url = urlnxt
	else:
		url = urlnxt + '?page=%d' %page
	content,kuk = getPost(url,data)
	ids = [(a.start(), a.end()) for a in re.finditer('div class="watch__item', content)]
	
	#
	
	ids.append( (-1,-1) )
	out=[]

	for i in range(len(ids[:-1])):
		tops = content[ ids[i][1]:ids[i+1][0] ]
		nxturl = re.findall('a href="(.+?)"',tops)[0]
		nxturl=BASEURL+nxturl if not nxturl.startswith('htt') else nxturl
		title = re.findall('title="(.+?)"',tops)[0]
		imag = re.findall('img src="(.+?)"',tops)[0]
		code = re.findall('"watch__type">(.+?)<',tops)[0]
		rating = re.findall('watch__rating">(.+?)<',tops)[0]
		plot=''
		year=''
		trail=''
		categ=''
		one = {'url'   : nxturl,				
			'title'  : PLchar(title),
			'plot'   : PLchar(plot[0].strip(': ')) if plot else '',
			'img'	: imag,
			'rating' : '',
			'genre' : ','.join(categ) if categ else '',
			'year'   : year.group(1) if year else '',
			'code'  : code.strip(),
			'trailer' : trail[0] if trail else '',
			'mediatype': 'movie'
				}
		out.append(one)
	nextPage=False
	prevPage=False
	return (out, (prevPage,nextPage))
	
def scanSearch(url):
	out=[]
	contents,k = getUrlJson(url)
	if contents:
		for content in contents:
			tit=content["title"]
			imag=content["image_name"]
			href=content["video_url"]
			one = {'url'   : href,				
				'title'  : PLchar(tit),
				'img'	: imag,
				'mediatype': 'movie'
					}
			out.append(one)
	return out
def scanMoja(url):
	content,k=getUrlReq(url)
	out=[]
	result = parseDOM(content,'div',attrs = {'class':"request-list"})[0]
	items = parseDOM(result,'div',attrs = {'class':"request-container"})# <div class="request-container">

	for item in items:
		hreftit=re.findall('href="(.+?)" title="(.+?)"',item)[0]
		imag = re.findall('src="(.+?)"',item)
		imag = imag[0] if imag else ''
		one = {'url'   : hreftit[0],				
			'title'  : PLchar(hreftit[1]),
			'img'	: imag,
			'mediatype': 'movie'
				}
		out.append(one)
	return out	
		
def scanPage(urlx,page=1):
	out=[]
	md,url=urlx.split('|')
	nwdata=eval('data'+md)
	if '?page=' in url:
		url = re.sub('page=\\d+','page=%d'%int(page),url)
	else:
		url = url + '?page=%d' %page
		
	content,kuk = getPost(url,nwdata)
	if' alert alert-info video-empty' in content:
		return out
	nextPage=False
	prevPage=False
	segUrl=url.replace(BASEURL,'').replace('page=%d'%page,'page=%d' %(page+1))
	if '?page=needtosee' in url:
		regex = '?page=needtosee&nr=%d'%(page+1)
		if content.find(regex)>0:
			nextPage = page+1
	else:
		if content.find('pagination__item pagination__item--next')>0:
			nextPage = page+1

	ids = [(a.start(), a.end()) for a in re.finditer('div class="watch__item', content)]

	ids.append( (-1,-1) )
	for i in range(len(ids[:-1])):
		tops = content[ ids[i][1]:ids[i+1][0] ]
		nxturl = re.findall('a href="(.+?)"',tops)[0]
		nxturl=BASEURL+nxturl if not nxturl.startswith('htt') else nxturl
		title = re.findall('title="(.+?)"',tops)[0]
		imag = re.findall('img src="(.+?)"',tops)[0]
		code = re.findall('"watch__type">(.+?)<',tops)[0]
		rating = re.findall('watch__rating">(.+?)<',tops)[0]
		plot=''
		year=''
		trail=''
		categ=''
		one = {'url'   : nxturl,				
			'title'  : PLchar(title),
			'plot'   : PLchar(plot[0].strip(': ')) if plot else '',
			'img'	: imag,
			'rating' : '',
			'genre' : ','.join(categ) if categ else '',
			'year'   : year.group(1) if year else '',
			'code'  : code.strip(),
			'trailer' : trail[0] if trail else '',
			'mediatype': 'movie'
				}
		out.append(one)
	return (out, (prevPage,nextPage))

def scanPageOK(url,page=1):
	
	if '?page=' in url:
		url = re.sub('page=\\d+','page=%d'%int(page),url)
	else:
		url = url + '?page=%d' %page	
	content,kuk = getUrlReq(url)
	nextPage=False
	
	segUrl=url.replace(BASEURL,'').replace('page=%d'%page,'page=%d' %(page+1))
	if '?page=needtosee' in url:
		regex = '?page=needtosee&nr=%d'%(page+1)
		if content.find(regex)>0:
			nextPage = page+1
	else:
		if content.find(segUrl.split('=')[-1])>-1:
			nextPage = page+1
	ids = [(a.start(), a.end()) for a in re.finditer('div class="watch__item', content)]
	
	#
	
	ids.append( (-1,-1) )
	out=[]

	for i in range(len(ids[:-1])):
		tops = content[ ids[i][1]:ids[i+1][0] ]
		nxturl = re.findall('a href="(.+?)"',tops)[0]
		nxturl=BASEURL+nxturl if not nxturl.startswith('htt') else nxturl
		title = re.findall('title="(.+?)"',tops)[0]
		imag = re.findall('img src="(.+?)"',tops)[0]
		code = re.findall('"watch__type">(.+?)<',tops)[0]
		rating = re.findall('watch__rating">(.+?)<',tops)[0]
		plot=''
		year=''
		trail=''
		categ=''
		one = {'url'   : nxturl,				
			'title'  : PLchar(title),
			'plot'   : PLchar(plot[0].strip(': ')) if plot else '',
			'img'	: imag,
			'rating' : '',
			'genre' : ','.join(categ) if categ else '',
			'year'   : year.group(1) if year else '',
			'code'  : code.strip(),
			'trailer' : trail[0] if trail else '',
			'mediatype': 'movie'
				}
		out.append(one)

	prevPage = page-1 if page>1 else False
	
	return (out, (prevPage,nextPage))
def getRecomend(url='http://segos.es/recomend_list.php'):
	outF=[]
	outB=[]
	content,kuk = getUrlReq(url)
	items = re.compile('<tr>(.*?)</tr>',re.DOTALL).findall(content)
	for item in items:
		hrefTitle = re.compile('<p><a href="(.*?)">(.*?)</a></p>').findall(item)
		imag = re.compile('<img src="(.*?)"').findall(item)
		if hrefTitle:
			one = {'url'   : BASEURL+hrefTitle[0][0],
				'title'  : PLchar(hrefTitle[0][1]),
				'plot'   : '',
				'img'	: BASEURL+imag[0]+'|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuk) if imag else '',
				'rating' : '',
				'year'   : '',
				'code'  : '',
					}
			if   '/bajki/' in hrefTitle[0][0]:
				outB.append(one)
			elif '/filmy/' in hrefTitle[0][0]:
				outF.append(one)
	return (outF,outB)
def getMovieInfo(url,infoTab=True):
	info={}
	if infoTab:
		content,kuk = getUrlReq(url)
		zx = content.find('<div id="myTabContent" class="tab-content">')
		if zx:
			tops=content[zx:-1]
			year = re.search('<b>Rok produkcji</b>:(.*?)<',tops,flags=re.MULTILINE|re.I)
			categ = re.search('<b>Gatunek</b>:(.*?)<',tops,flags=re.DOTALL)
			quality = re.search('<b>Jako\xc5\x9b\xc4\x87</b>:(.*?)<',tops,flags=re.MULTILINE|re.I)
			audio = re.search('<b>Audio</b>:(.*?)<',tops,flags=re.MULTILINE|re.I)
			lang = re.search('<b>J\xc4\x99zyk</b>:(.*?)<',tops,flags=re.MULTILINE|re.I)
			plot = re.search('<b>Opis</b>:(.*?)<',tops,flags=re.MULTILINE|re.I)
			if year:	info['year']=year.group(1).strip().strip('(').strip(')')
			if categ:   info['genre']=categ.group(1).strip()
			if quality: info['quality']=quality.group(1).strip()
			if audio:   info['audio']=audio.group(1).strip()
			if lang:	info['lang']=lang.group(1).strip()
			if plot:	info['plot']=PLchar(plot.group(1).strip())
			info['code']= ','.join([info.get('quality',''),info.get('lang',''),info.get('audio','')])
	return info
def getVideoLinks(url):
	out=[]
	content,kuk = getUrlReq(url)
	iframes = re.compile('div class="watch-table__column"(.*?)<div class="report-form-container"',re.DOTALL).findall(content)	
	for iframe in iframes:
		
		href = re.compile('data-link="(.*?)"').findall(iframe)
		if href:
			hrefSEG = href[0]
			dane=re.findall('"watch-table__row watch-table__row--small">(.+?)<',iframe)
			cc=', '.join(dane) if dane else ''
			host = urlparse.urlparse(hrefSEG).netloc
			hostseg = '[%s] %s'%(host,cc)
			out.append({'href':hrefSEG,'host':hostseg})

	return out
def getSegosVid(url):
	hrefSEG=''
	content,kuk = getUrlReq(url)
	iframes = re.compile('<iframe(.*?)</iframe>',re.DOTALL).findall(content)
	for iframe in iframes:
		href = re.compile('src="(.*?)"').findall(iframe)
		if href:
			hrefSEG=href[0]
			hrefSEG = 'http'+hrefSEG.split('http')[-1]
			if 'greevid.com' in hrefSEG: hrefSEG = getSubFrame(hrefSEG)
			if 'ebd.cda.pl' in hrefSEG: hrefSEG = 'http://www.cda.pl/video/'+hrefSEG.split('/')[-1]
	if not hrefSEG:
		hrefSEG = re.compile('<source src="(.*?)" type=[\'"]+video/mp4[\'"]+>').findall(content)
		hrefSEG = hrefSEG[0] if hrefSEG else ''
	return hrefSEG
def getSubFrame(url):
	content,kuk = getUrlReq(url)
	iframes = re.compile('<iframe(.*?)</iframe>',re.DOTALL).findall(content)
	if iframes:
		href = re.compile('src="(.*?)"').findall(iframes[0])
		if href:
			href = 'http'+href[0].split('http')[-1]
			return href
	return ''
def GatunekRok(url='http://segos.es/filmy'):
	cat=[]
	content,kuk = getUrlReq(url)
	idx=content.find('<h4>Kategorie</h4>')
	idx = parseDOM(content,'ul',attrs = {'class':'nav__list genres-list'})#[0]

	if idx:
		cat = re.compile('name="(.+?)" value="(.+?)"').findall(idx[-1])
		if cat:
			cat = [(x[1],x[1].strip()) for x in cat]
	return cat
def getNext(url,page=1):
	content,kuk = getUrlReq(url)
	ids = [(a.start(), a.end()) for a in re.finditer('<div class="col-lg-12" style="padding:0 0 5px 0;">', content)]
	ids.append( (-1,-1) )
	out=[]
	for i in range(len(ids[:-1])):
		tops = content[ ids[i][1]:ids[i+1][0] ]
		href = re.compile('href="(.*?view.*?)"').findall(tops)
		title = re.compile('">(\\w+.*?)</').findall(tops)
		imag = re.compile('<img src="(.*?)"').findall(tops)
		imag = imag[0] if imag else ''
		if imag.startswith('http'):
			imag=imag
		elif imag.startswith('../'):
			imag=imag.replace('..',BASEURL)
		elif imag.startswith('obrazki'):
			imag=BASEURL+'/'+imag
		elif imag.startswith('/obrazki'):
			imag=BASEURL+imag
		if href and title and imag:
			one = {'url'   : BASEURL+href[0],
				'title'  : PLchar(title[0]),
				'plot'   : '',
				'img'	: imag+'|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuk),
				'rating' : '',
				'year'   : '',
				'code'  : ''
					}
			out.append(one)
	return out
def getSeasons(url):
	content,kuk = getUrlReq(url)
	out=[]
	imag = parseDOM(content,'img',attrs = {'class':'page__image'},ret='src')
	imag = imag[0] if imag else ''
	sezons = parseDOM(content,'div',attrs = {'class':'seasons__season'})
	plot = re.findall('"page__description">(.+?)<',content)
	tit2= re.findall('"page__title">(.+?)<',content)
	tit2 = tit2[0]+' - ' if tit2 else ''

	for sezon in sezons:
		seas=re.findall('data-season="(\d+)">',sezon)
		hrefTitle = re.findall('a href="(.+?)" class=".+?">(.+?)<',sezon)

		for href,titul in hrefTitle:
			href=BASEURL+href if not href.startswith('htt') else href
			title = tit2+'Sezon '+seas[0]+' - '+titul
			one = {'url'   : href,
				   'title'  : PLchar(title),
				'plot'   : PLchar(plot[0].strip(': ')) if plot else '',
				'img'	: imag+'|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuk),
				'rating' : '',
				'year'   : '',
				'code'  : '',
				'mediatype': 'movie'
				}
			out.append(one)		
	return out
def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('#038;','')
	char = char.replace('&lt;br/&gt;',' ')
	char = char.replace('&#34;','"')
	char = char.replace('&#39;',"'").replace('&#039;',"'")
	char = char.replace('&#8221;','"')
	char = char.replace('&#8222;','"')
	char = char.replace('&#8211;','-').replace('&ndash;','-')
	char = char.replace('&quot;','"').replace('&amp;quot;','"')
	char = char.replace('&oacute;','ó').replace('&Oacute;','Ó')
	char = char.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
	char = char.replace('&amp;','&')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')

	return char
