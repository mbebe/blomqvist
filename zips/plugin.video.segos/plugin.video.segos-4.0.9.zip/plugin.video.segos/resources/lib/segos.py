# -*- coding: utf-8 -*-

import urllib2,urllib
import os,re
import urlparse
import cookielib
import requests

import cloudflare6
import xbmc,xbmcgui,xbmcaddon

my_addon	 = xbmcaddon.Addon()
DATAPATH	 = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
COOKIEFILE = os.path.join(DATAPATH,'segos.cookie')


UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0'
s=requests.Session()

s.headers ={'User-Agent': UA,
				'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
				'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
				'DNT': '1',
				'Connection': 'keep-alive',
				'Upgrade-Insecure-Requests': '1',}	





scraper = cloudflare6.create_scraper(sess=s)
scraper.cookies = cookielib.LWPCookieJar(COOKIEFILE)
BASEURL='http://segos.es/'

TIMEOUT = 10

def getUrlReq(url,kuk=''):
	if os.path.isfile(COOKIEFILE):
		scraper.cookies.load()
	aa=scraper.cookies
	my_cookies = requests.utils.dict_from_cookiejar(aa)
	found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]

	kukz= ';'.join(found)	
	headersok={
		'User-Agent': UA,}

	content=scraper.get(url,verify=False).text	
	return content,kukz
	
def getUrlReqPost(data):
	if os.path.isfile(COOKIEFILE):
		scraper.cookies.load()
	aa=scraper.cookies
	my_cookies = requests.utils.dict_from_cookiejar(aa)
	found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]
	
	kukz= ';'.join(found)	

	content=scraper.post('https://segos.es/?page=needtosee',data=data,verify=False).text	
	return content,kukz

def getLogin(u='',p=''):
	dataPath=os.path.dirname(COOKIEFILE)
	if not os.path.exists(dataPath):
		os.makedirs(dataPath)
	try:
		if os.path.isfile(COOKIEFILE):
			scraper.cookies.load()	
		url ='http://segos.es/'
		
		aa=scraper.get(url).text
		params = (('page', 'login'),)
		data = 'login=%s&password=%s&loguj='%(u,p)
		response = scraper.post('https://segos.es/',params=params,cookies=scraper.cookies,data=data,allow_redirects=False)
		kkk=scraper.cookies
		scraper.cookies.save()
		content=scraper.get(BASEURL).text
	except:
		content=''
	out = True if content.find('Wyloguj')>0 else False
	return out

def ListTop(top='Top 10 odwiedzanych'):
	content,kuk = getUrlReq(BASEURL)
	ids = [(a.start(), a.end()) for a in re.finditer('<h3 style="font-family: .*">', content)]
	ids.append( (-1,-1) )
	out=[]
	for i in range(len(ids[:-1])):
		tops = content[ ids[i][1]:ids[i+1][0] ]
		if top in tops:
			items = re.compile('<a data-toggle="tooltip"(.*?</a>)',re.DOTALL).findall(tops)
			for item in items:
				href = re.compile('href="(.*?)"').findall(item)
				imag = re.compile('<img class="img-responsive" src="(.*?)"').findall(item)
				plot = re.compile("title='(.*?)'").findall(item)
				title = re.compile('>(.*?)<').findall(item)
				lang =  re.compile('src="/images/langs/(.*?).png"').findall(item)
				quality = ' HD' if tops.find('src="/images/hd.')>-1 else ''
				trail = ''
				imag = imag[0] if imag else ''
				if imag.startswith('/images'): #/images/posters/7043932.6.jpg
					imag='http://segos.es'+imag+'|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuk)
				elif imag.startswith('../'):
					imag=imag.replace('..',BASEURL)
				elif imag.startswith('obrazki'):
					imag=BASEURL+'/'+imag
				code = lang[0] if lang else ''
				code += quality if quality else ''
				title = ''.join(title).strip()
				if href and title:
					year = re.search('\\((\\d{4})\\)',title)
					year = re.search('\\((\\d{4})\\)',plot[0]) if not year and plot else year
					one = {'url'   : urlparse.urljoin(BASEURL,href[0]),
						'title'  : PLchar(title),
						'plot'   : PLchar(plot[0].strip(': ')) if plot else '',
						'img'	: imag,
						'rating' : '',
						'genre' : '',
						'year'   : year.group(1) if year else '',
						'code'  : code.strip(),
						'trailer' : '',
						'mediatype': 'movie'
							}
					print one['trailer']
					out.append(one)
	return out
def scanPageSer(url,page=1):
	if 'nr=' in url:
		url = re.sub('nr=\\d+','nr=%d'%int(page),url)
	else:
		url = url + '&nr=%d' %page				
	my_mode = True 
	IsPlayable = False 
	content,kuk = getUrlReq(url)
	nextPage=False
	segUrl=url.replace(BASEURL,'').replace('nr=%d'%page,'nr=%d' %(page+1))
	if content.find(segUrl.split('/')[-1])>-1:
		nextPage = page+1
	ids = [(a.start(), a.end()) for a in re.finditer('<div class="col-lg-\\d+ col-md-\\d+', content)]
	ids.append( (-1,-1) )
	out=[]
	for i in range(len(ids[:-1])):
		tops = content[ ids[i][1]:ids[i+1][0] ]
		hrefTitle = re.compile('<a href="(.*?view.*?)"\\s*>(.*?)</a>').findall(tops)
		imag = re.compile('<img class="img-responsive" src="(.*?)"').findall(tops)
		categ = re.compile('category=[^"]+">(.*?)</a>').findall(tops)
		plot= re.compile('<b>Opis</b>(.*?)<',re.DOTALL).findall(tops)
		lang =  re.compile('src="/images/langs/(.*?).png">').findall(tops)
		quality = ' HD' if tops.find('src="/images/hd.')>-1 else ''
		trail = re.compile('class="embed-responsive-item" src="(.*?)"').findall(tops)
		imag = imag[0] if imag else ''
		if imag.startswith('/'):
			imag=BASEURL[:-1]+imag+'|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuk)
		elif imag.startswith('../'):
			imag=imag.replace('..',BASEURL)
		elif imag.startswith('obrazki'):
			imag=BASEURL+'/'+imag
		code = lang[0] if lang else ''
		code += quality if quality else ''
		if hrefTitle and imag:
			title = hrefTitle[0][1]
			year = re.search('\\((\\d{4})\\)',title)			
			one = {'url'   : BASEURL+hrefTitle[0][0],
				'title'  : PLchar(title),
				'plot'   : PLchar(plot[0].strip(': ')) if plot else '',
				'img'	: imag,
				'isFolder': my_mode,
				'IsPlayable':IsPlayable,
				'rating' : '',
				'genre' : ','.join(categ) if categ else '',
				'year'   : year.group(1) if year else '',
				'code'  : code.strip(),
				'trailer' : trail[0] if trail else '',
				'mediatype': 'movie'
					}
			out.append(one)
	prevPage = page-1 if page>1 else False
	return (out, (prevPage,nextPage))
def scanPage(url,page=1):
	if 'nr=' in url:
		url = re.sub('nr=\\d+','nr=%d'%int(page),url)
	else:
		url = url + '&nr=%d' %page
	content,kuk = getUrlReq(url)
	nextPage=False
	segUrl=url.replace(BASEURL,'').replace('nr=%d'%page,'nr=%d' %(page+1))
	if content.find(segUrl.split('=')[-1])>-1:
		nextPage = page+1
	if '?page=needtosee' in url:
		nextPage=False
	ids = [(a.start(), a.end()) for a in re.finditer('<div class="col-lg-\\d+ col-md-\\d+', content)]
	ids.append( (-1,-1) )
	out=[]
	for i in range(len(ids[:-1])):
		tops = content[ ids[i][1]:ids[i+1][0] ]
		delid = re.compile('value="(.+?)"').findall(tops)
		hrefTitle = re.compile('<a href="(.*?view.*?)"\\s*>(.*?)</a>').findall(tops)
		imag = re.compile('<img class="img-responsive" src="(.*?)"').findall(tops)
		categ = re.compile('category=[^"]+">(.*?)</a>').findall(tops)
		plot= re.compile('<b>Opis</b>(.*?)<',re.DOTALL).findall(tops)
		lang =  re.compile('src="/images/langs/(.*?).png">').findall(tops)
		quality = ' HD' if tops.find('src="/images/hd.')>-1 else ''
		trail = re.compile('class="embed-responsive-item" src="(.*?)"').findall(tops)
		imag = imag[0] if imag else ''
		if imag.startswith('/'):
			imag=BASEURL[:-1]+imag+'|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuk)
		elif imag.startswith('../'):
			imag=imag.replace('..',BASEURL)
		elif imag.startswith('obrazki'):
			imag=BASEURL+'/'+imag
		code = lang[0] if lang else ''
		code += quality if quality else ''
		if hrefTitle and imag:
			title = hrefTitle[0][1]
			year = re.search('\\((\\d{4})\\)',title)
			if delid:
				nxturl=BASEURL+hrefTitle[0][0]+'|%s'%delid[0]
			else:
				nxturl=BASEURL+hrefTitle[0][0]						
			one = {'url'   : nxturl,				
				'title'  : PLchar(title),
				'plot'   : PLchar(plot[0].strip(': ')) if plot else '',
				'img'	: imag,
				'rating' : '',
				'genre' : ','.join(categ) if categ else '',
				'year'   : year.group(1) if year else '',
				'code'  : code.strip(),
				'trailer' : trail[0] if trail else '',
				'mediatype': 'movie'
					}
			out.append(one)
	prevPage = page-1 if page>1 else False
	
	return (out, (prevPage,nextPage))
def getRecomend(url='http://segos.es/recomend_list.php'):
	outF=[]
	outB=[]
	content,kuk = getUrlReq(url)
	items = re.compile('<tr>(.*?)</tr>',re.DOTALL).findall(content)
	for item in items:
		hrefTitle = re.compile('<p><a href="(.*?)">(.*?)</a></p>').findall(item)
		imag = re.compile('<img src="(.*?)"').findall(item)
		if hrefTitle:
			one = {'url'   : BASEURL+hrefTitle[0][0],
				'title'  : PLchar(hrefTitle[0][1]),
				'plot'   : '',
				'img'	: BASEURL+imag[0]+'|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuk) if imag else '',
				'rating' : '',
				'year'   : '',
				'code'  : '',
					}
			if   '/bajki/' in hrefTitle[0][0]:
				outB.append(one)
			elif '/filmy/' in hrefTitle[0][0]:
				outF.append(one)
	return (outF,outB)
def getMovieInfo(url,infoTab=True):
	info={}
	if infoTab:
		content,kuk = getUrlReq(url)
		zx = content.find('<div id="myTabContent" class="tab-content">')
		if zx:
			tops=content[zx:-1]
			year = re.search('<b>Rok produkcji</b>:(.*?)<',tops,flags=re.MULTILINE|re.I)
			categ = re.search('<b>Gatunek</b>:(.*?)<',tops,flags=re.DOTALL)
			quality = re.search('<b>Jako\xc5\x9b\xc4\x87</b>:(.*?)<',tops,flags=re.MULTILINE|re.I)
			audio = re.search('<b>Audio</b>:(.*?)<',tops,flags=re.MULTILINE|re.I)
			lang = re.search('<b>J\xc4\x99zyk</b>:(.*?)<',tops,flags=re.MULTILINE|re.I)
			plot = re.search('<b>Opis</b>:(.*?)<',tops,flags=re.MULTILINE|re.I)
			if year:	info['year']=year.group(1).strip().strip('(').strip(')')
			if categ:   info['genre']=categ.group(1).strip()
			if quality: info['quality']=quality.group(1).strip()
			if audio:   info['audio']=audio.group(1).strip()
			if lang:	info['lang']=lang.group(1).strip()
			if plot:	info['plot']=PLchar(plot.group(1).strip())
			info['code']= ','.join([info.get('quality',''),info.get('lang',''),info.get('audio','')])
	return info
def getVideoLinks(url):
	out=[]
	content,kuk = getUrlReq(url)
	iframes = re.compile('<iframe(.*?)</iframe>',re.DOTALL).findall(content)	
	for iframe in iframes:
		href = re.compile('src="(.*?)"').findall(iframe)
		if href:
			hrefSEG = href[0]
			hrefSEG = 'http'+hrefSEG.split('http')[-1]
			host = urlparse.urlparse(hrefSEG).netloc
			if 'greevid.com' in host:
				hrefSEG = getSubFrame(hrefSEG)
				host += ' - ' + urlparse.urlparse(hrefSEG).netloc
			if 'ebd.cda.pl' in host:
				hrefSEG=False
			if hrefSEG and host: out.append({'href':hrefSEG,'host':host})
	tbody = re.compile('<tbody>(.*?)</tbody>',re.DOTALL).findall(content)
	if tbody:
		items=re.compile('<tr(.*?)</tr>',re.DOTALL).findall(tbody[0])
		for item in items:
			td=re.compile('<td(.*?)</td>',re.DOTALL).findall(item)
			if len(td)>3:
				lang = re.search('/images/langs/(.*?).png">',td[0])
				lang = lang.group(1) if lang else ''
				quality = td[1].split('>')[-1]
				hostSEG = re.search('src="/images/servers/(.*?)"',td[2])
				hostSEG = hostSEG.group(1).split('.')[0] if hostSEG else '?'
				access = td[3].split('>')[-1].strip()
				hrefSEG = re.compile('href="(.*?)"><').findall(item)
				if hrefSEG:
					hrefSEG=urlparse.urljoin(BASEURL,hrefSEG[0])
					host = '[%s] %s, %s, %s'%(hostSEG,lang,quality, access)
					out.append({'href':hrefSEG,'host':host})
	return out
def getSegosVid(url):
	hrefSEG=''
	content,kuk = getUrlReq(url)
	iframes = re.compile('<iframe(.*?)</iframe>',re.DOTALL).findall(content)
	for iframe in iframes:
		href = re.compile('src="(.*?)"').findall(iframe)
		if href:
			hrefSEG=href[0]
			hrefSEG = 'http'+hrefSEG.split('http')[-1]
			if 'greevid.com' in hrefSEG: hrefSEG = getSubFrame(hrefSEG)
			if 'ebd.cda.pl' in hrefSEG: hrefSEG = 'http://www.cda.pl/video/'+hrefSEG.split('/')[-1]
	if not hrefSEG:
		hrefSEG = re.compile('<source src="(.*?)" type=[\'"]+video/mp4[\'"]+>').findall(content)
		hrefSEG = hrefSEG[0] if hrefSEG else ''
	return hrefSEG
def getSubFrame(url):
	content,kuk = getUrlReq(url)
	iframes = re.compile('<iframe(.*?)</iframe>',re.DOTALL).findall(content)
	if iframes:
		href = re.compile('src="(.*?)"').findall(iframes[0])
		if href:
			href = 'http'+href[0].split('http')[-1]
			return href
	return ''
def GatunekRok(url='http://segos.es/?page=filmy'):
	cat=[]
	content,kuk = getUrlReq(url)
	idx=content.find('<h4>Kategorie</h4>')
	if idx:
		cat = re.compile('<li><a href="(.*?)">(.*?)</a></li>').findall(content[idx:-1])
		if cat:
			cat = [('http://segos.es'+x[0],x[1].strip()) for x in cat]
	return cat
def getNext(url,page=1):
	content,kuk = getUrlReq(url)
	ids = [(a.start(), a.end()) for a in re.finditer('<div class="col-lg-12" style="padding:0 0 5px 0;">', content)]
	ids.append( (-1,-1) )
	out=[]
	for i in range(len(ids[:-1])):
		tops = content[ ids[i][1]:ids[i+1][0] ]
		href = re.compile('href="(.*?view.*?)"').findall(tops)
		title = re.compile('">(\\w+.*?)</').findall(tops)
		imag = re.compile('<img src="(.*?)"').findall(tops)
		imag = imag[0] if imag else ''
		if imag.startswith('http'):
			imag=imag
		elif imag.startswith('../'):
			imag=imag.replace('..',BASEURL)
		elif imag.startswith('obrazki'):
			imag=BASEURL+'/'+imag
		elif imag.startswith('/obrazki'):
			imag=BASEURL+imag
		if href and title and imag:
			one = {'url'   : BASEURL+href[0],
				'title'  : PLchar(title[0]),
				'plot'   : '',
				'img'	: imag+'|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuk),
				'rating' : '',
				'year'   : '',
				'code'  : ''
					}
			out.append(one)
	return out
def getSeasons(url):
	content,kuk = getUrlReq(url)
	episodes=re.findall('<div id="collapse\d+" class="panel-collapse(.*?)</div>',content,re.DOTALL)
	imag =  re.findall("""<div style="overflow: hidden; margin-top: 15px;">..\s+<img src=['"](.*?)['"]""",content,re.DOTALL)
	imag = 'http://segos.es'+imag[0] if imag else ''
	plot=re.findall('<b>Opis</b>:\s+(.*?)</p>',content,re.DOTALL)
	out=[]
	for epis in episodes:
		seas=re.findall('aria-labelledby="heading(\d+)"',epis)
		hrefTitle=re.findall('<a href="(.*?)">(.*?)</a>',epis)
		for href,titul in hrefTitle:
			title = 'Sezon '+seas[0]+' - '+titul
			one = {'url'   : BASEURL+href,
				   'title'  : PLchar(title),
				'plot'   : PLchar(plot[0].strip(': ')) if plot else '',
				'img'	: imag+'|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuk),
				'rating' : '',
				'year'   : '',
				'code'  : '',
				'mediatype': 'movie'
				}
			out.append(one)		
	return out
def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	# txt = txt.replace('#038;','')
	# txt = txt.replace('&lt;br/&gt;',' ')
	# txt = txt.replace('&#34;','"')
	# txt = txt.replace('&#39;',''').replace('&#039;',''')
	# txt = txt.replace('&#8221;','"')
	# txt = txt.replace('&#8222;','"')
	# txt = txt.replace('&#8211;','-').replace('&ndash;','-')
	# txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
	# txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
	# txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
	# txt = txt.replace('&amp;','&')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	return char
