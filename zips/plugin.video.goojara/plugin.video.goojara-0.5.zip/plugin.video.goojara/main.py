# -*- coding: UTF-8 -*-
from __future__ import division
import sys,re,os
import six
from six.moves import urllib_parse

import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc, xbmcvfs
from resources.lib.brotlipython import brotlidec

if six.PY3:
    basestring = str
    unicode = str
    xrange = range
    from resources.lib.cmf3 import parseDOM
else:
    from resources.lib.cmf2 import parseDOM
import resolveurl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(urllib_parse.parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.goojara')

PATH            = addon.getAddonInfo('path')
if six.PY2:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
else:
    DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'../fanart.jpg'
ikona =RESOURCES+'../icon.png'

exlink = params.get('url', None)
nazwa= params.get('title', None)
rys = params.get('image', None)

page = params.get('page',[1])#[0]

MAIN_URL ='https://www.goojara.to' 

UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36'
TIMEOUT=15

headers = {'User-Agent': UA,}
sess = requests.Session()

def build_url(query):
    return base_url + '?' + urllib_parse.urlencode(query)

def add_item(url, name, image, mode, itemcount=1, page=1,fanart=FANART, infoLabels=False,contextmenu=None,IsPlayable=False, folder=False):
    list_item = xbmcgui.ListItem(label=name)
    if IsPlayable:
        list_item.setProperty("IsPlayable", 'True')    
    if not infoLabels:
        infoLabels={'title': name}    
    list_item.setInfo(type="video", infoLabels=infoLabels)    
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': fanart})
    
    if contextmenu:
        out=contextmenu
        list_item.addContextMenuItems(out, replaceItems=True)
    else:
        out = []
        out.append(('Informacja', 'XBMC.Action(Info)'),)
        list_item.addContextMenuItems(out, replaceItems=False)

    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url = build_url({'mode': mode, 'url' : url, 'page' : page, 'title':name,'image':image}),            
        listitem=list_item,
        isFolder=folder)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
    
def home():

    add_item('https://subsmovies.club/', 'Movies', ikona, "menu:movies",fanart=FANART, folder=True)
    add_item('https://subsmovies.club/', 'Series', ikona, "menu:series",fanart=FANART, folder=True)
    
    add_item('', '[COLOR lightblue]Search[/COLOR]', 'DefaultAddonsSearch.png', "search", folder=True)    
def menuMovies():
    add_item('https://vww.themoviebay.net/movies', '[COLOR gold][B]<=>=<=> MOVIES <=>=<=>[/COLOR][/B] ',ikona, " ",fanart=FANART, folder=False)
    add_item('movies|https://www.goojara.to/watch-movies-recent', 'Recent',ikona, "listmovies",fanart=FANART, folder=True)
    add_item('movies|https://www.goojara.to/watch-movies-popular', 'Popular',ikona, "listmovies",fanart=FANART, folder=True)
    add_item('movies', 'Genre',ikona, "listcateg",fanart=FANART, folder=True)
    add_item('movies', 'Year',ikona, "listyears",fanart=FANART, folder=True)
    add_item('movies', 'A-Z',ikona, "listaz",fanart=FANART, folder=True)

    xbmcplugin.endOfDirectory(addon_handle)
    
    
def menuSeries():
    add_item('https://vww.themoviebay.net/movies', '[COLOR gold][B]<=>=<=> SERIES <=>=<=>[/COLOR][/B] ',ikona, " ",fanart=FANART, folder=False)
    add_item('series|https://www.goojara.to/watch-series-recent', 'Recent',ikona, "listmovies",fanart=FANART, folder=True)
    add_item('series|https://www.goojara.to/watch-series-popular', 'Popular',ikona, "listmovies",fanart=FANART, folder=True)
    add_item('series', 'Genre',ikona, "listcateg",fanart=FANART, folder=True)
    add_item('series', 'Year',ikona, "listyears",fanart=FANART, folder=True)
    add_item('series', 'A-Z',ikona, "listaz",fanart=FANART, folder=True)

    xbmcplugin.endOfDirectory(addon_handle)

    
def ListCateg(rod):
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Action","Action",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Adventure","Adventure",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Animation","Animation",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Biography","Biography",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Comedy","Comedy",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Crime","Crime",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Documentary","Documentary",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Drama","Drama",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Family","Family",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Fantasy","Fantasy",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Film-Noir","Film-Noir",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Game-Show","Game-Show",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-History","History",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Horror","Horror",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Music","Music",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Musical","Musical",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Mystery","Mystery",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-News","News",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Reality-TV","Reality-TV",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Romance","Romance",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Sci-Fi","Sci-Fi",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Sport","Sport",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Talk-Show","Talk-Show",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Thriller","Thriller",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-War","War",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Western","Western",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-genre-Adult","Adult",ikona, "listmovies",fanart=FANART, folder=True)
    xbmcplugin.endOfDirectory(addon_handle)
    
def ListYears(rod):
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2020","2020",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2019","2019",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2018","2018",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2017","2017",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2016","2016",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2015","2015",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2014","2014",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2013","2013",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2012","2012",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2011","2011",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2010","2010",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2009","2009",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2008","2008",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2007","2007",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2006","2006",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2005","2005",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2004","2004",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2003","2003",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2002","2002",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-year-2001","2001",ikona, "listmovies",fanart=FANART, folder=True)
    xbmcplugin.endOfDirectory(addon_handle)    
    
def ListAZ(rod):
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-0","0",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-1","1",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-2","2",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-3","3",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-4","4",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-5","5",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-6","6",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-7","7",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-8","8",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-9","9",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-A","A",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-B","B",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-C","C",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-D","D",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-E","E",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-F","F",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-G","G",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-H","H",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-I","I",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-J","J",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-K","K",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-L","L",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-M","M",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-N","N",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-O","O",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-P","P",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-Q","Q",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-R","R",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-S","S",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-T","T",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-U","U",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-V","V",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-W","W",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-X","X",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-Y","Y",ikona, "listmovies",fanart=FANART, folder=True)
    add_item(rod+"|https://www.goojara.to/watch-"+rod+"-az-Z","Z",ikona, "listmovies",fanart=FANART, folder=True)
    xbmcplugin.endOfDirectory(addon_handle)    
    

def ListSearch(query):

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0',
        'Accept': '*/*',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Accept-Encoding': 'gzip, deflate, br',
        'Content-type': 'application/x-www-form-urlencoded',
        'Origin': 'https://www.goojara.to',
        'Alt-Used': 'www.goojara.to',
        'Connection': 'keep-alive',
        'Referer': 'https://www.goojara.to/watch-movies-az-N',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'TE': 'trailers',
    }
    xx = sess.get('https://www.goojara.to', headers=headers, verify=False)

    dt = {
    'q': urllib_parse.quote(query)
    }

    response = sess.post('https://www.goojara.to/xhrr.php', headers=headers, data=dt, cookies=sess.cookies, verify=False)
    out = []
    response_content = brotlidec(response.content, out).decode('utf-8')

    if six.PY3:
        try:
            response_content= (response_content).decode(encoding='utf-8', errors='strict') 
        except:
            response_content = response_content
    hreftyptit=re.findall('href="([^"]+).+?class="([^"]+)">(.+?)<',response_content,re.DOTALL)#0[0]
    items = len(hreftyptit)
    if items>0:
    
        for href,typ,tit in hreftyptit:
            modemy='getLinks'
            isplay=False
            fold=True
            ad = ' -[I]movies[/I]'
            if 'it' in typ: 
    
                modemy='listseasons'
                isplay=False
                fold=True
                ad = ' -[I]series[/I]'
            href = MAIN_URL + href if href.startswith('/') else href
            tit = re.sub('<[^<]+?>', '', tit)
            add_item(name=tit+ad, url=href, mode=modemy, image=ikona, infoLabels={'plot':tit}, itemcount=items,folder=fold, IsPlayable=isplay)    
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmcgui.Dialog().notification('[COLOR red][B]Info[/B][/COLOR]', "[COLOR red][B]No results.[/B][/COLOR]", xbmcgui.NOTIFICATION_INFO, 5000)

def ListLinks(exlink):
    pagination=None
    links=getLinks(exlink)
    
    itemz=links
    items = len(links)
    if items>0:
        for f in itemz:
            modemy='playLink'
            isplay=True
            fold=False
            add_item(name=f.get('title'), url=f.get('href'), mode=modemy, image=f.get('img'), infoLabels={'code':f.get('code'),'plot':f.get('plot'),'genre':f.get('genre')}, itemcount=items,folder=fold, IsPlayable=isplay)    
        
        if pagination:
            add_item(name='[COLOR blue]>> next page >>[/COLOR]', url=exlink, mode='listsubsmov', image=RESOURCES+'right.png', page=pagination,fanart=FANART, folder=True)        

        xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmcgui.Dialog().notification('[COLOR red][B]Info[/B][/COLOR]', "[COLOR red][B]No links for this video.[/B][/COLOR]", xbmcgui.NOTIFICATION_INFO, 5000)

def getLinks(url):
    out=[]
    ref = url

    url = url.replace('ww1.','www.')
    headers = {
        'Host': 'www.goojara.to',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'sec-fetch-site': 'none',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document',
        'accept-language': 'en-US,en;q=0.9',
    }

    response = sess.get(url, headers=headers,verify=False)
    if six.PY3:
        response_content= (response.content).decode(encoding='utf-8', errors='strict') 
    else:
        response_content= response.content
    
    plot = parseDOM(response_content,'div', attrs={'class': "fimm"})
    #
    plot = plot[0] if plot else nazwa
    plot = parseDOM(plot,'p')
    plot = plot[0] if plot else plot

    hrefhost = re.findall('class="bcg" href="(.+?)"\s*>(.+?)<',response_content)

    for href,host in hrefhost:
        tyt = nazwa+' - [I]'+host.replace('<span>','')+'[/I]'
        out.append({'title':tyt,'href':href+'|'+url,'img':rys,'year':'','plot':plot,'genre':'','code':''})
    return out

def PlayLink(urlref):
    UAx = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
    url,ref = urlref.split('|')
    ref = ref.replace('www.supernova.to','www.goojara.to')
    headers = {

        'upgrade-insecure-requests': '1',
        'user-agent': UAx,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'sec-fetch-site': 'none',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document',

        'accept-language': 'en-US,en;q=0.9',
    }

    response = sess.get(ref, headers=headers,verify=False)

    if six.PY3:
        response_content= (response.content).decode(encoding='utf-8', errors='strict') 
    else:
        response_content= response.content
    plot = parseDOM(response_content,'div', attrs={'class': "fimm"})
    #
    plot = plot[0] if plot else nazwa
    plot = parseDOM(plot,'p')
    plot = plot[0] if plot else plot
    
    
    dtinsshd = re.findall('shd" data-ins="(.+?)"',response_content,re.DOTALL)[0]

    
    

    gg=sess.cookies.get_dict()
    ck,ck2 = re.findall("""_3chk\(['"](.+?)['"],['"](.+?)['"]""",response_content,re.DOTALL)[0]
    gg[ck]=ck2
    refe = ref.replace('www.supernova.to','www.goojara.to')

    headers = {
        'Host': 'www.goojara.to',
        'user-agent': UAx,
        'content-type': 'application/x-www-form-urlencoded',
        'accept': '*/*',
        'origin': 'https://www.goojara.to',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
        'referer': ref.replace('www.supernova.to','www.goojara.to'),
        'accept-language': 'en-US,en;q=0.9',
    }
    
    params = (
        ('p', '2'),
    )
    
    data = 'act=1'
    response = sess.post(ref.replace('www.supernova.to','www.goojara.to'), headers=headers, params=params, cookies=gg, data=data,verify=False)
    if six.PY3:
        response_content= (response.content).decode(encoding='utf-8', errors='strict') 
    else:
        response_content= response.content
    lastkuk = createCook(dtinsshd,response_content,gg)

    headers.update({'Referer': ref})
    response = sess.get(url.replace('supernova.to','goojara.to'), headers=headers,cookies = lastkuk, verify=False)

    aa = response.url
    if 'wootly' in response.url:
        sess.close()
        headers2 = {
            'Host': 'www.wootly.ch',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': UAx,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Language': 'en-US,en;q=0.9,pl;q=0.8',
        }

        response = sess.get(response.url, headers=headers2, verify=False)
        if six.PY3:
            response_content= (response.content).decode(encoding='utf-8', errors='strict') 
        else:
            response_content= response.content
        
        nturl = re.findall('iframe src="([^"]+)',response_content)[0]
        headers2.update({'Referer': response.url})
        response = sess.get(nturl, headers=headers2, verify=False)
        vv=response.content
        headers = {
            'Host': 'www.wootly.ch',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': UAx,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-User': '?1',
            'Sec-Fetch-Dest': 'document',
            'Referer': nturl,
            'Accept-Language': 'en-US,en;q=0.9,pl;q=0.8',
        }
        
        response = sess.get('https://www.wootly.ch/prime', headers=headers, verify=False)
        if six.PY3:
            response_content= (response.content).decode(encoding='utf-8', errors='strict') 
        else:
            response_content= response.content
        cn = re.findall('cn="([^"]+)',response_content,re.DOTALL)[0]
        cv = re.findall('cv="([^"]+)',response_content,re.DOTALL)[0] 
    
        gg=sess.cookies.get_dict()

        gg[cn]=cv

        data = {'qdf': '1'}
        response = sess.post(nturl, headers=headers, cookies=gg, data=data, verify=False)
        vv=response.content
        
        if six.PY3:
            response_content= (response.content).decode(encoding='utf-8', errors='strict') 
        else:
            response_content= response.content
        tk = re.findall('tk="([^"]+)',response_content,re.DOTALL)[0]
        vd = re.findall('vd="([^"]+)',response_content,re.DOTALL)[0] 
        cn = re.findall('cn="([^"]+)',response_content,re.DOTALL)[0]
        cv = re.findall('cv="([^"]+)',response_content,re.DOTALL)[0] 


        url2 = 'https://wootly.ch/grabd' + "?t=" + tk + "&id=" + vd 
        response = sess.get(url2, headers=headers,cookies=sess.cookies,verify=False)
        if six.PY3:
            response_content= (response.content).decode(encoding='utf-8', errors='strict') 
        else:
            response_content= response.content
        link = response_content
		

		
		
        link ='https:' + link if link.startswith('//') else link
        link+='|User-Agent='+UAx+'&Referer='+link

    else:
        try:
            link = resolveurl.resolve(response.url)
        except Exception as e:
            link =''
            xbmcgui.Dialog().notification('[COLOR red][B]Error[/B][/COLOR]', "[COLOR red][B]This video is not working.[/B][/COLOR]", xbmcgui.NOTIFICATION_INFO, 5000)
    if link:

        play_item = xbmcgui.ListItem(path=link)

        play_item.setInfo(type="Video", infoLabels={"title": nazwa,'plot':plot})
        
        
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)    

def createCook(a,e, cook):
    b = a[len(a)-4:]
    c = a[7:10]+b
    d = a [len(a)-2:]
    e = e.split(' ')
    f = e[int(d[0])].lower()
    g = e[int(d[1])]
    h = '_' + f[int(b[0])]
    i = g[int(c[0])]
    j = 1
    l = len(b)
    for j in xrange(1,l):
        h += f[int(b[j])]
    n=len(c)
    for m in xrange(1,n):
        i += g[int(c[m])]    
    nt = amu(i)
    
    cook[h]=nt.upper()
    return cook
    
def amu(zz):
    import ctypes
    import math
    zz+=chr(128)
    a=zz
    
    g = [1518500249, 1859775393, 2400959708, 3395469782]
    b = [1732584193, 4023233417, 2562383102, 271733878, 3285377520];
    
    l= math.ceil((float(len(a))/4+2)/16)
    m={}
    
    for h in range(int(l)):
        m[h] = ['','','','','','','','','','','','','','','','']  
        d=0
        for d in range(16):
    
            try:
                a1=ord(a[64 * h + 4 * d])<< 24
            except:
                a1=0
            try:
                a2=ord(a[64 * h + 4 * d + 1])<< 16
            except:
                a2=0
    
            try:
                a4=ord(a[64 * h + 4 * d + 3])
            except:
                a4=0
            try:
                a3=ord(a[64 * h + 4 * d + 2]) << 8
            except:
                a3=0
    
            m[h][d]=a1|a2|a3|a4
        #  @  print m[h][d]
    
    m[l -1][14] = 8 * (len(a) - 1) / math.pow(2, 32)
    m[l - 1][14] = math.floor(m[l - 1][14]);
    m[l - 1][15] = 8 * (len(a) - 1) & 4294967295;
    d=[]
    def qq2(a, e, f, g):
    
        if a==0:
            return    ctypes.c_int(e & f ^ ~e & g).value
        elif a ==1:
    
            return ctypes.c_int(e ^ f ^ g).value
        elif a==2:
            return ctypes.c_int(e & f ^ e & g ^ f & g).value
        elif a==3:
            return ctypes.c_int(e ^ f ^ g).value       
    
    def unsigned32(signed):
        return signed % 0x100000000
    
    def zero_fill_right_shift(val, n):
        return (val >> n) if val >= 0 else ((val + 0x100000000) >> n)
    def qq(ab,eb):
    
        af= unsigned32(ab) >> 32 - eb
    
        return ctypes.c_int(ab << eb | zero_fill_right_shift(ab,32 - eb)).value 
        
    for ff in range(80):
        d.append('')
    for h in range(int(l)):#
    
        for c in range(16):
            d[c] = int(m[h][c]);
    
        for c in xrange(16,80):
            b1= int(d[c - 3] )
            b2= int(d[c - 8])
            b3=int(d[c - 14] )
            b4= int(d[c - 16])
    
            d[c] = qq(b1^b2^b3^b4,1)

        n=b[0]
        p = b[1]
        q = b[2]
        r = b[3]
        u = b[4]  
        for c in range(80):

            t = int(math.floor(c/20))

            t = ctypes.c_int(zero_fill_right_shift(    (qq(n, 5) + qq2(t, p, q, r)+ u + g[t] + d[c]),0)).value
    
            u = r
            
            r = q
            q = ctypes.c_int(zero_fill_right_shift(qq(p, 30),0)).value# >>> 0,
            p = n
            
            n = t;      
        b[0]=unsigned32(b[0] + n) >> 0
        b[1]=unsigned32(b[1] + p) >> 0
        b[2]=unsigned32(b[2] + q) >> 0
        b[3]=unsigned32(b[3] + r) >> 0
        b[4]=unsigned32(b[4] + u) >> 0

    for g in range(len(b)  ):
        z= (hex(b[g]).lstrip('0x').rstrip( "L" ))
        b[g] = ("00000000" + z)[-8:]

    return (','.join(b)).replace(',','')

def ListSubsMov(exlink,page):
    page = int(page) if page else 1    
    filmy,pagination=getSubsMov(exlink,page)
    
    itemz=filmy
    items = len(filmy)

    for f in itemz:
        modemy='getLinks'
        isplay=False
        fold=True
        if 'series' in f.get('rodz'): 

            modemy='listseasons'
            isplay=False
            fold=True

            tyt = re.sub('(\(\d+\.\d+\))\s*','',f.get('title')) #(\(1.1) [
        else:
            tyt = f.get('title')
        add_item(name=tyt, url=f.get('href'), mode=modemy, image=f.get('img'), infoLabels={'code':f.get('code'),'plot':f.get('plot'),'genre':f.get('genre')}, itemcount=items,folder=fold, IsPlayable=isplay)    
    
    if pagination:
        add_item(name='[COLOR blue]>> next page >>[/COLOR]', url=exlink, mode='listsubsmov', image=RESOURCES+'right.png', page=pagination,fanart=FANART, folder=True)        

    xbmcplugin.endOfDirectory(addon_handle)
    
def getSubsMov(urlk,page):

    typ,url=urlk.split('|')
    out=[]
    nxtpage='class="0">Next &raquo;<'
    
    if not '-popular' in url:
        url=url+'?p=%d' %page

    html=getUrlReqOk(url)
    kuks =''.join(['%s=%s;'%(c.name, c.value) for c in sess.cookies])
    add_head = '|User-Agent='+UA+'&Cookie='+kuks

    result = parseDOM(html,'div', attrs={'class': "dflex"})[1]
    
    links = parseDOM(result,'div')

    for link in links:
        href = parseDOM(link,'a', ret="href")[0]

        tyt = parseDOM(link,'a', ret="title")[0]
        imag = parseDOM(link,'img', ret="data-src")[0]
        
        href = MAIN_URL + href if href.startswith('/') else href
        imag = 'https:' + imag if imag.startswith('//') else imag
        imag = MAIN_URL + imag if imag.startswith('/') else imag

        qual = parseDOM(link,'span', attrs={'class': "hd hda"})
        qual = qual[0] if qual else ''
        genre = parseDOM(link,'span', attrs={'class': "genre"})
        genre = genre[0] if genre else ''
        year = parseDOM(link,'span', attrs={'class': "hd hdy"})

        year = year[0] if year else ''

        ftitle=tyt.strip()+' [COLOR orange][B]('+qual+')[/COLOR][/B]' if qual else tyt.strip()
        plot=PLchar(ftitle)
        out.append({'title':PLchar(ftitle),'href':href,'img':imag+add_head,'year':year,'plot':plot,'genre':genre,'code':qual,'rodz':typ})
        
        
    prevpage=False 
    nextpage=False  
    ktora=False

    if html.find(nxtpage)>1:
        nextpage=page+1

    return out,nextpage

def ListSeasons(exlink,org_tit):

    seasons =  getSeasons(exlink)
    itemz=seasons
    items = len(seasons)
    for f in seasons:
        mud='listepisodes' if f.get('typ')=='ok' else 'getLinks'
        add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), infoLabels={'code':f.get('code'),'plot':f.get('plot'),'genre':f.get('genre')}, itemcount=items,folder=True, IsPlayable=False)    
    xbmcplugin.endOfDirectory(addon_handle)

def getSeasons(url):
    
    url = url.replace('www1.','www.')
    sess.close()
    headers = {
    
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'sec-fetch-site': 'none',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document',
        'accept-language': 'en-US,en;q=0.9',
    }
    
    response = sess.get(url, headers=headers,verify=False)
    
    kuks =''.join(['%s=%s;'%(c.name, c.value) for c in response.cookies])
    add_head = '|User-Agent='+UA+'&Cookie='+kuks
    
    
    if six.PY3:
        response_content= (response.content).decode(encoding='utf-8', errors='strict') 
    else:
        response_content= response.content
    
    out=[]
    rys1= re.findall('img src="(.+?)"',response_content,re.DOTALL)#[0]
    ikon = rys
    if '/icon.png' in ikon:
        ikon = rys1[0]
        ikon = 'https:' + ikon if ikon.startswith('//') else ikon
        ikon = ikon.replace('supernova.to','goojara.to')+add_head

    try:    
        result = parseDOM(response_content,'div', attrs={'id': "sesh"})[0]
    #    ff=re.findall('<a href="(\/.+\?s\=\d+)"',result,re.DOTALL)#[0]
        ff=re.findall('<a href="(.*?=\d+)"',result,re.DOTALL)#[0]
        if ff:
            href = 'https://www.goojara.to'+ff[0] if ff[0].startswith('/') else ff[0]
            response = sess.get(href, headers=headers,verify=False)
            if six.PY3:
                response_content= (response.content).decode(encoding='utf-8', errors='strict') 
            else:
                response_content= response.content
    except:
        pass
    t = re.findall('"seon" data-id="(.+?)"',response_content,re.DOTALL)[0]
    sezony = re.findall('button data-season="(.+?)"',response_content,re.DOTALL)
    for seas in sezony:
    
        jaki = ' - [COLOR lightgreen]S%02d[/COLOR]'%(int(seas))
        tyt = nazwa + jaki
        href='t=%s&s=%s'%(str(t),str(seas))+'|'+url+'|'+tyt+'|'+ikon#+add_head
    
        out.append({'title':tyt,'href':href,'img':ikon,'plot':'','genre':'', 'season' : int(seas),'typ':'ok'})
    
    return out    

def ListEpisodes(exlink,pg):
    episodes,pagination = getEpisodes(exlink,pg)
    itemz=episodes
    items = len(episodes)
    for f in itemz:
        add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=True, infoLabels={'title':f.get('title'),'plot':f.get('plot')}, itemcount=items, IsPlayable=False)        

    if pagination:
        add_item(name='[COLOR blue]>> next page >>[/COLOR]', url=exlink, mode='listepisodes', image=RESOURCES+'right.png', page=pagination,fanart=FANART, folder=True)        

    xbmcplugin.endOfDirectory(addon_handle)
    
def getEpisodes(url,pg):
    url = url.replace('|User','!User')
    pg = int(pg)-1
    dt,urlh,naz,pho = url.split('|')
    pho = pho.replace('!User', '|User').replace('.supernova.','.goojara.').replace('https','http')

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0',
        'Accept': '*/*',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Accept-Encoding': 'gzip, deflate, br',
        'Content-type': 'application/x-www-form-urlencoded',
        'Origin': 'https://www.goojara.to',
        'Alt-Used': 'www.goojara.to',
        'Connection': 'keep-alive',
        'Referer': urlh,
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'TE': 'trailers',
    }
    xx = sess.get('https://www.goojara.to', headers=headers, verify=False)

    response = sess.post('https://www.goojara.to/xhrr.php', headers=headers, data=dt, cookies=sess.cookies, verify=False)
    out = []
    response_content = brotlidec(response.content, out).decode('utf-8')

    if six.PY3:
        try:
            response_content= (response_content).decode(encoding='utf-8', errors='strict') 
        except:
            response_content = response_content
    episodes = parseDOM(response_content,'div', attrs={'class': "seho"})#[0]
    epnumber = len(episodes)
    endparse = pg+30
    episodes = episodes [pg:(endparse-1)]
    
    out=[]
    npage=False

    for epis in episodes:
        ep,seas = re.findall('"sea">(.+?)</span><span>(.+?)<',epis,re.DOTALL)[0]
        ep = ep.strip(' ')
        ses = re.findall('(\d+)',seas,re.DOTALL)[0]
        href,tit = re.findall('a href="(.+?)">(.+?)<',epis,re.DOTALL)[0]
        href = 'https://www.goojara.to'+href if href.startswith('/') else href
        tyt = naz + str(' E%03d - %s'%(int(ep), tit))
        plot = parseDOM(epis,'p')
        plot = plot[0].strip('') if plot else ''
        out.append({'title':tyt,'href':href,'img':pho,'plot':plot,'genre':'', 'season' : int(ses),'episode' : int(ep) if epis else '',})
    
    if endparse<epnumber:
    
        npage=endparse#+1
    
    return out,npage    

def getUrlReqOk(url,ref=''):    

    headersok = {
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Connection': 'keep-alive',

    'Referer': ref,}

    content=sess.get(url, headers=headersok,verify=False).content
    if six.PY3:
        content= (content).decode(encoding='utf-8', errors='strict') 
    else:
        content = content
    return content

def PLchar(char):
    if type(char) is not str:
        char=char.encode('utf-8')
    char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
    char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
    char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
    char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
    char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
    char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
    char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
    char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
    char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
    char = char.replace('&#8217;',"'")
    char = char.replace('&#8211;',"-")    
    char = char.replace('&#8230;',"...")    
    char = char.replace('&#8222;','"').replace('&#8221;','"')    
    char = char.replace('[&hellip;]',"...")
    char = char.replace('&#038;',"&")    
    char = char.replace('&#039;',"'")
    char = char.replace('&quot;','"').replace('&oacute;','ó').replace('&rsquo;',"'")
    char = char.replace('&nbsp;',".").replace('&amp;','&').replace('&eacute;','e')
    return char    
def PLcharx(char):
    char=char.replace("\xb9","ą").replace("\xa5","Ą").replace("\xe6","ć").replace("\xc6","Ć")
    char=char.replace("\xea","ę").replace("\xca","Ę").replace("\xb3","ł").replace("\xa3","Ł")
    char=char.replace("\xf3","ó").replace("\xd3","Ó").replace("\x9c","ś").replace("\x8c","Ś")
    char=char.replace("\x9f","ź").replace("\xaf","Ż").replace("\xbf","ż").replace("\xac","Ź")
    char=char.replace("\xf1","ń").replace("\xd1","Ń").replace("\x8f","Ź");
    return char    
 
def Playlin(link) :
    play_item = xbmcgui.ListItem(path=link)

    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)    

 
def router(paramstring):
    params = dict(urllib_parse.parse_qsl(paramstring))
    if params:    

        mode = params.get('mode', None)

        if 'menu' in mode:
            mode2 = mode.split(':')[-1]
            
            if mode2 == 'series':
                menuSeries()
            elif mode2 == 'movies':
                menuMovies()

        elif mode =="listmovies":
            ListSubsMov(exlink,page)
            
        elif mode == 'playLink':
            PlayLink(exlink)

        elif mode == 'getLinks':
            ListLinks(exlink)

        elif mode == 'playVid':
            PlayVid(exlink)    
            
        elif mode == 'listsubsmov':
            ListSubsMov(exlink,page)    
            
        elif mode == 'listseasons':
            ListSeasons(exlink,nazwa)

        elif mode == 'listcateg':
            ListCateg(exlink)
            
        elif mode == 'listyears':
            ListYears(exlink)
            
        elif mode == 'listaz':
            ListAZ(exlink)

        elif mode == 'listepisodes':
            ListEpisodes(exlink,page)    
            
        elif mode=='search':
            query = xbmcgui.Dialog().input(u'Search...', type=xbmcgui.INPUT_ALPHANUM)
            if query:      
                query=query.replace(' ','+')
                ListSearch(query)

            else:
                pass
    else:
        home()
        xbmcplugin.endOfDirectory(addon_handle)    
if __name__ == '__main__':
    router(sys.argv[2][1:])