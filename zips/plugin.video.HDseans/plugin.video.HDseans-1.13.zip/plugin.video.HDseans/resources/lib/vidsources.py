# -*- coding: utf-8 -*-

import re,random,json, sys


try:
    import http.cookiejar as cookielib
    from urllib.request import Request as urllib_Request
    from urllib.request import HTTPSHandler, urlopen, install_opener, build_opener, HTTPCookieProcessor, HTTPHandler, ProxyHandler, ProxyHandler, HTTPBasicAuthHandler
    from urllib.error import HTTPError, URLError
    from urllib.parse import urlsplit, quote
except ImportError:
    from urlparse import urlsplit
    from urllib import quote
    import cookielib
    from urllib2 import Request as urllib_Request
    from urllib2 import urlopen, install_opener, build_opener, HTTPError, HTTPSHandler, URLError, HTTPCookieProcessor, HTTPHandler, ProxyHandler, HTTPBasicAuthHandler 
    
    

TIMEOUT=10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'
def getUrl(url,data=None,header={},cookies=True):
    cok=''
    cj=[]
    if cookies:
        cj = cookielib.LWPCookieJar()
        opener = build_opener(HTTPCookieProcessor(cj))
        install_opener(opener)
    if not header:
        header = {'User-Agent':UA}
    req = urllib_Request(url,data,headers=header)
    try:
        response = urlopen(req,timeout=TIMEOUT)
        hrefSEG =  response.read()
        response.close()
        cok = ''.join(['%s=%s;'%(c.name, c.value) for c in cj])
    except HTTPError as e:
        hrefSEG = ''
    return hrefSEG,cok
def getVideo(url):
    url = url.replace('http:','https:').replace('/e/','/?v=')
    content,c = getUrl(url)    
    www = re.compile('>\nQuality:\n</div>(.*?)<a id="button-light"', re.DOTALL).findall(content)    
    hh = re.compile('a href="(.*?)"', re.DOTALL).findall(www[0])    
    out=[]
    for h1 in hh:
        content2,c = getUrl(h1)    
        src= re.compile('<source src="(.*?)"', re.DOTALL).findall(content2)    
        h1=h1.split('&q=')            
        out.append((src[0],h1[1]))
    return out
    
def getVideo2(url):

    import binascii
    pth = urlsplit(url).path
    pth = (pth[1:]).split('.')[0]
    if sys.version_info >= (3,0,0):
        pth = pth.encode('utf-8')
    w = binascii.hexlify(pth)
    if sys.version_info >= (3,0,0):
        w = w.decode('utf-8')
    v = ''.join( [ hex(ord(w[i]))[2:] for i in range(len(w))])
    url = 'https://embedsb.com/sources/'+v+'/346536313435343634323666366135363331373634623335'
    
    content,c = getUrl(url)   
    if sys.version_info >= (3,0,0):
        content = content.decode('utf-8')
    stream = re.findall('"file":"([^"]+)',content)
    stream = stream[0]+'|User-Agent='+quote(UA) if stream else ''
    
    return stream
