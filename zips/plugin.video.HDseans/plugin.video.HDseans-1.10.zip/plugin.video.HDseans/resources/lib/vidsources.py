# -*- coding: utf-8 -*-

import re,random,json


try:
	import http.cookiejar as cookielib
	from urllib.request import Request as urllib_Request
	from urllib.request import HTTPSHandler, urlopen, install_opener, build_opener, HTTPCookieProcessor, HTTPHandler, ProxyHandler, ProxyHandler, HTTPBasicAuthHandler
	from urllib.error import HTTPError, URLError
except ImportError:
	import cookielib
	from urllib2 import Request as urllib_Request
	from urllib2 import urlopen, install_opener, build_opener, HTTPError, HTTPSHandler, URLError, HTTPCookieProcessor, HTTPHandler, ProxyHandler, HTTPBasicAuthHandler 
	
	

TIMEOUT=10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'
def getUrl(url,data=None,header={},cookies=True):
    cok=''
    cj=[]
    if cookies:
        cj = cookielib.LWPCookieJar()
        opener = build_opener(HTTPCookieProcessor(cj))
        install_opener(opener)
    if not header:
        header = {'User-Agent':UA}
    req = urllib_Request(url,data,headers=header)
    try:
        response = urlopen(req,timeout=TIMEOUT)
        hrefSEG =  response.read()
        response.close()
        cok = ''.join(['%s=%s;'%(c.name, c.value) for c in cj])
    except HTTPError as e:
        hrefSEG = ''
    return hrefSEG,cok
def getVideo(url):
    url = url.replace('http:','https:').replace('/e/','/?v=')
    content,c = getUrl(url)	
    www = re.compile('>\nQuality:\n</div>(.*?)<a id="button-light"', re.DOTALL).findall(content)	
    hh = re.compile('a href="(.*?)"', re.DOTALL).findall(www[0])	
    out=[]
    for h1 in hh:
        content2,c = getUrl(h1)	
        src= re.compile('<source src="(.*?)"', re.DOTALL).findall(content2)	
        h1=h1.split('&q=')			
        out.append((src[0],h1[1]))
    return out
