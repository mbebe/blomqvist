# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import urlparse
import urllib
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc

import base64
import cookielib
from CommonFunctions import parseDOM

packer = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)')
clappr = re.compile('new\s+Clappr\.Player\(\{\s*?source:\s*?["\'](.+?)["\']')
source = re.compile('sources\s*:\s*\[\s*\{\s*(?:type\s*:\s*[\'\"].+?[\'\"],|)src\s*:\s*[\'\"](.+?)[\'\"]')

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.darmowatv')

fprint = addon.getSetting('fprint')
PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
IMAGES       = PATH+'/resources/img/'
FANART=''

import resources.lib.jsunpack as jsunpack

ex_link = params.get('url', None)


UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36'
UAiphone='Mozilla/5.0 (iPhone; CPU iPhone OS 10_3 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) CriOS/56.0.2924.75 Mobile/14E5239e Safari/602.1'
session = requests.Session()
cookies=''

sessionx = requests.Session()
sessionx2 = requests.Session()
session.cookies = cookielib.LWPCookieJar()
sessionx.cookies = cookielib.LWPCookieJar()
sessionx2.cookies = cookielib.LWPCookieJar()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=1,fanart=FANART,moviescount=0):
	list_item = xbmcgui.ListItem(label=name)

	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')
	if not infoLabels:
		infoLabels={'title': name,'plot':name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	if not fanart:
		fanart=FANART
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': fanart})
	ok=xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url,'title':name,'image':image}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %P")
	return ok


def home():
	setUnblockKuk()

	add_item('https://ssl.ustreamix.com/search.php?q=poland', 'Ustreamix', RESOURCES+'darm.png', "ustreamlist", True)
    #
	#add_item('https://telewizja.cc/', 'telewizja.cc',  RESOURCES+'darm.png', "telecc", True)
	add_item('http://tv-swirtvteam.info/', 'SwirTeamTk', RESOURCES+'darm.png', "swirtk", True)
	add_item('http://darmowatv.ws', 'darmowatv.ws',  RESOURCES+'darm.png', "darmowatvws", True)

def getDarmowaws():
	UAx = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0'
	headx = {
		'user-agent': UAx,
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
	}
	url = params.get('url', None)

	html = sessionx2.get(url, headers=headx, verify=False).content
	result = parseDOM(html, 'div', attrs={'class': "entry-content"})[0]

	abc = re.findall("""href\s*=\s*['"](.+?)['"].+?<img src\s*=\s*['"](.+?)['"]""",result,re.DOTALL)
	src=''
	for href,src in abc:
		tyt = href
		href = href if href.startswith('http') else 'http://darmowatv.ws'+href
		if tyt.startswith('/'):
			tyt = tyt[1:].upper()
		else:
			from urlparse import urlparse
			tyt = (urlparse(tyt).path)[1:].upper()

		add_item(href, tyt,src, 'playDarmowaws', folder=False, IsPlayable=False,infoLabels={'plot':tyt})	
		
		
	xbmcplugin.setContent(addon_handle, 'videos')	
	xbmcplugin.endOfDirectory(addon_handle)

def playDarmowaws():

	url = params.get('url', None)
	tytul = params.get('title', None)

	UAx = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0'
	headx = {
		'user-agent': UAx,
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
	}
	html = sessionx2.get(url, headers=headx, verify=False).content

	import resources.lib.mydecode as mydecode
	stream = mydecode.decode(url,html)
	if stream:
		if 'run/co' in stream:
			tytul = tytul if tytul else 'stream'
			liz = xbmcgui.ListItem(label=tytul)
			liz.setProperty("IsPlayable", "true")
			stream_url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&url={0}&name={1}'.format(
				urllib.quote_plus(stream), urllib.quote_plus(tytul))
			liz.setPath(stream)
			try:
	
				#xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
				#xbmc.executebuiltin('Dialog.Close(all,true)')
				xbmc.executebuiltin('RunPlugin(' + stream_url + ')')
			except BaseException:
				pass
		elif 'internetowa.' in stream:
			play_item = xbmcgui.ListItem(path=stream)
			play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
			play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
			play_item.setMimeType('application/x-mpegurl')
			play_item.setContentLookup(False)
			Player = xbmc.Player()
			Player.play(stream, play_item)
			#xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
		else:
			play_item = xbmcgui.ListItem(path=stream)#
			play_item.setInfo(type="Video", infoLabels={"title": tytul,'plot':tytul})
			play_item.setProperty("IsPlayable", "true")
			Player = xbmc.Player()
			Player.play(stream, play_item)
			#play_item = xbmcgui.ListItem(path=stream)
			#xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
	else:
		xbmcgui.Dialog().notification('[COLOR orangered][B]Błąd[/B][/COLOR]', '[COLOR orangered][B]Brak działającego streama[/B][/COLOR]', xbmcgui.NOTIFICATION_INFO, 5000,False)
def ustreamList():

	newurl = params.get('url', None)
	html=session.get(newurl,verify=False).content
	
	result = parseDOM(html, 'div', attrs={'class': "container"})[0]
	links = parseDOM(html, 'p')
	for link in links:

		try:
			hrefnamestatus = re.findall("""href=['"](.+?)['"].+?>(.+?)<spa.+?['"]status_(.+?)['"]>""",link)
			href = hrefnamestatus[0][0]
			tyt = hrefnamestatus[0][1]
			stat = hrefnamestatus[0][2]

			if href.startswith('/embed'): href = 'https://ssl.ustreamix.com'+href#self.MAIN_URL + phUrl
			href = 'https://ssl.ustreamix.com'+href if href.startswith('/embed') else href

			add_item(href, tyt,'',  'playustreamix', folder=False, IsPlayable=True,infoLabels={'plot':tyt,'code':stat})	
			
		except:
			xbmc.log('Blad w : %s' % link, xbmc.LOGNOTICE)
	xbmcplugin.setContent(addon_handle, 'videos')
	xbmcplugin.endOfDirectory(addon_handle)

def bps_dguard(): 
	import random
	if not fprint:
		a= ''.join([random.choice('0123456789abcdef') for x in range(33)])
		addon.setSetting('fprint', str(a))
	fpr = addon.getSetting('fprint')
	host = "https://telewizja.cc/"
	UAx = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'
	headers2 = {
	
		'Referer':host,
		'user-agent': UAx,
		'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
	}
	response = sessionx.get("https://check.ddos-guard.net/check.js",headers=headers2,verify=False).text
	ddosBypassPath=re.findall("'(.*?)'", response)
	
	
	response = sessionx.get(host + ddosBypassPath[0],headers=headers2,verify=False).text
	
	response = sessionx.get(ddosBypassPath[1],headers=headers2,verify=False).text
	zz='https://check.ddos-guard.net/set/id4/'+fpr
	response = sessionx.get( zz,headers=headers2,verify=False).text
	
	zz2='https://telewizja.cc/.well-known/ddos-guard/id4/'+fpr
	response = sessionx.get( zz2,headers=headers2,verify=False).text
	
	sc = ''.join(['%s=%s;'%(c.name, c.value) for c in sessionx.cookies])
	addon.setSetting('dguardcuk', str(sc))
	return sc

	
def getTelecc():
	sc=bps_dguard()
	host = "https://telewizja.cc/"
	url = params.get('url', None)
	newurl = params.get('url', None)
	UAx = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'
	headx = {
		'Host': 'telewizja.cc',
		'user-agent': UAx,
		'accept': '*/*',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',} 
	ab=sessionx.cookies
	html = sessionx.get(url, headers=headx, cookies=sessionx.cookies, verify=False).text

	result = parseDOM(html, 'div', attrs={'id': "item-list","class":"row tv-list"})[0]
	
	links = parseDOM(result, 'div', attrs={'class': "col\-xs\-\d+ col\-sm\-\d+"})#div class="col-xs-2 col-sm-2"> 
	for link in links:
		src = parseDOM(link, 'img', ret='src')[0]
		href = parseDOM(link, 'a', ret='href')[0]   
		title = parseDOM(link, 'a', ret='title')[0]  
		if href and title:

			add_item(href, title,src+'|User-Agent='+urllib.quote(UAx)+'&Cookie='+sc,  'playtelecc', folder=False, IsPlayable=True,infoLabels={'plot':title})	

			
	xbmcplugin.endOfDirectory(addon_handle)
	
def playTelecc():
	url = params.get('url', None)
	newurl = params.get('url', None)
	kuk = addon.getSetting('dguardcuk')
	UAx = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0'
	headx = {
		'Host': 'telewizja.cc',
		'user-agent': UAx,
		'accept': '*/*',
		'cookie':kuk,
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',} 
	html=sessionx.get(url, headers=headx, cookies=sessionx.cookies, verify=False).text
	frm = parseDOM(html, 'form') 

	frm2 = re.findall('<form(.*?)<\/form',html,re.DOTALL)

	if frm2:
		frm=frm2[0]
		mthd,url2 = re.findall('method\s*=\s*(.+?)\s+\s*action\s*=\s*(.+?)\s*>',frm)[0]
		mthd = mthd.replace('"','').replace("'",'')
		url2 = url2.replace('"','').replace("'",'')
		if 'unescape' in frm:
			
			frm+= urllib.unquote(re.findall("""unescape\(['"](.+?)['"]""",frm)[0])
		post = {k.replace('"','').replace("'",''): v.replace('"','').replace("'",'') for k, v in re.findall("""name\s*=\s*(.+?)\s+\s*value\s*=\s*(.+?)\s*\/>""", frm)}
		headers = {

			'user-agent': UAx,
			'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
			'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
			'content-type': 'application/x-www-form-urlencoded',
			'origin': 'https://telewizja.cc',
			'dnt': '1',
			'referer': 'https://telewizja.cc/',
			'upgrade-insecure-requests': '1',
			'te': 'trailers',}
		
		if 'post' in mthd:
			html = requests.post(url2, data=post, headers=headers, verify=False).content
		else:
			html = requests.get(url2, headers=headers, verify=False).content
		
	source = re.findall('source:"([^"]+)"',html)
	source = source[0] if source else ''
	if source:
		headersx5 = {
			'Host': 's8dtv.m3u-cdn.live',
			'User-Agent': UAx,
			'Accept': '*/*',
			'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
			'Origin': 'https://embed.m3u-cdn.live',
			'DNT': '1',
			'Referer': 'https://embed.m3u-cdn.live/',
		}
		hea= '&'.join(['%s=%s' % (name, value) for (name, value) in headersx5.items()])	
	
	
		source+='|'+hea
		play_item = xbmcgui.ListItem(path=source)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)	
	else:
		xbmcgui.Dialog().notification('[COLOR orangered][B]Błąd[/B][/COLOR]', '[COLOR orangered][B]Brak działającego streama[/B][/COLOR]', xbmcgui.NOTIFICATION_INFO, 5000)
		
def getEpg(url):
	headersok = {
	'User-Agent': UA,
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
	'Connection': 'keep-alive',
	'Upgrade-Insecure-Requests': '1',
	'TE': 'Trailers',}	
	html=requests.get(url,headers=headersok,verify=False).text	
	result = parseDOM(html, 'div', attrs={'class': "col-md-4"})[0]
	link = parseDOM(result, 'iframe', ret='src')[0]
	html=requests.get(link,headers=headersok,verify=False).text		
	xxx=re.findall('</i>(.+?)</span>(.+?)</h2>',html,re.DOTALL)
	tyt=''
	
	for czas,co in xxx:
		tyt+='%s %s[CR]'%(czas,co)
	return tyt.replace('&nbsp','')
	
def setUnblockKuk():	
	import uuid
	hash = uuid.uuid4().hex					
	aa='1679497221'
	kuk='__ddgu=%s.%s'%(hash,aa)		
	addon.setSetting('unbkuk',kuk)
	return kuk
	
def playUstreamix(newurl):

	import resources.lib.jsunpack as jsunpack
	headers = {
		'Host': 'ssl.ustreamix.com',
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': newurl,
		'Upgrade-Insecure-Requests': '1',}	
	r = requests.get(newurl,verify=False)
	

	content=r.content
	unpacked=''
	packeds = packer.findall(content)#[0]
	for packed in packeds:
		unpacked += jsunpack.unpack(packed)

	varhost=re.compile('var host_tmg="(.*?)"').findall(unpacked)
	varfname=re.compile('var file_name="(.*?)"').findall(unpacked)
	varjdtk=re.compile('var jdtk="(.*?)"').findall(unpacked)
	if varhost and varfname and varjdtk:
		stream_url = 'https://' + varhost[0] + '/' + varfname[0] + '?token=' + varjdtk[0] +'|User-Agent='+urllib.quote(UA)+'&Referer='+newurl
		play_item = xbmcgui.ListItem(path=stream_url)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
	
	
	
	
	
	else:
	
		xbmcgui.Dialog().notification('[COLOR orangered][B]Błąd[/B][/COLOR]', '[COLOR orangered][B]Brak działającego streama[/B][/COLOR]', xbmcgui.NOTIFICATION_INFO, 5000)

def getSwirtk():
	newurl = params.get('url', None)
	
	content=sessionx2.get(newurl,verify=False).text	
	zle = re.findall("""(\<\!\-\-.*?\-\->)""",content,re.DOTALL)
	for zz in zle:
		content=content.replace(zz,'')
		
	#content=content.replace('<!--<li><a title=','')
	sc=''.join(['%s=%s;'%(c.name, c.value) for c in sessionx2.cookies])
	links = parseDOM(content,  'li')
	for link in links:	
		
		url= parseDOM(link, 'a', ret='href')
		if url:
			url = url[0]
			title=parseDOM(link, 'a', ret='title')[0]
			image=parseDOM(link, 'img', ret='src')[0]
			image = 'http://tv-swirtvteam.info/'+urllib.quote(image)+'|User-Agent='+urllib.quote(UA)+'&Referer='+urllib.quote('http://tv-swirtvteam.tk/')+'&Cookie='+urllib.quote(sc)		
			add_item('http://tv-swirtvteam.info/'+url, title,image,  'playtvswir', folder=False, IsPlayable=False)
		else:
			continue
	xbmcplugin.setContent(addon_handle, 'videos')	
	xbmcplugin.endOfDirectory(addon_handle)	
		
def playtvswir():

	newurl = params.get('url', None)
	tytul = params.get('title', None)
	headers = {

		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',

		'Upgrade-Insecure-Requests': '1',}	
	content=sessionx2.get(newurl,headers=headers, verify=False).content

	nturl= parseDOM(content, 'iframe', ret='src')#[0]
	if nturl:
	
		content=sessionx2.get(nturl[0],headers=headers, verify=False).content
	
	atobf=re.findall("""atob\([\\'"](.+?)[\\'"]""",content,re.DOTALL)
	if atobf:
		stream_url = base64.b64decode(atobf[0])
		stream_url += '|User-Agent='+urllib.quote(UA)+'&Referer='+newurl
		#play_item = xbmcgui.ListItem(path=stream_url)
		play_item = xbmcgui.ListItem(path=stream_url)#
		play_item.setInfo(type="Video", infoLabels={"title": tytul,'plot':tytul})
		play_item.setProperty("IsPlayable", "true")
		Player = xbmc.Player()
		Player.play(stream_url, play_item)
		#xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
		
	else:
		try:
		
			stream_url = clappr.findall(content)[0]
	
		except:
			stream_url = source.findall(content)[0]
		if stream_url:
	
			if stream_url.startswith('//'): stream_url = 'http:' + stream_url
	
			liz = xbmcgui.ListItem(label=tytul)
			liz.setProperty("IsPlayable", "true")
			stream_url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&url={0}&name={1}'.format(
				urllib.quote_plus(stream_url), urllib.quote_plus(tytul))
			liz.setPath(stream_url)
			try:
				xbmc.executebuiltin('RunPlugin(' + stream_url + ')')
			except BaseException:
				pass
		else:
			xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR] ','Brak działającego streama!!!')	
		
def NLheaders(ref):
	hea = {
		'Host': 'edge.nlive.club',
		'User-Agent': UA,
		'Accept': '*/*',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': ref,
		'Origin': 'https://nlive.club',
	}
	
	hed = ['%s=%s' % (name, value) for (name, value) in hea.items()]
	return '&'.join(hed)	
	
def getNlive(html, ref):
	embedd= parseDOM(html, 'iframe', ret='src')[0]
	header = {'User-Agent':UA,'Referer': ref, }	
	r = requests.get(embedd, headers=header,	verify=False)#.text
	header2 = {
		'User-Agent': UA,
		'Accept': 'application/json, text/javascript, */*; q=0.01',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': embedd,
		'X-Requested-With': 'XMLHttpRequest',
		'Connection': 'keep-alive',
		'Cache-Control': 'max-age=0',}	
	str=re.findall('curl = "(.+?)"',r.text,re.DOTALL)

	if str:
		token= requests.get('https://nlive.club/getToken.php', headers=header2,	cookies=r.cookies,verify=False).text
		token=re.findall('"token":"(.+?)"',token)#[0]	
	stream_url=''
	if token and str:
		hea=NLheaders(embedd)
		stream_url='%s%s|%s'%(str[0],token[0],hea)
	return stream_url


		
def playSawlive():
	newurl = params.get('url', None)
	headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': '*/*',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': newurl,
    'Connection': 'keep-alive',}

	content = requests.get(newurl,headers=headers,verify=False).content
	nexturl2 = re.compile('"text/javascript"\s+src="(.*?)"').findall(content)[0]
	headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': '*/*',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': newurl,
    'Connection': 'keep-alive',}		
	content = requests.get(nexturl2,headers=headers,verify=False).content
	decSawUrl=getDecodeSaw(content)
	str=	decode(decSawUrl,decSawUrl)
	if str:
		play_item = xbmcgui.ListItem(path=str)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)	
	else:
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR] ','Brak działającego streama!!!')	

def decode(content2,strona):

	if 'telerium' in content2:
		stream_url=getTelerium(content2,strona[0])
		return stream_url
		
	elif 'embed.twojetv.ws' in content2:
		stream_url=_twojetv(content2,strona)
		return stream_url		
	
	elif 'kastream.biz' in content2 or 'kastream.biz' in strona:
		stream_url=getKastream(content2,strona)
		return stream_url		
	elif 'tvmaniak.com/player2.php' in content2:
		stream_url=getManiakPlayer(content2,strona)
		return stream_url
	elif 'new Clappr.Player({' in content2:
		stream_url=getm3u8(content2,strona[0])
		return stream_url
	elif 'widestream.io' in content2:
		stream_url=getWidestream(content2,strona)
		return stream_url
	elif 'castto.me' in content2:
		stream_url=getCasttome(content2,strona[0])
		return stream_url
	elif 'emb.aliez.me' in content2:
		stream_url=getAliezme(content2,strona[0])
		return stream_url
	elif 'pxstream.tv' in content2:
		stream_url=getPxstream(content2,strona[0])
		return stream_url
	elif '123streams.co' in content2:
		stream_url=get123stream(content2,strona[0])
		return stream_url		
	elif 'tv4-poland' in content2:
		tv4url='https://ssl.ustreamix.com/stream.php?id=tv4-poland'
		stream_url=getTV4(tv4url)
		return stream_url	
	elif 'supersportowo' in content2:
		stream_url=getSupersportowo(content2,strona[0])
		return stream_url	
	elif 'polim-tv.blogspot' in content2:
		if 'tvmaniak' in strona:
			stream_url=getPolimblogspot(content2,strona)
		else:
			stream_url=getPolimblogspot(content2,strona[0])	
		return stream_url	
	elif 'tel-emporio.blogspot.com' in content2:
		if 'tvmaniak' in strona:
			stream_url=getTelemporio(content2,strona)
		else:
			stream_url=getTelemporio(content2,strona)	
		return stream_url	
	elif 'whostreams' in content2:
		if 'tvmaniak' in strona or 'darmowa-telewizja.online' in strona:
			stream_url=getWhostreams(content2,strona)	
		else:
			stream_url=getWhostreams(content2,strona[0])	
		return stream_url	
	elif 'wiz1.net' in content2:
		stream_url=getWiz1net(content2,strona[0])
		return stream_url	
	elif 'sawlive.tv' in content2:
		stream_url=getSawLive(content2,strona)
		return stream_url
	elif 'w.wlive.tv' in content2:
		stream_url=_wlivetv(content2,strona[0])
		return stream_url		
		
		
		
		
		
	return None

def getKastream(content2,strona):
	stream=''
	try:
		html=content2.replace("\'",'"')
		file=re.findall('file="(.+?)"; width="\d+"; height="\d+"',html)[0]
		url='http://kastream.biz/embed2.php?file=%s'%file
	except:
		url=content2
	headers = {
    'User-Agent': UA,
    'Accept': '*/*',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': strona,
    'Connection': 'keep-alive',}

	html = requests.get(url,headers=headers,verify=False,timeout=30).content	

	packed = packer.findall(html)[0]
	unpacked = jsunpack.unpack(packed)	
	str=re.findall('source:"(.+?)"',unpacked)
	if str:

		stream = 'http:'+str[0]+'|User-Agent='+UA+'&Referer='+strona
	return stream

def _twojetv(data,url):
	iframe=parseDOM(data, 'iframe', ret='src')[0]
	headers = {'User-Agent': UA,'Referer': url}	
	contentVideo=requests.get(iframe,headers=headers,verify=False).content
	vidurl=re.findall('source:\s+"(ht.+?.m3u8)"',contentVideo,re.DOTALL)#[0]
	vidurl = vidurl[0]+'|User-Agent'+urllib.quote(UA)+'&Referer='+iframe if vidurl else ''	
	return vidurl
	
	
	
def getManiakPlayer(content2,strona):

	iframe=parseDOM(content2, 'iframe', ret='src')[0]
	s.headers.update({'Referer': strona})
	content = s.get(iframe).content	
	stream=re.findall('file:"(.+?)"',content)[0]
	return stream
def getSawLive(content2,strona):

	headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': '*/*',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': 'http://www.sawlive.tv',
    'Connection': 'keep-alive',}

	result = requests.get(strona,headers=headers,verify=False).content
	unpacked = ''
	packed = result.split('\n')
	for i in packed:
		try:
			if 'unescape' in i:
				a=i
			if 'rtmp://' in i:
				rtm=i
			unpacked += jsunpack.unpack(i)
		except:
			pass

	varx = re.compile("'(.*?)'").findall(a)
	mem=varx[0]
	dod=varx[1].replace('n4n4n4n4','M')
	rtmp= re.compile('[\"](rtmp:.+?)[\"]').findall(rtm)[0]
	stream=rtmp+' playpath='+mem+'?'+dod+' swfUrl=http://static3.sawlive.tv/player.swf'+' pageUrl='+strona
	result += unpacked
	result = urllib.unquote_plus(result)
	var = re.compile('var\s(.+?)\s*=\s*[\'\"](.+?)[\'\"]').findall(result)
	rplcs = re.findall('dsss.=.(.*?).replace\([\"\'](.+?)[\"\']\s*,\s*[\"\']([^\"\']*)[\"\']',result) #;.+?=(.+?).replace\([\"\'](.+?)[\"\']\s*,\s*[\"\']([^\"\']*)[\"\']
	var_dict = dict(var)       
	file = re.compile(' "file":""(.+?)""').findall(result)[0]

	return stream	

	
def getTelerium(content2,strona):

	content2 = content2.replace("\'",'"')
	str=''
	embedd=''
	try:
		id = re.findall('javascript">id="(.+?)";',content2)

		embedd= "http://telerium.tv/embed/" + id[0] + ".html"
	except:		
		url = parseDOM(content2, 'iframe', ret='src')
		if url:
			embedd=url[0]
	if embedd:
		str=resolve(embedd,strona)
	return str
	
def getm3u8(content2,strona):
	m3u8playlist = re.compile('["\'](http.*?\\.m3u[8])["\']').findall(content2)
	if m3u8playlist:
		str = m3u8playlist[0]+'|User-Agent='+UA+'&Referer='+strona
	return str
	
def getDecodeSaw(content):
	mainsaw='http://www.sawlive.tv/embed/stream/'

	var = re.compile("""var\s+\w+\s+=\s*['"](.*?)['"]""").findall(content) #[0][1]
	print var

	vars=var[0].split(';')
	var1=vars[0]
	var2=vars[1]
	dec= mainsaw+var2+'/'+var1
	return dec
	
def getWiz1net(content2,strona):

	nexturl = parseDOM(content2, 'iframe',ret='src')
	headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': strona,
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
}

	content = requests.get(nexturl[0],headers=headers,verify=False).content	
	
	nexturl2 = re.compile('"text/javascript"\s+src="(.*?)"').findall(content)[0]
	headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': '*/*',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': nexturl[0],
    'Connection': 'keep-alive',}
	
	content = requests.get(nexturl2,headers=headers,verify=False).content
	decSawUrl=getDecodeSaw(content)
	str=	decode(decSawUrl,decSawUrl)
	return str
def getPolimblogspot(content2,strona):
	nexturl = parseDOM(content2, 'iframe',ret='src')
	content = requests.get(
		nexturl[0],
		verify=False).content		
	evalDecode=getDecodeEval(content)
	m3u8playlist = re.compile("""source:.["'](http.*?.m3u8.*?)["']""").findall(evalDecode)	
	if m3u8playlist:
		str = m3u8playlist[0]+'|User-Agent='+UA+'&Referer='+strona
	return str
	
def getTelemporio(content2,strona):	
	nexturl = parseDOM(content2, 'iframe',ret='src')
	content = requests.get(
		nexturl[0],
		verify=False).content
	try:
		evalDecode=getDecodeEval(content)
		stream_url=	decode(evalDecode,nexturl[0])
		return stream_url
	except:
		nexturls = parseDOM(content, 'a',ret='href')
		for nexturl2 in nexturls:
			if 'tel-emporio' in nexturl2:
				nexturl3=nexturl2
		content2 = requests.get(
			nexturl3,
			verify=False).content	
		evalDecode=getDecodeEval(content2)
		try:
			str_url=re.compile('[?](http[s].*?)"').findall(evalDecode)		
			if 'ustreamix' in str_url[0]:
				str=getTV4(str_url[0])
				return str
		except:
			str=	decode(evalDecode,nexturl3)
		return str
		
def decode_frame(s, splitconst, appendconst, offsetconst):
    r = ""
    tmp = s.split(splitconst)
    s = urllib.unquote(tmp[0])
    k = urllib.unquote(tmp[1]+appendconst)
    for i in range(0, len(s)):
        r = r + chr((int(k[i%len(k)]) ^ ord(s[i])) + offsetconst)
    return r	
	
def getDecodeEval(content):
	start = 0
	end = -1
	
	searcharea = content[start:]
	
	if searcharea.find("unescape('")!=-1:
		start = searcharea.find("unescape('")

		end = searcharea.find("')", start)
		encframe = searcharea[start+10:end]
		decframe = urllib.unquote(encframe)
		frame=decframe
	else:
		frame=searcharea
	
	if frame.__contains__('split("') and frame.__contains__("charCodeAt"):
		splitmatch = re.compile('split\("(.+?)"\);').findall(frame)
		appendmatch = re.compile('tmp\[1\].*?"(.+?)"').findall(frame)
		offsetmatch = re.compile('charCodeAt\(i\)\)\+(.+?)\)').findall(frame)
	
		payloadstart = searcharea.find("eval(unescape('")

		payloadstart = searcharea.find("unescape('", payloadstart+16)
		payloadstart = searcharea.find("'", payloadstart+11)
		payloadstart = searcharea.find("'", payloadstart+2)
		payloadend = searcharea.find("'", payloadstart+1)
		decframe = decode_frame(searcharea[payloadstart+1:payloadend], splitmatch[0], appendmatch[0], int(offsetmatch[0]))
		frame = decframe
	
	frame=frame.replace('\n', ' ').replace('\r', ' ')
	return frame
	
def getWidestream(content2,strona):
	nexturl = re.compile('iframe src="(.*?)"').findall(content2)
	r = requests.get(
		nexturl[0],
		verify=False)		
	m3u8playlist = re.compile('file:"(.*?)"').findall(r.content)
	if m3u8playlist:
		str = m3u8playlist[0]+'|User-Agent='+UA+'&Referer='+strona
	return str

def _wlivetv(data,url):
	
	video_url=''
	feed = re.compile('fid=["\'](.*?)["\']; v_width=(.*?); v_height=(.*?);').findall(data)
	if not feed:
		try:
			
			header = {'User-Agent':UA,'Referer': url}
			nxturl=re.findall('iframe src="(.+?)"',data)[0].replace('&amp;','&')
			contentVideo = requests.get(nxturl,headers=header).content
			pi = re.findall('return\\((.*?)\\);',contentVideo)
			#
			print pi
			pi=pi[0]
			if pi:
			
			
				join = re.findall('(\\[.*?\\]).join',pi)
				el_id = re.findall('(\\w+).join',pi)
				aa = re.findall('document.getElementById\\("(.*?)"',pi)
				if join:
					join = ''.join(eval(join[0])).replace('\\','')
				print join
				if el_id:
					tmp = re.findall('var %s\\s*=\\s*(\\[.*?\\])'%el_id[0],contentVideo)
					el_id = ''.join(eval(tmp[0])) if tmp else ''
				if aa:
					aa = re.findall('%s\\s*>(.*?)<'%aa[0],contentVideo)
					aa = aa[0] if aa else ''
					video_url = join + el_id + aa +'|User-Agent='+UA+'&Referer='+url
					video_url = 'https:'+video_url if video_url.startswith('//') else video_url
					
		except:
			pass
							
	else:
		
		header = {'User-Agent':UA,'Referer': url}
		if data.find('wlive.tv/embedra.js')>0:
			url_main='http://www.wlive.tv/embedra.php?player=desktop&live=%s&vw=660&vh=420'%feed[0][0]			
		else:
			url_main='http://www.wlive.tv/embedhd.php?player=desktop&live=%s&vw=660&vh=420'%feed[0][0]

		contentVideo = requests.get(url_main,headers=header).content
		
		pi = re.findall('return\\((.*?)\\);',contentVideo)
		pi=pi[0]
		if pi:		
			join = re.findall('(\\[.*?\\]).join',pi)
			el_id = re.findall('(\\w+).join',pi)
			aa = re.findall('document.getElementById\\("(.*?)"',pi)
			if join:
				join = ''.join(eval(join[0])).replace('\\','')
			if el_id:
				tmp = re.findall('var %s\\s*=\\s*(\\[.*?\\])'%el_id[0],contentVideo)
				el_id = ''.join(eval(tmp[0])) if tmp else ''
			if aa:
				aa = re.findall('%s\\s*>(.*?)<'%aa[0],contentVideo)
				aa = aa[0] if aa else ''
				video_url = join + el_id + aa +'|User-Agent='+UA+'&Referer='+url
	return video_url



	
def getCasttome(content2,strona):
	feed = re.compile('fid="(.*?)"; v_width=(.*?); v_height=(.*?);').findall(content2)
	if feed:
		url_main='http://static.castto.me/embedlivesrclappr.php?channel=%s&vw=%s&vh=%s'%feed[0]
	header = {'User-Agent':UA,
			'Referer': strona,
			'Host':'static.castto.me',
            }
	r = requests.get(
		url_main,
		headers=header,
		verify=False)
	file   = re.compile('file\\s*:\\s*["\'](.*?)[\'"]').findall(r.content)
	if file:
		str = file[-1]
	file   = re.compile('source\\s*:\\s*["\'](.*?)[\'"]').findall(r.content)
	if file:
		str = file[-1]
	file   = re.compile('<source src=["\'](.*?)[\'"]').findall(r.content)
	if file:
		str = file[-1]
	if str:
		str += '|User-Agent='+urllib.quote(UA)+'&Referer='+url_main+'&Cookie='+urllib.quote('userid=264414038;')
	return str	
	
def getAliezme(content2,strona):

	next_url = re.compile('src="(http://emb.aliez.me.*?)"').findall(content2)
	headers = {

		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Connection': 'keep-alive',
		'Upgrade-Insecure-Requests': '1',
		}
	r = requests.get(
		next_url[0],
		headers=headers,
		verify=False)

	cur=r.content
	str   = re.compile("""['"]*(http[^'^"]+?\.m3u8[^'^"]*?)['"]""").findall(r.content)
	str=str[0] +'|User-Agent='+UA+'&Referer='+next_url[0]  # '|User-Agent='+UA+'&Referer='+next_url[0] #' live=true swfVfy=1 swfUrl=http://i.aliez.me/swf/playernew.swf flashver=WIN\2024,0,0,221 pageUrl=' +next_url[0]
	if str:
		return str		
	else: return None
	
def getPxstream(content2,strona):	
	next_url = re.compile('src="(.*?)"').findall(content2)
	for url in next_url:
		if 'pxstream.tv' in url:
			pxurl=url
		else:
			continue
	header = {'User-Agent':UA,
		'Referer': strona,
		'Host':'pxstream.tv'}		
	r = requests.get(
		pxurl,
		headers=header,
		verify=False)
	a=r.content
	m3u8playlist = re.compile("""file:.['"](.*?)['"]""").findall(r.content)	
	if m3u8playlist:
		str = m3u8playlist[0]+'|User-Agent='+UA+'&Referer='+pxurl+'&X-Requested-With=ShockwaveFlash/24.0.0.186'	
		return str	
	else: return None
	
def getSupersportowo(content2,strona):

	next_url=re.compile("""(http://supersportowo.com/.*?)['"]""").findall(content2)
	r = requests.get(
		next_url[0],
		verify=False)
	content2=r.content
	if 'whostreams' in content2:
		stream_url=getWhostreams(content2,next_url[0])
	return stream_url

def getWhostreams(content2,strona):
	try:
		embedd= parseDOM(content2, 'iframe', ret='src')[0]
		header = {'User-Agent':UAiphone,'Referer': strona, }		
		page = requests.get(embedd, headers=header,	verify=False).text
		packed = packer.findall(page)[0]
		unpacked = jsunpack.unpack(packed)
		try:
			str = clappr.findall(unpacked)[0]
		except:
			str = source.findall(unpacked)[0]
		str += '|User-Agent={ua}&Referer={ref}'.format(ua=UAiphone, ref=embedd)
	except:
		str=''
	return str

def get123stream(content2,strona):
	feed = re.compile("""id=['"](.*?)['"]; width=['"](.*?)['"]; height=['"](.*?)['"];""").findall(content2)
	if feed:
		url_main='http://www.123streams.co/stream.php?id=%s&width=%s&height=%s&stretching=uniform'%feed[0]
	header = {'User-Agent':UA,
		'Referer': strona,
		'Host':'www.123streams.co'}		
	r = requests.get(
		url_main,
		headers=header,
		verify=False)		
	pi = re.findall('return\\((.*?)\\);',r.content)
	print pi
	pi=pi[2]
	if pi:
		join = re.findall('(\\[.*?\\]).join',pi)
		el_id = re.findall('(\\w+).join',pi)
		aa = re.findall('document.getElementById\\("(.*?)"',pi)
		if join:
			join = ''.join(eval(join[0])).replace('\\','')
		if el_id:
			tmp = re.findall('var %s\\s*=\\s*(\\[.*?\\])'%el_id[0],r.content)
			el_id = ''.join(eval(tmp[0])) if tmp else ''
		if aa:
			aa = re.findall('%s\\s*>(.*?)<'%aa[0],r.content)
			aa = aa[0] if aa else ''
		str = join + el_id + aa +'|User-Agent='+UA+'&Referer='+url_main		
	return str
	
def getTV4(tv4url):
	headers = {
		'Host': 'ssl.ustreamix.com',
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': tv4url,
		'Upgrade-Insecure-Requests': '1',}	
	r = requests.get(
		tv4url,
		verify=False)
	content=r.content
	next = re.compile("window.open\('(.*?)'").findall(content)
	r = requests.get(
		next[0],
		headers=headers,
		verify=False)	
	content=r.content
	headers2 = {
		'Host': 's.ustreamix.com',
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Upgrade-Insecure-Requests': '1',}	
	next2 = re.compile('url=(.*?)"').findall(content)
	r = requests.get(
		next2[0],
		headers=headers2,
		verify=False)	
	content=r.content
	packed = packer.findall(content)[0]
	unpacked = jsunpack.unpack(packed)
	varhost=re.compile('var host_tmg="(.*?)"').findall(unpacked)
	varfname=re.compile('var file_name="(.*?)"').findall(unpacked)
	varjdtk=re.compile('var jdtk="(.*?)"').findall(unpacked)
	stream_url = 'https://' + varhost[0] + '/' + varfname[0] + '?token=' + varjdtk[0] +'|Referer=' + next2[0]#;	
	return stream_url
	
def rev(a_string):
    return a_string[::-1]	

	
def resolve(embedd,stronka):
	resp = s.get(embedd, headers={'User-Agent':UA, 'Referer':stronka},verify=False,allow_redirects=False)#.content
	data=resp.content
	try:
		packed = packer.findall(data)[0]
	except:
		return ''
	
	unpacked = jsunpack.unpack(packed)	
	ab=unpacked

	pliki = (re.findall('hysterical\((.+?)\)',unpacked)[0]).split(',') 
	patern3	='var '+pliki[1]+'=window.atob\((.+?)\)'
	src6=re.compile(patern3).findall(unpacked)	
	patern6=src6[0]+'="(.*?)"'	
	
	src7=re.compile(patern6).findall(unpacked)	 #poprawny poczatek adresu
	d=src7[0]
	d1=base64.b64decode(d)	

	varNames = re.compile('url\:window\.atob\((.*?)\)\.slice\((.*?)\)\+window.atob\((.*?)\)')

	vars = varNames.findall(unpacked)[0]

	part1Reversed = re.compile('{0}\s*=\s*[\'\"](.+?)[\'\"];'.format(vars[0])).findall(unpacked)[0]
	part2Reversed = re.compile('{0}\s*=\s*[\'\"](.+?)[\'\"];'.format(vars[2])).findall(unpacked)[0]	
	oilepattern = 'var '+vars[1]+'=(\d+);'

	oile=re.compile(oilepattern).findall(unpacked)	
	if oile:
		oile = int(oile[0])
	else:
		oile = int(vars[1])
	
	part1 = (base64.b64decode(part1Reversed))[oile:]
	part2 = base64.b64decode(part2Reversed) 
	
	vuelta = re.findall('=dameVuelta\(.+?\[(.+?)\]\)',unpacked)
	
	vuelta = vuelta[0] if vuelta else ''
	oblpat =  vuelta+'=(.+?)([-+])(.+?);'
	sppech = re.compile(oblpat).findall(unpacked)[0]	

	reg1 = ';'+sppech[0]+'=(.+?)([-+])(.+?);'
	reg2 = ';'+sppech[2]+'=(.+?)([-+])(.+?);'
	ob1 =re.compile(reg1).findall(unpacked)
	ob2 =re.compile(reg2).findall(unpacked)
	
	ob11 = re.compile('var '+ob1[0][0]+'=(.+?);').findall(unpacked)
	ob12 = re.compile('var '+ob1[0][2]+'=(.+?);').findall(unpacked)
	
	ob21 = re.compile('var '+ob2[0][0]+'=(.+?);').findall(unpacked)
	ob22 = re.compile('var '+ob2[0][2]+'=(.+?);').findall(unpacked)

	obliczob1 = eval('%s%s%s'%(ob11[0],ob1[0][1],ob12[0]))
	obliczob2 = eval('%s%s%s'%(ob21[0],ob2[0][1],ob22[0]))
	spech = eval('%s%s%s'%(obliczob1,sppech[1],obliczob2))

	realtoken = getRealToken('https://telerium.tv'+part1+part2, embedd,spech)
	
	path = 'https:'+d1+realtoken
	path+='|User-Agent='+UA+'&Referer='+urllib.quote(embedd, safe='')+'&Sec-Fetch-Mode=cors&Origin=https://telerium.tv'

	return path	

    
def getRealToken(link, referer,spech):
	cookies = {
		'ChorreameLaJa': '100',
		'setVolumeSize': '100',
		'NoldoTres': '100',
	}
	h = {
		'Host': 'telerium.tv',
		'User-Agent': UA,
		'Accept': 'application/json, text/javascript, */*; q=0.01',
		'Cookie': 'elVolumen=100',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': referer,
		'X-Requested-With': 'XMLHttpRequest',
	}
	realResp = s.get(link, headers=h,verify=False).content#[1:-1]
	realResp=re.findall('"(.+?)"',realResp)[spech]	
	return realResp[::-1]	
	
def PLchar(char):
    if type(char) is not str:
        char=char.encode('utf-8')
    char = char.replace('\xc4\x85','ą').replace('\xc4\x84','Ą')
    char = char.replace('\xc4\x87','ć').replace('\xc4\x86','Ć')
    char = char.replace('\xc4\x99','ę').replace('\xc4\x98','Ę')
    char = char.replace('\xc5\x82','ł').replace('\xc5\x81','Ł')
    char = char.replace('\xc5\x84','ń').replace('\xc5\x83','Ń')
    char = char.replace('\xc3\xb3','ó').replace('\xc3\x93','Ó')
    char = char.replace('\xc5\x9b','ś').replace('\xc5\x9a','Ś')
    char = char.replace('\xc5\xba','ź').replace('\xc5\xb9','Ź')
    char = char.replace('\xc5\xbc','ż').replace('\xc5\xbb','Ż')
    char = char.replace('&ndash;','-') #.replace('\xc4\x84','Ą')	
    char = char.replace('\xb3','l') #.replace('\xc4\x84','Ą')
	#&ndash;
    return char	
	
	
def router(paramstring):
	params = dict(parse_qsl(paramstring))
	
	if params:
		mode = params.get('mode', None)
		
		if mode == 'swirtk':
			getSwirtk()
		
		elif mode == 'telecc':
			getTelecc()
		
		elif mode == 'playtelecc':
			playTelecc()
		
		elif mode == "darmowatvws":
			getDarmowaws()
		
		elif mode == "playDarmowaws":
			playDarmowaws()
		
		
		
		elif mode == 'playtvswir':
			playtvswir()
		elif mode == 'ustreamlist':
			ustreamList()
		elif mode == 'playustreamix':
			playUstreamix(ex_link) 
				
				
	else:
		home()
		xbmcplugin.endOfDirectory(addon_handle)	
if __name__ == '__main__':
    router(sys.argv[2][1:])	
	
  