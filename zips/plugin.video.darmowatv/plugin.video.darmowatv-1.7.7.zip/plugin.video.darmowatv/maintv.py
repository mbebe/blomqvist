# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import urlparse
import urllib
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import threading
import base64
import cookielib
from CommonFunctions import parseDOM

reload(sys)
sys.setdefaultencoding('utf8')
tvinternet='PGxpPjxhIGhyZWY9ImV1cm9zcG9ydC5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC96MS5wbmciIGFsdD0iRVVST1NQT1JUIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJldXJvc3BvcnQyLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3oyLnBuZyIgYWx0PSJFVVJPU1BPUlQyIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJjYW5hbHNwb3J0Lmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3ozLnBuZyIgYWx0PSJDYW5hbCsgU3BvcnQiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImNhbmFsc3BvcnQyLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3o0LnBuZyIgYWx0PSJDYW5hbCsgU3BvcnQgMiIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0iZWxldmVuMS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC96Ni5wbmciIGFsdD0iRWxldmVuMSIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0iZWxldmVuMi5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC96Ny5wbmciIGFsdD0iRWxldmVuMiIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0iZWxldmVuMy5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC96OC5wbmciIGFsdD0iRWxldmVuMyIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0ibnNwb3J0Lmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3o5LnBuZyIgYWx0PSJOc3BvcnQiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InR2cHNwb3J0Lmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3oxMC5wbmciIGFsdD0iVFZQIFNwb3J0IiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJleHRyZW1lLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3oxMS5wbmciIGFsdD0iRXh0cmVtZSIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0iZHR4Lmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3oxMi5wbmciIGFsdD0iRFRYIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJwb2xzYXRzcG9ydC5odG1sIiB0aXRsZT0iUG9sc2F0IFNwb3J0Ij48aW1nIHNyYz0iZ2Z4L3o1LnBuZyIgYWx0PSJQb2xzYXQgU3BvcnQiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InBvbHNhdHNwb3J0ZXh0cmEuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvcG9sc2F0c3BvcnRleHRyYS5wbmciIGFsdD0iUG9sc2F0IFNwb3J0IEV4dHJhIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJwb2xzYXRzcG9ydG5ld3MuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvcG9sc2F0c3BvcnRuZXdzaGQucG5nIiBhbHQ9IlBvbHNhdCBTcG9ydCBOZXdzIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJwb2xzYXRzcG9ydGZpZ2h0Lmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3BvbHNhdHNwb3J0ZmlnaHRoZC5wbmciIGFsdD0iUG9sc2F0IFNwb3J0IEZpZ2h0IiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJwb2xzYXRzcG9ydHByZW1pdW0xLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3BvbHNhdHNwb3J0cHJlbWl1bTEucG5nIiBhbHQ9IlBvbHNhdCBTcG9ydCBQcmVtaXVtIDEiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InBvbHNhdHNwb3J0cHJlbWl1bS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9wb2xzYXRzcG9ydHByZW1pdW0ucG5nIiBhbHQ9IlBvbHNhdCBTcG9ydCBQcmVtaXVtIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJmaWdodGJveC5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9maWdodGJveGhkLnBuZyIgYWx0PSJGaWdodEJveCBIRCIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0idHZwMS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC96MTMucG5nIiBhbHQ9IlRWUDEiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InR2cDIuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvejE0LnBuZyIgYWx0PSJUVlAyIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJ0dm4uaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvdHZuLnBuZyIgYWx0PSJUVk4iIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InR2bjcuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvdHZuNy5wbmciIGFsdD0iVFZOIDciIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InR2bmZhYnVsYS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC90dm5mYWJ1bGEucG5nIiBhbHQ9IlRWTiBGYWJ1xYJhIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJwb2xzYXQuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvcG9sc2F0LnBuZyIgYWx0PSJQb2xzYXQiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InBvbHNhdDIuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvcG9sc2F0Mi5wbmciIGFsdD0iUG9sc2F0IDIiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InN1cGVycG9sc2F0Lmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3N1cGVycG9sc2F0LnBuZyIgYWx0PSIgU3VwZXIgUG9sc2F0IiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJwb2xzYXRmaWxtLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3BvbHNhdGZpbG0ucG5nIiBhbHQ9IlBvbHNhdCBGaWxtIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJ0djQuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvdHY0LnBuZyIgYWx0PSJUViA0IiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJ0djYuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvdHY2LnBuZyIgYWx0PSJUViA2IiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJwdWxzLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3R2cHVsc2hkLnBuZyIgYWx0PSJUViBQdWxzIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJwdWxzMi5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9wdWxzMi5wbmciIGFsdD0iVFYgUHVscyAyIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJzdG9wa2xhdGthLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3N0b3BrbGF0a2EucG5nIiBhbHQ9IlN0b3BrbGF0a2EiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9IjEzdWxpY2EuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvMTN1bC5wbmciIGFsdD0iMTNVbGljYSIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0idHR2Lmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3R0di5wbmciIGFsdD0iVFRWIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJhdG0uaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvYXRtLnBuZyIgYWx0PSJBVE0gUm96cnl3a2EiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InR2cHNlcmlhbGUuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvdHZwc2VyaWFsZS5wbmciIGFsdD0iVFZQIFNlcmlhbGUiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InR2cHJvenJ5d2thLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3R2cHJvenJ5d2thLnBuZyIgYWx0PSJUVlAgUm96cnl3a2EiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InR2cGguaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvdHZwaC5wbmciIGFsdD0iVFZQIEhpc3RvcmlhIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJraW5vLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3oxNS5wbmciIGFsdD0iS2lub1BvbHNrYSIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0iaGJvLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3oxNi5wbmciIGFsdD0iSEJPIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJoYm8yLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3oxNy5wbmciIGFsdD0iSEJPMiIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0iaGJvMy5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC96MTgucG5nIiBhbHQ9IkhCTzMiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImF4bi5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9heG4ucG5nIiBhbHQ9ImF4biIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0iYXhudy5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9heG53LnBuZyIgYWx0PSJheG4iIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImF4bmIuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvejE5LnBuZyIgYWx0PSJBWE4gQmxhY2siIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImF4bnNwaW4uaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvYXhuc3BpbmhkLnBuZyIgYWx0PSJBWE4gU3BpbiIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0iZm94Lmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3oyMy5wbmciIGFsdD0iRm94IiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJmb3hjb21lZHkuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvZm94Y29tZWR5aGQucG5nIiBhbHQ9IkZveCBDb21lZHkiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InBhcmFtb3VudC5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9wYXJhbW91bnRjaGFubmVsaGQucG5nIiBhbHQ9IlBhcmFtb3VudCBDaGFubmVsIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJmaWxtYm94Zi5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC96MjUucG5nIiBhbHQ9IkZpbG1Cb3ggRmFtaWx5IiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJmaWxtYm94cHJlbWl1bS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9maWxtYm94cHJlbWl1bS5wbmciIGFsdD0iRmlsbUJveFByZW1pdW0iIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9Imtpbm8yLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L2tpbm8yLnBuZyIgYWx0PSJLaW5vVHYiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImNhbmFscGx1cy5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC96MjYucG5nIiBhbHQ9IkNhbmFsKyIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0iY2FuYWxmLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L2NhbmFsZi5wbmciIGFsdD0iQ2FuYWwrIEZpbG0iIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImNhbmFsZmFtaWx5Lmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L2NhbmFsZmFtaWx5LnBuZyIgYWx0PSJDYW5hbCsgRmFtaWx5IiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJjYW5hbHNlcmlhbGUuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvY2FuYWxzZXJpYWxlLnBuZyIgYWx0PSJDYW5hbCsgU2VyaWFsZSIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0iY2luZW1heC5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9jaW5lbWF4LnBuZyIgYWx0PSJDaW5lbWF4IiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJjaW5lbWF4Mi5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9jaW5lbWF4MmhkLnBuZyIgYWx0PSJDaW5lbWF4IDIiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImFsZWtpbm8uaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvYWxla2luby5wbmciIGFsdD0iQWxlIEtpbm8rIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJjb21lZHljZW50cmFsLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L2NvbWVkeWNlbnRyYWwucG5nIiBhbHQ9IkNvbWVkeSBDZW50cmFsIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJkaXNjb3ZlcnkuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvejIwLnBuZyIgYWx0PSJEaXNjb3ZlcnkiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImRpc2NvdmVyeXMuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvejIxLnBuZyIgYWx0PSJEaXNjb3ZlcnkgSUQiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImRpc2NvdmVyeXNjaS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9kaXNjb3ZlcnlzY2kucG5nIiBhbHQ9IkRpc2NvdmVyeSBTY2llbmNlIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJkaXNjb3ZlcnlsaWZlLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L2Rpc2NvdmVyeWxpZmUucG5nIiBhbHQ9IkRpc2NvdmVyeSBMaWZlIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJuYXRnZW9jaGFubmVsLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L25hdGdlb2NoYW5uZWwucG5nIiBhbHQ9Ik5hdCBHZW8gQ2hhbm5lbCIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0ibmF0aW9uYWwuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvejIyLnBuZyIgYWx0PSJEaXNjb3ZlcnkiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9Im5hdGdlb3Blb3BsZS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9uYXRnZW9wZW9wbGUucG5nIiBhbHQ9Ik5hdCBHZW8gUGVvcGxlIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJiYmNlLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L2JiY2UucG5nIiBhbHQ9IkJCQyBFYXJ0aCIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0idHJhdmVsLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3RyYXZlbC5wbmciIGFsdD0iVHJhdmVsIENoYW5uZWwiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9Imhpc3RvcnkuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvaGlzdG9yeS5wbmciIGFsdD0iSGlzdG9yeSIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0iaGlzdG9yeTIuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvaGlzdG9yeTJoZC5wbmciIGFsdD0iSGlzdG9yeSAyIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJjaXBvbHNhdC5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9jaXBvbHNhdGhkLnBuZyIgYWx0PSJDSSBQb2xzYXQiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InBvbHNhdGRva3UuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvcG9sc2F0ZG9rdWhkLnBuZyIgYWx0PSJQb2xzYXQgRG9rdSIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0icG9sc2F0dmlhc2F0ZXhwbG9yZS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9wb2xzYXR2aWFzYXRleHBsb3JlaGQucG5nIiBhbHQ9IlBvbHNhdCBWaWFzYXQgRXhwbG9yZSIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0icG9sc2F0dmlhc2F0bmF0dXJlLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3BvbHNhdHZpYXNhdG5hdHVyZWhkLnBuZyIgYWx0PSJQb2xzYXQgVmlhc2F0IE5hdHVyZSIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0icG9sc2F0dmlhc2F0aGlzdG9yeS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9wb2xzYXR2aWFzYXRoaXN0b3J5aGQucG5nIiBhbHQ9IlBvbHNhdCBWaWFzYXQgSGlzdG9yeSIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0icG9sc2F0Z2FtZXMuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvcG9sc2F0Z2FtZXMucG5nIiBhbHQ9IlBvbHNhdCBHYW1lcyIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0idHZwa3VsdHVyYS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC90dnBrdWx0dXJhLnBuZyIgYWx0PSJUVlAgS3VsdHVyYSIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0iaGd0di5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9oZ3R2LnBuZyIgYWx0PSJIR1RWIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJkb21vLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L2RvbW8ucG5nIiBhbHQ9IkRvbW8rIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJmb2t1cy5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9mb2t1cy5wbmciIGFsdD0iRm9rdXMgVFYiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InBsYW5ldGUuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvcGxhbmV0ZS5wbmciIGFsdD0iUGxhbmV0ZSIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0idHVyYm8uaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvejI3LnBuZyIgYWx0PSJUVk4gVHVyYm8iIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InR2bnN0eWxlLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3R2bnN0eWxlLnBuZyIgYWx0PSJUVk4gU3R5bGUiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InBvbHNhdHBsYXkuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvcG9sc2F0cGxheS5wbmciIGFsdD0iUG9sc2F0IFBsYXkiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InBvbHNhdGNhZmUuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvcG9sc2F0Y2FmZS5wbmciIGFsdD0iUG9sc2F0IENhZmUiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImxpZmUuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvbGlmZS5wbmciIGFsdD0iTGlmZSIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0idGxjLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3RsYy5wbmciIGFsdD0idGxjIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJ0dm4yNC5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC96MjgucG5nIiBhbHQ9IlRWTjI0IiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJ0dm4yNGJpcy5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC90dm4yNGJpcy5wbmciIGFsdD0iVFZOMjQgQmlzIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJwb2xzYXRuZXdzLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3BvbHNhdG5ld3MucG5nIiBhbHQ9IlBvbHNhdCBOZXdzIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJwb2xzYXRuZXdzMi5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9wb2xzYXRuZXdzMi5wbmciIGFsdD0iUG9sc2F0IE5ld3MgMiIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0idHZwaS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC90dnBpLnBuZyIgYWx0PSJUVlAgSW5mbyIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0ic3VwZXJzdGFjamEuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvc3VwZXJzdGFjamEucG5nIiBhbHQ9IlN1cGVyc3RhY2phIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJ0dnJlcHVibGlrYS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC90dnJlcHVibGlrYS5wbmciIGFsdD0iVGVsZXdpemphIFJlcHVibGlrYSIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0id2F0ZXJwbGFuZXQuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvd2F0ZXJwbGFuZXQucG5nIiBhbHQ9IldhdGVyIFBsYW5ldCIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0iY2FydG9vbi5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9jYXJ0b29uLnBuZyIgYWx0PSJDYXJ0b29uIE5ldHdvcmsiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImRpc25leS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9kaXNuZXljaGFubmVsLnBuZyIgYWx0PSJEaXNuZXkiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImRpc25leWp1bmlvci5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9kaXNuZXlqdW5pb3IucG5nIiBhbHQ9IkRvc25leSBKdW5pb3IiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImRpc25leXhkLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L2Rpc25leXhkLnBuZyIgYWx0PSJEaXNuZXkgWEQiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9Im1pbmltaW5pLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L21pbmltaW5pLnBuZyIgYWx0PSJNaW5pIE1pbmkiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImppbWphbS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9qaW1qYW0ucG5nIiBhbHQ9IlBvbHNhdCBKaW0gSmFtIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSJuaWNrb2xlZGlvbi5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9uaWNrb2xlZGlvbi5wbmciIGFsdD0iTmlja2Vsb2Rlb24iIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9Im5pY2tqci5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9uaWNranIucG5nIiBhbHQ9Ik5pY2sgSnIiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InR2cGFiYy5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC90dnBhYmMucG5nIiBhbHQ9IlRWUCBBQkMiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImJhYnl0di5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9iYWJ5dHYucG5nIiBhbHQ9IkJhYnkgVFYiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9Im10di5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9tdHYucG5nIiBhbHQ9Ik1UViIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0iZXNrYS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9lc2thLnBuZyIgYWx0PSJFc2thIFRWIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSI0ZnVuLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4LzRmdW4ucG5nIiBhbHQ9IjQgRnVuIFRWIiAvPjwvYT48L2xpPjxsaT48YSBocmVmPSI0ZnVuZGFuY2UuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvNGZ1bmRhbmNlLnBuZyIgYWx0PSI0IEZ1biBEYW5jZSIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0iNGZ1bmdvbGQuaHRtbCIgdGl0bGU9IiMiPjxpbWcgc3JjPSJnZngvNGZ1bmdvbGRoaXRzLnBuZyIgYWx0PSI0IEZ1biBHb2xkIEhpdHMiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9InBvbHNhdG11c2ljLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L3BvbHNhdG11c2ljaGQucG5nIiBhbHQ9IlBvbHNhdCBNdXNpYyIgLz48L2E+PC9saT48bGk+PGEgaHJlZj0ia2lub3BvbHNrYW11enlrYS5odG1sIiB0aXRsZT0iIyI+PGltZyBzcmM9ImdmeC9raW5vcG9sc2thbXV6eWthLnBuZyIgYWx0PSJLaW5vIFBvbHNrYSBNdXp5a2EiIC8+PC9hPjwvbGk+PGxpPjxhIGhyZWY9ImRpc2NvcG9sb211c2ljLmh0bWwiIHRpdGxlPSIjIj48aW1nIHNyYz0iZ2Z4L2Rpc2NvcG9sb211c2ljLnBuZyIgYWx0PSJEaXNjbyBQb2xvIE11c2ljIiAvPjwvYT48L2xpPg=='
ref='https://internetowa.ws/channel/tvn-24/'
packer = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)')
clappr = re.compile('new\s+Clappr\.Player\(\{\s*?source:\s*?["\'](.+?)["\']')
source = re.compile('sources\s*:\s*\[\s*\{\s*(?:type\s*:\s*[\'\"].+?[\'\"],|)src\s*:\s*[\'\"](.+?)[\'\"]')

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.darmowatv')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
IMAGES       = PATH+'/resources/img/'
FANART=''
sys.path.append( os.path.join( RESOURCES, "lib" ) )

import cfdeco6
import jsunpack

ex_link = params.get('url', None)

darm='http://darmowa-telewizja.online/'
base_link3='http://darmowa-telewizja.online/index-2.html'
BASEURL4='https://www.olweb.tv'
BASEURL5='https://zobacz.ws'
livelooker_url='http://livelooker.com/events.php?lang=pl'
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36'
UAiphone='Mozilla/5.0 (iPhone; CPU iPhone OS 10_3 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) CriOS/56.0.2924.75 Mobile/14E5239e Safari/602.1'
s = requests.Session()
cookies=''


scraper = cfdeco6.create_scraper()

scraper.cookies = cookielib.LWPCookieJar()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)
	
def add_item(url, name, image, folder, mode,infoLabels=False,isPlayable=False):
	list_item = xbmcgui.ListItem(label=name)
	if isPlayable:
		list_item.setProperty("IsPlayable", 'true')
	else:
		list_item.setProperty("IsPlayable", 'false')
	#if folder:
	#    list_item.setProperty("IsPlayable", 'false')
	#else:
	#    list_item.setProperty("IsPlayable", 'true')
	if not infoLabels:
		infoLabels={'title': name, 'sorttitle': name,'plot':name}
	list_item.setInfo(type='video', infoLabels=infoLabels)
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url=build_url({'mode': mode, 'url': url,'title':name}),
		listitem=list_item,
		isFolder=folder
	)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	
def home():
	setUnblockKuk()
	add_item('https://ssl.ustreamix.com/search.php?q=poland', 'Ustreamix', RESOURCES+'darm.png', True, "ustreamlist")
	
	
	
	
	#add_item('https://pol-cast.tk/ipla/', 'POLCAST.TK', RESOURCES+'darm.png', True, "polcastipla")
	
	add_item('http://darmowa-telewizja.online/', 'Darmowa-telewizja.online', RESOURCES+'darm.png', True, "tv2")
	
#	add_item('https://zobacz.ws/', 'Zobacz.ws', RESOURCES+'zobaczws.png', True, "zobaczws")
	add_item('http://tv-swirtvteam.tk/', 'SwirTeamTk', RESOURCES+'darm.png', True, "swirtk")
		
	#add_item('http://telewizjastreamer.com/tv/', 'TelewizjaStreamer', RESOURCES+'chan2.png', True, "telstream")
	
	#add_item('https://telewizja-internetowa.pl/', 'Telewizja internetowa', RESOURCES+'chan2.png', True, "telinter")
	
	add_item('https://supersportowo.com', 'SuperSportowo', RESOURCES+'logoss.png', True, "supersport")
		
	xbmcplugin.endOfDirectory(addon_handle)

	
def getSuperSport():		
	add_item('https://supersportowo.com/stream1.html', 'Canal+ HD', "https://i.imgur.com/UUCy060.png", False, "playsupersportowo",isPlayable=True)	
	
	add_item('https://supersportowo.com/stream2.html', 'Canal+ Sport HD', "https://i.imgur.com/mqnZ2Io.png", False, "playsupersportowo",isPlayable=True)	
		
	add_item('https://supersportowo.com/stream3.html', 'Canal+ Sport 2 HD', "https://i.imgur.com/UYxVd2W.png", False, "playsupersportowo",isPlayable=True)	
	
	add_item('https://supersportowo.com/stream4.html', 'Eurosport HD', "https://i.imgur.com/yCgj02s.png", False, "playsupersportowo",isPlayable=True)	
	
	add_item('https://supersportowo.com/stream5.html', 'Eurosport 2 HD', "https://i.imgur.com/3IA1QAd.png", False, "playsupersportowo",isPlayable=True)	
	
	add_item('https://supersportowo.com/stream6.html', 'nSport+ HD', "https://i.imgur.com/GDTICof.png", False, "playsupersportowo",isPlayable=True)	
	
	add_item('https://supersportowo.com/stream7.html', 'TVP Sport HD', "https://i.imgur.com/A34dfve.png", False, "playsupersportowo",isPlayable=True)	
	
	add_item('https://supersportowo.com/stream8.html', 'Eleven Sports 1 HD', "https://i.imgur.com/6KvZtpg.png", False, "playsupersportowo",isPlayable=True)	
	
	add_item('https://supersportowo.com/stream9.html', 'Eleven Sports 2 HD', "https://i.imgur.com/yt3tfHm.png", False, "playsupersportowo",isPlayable=True)	
	
	add_item('https://supersportowo.com/stream10.html', 'Eleven Sports 3 HD', "https://i.imgur.com/FQkKANW.png", False, "playsupersportowo",isPlayable=True)	
	
	add_item('https://supersportowo.com/stream11.html', 'Polsat Sport HD', "https://i.imgur.com/VkY8zNV.png", False, "playsupersportowo",isPlayable=True)	
	
	xbmcplugin.setContent(addon_handle, 'videos')	
	xbmcplugin.endOfDirectory(addon_handle)	

def ustreamList():
	#out=[]
	newurl = params.get('url', None)
	html=scraper.get(newurl,verify=False).content
	
	result = parseDOM(html, 'div', attrs={'class': "container"})[0]
	links = parseDOM(html, 'p')
	for link in links:

		try:
			hrefnamestatus = re.findall("""href=['"](.+?)['"].+?>(.+?)<spa.+?['"]status_(.+?)['"]>""",link)
			href = hrefnamestatus[0][0]
			tyt = hrefnamestatus[0][1]
			stat = hrefnamestatus[0][2]

			if href.startswith('/embed'): href = 'https://ssl.ustreamix.com'+href#self.MAIN_URL + phUrl
			href = 'https://ssl.ustreamix.com'+href if href.startswith('/embed') else href
			add_item(href, tyt,'', False, 'playustreamix',infoLabels={'plot':tyt,'code':stat},isPlayable=True)	
		except:
			xbmc.log('Blad w : %s' % link, xbmc.LOGNOTICE)
	xbmcplugin.setContent(addon_handle, 'videos')
	xbmcplugin.endOfDirectory(addon_handle)

def getPolcastIpla():

	newurl = params.get('url', None)
	html=scraper.get(newurl,verify=False).content
	sc=''.join(['%s=%s;'%(c.name, c.value) for c in scraper.cookies])
	result = parseDOM(html, 'div', attrs={'class': "channels"})[0]
	links = parseDOM(result, 'li')
	for link in links:
	

	
		src = parseDOM(link, 'img', ret='src')[0]
		href = parseDOM(link, 'a', ret='href')[0]   
		title = parseDOM(link, 'a', ret='title')[0]  
		plot = parseDOM(link, 'p')
		plot = plot[0] if plot else title
		if href and title:
			if src.startswith('//'):
				src = 'https:'+urllib.quote(src)
			if href.startswith('play'):
				href = 'https://pol-cast.tk/ipla/'+href
			add_item(href, title, src+'|User-Agent='+urllib.quote(UA)+'&Cookie='+sc, False, 'playpolcast',infoLabels={'plot':plot})	
	xbmcplugin.endOfDirectory(addon_handle)
		
def PlayPolcast():

	newurl = params.get('url', None)
	html=scraper.get(newurl,verify=False).content
	sc=''.join(['%s=%s;'%(c.name, c.value) for c in scraper.cookies])

	aa = re.findall('sources: \[(.+?)\]',html,re.DOTALL)#[0].replace("\'",'"')
	stream = ''
	if aa:
		aa = aa[0].replace("\'",'"')

		stream = re.findall('src: "(.+?)"',aa)[0]
		if stream.startswith('//'):
			stream = 'https:'+stream+'|User-Agent='+urllib.quote(UA)+'&Referer='+newurl+'&Cookie='+urllib.quote(sc)
		if stream:
			play_item = xbmcgui.ListItem(path=stream)
			xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)	
		else:
			xbmcgui.Dialog().notification('[COLOR orangered][B]Błąd[/B][/COLOR]', '[COLOR orangered][B]Brak działającego streama[/B][/COLOR]', xbmcgui.NOTIFICATION_INFO, 5000)
		
	else:
		xbmcgui.Dialog().notification('[COLOR orangered][B]Błąd[/B][/COLOR]', '[COLOR orangered][B]Brak działającego streama[/B][/COLOR]', xbmcgui.NOTIFICATION_INFO, 5000)
		

def getZobaczws():
	url = params.get('url', None)
	newurl = params.get('url', None)
	html=scraper.get(newurl,verify=False).content
	links = parseDOM(html, 'ul', attrs={'class': "sub-menu"})
	for link in links:
		channels = parseDOM(link, 'li')#[0]
		for channel in channels:
			title = parseDOM(channel, 'a')[0]
			href = parseDOM(channel, 'a',ret='href')[0]
			add_item(href, title, '', False, 'playzobaczws')	
	xbmcplugin.endOfDirectory(addon_handle)	
	
def playZobaczws():
	url = params.get('url', None)
	newurl = params.get('url', None)
	html=scraper.get(newurl,verify=False).content
	stream=getTelerium(html,url)
	if stream:
		play_item = xbmcgui.ListItem(path=stream)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)	
	else:
		xbmcgui.Dialog().notification('[COLOR orangered][B]Błąd[/B][/COLOR]', '[COLOR orangered][B]Brak działającego streama[/B][/COLOR]', xbmcgui.NOTIFICATION_INFO, 5000)
		
def getEpg(url):
	headersok = {
	'User-Agent': UA,
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
	'Connection': 'keep-alive',
	'Upgrade-Insecure-Requests': '1',
	'TE': 'Trailers',}	
	html=requests.get(url,headers=headersok,verify=False).text	
	result = parseDOM(html, 'div', attrs={'class': "col-md-4"})[0]
	link = parseDOM(result, 'iframe', ret='src')[0]
	html=requests.get(link,headers=headersok,verify=False).text		
	xxx=re.findall('</i>(.+?)</span>(.+?)</h2>',html,re.DOTALL)
	tyt=''
	
	for czas,co in xxx:
		tyt+='%s %s[CR]'%(czas,co)
	return tyt.replace('&nbsp','')
	
def setUnblockKuk():	
	import uuid
	hash = uuid.uuid4().hex					
	aa='1679497221'
	kuk='__ddgu=%s.%s'%(hash,aa)		
	addon.setSetting('unbkuk',kuk)
	return kuk
	
def getTwojeTV():
	url = params.get('url', None)
	html=scraper.get(url,verify=False).text	
	sc=''.join(['%s=%s;'%(c.name, c.value) for c in scraper.cookies])
	links=parseDOM(html,'div', attrs={'class': "col-6 col-sm-12 col-lg-6"})
	for link in links:
		src = parseDOM(link, 'img', ret='src')[0]
		href = parseDOM(link, 'a', ret='href')[0]   
		title = parseDOM(link, 'a', ret='title')[0]  
		plot = parseDOM(link, 'p')
		plot = plot[0] if plot else ''
		if href and title:
			if src.startswith('//'):
				src = 'http:'+src
			if href.startswith('//'):
				href = 'http:'+href
			add_item(href, title, src+'|User-Agent='+urllib.quote(UA)+'&Cookie='+sc, False, 'playtwojetv',infoLabels={'plot':plot})	
	xbmcplugin.setContent(addon_handle, 'videos')
	xbmcplugin.endOfDirectory(addon_handle)			
def PlayTwojeTV():

	url = params.get('url', None)
	url = 'http:'+url if url.startswith('//') else url
	html=scraper.get(url,verify=False).text	
	result=parseDOM(html,'video', attrs={'id': "darmowo"})#[0]
	if result:
		try:
			link=parseDOM(result[0],'source', ret='src')[0]
		except:
			link=None
		if link:
			vidurl = 'http:'+link if link.startswith('//') else link
			vidurl = vidurl+'|User-Agent'+urllib.quote(UA)+'&Referer='+url if link else ''		
		
			if vidurl:
				play_item = xbmcgui.ListItem(path= vidurl)
				xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)		
		else:
			xbmcgui.Dialog().notification('[COLOR orangered][B]Błąd[/B][/COLOR]', '[COLOR orangered][B]Brak działającego streama[/B][/COLOR]', xbmcgui.NOTIFICATION_INFO, 5000)
			play_item = xbmcgui.ListItem(path='')
			xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)				
	else:
		xbmcgui.Dialog().notification('[COLOR orangered][B]Błąd[/B][/COLOR]', '[COLOR orangered][B]Darmowy odtwarzacz jest w tej chwili przeciążony[/B][/COLOR]', xbmcgui.NOTIFICATION_INFO, 5000)
		play_item = xbmcgui.ListItem(path='')
		xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)	
def getOlweb():
	url = params.get('url', None)
	headersok = {
	'User-Agent': UA,
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
	'Connection': 'keep-alive',
	'Upgrade-Insecure-Requests': '1',
	'TE': 'Trailers',}	
	html=requests.get(url,headers=headersok,verify=False).text	
	result = parseDOM(html, 'div', attrs={'class': "sigle mare"})[0]
	links=re.findall("""href="(.+?)"\s+title="(.+?)".+?mage:url\('(.+?)'""",result,re.DOTALL)
	
	for href,title,imag in links:	
		href = BASEURL4+href if href.startswith('/') else href
		imag = 'https:'+imag if imag.startswith('//') else imag	
		add_item(href, title, imag, False, 'playolweb')
		
	xbmcplugin.endOfDirectory(addon_handle)
	
def playOlweb():
	
	url = params.get('url', None)
	headersok = {
	'User-Agent': UA,
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
	'Connection': 'keep-alive',
	'Upgrade-Insecure-Requests': '1',
	'TE': 'Trailers',}	
	html=requests.get(url,headers=headersok,verify=False).text	
	
	iframes= parseDOM(html, 'iframe', ret='src')
	for iframe in iframes:
		if 'ustreamix.com' in iframe:
			break
		else:
			continue
	if 'ustreamix.com' in iframe:	
		playUstreamix(iframe)	
	else:
		xbmcgui.Dialog().notification('[COLOR orangered][B]Błąd[/B][/COLOR]', '[COLOR orangered][B]Brak działającego streama[/B][/COLOR]', xbmcgui.NOTIFICATION_INFO, 5000)

def getTelstream():

	url = params.get('url', None)
	headersok = {
	'User-Agent': UA,}	
	url = 'http://telewizjastreamer.com/telewizja-online/'
	html=requests.get(url,headers=headersok,verify=False).text	
	result = parseDOM(html, 'ul', attrs={'id': "main_header",'class':"main-header"})[0]
	results = parseDOM(result, 'ul', attrs={'class': "sub-menu"})
	for result in results:

		links = parseDOM(result, 'li') 
		
		for link in links:
			if 'Program Telewizyjny (EPG)' in link:
				continue

			nazw_main = ''

			try:
				tithref = re.findall('"([^"]+)".+?>([^>]+)</a>',link)[0]
			except:
				tithref = re.findall('"([^"]+)"\s*>([^>]+)</a>',link)[0]	
			add_item(tithref[0], tithref[1], '', False, 'playtelstream',infoLabels={'plot':tithref[1]})

	xbmcplugin.setContent(addon_handle, 'videos')
	xbmcplugin.endOfDirectory(addon_handle)

def playTelstream():
	url = params.get('url', None)
	headersok = {
	'User-Agent': UA,}	
	html=requests.get(url,headers=headersok,verify=False).text	
	result = parseDOM(html, 'div', attrs={'class': "wp-content"})[0]
	iframe=''
	try:
		iframe = re.findall('"application/x-mpegurl",src: "([^"]+)"',result)[0]
	except:
		iframe = parseDOM(result, 'iframe', ret='src')[0]
		headersok = {
		'User-Agent': UA,
		'Referer': url,}
		html=requests.get(iframe,headers=headersok,verify=False).text	
		iframe = parseDOM(html, 'iframe', ret='src')[0]
		iframe = iframe.replace('embed.html?true&token=','index.m3u8?token=')
	play_item = xbmcgui.ListItem(path=iframe)
	xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def getTelinter():
	add_item("https://telewizja-internetowa.pl/kategoria/4/dla-dzieci/","DLA DZIECI",'',True,'telinter2')
	add_item("https://telewizja-internetowa.pl/kategoria/8/filmowe/","FILMOWE",'',True,'telinter2')
	add_item("https://telewizja-internetowa.pl/kategoria/5/informacyjne/","INFORMACYJNE",'',True,'telinter2')
	add_item("https://telewizja-internetowa.pl/kategoria/3/muzyczne/","MUZYCZNE",'',True,'telinter2')
	add_item("https://telewizja-internetowa.pl/kategoria/6/naukowe/","NAUKOWE",'',True,'telinter2')
	add_item("https://telewizja-internetowa.pl/kategoria/9/ogolne/","OGÓLNE",'',True,'telinter2')
	add_item("https://telewizja-internetowa.pl/kategoria/7/sportowe/","SPORTOWE",'',True,'telinter2')
	xbmcplugin.setContent(addon_handle, 'videos')
	xbmcplugin.endOfDirectory(addon_handle)
		
def getTelinter2():
	url = params.get('url', None)
	html=scraper.get(url,verify=False).content
	my_cookies = requests.utils.dict_from_cookiejar(scraper.cookies)
	found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]
	kukz= ';'.join(found)		
	links = parseDOM(html, 'div', attrs={'class': "movie_l_all"})
	for link in links:
		href= parseDOM(link, 'a', ret='href')[0]
		href = 'https://telewizja-internetowa.pl/'+href
		tyt = parseDOM(link , 'div', attrs={'class': "movie_l_title"})[0]
		tit= parseDOM(tyt, 'a')[0]
		
		imag=parseDOM(link, 'img', ret='src')[0]
		imag = 'https://telewizja-internetowa.pl/'+imag
		add_item(href, tit, imag+'|User-Agent='+urllib.quote(UA)+'&Cookie='+urllib.quote(kukz), False, 'playtelinter')
	xbmcplugin.setContent(addon_handle, 'videos')
	xbmcplugin.endOfDirectory(addon_handle)

def PlayTelinter():
	newurl = params.get('url', None)
	html=scraper.get(newurl,verify=False).content
	stream_url=	decode(html,newurl)	
	if stream_url:
		play_item = xbmcgui.ListItem(path=stream_url)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
	
def playUstreamix(newurl):
	import jsunpack
	headers = {
		'Host': 'ssl.ustreamix.com',
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': newurl,
		'Upgrade-Insecure-Requests': '1',}	
	r = requests.get(newurl,verify=False)
	content=r.content
	next = re.compile("window.open\('(.*?)'").findall(content)
	if next:
		nxtu='https://ssl.ustreamix.com%s'%next[0]
		r = requests.get(nxtu,headers=headers,verify=False)	
		content=r.content
		packed = packer.findall(content)[0]
		unpacked = jsunpack.unpack(packed)		
		next2=re.findall('replace\("(.+?)"',unpacked,re.DOTALL)[0]
		headers2 = {
					'User-Agent': UA,
					'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
					'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
					'Referer': nxtu,
					'Connection': 'keep-alive',
					'Upgrade-Insecure-Requests': '1',
					'Cache-Control': 'max-age=0',}
		
		r = requests.get(next2,headers=headers2,verify=False)	
		content=r.content
		unpacked=''
		packeds = packer.findall(content)#[0]
		for packed in packeds:
			unpacked += jsunpack.unpack(packed)
		varhost=re.compile('var host_tmg="(.*?)"').findall(unpacked)
		varfname=re.compile('var file_name="(.*?)"').findall(unpacked)
		varjdtk=re.compile('var jdtk="(.*?)"').findall(unpacked)
		if varhost and varfname and varjdtk:
			stream_url = 'https://' + varhost[0] + '/' + varfname[0] + '?token=' + varjdtk[0] +'|User-Agent='+urllib.quote(UA)+'&Referer='+next2
			play_item = xbmcgui.ListItem(path=stream_url)
			xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)	
		else:
			xbmcgui.Dialog().notification('[COLOR orangered][B]Błąd[/B][/COLOR]', '[COLOR orangered][B]Brak działającego streama[/B][/COLOR]', xbmcgui.NOTIFICATION_INFO, 5000)
	
	else:
	
		xbmcgui.Dialog().notification('[COLOR orangered][B]Błąd[/B][/COLOR]', '[COLOR orangered][B]Brak działającego streama[/B][/COLOR]', xbmcgui.NOTIFICATION_INFO, 5000)

def getSwirtk():
	newurl = params.get('url', None)
	content=scraper.get(newurl,verify=False).text	
	sc=''.join(['%s=%s;'%(c.name, c.value) for c in scraper.cookies])
	links = parseDOM(content,  'li')
	for link in links:	
		
		url= parseDOM(link, 'a', ret='href')
		if url:
			url = url[0]
			title=parseDOM(link, 'a', ret='title')[0]
			image=parseDOM(link, 'img', ret='src')[0]
			image = 'http://tv-swirtvteam.tk/'+urllib.quote(image)+'|User-Agent='+urllib.quote(UA)+'&Referer='+urllib.quote('http://tv-swirtvteam.tk/')+'&Cookie='+urllib.quote(sc)
			add_item('http://tv-swirtvteam.tk/'+url, title, image, False,'playtvswir', isPlayable=False)
		else:
			continue
	xbmcplugin.setContent(addon_handle, 'videos')	
	xbmcplugin.endOfDirectory(addon_handle)	
	
		
def getTv2():
	newurl = params.get('url', None)
	content=scraper.get(newurl,verify=False).text	
	sc=''.join(['%s=%s;'%(c.name, c.value) for c in scraper.cookies])

	result=base64.b64decode(tvinternet)
	links = parseDOM(result,  'li')
	for link in links:	
		
		url= parseDOM(link, 'a', ret='href')[0]
		title=parseDOM(link, 'img', ret='alt')[0]
		image=parseDOM(link, 'img', ret='src')[0]
		image = 'https://darmowa-telewizja.online/'+image+'|User-Agent='+urllib.quote(UA)+'&Referer='+urllib.quote(darm)+'&Cookie='+urllib.quote(sc)
		add_item(darm+url, title, image, False, 'playtv2',isPlayable=True)
	xbmcplugin.setContent(addon_handle, 'videos')	
	xbmcplugin.endOfDirectory(addon_handle)	

def getTvManiak():
	deko=base64.b64decode(tvmaniak)
	results = parseDOM(deko, 'li')
	for link in results:	
		url= parseDOM(link, 'a', ret='href')[0]
		title=PLchar(parseDOM(link, 'a')[0])
		image=RESOURCES+'chan2.png'
		add_item(url, title, image, False, 'playtvmaniak')
	xbmcplugin.setContent(addon_handle, 'videos')
	xbmcplugin.endOfDirectory(addon_handle)	

	
	
def playtvswir():
	newurl = params.get('url', None)
	tytul = params.get('title', None)
	content=scraper.get(newurl,verify=False).content

	nturl= parseDOM(content, 'iframe', ret='src')#[0]
	if nturl:
	
		content=scraper.get(nturl[0],verify=False).content
	try:
	
		stream_url = clappr.findall(content)[0]

	except:
		stream_url = source.findall(content)[0]
	if stream_url:

		if stream_url.startswith('//'): stream_url = 'http:' + stream_url

		liz = xbmcgui.ListItem(label=tytul)
		liz.setProperty("IsPlayable", "true")
		stream_url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&url={0}&name={1}'.format(
			urllib.quote_plus(stream_url), urllib.quote_plus(tytul))
		liz.setPath(stream_url)
		try:
			xbmc.executebuiltin('RunPlugin(' + stream_url + ')')
		except BaseException:
			pass
	else:
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR] ','Brak działającego streama!!!')	

	
	
def playtv2():
	newurl = params.get('url', None)
	title = params.get('name', None)
	content=scraper.get(newurl,verify=False,timeout=30).content

	nturl= parseDOM(content, 'iframe', ret='src')#[0]
	if nturl:
		nturl=nturl[0]
		if nturl.startswith('//'): nturl = 'http:' + nturl
		if 'kastream' in nturl:
			pass
		else:
			content=scraper.get(nturl,verify=False,timeout=30).content
	#web_pdb.set_trace()
	try:
	
		stream_url = clappr.findall(content)[0]

	except:
		stream_url = source.findall(content)#[0]
		if stream_url:
			stream_url = stream_url[0]#:
		else:
			stream_url = decode(nturl,newurl)	
	if stream_url:
		origin = 'http://darmowa-telewizja.online'
		ref =nturl[0] if nturl else newurl
		headers44 = {
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36',
			'Accept': '*/*',
			'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
			'Origin': origin,
			'Connection': 'keep-alive',
			'Referer': ref,
		}	
		
		hea= '&'.join(['%s=%s' % (name, value) for (name, value) in headers44.items()])	
	
		if stream_url.startswith('//'): stream_url = 'http:' + stream_url
		liz = xbmcgui.ListItem(label=title)
		#	liz.setArt({"fanart": FANART, "icon": ICON})
		#	liz.setInfo(type="Video", infoLabels={"title": orig_title})
		liz.setProperty("IsPlayable", "true")
		#idle()
		#if my_addon.getSetting('play') == 'Inputstream':
		#stream_url = stream_url.replace('/i', '/index.m3u8') if stream_url.endswith('/i') else stream_url
		liz.setPath(stream_url)
		liz.setMimeType('application/vnd.apple.mpegurl')
		liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
		liz.setProperty('inputstream.adaptive.stream_headers', str(hea))



		try:

			ok = xbmcplugin.setResolvedUrl(addon_handle, True, liz)
			return ok
		except BaseException:
			pass
	
	else:
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR] ','Brak działającego streama!!!')	

def playTVmaniak():
	newurl = params.get('url', None)
	s.headers.update({
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'DNT': '1',
		'Connection': 'keep-alive',
		'Upgrade-Insecure-Requests': '1',})	
	check = s.get(base_link2)
	cf = cloudflare3x.Cloudflare(base_link2,check)
	cookies = {}
	verifyGet = ''
	if cf.is_cloudflare:
		authUrl = cf.get_url()
		makeAuth = s.get(authUrl)
		getCookies = s.get(base_link2)
		cookies = s.cookies.get_dict()	
	content = s.get(newurl, headers = s.headers, cookies = cookies).content		
	stream_url=	decode(content,newurl)	
	if stream_url:
		play_item = xbmcgui.ListItem(path=stream_url)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)	
	else:
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR] ','Brak działającego streama!!!')
		
def playSupersportowo():

	newurl = params.get('url', None)
	stream_url=''
	r = requests.get(
		newurl,
		verify=False)
	
	stream_url=	getWhostreams(r.content,newurl) #decode(r.content,newurl)
	if not stream_url:
		stream_url=	getNlive(r.content,newurl)
	if stream_url:
		play_item = xbmcgui.ListItem(path=stream_url)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)	
	else:
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR] ','Brak działającego streama!!!')
		
def NLheaders(ref):
	hea = {
		'Host': 'edge.nlive.club',
		'User-Agent': UA,
		'Accept': '*/*',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': ref,
		'Origin': 'https://nlive.club',
	}
	
	hed = ['%s=%s' % (name, value) for (name, value) in hea.items()]
	return '&'.join(hed)	
	
def getNlive(html, ref):
	embedd= parseDOM(html, 'iframe', ret='src')[0]
	header = {'User-Agent':UA,'Referer': ref, }	
	r = requests.get(embedd, headers=header,	verify=False)#.text
	header2 = {
		'User-Agent': UA,
		'Accept': 'application/json, text/javascript, */*; q=0.01',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': embedd,
		'X-Requested-With': 'XMLHttpRequest',
		'Connection': 'keep-alive',
		'Cache-Control': 'max-age=0',}	
	str=re.findall('curl = "(.+?)"',r.text,re.DOTALL)
	if str:
		token= requests.get('https://nlive.club/getToken.php', headers=header2,	cookies=r.cookies,verify=False).text
		token=re.findall('"token":"(.+?)"',token)#[0]	
	stream_url=''
	if token and str:
		hea=NLheaders(embedd)
		stream_url='%s%s|%s'%(str[0],token[0],hea)
	return stream_url


		
def playSawlive():
	newurl = params.get('url', None)
	headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': '*/*',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': newurl,
    'Connection': 'keep-alive',}

	content = requests.get(newurl,headers=headers,verify=False).content
	nexturl2 = re.compile('"text/javascript"\s+src="(.*?)"').findall(content)[0]
	headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': '*/*',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': newurl,
    'Connection': 'keep-alive',}		
	content = requests.get(nexturl2,headers=headers,verify=False).content
	decSawUrl=getDecodeSaw(content)
	str=	decode(decSawUrl,decSawUrl)
	if str:
		play_item = xbmcgui.ListItem(path=str)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)	
	else:
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR] ','Brak działającego streama!!!')	

def decode(content2,strona):
	#web_pdb.set_trace()
	if 'telerium' in content2:
		stream_url=getTelerium(content2,strona[0])
		return stream_url
		
	elif 'embed.twojetv.ws' in content2:
		stream_url=_twojetv(content2,strona)
		return stream_url		
	
	elif 'kastream.biz' in content2 or 'kastream.biz' in strona:
		stream_url=getKastream(content2,strona)
		return stream_url		
	elif 'tvmaniak.com/player2.php' in content2:
		stream_url=getManiakPlayer(content2,strona)
		return stream_url
	elif 'new Clappr.Player({' in content2:
		stream_url=getm3u8(content2,strona[0])
		return stream_url
	elif 'widestream.io' in content2:
		stream_url=getWidestream(content2,strona)
		return stream_url
	elif 'castto.me' in content2:
		stream_url=getCasttome(content2,strona[0])
		return stream_url
	elif 'emb.aliez.me' in content2:
		stream_url=getAliezme(content2,strona[0])
		return stream_url
	elif 'pxstream.tv' in content2:
		stream_url=getPxstream(content2,strona[0])
		return stream_url
	elif '123streams.co' in content2:
		stream_url=get123stream(content2,strona[0])
		return stream_url		
	elif 'tv4-poland' in content2:
		tv4url='https://ssl.ustreamix.com/stream.php?id=tv4-poland'
		stream_url=getTV4(tv4url)
		return stream_url	
	elif 'supersportowo' in content2:
		stream_url=getSupersportowo(content2,strona[0])
		return stream_url	
	elif 'polim-tv.blogspot' in content2:
		if 'tvmaniak' in strona:
			stream_url=getPolimblogspot(content2,strona)
		else:
			stream_url=getPolimblogspot(content2,strona[0])	
		return stream_url	
	elif 'tel-emporio.blogspot.com' in content2:
		if 'tvmaniak' in strona:
			stream_url=getTelemporio(content2,strona)
		else:
			stream_url=getTelemporio(content2,strona)	
		return stream_url	
	elif 'whostreams' in content2:
		if 'tvmaniak' in strona or 'darmowa-telewizja.online' in strona:
			stream_url=getWhostreams(content2,strona)	
		else:
			stream_url=getWhostreams(content2,strona[0])	
		return stream_url	
	elif 'wiz1.net' in content2:
		stream_url=getWiz1net(content2,strona[0])
		return stream_url	
	elif 'sawlive.tv' in content2:
		stream_url=getSawLive(content2,strona)
		return stream_url
	elif 'w.wlive.tv' in content2:
		stream_url=_wlivetv(content2,strona[0])
		return stream_url		
		
		
		
		
		
	return None

def getKastream(content2,strona):
	stream=''
	try:
		html=content2.replace("\'",'"')
		file=re.findall('file="(.+?)"; width="\d+"; height="\d+"',html)[0]
		url='http://kastream.biz/embed2.php?file=%s'%file
	except:
		url=content2
	headers = {
    'User-Agent': UA,
    'Accept': '*/*',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': strona,
    'Connection': 'keep-alive',}

	html = requests.get(url,headers=headers,verify=False,timeout=30).content	
	#web_pdb.set_trace()
	packed = packer.findall(html)[0]
	unpacked = jsunpack.unpack(packed)	
	str=re.findall('source:"(.+?)"',unpacked)
	if str:

		stream = 'http:'+str[0]+'|User-Agent='+UA+'&Referer='+strona
	return stream

def _twojetv(data,url):
	iframe=parseDOM(data, 'iframe', ret='src')[0]
	headers = {'User-Agent': UA,'Referer': url}	
	contentVideo=requests.get(iframe,headers=headers,verify=False).content
	vidurl=re.findall('source:\s+"(ht.+?.m3u8)"',contentVideo,re.DOTALL)#[0]
	vidurl = vidurl[0]+'|User-Agent'+urllib.quote(UA)+'&Referer='+iframe if vidurl else ''	
	return vidurl
	
	
	
def getManiakPlayer(content2,strona):

	iframe=parseDOM(content2, 'iframe', ret='src')[0]
	s.headers.update({'Referer': strona})
	content = s.get(iframe).content	
	stream=re.findall('file:"(.+?)"',content)[0]
	return stream
def getSawLive(content2,strona):

	headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': '*/*',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': 'http://www.sawlive.tv',
    'Connection': 'keep-alive',}

	result = requests.get(strona,headers=headers,verify=False).content
	unpacked = ''
	packed = result.split('\n')
	for i in packed:
		try:
			if 'unescape' in i:
				a=i
			if 'rtmp://' in i:
				rtm=i
			unpacked += jsunpack.unpack(i)
		except:
			pass

	varx = re.compile("'(.*?)'").findall(a)
	mem=varx[0]
	dod=varx[1].replace('n4n4n4n4','M')
	rtmp= re.compile('[\"](rtmp:.+?)[\"]').findall(rtm)[0]
	stream=rtmp+' playpath='+mem+'?'+dod+' swfUrl=http://static3.sawlive.tv/player.swf'+' pageUrl='+strona
	result += unpacked
	result = urllib.unquote_plus(result)
	var = re.compile('var\s(.+?)\s*=\s*[\'\"](.+?)[\'\"]').findall(result)
	rplcs = re.findall('dsss.=.(.*?).replace\([\"\'](.+?)[\"\']\s*,\s*[\"\']([^\"\']*)[\"\']',result) #;.+?=(.+?).replace\([\"\'](.+?)[\"\']\s*,\s*[\"\']([^\"\']*)[\"\']
	var_dict = dict(var)       
	file = re.compile(' "file":""(.+?)""').findall(result)[0]

	return stream	

	
def getTelerium(content2,strona):

	content2 = content2.replace("\'",'"')
	str=''
	embedd=''
	try:
		id = re.findall('javascript">id="(.+?)";',content2)

		embedd= "http://telerium.tv/embed/" + id[0] + ".html"
	except:		
		url = parseDOM(content2, 'iframe', ret='src')
		if url:
			embedd=url[0]
	if embedd:
		str=resolve(embedd,strona)
	return str
	
def getm3u8(content2,strona):
	m3u8playlist = re.compile('["\'](http.*?\\.m3u[8])["\']').findall(content2)
	if m3u8playlist:
		str = m3u8playlist[0]+'|User-Agent='+UA+'&Referer='+strona
	return str
	
def getDecodeSaw(content):
	mainsaw='http://www.sawlive.tv/embed/stream/'

	var = re.compile("""var\s+\w+\s+=\s*['"](.*?)['"]""").findall(content) #[0][1]
	print var

	vars=var[0].split(';')
	var1=vars[0]
	var2=vars[1]
	dec= mainsaw+var2+'/'+var1
	return dec
	
def getWiz1net(content2,strona):

	nexturl = parseDOM(content2, 'iframe',ret='src')
	headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': strona,
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
}

	content = requests.get(nexturl[0],headers=headers,verify=False).content	
	
	nexturl2 = re.compile('"text/javascript"\s+src="(.*?)"').findall(content)[0]
	headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': '*/*',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': nexturl[0],
    'Connection': 'keep-alive',}
	
	content = requests.get(nexturl2,headers=headers,verify=False).content
	decSawUrl=getDecodeSaw(content)
	str=	decode(decSawUrl,decSawUrl)
	return str
def getPolimblogspot(content2,strona):
	nexturl = parseDOM(content2, 'iframe',ret='src')
	content = requests.get(
		nexturl[0],
		verify=False).content		
	evalDecode=getDecodeEval(content)
	m3u8playlist = re.compile("""source:.["'](http.*?.m3u8.*?)["']""").findall(evalDecode)	
	if m3u8playlist:
		str = m3u8playlist[0]+'|User-Agent='+UA+'&Referer='+strona
	return str
	
def getTelemporio(content2,strona):	
	nexturl = parseDOM(content2, 'iframe',ret='src')
	content = requests.get(
		nexturl[0],
		verify=False).content
	try:
		evalDecode=getDecodeEval(content)
		stream_url=	decode(evalDecode,nexturl[0])
		return stream_url
	except:
		nexturls = parseDOM(content, 'a',ret='href')
		for nexturl2 in nexturls:
			if 'tel-emporio' in nexturl2:
				nexturl3=nexturl2
		content2 = requests.get(
			nexturl3,
			verify=False).content	
		evalDecode=getDecodeEval(content2)
		try:
			str_url=re.compile('[?](http[s].*?)"').findall(evalDecode)		
			if 'ustreamix' in str_url[0]:
				str=getTV4(str_url[0])
				return str
		except:
			str=	decode(evalDecode,nexturl3)
		return str
		
def decode_frame(s, splitconst, appendconst, offsetconst):
    r = ""
    tmp = s.split(splitconst)
    s = urllib.unquote(tmp[0])
    k = urllib.unquote(tmp[1]+appendconst)
    for i in range(0, len(s)):
        r = r + chr((int(k[i%len(k)]) ^ ord(s[i])) + offsetconst)
    return r	
	
def getDecodeEval(content):
	start = 0
	end = -1
	
	searcharea = content[start:]
	
	if searcharea.find("unescape('")!=-1:
		start = searcharea.find("unescape('")

		end = searcharea.find("')", start)
		encframe = searcharea[start+10:end]
		decframe = urllib.unquote(encframe)
		frame=decframe
	else:
		frame=searcharea
	
	if frame.__contains__('split("') and frame.__contains__("charCodeAt"):
		splitmatch = re.compile('split\("(.+?)"\);').findall(frame)
		appendmatch = re.compile('tmp\[1\].*?"(.+?)"').findall(frame)
		offsetmatch = re.compile('charCodeAt\(i\)\)\+(.+?)\)').findall(frame)
	
		payloadstart = searcharea.find("eval(unescape('")

		payloadstart = searcharea.find("unescape('", payloadstart+16)
		payloadstart = searcharea.find("'", payloadstart+11)
		payloadstart = searcharea.find("'", payloadstart+2)
		payloadend = searcharea.find("'", payloadstart+1)
		decframe = decode_frame(searcharea[payloadstart+1:payloadend], splitmatch[0], appendmatch[0], int(offsetmatch[0]))
		frame = decframe
	
	frame=frame.replace('\n', ' ').replace('\r', ' ')
	return frame
	
def getWidestream(content2,strona):
	nexturl = re.compile('iframe src="(.*?)"').findall(content2)
	r = requests.get(
		nexturl[0],
		verify=False)		
	m3u8playlist = re.compile('file:"(.*?)"').findall(r.content)
	if m3u8playlist:
		str = m3u8playlist[0]+'|User-Agent='+UA+'&Referer='+strona
	return str

def _wlivetv(data,url):
	
	video_url=''
	feed = re.compile('fid=["\'](.*?)["\']; v_width=(.*?); v_height=(.*?);').findall(data)
	if not feed:
		try:
			
			header = {'User-Agent':UA,'Referer': url}
			nxturl=re.findall('iframe src="(.+?)"',data)[0].replace('&amp;','&')
			contentVideo = requests.get(nxturl,headers=header).content
			pi = re.findall('return\\((.*?)\\);',contentVideo)
			#
			print pi
			pi=pi[0]
			if pi:
			
			
				join = re.findall('(\\[.*?\\]).join',pi)
				el_id = re.findall('(\\w+).join',pi)
				aa = re.findall('document.getElementById\\("(.*?)"',pi)
				if join:
					join = ''.join(eval(join[0])).replace('\\','')
				print join
				if el_id:
					tmp = re.findall('var %s\\s*=\\s*(\\[.*?\\])'%el_id[0],contentVideo)
					el_id = ''.join(eval(tmp[0])) if tmp else ''
				if aa:
					aa = re.findall('%s\\s*>(.*?)<'%aa[0],contentVideo)
					aa = aa[0] if aa else ''
					video_url = join + el_id + aa +'|User-Agent='+UA+'&Referer='+url
					video_url = 'https:'+video_url if video_url.startswith('//') else video_url
					
		except:
			pass
							
	else:
		
		header = {'User-Agent':UA,'Referer': url}
		if data.find('wlive.tv/embedra.js')>0:
			url_main='http://www.wlive.tv/embedra.php?player=desktop&live=%s&vw=660&vh=420'%feed[0][0]			
		else:
			url_main='http://www.wlive.tv/embedhd.php?player=desktop&live=%s&vw=660&vh=420'%feed[0][0]

		contentVideo = requests.get(url_main,headers=header).content
		
		pi = re.findall('return\\((.*?)\\);',contentVideo)
		pi=pi[0]
		if pi:		
			join = re.findall('(\\[.*?\\]).join',pi)
			el_id = re.findall('(\\w+).join',pi)
			aa = re.findall('document.getElementById\\("(.*?)"',pi)
			if join:
				join = ''.join(eval(join[0])).replace('\\','')
			if el_id:
				tmp = re.findall('var %s\\s*=\\s*(\\[.*?\\])'%el_id[0],contentVideo)
				el_id = ''.join(eval(tmp[0])) if tmp else ''
			if aa:
				aa = re.findall('%s\\s*>(.*?)<'%aa[0],contentVideo)
				aa = aa[0] if aa else ''
				video_url = join + el_id + aa +'|User-Agent='+UA+'&Referer='+url
	return video_url



	
def getCasttome(content2,strona):
	feed = re.compile('fid="(.*?)"; v_width=(.*?); v_height=(.*?);').findall(content2)
	if feed:
		url_main='http://static.castto.me/embedlivesrclappr.php?channel=%s&vw=%s&vh=%s'%feed[0]
	header = {'User-Agent':UA,
			'Referer': strona,
			'Host':'static.castto.me',
            }
	r = requests.get(
		url_main,
		headers=header,
		verify=False)
	file   = re.compile('file\\s*:\\s*["\'](.*?)[\'"]').findall(r.content)
	if file:
		str = file[-1]
	file   = re.compile('source\\s*:\\s*["\'](.*?)[\'"]').findall(r.content)
	if file:
		str = file[-1]
	file   = re.compile('<source src=["\'](.*?)[\'"]').findall(r.content)
	if file:
		str = file[-1]
	if str:
		str += '|User-Agent='+urllib.quote(UA)+'&Referer='+url_main+'&Cookie='+urllib.quote('userid=264414038;')
	return str	
	
def getAliezme(content2,strona):

	next_url = re.compile('src="(http://emb.aliez.me.*?)"').findall(content2)
	headers = {

		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Connection': 'keep-alive',
		'Upgrade-Insecure-Requests': '1',
		}
	r = requests.get(
		next_url[0],
		headers=headers,
		verify=False)

	cur=r.content
	str   = re.compile("""['"]*(http[^'^"]+?\.m3u8[^'^"]*?)['"]""").findall(r.content)
	str=str[0] +'|User-Agent='+UA+'&Referer='+next_url[0]  # '|User-Agent='+UA+'&Referer='+next_url[0] #' live=true swfVfy=1 swfUrl=http://i.aliez.me/swf/playernew.swf flashver=WIN\2024,0,0,221 pageUrl=' +next_url[0]
	if str:
		return str		
	else: return None
	
def getPxstream(content2,strona):	
	next_url = re.compile('src="(.*?)"').findall(content2)
	for url in next_url:
		if 'pxstream.tv' in url:
			pxurl=url
		else:
			continue
	header = {'User-Agent':UA,
		'Referer': strona,
		'Host':'pxstream.tv'}		
	r = requests.get(
		pxurl,
		headers=header,
		verify=False)
	a=r.content
	m3u8playlist = re.compile("""file:.['"](.*?)['"]""").findall(r.content)	
	if m3u8playlist:
		str = m3u8playlist[0]+'|User-Agent='+UA+'&Referer='+pxurl+'&X-Requested-With=ShockwaveFlash/24.0.0.186'	
		return str	
	else: return None
	
def getSupersportowo(content2,strona):

	next_url=re.compile("""(http://supersportowo.com/.*?)['"]""").findall(content2)
	r = requests.get(
		next_url[0],
		verify=False)
	content2=r.content
	if 'whostreams' in content2:
		stream_url=getWhostreams(content2,next_url[0])
	return stream_url

def getWhostreams(content2,strona):
	try:
		embedd= parseDOM(content2, 'iframe', ret='src')[0]
		header = {'User-Agent':UAiphone,'Referer': strona, }		
		page = requests.get(embedd, headers=header,	verify=False).text
		packed = packer.findall(page)[0]
		unpacked = jsunpack.unpack(packed)
		try:
			str = clappr.findall(unpacked)[0]
		except:
			str = source.findall(unpacked)[0]
		str += '|User-Agent={ua}&Referer={ref}'.format(ua=UAiphone, ref=embedd)
	except:
		str=''
	return str

def get123stream(content2,strona):
	feed = re.compile("""id=['"](.*?)['"]; width=['"](.*?)['"]; height=['"](.*?)['"];""").findall(content2)
	if feed:
		url_main='http://www.123streams.co/stream.php?id=%s&width=%s&height=%s&stretching=uniform'%feed[0]
	header = {'User-Agent':UA,
		'Referer': strona,
		'Host':'www.123streams.co'}		
	r = requests.get(
		url_main,
		headers=header,
		verify=False)		
	pi = re.findall('return\\((.*?)\\);',r.content)
	print pi
	pi=pi[2]
	if pi:
		join = re.findall('(\\[.*?\\]).join',pi)
		el_id = re.findall('(\\w+).join',pi)
		aa = re.findall('document.getElementById\\("(.*?)"',pi)
		if join:
			join = ''.join(eval(join[0])).replace('\\','')
		if el_id:
			tmp = re.findall('var %s\\s*=\\s*(\\[.*?\\])'%el_id[0],r.content)
			el_id = ''.join(eval(tmp[0])) if tmp else ''
		if aa:
			aa = re.findall('%s\\s*>(.*?)<'%aa[0],r.content)
			aa = aa[0] if aa else ''
		str = join + el_id + aa +'|User-Agent='+UA+'&Referer='+url_main		
	return str
	
def getTV4(tv4url):
	headers = {
		'Host': 'ssl.ustreamix.com',
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': tv4url,
		'Upgrade-Insecure-Requests': '1',}	
	r = requests.get(
		tv4url,
		verify=False)
	content=r.content
	next = re.compile("window.open\('(.*?)'").findall(content)
	r = requests.get(
		next[0],
		headers=headers,
		verify=False)	
	content=r.content
	headers2 = {
		'Host': 's.ustreamix.com',
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Upgrade-Insecure-Requests': '1',}	
	next2 = re.compile('url=(.*?)"').findall(content)
	r = requests.get(
		next2[0],
		headers=headers2,
		verify=False)	
	content=r.content
	packed = packer.findall(content)[0]
	unpacked = jsunpack.unpack(packed)
	varhost=re.compile('var host_tmg="(.*?)"').findall(unpacked)
	varfname=re.compile('var file_name="(.*?)"').findall(unpacked)
	varjdtk=re.compile('var jdtk="(.*?)"').findall(unpacked)
	stream_url = 'https://' + varhost[0] + '/' + varfname[0] + '?token=' + varjdtk[0] +'|Referer=' + next2[0]#;	
	return stream_url
	
def rev(a_string):
    return a_string[::-1]	

	
def resolve(embedd,stronka):
	resp = s.get(embedd, headers={'User-Agent':UA, 'Referer':stronka},verify=False,allow_redirects=False)#.content
	data=resp.content
	try:
		packed = packer.findall(data)[0]
	except:
		return ''
	
	unpacked = jsunpack.unpack(packed)	
	ab=unpacked
	pliki = (re.findall('doThePIayer\((.+?)\)',unpacked)[0]).split(',') 
	patern3	='var '+pliki[1]+'=window.atob\((.+?)\)'
	src6=re.compile(patern3).findall(unpacked)	
	patern6=src6[0]+'="(.*?)"'	
	
	src7=re.compile(patern6).findall(unpacked)	 #poprawny poczatek adresu
	d=src7[0]
	d1=base64.b64decode(d)	
	varNames = re.compile('url:window.atob\((.*?)\)\.slice\((\d+)\)\+window.atob\((.*?)\)')
	vars = varNames.findall(unpacked)[0]

	part1Reversed = re.compile('{0}\s*=\s*[\'\"](.+?)[\'\"];'.format(vars[0])).findall(unpacked)[0]
	part2Reversed = re.compile('{0}\s*=\s*[\'\"](.+?)[\'\"];'.format(vars[2])).findall(unpacked)[0]	
	part1 = (base64.b64decode(part1Reversed))[int(vars[1]):]
	part2 = base64.b64decode(part2Reversed) 
	
	obliczenia = re.findall('navigator.cookieEnabled\)\{(.+?);\$\.ajax',unpacked)[0]
	sppech = re.findall('var speechless=(.+?)([-+])(.+?)$',obliczenia)[0]
	reg1 = 'var '+sppech[0]+'=(.+?)([-+])(.+?);'
	reg2 = 'var '+sppech[2]+'=(.+?)([-+])(.+?);'
	ob1 =re.compile(reg1).findall(obliczenia)
	ob2 =re.compile(reg2).findall(obliczenia)
	ob11 = re.compile('var '+ob1[0][0]+'=(.+?);').findall(obliczenia)
	ob12 = re.compile('var '+ob1[0][2]+'=(.+?);').findall(obliczenia)
	
	ob21 = re.compile('var '+ob2[0][0]+'=(.+?);').findall(obliczenia)
	ob22 = re.compile('var '+ob2[0][2]+'=(.+?);').findall(obliczenia)
	
	
	obliczob1 = eval('%s%s%s'%(ob11[0],ob1[0][1],ob12[0]))
	obliczob2 = eval('%s%s%s'%(ob21[0],ob2[0][1],ob22[0]))
	spech = eval('%s%s%s'%(obliczob1,sppech[1],obliczob2))


	
	realtoken = getRealToken('https://telerium.tv'+part1+part2, embedd,spech)
	
	path = 'https:'+d1+realtoken
	
	path+='|User-Agent='+UA+'&Referer='+urllib.quote(embedd, safe='')+'&Sec-Fetch-Mode=cors&Origin=https://telerium.tv'
	
	
	#stream = 'https:{0}{1}|Referer={2}&User-Agent={3}&Origin=https://telerium.tv&Connection=keep-alive&Accept=*/*'
	#stream = stream.format(d1, realtoken, urllib.quote(embedd, safe=''), UA) 
	return path	

    
def getRealToken(link, referer,spech):
	cookies = {
		'ChorreameLaJa': '100',
		'setVolumeSize': '100',
		'NoldoTres': '100',
	}
	h = {
		'Host': 'telerium.tv',
		'User-Agent': UA,
		'Accept': 'application/json, text/javascript, */*; q=0.01',
		'Cookie': 'KodiamelaPiola=100;setVolumeSize=100;NoldoTres=100;ChorreameLaJa=100',
		
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': referer,
		'X-Requested-With': 'XMLHttpRequest',
	}

	realResp = s.get(link, headers=h,verify=False).content#[1:-1]
	realResp=re.findall('"(.+?)"',realResp)[spech]	
	return realResp[::-1]	
	
def PLchar(char):
    if type(char) is not str:
        char=char.encode('utf-8')
    char = char.replace('\xc4\x85','ą').replace('\xc4\x84','Ą')
    char = char.replace('\xc4\x87','ć').replace('\xc4\x86','Ć')
    char = char.replace('\xc4\x99','ę').replace('\xc4\x98','Ę')
    char = char.replace('\xc5\x82','ł').replace('\xc5\x81','Ł')
    char = char.replace('\xc5\x84','ń').replace('\xc5\x83','Ń')
    char = char.replace('\xc3\xb3','ó').replace('\xc3\x93','Ó')
    char = char.replace('\xc5\x9b','ś').replace('\xc5\x9a','Ś')
    char = char.replace('\xc5\xba','ź').replace('\xc5\xb9','Ź')
    char = char.replace('\xc5\xbc','ż').replace('\xc5\xbb','Ż')
    char = char.replace('&ndash;','-') #.replace('\xc4\x84','Ą')	
    char = char.replace('\xb3','l') #.replace('\xc4\x84','Ą')
	#&ndash;
    return char	
	
if __name__ == '__main__':
    mode = params.get('mode', None)
    if not mode:
        home()
    elif mode == 'tv2':
       getTv2()
    elif mode == 'olweb':
       getOlweb()	   
    elif mode == 'telstream':
       getTelstream()	 	   
    elif mode == 'playtelstream':
       playTelstream()	

    elif mode == 'telinter':
       getTelinter()	
    elif mode == 'telinter2':
       getTelinter2()	

 	   
    elif mode == 'playtelinter':
       PlayTelinter()	  
	   
	   
    elif mode == 'tvManiak':
       getTvManiak()	 	
    elif mode == 'sawlive':
       playSawlive()			   
    elif mode == 'playtv2':
        playtv2()
    elif mode == 'playtvinternetowa':
        playTVinternetowa()
    elif mode == 'playsupersportowo':
        playSupersportowo()
    elif mode == 'playtvru':
        playTVru()	
    elif mode == 'playtvmaniak':
        playTVmaniak()		
    elif mode == 'playolweb':
        playOlweb()			
    elif mode == 'playzobaczws':
        playZobaczws()			
    elif mode == 'supersport':
        getSuperSport()	
    elif mode == 'twojetv':
        getTwojeTV()		
    elif mode == 'playtwojetv':
        PlayTwojeTV()		
    elif mode == 'zobaczws':
       getZobaczws()
    elif mode == 'polcastipla':
       getPolcastIpla()
    elif mode == 'playpolcast':
       PlayPolcast()
    elif mode == 'swirtk':
       getSwirtk()
    elif mode == 'playtvswir':
       playtvswir()
    elif mode == 'ustreamlist':
       ustreamList()
    elif mode == 'playustreamix':
       playUstreamix(ex_link) 

	   