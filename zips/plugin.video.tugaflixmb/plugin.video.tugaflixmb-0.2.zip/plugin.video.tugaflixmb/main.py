# -*- coding: UTF-8 -*-
from __future__ import division
import sys,re,os
import six
from six.moves import urllib_parse

import requests
from requests.compat import urlparse

import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc, xbmcvfs
from resources.lib.brotlipython import brotlidec

if six.PY3:
    basestring = str
    unicode = str
    xrange = range
    from resources.lib.cmf3 import parseDOM
else:
    from resources.lib.cmf2 import parseDOM
import resolveurl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(urllib_parse.parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.tugaflixmb')

PATH            = addon.getAddonInfo('path')
if six.PY2:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
else:
    DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'../fanart.jpg'
ikona =RESOURCES+'../icon.png'

exlink = params.get('url', None)
nazwa= params.get('title', None)
rys = params.get('image', None)

page = params.get('page',[1])

UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0'
TIMEOUT=15
proxyport = addon.getSetting('proxyport')
playt = addon.getSetting('play')
headers = {'User-Agent': UA,}
sess = requests.Session()
wybor = addon.getSetting('subs')
wybor = addon.setSetting('subs', 'NO') if not wybor else wybor
def build_url(query):
    return base_url + '?' + urllib_parse.urlencode(query)

def add_item(url, name, image, mode, itemcount=1, page=1,fanart=FANART, infoLabels=False,contextmenu=None,IsPlayable=False, folder=False):
    list_item = xbmcgui.ListItem(label=name)
    if IsPlayable:
        list_item.setProperty("IsPlayable", 'True')    
    if not infoLabels:
        infoLabels={'title': name}    
    list_item.setInfo(type="video", infoLabels=infoLabels)    
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': fanart})
    
    if contextmenu:
        out=contextmenu
        list_item.addContextMenuItems(out, replaceItems=True)

    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url = build_url({'mode': mode, 'url' : url, 'page' : page, 'title':name,'image':image}),            
        listitem=list_item,
        isFolder=folder)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def home():

    add_item('film', '[COLOR khaki][B]Filmes[/COLOR][/B]', ikona, "menu",fanart=FANART, folder=True)
    add_item('series', '[COLOR khaki][B]Series[/COLOR][/B]', ikona, "menu",fanart=FANART, folder=True)
	
def menu(typ):
	if 'film' in typ:
		add_item('https://tugaflix.best/filmes/page/1/', '[COLOR khaki][B]Pesquisar - filmes[/COLOR][/B]', ikona, "search",fanart=FANART, folder=True)
		add_item('https://tugaflix.best/filmes/page/1', '[COLOR khaki][B]Filmes[/COLOR][/B]', ikona, "listmovies",fanart=FANART, folder=True)
		add_item('https://tugaflix.best/filmes/!ano', '[COLOR khaki][B]Filmes - ano[/COLOR][/B]', ikona, "listsubmenu",fanart=FANART, folder=True)
		add_item('https://tugaflix.best/filmes/!genero', '[COLOR khaki][B]Filmes - genero[/COLOR][/B]', ikona, "listsubmenu",fanart=FANART, folder=True)
		add_item('https://tugaflix.best/filmes/!pais', '[COLOR khaki][B]Filmes - pais[/COLOR][/B]', ikona, "listsubmenu",fanart=FANART, folder=True)
	else:	
		add_item('https://tugaflix.best/series/page/1/', '[COLOR khaki][B]Pesquisar - series[/COLOR][/B]', ikona, "search",fanart=FANART, folder=True)
		add_item('https://tugaflix.best/series/page/1', '[COLOR khaki][B]Series[/COLOR][/B]', ikona, "listmovies",fanart=FANART, folder=True)
		add_item('https://tugaflix.best/series/!ano', '[COLOR khaki][B]Series - ano[/COLOR][/B]', ikona, "listsubmenu",fanart=FANART, folder=True)
		add_item('https://tugaflix.best/series/!genero', '[COLOR khaki][B]Series - genero[/COLOR][/B]', ikona, "listsubmenu",fanart=FANART, folder=True)
		add_item('https://tugaflix.best/series/!pais', '[COLOR khaki][B]Series - pais[/COLOR][/B]', ikona, "listsubmenu",fanart=FANART, folder=True)
	xbmcplugin.endOfDirectory(addon_handle) 
	
def submenu(typ):

	url,cos = typ.split('!')

	html = sess.get(url, headers = headers, verify=False).text
	
	
	
	ispla = False
	fold = True
	mod = 'listmovies'

	part = re.findall(cos+'<\/button>(.*?)<\/div',html,re.DOTALL+re.I)[0]
	if 'ano' in cos:
		zxc = re.findall('href\s*=\s*"([^"]+)"\s*>([^<]+)<\/a>',part,re.DOTALL+re.I)[::-1]
	else:
		zxc = re.findall('href\s*=\s*"([^"]+)"\s*>([^<]+)<\/a>',part,re.DOTALL+re.I)
	for x,z in zxc:#re.findall('href\s*=\s*"([^"]+)"\s*>([^<]+)<\/a>',part,re.DOTALL+re.I):
	
		add_item(x+'page/1', z, ikona, mod,fanart=FANART, folder=fold, IsPlayable=ispla, infoLabels={'plot':z})
		acv=''
	xbmcplugin.endOfDirectory(addon_handle) 
	
	
	
	
def ListMovies(url, pg):

	if '/page/' in url:
		url = re.sub('/page/\\d+','/page/%d'%int(pg),url)
	else:
		url = url + '/page/%d' %int(pg)	
	html = sess.get(url, headers = headers, verify=False).text
	ntpage = re.sub('/page/\\d+','/page/%d'%(int(pg)+1),url)

	result = parseDOM(html,'div', attrs={'class':"items"} )[0]
	
	
	links = parseDOM(html,'div', attrs={'class':"poster"} )

	for link in links:
	
		href = parseDOM(link,'a', ret="href")[0]
		title = parseDOM(link,'a', ret="title")[0]
		href = 'https://tugaflix.best'+href if href.startswith('/') else href
	

		img = parseDOM(link,'img', ret="src")#[0]
		if len(img)>1:
			try:
				img = [img[1]]
			except:
				img = ['']

		try:

			img = ikona if img[0] == '' else img[0]
		except:
			img = ikona

		ispla = False
		fold = True
		mod = 'listlinks'
		h2 = href+'|'+title
		if '/series/' in href or '/tvano/' in href or '/tvgenre/' in href or 'tvcountry' in href:
			ispla = False
			fold = True
			mod = 'listserial'
			h2 = href
		add_item(h2, title, img, mod,fanart=FANART, folder=fold, IsPlayable=ispla, infoLabels={'plot':title})
	
	
	npag = ntpage+'/'
	ab = html.find(npag)>0
	ab2 = html.find(ntpage)>0
	if '/?s=' in ntpage:
		npag = ntpage

	if ab or ab2:

		nextpage = unicode(int(pg)+1)
		add_item(ntpage, '>> next page >>' ,RESOURCES+'right.png', "listmovies",fanart=FANART, page=nextpage, folder=True)
	xbmcplugin.endOfDirectory(addon_handle) 
	
def ListSerial(url):

	html = sess.get(url, headers = headers, verify=False).text
	dat = parseDOM(html,'div', attrs={'class':"movie-details"} )[0]

	img_main = parseDOM(dat,'img', ret="src")[0]
	orig_title = parseDOM(dat,'h3')[0]
	opis = parseDOM(html,'div', attrs={'class':"sinopse"} )
	plot = orig_title
	if opis:
		plot = re.sub("<[^>]*>","",opis[0]).replace('\n','[CR]')
	
	seasons = parseDOM(html,'form', attrs={'method':"post"} )
	out=[]
	for season in seasons:

		ses = re.findall('S(\d+)E\d+',season,re.DOTALL)[0]
		episodes =re.findall('name\s*=\s*"([^"]+)"',season,re.DOTALL)

		for episode in episodes:
			epis = re.findall('S\d+E(\d+)',episode,re.DOTALL+re.I)[0] 

			jaki = ' - S%02dE%02d '%(int(ses),int(epis))
				
			tyt = orig_title+jaki
			out.append({'title':tyt,'href':episode+'|'+url,'img':img_main, 'fnrt':FANART, 'plot':plot, 'season' : int(ses),'episode' : int(epis) })
	sezony =  splitToSeasons(out)

	for i in sorted(sezony.keys()):
		ac=urllib_parse.quote_plus(str(sezony[i]))
		add_item(ac, i, img_main, 'listepisodes',fanart=FANART, folder=True, IsPlayable=False, infoLabels={'plot':plot})
	xbmcplugin.endOfDirectory(addon_handle) 
		
		
def ListEpisodes(exlink):
	import ast

	episodes = ast.literal_eval(urllib_parse.unquote_plus(exlink))
	
	itemz=episodes
	items = len(episodes)
	
	for f in itemz:

		add_item(f.get('href')+'***'+f.get('title'), f.get('title'), f.get('img'), 'listlinks',fanart=FANART, folder=True, IsPlayable=False, infoLabels={'plot':f.get('plot')})
	xbmcplugin.endOfDirectory(addon_handle) 
def splitToSeasons(input):
	out={}
	seasons = [x.get('season') for x in input]

	xx= re.findall('^(.*?)\-',input[0].get('title', None))[0]
	for s in set(seasons):

		out[xx+ ' Season %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
	return out
	
def ListLinks(urlk):
	wybor = addon.getSetting('subs')
	playt = str(addon.getSetting('play'))
	add_item('xxxx', '===== playing: [COLOR khaki]%s[/COLOR] ====='%(playt), ikona, 'sett',fanart=FANART, folder=False, IsPlayable=False)
	url,tyt = urlk.split('|')	
	if '***' in tyt:
		url2,tyt =  tyt.split('***')
	headers = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Content-Type': 'application/x-www-form-urlencoded',
		'Origin': 'https://tugaflix.best',
		'Connection': 'keep-alive',
		'Referer': url,
		'Upgrade-Insecure-Requests': '1',
		'Sec-Fetch-Dest': 'document',
		'Sec-Fetch-Mode': 'navigate',
		'Sec-Fetch-Site': 'same-origin',
		'Sec-Fetch-User': '?1',
	}
	if 'http' in url:
		data = {
			'play': '',
		}
	else:
		data = {
			url: '',
		}
		url = url2

	response = sess.post(url, headers=headers, data=data).text
	html = response.replace("\'",'"')
	opis = parseDOM(html,'div', attrs={'class':"sinopse"} )
	plot = tyt
	if opis:
		plot = re.sub("<[^>]*>","",opis[0]).replace('\n','[CR]')
	img = parseDOM(html,'img', ret="src")
	try:
		img = ikona if img[0] == '' else img[0]
	except:
		img = ikona
	
	if '/series/' in url:
		iframe = parseDOM(html,'iframe', ret="src")[0]
		iframe = 'https:'+iframe if iframe.startswith('//') else iframe
		data = {
			'submit': '',
		}
		response = sess.post(iframe, headers=headers, data=data).text
		players = parseDOM(response,'iframe', ret="src")
		tit = tyt
	else:
		players = re.findall('"player"\s*href\s*=\s*"([^"]+)"',html,re.DOTALL+re.I)
	l = 1
	ok = False
	mod = 'playvideo' 
	ispla = True
	fold = False

	add_item(name="[COLOR gold]Subtitles if available:[/COLOR] [B]"+wybor+"[/B]", url='xx', mode='settx', image=ikona, folder=False, infoLabels={'plot':'tugaflix'}, IsPlayable=False)

	for player in players:
		ok = True
		x=''
		tit = tyt+' - [I]link '+str(l)+'[/I]'
		player = 'https:'+player if player.startswith('//') else player
		add_item(player, tit, img, mod,fanart=FANART, folder=fold, IsPlayable=ispla, infoLabels={'plot':plot})#, 'year':year, 'duration':duration})
		l+=1
	if ok:
		xbmcplugin.endOfDirectory(addon_handle) 

	else:
		xbmcgui.Dialog().notification('[B]Info[/B]', 'Links are not available',xbmcgui.NOTIFICATION_INFO, 6000)
		
def PlayVideo(url):	

	link = None
	subt = None

	try:
		link = resolveurl.resolve(url)
	except:
		link=None
	if not link:
		if 'gdplayer.to' in url:
			link, subt = Resolve_Neo(url=url, ref=url)
		else:
			html = sess.get(url, headers = headers, verify=False).text
			hrefs = re.findall('href\s*=\s*"([^"]+)"', html,re.DOTALL)
			v= [i for i, s in enumerate(hrefs) if '.srt' in s]
			subt = hrefs[v[0]] if v else None

			iframe = parseDOM(html,'iframe', ret="src")#[0]
			if iframe:
				try:
					link = resolveurl.resolve(iframe[-1])
				except:
					link=''
				if 'ninjastream.' in iframe[-1]:
					link = Resolve_ninja(url=iframe[-1], ref=url)
				elif 'neohd' in iframe[-1] or 'ninjahd' in iframe[-1]:
					if not link:
						link,subt = Resolve_Neo(url=iframe[-1], ref=url)
		
	if link:
		video_url = link
		if pla():
			video_url = link
		else:
			if '|' in link:
				link = link.split('|')[0]
			video_url = 'http://127.0.0.1:{port}/dd='.format(port=proxyport)+link
		
		play_item = xbmcgui.ListItem(path=video_url)#
		if subt:
			play_item.setSubtitles([subt])
		#play_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
		#play_item.setProperty('inputstream.ffmpegdirect.mime_type', 'video/mp4')
		#play_item.setContentLookup(False)

		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
def pla():
	#tt=True
	if addon.getSetting('play') == 'default':
		return True
	else:
		return False
	
def Resolve_Neo(url,ref)	:
	#from resolveurl by gujal
	#neohd plugin
	subt = None
	import json
	import codecs
	import time
	from resources.lib.jscrypto import jscrypto
	headers.update({'Referer': ref})
	zz=''
	response = sess.get(url, headers = headers, verify=False)
	cookies=dict(response.cookies)
	html = response.text
	r = re.search(r"var\s*playerConfig\s*=\s*({.*?})", html)  #will be updated
	host = urlparse(url).netloc
	if r:
		data = json.loads(r.group(1))
		ct = data.get('ct', False)
		salt = codecs.decode(data.get('s'), 'hex')
		html2 = jscrypto.decode(ct, 'F1r3b4Ll_GDP~5H', salt)
		html2 = html2[1:-1].replace('\\"', '"').replace('\\\\', '\\').replace('\\\\/','/')	
		s = re.search(r'apiQuery":"([^"]+)', html2)
		s2 = re.search(r'apiURL":"([^"]+)', html2)
		if s or s2:
			murl = 'https://{0}/'.format(host)
			if s2:
				host = s2.group(1)
				s = re.search(r'kaken\s*=\s*"([^"]+)', html)
				murl = host
			headers.update({'Referer': url, 'X-Requested-With': 'XMLHttpRequest'})
			aurl = '{0}api/?{1}&_={2}'.format(murl, s.group(1), int(time.time() * 1000))
			jd = sess.get(aurl, headers=headers).json()
			try:
				subt = jd.get('query', None).get('sub', None)
			except:
				subt = None
			try:
				subt2 = jd.get('tracks', None)[0].get('file', None)
			except:
				subt2 = None
			if subt:
				subt = subt[0]
			elif subt2:
				subt = subt2
			urlk = jd.get('sources')[0].get('file').replace(' ', '%20')
			if urlk.startswith('//'):
				urlk = 'https:' + urlk
			link = urlk+'|User-Agent='+UA+'&Referer='+url
	return link, subt

	
def Resolve_ninja(url,ref):
	headers.update({'Referer': ref})
	zz=''
	response = sess.get(url, headers = headers, verify=False)
	cookies=dict(response.cookies)
	html = response.text

	csrf = re.findall('csrf\-token"\s*content\s*=\s*"([^"]+)"',html,re.DOTALL)[0]
	xsrf = cookies.get('XSRF-TOKEN', None)

	headersx = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
		'Accept': 'application/json, text/plain, */*',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': url,
		'X-Requested-With': 'XMLHttpRequest',
		'X-CSRF-TOKEN': csrf,		'Content-Type': 'application/json;charset=utf-8',
		'X-XSRF-TOKEN': xsrf,
		'Origin': 'https://ninjastream.to',
		'DNT': '1',
		'Connection': 'keep-alive',
		'Sec-Fetch-Dest': 'empty',
		'Sec-Fetch-Mode': 'cors',
		'Sec-Fetch-Site': 'same-origin',
	}
	id_ = url.split('/')[-1]

	data = {'id':id_}

	html = sess.post('https://ninjastream.to/api/video/get', cookies=sess.cookies, headers=headersx, json=data).json()
	link = html.get('result', None).get('playlist', None)
	link = link+'|User-Agent='+UA+'&Referer='+url
	return link

def router(paramstring):
	params = dict(urllib_parse.parse_qsl(paramstring))
	if params:    
	
		mode = params.get('mode', None)
	
		if mode == 'listmovies':
			ListMovies(exlink, page)	
		elif mode == 'menu':
			menu(exlink)
		elif mode == 'listsubmenu':
			submenu(exlink)
			
			
		elif mode == 'playvideo':
			PlayVideo(exlink)
		elif mode == 'listserial':
			ListSerial(exlink)
		elif mode == 'listlinks':
			ListLinks(exlink)
			
			
		elif mode == 'listepisodes':
			ListEpisodes(exlink)
		elif mode == 'search':
			query = xbmcgui.Dialog().input(u'Pesquisar: ', type=xbmcgui.INPUT_ALPHANUM)
			if query:   
				k=exlink+'?s='+query.replace(' ','+')
				ListMovies(k, '1')
			
		elif mode == 'sett':
			addon.setSetting('play', 'default') if playt == 'proxy' else addon.setSetting('play', 'proxy')
			xbmc.executebuiltin('Container.Refresh')
		elif mode == 'settx':
			addon.setSetting('subs', 'NO') if wybor == 'YES' else addon.setSetting('subs', 'YES')
			xbmc.executebuiltin('Container.Refresh')	
	else:
		home()
		xbmcplugin.endOfDirectory(addon_handle)    
if __name__ == '__main__':
    router(sys.argv[2][1:])