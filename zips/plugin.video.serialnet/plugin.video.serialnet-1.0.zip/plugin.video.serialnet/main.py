# -*- coding: UTF-8 -*-
import sys,re,os
import urlparse
from urlparse import parse_qsl
import base64
import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.serialnet')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=PATH+'fanart.jpg'
blad=RESOURCES+'error.png'
packer = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)')

sys.path.append( os.path.join( RESOURCES, "lib" ) )
import jsunpack
exlink = params.get('url', None)
name= params.get('title', None)
page = params.get('page',[1])[0]

main_url="https://serialnet.pl"
s = requests.Session()
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0'}

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=1):
	list_item = xbmcgui.ListItem(label=name)

	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')
		
	if not infoLabels:
		infoLabels={'title': name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	
def home():
	add_item('https://serialnet.pl/|ostat', 'Ostatnio dodane', RESOURCES+'Filmy.png', True, "poldod")	
	add_item('https://serialnet.pl/|polec', 'Polecane', RESOURCES+'Filmy.png', True, "poldod")		
	add_item('https://serialnet.pl/', 'Spis seriali', RESOURCES+'Filmy.png', True, "listspis")			
	add_item('', '[COLOR lightblue]Szukaj[/COLOR]', '', True, "search")		
	xbmcplugin.endOfDirectory(addon_handle)
def getUrlReq(url):
	content=s.get(url,headers=headers, verify=False).text	
	return content	
def ListPoldod(exlink):		
	links = getPoldod(exlink)
	itemz=links
	if itemz:
		items = len(links)
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='listSerials', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)			
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)		
	
def getPoldod(url):	
	url,typ = url.split('|')
	html=getUrlReq(url)
	out=[]
	if 'ostat' in typ:
		result=parseDOM(html,'div', attrs={'class': "bx"})[1]	
		links= parseDOM(result, 'div', attrs={'class': "item"})
		for link in links:
			href= parseDOM(link, 'a', ret='href')[0]
			imag= parseDOM(link, 'img', ret='src')[0]
			title= parseDOM(link, 'p')
			out.append({'title':title[0]+' - '+title[1],'href':href,'img':imag})		
	else:
		result=parseDOM(html,'div', attrs={'class': "bx"})[0]		
		links= parseDOM(result, 'div', attrs={'class': "item"}) 
		for link in links:
			href= parseDOM(link, 'a', ret='href')[0]
			imag= parseDOM(link, 'img', ret='src')[0]
			title= parseDOM(link, 'img', ret='title')[0]
			out.append({'title':title,'href':href,'img':imag})
	return out
	
def ListSerials(exlink):	
	links= getSerials(exlink)
	itemz=links
	items = len(links)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listEpisodes', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)		
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)		
def getSerials(url):	
	html=getUrlReq(url)
	out=[]
	result2=parseDOM(html,'div', attrs={'id': "colTwo"})[0]	#<div class="panel-body">	
	plot = parseDOM(result2, 'strong')[0]
	imag= parseDOM(result2, 'img', ret='src')[0]
	title = parseDOM(result2, 'h2')[0]
	links= parseDOM(result2, 'h3') #<ul class="mov_list">
	
	for link in links:
		href= link
		out.append({'title':title+' - '+href,'href':href+'|'+url,'img':imag,'plot':plot})		
	return out	
	
def ListEpisodes(exlink):	
	links= getEpisodes(exlink)
	itemz=links
	items = len(links)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)		
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)	
	
def getEpisodes(url):	
	sez,url = url.split('|')
	sez=re.findall('(\d+)',sez)[0]
	html=getUrlReq(url)
	out=[]
	result2=parseDOM(html,'div', attrs={'id': "colTwo"})[0]	#<div class="panel-body">	
	result=parseDOM(result2,'div', attrs={'id': "wrp1"})[0]
	plot = parseDOM(result2, 'strong')[0]
	imag= parseDOM(result2, 'img', ret='src')[0]
	links= parseDOM(result, 'a', ret='href')
	sezon='sezon-'+sez
	for link in links:
		if sezon in link:
			href=link
			odc=re.findall('odcinek-(\d+)',href)[0]

			out.append({'title':'Sezon:'+sez+' - Odcinek '+odc,'href':href,'img':imag,'plot':plot})		
	return out		
def getLinks(ex_link):
		link = getVideosOk(exlink)
		if link:
			xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=link))
		else:
			xbmcgui.Dialog().notification('Ups...', 'Wystąpił błąd. Prawdopodobnie brak linków.', blad, 6000)
			xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
			
def getVideosOk(url):
	html=getUrlReq(url)	
	out=[]
	link=parseDOM(html,'iframe', ret='src')#[0]
	
	if link:
		page=getUrlReq(link[0])	
		try:
			packed = packer.findall(page)[0]
			unpacked = (jsunpack.unpack(packed)).decode('string_escape')
			tx=re.findall("db91\('(.+?)'\)",unpacked)[0]
			decode = tx.decode('string_escape')
			link=(base64.b64decode(decode)).replace('\/','/')
		except:
			link=''	
			
	return link	
	
def ListSearch(query):	
	links= getSearch(query)
	itemz=links
	items = len(links)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listSerials', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)		
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)	
	
def getSearch(query):
	html=getUrlReq(main_url)	
	out=[]
	match = re.compile('<li><a href="https://serialnet.pl(/serial-online/.+?)">(.+?)(?:<p>(.+?)</p>)?</a>').findall(html)
	print match[0][0]
	if len(match) > 0:
		for i in range(len(match)):
			if query.lower() in match[i][2].lower() or query.lower() in match[i][1].lower():
				if match[i][2] != '':
					title = match[i][2].strip()
				else:
					title = match[i][1].strip()
				out.append({'title':title,'href':main_url + match[i][0]})		
	return out	

def ListSpis(exlink):	
	links= getSpis(exlink)
	itemz=links
	items = len(links)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listSerials', image='', folder=True, infoLabels=f, itemcount=items)		
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)		
	
def getSpis(url):
	html=getUrlReq(url)	
	out=[]
	result=parseDOM(html,'ul', attrs={'id': "list"})[0]
	links= parseDOM(result, 'li')	
	
	for link in links:	
		href= parseDOM(link, 'a', ret='href')[0]
		href=re.findall('(https.+?/.+?/.+?/.+?/)',href)[0]
		title= parseDOM(link, 'a')[0]
		try:
			titlepl= parseDOM(link, 'p')[0]
		except:
			titlepl=None
		if titlepl is not None:
			title=titlepl.strip()+' / '+title.strip()	
		out.append({'title':title,'href':href})	
		
	return out	

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86') #E9
	char = char.replace('\\u00e9','\xc3\xa9').replace('\\u00C9','\xc3\x89') #E9	
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&nbsp;',".").replace('&amp;','&')
	return char	

if __name__ == '__main__':
	mode = params.get('mode', None)
	if not mode:
		home()	
	elif mode == 'poldod':
		ListPoldod(exlink)		
	elif mode == 'listSerials':
		ListSerials(exlink)
	elif mode == 'listEpisodes':
		ListEpisodes(exlink)
	elif mode == 'listspis':
		ListSpis(exlink)			
	elif mode == 'getLinks':
		getLinks(exlink)					
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Szukaj, Czego szukasz', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			ListSearch(query)		
xbmcplugin.endOfDirectory(addon_handle)
