# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl

import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import resolveurl as urlresolver

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.videopenny')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=PATH+'fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('title', None)
page = params.get('page',[1])[0]

UAx='Mozilla/5.0 (Linux; Android 7.0; PLUS Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36'
UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'
TIMEOUT=15

headers = {'User-Agent': UA,}
s = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=1):
	list_item = xbmcgui.ListItem(label=name)

	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')
		
	if not infoLabels:
		infoLabels={'title': name,'plot':name}
	list_item.setInfo(type="video", infoLabels=infoLabels)		
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	
def home():
	add_item('https://videopenny.net/kategoria-2/seriale-pol', 'Seriale', RESOURCES+'Seriale.png', True, "listmovies")
	add_item('https://videopenny.net/kategoria-2/filmy-pol', 'Filmy', RESOURCES+'Filmy.png', True, "listmovies")	
	add_item('https://videopenny.net/kategoria-2/bajki_pol', 'Bajki', RESOURCES+'Bajki.png', True, "listmovies")
	add_item('https://videopenny.net/kategoria-2/programy-rozrywkowe_pol', 'Programy', RESOURCES+'Programy.png', True, "listmovies")
	add_item('https://videopenny.net/ostatnio-dodane', 'Ostatnio dodane', '', True, "listmovies")	
	add_item('', '[COLOR lightblue]Szukaj[/COLOR]', '', True, "search")		

def ListMovies(exlink,page):
	page = int(page) if page else 1	
	links,pagin = getMovies(exlink,page)
	if pagin[0]:
		add_item(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[0])	
	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)							
	if pagin[1]:
		add_item(name='[COLOR blue]>> Nastepna strona >>>[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[1])
	xbmcplugin.setContent(addon_handle, 'videos')		
def getUrlReq(url):
	content=s.get(url, headers=headers,verify=False).text	
	return content
	
def getMovies(url,page=1):
	if page>1:
		url = url + '/page/%d' %page	
	else:
		url=url		
	html=getUrlReq(url)
	out=[]
	serout=[]
	if 'ostatnio-dodane' in url:
		links = parseDOM(html, 'div', attrs={'class': "col-md-2 col-sm-6 col-xs-6"})  #	
		prevpage=False #gr=False
		nextpage=False  # pr=False	
		if html.find('class="nextpostslink"')>0:
			nextpage = page+1
		for link in links:
			imag= (parseDOM(link, 'img', ret='src')[0]).replace('-130x73','')
			title= parseDOM(link, 'a',ret='title')[0]    
			href = parseDOM(link, 'a', ret='href')[0]
			plot = ''
			out.append({'title':PLchar(title),'href':href,'img':imag,'plot':plot})		
	else:
		links = parseDOM(html, 'div', attrs={'class': "col-md-3 col-sm-6 col-xs-6 "})  #
		prevpage=False #gr=False
		nextpage=False  # pr=False	
		if html.find('class="nextpostslink"')>0:
			nextpage = page+1
		for link in links:
			dotyt = parseDOM(link, 'h3') [0]  
			imag= parseDOM(link, 'img', ret='src')[0]
			title= parseDOM(dotyt, 'a',ret='title')[0]    
			href = parseDOM(link, 'a', ret='href')[0]
			plot = parseDOM(link, 'p')[0]	
			out.append({'title':PLchar(title),'href':href,'img':imag,'plot':PLchar(plot)})
	prevpage = page-1 if page>1 else False
	return (out,(prevpage,nextpage))

def getRodzinne(url):
	r = s.get(url=url, headers=headers, allow_redirects=False,verify=False)	
	strm = r.headers['Location']
	return strm

def getLinks(exlink):
	links=getVideosOk(exlink)
	if len(links)>1:
		linksAllb = [x.get('host') for x in links]
		s = xbmcgui.Dialog().select('Linki',linksAllb)	
	else:
		s=0
	if s>-1:	
		hrefs=links[s].get('href') if s>-1 else ''
		host=links[s].get('host') if s>-1 else ''	
		if 'rodzinnekino.com' in hrefs:	
			stream=getRodzinne(hrefs)
		else:
			stream=hrefs
		try:
			stream_url = urlresolver.resolve(stream)
		except Exception,e:
				stream_url=''
				s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link bedzie działał?','ERROR: %s'%str(e))	
		if stream_url:	
			play_item = xbmcgui.ListItem(path=stream_url)
			xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
		else:
			play_item = xbmcgui.ListItem(path='')
			xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)
	else:
		quit()
	
def getVideosOk(url):
	html=getUrlReq(url)	
	results = parseDOM(html, 'div', attrs={'role': "main"})[0]   #table table-bordered
	results2 = parseDOM(html, 'table', attrs={'class': "table table-bordered"})[0]
	hosts = parseDOM(results2.replace('<i class="fa fa-play"></i>',''), 'a')   #<i class="fa fa-play"></i>''
	resultaty = parseDOM(results, 'div', attrs={'style': "display:none;"})[0]
	hrefs=re.findall('src="(.+?)"',resultaty)
	co=0
	out=[]
	for host in hosts:
		host=host.replace(' (reklamy)','')
		film = {'href' : hrefs[co],'host' : host,}
		out.append(film)
		co+=1
	return out

def ListSearch(exlink,page):
	page = int(page) if page else 1	
	links,pagin = getSearch(exlink,page)
	if pagin[0]:
		add_item(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__S', image='', folder=True, page=pagin[0])	
	itemz=links
	items = len(links)
	for f in itemz:
		mud='getLinks'
		fold=False
		ilab = f
		
		if '/kategoria-2/seriale-pol/' in f.get('href'):
			mud = "listmovies"
			fold = True
			ilab = False
			
		add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, infoLabels=ilab, itemcount=items)							
	if pagin[1]:
		add_item(name='[COLOR blue]>> Nastepna strona >>>[/COLOR]', url=exlink, mode='__page__S', image='', folder=True, page=pagin[1])
	xbmcplugin.setContent(addon_handle, 'videos')		
def getSearch(quer,page=1):
	url = 'https://videopenny.net/page/%d' %page +quer	
	
	html=getUrlReq(url)
	out=[]
	serout=[]	
	if html:
		links = parseDOM(html, 'div', attrs={'id': "post\-[\d\-]\d+"})  #
		prevpage=False #gr=False
		nextpage=False  # pr=False	
		if html.find('class="nextpostslink"')>0:
			nextpage = page+1
		for link in links:
			dotyt = parseDOM(link, 'h3') [0]  
			imag= parseDOM(link, 'img', ret='src')#[0]
			if imag:
				imag = imag[0]
			else:
				imag=''
			title= parseDOM(dotyt, 'a',ret='title')[0]    
			href = parseDOM(link, 'a', ret='href')[0]
			plot = parseDOM(link, 'p')#[0]	
			if plot:
				plot = plot[0]
			else:
				plot=''
			out.append({'title':PLchar(title),'href':href,'img':imag,'plot':PLchar(plot)})
	prevpage = page-1 if page>1 else False
	return (out,(prevpage,nextpage))	
	
def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	return char	

if __name__ == '__main__':
	mode = params.get('mode', None)
	if not mode:
		home()
		xbmcplugin.endOfDirectory(addon_handle)
	elif mode == 'listmovies':
		ListMovies(exlink,page)
		xbmcplugin.setContent(addon_handle, 'movies')
		xbmcplugin.endOfDirectory(addon_handle)
	elif mode == 'getLinks':
		getLinks(exlink)	
	elif mode == 'listserials':
		ListSerials(exlink,page)
		xbmcplugin.setContent(addon_handle, 'movies')
		xbmcplugin.endOfDirectory(addon_handle)
	elif mode == 'gatunek':
		data = getGatunek(exlink)
		par= exlink.split('|')
		if data:
			label = [x[0].strip() for x in data]
			url = [x[1].strip() for x in data]
			s = xbmcgui.Dialog().select('Wybierz '+par[0],label)
			if s>-1:
				url = build_url({'mode': 'listmovies', 'foldername': name, 'url' : url[s]})
				xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)	
		xbmcplugin.endOfDirectory(addon_handle)				
	elif mode == '__page__M':
		url = build_url({'mode': 'listmovies', 'foldername': name, 'url' : exlink, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
		xbmcplugin.endOfDirectory(addon_handle)
	elif mode == '__page__S'	:
		url = build_url({'mode': 'listsearch', 'foldername': name, 'url' : exlink, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)		
		xbmcplugin.endOfDirectory(addon_handle)
	elif mode=='listsearch':	
		ListSearch(exlink,page)
		xbmcplugin.endOfDirectory(addon_handle)
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			ListSearch('?s=%s'%query,1)
			xbmcplugin.setContent(addon_handle, 'movies')
		xbmcplugin.endOfDirectory(addon_handle)
