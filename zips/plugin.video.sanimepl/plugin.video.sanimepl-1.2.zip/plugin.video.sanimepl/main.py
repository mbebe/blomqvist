# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import urllib
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import urlparse
import resolveurl
import json
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.sanimepl')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART = xbmc.translatePath( os.path.join( PATH, 'fanart.jpg' ) )
ikona = RESOURCES+'rrrr.png'
npikona= RESOURCES+'npage.png'
lupe = RESOURCES+'lupe.png'

sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('name', None)
page = params.get('page','')
scount= params.get('scount', None)
rys= params.get('image', None)

UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'
TIMEOUT=15
MAIN_URL='https://superanime.pl/'
s = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False,itemcount=1, page=1,fanart=FANART,scount=0):
	list_item = xbmcgui.ListItem(label=name)

	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')
	if not infoLabels:
		infoLabels={'title': name,'plot':name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	art_keys = ['thumb','poster','banner','fanart','icon','clearart','landscape']
	art = dict(zip(art_keys,[image for x in art_keys]))
	art['landscape'] = fanart if fanart else art['landscape']
	art['fanart'] = fanart if fanart else art['landscape']
	list_item.setArt(art)
	if 'Następna strona' not in infoLabels.get('title',''):
		isp = []
		isp.append(('Informacja', 'XBMC.Action(Info)'),)
		list_item.addContextMenuItems(isp, replaceItems=True)
	
	
	ok=xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page,'name':name,'image':image,'scount':scount}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%P, %Y")
	return ok

def home():
	add_item('blue', '[B][COLOR lightblue]Nowości - Anime[/COLOR][/B]', ikona, "listmainpage", folder=True,fanart=FANART)
	add_item('orange', '[B][COLOR lightblue]Nowości - Ecchi[/COLOR][/B]', ikona, "listmainpage", folder=True,fanart=FANART)
	add_item('green', '[B][COLOR lightblue]Nowości - Drama[/COLOR][/B]', ikona, "listmainpage", folder=True,fanart=FANART)
	add_item('blue', '[B][COLOR lightblue]Nowości - Filmy[/COLOR][/B]', ikona, "listmainpage", folder=True,fanart=FANART)
	add_item('anime', '[B][COLOR khaki]Kategorie - Anime[/COLOR][/B]', ikona, "kateg", folder=True,fanart=FANART)
	add_item('drama', '[B][COLOR khaki]Kategorie - Drama[/COLOR][/B]', ikona, "kateg", folder=True)
	add_item('filmy', '[B][COLOR khaki]Kategorie - Filmy[/COLOR][/B]', ikona, "kateg", folder=True)
	add_item(' ', '[B][COLOR pink]Szukaj[/COLOR][/B]', lupe, "search", folder=True)

def getRequests(url,data={},ref=None):
	headers = {
		'User-Agent': UA,
		'Accept': 'text/html, */*; q=0.01',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Connection': 'keep-alive',}
	if data:
		headers = {
			'User-Agent': UA,
			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
			'Referer': 'https://superanime.pl/index.php?do=search',
			'Content-Type': 'application/x-www-form-urlencoded',
			'Connection': 'keep-alive',
			'Upgrade-Insecure-Requests': '1',
		}

		content=s.post(url,headers=headers,data=data,verify=False).content
	else:
		if ref:
			ab=s.get(ref,headers=headers)
			headersx = {
				'User-Agent': UA,
				'Accept': 'text/html, */*; q=0.01',
				'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
				'Referer': ref,
				'X-Requested-With': 'XMLHttpRequest',
				'Connection': 'keep-alive',
				'TE': 'Trailers',
			}
			headers=headersx
		
		content=s.get(url,headers=headers,cookies=s.cookies).content
	return content

def ListMainPage(id):
	links=getMainPage(id)
	itemz=links
	items = len(links)
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=True, IsPlayable=False, infoLabels=f, itemcount=items)		
	xbmcplugin.endOfDirectory(addon_handle)	
	
def getMainPage(id):
	html=getRequests(MAIN_URL)	
	out=[]
	result = parseDOM(html, 'div', attrs={'class': "owl-cat owl-%s"%id})[0]
	if ' - Filmy' in name:
		result = parseDOM(html, 'div', attrs={'class': "owl-cat owl-%s"%id})[1]
	links = parseDOM(result, 'div', attrs={'class': "shortstory-in"})#[0]
	for link in links:
		href = parseDOM(link, 'a', ret='href')[0]
		imag = parseDOM(link, 'img', ret='src')[0]
		tyt = parseDOM(link, 'a', ret='title')[0]
		code=''
		codes=parseDOM(link,'span', attrs={'class': "film-rip"})#[0]
		if codes:
			code =parseDOM(codes[0],'a')
			code = [i.title() for i in code]
			if code == []: code = ' '
			code = ' / '.join(code)
		out.append({'title':PLchar(tyt),'href':href,'img':imag,'code':code,'plot':PLchar(tyt)})
	return out	

def getLinks(url):

	html=getRequests(url)
	out=[]
	dane = parseDOM(html, 'div', attrs={'id': "fstory-film"})[0]
	plot = re.findall('"fstory-content margin-b40 block-p">([^>]+)<',html)
	if plot:
		plot = plot[0].strip()
	else:
		plot=''
		
	imgs = parseDOM(dane, 'div', attrs={'class': "fstory-poster"})[0]
	imag  = parseDOM(imgs, 'img', ret='src')[0]
	
	year=''
	genre=''
	code=''

	codes = parseDOM(imgs, 'span', attrs={'class': "film-rip"})
	if codes:
		code = parseDOM(codes[0],'a')
		code = [i.title() for i in code]
		if code == []: code = ' '
		code = ', '.join(code)
	
	finfo_blocks = parseDOM(dane, 'div', attrs={'class': "finfo-block"})

	for finfo in finfo_blocks:
		if 'rok' in finfo.lower():
			year = parseDOM(finfo, 'div', attrs={'class': "finfo-text"})[0]
		elif 'gatunek' in finfo.lower():
			genres = parseDOM(finfo, 'div', attrs={'class': "finfo-text"})[0]
			genre = parseDOM(genres,'a')
			genre = [i.title() for i in genre]
			if genre == []: genre = ' '
			genre = ', '.join(genre)
	if html.find('<div id="full-video">')>0:
		progress = xbmcgui.DialogProgress()

		progress.create('Wyszukuje')
		progress.update(20, "", 'Wczytuje linki', "")
		result = parseDOM(html, 'div', attrs={'id': "full-video"})[0]
		result2= json.loads(re.findall('var players\s*=\s*(\[.+?\])',result)[0])
		for x in result2:
			href = re.findall("""iframe src=['"](.+?)['"]""",x['code'])[0]
			host = urlparse.urlparse(href).netloc
			tyt1 = PLchar(name)
			host1 = PLchar(host)
			tyt = '%s - [COLOR blue](%s)[/COLOR]'%(tyt1,host1)
			out.append({'title':PLchar(tyt),'href':href,'img':imag,'code':code,'genre':genre,'year':year,'plot':PLchar(plot)})
		items = len(out)
		fold=False
		for f in out:
			add_item(name=f.get('title'), url=f.get('href'), mode='playVids', image=f.get('img'), folder=False, IsPlayable=True, infoLabels=f, itemcount=items)	
		xbmc.sleep(1500)
		progress.update(100, "", "", "")
		xbmc.sleep(1000)
		progress.close()
		xbmcplugin.setContent(addon_handle, 'videos')	
	else:
		result = parseDOM(html, 'div', attrs={'class': "fstory-content margin-b40 block-p"})[1]
		hreftit=re.findall('a href="([^"]+)"><div class="green-box">(.+?)</center>',result,re.DOTALL)
		for href,tyt in hreftit:
			tyt = re.findall('<p>(.+?)</p>',tyt)[0]
			href = 'https://superanime.pl'+href if href.startswith('/') else href
			tyt = tyt.replace('</b>',' - ').replace('<b>','')
			out.append({'title':PLchar(tyt),'href':href,'img':imag,'code':code,'genre':genre,'year':year,'plot':PLchar(plot)})
		items = len(out)
		fold=False
		for f in out:
			add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=True, IsPlayable=False, infoLabels=f, itemcount=items)		
	xbmcplugin.endOfDirectory(addon_handle)	

def PlayVids(exlink):
	try:
		stream_url = resolveurl.resolve(exlink)
		
	except Exception,e:
		stream_url=''
		list_item = xbmcgui.ListItem(path=None)
	
		xbmc.executebuiltin('Notification(Problem, ' + str(e) + ', 1200)')
		quit()

	if stream_url:
		list_item = xbmcgui.ListItem(path=stream_url)
		return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)
		
def ListKateg(exlink,page):
	links, pagin=getListKateg(exlink,page)
	itemz=links
	items = len(links)
	if items>0:

		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=True, infoLabels=f , itemcount=items, IsPlayable=False)	
		if pagin:
			for f in pagin:	
				add_item(name=f.get('title'), url=f.get('href'), mode='listcateg', image=npikona, folder=True,page=f.get('page'))	
		xbmcplugin.endOfDirectory(addon_handle)	
	else:
		xbmc.executebuiltin('Notification(Info, ' + 'Brak materiałów do wyświetlenia' + ', 1200)')
		
def getListKateg(url,page):
	page = int(page)
	if  'page/' in url:
		url = re.sub(r'\/page/\d+', '/page/%d'%page,   url)  
	else:
		url = url+'/page/%d'%page
	html=getRequests(url)
	out=[]
	npout=[]

	nxtpag=int(page)+1
	if html.find('/page/%d/"><i class="fa fa-angle-right">'%nxtpag)>0:
		npout.append({'title':'Następna strona','href':url,'img':'','plot':'','page':page+1}) 
	result = parseDOM(html, 'div', attrs={'id': "dle-content"})[0]
	links = parseDOM(result, 'div', attrs={'class': "shortstory radius-3"})
	for link in links:
		href = parseDOM(link, 'a', ret='href')[0]
		imag = parseDOM(link, 'img', ret='src')[0]
		tyt = parseDOM(link, 'a', ret='title')[0]
		code=''
		codes=parseDOM(link,'span', attrs={'class': "film-rip"})#[0]
		if codes:
			code =parseDOM(codes[0],'a')
			code = [i.title() for i in code]
			if code == []: code = ' '
			code = ' / '.join(code)
		out.append({'title':PLchar(tyt),'href':PLchar(href),'img':imag,'code':PLchar(code),'plot':PLchar(tyt)})
		
	return out,npout

def ListSearch(query):
	data = {
	'do': 'search',
	'subaction': 'search',
	'search_start': page,
	'full_search': '0',
	'result_from': scount,
	'story': query
	}
	url='https://superanime.pl/index.php?do=search'
	
	out=[]
	npout=[]
	html=getRequests(url,data)
	result = parseDOM(html, 'div', attrs={'id': "dle-content"})[0]
	links = parseDOM(result, 'div', attrs={'class': "shortstory radius-3"})
	co=1
	for link in links:
		href = parseDOM(link, 'a', ret='href')[0]
		imag = parseDOM(link, 'img', ret='src')[0]
		tyt = parseDOM(link, 'a', ret='title')[0]
		code=''
		codes=parseDOM(link,'span', attrs={'class': "film-rip"})#[0]
		if codes:
			code =parseDOM(codes[0],'a')
			code = [i.title() for i in code]
			if code == []: code = ' '
			code = ' / '.join(code)
		out.append({'title':PLchar(tyt),'href':PLchar(href),'img':imag,'code':PLchar(code),'plot':PLchar(tyt)})
		co+=1
	if html.find('href="#"><i class="fa fa-angle-right">')>0:
		npout.append({'title':'Następna strona','href':'','img':npikona,'plot':'','page':int(page)+1}) 

	items = len(out)

	for f in out:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=True, infoLabels=f , itemcount=items, IsPlayable=False)	
	if npout:
		for f in npout:	
			add_item(name=f.get('title'), url=query, mode='listSearch', image=npikona, folder=True,page=f.get('page'),scount=co)
	xbmcplugin.endOfDirectory(addon_handle)			
		
def getSearch(d):
	data = {'search': d,'wyslij_szuk': 'Szukaj filmu'}
	url='https://www.filmy321.pl/pokaz_film'

	out=[]
	html=getRequests(url,data)
	links = parseDOM(html, 'div', attrs={'class': "movie_info"})

	for link in links:
		href = parseDOM(link, 'a', ret='href')[0]
		imag = parseDOM(link, 'img', ret='src')[0]
		tyt = (re.findall('class="movie_infot">([^>]+)<br',link)[0]).strip()
		cod = parseDOM(link, 'strong')[0]

		href = MAIN_URL+href if href.startswith('/') else href
		imag = MAIN_URL+imag if imag.startswith('/') else imag
		out.append({'title':PLchar(tyt),'href':href,'img':imag,'code':cod,'plot':PLchar(tyt)})
	return out

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&#039;',"'")
	char = char.replace('&quot;','"')
	char = char.replace('&nbsp;',".").replace('&amp;','&').replace('&prime;',"'")
	return char	
	
if __name__ == '__main__':
	mode = params.get('mode', None)
	
	if not mode:
		home()
		xbmcplugin.endOfDirectory(addon_handle)		
		
	elif mode == 'listmainpage':
		ListMainPage(exlink)	
	
	elif mode == 'listSearch':
		ListSearch(exlink)	
		
	elif mode == 'listcateg':
		ListKateg(exlink,page)

	elif mode =='getLinks':
		getLinks(exlink)
		
	elif mode =='kateg':
		if 'anime' in exlink:
			value=['/sztuki-walki', '/akcja', '/cyberpunk', '/parodia', '/thriller', '/vampiry', '/komedia', '/shoujo', '/szkola', '/wojskowe', '/sensacyjne', '/fikcja', '/melodramat', '/fantasy', '/przygodowe', '/mistyczne', '/psychologiczne', '/sportowe', '/historyczne', '/muzykalne', '/romans', '/horror', '/steampunk', '/space-opera', '/okruchy-zycia', '/seinen', '/shounen', '/josei', '/duchy', '/youkai', '/kodomo', '/samurajowie', '/dramat', '/nadprzyrodzone', '/super-moce', '/kryminal', '/tajemnicze', '/harem', '/sci-fiction', '/yuri', '/yaoi', '/ecchi', '/wspolczesnosc', '/hentai', '/serie']
			label=["Sztuki Walki","Akcja","Cyberpunk","Parodia","Thriller","Vampiry","Komedia","Shoujo","SzkołA","Wojskowe","Sensacyjne","Fikcja","Melodramat","Fantasy","Przygodowe","Mistyczne","Psychologiczne","Sportowe","Historyczne","Muzykalne","Romans","Horror","Steampunk","Space Opera","Okruchy żYcia","Seinen","Shounen","Josei","Duchy","Youkai","Kodomo","Samurajowie","Dramat","Nadprzyrodzone","Super Moce"," Kryminał"," Tajemnicze"," Harem"," Sci-Fiction"," Yuri"," Yaoi"," Ecchi"," WspółCzesność","Hentai","Serie Anime"]

		elif 'drama' in exlink:
			value=['/drama/japonska', '/drama/koreanska', '/drama/pozostale', '/serie-drama']
			label=["Japońska","Koreańska","Pozostałe","Serie Drama"]
			
		elif 'film' in exlink:
			value=['/filmy-pelnometrazowe/japonskie','/filmy-pelnometrazowe/koreanskie','/filmy-pelnometrazowe/pozostale']
			label=['Japonskie','Koreanskie','Pozostale']

		msg = 'Kategorie %s:'%exlink
		sel = xbmcgui.Dialog().select(msg,label)
		if sel>-1:
			href='https://superanime.pl'+value[sel]
			ListKateg(href,1)

	elif 'playVids' in mode:
		PlayVids(exlink)
		
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
		if query:  
			ListSearch(query)
