# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import urlparse
import urllib
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc

import string
from CommonFunctions import parseDOM
from CommonFunctions import replaceHTMLCodes
import cookielib

import random
import time
reload(sys)
sys.setdefaultencoding('utf8')
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.sportpremium')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
COOKIEFILE = os.path.join(DATAPATH,'canalplus.cookie')

RESOURCES       = PATH+'/resources/'
FANART=PATH+'fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('title', None)
opisy= params.get('plot', None)
imig=params.get('image', None)

sess=requests.Session()
sess.cookies = cookielib.LWPCookieJar(COOKIEFILE)
UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0'

auth_url='https://b2c-www.redefine.pl/rpc/auth/'
navigate_url='https://b2c-www.redefine.pl/rpc/navigation/'

clid = addon.getSetting('clientId')
devid = addon.getSetting('devid')

stoken = addon.getSetting('sesstoken')
sexpir = addon.getSetting('sessexpir')
skey = addon.getSetting('sesskey')





def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            # Must be encoded in UTF-8
            v.decode('utf8')
        out_dict[k] = v
    return out_dict
    
def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))

	
def add_item(url, name, image, folder, mode,  isPlayable=True, infoLabels=False, FANART=None,itemcount=1, page=1):

	list_item = xbmcgui.ListItem(label=name)	
		
	if isPlayable:
		list_item.setProperty("IsPlayable", 'true')

	else:
		list_item.setProperty("IsPlayable", 'false')
		
	if not infoLabels:
		infoLabels={'title': name,'plot':name}

	list_item.setInfo(type="video", infoLabels=infoLabels)

	FANART = FANART if FANART else image
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': FANART})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,	
		url = build_url({'title':name,'mode': mode, 'url' : url, 'page' : page,'plot':infoLabels}),	
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")


def home():
	add_item(name='CANAL+ Sport', url='', mode="canallist", image=RESOURCES+'cpo.png', folder=True, FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg')	
	add_item(name='ElevenSports', url='', mode="elevenlist", image=RESOURCES+'es.png', folder=True, FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg')	

	xbmcplugin.endOfDirectory(addon_handle)
def homeEleven():
	loginEleven()

def homeCanal():
	login()
	
	#add_item(name='Na żywo', url='https://canalplussport.pl', mode="listnazywo", image='https://canalplussport.pl/Content/images/icon__watch-live.png', folder=True, FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg')	
	#add_item(name='Magazyny PKO BP Ekstraklasa', url='https://canalplussport.pl/magazyn/ekstraklasa', mode="listmagazyny", image='https://ncplus-sport.img.rd.insyscd.net/online-liga-14092019-25028665/p20.jpg', folder=True, FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg')	
	xbmcplugin.endOfDirectory(addon_handle)
	
	
def newtime(ff):
	from datetime import datetime
	ff=re.sub(':\d+Z','',ff)
	dd=re.findall('T(\d+)',ff)[0]
	dzien=re.findall('(\d+)T',ff)[0]
	dd='{:>02d}'.format(int(dd)+2)
	if dd=='24':
		dd='00'
		dzien='{:>02d}'.format(int(dzien)+1)
	if dd=='25':
		dd='01'
		dzien='{:>02d}'.format(int(dzien)+1)

	ff=re.sub('(\d+)T(\d+)','%sT%s'%(dzien,int(dd)),ff)
	format_date = datetime.strptime(ff, '%Y-%m-%dT%H:%M')

	dd= int('{:0}'.format(int(time.mktime(format_date.timetuple()))))
	return dd,format_date	
	
def getEpg2():
	import datetime 
	now = datetime.datetime.now()
	now2 = datetime.datetime.now()+ datetime.timedelta(days=1)

	aa=now2.strftime('%Y-%m-%dT%H:%M:%S') + ('.%03dZ' % (now.microsecond / 10000))



	headers = {
			'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
		'Accept': 'application/json, text/plain, */*',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Content-Type': 'text/plain',
		'Origin': 'https://www.elevensports.pl',
		'DNT': '1',
		'Connection': 'keep-alive',
		'Referer': 'https://www.elevensports.pl/',
	}
	data={"id":1,"jsonrpc":"2.0","method":"getChannelsProgram","params":{"userAgentData":{"portal":"eleven","deviceType":"pc","application":"firefox","os":"windows","build":1},"channelIds":["11633","11644","13105","18830"],"toDate":aa,"clientId":clid}}
	epg = requests.post('https://b2c-www.redefine.pl/rpc/navigation/', headers=headers, json=data).json()

	
	
	
	danks=epg['result']['11633']
	danks2=epg['result']['11644']
	danks3=epg['result']['13105']
	danks4=epg['result']['18830']
	items=[]
	for dank in danks:
		item = {}
		item['tyt1']=dank['title']
		item['tyt2']=dank['genre']
		item['czas']=dank['startTime']
		items.append(item)

	import datetime 
	now = datetime.datetime.now()
	ab=now.strftime('%Y-%m-%dT%H:%M:%SZ')
	
	
	
	
	from datetime import datetime
	format_date = datetime.strptime(ab, '%Y-%m-%dT%H:%M:%SZ')
	zz= int('{:0}'.format(int(time.mktime(format_date.timetuple()))))

	el1=''
	for i in range(len(items)):
		try:
			nowy,format_date=newtime(items[i]['czas'])
			nowy2,format_date2=newtime(items[i+1]['czas'])
			trwa=nowy2-nowy
			if nowy<zz and nowy+trwa>zz:
				tyt=items[i]['tyt1']
				tyt2=items[i]['tyt2']
				cc=re.sub(':\d+$','',str(format_date))
				el1+='[COLOR khaki]'+cc+'[/COLOR] - '+tyt+' '+tyt2+'[CR]'

			elif nowy>zz:
				tyt=items[i]['tyt1']
				tyt2=items[i]['tyt2']
				cc=re.sub(':\d+$','',str(format_date))
				el1+='[COLOR khaki]'+cc+'[/COLOR] - '+tyt+' '+tyt2+'[CR]'

		except:
			pass

	items=[]
	for dank in danks2:
		item = {}
		item['tyt1']=dank['title']
		item['tyt2']=dank['genre']
		item['czas']=dank['startTime']
		items.append(item)
	import datetime 
	now = datetime.datetime.now()
	ab=now.strftime('%Y-%m-%dT%H:%M:%SZ')
	
	
	
	
	from datetime import datetime
	format_date = datetime.strptime(ab, '%Y-%m-%dT%H:%M:%SZ')
	zz= int('{:0}'.format(int(time.mktime(format_date.timetuple()))))

	el2=''
	for i in range(len(items)):
		try:
			nowy,format_date=newtime(items[i]['czas'])
			
			nowy2,format_date2=newtime(items[i+1]['czas'])
			trwa=nowy2-nowy
			if nowy<zz and nowy+trwa>zz:
			
			
				tyt=items[i]['tyt1']
				tyt2=items[i]['tyt2']
				cc=re.sub(':\d+$','',str(format_date))
				el2+='[COLOR khaki]'+cc+'[/COLOR] - '+tyt+' '+tyt2+'[CR]'

			elif nowy>zz:
				tyt=items[i]['tyt1']
				tyt2=items[i]['tyt2']
				cc=re.sub(':\d+$','',str(format_date))
				el2+='[COLOR khaki]'+cc+'[/COLOR] - '+tyt+' '+tyt2+'[CR]'

		except:
			pass
			
			
	items=[]		
	for dank in danks3:
		item = {}
		item['tyt1']=dank['title']
		item['tyt2']=dank['genre']
		item['czas']=dank['startTime']
		items.append(item)
	import datetime 
	now = datetime.datetime.now()
	ab=now.strftime('%Y-%m-%dT%H:%M:%SZ')
	
	
	
	
	from datetime import datetime
	format_date = datetime.strptime(ab, '%Y-%m-%dT%H:%M:%SZ')
	zz= int('{:0}'.format(int(time.mktime(format_date.timetuple()))))

	el3=''
	for i in range(len(items)):
		try:
			nowy,format_date=newtime(items[i]['czas'])
			nowy2,format_date2=newtime(items[i+1]['czas'])
			trwa=nowy2-nowy
			if nowy<zz and nowy+trwa>zz:
			
			
				tyt=items[i]['tyt1']
				tyt2=items[i]['tyt2']
				cc=re.sub(':\d+$','',str(format_date))
				el3+='[COLOR khaki]'+cc+'[/COLOR] - '+tyt+' '+tyt2+'[CR]'

			elif nowy>zz:
				tyt=items[i]['tyt1']
				tyt2=items[i]['tyt2']
				cc=re.sub(':\d+$','',str(format_date))
				el3+='[COLOR khaki]'+cc+'[/COLOR] - '+tyt+' '+tyt2+'[CR]'

		except:
			pass
	items=[]		
	for dank in danks4:
		item = {}
		item['tyt1']=dank['title']
		item['tyt2']=dank['genre']
		item['czas']=dank['startTime']
		items.append(item)

	import datetime 
	now = datetime.datetime.now()
	ab=now.strftime('%Y-%m-%dT%H:%M:%SZ')
	
	
	
	
	from datetime import datetime
	format_date = datetime.strptime(ab, '%Y-%m-%dT%H:%M:%SZ')
	zz= int('{:0}'.format(int(time.mktime(format_date.timetuple()))))

	el4=''
	for i in range(len(items)):
		try:
			nowy,format_date=newtime(items[i]['czas'])
			nowy2,format_date2=newtime(items[i+1]['czas'])
			trwa=nowy2-nowy
			if nowy<zz and nowy+trwa>zz:
			
			
				tyt=items[i]['tyt1']
				tyt2=items[i]['tyt2']
				cc=re.sub(':\d+$','',str(format_date))
				el3+='[COLOR khaki]'+cc+'[/COLOR] - '+tyt+' '+tyt2+'[CR]'

			elif nowy>zz:
				tyt=items[i]['tyt1']
				tyt2=items[i]['tyt2']
				cc=re.sub(':\d+$','',str(format_date))
				el4+='[COLOR khaki]'+cc+'[/COLOR] - '+tyt+' '+tyt2+'[CR]'
		except:
			pass
	return el1,el2,el3,el4		

def ListTVeleven():
	el1,el2,el3,el4=getEpg2()
	add_item(name='Eleven Sports 1', url='11633', mode="playtv", image='https://canalplussport.pl/Content/images/icon__watch-live.png', folder=False, infoLabels={'plot':el1},isPlayable=False, FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg')	
	add_item(name='Eleven Sports 2', url='11644', mode="playtv", image='https://canalplussport.pl/Content/images/icon__watch-live.png', folder=False, infoLabels={'plot':el2},isPlayable=False, FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg')	
	add_item(name='Eleven Sports 3', url='13105', mode="playtv", image='https://canalplussport.pl/Content/images/icon__watch-live.png', folder=False, infoLabels={'plot':el3},isPlayable=False, FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg')	
	add_item(name='Eleven Sports 4', url='18830', mode="playtv", image='https://canalplussport.pl/Content/images/icon__watch-live.png', folder=False, infoLabels={'plot':el4},isPlayable=False, FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg')	
	xbmcplugin.endOfDirectory(addon_handle)
	
def cookieString(COOKIEFILE):
	sc=''
	if os.path.isfile(COOKIEFILE):
		sess.cookies.load(COOKIEFILE)
		sc=''.join(['%s=%s;'%(c.name, c.value) for c in sess.cookies])
	return sc	
	
	cookieString(COOKIEFILE)
	
	
	
def getUrl(url,coki='bb',redir=True):
	kukis= addon.getSetting('kukiz')
	headers = {
		'Host': 'canalplussport.pl',
		'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36',
		'accept': '*/*',
		'Cookie':kukis,
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'referer': 'https://canalplussport.pl/',
		'te': 'trailers',
	}

	if redir:
		html=sess.get(url,verify=False,headers=headers,allow_redirects=redir).content
	else:
		html=sess.get(url,verify=False,headers=headers,allow_redirects=redir)#.content
	return html

def login():
	username = addon.getSetting('username')
	password = addon.getSetting('password')	
	logowanie = addon.getSetting('logowanie')
	
	if username and password and logowanie == 'true':
		headers = {
			'Host': 'canalplussport.pl',
			'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36',
			'accept': '*/*',
			'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'x-requested-with': 'XMLHttpRequest',
			'referer': 'https://canalplussport.pl/',
			'te': 'trailers',
		}
		
		data = 'ReturnUrl=https://canalplussport.pl/&Email=%s&Password=%s'%(username,password)
		
		response = sess.post('https://canalplussport.pl/zaloguj', headers=headers, data=data)
		html=response.text
		if html.find('<span class="error">')>0:
			xbmcgui.Dialog().notification('[B]Logowanie[/B]', 'Błąd logowania.',xbmcgui.NOTIFICATION_INFO, 6000)
			add_item('', '[B]Zaloguj[/B]','DefaultAddonService.png',False,'settings',False,FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg')

		else:
			sc=''.join(['%s=%s;'%(c.name, c.value) for c in sess.cookies])
			dataPath=os.path.dirname(COOKIEFILE)
			if not os.path.exists(dataPath):
				os.makedirs(dataPath)
			sess.cookies.save(COOKIEFILE, ignore_discard = True)
			addon.setSetting('kukiz',sc)
			xbmcgui.Dialog().notification('[B]Logowanie[/B]', 'Zalogowano poprawnie.',xbmcgui.NOTIFICATION_INFO, 6000)
			add_item(name='Na żywo', url='https://canalplussport.pl', mode="listnazywo", image='https://canalplussport.pl/Content/images/icon__watch-live.png', folder=True, FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg')	
			add_item(name='Magazyny PKO BP Ekstraklasa', url='https://canalplussport.pl/magazyn/ekstraklasa', mode="listmagazyny", image='https://ncplus-sport.img.rd.insyscd.net/online-liga-14092019-25028665/p20.jpg', folder=True, FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg')	

	else:
		xbmcgui.Dialog().notification('[B]Logowanie[/B]', 'Brak danych logowania.',xbmcgui.NOTIFICATION_INFO, 6000)
		add_item('', '[B]Zaloguj[/B]','DefaultAddonService.png',False,'settings',False,FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg')

	return

def PLznak(char):
	char = char.replace('&#260;','Ą')
	char = char.replace('&#261;','ą')
	char = char.replace('&#280;','Ę')
	char = char.replace('&#281;','ę')
	char = char.replace('&#211;','Ó')
	char = char.replace('&#243;','ó')
	char = char.replace('&#262;','Ć')
	char = char.replace('&#263;','ć')
	char = char.replace('&#321;','Ł')
	char = char.replace('&#322;','ł')
	char = char.replace('&#323;','Ń')
	char = char.replace('&#324;','ń')
	char = char.replace('&#346;','Ś')
	char = char.replace('&#347;','ś')
	char = char.replace('&#377;','Ź')
	char = char.replace('&#378;','ź')
	char = char.replace('&#379;','Ż')
	char = char.replace('&#380;','ż')
	char = char.replace('&#252;','u')
	char = char.replace('&#252','u')
	char = char.replace('&#260','Ą')
	char = char.replace('&#261','ą')
	char = char.replace('&#280','Ę')
	char = char.replace('&#281','ę')
	char = char.replace('&#211','Ó')
	char = char.replace('&#243','ó')
	char = char.replace('&#262','Ć')
	char = char.replace('&#263','ć')
	char = char.replace('&#321','Ł')
	char = char.replace('&#322','ł')
	char = char.replace('&#323','Ń')
	char = char.replace('&#324','ń')
	char = char.replace('&#346','Ś')
	char = char.replace('&#347','ś')
	char = char.replace('&#377','Ź')
	char = char.replace('&#378','ź')
	char = char.replace('&#379','Ż')
	char = char.replace('&#380','ż')
	char = char.replace('&#233;','é')
	char = char.replace('&#39;',"'")
	return char
	
def getNaZywo(url):
	url='https://canalplussport.pl/Main/RedirectToMain'
	html=getUrl(url)
	if 'zaloguj' in html:
		zaloguj()
		html=getUrl(url)
	out=[]
	html=PLznak(html)
	links = parseDOM(html, 'div', attrs={'class': "rotator__item__background rotator__item__background--match"})#[0]#'

	for link in links:

		href = parseDOM(link, 'a', ret='href')#[0]	
		if href:
			href = 'https://canalplussport.pl'+href[0] 
		else:
			continue

		teams= re.findall('text--l">([^>]+)<\/h2>',link)
		time = re.findall('>([^>]+)<\/em>',link)#[0]
		
		
		kiedy = re.findall('>([^<]+)<\/time>',link)
		time = time[0] if time else ''
		kiedy = kiedy[0] if kiedy else ''
		
		try:
			tyt = '%s vs %s  - (%s o %s)'%(teams[0],teams[1],kiedy,time)
			cod =  '%s, %s'%(kiedy,time)
		except:
			continue
		if 'header__watch-icon icon__watch-live' in link:
			tyt=u'[COLOR lime]► [/COLOR]'+tyt
		else:	
			tyt=u'[COLOR orangered]■ [/COLOR]'	+tyt
		imag=re.findall('src="(.+?)" width="150"',link)[0]#''
		out.append({'title':str(tyt),'href':href,'img':imag,'plot':str(tyt),'code':cod})
	return out
def ListNaZywo(exlink):
	links = getNaZywo(exlink)
	if links:
		itemz=links
		items = len(links)

		fold=False
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='playnazywo', image=f.get('img'), folder=False, isPlayable=True , infoLabels=f,FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg', itemcount=items)	
		xbmcplugin.endOfDirectory(addon_handle)

def PlayNaZywo(url):
	html=getUrl(url,'ekstr')

	if 'zalogowany live' in html:

		result = parseDOM(html, 'div', attrs={'class': "col-xs-6"})[0]
		href = parseDOM(result, 'a', ret='href')#[0]	
		if href:
			href = 'https://canalplussport.pl'+href[0] 

		if 'zaloguj?returnUrl='	in href:
			zaloguj()
			PlayNaZywo(url)
		PlayMagazyn(href)
	return
		
def getMagazyny(url):
	html=getUrl(url)
	out=[]

	links = parseDOM(html, 'li', attrs={'class': "col-xs-4.+?"})
	for link in links:
		href = parseDOM(link, 'a', ret='href')#[0]	
		if href:
			href = 'https://canalplussport.pl'+href[0] 
		else:
			continue
		imag = parseDOM(link, 'img', ret='src')[0]		
		imag=re.findall('(^.+?.jpg)',imag)[0]
		title = (parseDOM(link, 'h4')[0])#.replace('ONLINE','')
		out.append({'title':title,'href':href,'img':imag,'plot':title})
	return out
		
def ListMagazyny(exlink):

	links = getMagazyny(exlink)
	if links:
		itemz=links
		items = len(links)

		fold=False
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='playmagazyny', image=f.get('img'), folder=False, isPlayable=True , infoLabels=f,FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg', itemcount=items)	
	
		xbmcplugin.endOfDirectory(addon_handle)
		
def zaloguj():

	username = addon.getSetting('username')
	password = addon.getSetting('password')	
	logowanie = addon.getSetting('logowanie')
	
	if username and password:

		headers = {
			'Host': 'canalplussport.pl',
			'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
			'accept': '*/*',
			'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'x-requested-with': 'XMLHttpRequest',
			'referer': 'https://canalplussport.pl/magazyn/ekstraklasa',
			'te': 'trailers',
		}
		data = 'ReturnUrl=https://canalplussport.pl/magazyn/ekstraklasa&Email=%s&Password=%s'%(username,password)

		response = sess.post('https://canalplussport.pl/zaloguj', headers=headers, data=data)
		sc=''.join(['%s=%s;'%(c.name, c.value) for c in sess.cookies])
		sess.cookies.save(COOKIEFILE, ignore_discard = True)
		addon.setSetting('kukiz',sc)

	
	
def PlayMagazyn(url):
	html=getUrl(url,'ekstr')

	if 'zaloguj">zalog' in html:
		zaloguj()
		html=getUrl(url,'ekstr')
		html=replaceHTMLCodes(html)
	DrmChallengeCustomData=re.findall('"DrmChallengeCustomData"\:\s*"(.+?)"',html)
	source=re.findall('src="(.+?\.mpd)"',html)
	import inputstreamhelper
	PROTOCOL = 'mpd'
	DRM = 'com.widevine.alpha'
	hdrs={
			'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
			'accept': '*/*',
			'referer': url,

		}
	try:
		STREAM_URL = source[0]
		LICENSE_URL = 'https://wv.drm.insyscd.net/AcquireLicense.ashx'
	
		is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
		if is_helper.check_inputstream():
			play_item = xbmcgui.ListItem(path=STREAM_URL)
			play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
			play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
			play_item.setProperty('inputstream.adaptive.license_type', DRM)
			play_item.setProperty('inputstream.adaptive.stream_headers', str(hdrs))
			bb=urllib.quote(DrmChallengeCustomData[0])
			play_item.setProperty('inputstream.adaptive.license_key', LICENSE_URL + '|DrmChallengeCustomData='+bb+'|R{SSM}|')
			xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
	except:
		pass
	
	
def loginEleven():
	clid = addon.getSetting('clientId')
	devid = addon.getSetting('devid')
	
	stoken = addon.getSetting('sesstoken')
	sexpir = addon.getSetting('sessexpir')
	skey = addon.getSetting('sesskey')
	
	def gen_hex_code(myrange=6):
		return ''.join([random.choice('0123456789ABCDEF') for x in range(myrange)])
	
	def ipla_system_id():
		myrand = gen_hex_code(10) + '-' + gen_hex_code(4) + '-' + gen_hex_code(4) + '-' + gen_hex_code(4) + '-' + gen_hex_code(12)
	
		return myrand
	if not clid and not devid:
	
		clientid=ipla_system_id()
		deviceid=ipla_system_id()
		
		addon.setSetting('clientId', clientid)
		addon.setSetting('devid', deviceid)
		loginEleven()
	else:
		usernameEl = addon.getSetting('usernameEleven')
		passwordEl = addon.getSetting('passwordEleven')	
		if usernameEl and passwordEl:
		
			headers = {
				'Host': 'b2c-www.redefine.pl',
				'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
				'Accept': 'application/json, text/plain, */*',
				'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
				'Content-Type': 'text/plain',
				'Origin': 'https://www.elevensports.pl',
				'Referer': 'https://www.elevensports.pl/uzytkownik/zaloguj/natywnie',
			}
		
			data = {"id":1,"jsonrpc":"2.0","method":"login","params":{"userAgentData":{"portal":"eleven","deviceType":"pc","application":"firefox","os":"windows","build":1},"authData":{"deviceId":{"type":"other","value":devid},"login":usernameEl,"password":passwordEl},"clientId":clid}}
			response = requests.post(auth_url, headers=headers, json=data,verify=False).json()
			if 'error' not in response:
				sesja=response['result']['session']
				
				sesstoken=sesja['id']
				sessexpir=sesja['keyExpirationTime']
				sesskey=sesja['key']
				
				addon.setSetting('sesstoken', sesstoken)
				addon.setSetting('sessexpir', str(sessexpir))
				addon.setSetting('sesskey', sesskey)
				xbmcgui.Dialog().notification('[B]Logowanie[/B]', 'Zalogowano poprawnie.',xbmcgui.NOTIFICATION_INFO, 6000)
				
				
				
				add_item(name='Na żywo', url='', mode='listtveleven', image='https://canalplussport.pl/Content/images/icon__watch-live.png', folder=True, FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg')	
				xbmcplugin.endOfDirectory(addon_handle)
			else:
				xbmcgui.Dialog().notification('[B]Logowanie[/B]', 'Błędne dane logowania.',xbmcgui.NOTIFICATION_INFO, 6000)
				add_item('', '[B]Zaloguj[/B]','DefaultAddonService.png',False,'settings',False,FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg')
				xbmcplugin.endOfDirectory(addon_handle)

		else:
			xbmcgui.Dialog().notification('[B]Logowanie[/B]', 'Błędne dane logowania.',xbmcgui.NOTIFICATION_INFO, 6000)

			add_item('', '[B]Zaloguj[/B]','DefaultAddonService.png',False,'settings',False,FANART='https://ncplus-sport.files.e56-po.insyscd.net/backgrounds/ekstraklasa.jpg')
			xbmcplugin.endOfDirectory(addon_handle)

	return
def getHmac(dane):
	skey = addon.getSetting('sesskey')
	import hmac
	import hashlib 
	import binascii
	import base64
	from hashlib import sha256
	ssdalej=dane
	import base64
	
	
	
	
	def base64_decode(s):
		"""Add missing padding to string and return the decoded base64 string."""
		#log = logging.getLogger()
		s = str(s).strip()
		try:
			return base64.b64decode(s)
		except TypeError:
			padding = len(s) % 4
			if padding == 1:
				#log.error("Invalid base64 string: {}".format(s))
				return ''
			elif padding == 2:
				s += b'=='
			elif padding == 3:
				s += b'='
			return base64.b64decode(s)
	secretAccessKey = base64_decode(skey.replace('-','+').replace('_','/'))

	auth = hmac.new(secretAccessKey, ssdalej.encode("ascii"), sha256)
	vv=base64.b64encode(auth.digest())
	
#	(/\+/g, "-").replace(/\//g, "_")
	
	
	return ssdalej+'|'+vv.replace('+','-').replace('/','_')

def PlayEleven(stream_url,data):


	dane=eval(opisy)

	import inputstreamhelper
	from urllib import quote
	PROTOCOL = 'mpd'
	DRM = 'com.widevine.alpha'
	LICENSE_URL = 'https://gm2.redefine.pl/rpc/drm/'
	is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
	
	UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0'
	if is_helper.check_inputstream():
	
		play_item = xbmcgui.ListItem(path=stream_url)#
		play_item.setInfo(type="Video", infoLabels={"title": name,'plot':dane['plot']})
		
		play_item.setArt({'thumb': imig, 'poster': imig, 'banner': imig, 'fanart': FANART})
		
		play_item.setProperty("IsPlayable", "true")
		play_item.setMimeType('application/xml+dash')
		play_item.setContentLookup(False)
		play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
		play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
		play_item.setProperty('inputstream.adaptive.license_type', DRM)

		play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
		play_item.setProperty('inputstream.adaptive.stream_headers', 'Referer: https://www.elevensports.pl/')
		play_item.setProperty('inputstream.adaptive.license_key',
							LICENSE_URL + '|Content-Type=application%2Fjson&Referer=https://www.elevensports.pl/&User-Agent=' + quote(UA) +
							'|'+data+'|JBlicense')						
		play_item.setProperty('inputstream.adaptive.license_flags', "persistent_storage")

		import threading
		thread = threading.Thread(name='cofanie', target=cofanie, args=[])
		thread.start()
		Player = xbmc.Player()
		Player.play(stream_url, play_item)

def cofanie():
	seek_secs=86399
	while not xbmc.Player().isPlayingVideo():
		xbmc.Monitor().waitForAbort(0.25)
	
	if xbmc.Player().isPlayingVideo():
		xbmc.executebuiltin('Seek(' + str(seek_secs) + ')')		
		
def PlayTVeleven(id):
	clid = addon.getSetting('clientId')
	devid = addon.getSetting('devid')
	
	stoken = addon.getSetting('sesstoken')
	sexpir = addon.getSetting('sessexpir')
	
	dane =stoken+'|'+sexpir+'|navigation|prePlayData'
	authdata=getHmac(dane)
	
	
	headers = {
		'Host': 'b2c.redefine.pl',
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
		'Accept': '*/*',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Content-Type': 'text/plain;charset=UTF-8',
		'Origin': 'https://www.elevensports.pl',
		'DNT': '1',
		'Referer': 'https://www.elevensports.pl/',
	}
	
	
	data = {"jsonrpc":"2.0","id":1,"method":"prePlayData","params":{"ua":"eleven_pc_windows_firefox/1 (Windows 7; widevine=true)","userAgentData":{"deviceType":"pc","application":"firefox","os":"windows","build":1,"portal":"eleven","player":"html","widevine":True},"cpid":0,"mediaId":id,"authData":{"sessionToken":authdata},"clientId":clid}}

	response = requests.post('https://b2c.redefine.pl/rpc/navigation/', headers=headers, json=data).json()
	playback = response['result']['mediaItem']['playback']
	mediaid = playback['mediaId']['id']
	mediaSources = playback['mediaSources'][0]
	keyid = mediaSources['keyId']
	sourceid = mediaSources['id']
	stream_url = mediaSources['url']
	
	dane =stoken+'|'+sexpir+'|drm|getWidevineLicense'
#	dane="%s|%s|navigation|prePlayData"(stoken,sexpir) #dane podzielone |
	authdata=getHmac(dane)
	
	
	
	data=urllib.quote('{"jsonrpc":"2.0","id":1,"method":"getWidevineLicense","params":{"userAgentData":{"deviceType":"pc","application":"firefox","os":"windows","build":1,"portal":"eleven","player":"html","widevine":true},"cpid":0,"mediaId":"'+mediaid+'","sourceId":"'+sourceid+'","keyId":"'+keyid+'","object":"b{SSM}","deviceId":{"type":"other","value":"'+devid+'"},"ua":"eleven_pc_windows_firefox_html/1","authData":{"sessionToken":"'+authdata+'"},"clientId":"'+clid+'"}}')
	PlayEleven(stream_url,data)
	#return

if __name__ == '__main__':
	mode = params.get('mode', None)
	if  mode is None:
		home()
		
	elif mode == 'canallist':
		homeCanal()
	elif mode == 'elevenlist':
		homeEleven()
	elif mode == 'listmagazyny':
		ListMagazyny(exlink)
	elif mode == 'playmagazyny':
		PlayMagazyn(exlink)
	elif mode == "listnazywo":
		ListNaZywo(exlink)
	elif mode == 'playnazywo':
		PlayNaZywo(exlink)
	elif mode == 'playtv':
		PlayTVeleven(exlink)
	elif mode == 'listtveleven':
		ListTVeleven()
		

		
		
	elif mode == 'settings':
		addon.openSettings()
		xbmc.executebuiltin('XBMC.Container.Refresh()')

