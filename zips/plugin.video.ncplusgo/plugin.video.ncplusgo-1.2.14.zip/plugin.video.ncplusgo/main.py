# -*- coding: UTF-8 -*-
import sys,re,os

if sys.version_info >= (3,0,0):
# for Python 3
    from urllib.parse import parse_qsl, quote, unquote, urlencode, quote_plus

else:
    # for Python 2

    from urllib import unquote, quote, urlencode, quote_plus
    from urlparse import parse_qsl






import json
#import urllib

import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc, xbmcvfs



base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.ncplusgo')
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED)
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE)
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_TITLE)
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL)
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LASTPLAYED)

PATH            = addon.getAddonInfo('path')

if sys.version_info[0] > 2:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile'))#.decode('utf-8')
else:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile'))
    
RESOURCES       = PATH+'/resources/'

FANART=RESOURCES+'../fanart.jpg'
ikon =RESOURCES+'../icon.png'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('name', None)
page = params.get('page','')
mcount= params.get('moviescount', None)
movie= params.get('movie', None)
rys= params.get('image', None)

nctoken = addon.getSetting('ncToken')
if not nctoken:
    addon.setSetting('ncToken','')
    
    
    
def IMEI():

    import random
    def luhn_residue(digits):
        return sum(sum(divmod(int(d)*(1 + i%2), 10))for i, d in enumerate(digits[::-1])) % 10

    part = ''.join(str(random.randrange(0,9)) for _ in range(14))
    res = luhn_residue('{}{}'.format(part, 0))
    imIE= '{}{}'.format(part, -res%10)
    addon.setSetting('imei',(imIE))
    return imIE
    
#devicekey = addon.getSetting('imei')
#if not devicekey:
#    imei=IMEI()
#    addon.setSetting('imei',imei)
#devicekey = addon.getSetting('imei')
#    

TIMEOUT=15
#imei='3'
imei='35'
#devicekey=imei



headers = {
    'Content-Type': 'application/json; charset=UTF-8',
    'Accept': 'application/json',
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9.0; SM-G850F Build/LRX22G)',
    'Host': 'api-ncplusgo.ncplus.pl',
}
MAIN_API_URL='https://api-ncplusgo.ncplus.pl/v1/'

sess=requests.Session()

def czas():

    import datetime 
    now = datetime.datetime.now()
    czas=now.strftime('%Y-%m-%dT%H:%M:%SZ')
    from datetime import datetime
    import time
    try:
        format_date=datetime.strptime(czas, '%Y-%m-%dT%H:%M:%SZ')
    except TypeError:
        format_date=datetime(*(time.strptime(czas, '%Y-%m-%dT%H:%M:%SZ')[0:6]))
    tstampnow= int('{:0}'.format(int(time.mktime(format_date.timetuple()))))
    return tstampnow

addon.setSetting('czasteraz',str(czas()))
czasteraz = int(addon.getSetting('czasteraz'))



#def encoded_dict(in_dict):
#   # from future.utils import iteritems
#    out_dict = {}
#    for k, v in in_dict.iteritems():
#        if isinstance(v, unicode):
#            v = v.encode('utf8')
#        elif isinstance(v, str):
#
#            v.decode('utf8')
#        out_dict[k] = v
#    return out_dict
    
def build_url(query):
    return base_url + '?' + urlencode(query)

#def build_url(query):
#    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=1,fanart=FANART,moviescount=0):
    list_item = xbmcgui.ListItem(label=name)

    if IsPlayable:
        list_item.setProperty("IsPlayable", 'True')
    if not infoLabels:
        infoLabels={'title': name,'plot':name}
    list_item.setInfo(type="video", infoLabels=infoLabels)    
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': FANART})
    ok=xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url = build_url({'mode': mode, 'url' : url, 'page' : page, 'moviescount' : moviescount,'movie':movie,'name':name,'image':image}),            
        listitem=list_item,
        isFolder=folder)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %P")
    return ok
    
def IMEI():

    import random
    def luhn_residue(digits):
        return sum(sum(divmod(int(d)*(1 + i%2), 10))for i, d in enumerate(digits[::-1])) % 10

    part = ''.join(str(random.randrange(0,9)) for _ in range(14))
    res = luhn_residue('{}{}'.format(part, 0))
    imIE= '{}{}'.format(part, -res%10)
    addon.setSetting('imei',(imIE))
    return imIE
    
    
def zamiana(response):
    from datetime import datetime
    out=[]
    cc=response["DevicesToReplace"]
    for c in cc:
        tyt1=c["Name"]
        tyt2=c["Type"]
        dat=c["CreateDate"]
        keyid=c["Key"]
        dat=dat/1000
        dat=(datetime.utcfromtimestamp(dat+3600).strftime('%Y-%m-%d %H:%M'))
        tytok = '%s (%s) - dodano: %s'%(tyt1,tyt2,dat)
        out.append({'keyid':keyid,'label':tytok}) 
    return out
def wyszukaj(response):
    cc=response["DevicesToReplace"]
    devkey=''
    for c in cc:
        keyid=c["Key"]
        if keyid:
            devkey=keyid
            break
    return devkey    
def nclogowanie(wymiana=False,dodawanie=False,resp=False):
    devicekey=IMEI()
    email = addon.getSetting("username")
    pwd = addon.getSetting("password")
    
    if email and pwd:
        if wymiana:
            
        
        
            devicekey = addon.getSetting('imei')
            dev2repl = addon.getSetting('dev2repl')
            data = {"DeviceTypeId":14454,"AddDevice":True, "Email":email,"Password":pwd,"DeviceName":"GT-I8200","Token":"","DeviceKey":devicekey,"PlatformCodename":"android","DeviceToReplaceKey":dev2repl,"IsHomeNetwork":False,"ServiceType":"1"}
            addon.setSetting('dev2repl','')
        elif dodawanie:
            #data = {"DeviceTypeId":14454,"AddDevice":True, "Email":email,"Password":pwd,"DeviceName":"GT-I8200","Token":"","DeviceKey":devicekey,"PlatformCodename":"android","IsHomeNetwork":False,"ServiceType":"1"}
            devkey=wyszukaj(resp)
            #addon.setSetting('dev2repl','')
            addon.setSetting('imei',devkey)
            devicekey = addon.getSetting('imei')
            data = {"DeviceTypeId":14454,"AddDevice":False,"Email":email,"Password":pwd,"DeviceName":"GT-I8200","Token":"","DeviceKey":devicekey,"PlatformCodename":"android","IsHomeNetwork":False,"ServiceType":"1"}

        else:
            devicekey=imei
            data = {"DeviceTypeId":14454,"AddDevice":False,"Email":email,"Password":pwd,"DeviceName":"GT-I8200","Token":"","DeviceKey":devicekey,"PlatformCodename":"android","IsHomeNetwork":False,"ServiceType":"1"}
        response = sess.post(MAIN_API_URL+'NcAccount/Login', headers=headers, json=data,verify=False).json()
        
        if response['Result']['Success']:
            token=response['Token']
            tokenexpir=response['TokenExpirationTime']
            addon.setSetting('tokenexpir',str(tokenexpir/1000))
            addon.setSetting('ncToken',token)
            
            xbmcgui.Dialog().notification('[B]Extra[/B]', 'Zalogowano poprawnie',xbmcgui.NOTIFICATION_INFO, 8000)
            ab=True
            
            response={}
            return ab
        else:
            ab=False
            msg = response['Result']["DisplayMessage"]
            if response['Result']["MessageCodename"]=="devices_limit_exceeded_specify_device_to_remove":
                xbmcgui.Dialog().notification('[B]Błąd[/B]', msg,xbmcgui.NOTIFICATION_INFO, 8000)
    
                yes = xbmcgui.Dialog().yesno("[COLOR orange]Uwaga[/COLOR]", 'Brak miejsc na urządzenie. Zamienić je z jednym z dostępnych już na koncie?',yeslabel='YES', nolabel='NO')
                if yes:
                
                    outs=zamiana(response)
                    label = [x.get('label') for x in outs]
                    sel = xbmcgui.Dialog().select('Wybierz urządzenie do zastąpienia:',label)
                    keyid = outs[sel].get('keyid') if sel>-1 else ''
                    
                    if keyid:
                        addon.setSetting('dev2repl',keyid)
                        nclogowanie(wymiana=True)    
            elif response['Result']["MessageCodename"]=="device_not_registered":
                nclogowanie(wymiana=False,dodawanie=True,resp=response)
                ab=True
            elif response['Result']["MessageCodename"]=="wsi_error_13":
                xbmcgui.Dialog().notification('[B]Błąd[/B]', msg,xbmcgui.NOTIFICATION_INFO, 8000)    
            else:
                xbmcgui.Dialog().notification('[B]Błąd[/B]', msg,xbmcgui.NOTIFICATION_INFO, 8000)
            return ab

    else:
        xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Brak danych logowania',xbmcgui.NOTIFICATION_INFO, 8000)
        ab=False
        return ab


def getJson(url,params):
    email = addon.getSetting("username")
    pwd = addon.getSetting("password")
    devicekey = addon.getSetting('imei')
    response = sess.get(MAIN_API_URL+url, headers=headers, params=params,verify=False).json()
    try:
        if response['Result']['MessageCodename']=='token_is_not_valid':
            data = {"DeviceTypeId":14454,"AddDevice":False,"Email":email,"Password":pwd,"DeviceName":"GT-I8200","Token":"","DeviceKey":devicekey,"PlatformCodename":"android","IsHomeNetwork":False,"ServiceType":"1"}
            response = sess.post(MAIN_API_URL+'NcAccount/Login', headers=headers, json=data,verify=False).json()
            token=response['Token']
            tokenexpir=response['TokenExpirationTime']
            addon.setSetting('tokenexpir',str(tokenexpir/1000))
            addon.setSetting('ncToken',token)
            response = sess.get(MAIN_API_URL+url, headers=headers, params=params,verify=False).json()
        elif response['Result']['MessageCodename']=="wsi_error_10":
            data = {"DeviceTypeId":14454,"AddDevice":False,"Email":email,"Password":pwd,"DeviceName":"GT-I8200","Token":"","DeviceKey":devicekey,"PlatformCodename":"android","IsHomeNetwork":False,"ServiceType":"1"}
            response = requests.post(MAIN_API_URL+'NcAccount/Login', headers=headers, json=data,verify=False).json()
            token=response['Token']
            tokenexpir=response['TokenExpirationTime']
            addon.setSetting('tokenexpir',str(tokenexpir/1000))
            addon.setSetting('ncToken',token)
            response = requests.get(MAIN_API_URL+url, headers=headers, params=params,verify=False).json()
    except:
        pass
    return response
    
    
def ListKanaly():
    nctoken = addon.getSetting('ncToken')
    
    params = (
        ('PlatformCodename', 'android'),
        ('token', nctoken),
        ('sortOrder', '0'),
        ('limit', '9999'),
        ('zoneCategory', ''),
        ('page', '1'),
        ('channelCodename', ''),
    )

    url = 'NcContent/GetNowOnTv'
    response = getJson(url,params)
    from datetime import datetime
    aa=response["Contents"]
    
    for a in aa:  
        if a['IsActive']:
            plot1=a["Title"]
            plotczas1=a["Program"]['Start']
            plotczas2=a["Program"]['Stop']

            czas1=plotczas1/1000
            czas2=plotczas2/1000

            czas1=(datetime.utcfromtimestamp(czas1+3600).strftime('%H:%M'))
            czas2=(datetime.utcfromtimestamp(czas2+3600).strftime('%H:%M'))
            plot='%s - %s : %s'%(czas1,czas2,plot1)
            
            tyt= a['Channel']['Title']
            href= a['Channel']['Codename']
            imag= a.get('IconUrl',None)
            imag = imag if imag else ikon
            tyt = PLchar(tyt)
            plot = PLchar(plot)
            add_item(name=tyt, url=href, mode='playNC', image=imag, infoLabels={'plot':plot},folder=False,IsPlayable=True)
    xbmcplugin.endOfDirectory(addon_handle)        
    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
def home():

    loguj=nclogowanie()
    
    if loguj:
        add_item('film', '[B][COLOR khaki]Kanaly[/COLOR][/B]', 'DefaultMovies.png', "listKanaly", folder=True,fanart=RESOURCES+'fanart.png')
        add_item('film', '[B][COLOR khaki]VOD[/COLOR][/B]', 'DefaultMovies.png', "vods", folder=True,fanart=RESOURCES+'fanart.png')
        add_item('film', '[B][COLOR khaki]TV na życzenie[/COLOR][/B]', 'DefaultMovies.png', "zyczenie", folder=True,fanart=RESOURCES+'fanart.png')
        add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "listSearch", folder=True,fanart=RESOURCES+'fanart.png')
            
    else:
        add_item('film', '[B][COLOR khaki]Zaloguj[/COLOR][/B]', 'DefaultAddonService.png', "settings", folder=False,fanart=RESOURCES+'fanart.png')
    xbmcplugin.endOfDirectory(addon_handle)    

def Vods():
        add_item('film', '[B][COLOR khaki]Kolekcje[/COLOR][/B]', 'DefaultMovies.png', "listcollections", folder=True,fanart=RESOURCES+'fanart.png')
        #add_item('film', '[B][COLOR khaki]Kategorie[/COLOR][/B]', 'DefaultMovies.png', "listcategories", folder=True,fanart=RESOURCES+'fanart.png')
        xbmcplugin.endOfDirectory(addon_handle)    

def ListCollections():
    nctoken = addon.getSetting('ncToken')
    
    params = (
        ('PlatformCodename', 'android'),
        ('token', nctoken),
        ('collectionCategoryCodename', 'vod'),
    )

    url = 'NcContent/GetVodCollections'
    response = getJson(url,params)
    aa= response["VodCollections"]
    for a in aa:
        mud = 'listcolcd'
        tyt = PLchar(a['Title'])
        imag = a["IconUrl"]
        href = a["Codename"]
        purch = a["IsPurchased"]
        if not purch:
            tyt+=' [COLOR red](brak dostępu)[/COLOR]'
            mud='ccc'
        add_item(name=tyt, url=href, mode=mud, image=imag, infoLabels=False,folder=True,IsPlayable=False)#, infoLabels=f, itemcount=items)
    xbmcplugin.endOfDirectory(addon_handle)    
def imgcr(img):
    imag = (re.findall('\/(ht.+?)$',unquote(img))[0]).replace('|WIDTH|','800').replace('|HEIGHT|','600')
    return imag
    
def ListCollCd(codename,pg,zyczenie=False):

    if codename.find('|')>0:
        codename,zyczenie=codename.split('|')
        zyczenie = eval(zyczenie)
    pg=int(pg)
    nctoken = addon.getSetting('ncToken')
    params = (
        ('PlatformCodename', 'android'),
        ('token', nctoken),
        ('sortOrder', '6'),
        ('limit', '30'),
        ('collectionTypeCategoryCodename', 'vod'),
        ('vodCollectionCodename', codename),
        ('page', page),
    )

    if zyczenie:
        params = (
            ('PlatformCodename', 'android'),
            ('token', nctoken),
            ('sortOrder', '6'),
            ('limit', '25'),
            ('collectionTypeCategoryCodename', 'catchup'),
            ('page', page),
            ('parentCategoryCodename', codename),
        )

    url = 'NcContent/GetVods'
    response = getJson(url,params)
    ilstron = int(response["Pagination"]["TotalPages"])
    aa=response["Vods"]
    co=0
    for a in aa:
        tyt = PLchar(a['Title'])
        if '(SD)' in tyt:
            continue
        if (a["Movie"]["EndPublishDate"])/1000<czasteraz:
            continue
        if not a['IsActive']:
            continue
        co+=1
        imag = a["ImageUrl"]
        imag = imgcr(imag)
        href = a["Codename"]

        fold=False
        isplay=True
        mud='playNC'
        if re.findall('(serial)',a["CategoryDisplayName"]) or 'EpisodeNumber' in a['Movie']:#.has_key('EpisodeNumber'):

            fold=True
            isplay=False
            mud='listncseasons'
        add_item(name=tyt, url=href, mode=mud, image=imag, infoLabels=False,folder=fold,IsPlayable=isplay)#, infoLabels=f, itemcount=items)
    if pg<ilstron:
        add_item(name='Następna strona', url=codename+'|'+str(zyczenie), mode='listcolcd', image='', infoLabels=False,folder=True,IsPlayable=False,page=pg+1)
    xbmcplugin.setContent(int(sys.argv[1]), 'seasons')
    if co>0:
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia.',xbmcgui.NOTIFICATION_INFO, 6000)
    
def ListNCseasons(codename):
    nctoken = addon.getSetting('ncToken')
    xbmcplugin.setContent(int(sys.argv[1]), 'seasons')
    params = (
        ('PlatformCodename', 'android'),
        ('token', nctoken),
        ('contentIdentifier.Codename', codename),
    )
    url = 'NcContent/GetPlayerDetails'
    response = getJson(url,params)
    images=response["Content"]["Images"]
    for c in images:
        if not c["IsMain"]:
            continue
        imag = c["Url"]
        imag = imgcr(imag)
        break
        
    aa = response["Seasons"]
    for a in aa:
        href = a["EpisodeCodename"]
        tyt = PLchar(a["Title"])
        add_item(name=tyt, url=href, mode='listncepis', image=imag, infoLabels=False,folder=True,IsPlayable=False)
        
    xbmcplugin.endOfDirectory(addon_handle)

def ListNCepis(codename):
    nctoken = addon.getSetting('ncToken')
    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    fold=False
    isplay=True
    mud='playNC'
    
    params = (
        ('PlatformCodename', 'android'),
        ('token', nctoken),
        ('contentIdentifier.Codename', codename),
    )
    
    url = 'NcContent/GetPlayerDetails'
    response = getJson(url,params)
    
    images=response["Content"]["Images"]
    for c in images:
        if not c["IsMain"]:
            continue
        imag = c["Url"]
        imag = imgcr(imag)
        break
    content = response["Content"]#: {
    tyt = PLchar(content["Title"])
    opis = PLchar(content["Description"])
    add_item(name=tyt, url=codename, mode=mud, image=imag, infoLabels={'plot':opis},folder=fold,IsPlayable=isplay)

    aa = response["Episodes"]
    for a in aa:
        href = a["Codename"]
        tyt = PLchar(a["Title"])
        imag = a["ImageUrl"]
        imag = imgcr(imag)
        
        add_item(name=tyt, url=href, mode=mud, image=imag, infoLabels={'plot':opis},folder=fold,IsPlayable=isplay)#, infoLabels=f, itemcount=items)
    xbmcplugin.endOfDirectory(addon_handle)

def ListNaZyczenie():
    nctoken = addon.getSetting('ncToken')
    
    params = (
        ('PlatformCodename', 'android'),
        ('token', nctoken),
        ('collectionTypeCategoryCodename', 'catchup'),
        ('categoryTypeCodename', 'genre'),
    )
    url = 'NcContent/GetCategories'
    response = getJson(url,params)
    aa = response["Categories"]
    for a in aa:
        tyt = PLchar(a["Name"])
        href = a["Codename"]
        add_item(name=tyt, url=href, mode="zyczeniecd", image='', infoLabels=False,folder=True,IsPlayable=False)
    xbmcplugin.endOfDirectory(addon_handle)

def getsources(codename):
    nctoken = addon.getSetting('ncToken')
    devicekey = addon.getSetting('imei')
    params = (
        ('PlatformCodename', 'android'),
        ('token', nctoken),
        ('deviceKey', devicekey),
        ('codename', codename),
    )

    url = 'NcContent/AcquireContent2'
    response = getJson(url,params)
    licserv=''
    DrmChallengeCustomData=''
    str_url=''
    if not "DrmInfo" in response:

        email = addon.getSetting("username")
        pwd = addon.getSetting("password")
        data={"DeviceTypeId":14454,"AddDevice":False,"Email":email,"Password":pwd,"DeviceName":"GT-I8200","Token":nctoken,"DeviceKey":devicekey,"PlatformCodename":"android","IsHomeNetwork":False,"ServiceType":"1"}
        response = sess.post(MAIN_API_URL+'NcAccount/Login', headers=headers, json=data,verify=False).json()
        if response['Result']['Success']:
            token=response['Token']
            tokenexpir=response['TokenExpirationTime']
            addon.setSetting('tokenexpir',str(tokenexpir/1000))
            addon.setSetting('ncToken',token)
            nctoken2 = addon.getSetting('ncToken')
            params = (
                ('PlatformCodename', 'android'),
                ('token', nctoken2),
                ('deviceKey', devicekey),
                ('codename', codename),
            )
        
            url = 'NcContent/AcquireContent2'
            response = getJson(url,params)
        
    aa=response["DrmInfo"]
    for a in aa:  
        if a["DrmSystem"]=='Widevine':
            licserv=a["LicenseServerUrl"]
            DrmChallengeCustomData=a["DrmChallengeCustomData"]
            break
    aa=response["MediaFiles"][0]['Formats']       
    for a in aa:
        if a['Protection']==4:
            str_url=a['Url']
            str_url=requests.get(str_url,verify=False,allow_redirects=False)
            str_url=str_url.headers['Location']
            try:
                if 'opl-' not in str_url:
                    xx=re.findall('(\.cdn\-ncplus.pl\/.+?)$',str_url)
                    if xx:
                        str_url='https://opl-n02'+xx[0]
                else:
                    str_url=str_url
            except:
                pass
                
            break
    return licserv,    DrmChallengeCustomData, str_url
    
def PlayNc(url):
    UAx='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0'
    licserv,    DrmChallengeCustomData, str_url = getsources(url)
    licserv = 'https://wv.drm.insyscd.net/AcquireLicense.ashx'
    import inputstreamhelper
    #from urllib import quote
    PROTOCOL = 'mpd'
    DRM = 'com.widevine.alpha'
    LICENSE_URL=licserv
    str_url=str_url+'|auth=SSL/TLS&verifypeer=false'
    hea='DrmChallengeCustomData='+quote(DrmChallengeCustomData)
    
    is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
    if is_helper.check_inputstream():
    
        play_item = xbmcgui.ListItem(path=str_url)
        play_item.setContentLookup(False)
        
        
        if sys.version_info >= (3,0,0):
            play_item.setProperty('inputstream', is_helper.inputstream_addon)
        else:
            play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
        
        #play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
        play_item.setMimeType('application/xml+dash')
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+quote(UAx)+'&auth=SSL/TLS&verifypeer=false')
        play_item.setProperty('inputstream.adaptive.license_type', DRM)
    #    play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
        play_item.setProperty('inputstream.adaptive.license_key', LICENSE_URL+'|' + hea +'&auth=SSL/TLS&verifypeer=false|R{SSM}|')
    #    play_item.setProperty('inputstream.adaptive.license_flags', "persistent_storage")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def ListSearch():
    nctoken = addon.getSetting('ncToken')
    from datetime import datetime
    d = xbmcgui.Dialog().input(u'Szukaj...', type=xbmcgui.INPUT_ALPHANUM)
    if d:
        params = (
            ('PlatformCodename', 'android'),
            ('token', nctoken),
            ('sortOrder', '0'),
            ('query', d),
        )

        url = 'NcSearch/Search2'
        response = getJson(url,params)
     #   xbmc.log('@#@htmlhtml: %s' % str(response), xbmc.LOGNOTICE)
        try:
            msg = response['Result']['DisplayMessage']
        except:
            msg = None
        if msg:
            xbmcgui.Dialog().notification('[B]Uwaga![/B]', msg,xbmcgui.NOTIFICATION_INFO, 8000)    
        else:
            ab = response.get("Movies",None)
 #         #  ab = response.get("Channels",None)
            #if ab:
            for a in ab:
                tyt = PLchar(a['Title'])
                if '(SD)' in tyt:
                    continue
                if (a["Movie"]["EndPublishDate"])/1000<czasteraz:
                    continue
                if not a['IsActive']:
                    continue
                imag = a["ImageUrl"]
                imag = imgcr(imag)
                
                href = a["Codename"]
                
                fold=False
                isplay=True
                mud='playNC'
                
                if re.findall('(serial)',a["CategoryDisplayName"]): #or a['Movie'].has_key('EpisodeNumber'):
                
                    fold=True
                    isplay=False
                    mud='listncseasons'
                
                add_item(name=tyt, url=href, mode=mud, image=imag, infoLabels=False,folder=fold,IsPlayable=isplay)#, infoLabels=f, itemcount=items)
            
            
            
            
            
            
            
            
            
             #   acv=''
#            #    xbmc.log('@#@htmlhtml: %s' % str(a), xbmc.LOGNOTICE)
#                plot1=PLchar(a["Title"])
#                try:
#                    plotczas1=a["Program"]['Start']
#                    plotczas2=a["Program"]['Stop']
#                except:
#                    xbmc.log('@#@aaaaaaaaaaaaa: %s' % str(a), xbmc.LOGNOTICE)
#                czas1=plotczas1/1000
#                czas2=plotczas2/1000
#            
#                czas1=(datetime.utcfromtimestamp(czas1+3600).strftime('%d.%m. %H:%M'))
#                czas2=(datetime.utcfromtimestamp(czas2+3600).strftime('%H:%M'))
#                plot='%s - %s'%(czas1,czas2)
#                
#                tyt= '[B]'+plot1+'[/B] - data: %s (%s)'%(plot,(PLchar(a['Channel']['Title'])))
#                href= a['Channel']['Codename']
#                imag= a['IconUrl']
#                add_item(name=tyt, url=href, mode='playNC', image=imag, infoLabels={'plot':tyt},folder=False,IsPlayable=True)
            
            
          #  xbmc.log('@#@htmlhtml: %s' % str(response), xbmc.LOGNOTICE)
            aa = response.get("Programs",None)
            if aa:
                for a in aa:
                    if a["Type"]=="program":
                        plotczas1=a["Program"]['Start']
                        plotczas2=a["Program"]['Stop']
                        czas1=plotczas1/1000
                        czas2=plotczas2/1000
                        czas2=(datetime.utcfromtimestamp(czas2+3600).strftime('%H:%M'))
                        opis=' '
                        mud= ' '
                        if czasteraz<czas1:
                            czas1=(datetime.utcfromtimestamp(czas1+3600).strftime('%Y-%m-%d %H:%M'))
                            
                            opis='Zacznie sie o: %s'%czas1
                            mud='playNC'
                        else:
                            opis=' '
                            mud= ' '
                        tyt1= PLchar(a['Title'])
                        tyt2=PLchar( a['Channel']['Title'])
                        href= a['Channel']['Codename']
                        imag= a['IconUrl']
                        tyt = '%s ([COLOR lightgreen][B]%s[/B][/COLOR]) [COLOR khaki]%s-%s[/COLOR]'%(tyt1,tyt2,czas1,czas2)
                        plot = '%s[CR]- %s[CR]%s-%s'%(tyt1,tyt2,czas1,czas2)
                        add_item(name=tyt, url=href, mode=mud, image=imag, infoLabels={'plot':plot},folder=False,IsPlayable=True)
                    else:
                        tyt = PLchar(a['Title'])
                        if '(SD)' in tyt:
                            continue
                        if (a["Movie"]["EndPublishDate"])/1000<czasteraz:
                            continue
                        if not a['IsActive']:
                            continue
                        imag = a["ImageUrl"]
                        imag = imgcr(imag)
                        
                        href = a["Codename"]
                
                        fold=False
                        isplay=True
                        mud='playNC'
                
                        if re.findall('(serial)',a["CategoryDisplayName"]) or 'EpisodeNumber' in a['Movie']:#.has_key('EpisodeNumber'):
                
                            fold=True
                            isplay=False
                            mud='listncseasons'
                
                        add_item(name=tyt, url=href, mode=mud, image=imag, infoLabels=False,folder=fold,IsPlayable=isplay)#, infoLabels=f, itemcount=items)
            if not aa and not ab:
                xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Nic nie znaleziono.',xbmcgui.NOTIFICATION_INFO, 6000)
            else:
                xbmcplugin.endOfDirectory(addon_handle)

def PLchar(char):
    if type(char) is not str:
        char=char.encode('utf-8')
    char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
    char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
    char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
    char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
    char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
    char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
    char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
    char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
    char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
    char = char.replace('&#8217;',"'")
    char = char.replace('&#8211;',"-")    
    char = char.replace('&#8230;',"...")    
    char = char.replace('&#8222;','"').replace('&#8221;','"')    
    char = char.replace('[&hellip;]',"...")
    char = char.replace('&#038;',"&")    
    char = char.replace('&#039;',"'")
    char = char.replace('&quot;','"').replace('&oacute;','ó').replace('&rsquo;',"'")
    char = char.replace('&nbsp;',".").replace('&amp;','&').replace('&eacute;','e')
    return char    

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        mode = params.get('mode', None)
        if mode =="listKanaly":    
            ListKanaly()
            
        elif mode == 'listSearch':
            ListSearch()    
            
        elif mode =='playNC':    
            PlayNc(exlink)

        elif mode =="listcollections":    
            ListCollections()
            
        elif mode =="vods":    
            Vods()
            
        elif mode =='listcolcd':    
            ListCollCd(exlink,page)    
            
        elif mode =='listncseasons':    
            ListNCseasons(exlink)        

        elif mode =='listncepis':    
            ListNCepis(exlink)
            
        elif mode =='zyczenie':    
            ListNaZyczenie()
        elif mode =='zyczeniecd':    
            ListCollCd(exlink,page,True)
            
        elif mode == 'settings':
            addon.openSettings()
            xbmc.executebuiltin('Container.Refresh()')
    
    else:
        home()
        xbmcplugin.endOfDirectory(addon_handle)    
if __name__ == '__main__':
    router(sys.argv[2][1:])

    
    
    
    
    
    
    
    
    
    
    
    
    
    