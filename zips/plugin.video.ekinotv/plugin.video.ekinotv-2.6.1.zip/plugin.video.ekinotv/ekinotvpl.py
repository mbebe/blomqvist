# -*- coding: utf-8 -*-

import sys,os,re
import urllib,urllib2
import urlparse
import requests
import cookielib
import xbmcaddon
import xbmc,xbmcgui

addon = xbmcaddon.Addon()
PATH			= addon.getAddonInfo('path')
DATAPATH		= xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES	   = PATH+'/resources/'
COOKIEFILE = os.path.join(RESOURCES,'ekino.cookie')
sys.path.append(os.path.join(RESOURCES, "lib"))
import cloudscraper

baseurl='http://ekino-tv.pl'
UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0'
hd={'User-Agent': UA}
sess=requests.Session()
COOKIEFILE = os.path.join(DATAPATH,'intws.cookie')

sessi = requests.Session()
sessi.cookies = cookielib.LWPCookieJar(COOKIEFILE)
def PLchar(letter):
	if isinstance(letter, unicode):
		letter = letter.encode('utf-8')
	letter = letter.replace('&lt;br/&gt;',' ')
	letter = letter.replace('&nbsp;','')
	s='JiNcZCs7'
	letter = re.sub(s.decode('base64'),'',letter)
	letter = letter.replace('&mdash;','-') #.replace('&Oacute;','Ó')
	letter = letter.replace('&iacute;','í').replace('&Iacute;','Í')	
	letter = letter.replace('&bdquo;','„').replace('&rdquo;','”')
	letter = letter.replace('&aacute;','á').replace('&Aacute;','Á')	
	letter = letter.replace('&quot;','"').replace('&amp;quot;','"')
	letter = letter.replace('&oacute;','ó').replace('&Oacute;','Ó')
	letter = letter.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
	letter = letter.replace('&amp;','&')
	letter = letter.replace('\u0105','ą').replace('\u0104','Ą')
	letter = letter.replace('\u0107','ć').replace('\u0106','Ć')
	letter = letter.replace('\u0119','ę').replace('\u0118','Ę')
	letter = letter.replace('\u0142','ł').replace('\u0141','Ł')
	letter = letter.replace('\u0144','ń').replace('\u0144','Ń')
	letter = letter.replace('\u00f3','ó').replace('\u00d3','Ó')
	letter = letter.replace('\u015b','ś').replace('\u015a','Ś')
	letter = letter.replace('\u017a','ź').replace('\u0179','Ź')
	letter = letter.replace('\u017c','ż').replace('\u017b','Ż')
	return letter
	
	
def getverystream(url):	
	import requests
	sess = requests.Session()
	sess.headers.update({
	'User-Agent': UA,
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Connection': 'keep-alive',})
	html=sess.get(url).content
	id=re.findall('id="videolink">([^>]+)<',html,re.DOTALL)[0]
	sess.headers.update({'Referer': url})
	url2='https://verystream.com/gettoken/%s?mime=true'%id
	response=sess.get(url2,allow_redirects=False)#.content
	locat= response.headers['Location']
	return locat+'|User-Agent='+UA+'&Referer='+url
	
def zaloguj(user,password):
	loguj=False
	kto=''
	avat=''
	headers = {
		'Host': 'ekino-tv.pl',
		'user-agent': UA,
		'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'content-type': 'application/x-www-form-urlencoded',
		'origin': 'https://ekino-tv.pl',
		'dnt': '1',
		'referer': 'https://ekino-tv.pl/',
		'upgrade-insecure-requests': '1',
		'te': 'trailers',
	}

	data = 'login=%s&password=%s'%(user,password)
	response = sessi.post('https://ekino-tv.pl/user/log_in',headers=headers,data=data,verify=False)

	ab=response.text
	if '/user/logout' in response.text:
		kukz=''.join(['%s=%s;'%(c.name, c.value) for c in response.cookies])
		addon.setSetting('unbkuk',kukz)
		sessi.cookies.save(COOKIEFILE, ignore_discard = True)
		response = sessi.get(baseurl,headers=hd,verify=False).text

		avat = re.findall('<div class="avatar">(.*?)<\/div>',response,re.DOTALL)
		avat = re.findall('img src="([^"]+)"',avat[0],re.DOTALL)[0] if avat else ''
		avat = baseurl+avat if avat else ''
		kto = re.findall('<a href="">(.+?)<br.+?',response,re.DOTALL)
		kto = kto[0] if kto else ''

		konto = re.findall('href="\/premium\/">(.+?)<',response,re.DOTALL)
		konto = konto[0].lower() if konto else ''
		if 'standard' in konto:
			kto = '[COLOR violet]'+PLchar(kto)+'[/COLOR]'+ '[COLOR yellow] %s [/COLOR]'%PLchar(konto)
		else:
			kto = '[COLOR violet]'+PLchar(kto)+'[/COLOR]'+ '[COLOR khaki][B] %s [/COLOR][/B]'%PLchar(konto)
		loguj=True
	elif 'role="alert">Podane dane s' in response.text:
		xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Błędne dane logowania.',xbmcgui.NOTIFICATION_INFO, 6000,False)
	return loguj,(kto,avat)
def resetkukz():
	sess.cookies.clear()
	sessi.cookies.save(COOKIEFILE, ignore_discard = True)
	return
def getUrl(url,data=None,remcook=False):
	if os.path.isfile(COOKIEFILE):
		sessi.cookies.load(COOKIEFILE, ignore_discard = True)
	if remcook:
		sessi.cookies.clear('ekino-tv.pl', '/', 'pplayer')
	import requests
	content=sessi.get(url,headers=hd,verify=False)
	if content.status_code == 503:
		_cfscrapex = cloudscraper.create_scraper(interpreter='native', browser={'custom': UA})
		ab = _cfscrapex.get(url)
		kukz=''.join(['%s=%s;'%(c.name, c.value) for c in ab.cookies])
		content=ab.content
	else:
		kukz=''.join(['%s=%s;'%(c.name, c.value) for c in content.cookies])
		content=content.content

	return content,kukz	

	
def cfandsave():
	s.cookies.clear()
	s.headers.update({'User-Agent': UA})
	url_test = baseurl
	response=s.get(url_test)
	cookies = s.cookies
	if cookies:
		s.cookies.save()
		
	return
	
def getCategory(kateg='',wersja='', page='1', url='http://ekino-tv.pl/movie/cat/'):
	if kateg or wersja:
		dod='kategoria[%s]+wersja[%s]+strona[%s]+'%(kateg,wersja,page)
		dod=urllib.quote_plus(dod)
		urlEK = r'https://ekino-tv.pl/movie/cat/'+dod

	else:
		urlEK = 'http://ekino-tv.pl/movie/cat/'
	content,kuk  = getUrl(urlEK)
	out,out2=getContent(content,kuk)
	return out,out2
	
def getContent(content,kuk):
	idx = [(a.start(), a.end()) for a in re.finditer('<div class="movies-list-item"', content)]
	idx.append( (-1,-1) )
	res=[]
	reser=[]
	for i in range(len(idx[:-1])):
		match = content[ idx[i][1]:idx[i+1][0] ]
		imag = re.compile('<img src="(/static/thumb/.*.jpg)" alt=').findall(match)
		title = re.compile('<div class="title">[\\s]*<a href="(.*?)">(.*?)</a><br>').findall(match)
		plot = re.compile('<div class="movieDesc">[\\s\n]*(.*?)</div>').findall(match)
		rating = re.compile('<div class="sum-vote"><[^>]*>([^>]*)</div>').findall(match)
		year = re.compile('<p class="cates">(.*) \\|').findall(match)
		categ = re.compile('<p class="cates">(.*) \\| (<a href="/movie/cat/kategoria\\[\\d+\\]">.*</a>[,]*)*</p>').findall(match)
		infocat = re.compile('<div class="info-categories"(.*?)</div>',re.DOTALL).findall(match)
		href=title[0][0]
		if infocat:
			infocat = ''.join(re.compile('>(.*?)<').findall(infocat[0]))
		if title:
			out={}
			out['href'] = href
			out['title'] = PLchar(title[0][1].replace('- HD','')).strip('\n ')
			out['year'] = year[0] if year else ''
			out['genre'] = ''.join(re.compile('>(.*?)<').findall(categ[0][1])) if categ else ''
			out['code'] = 'HD' if 'HD' in out['genre'] else ''
			out['plot'] = PLchar(plot[0].strip('\n ')) if plot else ''
			out['rating'] = rating[0].strip() if rating else ''
			out['img'] = baseurl+imag[0].replace('/thumb/','/normal/')+'|User-Agent='+urllib.quote(UA)+'&Referer='+baseurl+'&Cookie='+urllib.quote(kuk) if imag else ''
			if '/serie/show/' in href:
				reser.append(out)
			else:
				res.append(out)				
	return res,reser
def getPremVid(ccc,host,hrefid,idd):
	code=''
	if host == "playerbox":
		SID = re.findall('SID\s*=\s*"(.+?)"',ccc)[0]
		code = baseurl + '/watch/ex/playerbox/' + hrefid + '/' + SID
		
	elif host == "upzone":
		SID = re.findall('SID\s*=\s*"(.+?)"',ccc)[0]
		itemType = re.findall('itemType\s*=\s*(\d+)',ccc)[0]
		code = baseurl + '/watch/ex/upzone/' + hrefid + '/' + SID + '/' + itemType + '/' + idd
		
	elif host == "jetload":
		SID = re.findall('SID\s*=\s*"(.+?)"',ccc)[0]
		itemType = re.findall('itemType\s*=\s*(\d+)',ccc)[0]
		code = baseurl +'/watch/ex/jetload/' + hrefid + '/' + SID + '/' + itemType + '/' + idd
		
	elif host == "fone":
		SID = re.findall('SID\s*=\s*"(.+?)"',ccc)[0]
		code = baseurl +'/watch/exx/fone/' + hrefid + '/' + SID
	return code
	
def getVideos(url='http://ekino-tv.pl/movie/show/moj-przyjaciel-smok-hd-petes-dragon-2016-dubbing/19887'):
	if not url.startswith('http:'):
		url = urlparse.urljoin(baseurl,url)
	idd = re.findall('(\d+)$',url)#[0]
	idd = idd[0] if idd else ''
	content,kuk  = getUrl(url)
	hostEK=[]
	out=[]
	subset = re.compile('ShowPlayer\\(["\'](.*?)["\'],["\'](.*?)["\']\\)').findall(content)

	for host,content in subset:
	
		out.append(content)
		hostEK.append(host)
	if not subset:
		content = content.replace("\'",'"')
		subset = re.compile("""ShowPlayer\(['"](.+?)['"],\s*['"](.+?)['"]""").findall(content)
		for host,hrefid in subset:
			if host == "jetload":
				continue
			ccc=re.findall('\(host\s*==\s*"%s"\)\s*\{(.+?)\}'%host,content,re.DOTALL)[0]
			code = getPremVid(ccc,host,hrefid,idd)
			out.append(code)
			hostEK.append(host+'[COLOR lightgreen][B] premium[/COLOR][/B]')
		html,kuk2  = getUrl(url,remcook=True)
		subset = re.compile('ShowPlayer\\(["\'](.*?)["\'],["\'](.*?)["\']\\)').findall(html)
		for host,content in subset:
			out.append(content)
			hostEK.append(host)
	return (hostEK,out)
	
def getStreams2(url):
	content,kuk   = getUrl(url)
	content = content.replace("\'",'"')
	nturl = re.findall('var\s*url\s*=\s*"(.+?)"',content)[0]
	nturl = baseurl+nturl
	content,kuk   = getUrl(nturl)
	content = content.replace("\'",'"')
	link = re.findall('source src="(.+?)"',content)#[0]
	link = link[0] if link else ''
	link+='|User-Agent='+urllib.quote(UA)+'&Referer='+nturl if link else ''
	return link

def getStreams(host='openload',id='cHl1ZUV5T3hBeTltR1VwPQclmn'):
	import base64
	streams=''

	url=urlparse.urljoin(baseurl,'/watch/f/') + host + '/' + id
	content,kuk   = getUrl(url)
	try:
		content2 = re.compile('atob\([\'"](.*?)[\'"]').findall(content)
		nturl=base64.b64decode(content2[0])
		content2,kuk   = getUrl(nturl)
	
		streams = re.compile('iframe src=[\'"](.*?)[\'"]').findall(content2)
	except:
		streams = re.findall('href="([^"]+)"\s*target=".+?"\s*class=".+?"',content,re.DOTALL)
		
	stream =streams[0] if streams else ''

	return stream	
def getFileone(stream):
	hd={'User-Agent': UA}
	html=requests.get(stream, headers=hd,verify=False).content
	src = re.findall('src=[\'"](.+?)[\'"]\s*type=[\'"]video',html)
	if src:
		src = src[0]
	else:
		src = stream
	src = 'https:' + src if src.startswith('//') else src
	return src
	
def getvidspace(stream):
	hd={'User-Agent': UA}
	packer = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)')
	import requests
	import jsunpack
	html=requests.get(stream, headers=hd,verify=False).content
	packed = packer.findall(html)#[0]
	if packed:
		unpacked = (jsunpack.unpack(packed[0]))
	else:
		unpacked = html
	sources = re.findall('sources\:\s*\[(.+?)\]',unpacked)
	if sources:
		src = re.findall('[\'"](.+?)[\'"]',sources[0])[-1]
	else:
		src = stream
	src = 'https:' + src if src.startswith('//') else src
	return src
	
def getMixdrop(stream):
	hd={'User-Agent': UA}
	packer = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)')
	import requests
	import jsunpack
	stream=stream.replace("mixdrop.co/f/","mixdrop.co/e/")
	html=requests.get(stream, headers=hd,verify=False).content
	packed = packer.findall(html)#[0]
	if packed:
		unpacked = (jsunpack.unpack(packed[0]))
	else:
		unpacked = html

	src = re.findall('wurl=[\'"](.+?)[\'"]',unpacked)

	if src:
		src = src[0]
	else:
		src=stream
	src = 'https:' + src if src.startswith('//') else src
	return src
def getOnlyStream(stream):
	hd={'User-Agent': UA}
	packer = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)')
	import requests
	import jsunpack
	html=requests.get(stream, headers=hd,verify=False).content
	packed = packer.findall(html)#[0]
	if packed:
		unpacked = (jsunpack.unpack(packed[0]))
	else:
		unpacked = html
	if 'window.location="' in unpacked:
		unpacked = html
	try:

		sregex =  '(?:file|src): *"([^"]+)"[^{}<>]+?(?:, *label: *"([^"]+)")*}'
		
		links=re.findall(sregex,unpacked)
		try:
			ac=links[-1]
			link=ac[0]+'|User-Agent='+UA+'&Referer='+stream
		except:
			link=''

	except:
		link=''

	return link
	
	
	
def _1ll1ll1_ef_(url='/movie/show/partyzant-napisy-pl-partisan-2015-napisy/7909'):
	content,kuk   = getUrl(baseurl+url)
	subset = re.compile('<iframe(.*)></iframe>\n', re.DOTALL).findall(content)
	hostEK=[]
	out=[]
	for f in subset:
		itemEK = re.compile('src="(.*?)"', re.DOTALL).findall(content)
		for th in itemEK:
			if 'hosting=vshare' in th:
				th='http://vshare.io/v/%s/width-640/height-400/'  % (th.split('=')[-1])
			if th.startswith('http'):
				out.append(th)
				hostEK.append(th.split('/')[2])
	return (hostEK,out)
def getFilmCat(url='http://ekino-tv.pl/movie/cat/'):
	content,kuk   = getUrl(url)
	match = re.compile('<li data-id="(\\d+)">[\\s\n]+<a href="/movie/cat/kategoria\\[\\d+\\]">(.*?)</a>[\\s\n]*</li>').findall(content)
	catNumb = [x[0] for x in match]
	catNameEK = [x[1] for x in match]
	return (catNameEK,catNumb)
def search(phrase='Piraci'):
	urlk='https://ekino-tv.pl/search/q/?q='+phrase	 #https://ekino-tv.pl/se/search?q=piraci
	contentz,kuk  = getUrl(urlk)
	return getContent(contentz,kuk)
def getSeriale(url='/serie/catalog/W'):
	content,kuk   = getUrl(baseurl+url)
	out = getContent(content,kuk)
	return out
def getSerKat():
	content,kuk   = getUrl('http://ekino-tv.pl/serie/')
	match = re.compile('<ul class="serialsmenu">(.*?)</ul>',re.DOTALL).findall(content)
	out=[]
	if match:
		items = re.compile('<a href="(.*?)"><span class="name">(.*?)</span><span class="count">(.*?)</span></a>').findall(match[0])
		for item in items:
			out.append({'href':item[0],'title':'%s ([COLOR blue]%s[/COLOR])'%(item[1],item[2])})
	return out
def getEpisode(url):
	content,kuk  = getUrl(baseurl+url)
	match = re.compile('<ul class="list-series">(.*?)</ul>',re.DOTALL).findall(content)
	out=[]
	for tEK in match:
		match2 = re.compile('<a href="(.*?)">(.*?)</a>').findall(tEK)
		for e in match2:
			href = e[0]
			title = e[1]
			season = re.compile('season\\[(\\d+)\\]').findall(href)
			season = int(season[0]) if season else ''
			episode = re.compile('episode\\[(\\d+)\\]').findall(href)
			episode = int(episode[0]) if episode else ''
			th = { 'href'  : href,
					'season' : season,
					'episode' : episode,
					'mediatype': 'episode',
					'title' : 'S%02dE%02d %s'%(season,episode, PLchar(title.strip()))}
			out.append(th)
	return out

