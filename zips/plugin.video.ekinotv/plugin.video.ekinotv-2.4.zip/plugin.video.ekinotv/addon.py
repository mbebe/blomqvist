# -*- coding: utf-8 -*-

import sys,os,re
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import resolveurl as urlresolver
import time
import ekinotvpl as ekinotv

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
my_addon = xbmcaddon.Addon()

def addDir(name,mode='',kateg='',wersja='',page='1',ex_link=None,infoLabels=None,iconImage='DefaultFolder.png'):
	url = buildUrl({'mode': mode, 'foldername': name, 'ex_link' : ex_link,'kat' : kateg,'wer' : wersja,'page' : page,'iconImage':iconImage})
	liz = xbmcgui.ListItem(name)
	art_keys=['thumb','poster','banner','clearart','clearlogo','icon']
	art = dict(zip(art_keys,[iconImage for x in art_keys]))
	liz.setArt(art)
	if not infoLabels:
		infoLabels={'Title': name}
	liz.setInfo(type='Video', infoLabels=infoLabels)
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=liz, isFolder=True)
def buildUrl(query):
	return base_url + '?' + urllib.urlencode(query)
def getLinks(ex_link):
	(hostEK,out)=ekinotv.getVideos(ex_link)
	link=''
	select = xbmcgui.Dialog().select('Wybierz źródło', hostEK)
	if select>-1:
		content = ekinotv.getStreams(hostEK[select],out[select])
		if content:
			if 'verystream' in content:
				link=ekinotv.getverystream(content)	
			else:
				try:
				
					link = urlresolver.resolve(content)
				except Exception,e:
					link=''
					s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Mo\xc5\xbce inny link b\xc4\x99dzie dzia\xc5\x82a\xc5\x82?','URL resolver ERROR: [%s]'%str(e))
			if link:
				xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=link))
			else:
				s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Mo\xc5\xbce inny link b\xc4\x99dzie dzia\xc5\x82a\xc5\x82?')
	else:
		xbmc.executebuiltin('XBMC.Container.Refresh()')

def addLinkItem(name, url, mode, l1_ef_='DefaultFolder.png', infoLabels={}, IsPlayable=True, fanart=None, kateg='',wersja='',page='1'):
	u = buildUrl({'mode': mode, 'foldername': name, 'ex_link' : url,'kat' : kateg,'wer' : wersja,'page' : page})
	li = xbmcgui.ListItem(name)
	art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
	art = dict(zip(art_keys,[l1_ef_ for x in art_keys]))
	art['landscape'] = fanart if fanart else art['landscape']
	li.setArt(art)
	if not infoLabels:
		infoLabels={'Title': name}
	li.setInfo(type='Video', infoLabels=infoLabels)
	if IsPlayable:
		li.setProperty('IsPlayable', 'true')
	if fanart:
		li.setProperty('fanart_image',fanart)
	isp = []
	isp.append(('Informacja', 'XBMC.Action(Info)'))
	li.addContextMenuItems(isp, replaceItems=False)
	ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=li)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = '%R,%Y,%P')
	#return ok
def getFilmy(kateg,wersja,page,ex_link):

	itemLink,itemLink2= ekinotv.getCategory(kateg=kateg,wersja=wersja, page=page,url=ex_link)
	if int(page)>1:
		addLinkItem('[COLOR gold]<< Poprzednia Strona %d <<[/COLOR]' %(int(page)-1), url=ex_link , mode='__page__', kateg=kateg,wersja=wersja,page= int(page)-1, IsPlayable=False)
	for p in itemLink:
		addLinkItem(name=p['title'],url=p['href'],mode='ChooseAndPlay',l1_ef_=p['img'],infoLabels=p,fanart=p['img'])
	addLinkItem('[COLOR gold]>> Następna Strona %d >>[/COLOR]' %(int(page)+1), url=ex_link , mode='__page__', kateg=kateg,wersja=wersja,page= int(page)+1, IsPlayable=False)
	xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_GENRE )
	xbmcplugin.endOfDirectory(addon_handle)	
def getTestPlay(ex_link):
	if 'openload.co/stream' in ex_link:
		link=ex_link
	else:
		link = urlresolver.resolve(ex_link)
	if link:
		listitem = xbmcgui.ListItem(path=link)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem)
xbmcplugin.setContent(addon_handle, 'movies')
mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
kateg = args.get('kat',[''])[0]
wersja = args.get('wer',[''])[0]
page = args.get('page',[''])[0]
rys = args.get('iconImage',[''])[0]
def getLangType():
	langtype=['Napisy','Lektor','Dubbing','ENG','PL']
	versType=''
	for w in langtype:
		if my_addon.getSetting(w)=='true':
			if versType:
				versType += ','
			versType += w
	return versType
versType  = getLangType()

if mode is None:
	ekinotv.cfandsave()
	addDir('[COLOR blue]Filmy[/COLOR]',mode='filmy',kateg='',wersja=versType)
	addDir('Filmy HD',mode='filmy',kateg='35',wersja=versType)
	addDir('Filmy 3D',mode='filmy',kateg='36',wersja=versType)
	addDir('Filmy Dla Dzieci HD',mode='filmy',kateg='2,3,5,6',wersja=versType)
	addDir('Filmy [Kategoria]',mode='filmy_kategoria',kateg='',wersja=versType)
	addDir('[COLOR blue]Seriale Katalog[/COLOR]',mode='seriale_ktalog')
	addDir('[COLOR green]Szukaj[/COLOR]',mode='szukaj')
	url = buildUrl({'mode': 'Opcje'})
	liz = xbmcgui.ListItem(label = '-=Opcje=-', iconImage='DefaultScript.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=liz)
	xbmcplugin.endOfDirectory(addon_handle)		
elif mode[0] == '__page__':
	url = buildUrl({'mode': 'filmy', 'foldername': '', 'ex_link' : ex_link,'kat' : kateg,'wer' : wersja,'page' : page})
	xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
	xbmcplugin.endOfDirectory(addon_handle)	
elif mode[0] == 'testPlay':
	getTestPlay(ex_link)

elif mode[0] == 'ChooseAndPlay':
	getLinks(ex_link)

elif mode[0] == 'Opcje':
	my_addon.openSettings()
	xbmc.executebuiltin("Container.Refresh") 
elif mode[0]=='filmy':
	getFilmy(kateg,wersja,page,ex_link)
	xbmcplugin.endOfDirectory(addon_handle)	
	
elif mode[0]=='filmy_kategoria':
	data = ekinotv.getFilmCat()
	select = xbmcgui.Dialog().select('Wybierz:', data[0])
	if select>-1:
		getFilmy(data[1][select],wersja,page,ex_link)
		
elif mode[0]=='szukaj':
	dialog = xbmcgui.Dialog()
	d = dialog.input('Szukaj, Podaj tytu\xc5\x82 filmu', type=xbmcgui.INPUT_ALPHANUM)
	if d:

		itemLink,itemLink2 = ekinotv.search(d.replace(' ','%20'))
		for p in itemLink:
			addLinkItem(p['title'],p['href'],'ChooseAndPlay',p['img'],p)
		for p in itemLink2:
			addDir(p.get('title'),ex_link=p.get('href'),mode='epizody',infoLabels=p,iconImage=p.get('img'))
		xbmcplugin.endOfDirectory(addon_handle)
	else:
		quit()
elif mode[0]=='seriale_ktalog':
	itemLink = ekinotv.getSerKat()
	for p in itemLink:
		addDir(p.get('title'),ex_link=p.get('href'),mode='seriale')
	xbmcplugin.endOfDirectory(addon_handle)		
	
elif mode[0]=='seriale':
	itemLink,itemLink2 = ekinotv.getSeriale(ex_link)
	for p in itemLink2:
		addDir(p.get('title'),ex_link=p.get('href'),mode='epizody',infoLabels=p,iconImage=p.get('img'))
	xbmcplugin.endOfDirectory(addon_handle)		
	
elif mode[0]=='epizody':
	itemLink = ekinotv.getEpisode(ex_link)
	for p in itemLink:
		addLinkItem(p['title'],p['href'],'ChooseAndPlay',rys,p)
	xbmcplugin.endOfDirectory(addon_handle)
