# -*- coding: utf-8 -*-

import sys,os,re
import urllib,urllib2
import urlparse
import requests
import cookielib
import cloudflare3
import xbmcaddon
import xbmc

addon = xbmcaddon.Addon()
PATH			= addon.getAddonInfo('path')
DATAPATH		= xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES	   = PATH+'/resources/'
COOKIEFILE = os.path.join(RESOURCES,'ekino.cookie')
s = requests.Session()
s.cookies = cookielib.LWPCookieJar(COOKIEFILE)

baseurl='http://ekino-tv.pl'
UA='Mozilla/5.0 (Windows NT 6.1; rv:22.0) Gecko/20100101 Firefox/22.0'
s.headers.update({'User-Agent': UA})

def PLchar(letter):
	if isinstance(letter, unicode):
		letter = letter.encode('utf-8')
	letter = letter.replace('&lt;br/&gt;',' ')
	letter = letter.replace('&nbsp;','')
	s='JiNcZCs7'
	letter = re.sub(s.decode('base64'),'',letter)
	letter = letter.replace('&mdash;','-') #.replace('&Oacute;','Ó')
	letter = letter.replace('&iacute;','í').replace('&Iacute;','Í')	
	letter = letter.replace('&bdquo;','„').replace('&rdquo;','”')
	letter = letter.replace('&aacute;','á').replace('&Aacute;','Á')	
	letter = letter.replace('&quot;','"').replace('&amp;quot;','"')
	letter = letter.replace('&oacute;','ó').replace('&Oacute;','Ó')
	letter = letter.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
	letter = letter.replace('&amp;','&')
	letter = letter.replace('\u0105','ą').replace('\u0104','Ą')
	letter = letter.replace('\u0107','ć').replace('\u0106','Ć')
	letter = letter.replace('\u0119','ę').replace('\u0118','Ę')
	letter = letter.replace('\u0142','ł').replace('\u0141','Ł')
	letter = letter.replace('\u0144','ń').replace('\u0144','Ń')
	letter = letter.replace('\u00f3','ó').replace('\u00d3','Ó')
	letter = letter.replace('\u015b','ś').replace('\u015a','Ś')
	letter = letter.replace('\u017a','ź').replace('\u0179','Ź')
	letter = letter.replace('\u017c','ż').replace('\u017b','Ż')
	return letter
	
def getUrl(url,data=None):
	if os.path.isfile(COOKIEFILE):
		s.cookies.load()
	s.headers.update({'User-Agent': UA})
	aa=s.cookies
	my_cookies = requests.utils.dict_from_cookiejar(aa)
	found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]
	kukz= ';'.join(found)	
	content=s.get(url,verify=False).content	
	return content,kukz	
	
	
	
	#content=s.get(url,verify=False).content
	#return content
	
def cfandsave():
	s.headers.update({'User-Agent': UA})
	url_test = baseurl
	check = s.get(url_test)
	cf = cloudflare3.Cloudflare(url_test,check)
	cookies = {}
	verifyGet = ''
	if cf.is_cloudflare:
		authUrl = cf.get_url()
		makeAuth = s.get(authUrl)
		getCookies = s.get(url_test)
		cookies = s.cookies #.get_dict()	
		if cookies:
			s.cookies.save()		
	return
	
def getCategory(kateg='',wersja='', page='1', url='http://ekino-tv.pl/movie/cat/'):
	if kateg or wersja:
		urlEK = 'http://ekino-tv.pl/movie/cat/kategoria[%s]+wersja[%s]+strona[%s]+' %(kateg,wersja,page)
	else:
		urlEK = url
	print urlEK
	content,kuk  = getUrl(urlEK)
	out,out2=getContent(content,kuk)
	return out,out2
	
def getContent(content,kuk):
	idx = [(a.start(), a.end()) for a in re.finditer('<div class="movies-list-item"', content)]
	idx.append( (-1,-1) )
	res=[]
	reser=[]
	for i in range(len(idx[:-1])):
		match = content[ idx[i][1]:idx[i+1][0] ]
		imag = re.compile('<img src="(/static/thumb/.*.jpg)" alt=').findall(match)
		title = re.compile('<div class="title">[\\s]*<a href="(.*?)">(.*?)</a><br>').findall(match)
		plot = re.compile('<div class="movieDesc">[\\s\n]*(.*?)</div>').findall(match)
		rating = re.compile('<div class="sum-vote"><[^>]*>([^>]*)</div>').findall(match)
		year = re.compile('<p class="cates">(.*) \\|').findall(match)
		categ = re.compile('<p class="cates">(.*) \\| (<a href="/movie/cat/kategoria\\[\\d+\\]">.*</a>[,]*)*</p>').findall(match)
		infocat = re.compile('<div class="info-categories"(.*?)</div>',re.DOTALL).findall(match)
		href=title[0][0]
		if infocat:
			infocat = ''.join(re.compile('>(.*?)<').findall(infocat[0]))
		if title:
			out={}
			out['href'] = href
			out['title'] = PLchar(title[0][1].replace('- HD','')).strip('\n ')
			out['year'] = year[0] if year else ''
			out['genre'] = ''.join(re.compile('>(.*?)<').findall(categ[0][1])) if categ else ''
			out['code'] = 'HD' if 'HD' in out['genre'] else ''
			out['plot'] = PLchar(plot[0].strip('\n ')) if plot else ''
			out['rating'] = rating[0].strip() if rating else ''
			out['img'] = baseurl+imag[0].replace('/thumb/','/normal/')+'|User-Agent='+urllib.quote(UA)+'&Referer='+baseurl+'&Cookie='+urllib.quote(kuk) if imag else ''
			if '/serie/show/' in href:
				reser.append(out)
			else:
				res.append(out)				
	return res,reser
def getVideos(url='http://ekino-tv.pl/movie/show/moj-przyjaciel-smok-hd-petes-dragon-2016-dubbing/19887'):
	if not url.startswith('http:'):
		url = urlparse.urljoin(baseurl,url)
	content,kuk  = getUrl(url)
	subset = re.compile('ShowPlayer\\(["\'](.*?)["\'],["\'](.*?)["\']\\)').findall(content)
	hostEK=[]
	out=[]
	for host,content in subset:
		out.append(content)
		hostEK.append(host)
	return (hostEK,out)
	
def getStreams(host='openload',id='cHl1ZUV5T3hBeTltR1VwPQclmn'):
	streams=''
	url=urlparse.urljoin(baseurl,'/watch/f/') + host + '/' + id
	content,kuk   = getUrl(url)
	content = re.compile('var url\\s*=\\s*[\'"](.*?)[\'"]').findall(content)
	if content:
		if content[0].startswith('/watch.php?'):
			data,kuk   = getUrl(urlparse.urljoin(baseurl,content[0]) )
			item = re.findall('src=["\'](http.*?)["\']',data,re.I)
			for s in item:
				streams = s
				if 'host' in streams:
					break
		else:
			streams= content[0]
	return streams
def _1ll1ll1_ef_(url='/movie/show/partyzant-napisy-pl-partisan-2015-napisy/7909'):
	content,kuk   = getUrl(baseurl+url)
	subset = re.compile('<iframe(.*)></iframe>\n', re.DOTALL).findall(content)
	hostEK=[]
	out=[]
	for f in subset:
		itemEK = re.compile('src="(.*?)"', re.DOTALL).findall(content)
		for th in itemEK:
			if 'hosting=vshare' in th:
				th='http://vshare.io/v/%s/width-640/height-400/'  % (th.split('=')[-1])
			if th.startswith('http'):
				out.append(th)
				hostEK.append(th.split('/')[2])
	return (hostEK,out)
def getFilmCat(url='http://ekino-tv.pl/movie/cat/'):
	content,kuk   = getUrl(url)
	match = re.compile('<li data-id="(\\d+)">[\\s\n]+<a href="/movie/cat/kategoria\\[\\d+\\]">(.*?)</a>[\\s\n]*</li>').findall(content)
	catNumb = [x[0] for x in match]
	catNameEK = [x[1] for x in match]
	return (catNameEK,catNumb)
def search(phrase='Piraci'):
	urlk='http://ekino-tv.pl/s/search?q='+phrase	
	contentz,kuk  = getUrl(urlk)
	return getContent(contentz,kuk)
def getSeriale(url='/serie/catalog/W'):
	content,kuk   = getUrl(baseurl+url)
	out = getContent(content,kuk)
	return out
def getSerKat():
	content,kuk   = getUrl('http://ekino-tv.pl/serie/')
	match = re.compile('<ul class="serialsmenu">(.*?)</ul>',re.DOTALL).findall(content)
	out=[]
	if match:
		items = re.compile('<a href="(.*?)"><span class="name">(.*?)</span><span class="count">(.*?)</span></a>').findall(match[0])
		for item in items:
			out.append({'href':item[0],'title':'%s ([COLOR blue]%s[/COLOR])'%(item[1],item[2])})
	return out
def getEpisode(url):
	content,kuk  = getUrl(baseurl+url)
	match = re.compile('<ul class="list-series">(.*?)</ul>',re.DOTALL).findall(content)
	out=[]
	for tEK in match:
		match2 = re.compile('<a href="(.*?)">(.*?)</a>').findall(tEK)
		for e in match2:
			href = e[0]
			title = e[1]
			season = re.compile('season\\[(\\d+)\\]').findall(href)
			season = int(season[0]) if season else ''
			episode = re.compile('episode\\[(\\d+)\\]').findall(href)
			episode = int(episode[0]) if episode else ''
			th = { 'href'  : href,
					'season' : season,
					'episode' : episode,
					'mediatype': 'episode',
					'title' : 'S%02dE%02d %s'%(season,episode, PLchar(title.strip()))}
			out.append(th)
	return out

