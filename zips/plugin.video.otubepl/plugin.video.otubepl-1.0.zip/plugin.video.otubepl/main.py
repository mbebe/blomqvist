# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl

import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM

import urlparse

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.otubepl')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'

FANART=RESOURCES+'../fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('name', None)
page = params.get('page','')
mcount= params.get('moviescount', None)
movie= params.get('movie', None)
rys= params.get('image', None)

katv = addon.getSetting('katV')
if not katv:
	addon.setSetting('katV','')
katn = addon.getSetting('katN') if katv else 'Wszystkie'

rokv = addon.getSetting('rokV')
if not rokv:
	addon.setSetting('rokV','')
rokn = addon.getSetting('rokN') if rokv else 'Wszystkie'



UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'
TIMEOUT=15
main_url='https://otube.pl/filmy-online-pl/'
s = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=1,fanart=FANART,moviescount=0):
	list_item = xbmcgui.ListItem(label=name)

	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')
	if not infoLabels:
		infoLabels={'title': name,'plot':name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': FANART})
	ok=xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page, 'moviescount' : moviescount,'movie':movie,'name':name,'image':image}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	return ok

def home():

	add_item('', "-        [COLOR lime]Rok produkcji:[/COLOR] [B]"+rokn+"[/B]",'DefaultRecentlyAddedMovies.png', "filtr:rok", folder=False)	
	add_item('', "-        [COLOR lime]Kategorie:[/COLOR] [B]"+katn+"[/B]",'DefaultRecentlyAddedMovies.png', "filtr:kateg", folder=False)
	add_item('', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "listFilmy", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "listSeriale", folder=True,fanart=RESOURCES+'fanart.png')

	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "listSearch", folder=True,fanart=RESOURCES+'fanart.png')

	
def getRequests(url):
	headers = {
		'User-Agent': UA,
		'Accept': 'text/html, */*; q=0.01',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'X-Requested-With': 'XMLHttpRequest',
		'Connection': 'keep-alive',
	}
	content=s.get(url,headers=headers,verify=False).content
	return content
	
	
def ListSeriale(url,pg):
	page = int(pg)
	links, pagin=getSeriale(url,page)	
	itemz=links
	items = len(links)
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listLinks', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	if pagin:
		for f in pagin:	
			add_item(name=f.get('title'), url=f.get('href'), mode='listSeriale', image='', folder=True,page=f.get('page'))	

	xbmcplugin.endOfDirectory(addon_handle)	
	
def getSeriale(url,page):
	out=[]
	npout=[]
	url = 'https://otube.pl/seriale-online/?page=%s'%page
	html=getRequests(url)	
	lastpage=re.findall("data-pagenumber='(\d+)'>Ostatnia<",html,re.DOTALL)
	if lastpage:
		if page<int(lastpage[-1]):
			npout.append({'title':'NEXT_PAGE','href':'','img':'','plot':'','page':page+1}) 
	result = parseDOM(html,'div', attrs={'id': "item-list"})[0]
	links = parseDOM(result,'div', attrs={'class': "col-sm-4"})
	for link in links:
		href= parseDOM(link, 'a', ret='href')[0]
		imag= parseDOM(link, 'img', ret='src')[0]
		tytul = parseDOM(link,'div', attrs={'class': "title"})[0]
		plot = parseDOM(link,'div', attrs={'class': "description.+?"})[0]
		out.append({'title':PLchar(tytul),'href':href,'img':imag,'plot':PLchar(plot),'code':''})
	return out,npout	
	
def ListFilmy(url,pg,katv,rokv):
	page = int(pg)
	links, pagin=getFilmy(url,page,katv,rokv)	
	itemz=links
	items = len(links)
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listLinks', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	if pagin:
		for f in pagin:	
			add_item(name=f.get('title'), url=f.get('href'), mode='listFilmy', image='', folder=True,page=f.get('page'))	

	xbmcplugin.endOfDirectory(addon_handle)		
	
def getFilmy(url,page,katg,rokg):
	out=[]
	npout=[]
	
	if 'Wszystkie' in katn and 'Wszystkie' in rokn:
		url='https://otube.pl/filmy-online-pl/?page=%d'%page
	else:
		if 'Wszystkie' in katn:
			katg=''
		else:
			katg = katg+'/'
		if 'Wszystkie' in rokn:
			rokg=''
		else:
			rokg = rokg
		url='https://otube.pl/filmy-online/%s%s?page=%d'%(katg,rokg,page)
	html=getRequests(url)	
	lastpage=re.findall("data-pagenumber='(\d+)'>Ostatnia<",html,re.DOTALL)
	if lastpage:
		if page<int(lastpage[-1]):
			npout.append({'title':'NEXT_PAGE','href':'','img':'','plot':'','page':page+1}) 
	result = parseDOM(html,'div', attrs={'id': "item-list"})[0]
	links = parseDOM(result,'div', attrs={'class': "col-sm-6"})
	for link in links:
		href= parseDOM(link, 'a', ret='href')[0]
		imag= parseDOM(link, 'img', ret='src')[0]
		tytul = parseDOM(link,'div', attrs={'class': "title"})[0]
		plot = parseDOM(link,'div', attrs={'class': "description.+?"})[0]
		out.append({'title':PLchar(tytul),'href':href,'img':imag,'plot':PLchar(plot),'code':''})
	return out,npout
	
def ListLinks(url,movie,rys,nme): 
	movies, seasons=getLinks(url,movie,rys,nme)
	if movies or seasons:
		if movies:
			itemz=movies
			items = len(movies)
			fold=False
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode='playVideo', image=f.get('img'), IsPlayable=True, folder=False, infoLabels=f, itemcount=items)	
		elif seasons:
			items = len(seasons)
			for i in sorted(seasons.keys()):
				add_item(name=nme+' - '+i, url=urllib.quote(str(seasons[i])), mode='getEpisodesLosmovies', image=rys, folder=True,  infoLabels=i, itemcount=items)	
		xbmcplugin.setContent(addon_handle, 'videos')
		xbmcplugin.endOfDirectory(addon_handle)	
	else:
		xbmcgui.Dialog().notification('[COLOR red][B]Błąd[/B][/COLOR]', "[COLOR red][B]Brak materiałów do wyświetlenia.[/B][/COLOR]", xbmcgui.NOTIFICATION_INFO, 5000)

def getLinks(url,movie,rys,nme):

	html=getRequests(url)
	plot = parseDOM(html,'p', attrs={'class': "description"})
	plot = PLchar(plot[0]) if plot else ''

	nme = PLchar(nme)
	movs=[]
	seasons=None
	resultsez=parseDOM(html,'div', attrs={'class': ".+?seriesInfo"})
	resultsez=parseDOM(html,'ul', attrs={'id': "episode-list"})
	if resultsez:
		result = resultsez[0]
		episodes = scanEpisodes(result,url,rys,plot)

		seasons = splitToSeasons(episodes)

	else:
		result=parseDOM(html,'div', attrs={'class': "link-table-wrapper"})[0]
		links=parseDOM(result,'tr', attrs={'class': "link-.+?"})
		co=1
		
		for link in links:
			href = parseDOM(link,'a', ret="href")[0]
			host = parseDOM(link,'img', ret="alt")[0].strip()
			tytul = '%s - [COLOR violet](%s)[/COLOR]'%(nme,PLchar(host))
			typjakosc = parseDOM(link,'td')
			code = typjakosc[0]+','+typjakosc[1]
			movs.append({'title':tytul,'href':href,'img':rys,'code':code,'plot':plot})
			co+=1
	return movs,seasons
	
def scanEpisodes(result,url,imag,plot):
	out=[]
	links = re.findall('<span>(.+?)</ul>',result,re.DOTALL)
	for link in links:
		ses = re.findall('ezon\s*(\d+)',link)[0]

		eps = parseDOM(link,'li')
		for ep in eps:
			href = parseDOM(ep,'a', ret='href')[0]
			tyt = parseDOM(ep,'a')[-1]
			try:
			
				epis = re.findall('dcinek\s*(\d+)',ep)[-1]
			except:
				epis = re.findall('e(\d+)\]',ep)[-1]
			out.append({'title':tyt,'href':href,'img':imag,'code':'','plot':plot,'season':int(ses),'episode':int(epis)})
	return out

def splitToSeasons(input):
    out={}
    seasons = [x.get('season') for x in input]
    for s in set(seasons):
        out['Sezon %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
	
def getEpisodesLosmovies(seasons,nme):
	episodes = eval(urllib.unquote(seasons))[::-1]
	items=len(episodes)

	for f in episodes: 
		ses=f.get('season')
		epp=f.get('episode')
		tyt=f.get('title').split('Season')[0]
		tyt2 = '%s - odc.%02d'%(nme,epp)
		add_item(name=tyt2, url=f.get('href'), mode='listLinks', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)

def ListSearch(pg):
	d = xbmcgui.Dialog().input(u'Szukaj...', type=xbmcgui.INPUT_ALPHANUM)
	if d:
		d = d.replace(' ','+')
		movies,serials = getSearch(d)
		if movies:
			itemz=movies
			items = len(movies)
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode='listLinks', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)
		if serials:
			itemz=serials
			items = len(serials)

			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode='listLinks', image=f.get('img'), folder=True, infoLabels=f, itemcount=items,movie=False)	
		if not serials and not movies:
			return
		else:
			xbmcplugin.endOfDirectory(addon_handle)	
def getSearch(d):
	fout=[]
	sout=[]

	url='https://otube.pl/wyszukiwarka?phrase=%s'%d

	html=getRequests(url)

	links = parseDOM(html,'div', attrs={'class': "col-sm-4"})#[0]
	for link in links:
		href = parseDOM(link,'a', ret='href')[0]#attrs={'class': "col-sm-4"})#[0]
		tyt = parseDOM(link,'div', attrs={'class': "title"})[0]
		plot = parseDOM(link,'div', attrs={'class': "description.+?"})#[0]
		plot = plot[0] if plot else ''
		imag = parseDOM(link,'img', ret='src')[0]
		imag = imag.replace('/thumb/','/big/')
		if 'serial-online' in href:
			sout.append({'title':'[COLOR yellowgreen](serial)[/COLOR] '+PLchar(tyt),'href':href,'img':imag,'plot':PLchar(plot),'code':''})
		else:
			fout.append({'title':PLchar(tyt),'href':href,'img':imag,'plot':PLchar(plot),'code':''})
	return fout,sout

def PlayVideo(link):
	import resolveurl
	try:
		hmf = resolveurl.HostedMediaFile(url=link)
		if not hmf:
			xbmcgui.Dialog().notification('[COLOR red][B]Error[/B][/COLOR]', "[COLOR red][B]Can't resolve this link.[/B][/COLOR]", xbmcgui.NOTIFICATION_INFO, 5000)
			return
		else:
			stream_url = resolveurl.resolve(link)
	except Exception,e:
		stream_url=''
		s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))
	
	if stream_url:
		play_item = xbmcgui.ListItem(path=stream_url)
		xbmcplugin.setResolvedUrl(addon_handle, True, play_item)	
	else:
		xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&#039;',"'")
	char = char.replace('&quot;','"').replace('&oacute;','ó').replace('&rsquo;',"'")
	char = char.replace('&nbsp;',".").replace('&amp;','&').replace('&eacute;','e')
	return char	
			
def Play365(url):	
	stream_url,napis = Play3651st(url)	
	play_item = xbmcgui.ListItem(path=stream_url)
	if napis:
		play_item.setSubtitles([napisy])
	if stream_url:
		xbmcplugin.setResolvedUrl(addon_handle, True, play_item)	
	else:
		xbmcplugin.setResolvedUrl(addon_handle, False,  xbmcgui.ListItem(path=''))	

if __name__ == '__main__':
	mode = params.get('mode', None)
	
	if not mode:
		home()
		xbmcplugin.endOfDirectory(addon_handle)		

	elif mode == 'listFilmy':
		ListFilmy(exlink,page,katv,rokv)		
		
	elif mode == 'listSeriale':
		ListSeriale(exlink,page)

	elif mode == 'listLinks':
		ListLinks(exlink,movie,rys,name)	
			
	elif mode == 'playVideo':
		PlayVideo(exlink)		
		
	elif mode == 'listLinkslosmovies':
		ListLinksLosmovies(exlink)	
	elif mode == 'listLinksSerial':
		ListLinksSerial(exlink)	
		
	elif mode == 'listSearch':
		ListSearch(page)			
	
	elif 'kateg' in mode:
		myMode = 'kat'
		label = ['Wszystkie','Akcja', 'Animacja', 'Anime', 'Ba\xc5\x9b\xc5\x84', 'Biblijny', 'Biograficzny', 'Czarna komedia', 'Dla dzieci', 'Dla m\xc5\x82odzie\xc5\xbcy', 'Dokumentalizowany', 'Dokumentalny', 'Dramat', 'Dramat historyczny', 'Dramat obyczajowy', 'Dramat s\xc4\x85dowy', 'Dramat spo\xc5\x82eczny', 'Dreszczowiec', 'Edukacyjny', 'Erotyczny', 'Etiuda', 'Fabularyzowany dok.', 'Familijny', 'Fantasy', 'Film-Noir', 'Gangsterski', 'Groteska filmowa', 'Historyczny', 'Horror', 'Karate', 'Katastroficzny', 'Komedia', 'Komedia kryminalna', 'Komedia obycz.', 'Komedia rom.', 'Kostiumowy', 'Kr\xc3\xb3tkometra\xc5\xbcowy', 'Krymina\xc5\x82', 'Melodramat', 'Musical', 'Muzyczny', 'Niemy', 'Nowele filmowe', 'Obyczajowy', 'P\xc5\x82aszcza i szpady', 'Poetycki', 'Polityczny', 'Przygodowy', 'Przyrodniczy', 'Psychologiczny', 'Religijny', 'Romans', 'Satyra', 'Sci-Fi', 'Sensacyjny', 'Sportowy', 'Surrealistyczny', 'Szpiegowski', 'Sztuki walki', 'Thriller', 'Western', 'Wojenny', 'XXX']
		value=['','1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '25', '26', '27', '28', '29', '30', '31', '32', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '53', '46', '47', '50', '51', '52', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66']
		ex_link='category'
		msg = 'kategorie'
		
		try:
			sel = xbmcgui.Dialog().multiselect('Wybierz '+msg,label)
		except:
			sel = xbmcgui.Dialog().select('Wybierz '+msg,label)
		if not sel: sel=quit()
		if isinstance(sel,list):
			v = '%s:%s'%(ex_link,','.join( [ value[i] for i in sel])) if sel[0]>-1 else ''
			n = '%s'%','.join( [ label[i] for i in sel]) if sel[0]>-1 else ''
		else:
			sel = sel if sel>-1 else quit()
			v = '%s:%s'%(ex_link,value[sel])
			n = '%s'%(label[sel])
		addon.setSetting(myMode+'V',v)
		addon.setSetting(myMode+'N',n)		
		xbmc.executebuiltin("Container.Refresh") 	

	elif 'rok' in mode:
		myMode = 'rok'
		label = ['Wszystkie','2017', '2016', '2015', '2014', '2013', '2012', '2011', '2010', '2009', '2008', '2007', '2006', '2005', '2004', '2003', '2002', '2001', '2000', '1999', '1998', '1997', '1996', '1995', '1994', '1993', '1992', '1991', '1990', '1989', '1988', '1987', '1986', '1985', '1984', '1983', '1982', '1981', '1980', '1979', '1978', '1977', '1976', '1975', '1974', '1973', '1972', '1971', '1970', '1969', '1968', '1967', '1966', '1965', '1964', '1963', '1962', '1961', '1960', '1959', '1958', '1957', '1956', '1955', '1954', '1953', '1952', '1951', '1950', '1949', '1948', '1947', '1946', '1945', '1944', '1943', '1942', '1941', '1940', '1939', '1938', '1937', '1936', '1935', '1934', '1933', '1932', '1931', '1930', '1929', '1928', '1927', '1926', '1925', '1924', '1923', '1922', '1921', '1920', '1919', '1918', '1917', '1916', '1915', '1914', '1911', '1908', '1902']
		value=['','2017', '2016', '2015', '2014', '2013', '2012', '2011', '2010', '2009', '2008', '2007', '2006', '2005', '2004', '2003', '2002', '2001', '2000', '1999', '1998', '1997', '1996', '1995', '1994', '1993', '1992', '1991', '1990', '1989', '1988', '1987', '1986', '1985', '1984', '1983', '1982', '1981', '1980', '1979', '1978', '1977', '1976', '1975', '1974', '1973', '1972', '1971', '1970', '1969', '1968', '1967', '1966', '1965', '1964', '1963', '1962', '1961', '1960', '1959', '1958', '1957', '1956', '1955', '1954', '1953', '1952', '1951', '1950', '1949', '1948', '1947', '1946', '1945', '1944', '1943', '1942', '1941', '1940', '1939', '1938', '1937', '1936', '1935', '1934', '1933', '1932', '1931', '1930', '1929', '1928', '1927', '1926', '1925', '1924', '1923', '1922', '1921', '1920', '1919', '1918', '1917', '1916', '1915', '1914', '1911', '1908', '1902']
		ex_link='year'
		msg = 'rok/lata produkcji'
		
		try:
			sel = xbmcgui.Dialog().multiselect('Wybierz '+msg,label)
		except:
			sel = xbmcgui.Dialog().select('Wybierz '+msg,label)
		if not sel: sel=quit()
		if isinstance(sel,list):
			v = '%s:%s'%(ex_link,','.join( [ value[i] for i in sel])) if sel[0]>-1 else ''
			n = '%s'%','.join( [ label[i] for i in sel]) if sel[0]>-1 else ''
		else:
			sel = sel if sel>-1 else quit()
			v = '%s:%s'%(ex_link,value[sel])
			n = '%s'%(label[sel])
		addon.setSetting(myMode+'V',v)
		addon.setSetting(myMode+'N',n)		
		xbmc.executebuiltin("Container.Refresh") 	
		
	elif mode == 'gatunek':
		myMode = 'kat'
		label = ['Akcja', 'Animacja', 'Anime', 'Ba\xc5\x9b\xc5\x84', 'Biblijny', 'Biograficzny', 'Czarna komedia', 'Dla dzieci', 'Dla m\xc5\x82odzie\xc5\xbcy', 'Dokumentalizowany', 'Dokumentalny', 'Dramat', 'Dramat historyczny', 'Dramat obyczajowy', 'Dramat s\xc4\x85dowy', 'Dramat spo\xc5\x82eczny', 'Dreszczowiec', 'Edukacyjny', 'Erotyczny', 'Etiuda', 'Fabularyzowany dok.', 'Familijny', 'Fantasy', 'Film-Noir', 'Gangsterski', 'Groteska filmowa', 'Historyczny', 'Horror', 'Karate', 'Katastroficzny', 'Komedia', 'Komedia kryminalna', 'Komedia obycz.', 'Komedia rom.', 'Kostiumowy', 'Kr\xc3\xb3tkometra\xc5\xbcowy', 'Krymina\xc5\x82', 'Melodramat', 'Musical', 'Muzyczny', 'Niemy', 'Nowele filmowe', 'Obyczajowy', 'P\xc5\x82aszcza i szpady', 'Poetycki', 'Polityczny', 'Przygodowy', 'Przyrodniczy', 'Psychologiczny', 'Religijny', 'Romans', 'Satyra', 'Sci-Fi', 'Sensacyjny', 'Sportowy', 'Surrealistyczny', 'Szpiegowski', 'Sztuki walki', 'Thriller', 'Western', 'Wojenny', 'XXX']
		value=['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '25', '26', '27', '28', '29', '30', '31', '32', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '53', '46', '47', '50', '51', '52', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66']
		ex_link='category'
		msg = 'kategorie'
		
		try:
			sel = xbmcgui.Dialog().multiselect('Wybierz '+msg,label)
		except:
			sel = xbmcgui.Dialog().select('Wybierz '+msg,label)
		if not sel: sel=quit()
		if isinstance(sel,list):
			v = '%s:%s'%(ex_link,','.join( [ value[i] for i in sel])) if sel[0]>-1 else ''
			n = '%s'%','.join( [ label[i] for i in sel]) if sel[0]>-1 else ''
		else:
			sel = sel if sel>-1 else quit()
			v = '%s:%s'%(ex_link,value[sel])
			n = '%s'%(label[sel])
		addon.setSetting(myMode+'V',v)
		addon.setSetting(myMode+'N',n)		
		xbmc.executebuiltin("Container.Refresh") 

	elif mode == 'getEpisodesLosmovies':	
		getEpisodesLosmovies(exlink,name)
		xbmcplugin.endOfDirectory(addon_handle,True)

