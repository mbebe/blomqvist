# -*- coding: utf-8 -*-

import sys , re , os
import urllib , urllib2
import urlparse , json

import xbmc , xbmcgui , xbmcaddon
import xbmcplugin

base_url = sys . argv [ 0 ]
addon_handle = int ( sys . argv [ 1 ] )
args = urlparse . parse_qs ( sys . argv [ 2 ] [ 1 : ] )
my_addon = xbmcaddon . Addon ( )
addonName = xbmcaddon . Addon ( ) . getAddonInfo ( 'name' )
my_addon_id = xbmcaddon . Addon ( ) . getAddonInfo ( 'id' )
PATH = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' )
DATAPATH = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'profile' ) ) . decode ( 'utf-8' )
RESOURCES = PATH + '/resources/'

FANART = PATH + '/fanart.jpg'
ICON = PATH + '/icon.png'

def addLinkItem ( name , url , mode , cat = '' , iconImage = None , infoLabels = False , IsPlayable = True , fanart = FANART , itemcount = 1 ) :
	u = build_url ( { 'mode' : mode , 'foldername' : name , 'ex_link' : url , 'cat' : cat } )
	liz = xbmcgui . ListItem ( name , iconImage = iconImage , thumbnailImage = iconImage )
	liz . setArt ( { 'poster' : infoLabels . get ( 'poster' , iconImage ) , 'thumb' : iconImage , 'icon' : iconImage , 'fanart' : infoLabels . get ( 'fanart' , iconImage ) , 'banner' : infoLabels . get ( 'banner' , iconImage ) } )
	infoLabels [ 'url' ] = str ( infoLabels . get ( 'url' ) )
	liz . setInfo ( type = "video" , infoLabels = infoLabels )
	if IsPlayable : liz . setProperty ( 'IsPlayable' , 'true' )
	if fanart : liz . setProperty ( 'fanart_image' , fanart )
	i1 = xbmcplugin . addDirectoryItem ( handle = addon_handle , url = u , listitem = liz , isFolder = False , totalItems = itemcount )
	xbmcplugin . addSortMethod ( addon_handle , sortMethod = xbmcplugin . SORT_METHOD_NONE , label2Mask = "%R, %Y, %P" )
	return i1
 
def addDir ( name , url = None , mode = '' , cat = '' , iconImage = ICON , fanart = FANART , infoLabels = { } , totalItems = 1 ) :
	u = build_url ( { 'mode' : mode , 'foldername' : name , 'ex_link' : url , 'cat' : cat } )
	print u
	if iconImage == None :
		iconImage = 'DefaultFolder.png'
	li = xbmcgui . ListItem ( label = name , iconImage = iconImage )
	li = xbmcgui . ListItem ( name , iconImage = iconImage , thumbnailImage = iconImage )
	li . setArt ( { 'poster' : infoLabels . get ( 'poster' , iconImage ) , 'thumb' : iconImage , 'icon' : iconImage , 'fanart' : infoLabels . get ( 'fanart' , iconImage ) , 'banner' : infoLabels . get ( 'banner' , iconImage ) } )
	if infoLabels : li . setInfo ( type = "video" , infoLabels = infoLabels )
	if fanart : li . setProperty ( 'fanart_image' , fanart )
	xbmcplugin . addDirectoryItem ( handle = addon_handle , url = u , listitem = li , isFolder = True )
 
def encoded_dict ( in_dict ) :
	out_dict = { }
	for k , v in in_dict . iteritems ( ) :
		if isinstance ( v , unicode ) :
			v = v . encode ( 'utf8' )
		elif isinstance ( v , str ) :
			v . decode ( 'utf8' )
		out_dict [ k ] = v
	return out_dict
 
def build_url ( query ) :
	return base_url + '?' + urllib . urlencode ( encoded_dict ( query ) )
 
def play ( url ) :
	qual = url . keys ( ) ;
	stream_url = url . get ( qual [ 0 ] ) if qual else ''
	select = xbmcgui . Dialog ( ) . select ( 'Jakość' , qual )
	if select > - 1 : stream_url = url . get ( qual [ select ] )
	if stream_url : xbmcplugin . setResolvedUrl ( addon_handle , True , xbmcgui . ListItem ( path = stream_url ) )
	else : xbmcplugin . setResolvedUrl ( addon_handle , False , xbmcgui . ListItem ( path = '' ) )
 
def getUrl ( url ) :
	req = urllib2 . Request ( url , data = None , headers = { 'User-Agent' : 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.472.63 Safari/534.3' } )
	try :
		response = urllib2 . urlopen ( req , timeout = 10 )
		link = response . read ( )
		response . close ( )
	except :
		link = ''
	return link
 
def tvn24 ( url = 'http://www.tvn24.pl/wideo/z-anteny/' , category = 'cat20535' ) :
	content = getUrl ( url )
	out = [ ]
	if not category :
		navList = re . compile ( '<ul class="nav nav-list">(.*?)</ul>' , re . DOTALL ) . findall ( content )
		if navList :
			for li in re . compile ( '<li(.*?)</li>' , re . DOTALL ) . findall ( navList [ 0 ] ) :
				hrefTitle = re . compile ( '<a id="(.*?)"[^>]*>(.*?)</a>' ) . findall ( li )
				out . append ( { 'url' : hrefTitle [ 0 ] [ 0 ] ,
								'title' : hrefTitle [ 0 ] [ 1 ] . replace ( '&quot;' , '"' ) } )
	else :
		id = re . compile ( '<ul id="%s(.*?)</ul>' % category , re . DOTALL ) . findall ( content )
		if id :
			items = re . compile ( '<li(.*?)</li>' , re . DOTALL ) . findall ( id [ 0 ] )
   
			for item in items :
				title = re . compile ( '<h2 class="title-cont">(.*?)\n' ) . findall ( item )
				code = re . compile ( '<span class="date-time" >(.*?)\n' ) . findall ( item )
				imag = re . compile ( 'data-poster="(.*?)"' ) . findall ( item )
				plot = re . compile ( '<span class="data-long-desc">(.*?)<' , re . DOTALL ) . findall ( item )
				href = re . compile ( 'data-quality="(.*?)"' , re . DOTALL ) . findall ( item )
				href = json . loads ( href [ 0 ] . replace ( '&quot;' , '"' ) ) if href else { }
				if href and title :
					out . append ( { 'title' : title [ 0 ] . replace ( '&quot;' , '' ) if title else '' ,
									'img' : imag [ 0 ] if imag else '' ,
									'code' : code [ 0 ] if code else '' ,
									'plot' : plot [ 0 ] . strip ( ) if plot else '' ,
									'url' : href ,
									} )
	return out
 
mode = args . get ( 'mode' , None )
fname = args . get ( 'foldername' , [ '' ] ) [ 0 ]
ex_link = args . get ( 'ex_link' , [ '' ] ) [ 0 ]
cat = args . get ( 'cat' , [ '' ] ) [ 0 ]

if mode is None :
	addDir ( 'TVN24 Informacje' , 'http://www.tvn24.pl/wideo/z-anteny/' , mode = 'getFolders' , iconImage = ICON )
	addDir ( 'TVN24 Magazyny' , 'http://www.tvn24.pl/wideo/magazyny/' , mode = 'getFolders' , iconImage = ICON )
 
elif mode [ 0 ] == 'getFolders' :
	data = tvn24 ( ex_link , '' )
	for d in data : addDir ( d . get ( 'title' ) , url = ex_link , cat = d . get ( 'url' ) , mode = 'getContent' , infoLabels = d , iconImage = d . get ( 'img' , ICON ) )
elif mode [ 0 ] == 'getContent' :
	data = tvn24 ( ex_link , cat )
	addLinkItem ( '[COLOR blue][B]%s[/B][/COLOR]' % fname , url = urllib . quote ( str ( data ) ) , mode = 'playAll' , infoLabels = { } , iconImage = ICON )
	for d in data : addLinkItem ( d . get ( 'title' ) , url = d . get ( 'url' ) , mode = 'play' , infoLabels = d , iconImage = d . get ( 'img' ) )
 
elif mode [ 0 ] == 'play' :
	play ( eval ( ex_link ) )
elif mode [ 0 ] == 'playAll' :
	data = eval ( urllib . unquote ( ex_link ) )
	qs = data [ 0 ] . get ( 'url' , { } ) . keys ( )
	s = xbmcgui . Dialog ( ) . select ( 'Jakość' , qs )
	quality = qs [ s ] if s > - 1 else qs [ 0 ]
	playlist = xbmc . PlayList ( xbmc . PLAYLIST_VIDEO )
	playlist . clear ( )
	for d in data :
		link = d . get ( 'url' , { } ) . get ( quality )
		if link : playlist . add ( url = link , listitem = xbmcgui . ListItem ( d . get ( 'title' , '' ) ) )
		if len ( playlist ) == 1 : playlist . add ( url = link , listitem = xbmcgui . ListItem ( d . get ( 'title' , '' ) ) )
	if playlist :
		xbmcplugin . setResolvedUrl ( addon_handle , True , xbmcgui . ListItem ( path = '' ) )
	else :
		xbmcplugin . setResolvedUrl ( addon_handle , False , xbmcgui . ListItem ( path = '' ) )
else :
	xbmcplugin . setResolvedUrl ( addon_handle , False , xbmcgui . ListItem ( path = '' ) )
 
xbmcplugin . endOfDirectory ( addon_handle )


