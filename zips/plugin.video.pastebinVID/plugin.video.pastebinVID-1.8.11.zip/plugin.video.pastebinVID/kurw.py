# -*- coding: utf-8 -*-
import requests
#/\/\/\/\/\/\/\/\/\/\/\

#/\/\/\/\/\/\/\/\/\/\/\

#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\

import re,sys

#/\/\/\/\/\/\/\/\/\/\/\

#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\

import base64
import xbmcaddon
PY3 = sys.version_info >= (3,0,0)

#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\

addon = xbmcaddon.Addon(id='plugin.video.pastebinVID')
sess=requests.Session()

#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\

def string_escape(s, encoding='utf-8'):
#/\/\/\/\/\/\/\/\/\/\/\

    return (s.encode('latin1')         # To bytes, required by 'unicode-escape'
                        .decode('unicode-escape') # Perform the actual octal-escaping decode
                         .encode('latin1')         # 1:1 mapping back to bytes
                         .decode(encoding))  
#/\/\/\/\/\/\/\/\/\/\/\

def getU():#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\

    headers = {
        'Host': 'filmninja.ws',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'DNT': '1',
        'Upgrade-Insecure-Requests': '1',
    }
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\

    response = sess.get('http://filmninja.ws/', headers=headers,verify=False)
    sc=''.join(['%s=%s;'%(c.name, c.value) for c in response.cookies])#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\

    return response.text,sc
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\

def getU2():
    headers = {
        'Host': 'playtube.ws',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'DNT': '1',
        'Upgrade-Insecure-Requests': '1',
    }
    
    response = sess.get('http://playtube.ws/', headers=headers,verify=False)
    sc=''.join(['%s=%s;'%(c.name, c.value) for c in response.cookies])
    return response.text,sc
	
def zdekod(html):
    cod=re.findall('data-cfasync="false">([^<]+)',html)
#/\/\/\/\/\/\/\/\/\/\/\

    ab= ( string_escape(cod[0]))
#/\/\/\/\/\/\/\/\/\/\/\

    if 'escape(window.atob(' in ab:
        az = re.findall('atob\((.+?)\)',ab,re.DOTALL)[0]
        if not' + ' in az:
            cc=re.findall("""window.atob\(['"](.+?)['"]""",ab)[0]
            cc1=base64.b64decode(cc)
            if PY3:
            	ab=( string_escape(cc1.decode("utf-8") ))
            else:
            	ab=( string_escape(cc1))
        else:
            strung=''
            words=re.findall('(\w*)',az)
            for word in words:
                try:
                    x1=re.findall('var %s="(.+?)"'%word,ab,re.DOTALL)[0]
                    strung+=x1
                except:
                    continue
            ab=base64.b64decode(strung)
            if PY3:
            	ab=( string_escape(ab.decode("utf-8") ))
            else:
            	ab=( string_escape(ab))

    return ab#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\

def obliczwar(war,unp):
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\

    obl=re.findall("""var\s*%s=(.+?);"""%war,unp)[0].replace('parseInt','int')
    return (eval(obl))
def cdRozw(unp,sc):
    headers3 = {
        'Host': 'filmninja.ws',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
        'dnt': '1',
        'upgrade-insecure-requests': '1',
        'pragma': 'no-cache',
        'cache-control': 'no-cache',
        'te': 'trailers',
    }
    kuk1 = re.findall("""document.cookie\s*=\s*['"](.+?)['"]""",unp)
    kuk1 = sc+kuk1[0] if kuk1 else sc
    kukmacz=re.findall("""cookie.match(.+?)XMLHttpRequest""",unp,re.DOTALL)
    if kukmacz:
        war=re.findall("""var\s*(\w*)=""",kukmacz[0])[0]
        dlawar=re.findall("""setRequestHeader\(['"](.+?)['"],\s*%s"""%(war),unp)[0]
        az=str(obliczwar(war,unp))
    unp2=re.findall("""http.open(.+?)screen.""",unp,re.DOTALL)[0]
    headers2 = {
        'Host': 'filmninja.ws',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0',
        'accept': '*/*',
        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',}  
    post = {k: v for k, v in re.findall("""setRequestHeader\(['"](.+?)['"],\s*['"](.*?)['"]""", unp2)}
    
    datasend=re.findall("""http.send\(['"](.+?)['"]""",unp,re.DOTALL)#[0]

    headers2.update({dlawar:az,'cookie':kuk1})
    headers2.update(post)
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\

    if datasend:
        html = sess.post('https://filmninja.ws/', headers=headers2, data=datasend[0],verify=False)
    else:
        html = sess.get('https://filmninja.ws/', headers=headers2,verify=False)
    sc=''.join(['%s=%s;'%(c.name, c.value) for c in html.cookies])
    html = sess.get('https://filmninja.ws/', headers=headers3,verify=False)
    return html.text,sc
	
def cdRozw2(unp,sc):
    headers3 = {
        'Host': 'playtube.ws',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
        'dnt': '1',
        'upgrade-insecure-requests': '1',
        'pragma': 'no-cache',
        'cache-control': 'no-cache',
        'te': 'trailers',
    }
    kuk1 = re.findall("""document.cookie\s*=\s*['"](.+?)['"]""",unp)
    kuk1 = sc+kuk1[0] if kuk1 else sc
    kukmacz=re.findall("""cookie.match(.+?)XMLHttpRequest""",unp,re.DOTALL)
    if kukmacz:
        war=re.findall("""var\s*(\w*)=""",kukmacz[0])[0]
        dlawar=re.findall("""setRequestHeader\(['"](.+?)['"],\s*%s"""%(war),unp)[0]
        az=str(obliczwar(war,unp))
    unp2=re.findall("""http.open(.+?)screen.""",unp,re.DOTALL)[0]
    headers2 = {
        'Host': 'playtube.ws',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0',
        'accept': '*/*',
        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',}  
    post = {k: v for k, v in re.findall("""setRequestHeader\(['"](.+?)['"],\s*['"](.*?)['"]""", unp2)}
    
    datasend=re.findall("""http.send\(['"](.+?)['"]""",unp,re.DOTALL)#[0]

    headers2.update({dlawar:az,'cookie':kuk1})
    headers2.update(post)
    if datasend:
        html = sess.post('https://playtube.ws/', headers=headers2, data=datasend[0],verify=False)
    else:
        html = sess.get('https://playtube.ws/', headers=headers2,verify=False)
    sc=''.join(['%s=%s;'%(c.name, c.value) for c in html.cookies])
    html = sess.get('https://playtube.ws/', headers=headers3,verify=False)
    return html.text,sc
def abc():
    html,sc=getU()
    ab=zdekod(html)
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\
#/\/\/\/\/\/\/\/\/\/\/\

    html,kukz=cdRozw(ab,sc)
    addon.setSetting('fjkukz', kukz)
    html,sc=getU2()
    ab=zdekod(html)

    html,kukz2=cdRozw2(ab,sc)
    addon.setSetting('fjkukz2', kukz2)

    return html, kukz,kukz2
