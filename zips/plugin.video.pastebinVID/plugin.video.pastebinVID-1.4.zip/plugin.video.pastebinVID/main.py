# -*- coding: UTF-8 -*-
import sys,re,os
import urlparse
from urlparse import parse_qsl
import base64
import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import resolveurl as urlresolver
 
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.pastebinVID')
PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=PATH+'fanart.jpg'
link_path = os.path.join(DATAPATH, 'links')
file_link = 'linki.txt'

if not os.path.exists(DATAPATH):
    os.mkdir(DATAPATH)
if not os.path.exists(link_path):
    os.mkdir(link_path)

sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('title', None)
paths= params.get('path', None)
index= params.get('index', None)
page = params.get('page',[1])[0]

UA='Mozilla/5.0 (Linux; Android 7.0; PLUS Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36'
TIMEOUT=10
s = requests.Session()


def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=1,contextmenu=None):
	list_item = xbmcgui.ListItem(label=name)

	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')
		
	if not infoLabels:
		infoLabels={'title': name}
	if contextmenu:
		isp=contextmenu
		list_item.addContextMenuItems(isp, replaceItems=True)
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url,'page' : page}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def home():	
	add_item('', '[COLOR khaki]Dodaj nową listę z PASTEBIN[/COLOR]', '', True, "dodajnowa")	
	path, dirs, files = get_directory(link_path)
	if file_link in files:
		link_file = os.path.join(path, file_link)
		with open(link_file) as f:
			for i, line in enumerate(f):
				item = line.split('|')
				href = item[0].strip()
				if not href: 
					continue
				try: 
					title = item[1]
				except: 
					title = item[0]
				dalejxx(i, href, title, path)

	xbmcplugin.setContent(addon_handle, 'files')
	xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)

def dalejxx(index, href, title, path):	
	contextmenu = [] 
	contextmenu.append(('Usuń tę listę', 'RunPlugin(%s)' % build_url({'mode': 'usunlist', 'url' : index, 'index': index, 'path': path})),)
	
	contextmenu.append((u'Usuń wszystkie listy', 'XBMC.Container.Update(%s)' % build_url({'mode': 'delall', 'index': index, 'path': path})),)
	contextmenu.append((u'Zmiana nazwy', 'RunPlugin(%s)' % build_url({'mode': 'zmiananazwy', 'index': index, 'path': path})),)
	add_item(href, title, '', True, "pastebin",contextmenu=contextmenu)

def get_directory(path):
    try: return next(os.walk(path))
    except: return (path, [], [])
def dalej():
	history = HistoryLoad()
	if not history == ['']:
		for entry in history:
			entryok=entry.split('|')
			contextmenu = []
			contextmenu.append((u'Usuń tę listę', 'XBMC.Container.Update(%s)'% build_url({'mode': 'SzukajUsun', 'url' : entry})),)
			contextmenu.append((u'Usuń wszystkie listy', 'XBMC.Container.Update(%s)' % build_url({'mode': 'SzukajUsunAll'})),)
			contextmenu.append((u'Zmiana nazwy', 'XBMC.Container.Update(%s)' % build_url({'mode': 'zmiananazwy'})),)			
			add_item(entryok[0],entryok[1], '', True, "pastebin", contextmenu=contextmenu)	

def ListPastebin(exlink):
	exlink=exlink.split('|')[0]
	lists = getPastebin(exlink)
	itemz=lists
	items = len(lists)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)			
	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle)	
def getUrlReq(url):
	s.headers.update({'User-Agent': UA})
	content=s.get(url,verify=False).text
	return content
	
def getPastebin(exlink):
	html=getUrlReq(exlink)
	try:
		result=parseDOM(html,'span', attrs={'class': "go_right"})[0]
		href = parseDOM(result, 'a', ret='href')[0]  
		href = 'https://pastebin.com' + href if href.startswith('/raw') else href
		html=getUrlReq(href)
	except:
		pass
	ass=html.split('\r\n')
	imag=''
	out=[]
	for aser in ass:
		link=re.findall("(http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+)",aser)[0]
		tytul=aser.partition(' ')[2]
		if not tytul:
			tytul = link
		out.append({ 'href'  : link,'title' : tytul,'img': imag})	
	return out

def getLinks(exlink):
	stream=exlink
	hlink='https://freedisc.pl/'
	strfile=''
	if 'freedisc.pl' in stream:
		strfile=stream+'|Referer='+hlink +' swfUrl=http://http://freedisc.pl/static/player/v58/player.swf'
	if strfile:
		play_item = xbmcgui.ListItem(path=strfile)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
	else:
	
		try:
			stream_url = urlresolver.resolve(stream)
		except Exception,e:
				stream_url=''
				s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link bedzie działał?','ERROR: %s'%str(e))	
		if stream_url:	
			play_item = xbmcgui.ListItem(path=stream_url)
			xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
		else:
			play_item = xbmcgui.ListItem(path='')
			xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)		

def DelList(index, paths):
	try:
		ret = xbmcgui.Dialog().yesno('Kodi', 'Jesteś pewien?')
	except:
		return
		
	if ret: 
		path = os.path.join(paths, file_link)
		new_lines = []
		with open(path) as f:
			for i, line in enumerate(f):
				if i == int(index):
					continue
				new_lines.append(line)
		write_links(path, new_lines)       	
		xbmc.executebuiltin("Container.Refresh") 
	else:
		return	
		
def DelAll(index, paths):
	try:
		ret = xbmcgui.Dialog().yesno('Kodi', 'Jesteś pewien?')
	except:
		return
		
	if ret: 
		path = os.path.join(paths, file_link)
		open(path, 'w').close()    	
		xbmc.executebuiltin("Container.Refresh") 
	else:
		return
	
def write_links(path, links):
    with open(path, 'w') as f:
        for line in links:
            if not line.endswith('\n'):
                line += '\n'               
            f.write(line)	

def edit_link(index, paths):
	path = os.path.join(paths, file_link)
	new_lines = []
	with open(path) as f:
		for i, line in enumerate(f):
			if i == int(index):
				item = line.split('|')
				result = prompt_for_link(*item)
				if result:
					line = '|'.join(result)				
			new_lines.append(line)	
	write_links(path, new_lines)
	xbmc.executebuiltin("Container.Refresh") 
	
def prompt_for_link(old_link='', old_name=''):
	if old_link.endswith('\n'): old_link = old_link[:-1]
	if old_name.endswith('\n'): old_name = old_name[:-1]

	new_name = xbmcgui.Dialog().input(u'Podaj nową nazwę', type=xbmcgui.INPUT_ALPHANUM)
	if new_name is None:
		return
	
	if new_name:
		return (old_link, new_name)
	else:
		return (old_link, )

def prompt_for_link2(old_link='', old_name=''):
	if old_link.endswith('\n'): old_link = old_link[:-1]
	if old_name.endswith('\n'): old_name = old_name[:-1]
	new_link = xbmcgui.Dialog().input(u'Podaj link z PASTEBIN.COM', type=xbmcgui.INPUT_ALPHANUM)
	if new_link is None:
		return
	new_name = xbmcgui.Dialog().input(u'Podaj nazwę', type=xbmcgui.INPUT_ALPHANUM)
	if new_name is None:
		return
	
	if new_name:
		return (new_link, new_name)
	else:
		return (new_link, )
		
def DodajNowa(link=None, name=None, path=None):
	if path is None: path = link_path
	if link is None:
		result = prompt_for_link2()
	else:
		if name is None:
			result = (link, )
		else:
			result = (link, name)
			
	if result:
		if not os.path.exists(os.path.dirname(path)):
			os.mkdir(os.path.dirname(path))
			
		path = os.path.join(path, file_link)
		with open(path, 'a') as f:
			line = '|'.join(result)
			if not line.endswith('\n'):
				line += '\n'
			f.write(line)
		
	xbmc.executebuiltin("Container.Refresh") 	

if __name__ == '__main__':
	mode = params.get('mode', None)	
	if mode == None:
		home()
	elif mode == 'getLinks':
		getLinks(exlink)	
	elif mode == 'pastebin':
		ListPastebin(exlink)			
	elif mode == 'dodajnowa':
		DodajNowa()		
	elif mode == 'delall':
		DelAll(index, paths)
	elif mode == 'usunlist':
		DelList(index, paths)	
	elif mode == 'zmiananazwy':
		edit_link(index, paths)	