# -*- coding: UTF-8 -*-
import sys,re,os
import urlparse
from urlparse import parse_qsl
import base64
import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import resolveurl as urlresolver

try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
  
cache = StorageServer.StorageServer("pbin")



urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.pastebinVID')
PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=PATH+'fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('title', None)
page = params.get('page',[1])[0]

UA='Mozilla/5.0 (Linux; Android 7.0; PLUS Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36'
TIMEOUT=10
s = requests.Session()

s.headers.update({'User-Agent': UA})
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=1,contextmenu=None):
	list_item = xbmcgui.ListItem(label=name)

	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')
		
	if not infoLabels:
		infoLabels={'title': name}
	if contextmenu:
		isp=contextmenu
		list_item.addContextMenuItems(isp, replaceItems=True)
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def home():	
	add_item('', '[COLOR lightblue]URL pastebin[/COLOR]', '', True, "Szukaj")		

def ListPastebin(exlink):
	lists = getPastebin(exlink)
	itemz=lists
	items = len(lists)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)			
	xbmcplugin.setContent(addon_handle, 'tvshows')

def getUrlReq(url):
	content=s.get(url,verify=False).text
	return content
def getPastebin(exlink):
	html=getUrlReq(exlink)
	try:
		result=parseDOM(html,'span', attrs={'class': "go_right"})[0]
		href = parseDOM(result, 'a', ret='href')[0]  
		href = 'https://pastebin.com' + href if href.startswith('/raw') else href
		html=getUrlReq(href)
	except:
		pass
	ass=html.split('\r\n')
	imag=''
	out=[]
	for aser in ass:
		link=re.findall("(http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+)",aser)[0]
		out.append({ 'href'  : link,'title' : link,'img': imag})	
	return out

def getLinks(exlink):
	stream=exlink
	try:
		stream_url = urlresolver.resolve(stream)
	except Exception,e:
			stream_url=''
			s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link bedzie działał?','ERROR: %s'%str(e))	
	if stream_url:	
		play_item = xbmcgui.ListItem(path=stream_url)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
	else:
		play_item = xbmcgui.ListItem(path='')
		xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)		
	
def getHistory():
    return cache.get('history').split(';')

def setHistory(entry):
    history = getHistory()
    if history == ['']:
        history = []
    history.insert(0, entry)
    cache.set('history',';'.join(history[:50]))

def remCache(entry):
    history = getHistory()
    if history:
        cache.set('history',';'.join(history[:50]))
    else:
        delHistory()

def delHistory():
    cache.delete('history')

if __name__ == '__main__':
	mode = params.get('mode', None)
	
	if not mode:
		home()
	elif mode == 'getLinks':
		getLinks(exlink)	
	elif mode == 'pastebin':
		ListPastebin(exlink)

	elif mode =='Szukaj':
		add_item('', '[COLOR khaki]Nowy adres PASTEBIN[/COLOR]', '', True, "SzukajNowe")	
		history = getHistory()
		if not history == ['']:
			for entry in history:
				contextmenu = []
				contextmenu.append((u'Usun', 'XBMC.Container.Refresh(%s)'% build_url({'mode': 'SzukajUsun', 'ex_link' : entry})),)
				contextmenu.append((u'Usun cała historie', 'XBMC.Container.Update(%s)' % build_url({'mode': 'SzukajUsunAll'})),)
				add_item(entry,entry, '', True, "pastebin", contextmenu=contextmenu)			
	elif mode =='SzukajNowe':
		d = xbmcgui.Dialog().input(u'Podaj adres PASTEBIN.com', type=xbmcgui.INPUT_ALPHANUM)
		if d:
			setHistory(d)
			ex_link=d
			ListPastebin(ex_link)
			xbmcplugin.setContent(addon_handle, 'movies')
	
	elif mode =='SzukajUsun':
		remCache(ex_link)
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))
	
	elif mode == 'SzukajUsunAll':
		delHistory()
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))


		
xbmcplugin.endOfDirectory(addon_handle)
