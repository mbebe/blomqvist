# -*- coding: UTF-8 -*-
from __future__ import division
import sys,re,os
import six
from six.moves import urllib_parse

import json, ast

from requests.compat import urlparse

import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc, xbmcvfs
import ast, unicodedata

if six.PY3:
    basestring = str
    unicode = str
    xrange = range

import platform

ac=platform.system()
UA = "okhttp/4.9.2"

#### cloudscraper wymaga nizszego urllib3 - max 1.26
#### kodi ma najnowszy , wiec trzeba downgrade'owac - pliki w resource/lib


if 'windows' in ac.lower():
	from resources.lib import cloudscraper
	
	sessi = cloudscraper.create_scraper(interpreter='native', browser={'custom': UA})
	response = sessi.get("https://kick.com/")
	if (response.status_code)==200:
		pass
	else:
		from resources.lib import cloudscraper_OK
	
		sessi = cloudscraper_OK.create_scraper(interpreter='native', browser={'custom': UA})
else:
	from resources.lib import cloudscraper_OK
	
	sessi = cloudscraper_OK.create_scraper(interpreter='native', browser={'custom': UA})
	response = sessi.get("https://kick.com/")
	if (response.status_code)==200:
		pass
	else:
		from resources.lib import cloudscraper
	
		sessi = cloudscraper.create_scraper(interpreter='native', browser={'custom': UA})
	
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(urllib_parse.parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.kickcommb')



PATH            = addon.getAddonInfo('path')
if six.PY2:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
else:
    DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'../fanart.jpg'
ikona =RESOURCES+'../icon.png'
pem = RESOURCES+'../x.pem'
exlink = params.get('url', None)
nazwa= params.get('title', None)
rys = params.get('image', None)

page = params.get('page',[1])#[0]

TIMEOUT=15
def build_url(query):
    return base_url + '?' + urllib_parse.urlencode(query)

def add_item(url, name, image, mode, itemcount=1, page=1,fanart=FANART, infoLabels=False,contextmenu=None,IsPlayable=False, folder=False):
    list_item = xbmcgui.ListItem(label=name)
    if IsPlayable:
        list_item.setProperty("IsPlayable", 'True')    
    if not infoLabels:
        infoLabels={'title': name}    
    list_item.setInfo(type="video", infoLabels=infoLabels)    
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': fanart})
    
    if contextmenu:
        out=contextmenu
        list_item.addContextMenuItems(out, replaceItems=True)
    #else:
    #    out = []
    #    out.append(('Informacja', 'XBMC.Action(Info)'),)
    #    list_item.addContextMenuItems(out, replaceItems=False)

    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url = build_url({'mode': mode, 'url' : url, 'page' : page, 'title':name,'image':image}),            
        listitem=list_item,
        isFolder=folder)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
   
def home():
	zalogowany = addon.getSetting('auth')

	if zalogowany!='1':
		add_item('https://kick.com/', 'Zaloguj', ikona, "logowanie",fanart=FANART, folder=False, IsPlayable=False)
		
	else:
		
		add_item('https://kick.com/', 'Obserwowane', ikona, "listobserwowane",fanart=FANART, folder=True)
	add_item('https://kick.com/stream/livestreams/pl?page=1', 'Kanały na żywo', ikona, "live",fanart=FANART, folder=True)
	add_item('old', 'Kategorie', ikona, "listcateg",fanart=FANART, folder=True)
	add_item('https://kick.com/', 'Szukaj', ikona, "szukaj",fanart=FANART, folder=False, IsPlayable=False)
	if zalogowany=='1':
		add_item('https://kick.com/', '[B][I]Wyloguj[/B][/I]', ikona, "wyloguj",fanart=FANART, folder=False, IsPlayable=False)
def ListCateg():

	add_item('games|https://kick.com/api/v1/subcategories?page=1', 'Gry', ikona, "listsubcateg",fanart=FANART, folder=True)
	add_item('irl|https://kick.com/api/v1/subcategories?page=1', 'Irl', ikona, "listsubcateg",fanart=FANART, folder=True)
	add_item('music|https://kick.com/api/v1/subcategories?page=1', 'Muzyka', ikona, "listsubcateg",fanart=FANART, folder=True)
	
	
	add_item('gambling|https://kick.com/api/v1/subcategories?page=1', 'Hazard', ikona, "listsubcateg",fanart=FANART, folder=True)
	add_item('creative|https://kick.com/api/v1/subcategories?page=1', 'Creative', ikona, "listsubcateg",fanart=FANART, folder=True)
	
	
	add_item('alternative|https://kick.com/api/v1/subcategories?page=1', 'Alternatywne', ikona, "listsubcateg",fanart=FANART, folder=True)
	
	xbmcplugin.endOfDirectory(addon_handle) 
	
	
def ListObserwowane():
	auth_head = addon.getSetting('auth_headers')#,auth_headers)

	jsdata = sessi.get('https://kick.com/')
	sessi.headers.update(ast.literal_eval(urllib_parse.unquote_plus(auth_head)))
	
	url='https://kick.com/api/v2/channels/followed?cursor=0'
	

	jsdata = sessi.get(url).json()#\]
	channels = jsdata.get('channels', None)

	add_item('x', '[COLOR khaki][B]==== Obserwowane kanały ===[/B][/COLOR]', ikona, "nic",fanart=FANART, infoLabels={"title": '[COLOR khaki][B]====  Obserwowane kanały ==== [/B][/COLOR]','plot':'=== Obserwowane kanały ==='}, folder=False, IsPlayable=False)
	for x in channels:
		is_live = x.get('is_live', None)
		dod =''
		if is_live:
			dod = ' [B][COLOR yellowgreen]LIVE[/B][/COLOR]'
		profile_picture = x.get('profile_picture', None)
		channel_slug = x.get('channel_slug', None)
		contextmenu=[]

		contextmenu.append(('[B][COLOR gold]Usuń z obserwowanych[/B][/COLOR]', 'RunPlugin(plugin://plugin.video.kickcommb?mode=usun&url=%s)'%str(channel_slug)))

		user_username = x.get('user_username', None)
		title = user_username + dod
		add_item(channel_slug, title, profile_picture, "listchannel",fanart=FANART, infoLabels={"title": title,'plot':title}, contextmenu=contextmenu, folder=True, IsPlayable=False)
	if not channels:
		add_item('x', '[I]- brak obserwowanych kanałów -[/I]', ikona, "nic",fanart=FANART, infoLabels={"title": '[I]- brak obserwowanych kanałów -[/I]','plot':'brak obserwowanych kanałów'}, folder=False, IsPlayable=False)

	url = 'https://kick.com/api/v1/user/categories/top'

	categories = sessi.get(url).json()
	if categories:
		add_item('x', '[COLOR khaki][B]=== Obserwowane kategorie ===[/B][/COLOR]', ikona, "nic",fanart=FANART, infoLabels={"title": '[COLOR khaki][B]=== Obserwowane kategorie ===[/B][/COLOR]','plot':'[COLOR khaki]=== Obserwowane kategorie ===[/COLOR]'}, folder=False, IsPlayable=False)
	
		for x in categories:
			slug = x.get('slug', None)	
			title = x.get('name', None)	
			viewers = x.get('viewers', None)	
			urlmain = slug+'|https://kick.com/stream/livestreams/pl?page=1'
			t2 = title + ' ['+str(viewers)+']'
			add_item(urlmain, t2, ikona, "live",fanart=FANART, infoLabels={"title": t2,'plot':t2}, folder=True, IsPlayable=False)
	if not categories:
		add_item('x', '[I]- brak obserwowanych kategorii -[/I]', ikona, "nic",fanart=FANART, infoLabels={"title": '[I]- brak obserwowanych kategorii -[/I]','plot':'brak obserwowanych kategorii'}, folder=False, IsPlayable=False)

	xbmcplugin.endOfDirectory(addon_handle) 

def ListSubCateg(mainurl):
	
	tt, murl = mainurl.split('|')
	url = murl+'&limit=20&category='+tt

	jsdata = sessi.get(url).json()
	dt = jsdata.get('data', None)
	for x in dt:
		title = x.get('name', None)
		slug = x.get('slug', None)
		description = x.get('description', None)

		viewers = x.get('viewers', None)
		murl2 = 'https://kick.com/stream/livestreams/pl?page=1'
		t2 = title + ' ['+str(viewers)+']'
		description = description if description else t2
		add_item(slug+'|'+murl2, t2 ,ikona, "live",fanart=FANART, folder=True,infoLabels={"title": t2,'plot':description})

	if jsdata.get("next_page_url", None):
	

		add_item(tt+'|'+jsdata.get("next_page_url", None), '>> next page >>' ,RESOURCES+'right.png', "listsubcateg",fanart=FANART, folder=True)
	xbmcplugin.endOfDirectory(addon_handle) 

def live(urlmain):

	tt = ''
	if '|' in urlmain:
		tt,urlmain = urlmain.split('|')

	url = urlmain+'&limit=25&subcategory=&sort=desc' if not tt else urlmain+'&limit=25&subcategory='+tt+'&sort=desc'

	jsdata = sessi.get(url).json()

	dt = jsdata.get('data', None)

	for x in dt:
		session_title = x.get('session_title', None).replace('\n', ' ').replace('🔴', '').replace('🐪', '')
		session_title = "".join(c for c in session_title if "So" not in unicodedata.category(c))

		viewers = x.get('viewers', None)
		thumbnail = x.get('thumbnail', None).get('src', None)
		slug = x.get('channel', None).get('slug', None)
		title = '[B]'+slug+'[/B] ' +session_title+' ['+str(viewers)+']'

		
		add_item(slug, title, thumbnail, "listchannel",fanart=FANART, infoLabels={"title": title,'plot':title}, folder=True, IsPlayable=False)

	if jsdata.get("next_page_url", None):

		nturl = jsdata.get("next_page_url", None) if tt else tt+'|'+jsdata.get("next_page_url", None)
		
		add_item(nturl, '>> next page >>' ,RESOURCES+'right.png', "live",fanart=FANART, folder=True)
	xbmcplugin.endOfDirectory(addon_handle) 
	
def usun(slug):
	auth_head = addon.getSetting('auth_headers')

	jsdata = sessi.get('https://kick.com/')
	sessi.headers.update(ast.literal_eval(urllib_parse.unquote_plus(auth_head)))
	url ='https://kick.com/api/v2/channels/'+slug+'/follow'
	jsdata = sessi.delete(url)

	return
	
def dodaj(slug):
	auth_head = addon.getSetting('auth_headers')#,auth_headers)

	jsdata = sessi.get('https://kick.com/')
	sessi.headers.update(ast.literal_eval(urllib_parse.unquote_plus(auth_head)))
	url ='https://kick.com/api/v2/channels/'+slug+'/follow'
	jsdata = sessi.post(url)
	if jsdata.status_code ==200:
		xbmcgui.Dialog().notification('[COLOR yellowgreen][B]OK[/B][/COLOR]', 'Poprawnie dodano', xbmcgui.NOTIFICATION_INFO, 5000,False)

	return
	
def ListChannel(slug):
	auth_head = addon.getSetting('auth_headers')#,auth_headers)
	if auth_head:
		jsdata = sessi.get('https://kick.com/')
		sessi.headers.update(ast.literal_eval(urllib_parse.unquote_plus(auth_head)))




	url = 'https://kick.com/api/v1/channels/'+slug

	jsdata = sessi.get(url).json()
	contextmenu=[]
	if auth_head:
		following = jsdata.get('following', None)
		contextmenu=[]

		contextmenu.append(('[B][COLOR gold]Dodaj do obserwowanych[/B][/COLOR]', 'RunPlugin(plugin://plugin.video.kickcommb?mode=dodaj&url=%s)'%str(slug)))

		if following:
			contextmenu=[]

			contextmenu.append(('[B][COLOR gold]Usuń z obserwowanych[/B][/COLOR]', 'RunPlugin(plugin://plugin.video.kickcommb?mode=usun&url=%s)'%str(slug)))

			
			
	user = jsdata.get('user', None)
	pic = user.get('profile_pic', None)
	username = user.get('username', None)
	livestream = jsdata.get('livestream', None) 

	if livestream:
		thumbnail = livestream.get('thumbnail', None) .get('url', None) 
		title = livestream.get('session_title', None).replace('\n', ' ')
		title = "".join(c for c in title if "So" not in unicodedata.category(c))
		title += '     [B][COLOR yellowgreen]LIVE[/B][/COLOR]'
		add_item(slug, title, thumbnail, "playvid",fanart=FANART, infoLabels={"title": title,'plot':title}, contextmenu = contextmenu, folder=False, IsPlayable=True)

	prev = urllib_parse.quote_plus(str(jsdata.get('previous_livestreams', None)))
	add_item(prev, "[B][COLOR khaki]Filmy[/COLOR] "+username+'[/B]', pic, "liststreams",fanart=FANART, infoLabels={"title": "[B][COLOR khaki]Filmy[/COLOR] "+username+'[/B]','plot':"[B][COLOR khaki]Filmy[/COLOR] "+username+'[/B]'}, contextmenu = contextmenu, folder=True, IsPlayable=False)
	add_item(slug, "[B][COLOR khaki]Klipy[/COLOR] "+username+'[/B]', pic, "listclips",fanart=FANART, infoLabels={"title": "[B][COLOR khaki]Klipy[/COLOR] "+username+'[/B]','plot':"[B][COLOR khaki]Klipy[/COLOR] "+username+'[/B]'}, contextmenu = contextmenu, folder=True, IsPlayable=False)
	xbmcplugin.endOfDirectory(addon_handle) 

def ListPrev(data):
	

	data=ast.literal_eval(urllib_parse.unquote_plus(data))
	for x in data:
		ac=''
		session_title = x.get('session_title', None).replace('\n', ' ').replace('🔴', '').replace('🐪', '')
		session_title = "".join(c for c in session_title if "So" not in unicodedata.category(c))
		duration = int(x.get('duration', None))//1000
		thumbnail = x.get('thumbnail', None).get('src', None)
		created_at = x.get('created_at', None)
		video = x.get('video', None)
		uuid = video.get('uuid', None)
		title = session_title+ ' [I](%s)[/I]'%(created_at)

		href = 'https://kick.com/api/v1/video/'+uuid
		add_item(href, title, thumbnail, "playvid",fanart=FANART, infoLabels={"title": title,'plot':title, 'duration':duration}, folder=False, IsPlayable=True)


	xbmcplugin.endOfDirectory(addon_handle) 
def ListClips(slug):
	url ='https://kick.com/api/v2/channels/'+slug+'/clips?cursor=0&sort=view&time=all'

	response = sessi.get(url)#.json()
	if (response.status_code)==500:
		return
	jsdata= response.json()
	xcx=''
	for x in jsdata.get('clips', None):
		title = x.get('title', None)
		thumbnail_url = x.get('thumbnail_url', None)
		duration = x.get('duration', None)
		href = x.get('video_url', None) 
		add_item(href, title, thumbnail_url, "playvid",fanart=FANART, infoLabels={"title": title,'plot':title, 'duration':duration}, folder=False, IsPlayable=True)

	xbmcplugin.endOfDirectory(addon_handle) 

def PlayVid(slug):

	if 'http' in slug and not (slug.endswith('.mp4') or slug.endswith('.m3u8')):
		jsdata = sessi.get(slug).json()
		stream = jsdata.get('source', None)
	elif slug.endswith('.mp4') or slug.endswith('.m3u8'):
		stream = slug
	else:
		url = 'https://kick.com/api/v2/channels/'+slug+'/livestream'
		
		jsdata = sessi.get(url).json()
		stream = jsdata.get('data', None).get('playback_url', None)# = 
	from requests.compat import urlparse
	domain = urlparse(stream).netloc
	hdz = {
    'Accept': 'application/x-mpegURL, application/vnd.apple.mpegurl, application/json, text/plain',
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; SM-J330F Build/PPR1.180610.011)',
    'Host': domain}
	hea= '&'.join(['%s=%s' % (name, value) for (name, value) in hdz.items()]) 
	link = stream+'|'+hea
	play_item = xbmcgui.ListItem(path=link)

	xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item) 
	

def Logowanie():

	username_ = addon.getSetting('username')
	password_ = addon.getSetting('password')
	if not (username_ or password_):
		addon.openSettings() 
		return
	if username_ and password_:

		tok = sessi.get("https://kick.com/")
		az=sessi.cookies.get_dict()

		xc=az.get('XSRF-TOKEN', None)
		tok = sessi.get("https://kick.com/kick-token-provider")
		sessi.headers.update({"x-xsrf-token":xc})

		nameFieldName = tok.json().get("nameFieldName", None)
		validFromFieldName = tok.json().get("validFromFieldName", None)
		encryptedValidFrom = tok.json().get("encryptedValidFrom", None)
		payload={
					"email": username_,
					"password": password_,
					"isMobileRequest": True,
					nameFieldName: "",
					validFromFieldName: encryptedValidFrom,
				}
		response = sessi.post(
			"https://kick.com/mobile/login",
			json=payload, headers=sessi.headers
		)
		if (response.status_code)==200:
			
			if '"2fa_required":true' in response.text:
				twofactor_code = xbmcgui.Dialog().input(u'Podaj kod, wysłany na maila', type=xbmcgui.INPUT_NUMERIC)
				if twofactor_code:
				#twofactor_code = input()
					payload['one_time_password'] = twofactor_code
					r = sessi.post(
						"https://kick.com/mobile/login",
						json=payload
					)
			auth = r.json().get("token")
			sessi.headers.update({"authorization":'Bearer '+auth})
			auth_headers=urllib_parse.quote_plus(str(dict(sessi.headers)))
			addon.setSetting('auth_headers',auth_headers)
			addon.setSetting('auth','1')
			xbmcgui.Dialog().notification('[COLOR yellowgreen][B]OK[/B][/COLOR]', "[COLOR yellowgreen][B]Zalogowano poprawnie[/B][/COLOR]", xbmcgui.NOTIFICATION_INFO, 5000,False)


		else:
			addon.setSetting('auth','0')

	else:
		xbmcgui.Dialog().notification('[COLOR orangered][B]Error[/B][/COLOR]', "[COLOR orangered][B]Brak hasła lub nazwy użytkownika[/B][/COLOR]", xbmcgui.NOTIFICATION_INFO, 5000,False)
		addon.setSetting('auth','0')

	xbmc.executebuiltin('Container.Refresh')				
	

def ListSearch(query):
	tok = sessi.get("https://kick.com/")
	az=sessi.cookies.get_dict()
	xc=az.get('XSRF-TOKEN', None)
	sessi.headers.update({"x-xsrf-token":xc})
	query=query.replace(' ','+')

	url = 'https://kick.com/api/search?searched_word='+query
	response = sessi.get(url)

	kanaly = (response.json()).get('channels', None)
	kategorie = (response.json()).get('categories', None)
	for x in kanaly:
		slug = x.get('slug', None)
		user = x.get('user', None)
		username = user.get('username', None)
		profilePic = user.get('profilePic', None)
		profilePic = profilePic if profilePic else ikona
		bio = user.get('bio', None)
		if bio:
			bio = "".join(c for c in bio if "So" not in unicodedata.category(c))
			bio = bio.replace('\n','[CR]')
		bio = bio if bio else username
		add_item(slug, username, profilePic, "listchannel",fanart=FANART, infoLabels={"title": username,'plot':bio}, folder=True, IsPlayable=False)

	for x in kategorie:
		title = x.get('name', None)
		slug = x.get('slug', None)
		description = x.get('description', None)
		
		viewers = x.get('viewers', None)
		t2 = title +' ['+str(viewers)+']'
		description = description if description else t2
		urlmain = slug+'|https://kick.com/stream/livestreams/pl?page=1'
		add_item(urlmain, t2, profilePic, "live",fanart=FANART, infoLabels={"title": t2,'plot':description}, folder=True, IsPlayable=False)
	if kanaly or kategorie:
		xbmcplugin.endOfDirectory(addon_handle) 
	else:
		xbmcgui.Dialog().notification('[COLOR yellowgreen][B]Info[/B][/COLOR]', 'Nic nie znaleziono', xbmcgui.NOTIFICATION_INFO, 5000,False)
	
def router(paramstring):
	params = dict(urllib_parse.parse_qsl(paramstring))
	if params:    
	
		mode = params.get('mode', None)
	
		if mode =='menu':
			Menu(exlink)
			
		elif mode =="live":
			live(exlink)
			
		elif mode =="playvid":
			PlayVid(exlink)
			
		elif mode =="listcateg":
			ListCateg()
			
		elif mode =="listsubcateg":
			ListSubCateg(exlink)
			
		elif mode =="listchannel":
			ListChannel(exlink)
			
		elif mode =="liststreams":
			ListPrev(exlink)
			
		elif mode =="listclips":
			ListClips(exlink)
		elif mode =='logowanie':
			Logowanie()
		elif mode == 'listobserwowane':
			ListObserwowane()
			
		elif mode == 'szukaj':
			query = xbmcgui.Dialog().input(u'Szukaj...', type=xbmcgui.INPUT_ALPHANUM)
			if query:

				urlk = build_url({'mode': 'listsearch', 'url' : query})
				xbmc.executebuiltin('Container.Update(%s)'% urlk)
		elif mode == 'listsearch':
			ListSearch(exlink)
			
		elif mode == 'nic':
			return
			
		elif mode == 'dodaj':
			dodaj(exlink)
			xbmc.executebuiltin('Container.Refresh()')	

		elif mode == 'usun':
			usun(exlink)
			xbmc.executebuiltin('Container.Refresh()')			

		elif mode == 'wyloguj':
			yes = xbmcgui.Dialog().yesno("[COLOR orange]Uwaga[/COLOR]", 'Wylogowanie spowoduje konieczność ponownego wpisania kodu.[CR]Jesteś pewien?',yeslabel='TAK', nolabel='NIE')
			if yes:
				addon.setSetting('auth','0')
				addon.setSetting('auth_headers','')
				xbmc.executebuiltin('Container.Refresh()')
			
			
	else:
		home()
		xbmcplugin.endOfDirectory(addon_handle)    
if __name__ == '__main__':
    router(sys.argv[2][1:])