# -*- coding: utf-8 -*-
import sys,re,os,json
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import resolveurl as urlresolver
import time,threading
import base64
import cookielib
import requests
from CommonFunctions import parseDOM

try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
  
cache = StorageServer.StorageServer("filmancc")

base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonName       = my_addon.getAddonInfo('name')
addonId         = my_addon.getAddonInfo('id')
PATH            = my_addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART          = RESOURCES+'fanart.png'
sys.path.append( os.path.join( RESOURCES, "lib" ) )
import cfdeco6
UA ='Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36'


mainurl ='https://filman.cc/'
mybtn_user=''
TIMEOUT      = 10

BASEURL='https://filman.cc/'

COOKIEFILE = os.path.join(DATAPATH,'filmancookie')
#BASEURL='https://filmbit.ws/'
#scraper = cfdeco6.create_scraper()
scraper=requests.Session()
scraper.cookies = cookielib.LWPCookieJar(COOKIEFILE)
#scraper.headers.update({'User-Agent': UA})

def addLinkItem(name, url, mode, page=1, iconimage='DefaultFolder.png', infoLabels=False, contextO=[''], IsPlayable=True,fanart=FANART, itemcount=1):
	u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'page':page, 'token': mybtn_user})
	liz = xbmcgui.ListItem(name)
	art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
	art = dict(zip(art_keys,[iconimage for x in art_keys]))
	art['landscape'] = fanart if fanart else art['landscape']
	liz.setArt(art)
	
	if not infoLabels:
	    infoLabels={"title": name,'plot':name}
	
	liz.setInfo(type="video", infoLabels=infoLabels)
	
	if IsPlayable:
		liz.setProperty('IsPlayable', 'true')
	
	isp = []
	content = urllib.quote_plus(json.dumps(infoLabels))
	
	if 'DOWNLOAD' in contextO:
		isp.append(('[B]Download[/B]', 'RunPlugin(plugin://%s?mode=DOWNLOAD&ex_link=%s)'%(addonId,content)))
	
	liz.addContextMenuItems(isp, replaceItems=False)
	ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=False,totalItems=itemcount)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	xbmcplugin.setContent(addon_handle, 'videos')	
	return ok

def addDir(name,ex_link=None, page=1, mode='folder',iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART,contextmenu=None):
	url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'page' : page,'iconImage':iconImage, 'token': mybtn_user})
	li = xbmcgui.ListItem(name)
	if not infoLabels:
		infoLabels={"title": name,'plot':name}
	if infoLabels:
		li.setInfo(type="video", infoLabels=infoLabels)
	
	art_keys=['thumb','poster','banner','clearart','clearlogo','landscape','icon']
	art = dict(zip(art_keys,[iconImage for x in art_keys]))
	art['landscape'] = fanart if fanart else art['landscape']
	li.setArt(art)
	
	if contextmenu:
		isp=contextmenu
		li.addContextMenuItems(isp, replaceItems=True)
	
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
	xbmcplugin.setContent(addon_handle, 'videos')	
	#xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	#xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE , label2Mask = "%R, %Y, %P")
def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        out_dict[k] = v
    return out_dict

def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))

def listTv(ex_link):
    mlinks= getTvs(ex_link)
    items = len(mlinks)
    for f in mlinks:
		addDir(name=f.get('title'), ex_link=f.get('href'), mode='getTvLinks', iconImage=f.get('img'), infoLabels={'plot':f.get('title')})
	
def listMovies(ex_link,page):
	page = int(page) if page else 1
	group = ''
	
	if '|'in ex_link:
		ex_link,group = ex_link.split('|')
	
	mlinks,mparams = getMovies(ex_link,page,group)
	if mparams[0]:
		addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__M', page=mparams[0], IsPlayable=False)
	
	items = len(mlinks)
	
	for f in mlinks:
		addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD'], IsPlayable=True, itemcount=items)
	
	if mparams[1]:
		addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__M', page=mparams[1], IsPlayable=False)
#	xbmcplugin.setContent(addon_handle, 'videos')

def listSeries(ex_link,page):
    page = int(page) if page else 1
    group=''

    if '|'in ex_link:
        ex_link,group = ex_link.split('|')

    if group:
        mlinks,mparams = getSeries(ex_link,int(page),group)
    else:
        mlinks,mparams = getSeries(ex_link)

    my_mode = 'getEpisodes'

    if 'true' in my_addon.getSetting('groupEpisodes'):
        my_mode = 'getSeasons'

    if mparams[0]:
        addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__S', page=mparams[0], IsPlayable=False)

    items=len(mlinks)

    for f in mlinks:
        addDir(name=f.get('title'), ex_link=f.get('href'), mode=my_mode, iconImage=f.get('img'))#, infoLabels=f)

    if mparams[1]:
        addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__S', page=mparams[1], IsPlayable=False)

def getSeasons(ex_link):
	episodes = scanEpisodes(ex_link)
	if episodes:
		imag=episodes[0].get('img')#
		seasons = splitToSeasons(episodes)
	
		for i in sorted(seasons.keys()):
			addDir(name=i, ex_link=urllib.quote(str(seasons[i])), iconImage=imag, mode='getEpisodes2')
	
	#	xbmcplugin.setContent(addon_handle, 'season')
		xbmcplugin.endOfDirectory(addon_handle,True)		
			
	else:
		sel = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak odcinków','')

def getEpisodes(ex_link):
	episodes = scanEpisodes(ex_link)
	if episodes:
		for f in episodes:
			addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD'], IsPlayable=True)

	#	xbmcplugin.setContent(addon_handle, 'episodes')
		xbmcplugin.endOfDirectory(addon_handle,True)
	else:
		sel = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak odcinków','')
def getEpisodes2(ex_link):
    episodes = eval(urllib.unquote(ex_link))

    for f in episodes:
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD'], IsPlayable=True, fanart=f.get('img'))
#	xbmcplugin.setContent(addon_handle, 'episodes')
	xbmcplugin.endOfDirectory(addon_handle,True)

def listFS(ex_link):
	mlinks,match = search(ex_link)
	for f in mlinks:
		addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD'], IsPlayable=True, itemcount=len(mlinks))
	
	for f in match:
		addDir(name=f.get('title'), ex_link=f.get('href'), mode='getEpisodes', iconImage=f.get('img'), infoLabels=f)
	
def getTvLinks(ex_link,rys):

    mlinks = getTvLink(ex_link,rys)
	
    items = len(mlinks)

    for f in mlinks:
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='playTv', iconimage=rys, infoLabels={'plot':f.get('title')}, contextO=['DOWNLOAD'], IsPlayable=True, itemcount=items)
			
def PlayTv(ex_link):
	stream_url=ex_link
	if stream_url:
		xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
	else:
		xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))		
						
def getLinks(ex_link, get_download = False, name = '', image = ''):
	streams = getVideos(ex_link)
	stream_url = ''
	
	t = [ x.get('title') for x in streams]
	u = [ x.get('url') for x in streams]
	h = [ x.get('host') for x in streams]
	al = "Z jakiego źródla pobieramy?" if get_download else "  Wersja  |   Host   |  Jakość  "
	
	select = xbmcgui.Dialog().select(al, t)
	
	if select > -1:
		link = u[select];
		link = parseVideoLink(link,[select])
	
		if not stream_url:
			try:
				stream_url = urlresolver.resolve(link)
			except Exception,e:
				stream_url=''
				sel = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link będzie działał?','Resolveurl ERROR: [%s]'%str(e))
	else:
		pass	
	if stream_url:
		if get_download:
			downloadPath = my_addon.getSetting('download.path')
			if downloadPath and downloadPath != '':
				import resources.lib.downloader as dw
				try:
					dw.download(name, image, stream_url, downloadPath)
				except:
					xbmc.executebuiltin( "XBMC.Notification(%s,%s,%i,%s)" % ( '[COLOR red] Bląd pobierania [/COLOR]', name, 5000, image))
			else:
				xbmcgui.Dialog().ok("FilmanCC", "Ustaw docelowy folder!")
				xbmc.executebuiltin("Addon.OpenSettings(%s)"%addonId)
	
		xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
	else:
		xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

def getHistory():
    return cache.get('history').split(';')

def setHistory(entry):
    history = getHistory()
    if history == ['']:
        history = []
    history.insert(0, entry)
    cache.set('history',';'.join(history[:50]))

def remCache(entry):
    history = getHistory()
    if history:
        cache.set('history',';'.join(history[:50]))
    else:
        delHistory()

def delHistory():
    cache.delete('history')


def login():
	dataPath=os.path.dirname(COOKIEFILE)
	
	if not os.path.exists(dataPath):
		os.makedirs(dataPath)
	u = my_addon.getSetting('user')
	p = my_addon.getSetting('pass')
	l = my_addon.getSetting('login')
	logged=False
	if u and p and l == 'true':
		logged,dane=  getLogin(u,p)
		if logged:
			addLinkItem('[B]Zalogowany jako %s %s[/B]'%(u,dane),'',mode=' ',iconimage='',IsPlayable=False,infoLabels={'plot':dane})
		else:
			xbmcgui.Dialog().notification('[COLOR red][B]Błąd logowania[/B][/COLOR]', '', xbmcgui.NOTIFICATION_INFO, 5000)
			scraper.cookies.clear()
			scraper.cookies.save(COOKIEFILE, ignore_discard = True)	
			addLinkItem('[B]Zaloguj[/B]','',mode='Opcje',iconimage='',IsPlayable=False,infoLabels={'plot':'[B]Zaloguj[/B]'})
	else:
		global mybtn_user
		scraper.cookies.clear()
		scraper.headers.update({
				'Host': 'filman.cc',
				'User-Agent': UA,
				'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
				'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
				'Referer': 'http://filman.cc/logowanie',
				'Upgrade-Insecure-Requests': '1',})
	
		url ='https://filman.cc/logowanie'
		cont=scraper.get(url)
		aa=scraper.cookies
		
		my_cookies = requests.utils.dict_from_cookiejar(aa)
		found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]
		
		mybtn_user= ';'.join(found)	
		scraper.cookies.save(COOKIEFILE, ignore_discard = True)		
		addLinkItem('[B]Zaloguj[/B]','',mode='Opcje',iconimage='',IsPlayable=False)			
		
from urlparse import urlparse
from urlparse import urlsplit

def getLogin(u='',p=''):
	url ='https://filman.cc/logowanie'
	global mybtn_user
	try:
		scraper.cookies.clear()
		scraper.cookies.save(COOKIEFILE, ignore_discard = True)	
		headers = {
			'Host': 'filman.cc',
			'User-Agent': UA,
			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
			'DNT': '1',
			'Upgrade-Insecure-Requests': '1',
		}
		
		response = scraper.get('http://filman.cc/logowanie', headers=headers,verify=False)

		headers = {
			'Host': 'filman.cc',
			'user-agent': 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36',
			'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
			'referer': 'https://filman.cc/logowanie',
			'content-type': 'application/x-www-form-urlencoded',
			'dnt': '1',
			'upgrade-insecure-requests': '1',
			'te': 'trailers',
		}
		
		data = 'login='+u+'&password='+p+'&submit='
		
		response = scraper.post('https://filman.cc/logowanie', headers=headers, cookies=scraper.cookies, data=data,verify=False)
		ab=scraper.cookies
		ad=response.cookies
		content=response.text
		my_cookies = requests.utils.dict_from_cookiejar(ab)
		found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]
		
		mybtn_user= ';'.join(found)		
	except:
		content=''
	dane=''
	
	if content.find('Wyloguj')>0:
		out=True
		dane='[COLOR yellowgreen] darmowe[/COLOR]'
		try:
			content=scraper.get('http://filman.cc/premium').text
			danex=re.findall(' aktywne konto premium.+?<strong>(.+?)</strong>(.+?)<',content,re.DOTALL)
			if danex:
				dane='[COLOR orangered] premium do %s %s[/COLOR]'%(danex[0][0],danex[0][1])
		except:
			pass
			
	else:
		out=False
	scraper.cookies.save(COOKIEFILE, ignore_discard = True)
	return out,dane


def getUrlReq(url, ref, allow=True):
	global mybtn_user
	if os.path.isfile(COOKIEFILE):
		scraper.cookies.load()
	
	aa=scraper.cookies
	my_cookies = requests.utils.dict_from_cookiejar(aa)
	found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]
	kukz= ';'.join(found)	
	headersy={'User-Agent': UA,'Upgrade-Insecure-Requests':'1','Cookie':kukz,'Referer':ref}
	content=requests.get(url,headers=headersy,verify=False,allow_redirects=allow)#.text
	if 'Security Check' in content.text:
		content=scraper.get(url,headers=headersy)#.text	
		scraper.cookies.save(COOKIEFILE, ignore_discard = True)
	if allow:
		content=content.text
	else:
		content=content
	aa=scraper.cookies
	
	my_cookies = requests.utils.dict_from_cookiejar(aa)
	found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]
	
	mybtn_user= ';'.join(found)		
	return content	#.text

def getTvs(url):
	global mybtn_user
	mybtn_user = args.get('token',[''])[0]
	cuk=urllib.quote(mybtn_user)
	content=getUrlReq(url,url)
	out=[]
	result=parseDOM(content,'div', attrs={'class': "row tv-list"})[0]
	links=parseDOM(result,'div', attrs={'class': "col-xs-6 col-sm-3"})
	for link in links:
		src = parseDOM(link, 'img', ret='src')[0]
		href = parseDOM(link, 'a', ret='href')[0]   
		title = parseDOM(link, 'a', ret='title')[0]  
		if href and title:
			if src.startswith('//'):
				src = 'http:'+src
			film = {
				'href'   : href,
				'title'  : title,
				'plot'   : '',
				'img'    : src+'|User-Agent='+urllib.quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk,}
			out.append(film)
	return out		

def getEpg(url):
	content = getUrl(url)
	plot=''
	trwa=parseDOM(content,'b')[0]
	czastrwa=parseDOM(content,'p')[1]
	czastrwado=parseDOM(content,'p')[2]
	dalej=parseDOM(content,'table', attrs={'width': ".+?"})[0]
	plot+='[COLOR khaki]'+czastrwa+'-'+czastrwado+'[/COLOR] '+trwa
	plot+='[CR]'
	try:
		typhourtitle=re.findall('<tr.+?title="(.+?)".+?<b>(.+?)<\/b.+?<td>(.+?)<\/td',dalej)#[0]
		for typ,hour,title in typhourtitle:
			plot+='[COLOR khaki]'+hour+'[/COLOR] '+title
			plot+='[CR]'
	except:
		pass
	return plot
	
def getTvLink(url,imag):
	global mybtn_user
	mybtn_user = args.get('token',[''])[0]
	cuk=urllib.quote(mybtn_user)
	content=getUrlReq(url,url)
	out=[]
	epgresult=parseDOM(content,'div', attrs={'class': "epg"})#[0]
	plot=''
	if epgresult:
		epgs=parseDOM(epgresult[0],'h4')
		if epgs:
			for epg in epgs:
				plot+='[COLOR khaki]'+epg+'[/COLOR] '
				plot+='[CR][CR]'
		else:
			epgs=parseDOM(epgresult[0],'span')
			if epgs:
				for epg in epgs:
					plot+='[COLOR khaki]'+epg+'[/COLOR] '
					plot+='[CR][CR]'				
	result=parseDOM(content,'div', attrs={'class': "tab-content"})#[0]
	
	if result:
		result=result[0]
		co=1	
		tts=re.findall('<div role="tabpanel"(.+?)</div',result,re.DOTALL)
		for tt in tts:
			tthref=re.findall('id="(.+?)".+?<iframe.+?src="(.+?)"',tt,re.DOTALL)
			if  not tthref:
				continue
			else:
				typs=tthref[0][0]
				link=tthref[0][1]
				typ=' - [COLOR orangered][B](premium)[/COLOR][/B]'
				if 'free' in typs:
					typ=' - [COLOR yellowgreen][B](darmowy)[/COLOR][/B]'
				info='Link %s'%str(co)+typ
				html=getUrlReq(link,url,False)
				try:
					nooder_secure = html.cookies['nooder_secure']
					nooder_t = html.cookies['nooder_t']
					aa= html.content
					bb=re.findall('type="text/javascript">(.+?);window.onload',aa)
					bb2=re.findall('var (.+?) =',bb[0])
					bb2=bb2[0]
					bb=bb[0].replace('var ','').replace('; ',';\n')	
					aa=bb.replace('!!![]','0').replace('!!+[]','0').replace('!+[]','1').replace('!![]','1').replace('[]','0')
					exec(aa)
					a1=eval(bb2)
					kuk="nooder_secure=%s;nooder_t=%s;nooder_challenge=%s"%(nooder_secure,nooder_t,a1)
					nextlink=link.replace('embed.html?autoplay=false&','index.m3u8?')
					film = {'href': nextlink+'|User-Agent='+UA+'&Referer='+link+'&Cookie='+kuk,'title': info,'plot': plot,'img': imag,}	
				except:
					nextlink=link.replace('embed.html?autoplay=false&','index.m3u8?')
					film = {'href': nextlink+'|User-Agent='+UA+'&Referer='+link,'title': info,'plot': plot,'img': imag,}	
				out.append(film)
				co+=1
	return out
	
def getMovies(url,page=1,group=''):
	global mybtn_user
	mybtn_user = args.get('token',[''])[0]
	cuk=urllib.quote(mybtn_user)
	
	
	if '?page=' in url:
		url = url.replace('?page=','?page=%d' %page)
	else:
		url += '/' if url[-1] != '/' else ''
		url = url + '?page=%d' %page
	if group:
		url=url.split('?')[0]	
	content= getUrlReq(url,url)
	out=[]
	gr=False
	pr=False
	ids = []
	try:
		result=parseDOM(content,'div', attrs={'class': "col-sm-9"})[1]
	except:
		result=content		#<ul class='clearfix pagination'>
	mdata=parseDOM(content,'ul', attrs={'class': "clearfix pagination"})#[0]	 #<ul class='clearfix pagination'>
	mdata = urllib.unquote(mdata[0]) if mdata else content
	gr=False
	
	if mdata.find( '?page=%d' %(page+1))>-1:
		gr = page+1
	links=parseDOM(result,'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"}) #[0]	col-xs-6 col-sm-3 col-lg-2 #<ul class='clearfix pagination'>		links=
	for link in links:
		src = parseDOM(link, 'img', ret='src')[0]
		href = parseDOM(link, 'a', ret='href')[0]   
		plot = parseDOM(link, 'a', ret='data-text')#[0]  
		try:
			title = parseDOM(link,'div', attrs={'class': "title"})[0]
		except:
			title = parseDOM(link, 'a', ret='title')[0]  
		try:
			rating = parseDOM(link,'div', attrs={'class': "rate"})[0]
		except:
			rating =''
		try:
			year = int(parseDOM(link,'div', attrs={'class': "film_year"})[0])
		except:
			year=''
		if href and title:
			if src.startswith('//'):
				src = 'http:'+src
			film = {
				'href'   : href,
				'title'  : fixSC(title),
				'plot'   : fixSC(plot[0]) if plot else '',
				'img'    : src+'|User-Agent='+urllib.quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk,
				'rating' : rating,
				'year'   : year,
					}
			out.append(film)
		pr = page-1 if page>1 else False
	return (out, (pr,gr))	
	
def getSeries(url, page = 1,group = ''):
	global mybtn_user
	mybtn_user = args.get('token',[''])[0]
	cuk=urllib.quote(mybtn_user)
	if '?page=' in url:
		url = url.replace('?page=','?page=%d' %page)
	else:
		url += '/' if url[-1] != '/' else ''
		url = url + '?page=%d' %page
	if group:
		url=url.split('?')[0]
	content =getUrlReq(url,url)
	out=[]
	gr=False
	pr=False
	ids = []
	if group:
		result=parseDOM(content,'div', attrs={'id': "item-list"}) 
		if 'Ostatnio dodane' in group:
			result=result[0]
		else:
			result=result[1]
			
		links=parseDOM(result,'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"}) 
		for link in links:
			src = parseDOM(link, 'img', ret='src')[0]
			href = parseDOM(link, 'a', ret='href')[0]   
			title = parseDOM(link,'div', attrs={'class': "title"})[0]
			if href and title:
				if src.startswith('//'):
					src = 'http:'+src
				film = {
					'href'   : href,
					'title'  : fixSC(title),
					'plot'   : '',
					'img'    : src+'|User-Agent='+urllib.quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk,
						}
				out.append(film)	
	else: 
		result=parseDOM(content,'div', attrs={'class': "col-sm-9"})[1]	 
		mdata=parseDOM(content,'ul', attrs={'id': "series-list"})[0]	 
		mdata = urllib.unquote(mdata) if mdata else content
		gr=False
		
		if mdata.find( '?page=%d' %(page+1))>-1:
			gr = page+1	
		links=parseDOM(result,'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"}) 
		for link in links:
			src = parseDOM(link, 'img', ret='src')[0]
			href = parseDOM(link, 'a', ret='href')[0]   
			title = parseDOM(link,'div', attrs={'class': "title"})[0]
			if href and title:
				if src.startswith('//'):
					src = 'http:'+src
				film = {
					'href'   : href,
					'title'  : fixSC(title),
					'plot'   : '',
					'img'    : src+'|User-Agent='+urllib.quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk,
						}
				out.append(film)		
		pr = page-1 if page > 1 else False
	return (out, (pr,gr))

def parseVideoLink(url, host = ''):
	if 'cda' in host:
		return 'http://www.cda.pl/video/%s'%(url.split('id=')[-1])
	elif 'alltube' in url:
		content =getUrlReq(url,url)
		outurl=''
		href= re.compile('src="(.*?)"').findall(content)
		if href:
			href = [h for h in href if BRAMKA not in h]
			outurl = getHref(href[0])
			if outurl.startswith('//'):
				outurl = 'http:'+outurl
		return outurl
	elif str(host) in url:
		if url.startswith('//'):
			url = 'http:' + url
		return url
	else:
		return url

def getVideos(url):
	content =getUrlReq(url,url)
	
	out=[]
	result = parseDOM((parseDOM(content,'table', attrs={'id': "links"})[0]),'tbody')
	if result:
		links = parseDOM(result[0],'tr')
		for link in links:
			href=re.compile('href="(.*?)"').search(link)
			iframe = re.compile('data-iframe="(.*?)"').search(link)
			try:
				decodiframe=base64.b64decode(iframe.group(1)).replace('\/','/')
				hrefok=re.findall("""src['"]:['"](.+?)['"]\,""",decodiframe)[0] #.replace('\/','/')
				info = ' '.join(re.compile('>(.*?)<',re.DOTALL).findall(link))
				info = re.sub(' +','  ',fixSC(info))#.strip()
				info = re.sub('\(.+?\)','',info)
			except:
				pass
			if hrefok:
				film = {'url' : hrefok,'title': info,}
				out.append(film)
	return out

def scanEpisodes(url):
	global mybtn_user
	mybtn_user = args.get('token',[''])[0]
	cuk=urllib.quote(mybtn_user)
	content =getUrlReq(url,url)
	src = re.compile('<ul id="episode-list">(.*?)</ul>').findall(content)
	src = src[-1] if src else ''
	out=[]
	odcinki = content.find('Odcinki')
	odcinek = content.find('Dodaj odcinek')
	gdzie=re.findall('Odcinki(.+?)Dodaj odcinek',content,re.DOTALL)[0]
	if 'ten serial nie posiada' in gdzie:
		return out
	links = re.compile('<a href="(.*?)">(.*?)</a>',re.DOTALL).findall(gdzie)
	imgsrc = re.compile('class="col-sm-3">(.+?)<div',re.DOTALL).findall(content)	
	imgsrc = imgsrc[1] if imgsrc else ''
	imgsrc = re.compile('<img src="(.*?)"',re.DOTALL).findall(imgsrc)
	imgsrc = imgsrc[-1]+'|User-Agent='+urllib.quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk if imgsrc else ''
	for h,t in links:
		t= fixSC(t.strip())
		t=re.sub(' +',' ',t)
		data = re.compile('[sS](\d+)[Ee](\d+)').findall(t)
		
		film = {
			'href'  : h.strip(),
			'plot' : t,
			'title' : t,
			'img' : imgsrc,
			'season' : int(data[0][0]) if data else '',
			'episode' : int(data[0][1]) if data else '',
			'aired' : ''}
		out.append(film)
	return out

def splitToSeasons(input):
    out={}
    seasons = [x.get('season') for x in input]
    for s in set(seasons):
        out['Sezon %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
    return out

def getSort(mv='film',sc='category'):
	label=[]
	value=[]
	url = 'https://filman.cc/filmy-online/'
	if mv=='film':
		content =getUrlReq(url,BASEURL)
		if sc=='category':
			result=parseDOM(content,'ul', attrs={'id': "filter-category"})[0]
			value=parseDOM(result,'li', ret='data-id') #[0]
			label=parseDOM(result,'a')
		elif sc=='year':
			result=parseDOM(content,'ul', attrs={'id': "filter-year"})[0]
			value=parseDOM(result,'li', ret='data-id') #[0]
			label=parseDOM(result,'a')
		elif sc=='country': 
			result=parseDOM(content,'ul', attrs={'id': "filter-country"})[0]
			value=parseDOM(result,'li', ret='data-id') #[0]
			result = re.sub('	HiszpaniaWielka Brytania', 'Hiszpania/Wielka Brytania', result)
			result = re.sub(r'\s+', ' ', result)
			label=parseDOM(result,'a')
	elif mv=='serial':
		pass
	return (label,value)

def search(pharse='dom'):
	global mybtn_user
	mybtn_user = args.get('token',[''])[0]
	cuk=urllib.quote(mybtn_user)
	url='https://filman.cc/wyszukiwarka?phrase='+pharse
	content =getUrlReq(url,BASEURL)
	out1=[]
	out2=[]
	result=parseDOM(content,'div', attrs={'id': "advanced-search"})[0]
	links=parseDOM(result,'div', attrs={'class': "col-sm-4"})
	for link in links:
		src = parseDOM(link, 'img', ret='src')[0]
		src=src.replace('thumb','big')
		href = parseDOM(link, 'a', ret='href')[0]   
		title = parseDOM(link,'div', attrs={'class': "title"})[0] 
		plot = parseDOM(link,'div', attrs={'class': "description text-justify"})[0]  
		if href and title:
			if src.startswith('//'):
				src = 'http:'+src
			film = {
				'href'   : href,
				'title'  : fixSC(title),
				'plot'   : fixSC(plot),
				'img'    : src+'|User-Agent='+urllib.quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk,
					}
			if '/film' in film['href']:
				out1.append(film)
			elif '/serial'in film['href']:
				out2.append(film)
	return out1,out2

def fixSC(pharse):
    if isinstance(pharse, unicode):
        pharse = pharse.encode('utf-8')
    pharse = pharse.replace('&lt;br/&gt;',' ')
    s='JiNcZCs7'
    pharse = re.sub(s.decode('base64'),'',pharse)
    pharse = pharse.replace('\n','').replace('\r','').replace('\t','')
    pharse = pharse.replace('&nbsp;','')
    pharse = pharse.replace('&quot;','"').replace('&amp;quot;','"')
    pharse = pharse.replace('&oacute;','ó').replace('&Oacute;','Ó')
    pharse = pharse.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    pharse = pharse.replace('&amp;','&')
    pharse = pharse.replace('\u0105','ą').replace('\u0104','Ą')
    pharse = pharse.replace('\u0107','ć').replace('\u0106','Ć')
    pharse = pharse.replace('\u0119','ę').replace('\u0118','Ę')
    pharse = pharse.replace('\u0142','ł').replace('\u0141','Ł')
    pharse = pharse.replace('\u0144','ń').replace('\u0144','Ń')
    pharse = pharse.replace('\u00f3','ó').replace('\u00d3','Ó')
    pharse = pharse.replace('\u015b','ś').replace('\u015a','Ś')
    pharse = pharse.replace('\u017a','ź').replace('\u0179','Ź')
    pharse = pharse.replace('\u017c','ż').replace('\u017b','Ż')
    return pharse


mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
rys = args.get('iconImage',[''])[0]
page = args.get('page',[1])[0]
sortv = my_addon.getSetting('sortV')
sortn = my_addon.getSetting('sortN') if sortv else 'Daty dodania'
qualityv = my_addon.getSetting('qualityV')
qualityn = my_addon.getSetting('qualityN') if qualityv else 'Wszystkie'
versionv = my_addon.getSetting('versionV')
versionn = my_addon.getSetting('versionN') if versionv else 'Wszystkie'

if mode is None:
	login()
	addDir(name="Telewizja (LIVE)",ex_link='https://filman.cc/telewizja-online',page=1, mode='ListTv',iconImage='DefaultFolder.png',fanart=FANART)
	addLinkItem("[COLOR lightblue]Sortowanie:[/COLOR] [B]"+sortn+"[/B]",'',mode='filtr:sort',iconimage='',IsPlayable=False)
	addLinkItem("[COLOR lightblue]Jakość:[/COLOR] [B]"+qualityn+"[/B]",'',mode='filtr:quality',iconimage='',IsPlayable=False)
	addLinkItem("[COLOR lightblue]Wersja:[/COLOR] [B]"+versionn+"[/B]",'',mode='filtr:version',iconimage='',IsPlayable=False)
	addDir(name="[COLOR blue]Filmy[/COLOR]",ex_link='https://filman.cc/filmy-online/',page=1, mode='ListMovies',iconImage='DefaultFolder.png',fanart=FANART)
	addDir(name=" [Kategoria]",ex_link='film|category',page=1, mode='GatunekRok',iconImage='DefaultFolder.png',fanart=FANART)
	addDir(name=" [Rok]",ex_link='film|year',page=1, mode='GatunekRok',iconImage='DefaultFolder.png',fanart=FANART)
	addDir(name=" [Kraj]",ex_link='film|country',page=1, mode='GatunekRok',iconImage='DefaultFolder.png',fanart=FANART)
	addDir(name="[COLOR blue]Seriale (Lista)[/COLOR]",ex_link='https://filman.cc/seriale-online/',page=1, mode='ListSeriale',iconImage='DefaultFolder.png',fanart=FANART)
	addDir(name=" Ostatnio dodane seriale",ex_link='https://filman.cc/seriale-online/|Ostatnio dodane seriale',page=1, mode='ListSeriale',iconImage='DefaultFolder.png',fanart=FANART)
	addDir(name=" Popularne seriale",ex_link='https://filman.cc/seriale-online/|Popularne seriale',page=1, mode='ListSeriale',iconImage='DefaultFolder.png',fanart=FANART)
	addDir(name="[COLOR blue]Dla dzieci[/COLOR]",ex_link='https://filman.cc/dla-dzieci/',page=1, mode='ListMovies',iconImage='DefaultFolder.png',fanart=FANART)
	addDir('[COLOR lightblue]Szukaj[/COLOR]','',mode='Szukaj')
	addLinkItem('[COLOR gold]-=Opcje=-[/COLOR]','','Opcje',IsPlayable=False)
#	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle,True)
elif 'filtr' in mode[0]:
	myMode = mode[0].split(":")[-1]
	
	if myMode=='sort':
		label=[u'Daty dodania',u'Liczba głosów',u'Premiera',u'Odsłony',u'Ocena']
		value=['sort:date','sort:vote','sort:premiere','sort:view','sort:rate']	
		
		msg = 'Sortowanie'
	elif myMode=='quality':
		label=[u'Wszystkie',u'Niska',u'Średnia',u'Wysoka']
		value=['','quality:1','quality:2','quality:3']
		msg = 'Jakość'
	elif myMode=='version':
		label=['Wszystkie','Dubbing',   'Dubbing Kino','ENG',      'Lektor',   'Lektor IVO','Napisy',  'PL']
		value=[''         ,'version:2', 'version:7',   'version:5','version:1','version:6', 'version:3','version:4']
		msg = 'Wersja'
				
	if myMode in ['quality','version']:
		try:
			sel = xbmcgui.Dialog().select('Wybierz wersje językową',label) #l1l1l11ll11l1l11_nktv_
		except:
			sel = xbmcgui.Dialog().select('Wybierz wersje językową',label)
		if isinstance(sel,list):
			if 0 in sel: sel=[0]
			v = myMode+':'+','.join( [ value[i].replace(myMode+':','') for i in sel])
			n = ','.join( [ label[i] for i in sel])
		else:
			if sel>-1:
				v = value[sel]
				n = label[sel]
				my_addon.setSetting(myMode+'V',v)
				my_addon.setSetting(myMode+'N',n)
				xbmc.executebuiltin('XBMC.Container.Refresh')
			else:
				pass
	else:
		sel = xbmcgui.Dialog().select(msg,label)
		if sel>-1:
			v = value[sel]
			n = label[sel]
	
			my_addon.setSetting(myMode+'V',v)
			my_addon.setSetting(myMode+'N',n)
			xbmc.executebuiltin('XBMC.Container.Refresh')
		else:
			pass
			
elif mode[0] == 'playTv':
	PlayTv(ex_link)
	#xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle,True)	
elif mode[0] == 'ListTv':
	listTv(ex_link)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE , label2Mask = "%R, %Y, %P")
#	xbmcplugin.setContent(addon_handle, 'movies')		
	xbmcplugin.endOfDirectory(addon_handle,True)
elif mode[0] == 'getTvLinks':
	getTvLinks(ex_link,rys)
#	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle,True)	
elif mode[0] == 'ListMovies':
	sr = '/'.join([x for x in [sortv,qualityv,versionv] if x]) if '/filmy-online/' in ex_link else ''
	listMovies(ex_link+sr,page)
	
#	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle,True)
elif mode[0] == 'ListMoviesKids':
	listMovies(ex_link,page)
#	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle,True)	
elif mode[0] == 'Opcje':
    my_addon.openSettings()
    xbmc.executebuiltin('XBMC.Container.Refresh()')	

elif mode[0] == '__page__M':
	url = build_url({'mode': 'ListMovies', 'foldername': '', 'ex_link' : ex_link, 'page': page})
	xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == '__page__S':
	url = build_url({'mode': 'ListSeriale', 'foldername': '', 'ex_link' : ex_link, 'page': page})
	xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == 'getEpisodes':
	getEpisodes(ex_link)

elif mode[0] == 'getEpisodes2':
	getEpisodes2(ex_link)
	
elif mode[0] == 'ListSeriale':
	listSeries(ex_link,page)
	if 'Ostatnio dodane seriale' in ex_link:
		xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE , label2Mask = "%R, %Y, %P")
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE , label2Mask = "%R, %Y, %P")
#	xbmcplugin.setContent(addon_handle, 'tvshows')
	xbmcplugin.endOfDirectory(addon_handle,True)
elif mode[0] == 'getSeasons':
	getSeasons(ex_link)

elif mode[0] == 'ListFS':
	listFS(ex_link)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE , label2Mask = "%R, %Y, %P")
#	xbmcplugin.setContent(addon_handle, 'tvshows')
	xbmcplugin.endOfDirectory(addon_handle,True)
elif mode[0] == 'getLinks':
    getLinks(ex_link)

elif mode[0] == 'DOWNLOAD':
    data = eval(ex_link)
    download_path = my_addon.getSetting('download.path')

    if download_path:
        getLinks(data.get('href'), True, data.get('title'), data.get('img'))
    else:
        xbmcgui.Dialog().ok('Ustaw docelowy folder', 'Pobieranie nie powiodło się')
    xbmcplugin.endOfDirectory(addon_handle,True)
elif mode[0] == 'GatunekRok':
	param = ex_link.split('|')
	label,value = getSort(mv = param[0], sc = param[1])
	
	try:
		sel = xbmcgui.Dialog().select('Wybierz ',label)
	except:
		sel = xbmcgui.Dialog().select('Wybierz',label)
	
	if isinstance(sel,list):
		v = param[1]+':'+','.join([ value[i] for i in sel])
	else:
		if sel>-1:
			sel=sel
			v = param[1]+':'+value[sel]
			sr = '/'.join([x for x in [sortv,qualityv,versionv,v] if x])
			listMovies('https://filman.cc/filmy-online/'+sr,1)
			xbmcplugin.endOfDirectory(addon_handle,True)
		else:
			xbmc.executebuiltin('XBMC.Container.Refresh()')			
elif mode[0] =='Szukaj':
	global mybtn_user
	mybtn_user = args.get('token',[''])[0]
	addDir('[COLOR green]Nowe Szukanie[/COLOR]','',mode='SzukajNowe')
	history = getHistory()
	if not history == ['']:
		for entry in history:
			contextmenu = []
			contextmenu.append((u'Usun', 'XBMC.Container.Refresh(%s)'% build_url({'mode': 'SzukajUsun', 'ex_link' : entry, 'token': mybtn_user})),) #, 'token': mybtn_user})
			contextmenu.append((u'Usun cała historie', 'XBMC.Container.Update(%s)' % build_url({'mode': 'SzukajUsunAll', 'token': mybtn_user})),)
			addDir(name=entry, ex_link=entry.replace(' ','+'), mode='ListFS', fanart=None, contextmenu=contextmenu)
	xbmcplugin.endOfDirectory(addon_handle,True)
elif mode[0] =='SzukajNowe':
    d = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu/serialu', type=xbmcgui.INPUT_ALPHANUM)
    if d:
        setHistory(d)
        ex_link=d.replace(' ','+')
        listFS(ex_link)
   #     xbmcplugin.setContent(addon_handle, 'tvshows')
    xbmcplugin.endOfDirectory(addon_handle,True)
elif mode[0] =='SzukajUsun':
    remCache(ex_link)
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj', 'token': mybtn_user}))
    xbmcplugin.endOfDirectory(addon_handle,True)
elif mode[0] == 'SzukajUsunAll':
    delHistory()
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj', 'token': mybtn_user}))
    xbmcplugin.endOfDirectory(addon_handle,True)
elif mode[0] == 'folder':
    pass
else:
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

