# -*- coding: utf-8 -*-
import urllib2,urllib
import re,os,base64,time
import xbmc, xbmcaddon, xbmcgui
from urlparse import urlparse
from urlparse import urlsplit
import requests
from CommonFunctions import parseDOM

UA           = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
my_addon     = xbmcaddon.Addon()
DATAPATH     = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
COOKIEFILE   = os.path.join(DATAPATH,'cookie')
my_addon     = xbmcaddon.Addon()
TIMEOUT      = 10
my_url       = 'http://filman.cc/'

s = requests.Session()
s.headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0'})

def getUrl(url,data=None,header={}):
	out=s.get(url,verify=False).text
	return out

def getTvs(url):
	content = getUrl(url) 
	out=[]
	result=parseDOM(content,'div', attrs={'class': "row tv-list"})[0]
	links=parseDOM(result,'div', attrs={'class': "col-xs-6 col-sm-3"})
	for link in links:
		src = parseDOM(link, 'img', ret='src')[0]
		href = parseDOM(link, 'a', ret='href')[0]   
		title = parseDOM(link, 'a', ret='title')[0]  
		if href and title:
			if src.startswith('//'):
				src = 'http:'+src
			film = {
				'href'   : href,
				'title'  : title,
				'plot'   : '',
				'img'    : src,}
			out.append(film)
	return out	

#def getM3u8(url):
#	vidurl=''
#	content = getUrl(url) 
#	if 'filmen' in url:
#		nxt=re.findall('"streamName":"(.+?)"',content)[0]
#		host = urlsplit(url).netloc
#		vidurl='https://%s/%s/index.m3u8'%(host,nxt)
#	else:
#		vidurl=re.findall('file:"(.+?)"',content)[0]
#	vidurl = 'http:'+vidurl if vidurl.startswith('//') else vidurl
#	return vidurl
	
def getEpg(url):
	content = getUrl(url)
	plot=''
	trwa=parseDOM(content,'b')[0]
	czastrwa=parseDOM(content,'p')[1]
	czastrwado=parseDOM(content,'p')[2]
	dalej=parseDOM(content,'table', attrs={'width': ".+?"})[0]
	plot+='[COLOR khaki]'+czastrwa+'-'+czastrwado+'[/COLOR] '+trwa
	plot+='[CR]'
	try:
		typhourtitle=re.findall('<tr.+?title="(.+?)".+?<b>(.+?)<\/b.+?<td>(.+?)<\/td',dalej)#[0]
		for typ,hour,title in typhourtitle:
			plot+='[COLOR khaki]'+hour+'[/COLOR] '+title
			plot+='[CR]'
	except:
		pass
	return plot
	
def getTvLink(url,tyt):
	content = getUrl(url) 
	out=[]
	epgresult=parseDOM(content,'hr')[0]
	epgurl= parseDOM(epgresult, 'iframe', ret='src')#[0]
	if epgurl:
		epg=getEpg(epgurl[0])
	else:
		epg=tyt

	ig=parseDOM(content,'div', attrs={'class': "col-md-4"})[0] #<div class="col-md-4">
	imag= parseDOM(ig, 'img', ret='src')[0]
	try:
		vidurl=re.findall('"file": "(.+?m3u8)"',content)[0]	
	except:
		result=parseDOM(content,'div', attrs={'class': "col-md-8 tv-code"})[0]
		linkurl= parseDOM(result, 'iframe', ret='src')[0]		
		content = getUrl(linkurl) 
		if 'filmen' in linkurl:
			nxt=re.findall('"streamName":"(.+?)"',content)[0]
			host = urlsplit(linkurl).netloc
			vidurl='https://%s/%s/index.m3u8'%(host,nxt)
		else:
			vidurl=re.findall('file:"(.+?)"',content)[0]
			vidurl = 'http:'+vidurl if vidurl.startswith('//') else vidurl
	if vidurl:
		link = 'http:'+vidurl if vidurl.startswith('//') else vidurl #+'User-Agent='+UA+'&Referer='+url
	co=1

	info='Link %s'%str(co)
	film = {'href': link,'title': info,'plot': epg,'img': imag,}			
	out.append(film)
	return out
	
def getMovies(url,page=1,group=''):
	if '?page=' in url:
		url = url.replace('?page=','?page=%d' %page)
	else:
		url += '/' if url[-1] != '/' else ''
		url = url + '?page=%d' %page
	if group:
		url=url.split('?')[0]	
	content = getUrl(url) 
	out=[]
	gr=False
	pr=False
	ids = []
	try:
		result=parseDOM(content,'div', attrs={'class': "col-sm-9"})[1]
	except:
		result=content		#<ul class='clearfix pagination'>
	mdata=parseDOM(content,'ul', attrs={'class': "clearfix pagination"})#[0]	 #<ul class='clearfix pagination'>
	mdata = urllib.unquote(mdata[0]) if mdata else content
	gr=False
	
	if mdata.find( '?page=%d' %(page+1))>-1:
		gr = page+1
	links=parseDOM(result,'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"}) #[0]	col-xs-6 col-sm-3 col-lg-2 #<ul class='clearfix pagination'>		links=
	for link in links:
		src = parseDOM(link, 'img', ret='src')[0]
		href = parseDOM(link, 'a', ret='href')[0]   
		plot = parseDOM(link, 'a', ret='title')#[0]  
		title = parseDOM(link,'div', attrs={'class': "title"})[0]
		try:
			rating = parseDOM(link,'div', attrs={'class': "rate"})[0]
		except:
			rating =''
		try:
			year = int(parseDOM(link,'div', attrs={'class': "year"})[0])
		except:
			year=''
		if href and title:
			if src.startswith('//'):
				src = 'http:'+src
			film = {
				'href'   : href,
				'title'  : fixSC(title),
				'plot'   : fixSC(plot[0]) if plot else '',
				'img'    : src,
				'rating' : rating,
				'year'   : year,
					}
			out.append(film)
		pr = page-1 if page>1 else False
	return (out, (pr,gr))

def getSeries(url, page = 1,group = ''):
	if '?page=' in url:
		url = url.replace('?page=','?page=%d' %page)
	else:
		url += '/' if url[-1] != '/' else ''
		url = url + '?page=%d' %page
	if group:
		url=url.split('?')[0]
	content = getUrl(url)
	out=[]
	gr=False
	pr=False
	ids = []
	if group:
		result=parseDOM(content,'div', attrs={'id': "item-list"}) #[1]	 #<ul class='clearfix pagination'>	
		if 'Ostatnio dodane' in group:
			result=result[0]
		else:
			result=result[1]
			
		links=parseDOM(result,'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"}) #[0]col-xs-6 col-sm-3 col-lg-2	 #<ul class='clearfix pagination'>		links=
		for link in links:
			src = parseDOM(link, 'img', ret='src')[0]
			href = parseDOM(link, 'a', ret='href')[0]   
			title = parseDOM(link,'div', attrs={'class': "title"})[0]
			if href and title:
				if src.startswith('//'):
					src = 'http:'+src
				film = {
					'href'   : href,
					'title'  : fixSC(title),
					'plot'   : '',
					'img'    : src,
						}
				out.append(film)	
	else: 
		result=parseDOM(content,'div', attrs={'class': "col-sm-9"})[1]	 #<ul class='clearfix pagination'>
		mdata=parseDOM(content,'ul', attrs={'id': "series-list"})[0]	 #<ul class='clearfix pagination'>
		mdata = urllib.unquote(mdata) if mdata else content
		gr=False
		
		if mdata.find( '?page=%d' %(page+1))>-1:
			gr = page+1	
		links=parseDOM(result,'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"}) #[0]col-xs-6 col-sm-3 col-lg-2	 #<ul class='clearfix pagination'>		links=
		for link in links:
			src = parseDOM(link, 'img', ret='src')[0]
			href = parseDOM(link, 'a', ret='href')[0]   
			title = parseDOM(link,'div', attrs={'class': "title"})[0]
			if href and title:
				if src.startswith('//'):
					src = 'http:'+src
				film = {
					'href'   : href,
					'title'  : fixSC(title),
					'plot'   : '',
					'img'    : src,
						}
				out.append(film)		
		pr = page-1 if page > 1 else False
	return (out, (pr,gr))

def parseVideoLink(url, host = ''):
    if 'cda' in host:
        return 'http://www.cda.pl/video/%s'%(url.split('id=')[-1])
    elif 'alltube' in url:
        content = getUrl(url)
        outurl=''
        href= re.compile('src="(.*?)"').findall(content)
        if href:
            href = [h for h in href if BRAMKA not in h]
            outurl = getHref(href[0])
            if outurl.startswith('//'):
                outurl = 'http:'+outurl
        return outurl
    elif str(host) in url:
        if url.startswith('//'):
            url = 'http:' + url
        return url
    else:
        return url

def getVideos(url):
	content=getUrl(url)
	data = re.compile('<tbody>(.*?)</tbody>',re.DOTALL).findall(content)
	data = data[0] if data else ''
	ids = [(a.start(), a.end()) for a in re.finditer('<tr>', data)]
	ids.append( (-1,-1) )
	out=[]
	for i in range(len(ids[:-1])):
		wc = data[ ids[i][1]:ids[i+1][0] ]
		href=re.compile('href="(.*?)"').search(wc)
		iframe = re.compile('data-iframe="(.*?)"').search(wc)
		try:
			decodiframe=base64.b64decode(iframe.group(1)).replace('\/','/')
			hrefok=re.findall("""src['"]:['"](.+?)['"]\,""",decodiframe)[0] #.replace('\/','/')
			info = ''.join(re.compile('>(.*?)<',re.DOTALL).findall(wc))
			info = re.sub(' +',' ',fixSC(info)).strip()
		except:
			pass
		if hrefok:
			film = {'url' : hrefok,'title': info,}
			out.append(film)
	return out

def scanEpisodes(url):
    content = getUrl(url)
    src = re.compile('<ul id="episode-list">(.*?)</ul>').findall(content)
    src = src[-1] if src else ''
    out=[]
    odcinki = content.find('Odcinki')
    odcinek = content.find('Dodaj odcinek')
    links = re.compile('<a href="(.*?)">(.*?)</a>',re.DOTALL).findall(content[odcinki:odcinek])
    imgsrc = re.compile('<div id="single-poster" class="col-sm-3">(.*?)</div>').search(content)
    imgsrc = imgsrc[-1] if imgsrc else ''
    imgsrc = re.compile('<img src="(.*?)"',re.DOTALL).search(imgsrc)
    for h,t in links:
        t= fixSC(t.strip())
        t=re.sub(' +',' ',t)
        data = re.compile('[sS](\d+)[Ee](\d+)').findall(t)
        film = {
            'href'  : h.strip(),
            'plot' : t,
            'title' : t,
            'img' : imgsrc,
            'season' : int(data[0][0]) if data else '',
            'episode' : int(data[0][1]) if data else '',
            'aired' : ''}
        out.append(film)
    return out

def splitToSeasons(input):
    out={}
    seasons = [x.get('season') for x in input]
    for s in set(seasons):
        out['Sezon %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
    return out

def getSort(mv='film',sc='category'):
	label=[]
	value=[]
	url = 'https://filman.cc/filmy-online/'
	if mv=='film':
		content = getUrl(url)
		if sc=='category':
			result=parseDOM(content,'ul', attrs={'id': "filter-category"})[0]
			value=parseDOM(result,'li', ret='data-id') #[0]
			label=parseDOM(result,'a')
		elif sc=='year':
			result=parseDOM(content,'ul', attrs={'id': "filter-year"})[0]
			value=parseDOM(result,'li', ret='data-id') #[0]
			label=parseDOM(result,'a')
		elif sc=='country': 
			result=parseDOM(content,'ul', attrs={'id': "filter-country"})[0]
			value=parseDOM(result,'li', ret='data-id') #[0]
			result = re.sub('	HiszpaniaWielka Brytania', 'Hiszpania/Wielka Brytania', result)
			result = re.sub(r'\s+', ' ', result)
			label=parseDOM(result,'a')
	elif mv=='serial':
		pass
	return (label,value)

def search(pharse='dom'):
	url='https://filman.cc/wyszukiwarka?phrase='+pharse
	content=getUrl(url)
	out1=[]
	out2=[]
	result=parseDOM(content,'div', attrs={'id': "advanced-search"})[0]
	links=parseDOM(result,'div', attrs={'class': "col-sm-4"})
	for link in links:
		src = parseDOM(link, 'img', ret='src')[0].replace('/thumb/','/big/')
		href = parseDOM(link, 'a', ret='href')[0]   
		title = parseDOM(link,'div', attrs={'class': "title"})[0] 
		plot = parseDOM(link,'div', attrs={'class': "description text-justify"})[0]  
		if href and title:
			if src.startswith('//'):
				src = 'http:'+src
			film = {
				'href'   : href,
				'title'  : fixSC(title),
				'plot'   : fixSC(plot),
				'img'    : src,
					}
			if '/film/' in film['href']:
				out1.append(film)
			elif '/serial'in film['href']:
				out2.append(film)
	return out1,out2

def fixSC(pharse):
    if isinstance(pharse, unicode):
        pharse = pharse.encode('utf-8')
    pharse = pharse.replace('&lt;br/&gt;',' ')
    s='JiNcZCs7'
    pharse = re.sub(s.decode('base64'),'',pharse)
    pharse = pharse.replace('\n','').replace('\r','')
    pharse = pharse.replace('&nbsp;','')
    pharse = pharse.replace('&quot;','"').replace('&amp;quot;','"')
    pharse = pharse.replace('&oacute;','ó').replace('&Oacute;','Ó')
    pharse = pharse.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    pharse = pharse.replace('&amp;','&')
    pharse = pharse.replace('\u0105','ą').replace('\u0104','Ą')
    pharse = pharse.replace('\u0107','ć').replace('\u0106','Ć')
    pharse = pharse.replace('\u0119','ę').replace('\u0118','Ę')
    pharse = pharse.replace('\u0142','ł').replace('\u0141','Ł')
    pharse = pharse.replace('\u0144','ń').replace('\u0144','Ń')
    pharse = pharse.replace('\u00f3','ó').replace('\u00d3','Ó')
    pharse = pharse.replace('\u015b','ś').replace('\u015a','Ś')
    pharse = pharse.replace('\u017a','ź').replace('\u0179','Ź')
    pharse = pharse.replace('\u017c','ż').replace('\u017b','Ż')
    return pharse