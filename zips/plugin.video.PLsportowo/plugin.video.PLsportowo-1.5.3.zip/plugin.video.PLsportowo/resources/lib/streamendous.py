# -*- coding: UTF-8 -*-
import sys
import urllib2,urllib
import cookielib
import threading
import re
import time
import requests
from CommonFunctions import parseDOM
import urlparse
import mydecode
reload(sys)
sys.setdefaultencoding('utf8')

BASEURL='http://www.streamendous.com'
BASEURL2='https://cricfree.stream/'
BASEURL3='http://strims.world/'

UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'

def getUrl(url,ref=BASEURL2):
	headers = {'User-Agent': UA,'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8','Referer': ref,}
	html=requests.get(url,headers=headers,verify=False).content
	return html
	
def getScheduleCR():
	out=[]
	html=getUrl(BASEURL2)
	divs = parseDOM(html,'div',attrs = {'class':'panel_mid_body'})#[1] #<div class="panel_mid_body">
	for div in divs:
		day = parseDOM(div,'h2')#[0]
		if day:
			day='kiedy|%s'%day[0]
			out.append({'href':day})
		trs = parseDOM(div,'tr')#[0]
		for tr in trs:
			online= '[COLOR lime]► [/COLOR]' if tr.find('images/live.gif')>0 else '[COLOR orangered]■ [/COLOR]'
			if '>VS</td>' in tr:
				czas,dysc,team1,team2,href=re.findall('>(\d+:\d+)</td>.+?<span title="(.+?)".+?href=.+?>(.+?)<.+?>VS<.+?a href.+?>(.+?)</a>.+?<a class="watch_btn" href="(.+?)"',tr,re.DOTALL)[0]
				mecz='%s vs %s'%(team1,team2)
				
				czas=czas.split(':')
				hrs=int(czas[0])+1
				if hrs==24:
					hrs='00'
				mins=czas[1]
				czas='%s:%s'%(str(hrs),mins)
			else:
				czas,dysc,team1,href=re.findall('>(\d+:\d+)</td>.+?<span title="(.+?)".+?href=.+?>(.+?)<.+?<a class="watch_btn" href="(.+?)"',tr,re.DOTALL)[0]
				mecz=team1
			title = '[B][COLOR khaki]%s%s : [/COLOR][/B][COLOR gold][B]%s[/B][/COLOR]'%(online,czas,mecz)
			out.append({'title':title,'href':href,'code':dysc})
	return out
	
def getChannelsCR():
	out=[]
	html=getUrl(BASEURL2)
	result = parseDOM(html,'ul',attrs = {'class':"nav-sidebar"})[0]#<div class="arrowgreen">
	channels = parseDOM(result,'li')
	for channel in channels:
		if '<ul class="nav-submenu">' in channel:
			continue
		try:
			href = parseDOM(channel,'a',ret='href')[0]
			title = parseDOM(channel,'a',ret='title')[0]
			out.append({'href':href,'title':'[COLOR lime]► [/COLOR] [B][COLOR gold]'+title+'[/COLOR][/B]'})
		except:
			pass
	return out	
	
def getSWstreams(url):
	out=[]
	html=getUrl(url)
	try:
		result = parseDOM(html,'font',attrs = {'size':'3'})[0]
		t = re.sub('--.*?>', '', result)
		result= t.replace('\r\n\r\n','')	
		xx=re.findall('(\w+)\: <a(.+?)adsbygoogle',result,re.DOTALL)
		for x in xx:
			tit='%s'%x[0]
			aa=re.findall('href="(.+?)".+?>(.+?)</a>',x[1],re.DOTALL)
			for a in aa:
				href= a[0]
				tytul= a[1].replace('<b>','').replace('</b>','')
				tyt='%s - [B]%s[/B]'%(tytul,tit)
				href=url+href
				out.append({'href':href,'title':tyt})		
	except:
		out.append({'href':url,'title':'Link 1'})
	return out
def getCRlink(url):
	out=[]
	html=getUrl(url)
	result = parseDOM(html,'div',attrs = {'class':'video_btn'})#[0]
	if result:
		hrefhost=re.findall('link="(.+?)">(.+?)<',result[0],re.DOTALL)
		for href,host in hrefhost:
			out.append({'href':href,'title':host})
	return out
def resolvingCR(url,ref):
	html=getUrl(url,ref)
	vido_url = mydecode.decode(url,html)
	return vido_url
	
def getScheduleSE():
	out=[]
	html=getUrl(BASEURL)
	result = parseDOM(html,'table',attrs = {'align':'center'})[1]
	nt=re.findall("font-size:18px'>Thursday - Feb 14th, 2019<",result)
	tds = parseDOM(result,'tr',attrs = {'style':' height:35px; vertical-align:top;'})#[0]
	dat= parseDOM(result,'span',attrs = {'style':' font-size:18px'})#<span style='font-size:18px'>
	for td in tds:
		
		tdk = parseDOM(td,'td')[0]

		czas = parseDOM(tdk,'td',attrs = {'class':'matchtime'})[0]
		teams = parseDOM(tdk,'td')[2]
		href = parseDOM(tdk,'a',ret='href')[0]
		href = BASEURL+href if href.startswith('/') else href
		dysc=teams.split(':')[0]
		tem=teams.split(':')[1]
		tit='%s - %s'%(czas,tem)
		out.append({'href':href+'|sch','title':tit,'code':dysc})
	return out

def getChannelsSE():
	out=[]
	html=getUrl(BASEURL)
	result = parseDOM(html,'div',attrs = {'class':'arrowgreen'})[0]#<div class="arrowgreen">
	lis = parseDOM(result,'li')#[0]
	for li in lis:
		title = parseDOM(li,'img',ret='alt')#[0]
		if title:
			if 'schedule' in title[0].lower():
				continue
		title=title[0] if title else parseDOM(li,'a')[0]
		href = parseDOM(li,'a',ret='href')[0]
		href = BASEURL+href if href.startswith('/') else href
		imag = parseDOM(li,'img',ret='src')#[0]
		imag= BASEURL+'/'+imag[0] if imag else ''
		out.append({'href':href+'|chan','title':title,'image':imag})
	return out	
	
def getSElink(url):
	
	out=[]
	url2=url.split('|')[0]
	
	query=urlparse.urlparse(url2).query
	co=1
	if 'sch' in url.split('|')[1]:
		url3='%s/streams/ss/ss%s.html'%(BASEURL,query)
		html=getUrl(url3,BASEURL)
		xbmc.sleep(2000) 
		stream=mydecode.decode(url3,html)
		if stream:
			out.append({'href':stream,'title':'Link %d'%co})
		return out
	else:
		url='%s/streams/misc/%s.html'%(BASEURL,query)
	html=getUrl(url,BASEURL)
	links=re.findall('id="link\d+" class="class_.+?" href="(.+?)"',html,re.DOTALL)
	
	for link in links:
		link= BASEURL+link if link.startswith('/') else link
		query=urlparse.urlparse(link).query
		if not query:
			query=link #if not query
		out.append({'href':query,'title':'Link %d'%co})

		co+=1
	return out

def getScheduleSW():
	out=[]
	html=getUrl(BASEURL3)
	first  = parseDOM(html,'div',attrs = {'class':'tab'})[0]#<div class="tab">
	iddaydate=re.findall("event, '(.+?)'\).+?<b>(.+?)</b>.+?<b>(.+?)</b>",first,re.DOTALL)
	for id,day,date in iddaydate:

		result = parseDOM(html,'div',attrs = {'id':id})[0]
		xxx=re.findall('(\d+:\d+).+?href="(.+?)".+?>([^<]+)</a>',result,re.DOTALL)#(\d+:\d+).+?href="(.+?)".+?>([^<]+)</a>
		if xxx:
			day=('kiedy|%s %s'%(day,date)).replace('FIRDAY','FRIDAY')	
			out.append({'href':day})	
			for czas,href,tyt in  xxx:
				tyt = '[B][COLOR khaki]%s : [/COLOR][/B][COLOR gold][B]%s[/B][/COLOR]'%(czas,tyt)
				out.append({'title':tyt,'href':'http://strims.world/'+href})				
	return out
	
def getChannelsSW():
	out=[]
	html=getUrl(BASEURL3+'sports-channel/')
	result = parseDOM(html,'tbody')[0]
	hrefimage=re.findall('<a href="(.+?)"><img src="(.+?)"></a>',result,re.DOTALL)
	for href,image in hrefimage:
		tyt=href.split('-stream-online')[0].replace('-',' ').upper()
		href = 'http://strims.world/sports-channel/'+href
		out.append({'href':href,'title':'[COLOR lime]► [/COLOR] [B][COLOR gold]'+tyt+'[/COLOR][/B]','image':image})
	return out	
	
def getSWlink(url):
	stream=''
	playt=True
	html=getUrl(url,BASEURL3)
	if 'streamamg.com' in html:
		iframes= parseDOM(html,'iframe',ret='src')#[0]
		for iframe in iframes:
			if 'streamamg.' in iframe:
				html2=getUrl(iframe,url)	
				xx=re.findall('"partnerId":(\d+)',html2,re.DOTALL)[0]
				xx2=re.findall('"rootEntryId":"(.+?)"',html2,re.DOTALL)[0]
				m3u8='http://open.http.mp.streamamg.com/p/%s/playManifest/entryId/%s/format/applehttp'%(xx,xx2)
				return m3u8+'|User-Agent='+UA+'&Referer='+iframe,False
	stream=re.findall('source: "(.+?)"',html,re.DOTALL)
	if stream:
		stream=stream[0]	
	else:
		stream=re.findall('source src="(.+?)"',html,re.DOTALL)[0]
		playt=False
	return stream+'|User-Agent='+UA+'&Referer='+url,playt
	
	