# -*- coding: UTF-8 -*-

import sys
import urllib2,urllib
import cookielib
import threading
import re
import time
import requests
from CommonFunctions import parseDOM
import urlparse
import mydecode
reload(sys)
sys.setdefaultencoding('utf8')


BASEURL='http://www.streamendous.com'
BASEURL2='https://cricfree.stream/'
UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'

def getUrl(url,ref=BASEURL2):
	headers = {'User-Agent': UA,'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8','Referer': ref,}
	html=requests.get(url,headers=headers,verify=False).content
	return html
	
def getScheduleCR():
	out=[]
	html=getUrl(BASEURL2)
	divs = parseDOM(html,'div',attrs = {'class':'panel_mid_body'})#[1] #<div class="panel_mid_body">
	for div in divs:
		day = parseDOM(div,'h2')#[0]
		if day:
			day='kiedy|%s'%day[0]
			out.append({'href':day})
		trs = parseDOM(div,'tr')#[0]
		for tr in trs:
			online= '[COLOR lime]► [/COLOR]' if tr.find('images/live.gif')>0 else '[COLOR orangered]■ [/COLOR]'
			if '>VS</td>' in tr:
				czas,dysc,team1,team2,href=re.findall('>(\d+:\d+)</td>.+?<span title="(.+?)".+?href=.+?>(.+?)<.+?>VS<.+?a href.+?>(.+?)</a>.+?<a class="watch_btn" href="(.+?)"',tr,re.DOTALL)[0]
				mecz='%s vs %s'%(team1,team2)
				
				czas=czas.split(':')
				hrs=int(czas[0])+1
				if hrs==24:
					hrs='00'
				mins=czas[1]
				czas='%s:%s'%(str(hrs),mins)
			else:
				czas,dysc,team1,href=re.findall('>(\d+:\d+)</td>.+?<span title="(.+?)".+?href=.+?>(.+?)<.+?<a class="watch_btn" href="(.+?)"',tr,re.DOTALL)[0]
				mecz=team1
			title = '%s%s: [COLOR gold][B]%s[/B][/COLOR]'%(online,czas,mecz)
			out.append({'title':title,'href':href,'code':dysc})
	return out
	
def getChannelsCR():
	out=[]
	html=getUrl(BASEURL2)
	result = parseDOM(html,'ul',attrs = {'class':"nav-sidebar"})[0]#<div class="arrowgreen">
	channels = parseDOM(result,'li')
	for channel in channels:
		if '<ul class="nav-submenu">' in channel:
			continue
		try:
			href = parseDOM(channel,'a',ret='href')[0]
			title = parseDOM(channel,'a',ret='title')[0]
			out.append({'href':href,'title':title})
		except:
			pass
	return out	
	
def getCRlink(url):
	out=[]
	html=getUrl(url)
	result = parseDOM(html,'div',attrs = {'class':'video_btn'})#[0]
	if result:
		hrefhost=re.findall('link="(.+?)">(.+?)<',result[0],re.DOTALL)
		for href,host in hrefhost:
			out.append({'href':href,'title':host})
	return out
def resolvingCR(url,ref):
	html=getUrl(url,ref)
	vido_url = mydecode.decode(url,html)
	return vido_url
	
def getScheduleSE():
	out=[]
	html=getUrl(BASEURL)
	result = parseDOM(html,'table',attrs = {'align':'center'})[1]
	
	tds = parseDOM(result,'tr',attrs = {'style':' height:35px; vertical-align:top;'})#[0]
	for td in tds:
		
		tdk = parseDOM(td,'td')[0]

		czas = parseDOM(tdk,'td',attrs = {'class':'matchtime'})[0]
		teams = parseDOM(tdk,'td')[2]
		href = parseDOM(tdk,'a',ret='href')[0]
		href = BASEURL+href if href.startswith('/') else href
		tit='%s - %s'%(czas,teams)
		out.append({'href':href,'title':tit})
	return out
def getChannelsSE():
	out=[]
	html=getUrl(BASEURL)
	result = parseDOM(html,'div',attrs = {'class':'arrowgreen'})[0]#<div class="arrowgreen">
	lis = parseDOM(result,'li')#[0]
	for li in lis:
		title = parseDOM(li,'img',ret='alt')#[0]
		if title:
			if 'schedule' in title[0].lower():
				continue
		title=title[0] if title else parseDOM(li,'a')[0]
		href = parseDOM(li,'a',ret='href')[0]
		href = BASEURL+href if href.startswith('/') else href
		imag = parseDOM(li,'img',ret='src')#[0]
		imag= BASEURL+'/'+imag[0] if imag else ''
		out.append({'href':href,'title':title,'image':imag})
	return out	
	
def getSElink(url):
	out=[]
	query=urlparse.urlparse(url).query
	url='%s/streams/misc/%s.html'%(BASEURL,query)
	html=getUrl(url)
	links=re.findall('id="link\d+" class="class_.+?" href="(.+?)"',html,re.DOTALL)
	co=1
	for link in links:
		link= BASEURL+link if link.startswith('/') else link
		query=urlparse.urlparse(link).query
		if not query:
			query=link #if not query
		out.append({'href':query,'title':'Link %d'%co})

		co+=1
	return out

