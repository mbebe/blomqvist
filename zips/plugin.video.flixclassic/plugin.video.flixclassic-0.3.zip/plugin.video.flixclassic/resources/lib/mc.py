# -*- coding: utf-8 -*-
import os,re, sys
import xbmc,xbmcaddon,xbmcgui,xbmcvfs

addonInfo     = xbmcaddon.Addon().getAddonInfo
file_open     = xbmcvfs.File
file_delete   = xbmcvfs.delete

#PATH          = addonInfo('path')
rysunek         = addonInfo('path')+'/resources/media/transp.jpg'
#rysunek       = MEDIA+'transp.jpg'
if sys.version_info >= (3,0,0):
    DATAPATH        = xbmcvfs.translatePath(addonInfo('profile'))
else:
    DATAPATH        = xbmc.translatePath(addonInfo('profile')).decode('utf-8')

control       = xbmcgui.ControlImage
dialog        = xbmcgui.WindowDialog()
KEYBOARD      = xbmc.Keyboard


def keyboard(response):
	try:
		i = os.path.join(DATAPATH,'captcha')
		f = file_open(i, 'w')
		f.write(response)
		f.close()
		#i2 = os.path.join(DATAPATH,'transp.jpg')
		f2 = control(450,15,375,115, rysunek)
		f = control(450,15,375,115, i)
		d = dialog
		d.addControl(f2)
		d.addControl(f)

		file_delete(i)
		d.show()
		k = xbmc.Keyboard('','')
		k.doModal()
		c = k.getText() if k.isConfirmed() else None
		if c == '': c = None
		d.removeControl(f)
		d.close()
	
		return c.upper()
	except:
		return

def getDialog(title='',text='',action=''):
    xbmcgui.Dialog().ok(title,text,action)
