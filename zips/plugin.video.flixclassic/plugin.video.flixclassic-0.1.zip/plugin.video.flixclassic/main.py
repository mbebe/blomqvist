# -*- coding: UTF-8 -*-

from resources.lib.flix import Flix

if __name__ == '__main__':
    Flix()