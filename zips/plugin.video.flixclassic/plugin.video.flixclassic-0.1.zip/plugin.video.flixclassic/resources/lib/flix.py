# coding: UTF-8
import ast
import sys, re

import requests
import routing
import xbmcvfs

from .helper import Helper
from datetime import datetime, timedelta

base_url = sys.argv[0]
handle = int(sys.argv[1])
helper = Helper(base_url, handle)
plugin = routing.Plugin()

try:
    # Python 3
    from urllib.parse import quote_plus, unquote_plus, quote, unquote
except:
    # Python 2.7
    from urllib import quote_plus, unquote_plus, quote, unquote
    
@plugin.route('/')
def root():
    helper.CreateDatas()
    if helper.logged:
        CheckAvail()
        abc=''
        helper.add_item('[COLOR gold][B]Moja lista[/COLOR][/B]', plugin.url_for(moja_lista),folder=True)
        
        helper.add_item('[B]Filmy[/B]', plugin.url_for(submenu, entry = '1'),folder=True)
        helper.add_item('[B]Seriale[/B]', plugin.url_for(submenu, entry = '2'),folder=True)

        helper.add_item('[B]Żelazny kanon[/B]', plugin.url_for(listcateg, entry = quote_plus('products/sections/7864'),page = int(0)),folder=True)
        helper.add_item('[B]Zapomniane perełki[/B]', plugin.url_for(listcateg, entry = quote_plus('products/sections/7865'),page = int(0)),folder=True)
        helper.add_item('[B]Swobodna jazda[/B]', plugin.url_for(listcateg, entry = quote_plus('products/sections/7867'),page = int(0)),folder=True)
        helper.add_item('[B]Gaz do dechy[/B]', plugin.url_for(listcateg, entry = quote_plus('products/sections/7866'),page = int(0)),folder=True)
        helper.add_item('[B]Szukaj[/B]', plugin.url_for(szukaj),folder=True)
        helper.add_item('[COLOR orangered][B]-=Wyloguj=-[/COLOR][/B]', plugin.url_for(logout),folder=False)
    else:
        helper.add_item('[COLOR lightgreen][B]Zaloguj[/COLOR][/B]', plugin.url_for(logowanie),folder=False)
    
    helper.add_item('[B]Ustawienia[/B]', plugin.url_for(ustawienia),folder=False)

    helper.eod()

    
@plugin.route('/szukaj')
def szukaj():
    query = helper.input_dialog('Szukaj...')
    if len(query)>2:
        query =query.replace(' ','+')

        urlf = 'https://flixclassic.pl/api/products/vods/search/VOD?lang=pl&platform=BROWSER&keyword='+query
        fdata = helper.request_sess(urlf, 'get', headers=helper.headers, json=True)
        urls = 'https://flixclassic.pl/api/products/vods/search/SERIAL?lang=pl&platform=BROWSER&keyword='+query
        sdata = helper.request_sess(urls, 'get', headers=helper.headers, json=True)
        totf = fdata.get("meta", None).get("totalCount", None)
        tots = sdata.get("meta", None).get("totalCount", None)
        if totf or tots:
            if totf:
                helper.add_item('[B][COLOR gold]'+query.replace('+',' ')+'[/COLOR][/B]'+'[B]        FILMY ('+str(totf)+')[/B]', plugin.url_for(list_szukaj, data = quote_plus(str(fdata.get('items', None)))),folder=True)
            if tots:
                helper.add_item('[B][COLOR gold]'+query.replace('+',' ')+'[/COLOR][/B]'+'[B]        SERIALE ('+str(tots)+')[/B]', plugin.url_for(list_szukaj, data = quote_plus(str(sdata.get('items', None)))),folder=True)

            helper.eod()
            
    else:
        helper.notification('Info', 'Minimum 3 znaki...')
        
@plugin.route('/list_szukaj/<data>')
def list_szukaj(data):
    items = ast.literal_eval(unquote_plus(data))
    for item in items:
        id = str(item.get('id', None))
        title = item.get('title', None)
        lead = item.get('lead', None)
        type = item.get('type', None)
    
        duration = item.get('duration', None)
        year = item.get('year', None)
        originalTitle = item.get('originalTitle', None)
        
        info = CreateInfo(item)
        art,imag,fanart = getArts(item)
        
        
        if type == 'SERIAL':
            mod = plugin.url_for(listseasons, id=id,tyt=title, img=quote_plus(imag), fnrt=quote_plus(fanart) )
            fold = True
            ispla = False
    
        else:
            mod = plugin.url_for(playvid, id=id)
            fold = False
            ispla = True
    
        contextmenu = [] 
        contextmenu.append(('[COLOR khaki][B]Dodaj do twojej listy[/COLOR][/B]', 'Container.Update(%s)'%plugin.url_for(addfav, id=id)))
        helper.add_item(title, mod, playable=ispla, info=info, art=art, contextmenu = contextmenu)    
    if items:
        helper.eod()

def CheckAvail():

    url='https://flixclassic.pl/api/subscribers/products/available/list?lang=pl&platform=BROWSER'
    jsdata = helper.request_sess(url, 'get', headers=helper.headers, json=True)
    avail ={}
    for prod in jsdata:
        avail[prod.get('productId',None)] = prod.get('availableTill',None)    
    helper.set_setting('avail_products', quote_plus(str(avail)))
    return
    #
@plugin.route('/moja_lista')
def moja_lista():

    hash = (helper.kukis).get('cache_bookmark_favourite', None)

    url ='https://flixclassic.pl/api/subscribers/bookmarks?type=FAVOURITE&lang=pl&platform=BROWSER&hash='+hash
    jsdata = helper.request_sess(url, 'get', headers=helper.headers, json=True)
    items = jsdata.get('items', None)
    if items:
        for i in items:
            item = i.get('item', None)
            id = str(item.get('id', None))
            title = item.get('title', None)
            lead = item.get('lead', None)
            type = item.get('type', None)
                    
            duration = item.get('duration', None)
            year = item.get('year', None)
            originalTitle = item.get('originalTitle', None)
            
            info = CreateInfo(item)
            art,imag,fanart = getArts(item)
        
            if type == 'SERIAL':
                mod = plugin.url_for(listseasons, id=id,tyt=title, img=quote_plus(imag), fnrt=quote_plus(fanart) )
                fold = True
                ispla = False
        
            else:
                mod = plugin.url_for(playvid, id=id)
                fold = False
                ispla = True
        
            contextmenu = [] 
            contextmenu.append(('[COLOR khaki][B]Usuń z twojej listy[/COLOR][/B]', 'RunPlugin(%s)'%plugin.url_for(delfav, id=id)))

            helper.add_item(title, mod, playable=ispla, info=info, art=art, contextmenu=contextmenu)    

    
    else:
        helper.add_item('Brak materiałów do wyświetlenia', plugin.url_for(root))
    helper.eod()

@plugin.route('/delfav/<id>')
def delfav(id):
    url = 'https://flixclassic.pl/api/subscribers/bookmarks?type=FAVOURITE&itemId[]='+str(id)+'&lang=pl&platform=BROWSER'
    jsdata = helper.request_sess(url, 'delete', headers=helper.headers)

    helper.update(str( plugin.url_for(moja_lista)) )
    
    return

@plugin.route('/addfav/<id>')
def addfav(id):

    jest = CheckFavId(id)
    if jest:
        helper.notification('Info', 'Wybrany materiał jest już na twojej liście.')
    else:

        json_data = {
            'itemId': int(id),
        }

        url = 'https://flixclassic.pl/api/subscribers/bookmarks?type=FAVOURITE&lang=pl&platform=BROWSER'
        jsdata = helper.request_sess(url, 'post', headers=helper.headers, data = json_data, result = False, json_data = True)
        if jsdata.status_code == 204:
            helper.notification('Info', 'Wybrany materiał dodano do twojej listy.')

    return

def CheckFavId(idx):
    hash = (helper.kukis).get('cache_bookmark_favourite', None)

    url ='https://flixclassic.pl/api/subscribers/bookmarks?type=FAVOURITE&lang=pl&platform=BROWSER&hash='+hash
    jsdata = helper.request_sess(url, 'get', headers=helper.headers, json=True)
    items = jsdata.get('items', None)
    jest = False
    for i in items:
        item = i.get('item', None)
        id = str(item.get('id', None))
        if str(id) == str(idx):
            jest = True
            break
    return jest


    
@plugin.route('/submenu/<entry>')
def submenu(entry):    

    if entry == '1':
        tyt = "filmy"
        sortn = helper.fsortn
        katn = helper.fkatn
    else:
        tyt = "seriale"
        sortn = helper.ssortn
        katn = helper.skatn

    helper.add_item("[COLOR lightblue]    sortuj:[/COLOR] [B]"+sortn+"[/B]", plugin.url_for(filtry, entry = tyt[:1]+'sort'),folder=False,)
    helper.add_item("[COLOR lightblue]    kategoria:[/COLOR] [B]"+katn+"[/B]", plugin.url_for(filtry, entry = tyt[:1]+'kat'),folder=False,)

    helper.add_item('[B]Wyświetl '+tyt+'[/B]', plugin.url_for(listcateg, entry = str(entry),page = int(0)),folder=True)
    helper.eod()


@plugin.route('/filtry/<entry>')
def filtry(entry):

    if 'sort' in entry:
        dd='sortowanie:'
        value=['&sort=title&order=asc',    "&sort=title&order=desc",    "&sort=createdAt&order=desc",    "&sort=year&order=asc",    "&sort=year&order=desc"]
        label=['A-Z',                    "Z-A",                        " ostatnio dodane",                "najstarsze",            "najnowsze"]
    
    elif 'kat' in entry:
        dd='kategorię:'
        label=['wszystkie']
        value=['']

        id = '1' if 'f' in entry else '2'
        url ='https://flixclassic.pl/api/items/categories?mainCategoryId='+id+'&lang=pl&platform=BROWSER'
        jsdata = helper.request_sess(url, 'get', headers=helper.headers, json=True)
        for k in jsdata:
            vl=k.get('name', None)
            lb = k.get('id', None)
            value.append('&categoryId[]='+str(lb))
            label.append(vl)

    sel = helper.dialog_select('Wybierz '+dd, label)
    if sel > -1:
        v = '%s'%value[sel] if value[sel] else ''
        n = label[sel]
        helper.set_setting(entry+'V',v)
        helper.set_setting(entry+'N',n)
        helper.CreateFilters()

    helper.refresh()
        
@plugin.route('/listcateg/<entry>/<page>')
def listcateg(entry, page):    

    entry = unquote_plus(entry)
    first = str(int(page))
    maxres = str(   int(page)+25)
    if not 'sections' in entry:
        dod = 'mainCategoryId[]='+entry+helper.fdata if entry =='1' else 'mainCategoryId[]='+entry+helper.sdata

        url = helper.base_api_url.format('products/vods?&firstResult='+first+'&maxResults=25&')+dod+'&lang=pl&platform=BROWSER'
        jsdata = helper.request_sess(url, 'get', headers=helper.headers, json=True)
        totalCount = jsdata.get('meta', None).get('totalCount', None)
        items = jsdata.get('items', None)
        for item in items:
            id = str(item.get('id', None))
            title = item.get('title', None)
            lead = item.get('lead', None)
            type = item.get('type', None)
        
            duration = item.get('duration', None)
            year = item.get('year', None)
            originalTitle = item.get('originalTitle', None)
            
            info = CreateInfo(item)
            art,imag,fanart = getArts(item)
            
            
            if type == 'SERIAL':
                mod = plugin.url_for(listseasons, id=id,tyt=title, img=quote_plus(imag), fnrt=quote_plus(fanart) )
                fold = True
                ispla = False

            else:
                mod = plugin.url_for(playvid, id=id)
                fold = False
                ispla = True

            contextmenu = [] 
            contextmenu.append(('[COLOR khaki][B]Dodaj do twojej listy[/COLOR][/B]', 'Container.Update(%s)'%plugin.url_for(addfav, id=id)))
            helper.add_item(title, mod, playable=ispla, info=info, art=art, contextmenu = contextmenu)    

    else:
        url = helper.base_api_url.format(entry)+'?elementsLimit=100&lang=pl&platform=BROWSER&firstResult='+first+'&maxResults=25'
        jsdata = helper.request_sess(url, 'get', headers=helper.headers, json=True)
        totalCount = jsdata.get('meta', None).get('totalCount', None)
        elements = jsdata.get('elements', None)
        for elem in elements:
            item = elem.get('item', None)
            id = str(item.get('id', None))
            title = item.get('title', None)
            lead = item.get('lead', None)
            type = item.get('type', None)

            duration = item.get('duration', None)
            year = item.get('year', None)
            originalTitle = item.get('originalTitle', None)

            info = CreateInfo(item)
            art,imag,fanart = getArts(item)

            if type == 'SERIAL':
                mod = plugin.url_for(listseasons, id=id,tyt=title, img=quote_plus(imag), fnrt=quote_plus(fanart) )
                fold = True
                ispla = False

            else:
                mod = plugin.url_for(playvid, id=id)
                fold = False
                ispla = True

            contextmenu = [] 
            contextmenu.append(('[COLOR khaki][B]Dodaj do twojej listy[/COLOR][/B]', 'Container.Update(%s)'%plugin.url_for(addfav, id=id)))
            helper.add_item(title, mod, playable=ispla, info=info, art=art, contextmenu = contextmenu)        

    if int(totalCount)>int(maxres):
        helper.add_item('Następna strona', plugin.url_for(listcateg, entry = quote_plus(entry),page = (int(first)+25)),folder=True)
    helper.eod()

@plugin.route('/listseasons/<id>/<tyt>/<img>/<fnrt>')
def listseasons(id,tyt,img, fnrt):
    imag = unquote_plus(img)
    fanart = unquote_plus(fnrt)
    art = {
        'icon': imag,
        'fanart': fanart,
        }
    url = helper.base_api_url.format('products/vods/serials/'+id+'/seasons?lang=pl&platform=BROWSER')
    jsdata = helper.request_sess(url, 'get', headers=helper.headers, json=True)
    for season in jsdata:
        sesid = str(season.get('id', None))
        entry = quote_plus('products/vods/serials/'+id+'/seasons/'+sesid+'/episodes')
        title = season.get('title', None)
        ftitle = tyt+' '+title
        info = {'title': ftitle, 'plot':ftitle}
        helper.add_item(ftitle, plugin.url_for(listepisodes, entry = entry), info=info, art=art)
    helper.eod()

@plugin.route('/listepisodes/<entry>')
def listepisodes(entry):
    entry = unquote_plus(entry)

    url = helper.base_api_url.format(entry+'?lang=pl&platform=BROWSER')
    jsdata = helper.request_sess(url, 'get', headers=helper.headers, json=True)
    for item in jsdata:
        
        id = str(item.get('id', None))
        title = item.get('title', None)
        lead = item.get('lead', None)
        lead = lead if lead else title
        type = item.get('type', None)
        duration = item.get('duration', None)
        year = item.get('year', None)
        originalTitle = item.get('originalTitle', None)
        
        
        info = CreateInfo(item)
        art,imag,fanart = getArts(item)

        mod = plugin.url_for(playvid, id=id)
        fold = False
        ispla = True

        helper.add_item(title, mod, playable=ispla, info=info, art=art)    
    
    helper.eod()
def CreateInfo(item):
    title = item.get('title', None)
    lead = item.get('lead', None)
    lead = lead if lead else title
    type = item.get('type', None)

    duration = item.get('duration', None)
    year = item.get('year', None)
    originalTitle = item.get('originalTitle', None)
    info = {'title': title, 'plot':lead, 'year':year, 'originaltitle':originalTitle}
    if duration:
        info.update({'duration':duration})
    return info
    
def getArts(item):
    fanart=None
    imag=None
    for k, v in (item.get('images', None)).items():
    
        if k == '16x9':
            fanart = v[0].get('url', None)
            fanart = 'https:'+fanart if fanart.startswith('//') else fanart
        else:
            imag = v[0].get('url', None)#'id': 1877,
            imag = 'https:'+imag if imag.startswith('//') else imag
    if not fanart:
        fanart = helper.addon.getAddonInfo('fanart')
    if not imag:
        imag = helper.addon.getAddonInfo('icon')
    art = {'icon': imag, 'fanart': fanart}
    return art, imag, fanart
    
@plugin.route('/refr')
def refr():
    helper.refresh()

@plugin.route('/ustawienia')
def ustawienia():
    helper.open_settings()
    helper.refresh()


@plugin.route('/logout')
def logout():
    wyloguj = helper.dialog_choice('UWAGA','Chcesz się wylogować?',agree='TAK', disagree='NIE')
    if wyloguj:
        helper.save_file(file=helper.datapath+'kukis', data={}, isJSON=True)    
        helper.set_setting('zalogowany', 'false')
        helper.refresh()
@plugin.route('/logowanie')
def logowanie():

    if not helper.username or not helper.password:
        helper.notification('Info', 'Brak danych logowania')

        helper.set_setting('zalogowany', 'false')
    else:

        url = helper.base_api_url.format('subscribers/login')+'?lang=pl&platform=BROWSER'
        json_data = {'email': helper.username,'rememberMe': True, 'auth': {'type': 'PASSWORD','value': helper.password,},'appVersion': '32b211b',}

        jsdata = helper.request_sess(url, 'post', headers=helper.headers, data = json_data, json=True, json_data = True)

        if 'email' in jsdata:

            activeProfileId = jsdata.get("activeProfileId", None)
            for prof in jsdata.get('profiles', None):
                if prof.get('id', None) == activeProfileId:
                    profileuid = prof.get("uid", None)
                    helper.set_setting('profileuid', str(profileuid))
                    break
            
            
            abc = helper._sess.cookies
        
            abc.update({'uid': helper.DeviceUid})
            helper.save_file(file=helper.datapath+'kukis', data=(abc).get_dict(), isJSON=True)    
            helper.set_setting('zalogowany', 'true')
        else:
            #try:
            if jsdata.get('code', None)=='CAPTCHA_REQUIRED':
                
                from resources.lib import mc

                for x in range(3):
                    dod = str(helper.to_timestamp(helper.timeNow()))
                    capurl = 'https://flixclassic.pl/api/captcha/LOGIN?platform=BROWSER&reload=true&'+dod
                    response_content = helper.request_sess(capurl, 'get', headers=helper.headers, json=False)

                    rx=mc.keyboard(response_content)
                    if rx:
                        json_data = {'email': helper.username,'rememberMe': True, 'auth': {'type': 'PASSWORD','value': helper.password,},'captcha':rx, 'appVersion': '32b211b',}
                        jsdata = helper.request_sess(url, 'post', headers=helper.headers, data = json_data, json=True, json_data = True)

                        if 'email' in jsdata:
                            activeProfileId = jsdata.get("activeProfileId", None)
                            for prof in jsdata.get('profiles', None):
                                if prof.get('id', None) == activeProfileId:
                                    profileuid = prof.get("uid", None)
                                    helper.set_setting('profileuid', str(profileuid))
                                    break

                            abc = helper._sess.cookies
                        
                            abc.update({'uid': helper.DeviceUid})
                            helper.save_file(file=helper.datapath+'kukis', data=(abc).get_dict(), isJSON=True)    
                            helper.set_setting('zalogowany', 'true')
                            break
                        else:
                            helper.notification('Info', jsdata.get('code', None))
                            helper.set_setting('zalogowany', 'false')
                            helper.sleep(1000)

                
            else:    

                helper.notification('Info', jsdata.get('code', None))
                helper.set_setting('zalogowany', 'false')
    helper.refresh()


@plugin.route('/playvid/<id>')
def playvid(id):

    avail = ast.literal_eval(unquote_plus(helper.avail_products))
    if int(id) in avail:
        url = 'https://flixclassic.pl/api/products/'+id+'/videos/playlist?platform=BROWSER&videoType=MOVIE'
        jsdata = helper.request_sess(url, 'get', headers=helper.headers, json=True)
        src = jsdata.get('sources', None).get("DASH", None)[0].get('src', None)

        license_url = jsdata.get("drm", None).get('WIDEVINE', None).get('src', None)
        
        mpdurl = 'https:' + src if src.startswith('//') else src
        mpdurl += '|User-Agent=' + quote(helper.UA)

        lic_url = license_url  + '|Content-Type=&User-Agent=' + quote(helper.UA)+'|R{SSM}|'

    PROTOCOL = 'mpd'
    DRM = 'com.widevine.alpha'

    helper.PlayVid(mpdurl, lic_url, PROTOCOL, DRM)


class Flix(Helper):
    def __init__(self):
        super().__init__()
        plugin.run()


