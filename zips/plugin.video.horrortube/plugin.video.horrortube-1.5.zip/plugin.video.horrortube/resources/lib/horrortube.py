# -*- coding: utf-8 -*-
import urllib2,urllib
import re,os,base64,time
import xbmc, xbmcaddon, xbmcgui
from urlparse import urlparse
import requests
from CommonFunctions import parseDOM

import cfscr
_cfscrape = cfscr.create_scraper()
UA           = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
my_addon     = xbmcaddon.Addon()
DATAPATH     = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
COOKIEFILE   = os.path.join(DATAPATH,'cookie')

TIMEOUT      = 10
my_url       = 'https://horrortube.fun/'

sess = requests.Session()
sess.headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0'})
headers={'User-Agent': 'Mozilla/5.0 (Linux; Android 9; MI 8 Lite Build/PKQ1.181007.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/61.0.3163.128 Mobile Safari/537.36 XiaoMi/MiuiQuickSearchBox/ XiaoMi/HybridView/'
}
UAx='Mozilla/5.0 (Linux; Android 9; MI 8 Lite Build/PKQ1.181007.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/61.0.3163.128 Mobile Safari/537.36 XiaoMi/MiuiQuickSearchBox/ XiaoMi/HybridView/'
def scget(url=''):
	if not url:
		url='https://horrortube.fun'
	tokens, user_agent =cfscr.get_tokens(url,headers=headers)
	my_addon.setSetting('tok1', str(tokens))
	tokens2, user_agent2 = cfscr.get_cookie_string(url,headers=headers)
	my_addon.setSetting('tok2', str(tokens2))
	return
def getUrl(url,data=None,header={}):
	kuk1=my_addon.getSetting('tok1')
	kuk2=my_addon.getSetting('tok2')
	murl='https://horrortube.fun'
	if kuk1:
	
		content=sess.get(url, headers=headers,cookies=eval(kuk1),verify=False)	
	else:
		scget(murl)
		content=getUrl(url)
	if content.status_code ==503:
		scget(murl)
		content=getUrl(url)
	else:
		content=content.text
		content=content.encode('utf-8')
	return content

	
def getverystream(url):	
	sess.headers.update({
	'User-Agent': UA,
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Connection': 'keep-alive',})
	html=sess.get(url).content
	id=re.findall('id="videolink">([^>]+)<',html,re.DOTALL)[0]
	sess.headers.update({'Referer': url})
	url2='https://verystream.com/gettoken/%s?mime=true'%id
	response=sess.get(url2,allow_redirects=False)#.content
	locat= response.url
	return locat+'|User-Agent='+UA+'&Referer='+url
	
	
def getMovies(url,page=1,group=''):
	print url
	if '?page=' in url:
		url = url.replace('?page=','?page=%d' %page)
	else:
		url += '/' if url[-1] != '/' else ''
		url = url + '?page=%d' %page
	if group:
		url=url.split('?')[0]	
	content = getUrl(url) 
	kuk2=my_addon.getSetting('tok2')
	out=[]
	gr=False
	pr=False
	ids = []
	try:
		result=parseDOM(content,'div', attrs={'id': "item-list"})[0]
	except:
		result=content	

	mdata=parseDOM(content,'ul', attrs={'class': "clearfix pagination"})
	mdata = urllib.unquote(mdata[0]) if mdata else content
	gr=False
	
	if mdata.find( '?page=%d' %(page+1))>-1:
		gr = page+1
	links=parseDOM(result,'div', attrs={'class': "col-sm-6"})
	links = links if links else parseDOM(result,'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"})

	for link in links:
		src = parseDOM(link, 'img', ret='src')[0]
		href = parseDOM(link, 'a', ret='href')[0]   
		title = parseDOM(link, 'a', ret='title')
		if title:
			title=title[0]
		else:
			continue
		plot = parseDOM(link, 'a', ret='data-text')	
		plot =plot[0] if plot else ''
		year = parseDOM(link,'div', attrs={'class': "film_year"})#[0] 
		year = int(year[0]) if year else ''

		if href and title:
			if src.startswith('//'):
				src = 'http:'+src
			film = {
				'href'   : href,
				'title'  : fixSC(title),
				'plot'   : fixSC(plot),
				'img'    : src+'|User-Agent='+urllib.quote(UAx)+'&Cookie='+urllib.quote(kuk2),
				'year'   : year,
					}
			out.append(film)
		
		pr = page-1 if page>1 else False
	return (out, (pr,gr))

def getSeries(url, page = 1,group = ''):
	if '?page=' in url:
		url = url.replace('?page=','?page=%d' %page)
	else:
		url += '/' if url[-1] != '/' else ''
		url = url + '?page=%d' %page
	if group:
		url=url.split('?')[0]
	content = getUrl(url)
	kuk2=my_addon.getSetting('tok2')
	out=[]
	gr=False
	pr=False
	ids = []
	if group:
		result=parseDOM(content,'div', attrs={'id': "item-list"})
		if 'Ostatnio dodane' in group:
			result=result[0]
		else:
			result=result[1]
		links=parseDOM(result,'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"})	
		for link in links:
			src = parseDOM(link, 'img', ret='src')[0]
			href = parseDOM(link, 'a', ret='href')[0]   
			title = parseDOM(link, 'a', ret='title')[0]
			plot = parseDOM(link, 'a', ret='data-text')	
			plot =plot[0] if plot else ''
			if href and title:
				if src.startswith('//'):
					src = 'http:'+src
				film = {
					'href'   : href,
					'title'  : fixSC(title),
					'plot'   : plot,
					'img'    : src+'|User-Agent='+urllib.quote(UAx)+'&Cookie='+urllib.quote(kuk2),
						}
				out.append(film)	
	else: 
		result=parseDOM(content,'div', attrs={'id': "item-list"})[0] 

		links=parseDOM(result,'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"})	
		for link in links:
			src = parseDOM(link, 'img', ret='src')[0]
			href = parseDOM(link, 'a', ret='href')[0]   
			title = parseDOM(link, 'a', ret='title')[0]
			plot = parseDOM(link, 'a', ret='data-text')	
			plot =plot[0] if plot else ''
			if href and title:
				if src.startswith('//'):
					src = 'http:'+src
				film = {
					'href'   : href,
					'title'  : fixSC(title),
					'plot'   : plot,
					'img'    : src+'|User-Agent='+urllib.quote(UAx)+'&Cookie='+urllib.quote(kuk2),
						}
				out.append(film)
		mdata=parseDOM(content,'ul', attrs={'class': 'clearfix pagination'})[0]	
		mdata = urllib.unquote(mdata) if mdata else content
		gr=False
		
		if mdata.find( '?page=%d' %(page+1))>-1:
			gr = page+1	
		
		pr = page-1 if page > 1 else False
	return (out, (pr,gr))

def parseVideoLink(url, host = ''):
    if 'cda' in host:
        return 'http://www.cda.pl/video/%s'%(url.split('id=')[-1])
    elif 'alltube' in url:
        content = getUrl(url)
        outurl=''
        href= re.compile('src="(.*?)"').findall(content)
        if href:
            href = [h for h in href if BRAMKA not in h]
            outurl = getHref(href[0])
            if outurl.startswith('//'):
                outurl = 'http:'+outurl
        return outurl
    elif str(host) in url:
        if url.startswith('//'):
            url = 'http:' + url
        return url
    else:
        return url

def getVideos(url):
	content=getUrl(url)
	data = re.compile('<tbody>(.*?)</tbody>',re.DOTALL).findall(content)
	data = data[0] if data else ''
	ids = [(a.start(), a.end()) for a in re.finditer('<tr', data)]
	ids.append( (-1,-1) )
	out=[]
	for i in range(len(ids[:-1])):
		wc = data[ ids[i][1]:ids[i+1][0] ]
		href=re.compile('href="(.*?)"').search(wc)
		iframe = re.compile('data-iframe="(.*?)"').search(wc)
		try:
			decodiframe=base64.b64decode(iframe.group(1)).replace('\/','/')
			hrefok=re.findall("""src['"]:['"](.+?)['"]\,""",decodiframe)[0] #.replace('\/','/')
			info = ''.join(re.compile('>(.*?)<',re.DOTALL).findall(wc))
			info = re.sub(' +',' ',fixSC(info)).strip()
		except:
			pass
		if hrefok:
			film = {'url' : hrefok,'title': info,}
			out.append(film)
	return out

def scanEpisodes(url):
    content = getUrl(url)
    kuk2=my_addon.getSetting('tok2')
    src = re.compile('<ul id="episode-list">(.*?)</ul>').findall(content)
    src = src[-1] if src else ''
    out=[]
    odcinki = content.find('Odcinki')
    odcinek = content.find('Dodaj odcinek')
    links = re.compile('<a href="(.*?)">(.*?)</a>',re.DOTALL).findall(content[odcinki:odcinek])
    imgsrc=parseDOM(content,'div', attrs={'id': "single-poster"})
    imgsrc = re.findall('<img src="(.*?)"',imgsrc[0],re.DOTALL) [0]   if imgsrc else ''
    plot=re.findall('<p class="description">(.+?)</p>',content)#[0]
    plot=fixSC(plot[0]) if plot else ''

    for h,t in links:
        t= fixSC(t.strip())
        t=re.sub(' +',' ',t)
        data = re.compile('[sS](\d+)[Ee](\d+)').findall(t)
        film = {
            'href'  : h.strip(),
            'plot' : plot,
            'title' : t,
            'img' : imgsrc+'|User-Agent='+urllib.quote(UAx)+'&Cookie='+urllib.quote(kuk2),
            'season' : int(data[0][0]) if data else '',
            'episode' : int(data[0][1]) if data else '',
            'aired' : ''}
        out.append(film)
    return out

def splitToSeasons(input):
    out={}
    seasons = [x.get('season') for x in input]
    for s in set(seasons):
        out['Sezon %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
    return out

def getSort(mv='film',sc='category'):
	label=[]
	value=[]
	url = 'https://horrortube.pl/filmy-online/'
	if mv=='film':
		content = getUrl(url)
		if sc=='category':
			result=parseDOM(content,'ul', attrs={'id': "filter-category"})[0]
			value=parseDOM(result,'li', ret='data-id') #[0]
			label=parseDOM(result,'a')
		elif sc=='year':
			result=parseDOM(content,'ul', attrs={'id': "filter-year"})[0]
			value=parseDOM(result,'li', ret='data-id') #[0]
			label=parseDOM(result,'a')
		elif sc=='country': 
			result=parseDOM(content,'ul', attrs={'id': "filter-country"})[0]
			value=parseDOM(result,'li', ret='data-id') #[0]
			result = re.sub('	HiszpaniaWielka Brytania', 'Hiszpania/Wielka Brytania', result)
			result = re.sub(r'\s+', ' ', result)
			label=parseDOM(result,'a')
		elif sc=='tag':
			result=parseDOM(content,'ul', attrs={'id': "filter-tag"})[0]
			value=parseDOM(result,'li', ret='data-id') #[0]
			label=parseDOM(result,'a')
	elif mv=='serial':
		pass
	return (label,value)

def search(pharse='dom'):
	url='https://horrortube.pl/wyszukiwarka?phrase='+pharse
	content=getUrl(url)
	kuk2=my_addon.getSetting('tok2')
	out1=[]
	out2=[]
	result=parseDOM(content,'div', attrs={'id': "advanced-search"})[0]
	links=parseDOM(result,'div', attrs={'class': "col-sm-4"})
	for link in links:
		src = parseDOM(link, 'img', ret='src')[0]
		href = parseDOM(link, 'a', ret='href')[0]   
		title = parseDOM(link,'div', attrs={'class': "title"})[0] 
		plot = parseDOM(link,'div', attrs={'class': "description text-justify"})[0]  
		if href and title:
			if src.startswith('//'):
				src = 'http:'+src
			film = {
				'href'   : href,
				'title'  : fixSC(title),
				'plot'   : fixSC(plot),
				'img'    : src+'|User-Agent='+urllib.quote(UAx)+'&Cookie='+urllib.quote(kuk2),
					}
			if '/film' in film['href']:
				out1.append(film)
			elif '/serial'in film['href']:
				out2.append(film)
	return out1,out2

def fixSC(pharse):
    if isinstance(pharse, unicode):
        pharse = pharse.encode('utf-8')
    pharse = pharse.replace('&lt;br/&gt;',' ')
    s='JiNcZCs7'
    pharse = re.sub(s.decode('base64'),'',pharse)
    pharse = pharse.replace('\n','').replace('\r','')
    pharse = pharse.replace('&nbsp;','')
    pharse = pharse.replace('&quot;','"').replace('&amp;quot;','"')
    pharse = pharse.replace('&oacute;','ó').replace('&Oacute;','Ó')
    pharse = pharse.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    pharse = pharse.replace('&amp;','&')
    pharse = pharse.replace('\u0105','ą').replace('\u0104','Ą')
    pharse = pharse.replace('\u0107','ć').replace('\u0106','Ć')
    pharse = pharse.replace('\u0119','ę').replace('\u0118','Ę')
    pharse = pharse.replace('\u0142','ł').replace('\u0141','Ł')
    pharse = pharse.replace('\u0144','ń').replace('\u0144','Ń')
    pharse = pharse.replace('\u00f3','ó').replace('\u00d3','Ó')
    pharse = pharse.replace('\u015b','ś').replace('\u015a','Ś')
    pharse = pharse.replace('\u017a','ź').replace('\u0179','Ź')
    pharse = pharse.replace('\u017c','ż').replace('\u017b','Ż')
    return pharse