# -*- coding: utf-8 -*-
import urllib2
import re,os
import xbmc,xbmcgui,xbmcaddon
import cookielib
import requests
import sys
import urlparse
from CommonFunctions import parseDOM

BASEURL = 'https://zalukaj.com'
TIMEOUT = 10
UA      = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'

my_addon     = xbmcaddon.Addon()
DATAPATH     = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')

COOKIEFILE = os.path.join(DATAPATH,'zalukaj.cookie')
session = requests.Session()
session.cookies = cookielib.LWPCookieJar(COOKIEFILE)
u = my_addon.getSetting('user')

session.headers.update({'User-Agent': UA})

headersok = {
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
	'Accept-Language': 'pl,en-US;q=0.9,en;q=0.8,fr;q=0.7',
	'User-Agent': UA,
	'Referer': 'https://zalukaj.com/'}

def getUrlReq(url):
	if os.path.isfile(COOKIEFILE):
		session.cookies.load()

	content=session.get(url,verify=False).content
	captcha = re.search('<img src="/captcha-image"',content)
	if captcha:	
		import mc
		aa='https://zalukaj.com/captcha-image'
		resource = session.get(aa).content
		r=mc.keyboard(resource)
		datax = {'captcha': r}
		content = session.post('https://zalukaj.com/limit',data=datax).content
		content=session.get(url,verify=False).content
	return content

def getUrlReqPost(url,data):
	if os.path.isfile(COOKIEFILE):
		session.cookies.load()		
	session.headers = {
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': 'https://zalukaj.com/',
		'Content-Type': 'application/x-www-form-urlencoded',
		'Connection': 'keep-alive',
		'Upgrade-Insecure-Requests': '1',}		
	r = session.post(url=url, data=data, allow_redirects=True,verify=False)
	return r.content
	
def cookieString(COOKIEFILE):
    sc=''
    if os.path.isfile(COOKIEFILE):
        cj = cookielib.LWPCookieJar()
        cj.load(COOKIEFILE)
        sc=''.join(['%s=%s;'%(c.name, c.value) for c in cj])
    return sc

def getLogin(u='',p=''):
	hh={'User-Agent': UA}	
	ccoki=''
	content=session.get(BASEURL,headers=hh,verify=False).content		
	captcha = re.search('<img src="/captcha-image"',content)
	if captcha:	
		import mc
		aa='https://zalukaj.com/captcha-image'
		r=session.get(aa,headers=hh,verify=False)
		aa=r.cookies
		resource=r.content
		rx=mc.keyboard(resource)
		headerscap = {
			'User-Agent': UA,
			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
			'Referer': 'https://zalukaj.com/limit',
			'Content-Type': 'application/x-www-form-urlencoded',
			'Connection': 'keep-alive',
			'Upgrade-Insecure-Requests': '1',}
		data = {'captcha': rx}
		rrr = session.post('https://zalukaj.com/limit', headers=headerscap, data=data,cookies=r.cookies,verify=False)#.content	
		content=rrr.content
	hash=re.findall('name="hash" value="(.+?)"',content)[0]
	headerslog = {
				'User-Agent': UA,
				'Accept': 'application/json, text/javascript, */*; q=0.01',
				'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
				'Referer': 'https://zalukaj.com/',
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',}

	data = 'hash=%s&username=%s&password=%s'%(hash,u,p)
	r = session.post(
		'https://zalukaj.com/ajax/login',
		data=data,
		headers=headerslog,cookies=ccoki,
		allow_redirects=False,verify=False)		
	aa=r.content
	out=[]
	out2=[]
	
	if '"succes' in aa:
		kukizy=r.cookies
		if kukizy.get('__PHPSESSIDS') is not None:
			session.cookies.save()
		content=getUrlReq('https://zalukaj.com/')
		captcha = re.search('<img src="/captcha-image"',content)
		if captcha:	
			import mc
			aa='https://zalukaj.com/captcha-image'
			resource = session.get(aa).content
			r=mc.keyboard(resource)
			datax = {'captcha': r}
			content = session.post('https://zalukaj.com/limit',data=datax).content
		user = re.compile('<a style="text-decoration:underline;" href="#">(.*?)</a>').findall(content)
		img = re.compile('<img src="(.*?)"').findall(content)
		img = 'https:'+img[0] if img else ''
		href = re.compile('<a href="(.*?)">Ulubione</a>').findall(content)
		href = BASEURL + href[0] if href else ''
		typx = re.compile("""<p>Typ Konta: <.+?sms">(.+?)<\/a>""").findall(content)[0]	

		if 'Darmowe' in typx:
			typ='[COLOR red](darmowe)[/COLOR]'
			info=''		
		else:
			typ = '[COLOR green](VIP)[/COLOR]'
			info=re.findall("(do.+?)\)",typx)[0]
			info=typ+' - '+unicodePLchar(info)
		one = {'url'   : 'ulubione',
				'title':'[B]%s %s - Ulubione[/B]'%(user[0],typ),
				'url2'   : 'do-obejrzenia',
				'title2':'[B]%s %s - Do obejrzenia[/B]'%(user[0],typ),
				'plot'   : info,
				'img'    : img,}
		out.append(one)	
		return out,out2
	else:
		one = {'msg':'Problem z logowaniem'}
		out2.append(one)
		return out,out2

def getPopular(url):
	data = {'load': '0.2'}
	content=getUrlReqPost(url,data)	
	return content
	
def getPopularList(url):
	content=getPopular(url)
	out=[]
	links = parseDOM(content, 'div', attrs={'class': "row"})  
	for link in links:
		href = parseDOM(link, 'a', ret='href')[0]
		href = BASEURL+href
		imag = parseDOM(link, 'img', ret='src')[0]	
		if "http" in imag:
			imag = imag
		else:
			imag = BASEURL + imag
		plot = parseDOM(link, 'div', attrs={'class': "desc"})[0] #if plot else ''
		title = parseDOM(link, 'a', ret='title')[0].strip()
		year = parseDOM(link, 'div', attrs={'class': "gen"})[0]
		year =(year.split('|'))[0].strip()
		year = int(year)
		code = parseDOM(link, 'i', ret='title')[1]
		code = (code.split('.'))[0].strip()
		one = {'url'   : href,
			'title'  : unicodePLchar(title),
			'plot'   : unicodePLchar(plot),
			'img'    : imag,
			'year'   : year if year else '',
			'code'   : code,
			'isFolder':False,
			}
		out.append(one)		
	return out	
	
	
def getUlubione(nxt):
	data = {'a': nxt,'b': u,'c': '1'}
	content=getUrlReqPost('https://zalukaj.com/ajax/profile',data)	
	return content
	
def getUlubioneList(nxt):
	content=getUlubione(nxt)
	out=[]
	links = parseDOM(content, 'div', attrs={'class': "row"})  
	for link in links:
		href = parseDOM(link, 'a', ret='href')[0]
		href = BASEURL+href
		imag = parseDOM(link, 'img', ret='src')[0]		
		imag = BASEURL+imag if imag.startswith('/') else imag
		plot = parseDOM(link, 'div', attrs={'class': "desc"})[0] #if plot else ''
		title = parseDOM(link, 'a', ret='title')[0].strip()
		year = parseDOM(link, 'div', attrs={'class': "gen"})[0]
		year =(year.split('|'))[0].strip()
		year = int(year)
		code = parseDOM(link, 'i', ret='title')[1]
		code = (code.split('.'))[0].strip()
		one = {'url'   : href,
			'title'  : unicodePLchar(title),
			'plot'   : unicodePLchar(plot),
			'img'    : imag,
			'year'   : year if year else '',
			'code'   : code,
			'isFolder':False,
			}
		out.append(one)		
	return out
	
def scanMainpage(url='https://zalukaj.com', data = None):
    if data is not None:
        content=getUrlReqPost(url,data)
    else:
        content=getUrlReq(url)
    prevPage = False
    nextPage = False

    if 'strona-' in url:
        cpage = int(re.search('strona-(\d+)',url).group(1))

        if content.find(',strona-%d'%(cpage+1)):
            nextPage = re.sub('strona-\d+','strona-%d'%(cpage+1),url)

        if cpage > 1:
            prevPage = re.sub('strona-\d+','strona-%d'%(cpage-1),url)

    ids = [(a.start(), a.end()) for a in re.finditer('<div class="tivief\d">', content)]
    ids.append( (-1,-1) )
    out=[]

    for i in range(len(ids[:-1])):
        subset = content[ ids[i][1]:ids[i+1][0] ]
        img = re.compile('<img.*?src="(.*?)"').search(subset)

        if not img:
            img = re.compile('style="background-image:url\((.*?)\);">').search(subset)

        href = re.compile('<a.*href="(.*?)" title="(.*?)"').search(subset)
        plot = re.compile('<div style="min-height:110px;font-size:10px;"(.*?)"').findall(subset)

        if not plot:
            plot = re.compile('<div style="min-height:110px"(.*?)"').findall(subset)

        plot = re.compile('>(.*?)<').findall(plot[0]) if plot else ''

        if href and img:
            h = href.group(1)
            h = 'https:' + h if h[0:2]=='//' else h
            t = href.group(2).strip()
            year = re.search('(\d{4})',t)
            t,code = t.split('|') if '|' in t else (t,'')
            p = plot[0].strip() if plot else ''
            if "http" in img.group(1):
               im = img.group(1)
            else:
               im = BASEURL + img.group(1)

            one = {'url'   : h,
                'title'  : unicodePLchar(t.strip()),
                'plot'   : unicodePLchar(p),
                'img'    : im,
                'year'   : year.group(1) if year else '',
                'code'   : code.strip(),
                'isFolder':False,
                }
            out.append(one)

    return out,(prevPage,nextPage)

def getSeriale(type=''):
    if type=='all':
        return getSerialeAll()
    else:
        return getSerialeLatest()

def getSerialeLatest(url='https://zalukaj.com/seriale'):
    content = getUrlReq(url)
    out=[]
    ids = [(a.start(), a.end()) for a in re.finditer('<div class="latest tooltip">', content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        subset = content[ ids[i][1]:ids[i+1][0] ]
        href_src =re.compile('<a href="(/serial.*?)"><img alt="(.*?)" src="(.*?)">').findall(subset)
        title_e = re.compile('<span style="font-weight:bold;">(.*?)</span>').findall(subset)
        code = re.compile('<span class="datelts">(.*?)</span>').findall(subset)

        if href_src and title_e:
            h=BASEURL+href_src[0][0]
            xbmc.log(msg=str(h), level=xbmc.LOGNOTICE) 
            if "http" in href_src[0][-1]:
               img = href_src[0][-1]
            else:
               img = BASEURL + href_src[0][-1]

            t = '%s (%s)'%(href_src[0][1],title_e[0])
            out.append(
                {'url'    : h,
                 'title'  : unicodePLchar(t.strip()),
                 'img'    : img,
                 'code'   : unicodePLchar(code[0].strip()) if code else '',
                 'plot'   : unicodePLchar(code[0].strip()) if code else '',
                })

    return out

def getSerialeAll():
    content = getUrlReq(BASEURL)
    out=[]
    seriale = re.compile('<a href="(/serial/.*?)" title="(.*?)">(.*?)</a>').findall(content)

    for s in seriale:
        out.append({
                   'url'   : BASEURL + s[0],
                   'title' : unicodePLchar(s[1].strip()).decode('utf-8')
                   })
    return out

def getSeasons(url='https://zalukaj.com/kategoria-serialu/2727,1/the_walking_dead_the_walking_dead_sezon_7/'):
    content = getUrlReq(url)
    out=[]
    img = re.compile('src="(\/promote_serial\/.*?)"',re.DOTALL).findall(content)
    img = img[0] if img else ''
    if "http" in img:
       im = img
    else:
       im = BASEURL + img

    seasons = re.compile('<a class="sezon" href="(.*?)" (?:.*?)>(.*?)<\/a>').findall(content)
    if not content:
        return ''
    for s in seasons:
        out.append({
            'url'   : BASEURL + s[0],
            'title' : unicodePLchar(s[1].strip()).decode('utf-8'),
            'img'   : im,
            })

    return out

def getEpisodes(url):
    content = getUrlReq(url)
    out=[]
    img = re.compile('src="(\/promote_serial\/.*?)"',re.DOTALL).findall(content)
    img = img[0] if img else ''
    if "http" in img:
       im = img
    else:
       im = BASEURL + img

    episodes = re.compile('<div align="left" id="sezony"[^>]*>(.*?)<a href="(.*?)" title="(.*?)">(.*?)</a></div>').findall(content)
    episodes = re.compile('<span class="vinfo">(.*?)</span> <a href="(.*?)">(.*?)</a>').findall(content)

    for s in episodes:
        h= s[1]
        h= 'https:'+h if h[0:2]=='//' else h
        t= '%s %s'%(s[0].strip(),s[2].strip())
        out.append({
            'url'   : h,
            'title' : unicodePLchar(t).decode('utf-8'),
            'img'   : im,
            })

    return out


def getPremiumVids (content):
	out=[]
	outy=[]
	outs=[]
	filmwersja=[]
	prem=''
	iframe = parseDOM(content, 'iframe', ret='src')#[0]	
	urlp = iframe[0].split('&')[0]+'&x=1&'+'&'.join(iframe[0].split('&')[1:])
	urlp = BASEURL + urlp if urlp[0]=='/' else urlp
	data=getUrlReq(urlp)
	if 'Film nie jest dost' in data:
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Linki usunięte.')
		return prem
	result = parseDOM(data, 'div', attrs={'id': "buttonsPL"})#[0]
	if result:
		links = re.findall('href="(.+?)"><span>(.+?)<',result[0])
		for link in links:
			urlp = link[0].split('&')[0]+'&x=1&'+'&'.join(link[0].split('&')[1:])
			qual = link[1]			
			urlp = BASEURL + urlp if urlp[0]=='/' else urlp
			filmwersja.append({'url':urlp,'title':qual})
			
		t = [ x.get('title') for x in filmwersja]
		u = [ x.get('url') for x in filmwersja]
		dlg_select = xbmcgui.Dialog().select('Sources', t)
		if dlg_select>-1:
			linkurl = filmwersja[dlg_select].get('url')
			data=getUrlReq(linkurl)
			result = parseDOM(data, 'video', attrs={'id': "my-video"})[0]
	
			links = re.findall('src="(.+?)".+?label="(.+?)"',result)
			for link in links:
				urlp = link[0] #.split('&')[0]+'&x=1&'+'&'.join(link[0].split('&')[1:])
				qual = link[1]
				outs.append({'url':urlp,'title':qual})	
			if len(outs)>1:
				linki = [x.get('title') for x in outs]
				s = xbmcgui.Dialog().select('Linki',linki)	
			else:
				s=0
			prem=outs[s].get('url') if s>-1 else ''
	else:
		result = parseDOM(data, 'video', attrs={'id': "my-video"})[0]
		links = re.findall('src="(.+?)".+?label="(.+?)"',result)
		for link in links:
			urlp = link[0] #.split('&')[0]+'&x=1&'+'&'.join(link[0].split('&')[1:])
			qual = link[1]
			outs.append({'url':urlp,'title':qual})	
		if len(outs)>1:
			linki = [x.get('title') for x in outs]
			s = xbmcgui.Dialog().select('Linki',linki)	
		else:
			s=0
		prem=outs[s].get('url') if s>-1 else ''
	return prem	

def getDarmoweVids(content):
	darm=''
	iframe = parseDOM(content, 'iframe', ret='src')#[0]
	try:
		if iframe:
			urlp = iframe[0].split('&')[0]+'&x=1&'+'&'.join(iframe[0].split('&')[1:])
			urlp = BASEURL + urlp if urlp[0]=='/' else urlp
			data=getUrlReq(urlp)
			if 'Film nie jest dost' in data:
				xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Linki usunięte.')
				return darm		
	
			href = re.compile('<iframe src="(.*?)" .+?></iframe>').findall(data)
			if not href:
				href = re.compile('<source src="(.*?)" type=').findall(data)
			if href:
				href='https:'+href[0] if href[0][0:2]=='//' else href[0]
				darm=href
	except:
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Duże obciążenie! Chwilowo tylko użytkownicy z kontem VIP mają dostęp do strony.')
	return darm
def getSearch(url):
	content=getUrlReq(url)
	out=[]
	serout=[]
	links = parseDOM(content, 'div', attrs={'class': "row"})  
	for link in links:
		href = parseDOM(link, 'a', ret='href')[0]
		href = BASEURL+href
		imag = parseDOM(link, 'img', ret='src')[0]	
		if "http" in imag:
			imag = imag
		else:
			imag = BASEURL + imag
		plot = parseDOM(link, 'div', attrs={'class': "desc"})[0] #if plot else ''
		title = parseDOM(link, 'a', ret='title')[0].strip()
		if '/serial/' in href:
			year=''
			code=''
		else:
			year = parseDOM(link, 'div', attrs={'class': "gen"})[0]
			year =(year.split('|'))[0].strip()
			year = int(year)
			code = parseDOM(link, 'i', ret='title')[1]
			code = (code.split('.'))[0].strip()
		one = {'url'   : href,
			'title'  : unicodePLchar(title),
			'plot'   : unicodePLchar(plot),
			'img'    : imag,
			'year'   : year if year else '',
			'code'   : code,
			'isFolder':False,
			}
		if '/serial/' in href:
			serout.append(one)	
		else:
			out.append(one)		
	return out,serout		
def getVideoUrl(url):	
	content=getUrlReq(url)
	darm=''
	prem=''
	if not'Duze obciazenie!' in content:	
		try:
			typ = re.compile("""href=['"]\/sms['"](.+?)<\/a>""").findall(content)[0]
			if 'Darmowe' in typ:
				darm=getDarmoweVids(content)
			elif 'VIP' in typ:
				prem=getPremiumVids(content)
			else:
				xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Duże obciążenie! Chwilowo tylko użytkownicy z kontem VIP mają dostęp do strony.')	

		except:
			xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Duże obciążenie! Chwilowo tylko użytkownicy z kontem VIP mają dostęp do strony.')	
	else:
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Duże obciążenie! Chwilowo tylko użytkownicy z kontem VIP mają dostęp do strony.')
	return darm,prem
	
def Gatunek(url=''):
    out=[
        {'url':"https://zalukaj.com/gatunek,22/",'title':"Akcja",},
        {'url':"https://zalukaj.com/gatunek,2/",'title':"Animowane",},
        {'url':"https://zalukaj.com/gatunek,21/",'title':"Biografie",},
        {'url':"https://zalukaj.com/gatunek,3/",'title':"Dokumentalne",},
        {'url':"https://zalukaj.com/gatunek,4/",'title':"Dramat",},
        {'url':"https://zalukaj.com/gatunek,25/",'title':"Familijne",},
        {'url':"https://zalukaj.com/gatunek,30/",'title':"Fantasty",},
        {'url':"https://zalukaj.com/gatunek,27/",'title':"Historyczne",},
        {'url':"https://zalukaj.com/gatunek,7/",'title':"Horror",},
        {'url':"https://zalukaj.com/gatunek,29/",'title':"Katastroficzne",},
        {'url':"https://zalukaj.com/gatunek,8/",'title':"Komedia",},
        {'url':"https://zalukaj.com/gatunek,23/",'title':"Kostiumowe",},
        {'url':"https://zalukaj.com/gatunek,28/",'title':"Musical",},
        {'url':"https://zalukaj.com/gatunek,20/",'title':"Obyczajowy",},
        {'url':"https://zalukaj.com/gatunek,24/",'title':"Polskie",},
        {'url':"https://zalukaj.com/gatunek,10/",'title':"Przygodowe",},
        {'url':"https://zalukaj.com/gatunek,12/",'title':"Sci-Fi",},
        {'url':"https://zalukaj.com/gatunek,13/",'title':"Sensacyjne",},
        {'url':"https://zalukaj.com/gatunek,26/",'title':"Sport",},
        {'url':"https://zalukaj.com/gatunek,14/",'title':"Thriller",},
        {'url':"https://zalukaj.com/gatunek,15/",'title':"Wojenne",},
        ]
    return out,(False, False)

def unicodePLchar(txt):
    if type(txt) is not str:
        txt=txt.encode('utf-8')
    txt = txt.replace('&nbsp;','')
    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    txt = txt.replace('&amp;','&')
    txt = txt.replace('&quot;','"')	
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')
    return txt
