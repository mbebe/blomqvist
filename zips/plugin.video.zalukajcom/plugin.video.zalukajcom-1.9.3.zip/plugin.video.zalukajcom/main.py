# -*- coding: utf-8 -*-
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import resolveurl as urlresolver

base_url     = sys.argv[0]
addon_handle = int(sys.argv[1])
args         = urlparse.parse_qs(sys.argv[2][1:])
my_addon     = xbmcaddon.Addon()
addonName    = my_addon.getAddonInfo('name')
PATH         = my_addon.getAddonInfo('path')
DATAPATH     = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES    = PATH+'/resources/'
FANART       = ''

import resources.lib.zalukaj as zalukaj

zalukaj.COOKIEFILE = os.path.join(DATAPATH,'zalukaj.cookie')
my_addon.setSetting('set','set')


def add_items(name, url, mode, params = {}, iconimage = 'DefaultFolder.png', infoLabels = False, isFolder = False, IsPlayable = True, fanart = FANART, itemcount = 1):
	u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'params':params})
	if iconimage==None:
		iconimage='DefaultFolder.png'
	liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
	art=dict(zip(art_keys,[iconimage for x in art_keys]))
	liz.setArt(art)
	if not infoLabels:
		infoLabels={'title': name}
	liz.setInfo(type='video', infoLabels=infoLabels)
	if IsPlayable:
		liz.setProperty('IsPlayable', 'true')
	if fanart:
		liz.setProperty('fanart_image',fanart)
	ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=isFolder,totalItems=itemcount)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	return ok

def addLinkItem(name, url, mode, params = {}, iconimage = 'DefaultFolder.png', infoLabels = False, isFolder = False, IsPlayable = True, fanart = FANART, itemcount = 1):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'params':params})
    liz = xbmcgui.ListItem(name)
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconimage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    art['fanart'] = fanart if fanart else art['landscape']
    liz.setArt(art)
    if not infoLabels:
        infoLabels={"title": name}
    liz.setInfo(type="video", infoLabels=infoLabels)
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')

    isFolder = infoLabels.get('isFolder',isFolder)
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=isFolder,totalItems=itemcount)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def addDir(name, ex_link = None, params = {}, mode = 'folder', iconImage = 'DefaultFolder.png', infoLabels = None, fanart = FANART, contextmenu = None):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link': ex_link, 'params': params})
    li = xbmcgui.ListItem(name)

    if infoLabels:
        li.setInfo(type="video", infoLabels=infoLabels)

    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconImage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    art['fanart'] = fanart if fanart else art['landscape']
    li.setArt(art)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def encoded_dict(in_dict):
    out_dict = {}

    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        out_dict[k] = v

    return out_dict

def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))
	
def home():
		login()
		add_items(name="[COLOR blue]Filmy Gatunek[/COLOR]",url='',params={},mode='ListFilmyGatunek',iconimage='', IsPlayable=False, isFolder=True)
		add_items(name="   Ostatnio dodane",url='https://zalukaj.com/cache/lastadded.html',params={},mode='ListItems',iconimage='', IsPlayable=False, isFolder=True)
		add_items(name="   Ostatnio oglądane",url='https://zalukaj.com/cache/lastseen.html',params={},mode='ListItems',iconimage='', IsPlayable=False, isFolder=True)
		add_items(name="   Najpopularniejsze",url='https://zalukaj.com/cache/wyswietlenia-tydzien.html',params={},mode='ListItems',iconimage='', IsPlayable=False, isFolder=True)
		add_items('   Szukaj filmu','',mode='SzukajFilmy', IsPlayable=False, isFolder=True)
		add_items(name="[COLOR blue]Seriale[/COLOR]",url='all',params={},mode='ListSeriale',iconimage='', IsPlayable=False, isFolder=True)
		add_items(name="   Ostatnio zaktualizowane",url='latest',params={},mode='ListSerialeOstatnie',iconimage='', IsPlayable=False, isFolder=True)
		add_items('Opcje','',mode='settings', IsPlayable=True, isFolder=True)	
		xbmcplugin.setContent(addon_handle, 'movies')
		xbmcplugin.endOfDirectory(addon_handle,True)		
	
def ListUlub(ex_link):
	filmy=zalukaj.getUlubioneList(ex_link)
	if not filmy:
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak filmów do wyświetlenia.')
		return	
	items=len(filmy)
	
	for f in filmy:
		add_items(name=f.get('title'), url=f.get('url',''), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True, isFolder=False,itemcount=items)
	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle)
def ListPopular(ex_link):
	filmy=zalukaj.getPopularList(ex_link)
	if not filmy:
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak filmów do wyświetlenia.')
		return	
	items=len(filmy)
	
	for f in filmy:
		addLinkItem(name=f.get('title'), url=f.get('url',''), mode='getLinks', iconimage=f.get('img',''), infoLabels=f, isFolder=True, IsPlayable=True,itemcount=items)
	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle)		
	
def ListMovies(ex_link, data = None):
	filmy,pagination = zalukaj.scanMainpage(ex_link,data)
	
	if not filmy:
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Duże obciążenie! Chwilowo tylko użytkownicy z kontem VIP mają dostęp do strony.')
		return
	
	if pagination[0]:
		addLinkItem(name='[COLOR blue]<< Poprzednia strona <<[/COLOR]', url=pagination[0], params={}, mode='page:ListItems', IsPlayable=False)
	
	items=len(filmy)
	
	for f in filmy:
		addLinkItem(name=f.get('title'), url=f.get('url',''), mode='getLinks', iconimage=f.get('img',''), infoLabels=f, isFolder=True, IsPlayable=True,itemcount=items)
	
	if pagination[1]:
		addLinkItem(name='[COLOR blue]>> Następna strona >>[/COLOR]', url=pagination[1], params={}, mode='page:ListItems', IsPlayable=False)
	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle,True)	

def ListSeriale(ex_link, nextMode):
    seriale = zalukaj.getSeriale(ex_link)
    items=len(seriale)
    if ex_link == "latest":
        nextMode = "getSeasons"
    for f in seriale:
        addLinkItem(name=f.get('title'), url=f.get('url',''), mode=nextMode, iconimage=f.get('img',''), infoLabels=f, isFolder=True, IsPlayable=True,itemcount=items)

def getSeasons(ex_link):
    seasons = zalukaj.getSeasons(ex_link)
    if not seasons:
        xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Duże obciążenie! Chwilowo tylko użytkownicy z kontem VIP mają dostęp do strony.')
        return

    items=len(seasons)

    for f in seasons:
        addLinkItem(name=f.get('title',''), url=f.get('url',''), mode='getEpisodes', iconimage=f.get('img',''), infoLabels=f, isFolder=True, IsPlayable=True,itemcount=items)

def getEpisodes(ex_link):
    episodes = zalukaj.getEpisodes(ex_link)
    if not episodes:
        xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Duże obciążenie! Chwilowo tylko użytkownicy z kontem VIP mają dostęp do strony.')
        return

    items = len(episodes)

    for f in episodes:
        addLinkItem(name=f.get('title'), url=f.get('url',''), mode='getLinks', iconimage=f.get('img'), infoLabels=f, isFolder=False, IsPlayable=True,itemcount=items)
def getLinks(ex_link):
	stream_url = ''
	darm,premium = zalukaj.getVideoUrl(ex_link)	
	if darm:
		stream_url=darm
		try:
			stream_url = urlresolver.resolve(stream_url)
		except Exception,e:
			stream_url=''
			xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))	
	elif premium:
		stream_url=premium
	if stream_url:
		xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
	else:
		xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))	
def ListSearch(url):
	films,serials = zalukaj.getSearch(url)	
	if films:
		items=len(films)
	
		for f in films:
			add_items(name=f.get('title'), url=f.get('url',''), mode='getLinks', iconimage=f.get('img',''), infoLabels=f, isFolder=False, IsPlayable=True,itemcount=items)
	if serials:
		items=len(serials)
		nextMode = "getSeasons"
		for f in serials:
			add_items(name=f.get('title'), url=f.get('url',''), mode=nextMode, iconimage=f.get('img',''), infoLabels=f, isFolder=True, IsPlayable=False,itemcount=items)
	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle,True)		
def login():
	u = my_addon.getSetting('user')
	p = my_addon.getSetting('pass')
	l = my_addon.getSetting('login')
	
	if u and p and l == 'true':
		data,data2 = zalukaj.getLogin(u,p)		
		if data:
			add_items(data[0].get('title'),url=data[0].get('url'), mode='ListItemsUlub', iconimage=data[0].get('img'),infoLabels=data[0], IsPlayable=False, isFolder=True)
			add_items(data[0].get('title2'),url=data[0].get('url2'), mode='ListItemsUlub', iconimage=data[0].get('img'),infoLabels=data[0], IsPlayable=False, isFolder=True)
		else:
			xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Błąd logowania.')
			add_items('[B]Zaloguj[/B]','',mode='settings')
	else:
	
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Błąd logowania.')
		add_items('[B]Zaloguj[/B]','',mode='settings')
	return

fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
params = args.get('params',[{}])[0]

sortV = my_addon.getSetting('sortV')
sortN = my_addon.getSetting('sortN') if sortV else 'ostatnio dodane'
if not sortV: sortV='ostatnio-dodane'

orderV = my_addon.getSetting('orderV')
orderN = my_addon.getSetting('orderN') if orderV else 'wszystkie'
if not orderV: orderV='wszystkie'

if __name__ == '__main__':
	mode = args.get('mode', None)
	if not mode:
		home()
	elif mode[0] == 'ListItemsUlub':
		ListUlub(ex_link)	
	elif mode[0] == 'ListPopular':
		ListPopular(ex_link)

		
	elif mode[0] =='ListFilmyGatunek':
		filmy,pagination = zalukaj.Gatunek(ex_link)
		addLinkItem("[COLOR blue]Sortuj:[/COLOR] [B]"+sortN+"[/B]",'',mode='filtr:sort',iconimage='',IsPlayable=False)
		addLinkItem("[COLOR blue]Wyświetl:[/COLOR] [B]"+orderN+"[/B]",'',mode='filtr:order',iconimage='',IsPlayable=False)
		
		for f in filmy:
			href=f.get('url','')+','.join([sortV,orderV,'strona-1'])
			addLinkItem(name=f.get('title'), url=href, mode='ListItems', iconimage=f.get('img',''), infoLabels=f, isFolder=True, IsPlayable=True,itemcount=len(filmy))
		xbmcplugin.setContent(addon_handle, 'movies')
		xbmcplugin.endOfDirectory(addon_handle,True)	
	elif 'filtr' in mode[0]:
		_type = mode[0].split(":")[-1]
	
		if _type=='sort':
			label=['ostatnio dodane','ostatnio oglądane','odsłon','ulubione','oceny','mobilne']
			value=['ostatnio-dodane','ostatnio-ogladane','odslon','ulubione','oceny','mobilne']
			msg = 'Sortowanie'
		elif _type=='order':
			label=['wszystkie','z lektorem','napisy pl','nietłumaczone']
			value=['wszystkie','tlumaczone','napisy-pl','nie-tlumaczone']
			msg = 'Wyświetl'
	
		s = xbmcgui.Dialog().select(msg,label)
		s = s if s > -1 else 0
		my_addon.setSetting(_type+'V',value[s])
		my_addon.setSetting(_type+'N',label[s])
		xbmc.executebuiltin('XBMC.Container.Refresh')
	
	elif mode[0] =='SzukajFilmy':
		d = xbmcgui.Dialog().input('Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
		if d:
			rurl='https://zalukaj.com/v2/ajax/load.search?html=1&q=%s'%d
			ListSearch(rurl)
			
	elif mode[0].startswith('page'):
		tmp, nmode = mode[0].split(':')
		url = build_url({'mode': nmode, 'foldername': '', 'ex_link': ex_link, 'params': params})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
	
	elif mode[0] == 'ListItems':
		ListMovies(ex_link,None)
		#xbmcplugin.setContent(addon_handle, 'movies')
		#xbmcplugin.endOfDirectory(addon_handle,True)	
		
	elif mode[0] == 'ListSeriale':
		ListSeriale(ex_link,'getSeasons')
		xbmcplugin.setContent(addon_handle, 'movies')
		xbmcplugin.endOfDirectory(addon_handle,True)	
		
	elif mode[0] == 'getSeasons':
		getSeasons(ex_link)
		xbmcplugin.setContent(addon_handle, 'movies')
		xbmcplugin.endOfDirectory(addon_handle,True)			
	elif mode[0] == 'ListSerialeOstatnie':
		ListSeriale(ex_link,'getEpisodes')
		xbmcplugin.setContent(addon_handle, 'movies')
		xbmcplugin.endOfDirectory(addon_handle,True)	
	
	elif mode[0] == 'settings':
		my_addon.openSettings()
		xbmc.executebuiltin('XBMC.Container.Refresh()')	

	elif mode[0] == 'getEpisodes':
		getEpisodes(ex_link)
		xbmcplugin.setContent(addon_handle, 'movies')
		xbmcplugin.endOfDirectory(addon_handle,True)
		
	elif mode[0] == 'getLinks': getLinks(ex_link)
	else:
		xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
