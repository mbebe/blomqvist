# -*- coding: utf-8 -*-

import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin

base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonId     = my_addon.getAddonInfo('id')
addonName       = my_addon.getAddonInfo('name')
PATH        = my_addon.getAddonInfo('path').decode('utf-8')
DATAPATH    = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES   = PATH+'/resources/'
ICON       = PATH+'/icon.png'
MH        = RESOURCES+'mh.png'
FANART=RESOURCES+'fanart.png'
sys.path.append(RESOURCES+'lib/')
op = urllib2.urlopen
r = urllib2.Request
dlg = xbmcgui.Dialog()
import time

def addLinkItem(name, url, mode, parPage=1, iconimage='DefaultFolder.png', infoLabels={}, IsPlayable=True, isFolder=False, fanart=FANART,itemcount=1):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'page':parPage,'minfo':'','iconImage':iconimage})
    isFolder = infoLabels.get('isFolder',isFolder)
    if isFolder and infoLabels.get('year',False):
        name += ' (%s)'%infoLabels.get('year')
    liz = xbmcgui.ListItem(name)
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[infoLabels.get(x,iconimage) for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    liz.setArt(art)
    liz.setInfo(type='video', infoLabels=infoLabels)
    if IsPlayable and not isFolder:
        liz.setProperty('IsPlayable', 'true')
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=isFolder,totalItems=itemcount)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = '%R, %Y, %P')
    return ok
def addDir(name,ex_link=None, parPage=1, mode='folder',iconImage='DefaultFolder.png', infoLabels={}, fanart=FANART,contextmenu=None):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'page' : parPage,'iconImage':iconImage})
    li = xbmcgui.ListItem(name)
    if infoLabels:
        li.setInfo(type='video', infoLabels=infoLabels)
    art_keys=['thumb','poster','banner','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[infoLabels.get(x,iconImage) for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    li.setArt(art)
    if contextmenu:
        isp=contextmenu
        li.addContextMenuItems(isp, replaceItems=True)
    else:
        isp = []
        isp.append(('Informacja', 'XBMC.Action(Info)'),)
        li.addContextMenuItems(isp, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = '%R, %Y, %P')
def addLinkItem2(name, url='', mode='', iconimage=None, fanart=FANART):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'page':1})
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setProperty('IsPlayable', 'false')
    if fanart:
        liz.setProperty('fanart_image',fanart)
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=False)
    return ok
def encoded_dict(in_dict):
    try:
        out_dict = {}
        for k, v in in_dict.iteritems():
            if isinstance(v, unicode):
                v = v.encode('utf8')
            elif isinstance(v, str):
                v.decode('utf8')
            out_dict[k] = v
    except:
        out_dict=in_dict
    return out_dict
def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))
	
def getverystream(url):	
	import requests
	sess = requests.Session()
	UA = "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0"
	sess.headers.update({
	'User-Agent': UA,
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Connection': 'keep-alive',})
	html=sess.get(url).content
	id=re.findall('id="videolink">([^>]+)<',html,re.DOTALL)#[0]
	if id:
		id = id[0]
		sess.headers.update({'Referer': url})
		url2='https://verystream.com/gettoken/%s?mime=true'%id
		response=sess.get(url2,allow_redirects=False)#.content
		locat= response.headers['Location']
		return locat+'|User-Agent='+UA+'&Referer='+url	
	else:
		return None
	
class default():
	@staticmethod
	def root():
		addDir(name='Filmy',mode='content',ex_link='http://ekinomaniak.tv/watch/movies/',iconImage='DefaultMovies.png',infoLabels={})
		addDir(name='  [COLOR lightblue]Kategorie[/COLOR]',mode='kategorie',ex_link='',iconImage='DefaultRecentlyAddedMovies.png',infoLabels={})
		addDir(name='  [COLOR lightblue]Ostatnio dodane[/COLOR]',mode='mainP',ex_link='recent-movies',iconImage='DefaultRecentlyAddedMovies.png',infoLabels={})
		addDir(name='  [COLOR lightblue]Najwięcej wyświetleń[/COLOR]',mode='content',ex_link='http://ekinomaniak.tv/watch/movies?sort=views',iconImage='DefaultRecentlyAddedMovies.png',infoLabels={})
		addDir(name='  [COLOR lightblue]Najwy\xc5\xbcej oceniane[/COLOR]',mode='content',ex_link='http://ekinomaniak.tv/watch/movies?sort=rating',iconImage='DefaultRecentlyAddedMovies.png',infoLabels={})
		addDir(name='Seriale',mode='content',ex_link='http://ekinomaniak.tv/watch/tv-shows/',iconImage='DefaultTVShows.png',infoLabels={})
		addDir(name='  [COLOR lightblue]Ostatnio dodane[/COLOR]',mode='mainP',ex_link='recent-tv-shows',iconImage='DefaultRecentlyAddedEpisodes.png',infoLabels={})		
		addDir(name='  [COLOR lightblue]Najwięcej wyświetleń[/COLOR]',mode='content',ex_link='http://ekinomaniak.tv/watch/tv-shows?sort=views',iconImage='DefaultRecentlyAddedEpisodes.png',infoLabels={})		
		addDir(name='  [COLOR lightblue]Najwy\xc5\xbcej oceniane[/COLOR]',mode='content',ex_link='http://ekinomaniak.tv/watch/tv-shows?sort=rating',iconImage='DefaultRecentlyAddedEpisodes.png',infoLabels={})		
		addDir(name='Szukaj',mode='search',ex_link=None, iconImage='DefaultAddonsSearch.png' )
		xbmcplugin.endOfDirectory(addon_handle)
	@staticmethod
	def getCategories():
		href=['https://ekinomaniak.tv/watch-genres/Akcja', 'https://ekinomaniak.tv/watch-genres/Animacja', 'https://ekinomaniak.tv/watch-genres/Anime', 'https://ekinomaniak.tv/watch-genres/Biograficzny', 'https://ekinomaniak.tv/watch-genres/Dokumentalny', 'https://ekinomaniak.tv/watch-genres/Dramat', 'https://ekinomaniak.tv/watch-genres/Dramat-historyczny', 'https://ekinomaniak.tv/watch-genres/Edukacyjny', 'https://ekinomaniak.tv/watch-genres/Erotyczny', 'https://ekinomaniak.tv/watch-genres/Etiuda', 'https://ekinomaniak.tv/watch-genres/Familijny', 'https://ekinomaniak.tv/watch-genres/Fantasy', 'https://ekinomaniak.tv/watch-genres/Historyczny', 'https://ekinomaniak.tv/watch-genres/Horror', 'https://ekinomaniak.tv/watch-genres/Katastroficzny', 'https://ekinomaniak.tv/watch-genres/Komedia', 'https://ekinomaniak.tv/watch-genres/Komedia-kryminalna', 'https://ekinomaniak.tv/watch-genres/Komedia-obyczajowa', 'https://ekinomaniak.tv/watch-genres/Komedia-romantyczna', 'https://ekinomaniak.tv/watch-genres/Krtkometraowy', 'https://ekinomaniak.tv/watch-genres/Krymina', 'https://ekinomaniak.tv/watch-genres/Melodramat', 'https://ekinomaniak.tv/watch-genres/Musical', 'https://ekinomaniak.tv/watch-genres/Muzyczny', 'https://ekinomaniak.tv/watch-genres/Niemy', 'https://ekinomaniak.tv/watch-genres/Przygodowy', 'https://ekinomaniak.tv/watch-genres/Romans', 'https://ekinomaniak.tv/watch-genres/Sci-fi', 'https://ekinomaniak.tv/watch-genres/Sportowy', 'https://ekinomaniak.tv/watch-genres/Thriller', 'https://ekinomaniak.tv/watch-genres/Western', 'https://ekinomaniak.tv/watch-genres/Wojenny']
		tyt=['Akcja', 'Animacja', 'Anime', 'Biograficzny', 'Dokumentalny', 'Dramat', 'Dramat historyczny', 'Edukacyjny', 'Erotyczny', 'Etiuda', 'Familijny', 'Fantasy', 'Historyczny', 'Horror', 'Katastroficzny', 'Komedia', 'Komedia kryminalna', 'Komedia obyczajowa', 'Komedia romantyczna', 'Kr\xc3\xb3tkometra\xc5\xbcowy', 'Krymina\xc5\x82', 'Melodramat', 'Musical', 'Muzyczny', 'Niemy', 'Przygodowy', 'Romans', 'Sci-fi', 'Sportowy', 'Thriller', 'Western', 'Wojenny']
		s = xbmcgui.Dialog().select('Kategorie:',tyt)		
		h=href[s] if s>-1 else quit()
		default().content(h)

	@staticmethod
	def mainP(ex_link):
		from ekinomaniaktv import ekinomaniaktv
		out = ekinomaniaktv().getMainPage(ex_link)
		my_mode2= 'getLink' if 'recent-movies' in ex_link else 'getSeasons'	
		for f in out:
			addLinkItem(name=f.get('title'), url=f.get('href'), mode=my_mode2, iconimage=f.get('img'), infoLabels=f, isFolder=f.get('isFolder',True), IsPlayable=f.get('IsPlayable',False))
		xbmcplugin.endOfDirectory(addon_handle)
	@staticmethod
	def content(ex_link):
		from ekinomaniaktv import ekinomaniaktv
		out,pagination = ekinomaniaktv().getContent(ex_link)
		my_mode='__page__:content'	
		my_mode2= 'getLink' if 'watch/movies' in ex_link else 'getSeasons'
		if pagination[0]:
			addLinkItem(name='[COLOR lightblue]<< poprzednia strona <<[/COLOR]', url=pagination[0], mode=my_mode, IsPlayable=False)
		for f in out:
			addLinkItem(name=f.get('title'), url=f.get('href'), mode=my_mode2, iconimage=f.get('img'), infoLabels=f, isFolder=f.get('isFolder'), IsPlayable=f.get('IsPlayable'))
		if pagination[1]:
			addLinkItem(name='[COLOR lightblue]>> nast\xc4\x99pna strona >>[/COLOR]', url=pagination[1], mode=my_mode, IsPlayable=False)
		xbmcplugin.endOfDirectory(addon_handle)
	@staticmethod
	def page(mode,ex_link):
		my_mode=mode.split(':')[-1]
		url = build_url({'mode': my_mode, 'foldername': '', 'ex_link' : ex_link })
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
	@staticmethod
	def getSeasons(ex_link,rys):	
		from ekinomaniaktv import ekinomaniaktv
		ektv=ekinomaniaktv()
		seasons = ektv.getSeasons(ex_link)
		episodes = ektv.getEpisodes(seasons)
		for items in sorted(episodes.keys()):
			addDir(name=items, ex_link=urllib.quote(str(episodes[items])), mode='getEpisodes',iconImage=rys)
		xbmcplugin.endOfDirectory(addon_handle)
	@staticmethod
	def getEpisodes(ex_link,rys):
	
		seasons = eval(urllib.unquote(ex_link))
		for f in seasons:
			addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLink', iconimage=rys, infoLabels=f, IsPlayable=True,fanart=f.get('img'))
		xbmcplugin.endOfDirectory(addon_handle)
	@staticmethod
	def getLink(ex_link,fname):	
		from ekinomaniaktv import ekinomaniaktv
		link = ekinomaniaktv().getLink(ex_link)
		if 'verystream' in link:
			stream_url = getverystream(link)
		if not stream_url:
			try:
				import resolveurl as urlresolver
				stream_url = urlresolver.resolve(link)
			except Exception,e:
				stream_url=''
				xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','','ERROR: %s'%str(e))
			
		if stream_url:
			xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
			#iconimage = xbmc.getInfoImage("ListItem.Thumb")
			#listitem = xbmcgui.ListItem(iconImage=iconimage, thumbnailImage=iconimage,path=stream_url)
			#listitem.setInfo('video', {'Title': fname})			
			#xbmc.Player().play(stream_url, listitem)	
	
	@staticmethod
	def search(mode,ex_link):
		from cache import storage
		mymode=mode.split(':')[-1] if ':' in mode else ''
		if mymode == '':
			addDir('[COLOR lightgreen]Nowe szukanie ...[/COLOR]',ex_link='',mode='search:new')
			history = storage().getHistory()
			if not history == ['']:
				for entry in history:
					contextmenu = []
					contextmenu.append((u'Remove', 'XBMC.Container.Update(%s)'% build_url({'mode': 'search:delOne', 'ex_link' : entry})),)
					contextmenu.append((u'Remove All', 'XBMC.Container.Update(%s)' % build_url({'mode': 'search:delAll'})),)
					addDir(name=entry, ex_link=entry, mode='search:new', fanart=None, contextmenu=contextmenu)
			xbmcplugin.endOfDirectory(addon_handle)
		elif mymode =='new':
			if not ex_link:
				search_entry = dlg.input(u'Tytu\u0142 filmu/serialu', type=xbmcgui.INPUT_ALPHANUM)
				if search_entry: storage().setHistory(search_entry)
			else:
				search_entry = ex_link
			if search_entry:
				print ('search_title',search_entry)
				from ekinomaniaktv import ekinomaniaktv
				out = ekinomaniaktv().search(search_entry)
				for f in out:
					addLinkItem(name=f.get('title'), url=f.get('href'), mode=f.get('mode'), iconimage=f.get('img'), infoLabels=f, isFolder=f.get('isFolder'), IsPlayable=f.get('IsPlayable'))
				xbmcplugin.endOfDirectory(addon_handle)
			else:
				quit()
		elif mymode =='delOne':
			storage().delOne(ex_link)
			xbmc.executebuiltin('XBMC.Container.Update(%s)'%  build_url({'mode': 'search'}))
		elif mymode =='delAll':
			storage().delAll()
			xbmc.executebuiltin('XBMC.Container.Update(%s)'%  build_url({'mode': 'search'}))