# -*- coding: utf-8 -*-

import xbmcaddon
addonName       = xbmcaddon.Addon().getAddonInfo('name')
class storage():
    def __init__(self,name=addonName):
        try:
            import StorageServer
        except:
            import storageserverdummy as StorageServer
        self.cache = StorageServer.StorageServer(name)
    def encode_entry(self,t):
        return t.encode('utf-8') if isinstance(t,unicode) else t
    def getHistory(self):
        return self.cache.get('history').split(';')
    def setHistory(self,entry):
        history = self.getHistory()
        if history == ['']:
            history = []
        history.insert(0, self.encode_entry(entry))
        try:
            self.cache.set('history',';'.join(history[:50]))
        except:
            pass
    def delOne(self,entry):
        history = self.getHistory()
        if history:
            try:
                self.cache.set('history',':'.join(history[:50]))
            except:
                pass
        else:
            self.delAll()
    def delAll(self):
        self.cache.delete('history')
