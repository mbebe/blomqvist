# -*- coding: utf-8 -*-

import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin

TIMEOUT = 15
UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'
COOKIE='ekinomaniak.cookie'
class NoRedirection(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response		
		
def getUrl(url,data=None):
    cookie = cookielib.LWPCookieJar()
    if data:
        opener = urllib2.build_opener(NoRedirection, urllib2.HTTPCookieProcessor(cookie))
    else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(cookie))
    opener.addheaders = [('User-Agent', UA)]
    try:
        response = opener.open(url,data,TIMEOUT)
        result= response.read()
        response.close()
    except:
        result=l1llll11l1l1_ek_ = e.read()
    return result
def PLchar(char):
    if isinstance(char, unicode):
        char = char.encode('utf-8')
    char = char.replace('&lt;br/&gt;',' ')
    s='JiNcZCs7'
    char = re.sub(s.decode('base64'),'',char)
    char = char.replace('\n','').replace('\r','')
    char = char.replace('&nbsp;','')
    char = char.replace('&quot;','"').replace('&amp;quot;','"')
    char = char.replace('&oacute;','\xc3\xb3').replace('&Oacute;','\xc3\x93')
    char = char.replace('&amp;oacute;','\xc3\xb3').replace('&amp;Oacute;','\xc3\x93')
    char = char.replace('&amp;','&')
    char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
    char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
    char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
    char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
    char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
    char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
    char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
    char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
    char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
    return char

def demix(e):
    result = {"d": "A", "D": "a", "a": "D", "a": "d", "c": "B", "C": "b", "b": "C", "b": "c", "h": "E", "H": "e", "e": "H", "E": "h", "g": "F", "G": "f", "f": "G", "F": "g", "l": "I", "L": "i", "i": "L", "I": "l", "k": "J", "K": "j", "j": "K", "J": "k", "p": "M", "P": "m", "m": "P", "M": "p", "o": "N", "O": "n", "n": "O",
              "N": "o", "u": "R", "U": "r", "r": "U", "R": "u", "t": "S", "T": "s", "s": "T", "S": "t", "z": "W", "Z": "w", "w": "Z", "W": "z", "y": "X", "Y": "x", "x": "Y", "X": "y", "3": "1", "1": "3", "4": "2", "2": "4", "8": "5", "5": "8", "7": "6", "6": "7", "0": "9", "9": "0"
              }.get(e)
    if result == None:
        result = '%'
    return result

def decodwrd(e):
    r = ""
    for i in range(len(e)):
        r += demix(e[i])
    return r

def decodeURIComponent(r):
    return urllib.unquote(r.encode("utf-8"))

def deshwp(e):
    r = decodwrd(e)
    return decodeURIComponent(r)
class ekinomaniaktv:
    @staticmethod
    def getMainPage(id='top-rated-tv-shows'):
        content = getUrl('http://ekinomaniak.tv')
        my_mode = False if '-movies' in id else True
        IsPlayable = False if my_mode else True
        out=[]
        content2 = re.compile('<div class="tab-pane(?: active|)" id="%s">(.*?)<div style="clear'%id,re.DOTALL).findall(content)
        if content2:
            content2 = content2[0]
            ids = [(a.start(), a.end()) for a in re.finditer('<div class="small-item"', content2,re.IGNORECASE)]
            ids.append( (-1,-1) )
            for i in range(len(ids[:-1])):
                subset = content2[ ids[i][1]:ids[i+1][0] ]
                href = re.compile('<a href="(.*?)"',re.DOTALL).findall(subset)
                title = re.compile('alt="(.*?)"',re.DOTALL).findall(subset)
                imag = re.compile('<img src="(.*?)"',re.DOTALL).findall(subset)
                year = re.compile('\\(((?:19|20)\\d{2})\\)',re.DOTALL).findall(subset)
                if href and title:
                    imag = imag[0] .replace('thumbnails/','') if imag else ''
                    title = title[0]
                    code=''
                    one = {'href'   : urljoin('http://ekinomaniak.tv',href[0]),
                        'title'  : PLchar(title),
                        'img'    : PLchar(imag),
                        'plot'   : '',
                        'year'   : year[0] if year else '',
                        'ifFolder'   : my_mode,
                        'IsPlayable' : IsPlayable,
                        }
                    out.append(one)
        return out

		
    @staticmethod
    def getContent(url,data=None):
        urlx = urljoin('http://ekinomaniak.tv',url) if url.startswith('/') else url
        content = getUrl(urlx)
        my_mode = True if '/watch/tv-shows' in url else False
        IsPlayable = False if my_mode else True
        ids = [(a.start(), a.end()) for a in re.finditer('<div class="small-item"', content,re.IGNORECASE)]
        ids.append( (-1,-1) )
        out=[]
        for i in range(len(ids[:-1])):
            subset = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile('<a href="(.*?)"',re.DOTALL).findall(subset)
            title = re.compile('alt="(.*?)"',re.DOTALL).findall(subset)
            imag = re.compile('<img src="(.*?)"',re.DOTALL).findall(subset)
            year = re.compile('\\(((?:19|20)\\d{2})\\)',re.DOTALL).findall(subset)
            views = re.compile('<div style="position:absolute;bottom:2px;right:-2px;color:white;background:black;padding:1px;padding-left:6px"><b>(.*?)</b> wyśw.</div>',re.DOTALL).findall(subset)
            if href and title:
                imag = imag[0].replace('thumbnails/','') if imag else ''
                title = title[0]
                code=''
                one = {'href'   : urljoin('http://ekinomaniak.tv',href[0]),
                       'title'  : PLchar(title),
                       'img'    : PLchar(imag),
                       'plot'   : '',
                       'isFolder': my_mode,
                       'IsPlayable':IsPlayable,
                       'year'   : year[0] if year else '',
                       'code'   : code,
                        }
                out.append(one)
        pagination =re.findall('<div class="pagination">\\s*<ul>(.*?)</ul>',content)
        nextPage=False
        prevPage=False
        if pagination:
            pagination = pagination[0]
            prevPage = re.findall('<li class="previous"><a href="(.*?)">',content)
            prevPage = prevPage[0] if prevPage else False
            prevPage = urlx.split('/page')[0] if  prevPage=='1' else prevPage
            nextPage = re.findall('<li><a href="(.*?)">',pagination)
            nextPage = nextPage[-1] if nextPage else False
        return (out, (prevPage,nextPage))
    @staticmethod
    def getSeasons(url):
        urlx = urljoin('http://ekinomaniak.tv',url) if url.startswith('/') else url
        content = getUrl(urlx)
        episodes = re.findall('<li class="active"><span>Sezon: (\\d+)</span><ul(.*?)</ul>',content,re.DOTALL)
        imag =  re.findall('<div style="position:relative">[\\s\n]*<img src="(.*?)"',content)
        imag = imag[0].replace('thumbnails/','') if imag else ''
        out=[]
        for epis, data in episodes:
            seas = int(epis)
            hrefTitle = re.findall('<a href="(.*?)">(.+?)</a></li>',data)
            for href,title in hrefTitle:
                episode = re.findall('(\\d+)',title)
                episode = int(episode[0]) if episode else ''
                one = { 'href'  : href,
                    'season' : seas,
                    'img': imag,
                    'episode' : episode,
                    'mediatype': 'episode',
                    'title' : PLchar(title)}
                out.append(one)
        return out
    @staticmethod
    def getEpisodes(out):
        outx={}
        episodes = [x.get('season') for x in out]
        for s in set(episodes):
            outx['Sezon %02d'%s]=[out[i] for i, j in enumerate(episodes) if j == s]
        return outx
		
    @staticmethod
    def getLink(url):
        urlx = urljoin('http://ekinomaniak.tv',url) if url.startswith('/') else url
        content = getUrl(urlx)
        shwpu = re.findall('document.write\(shwp\("(.*?)"\)',content)
        if shwpu:
            decoded = deshwp(shwpu[0])#.replace('\n','')
            
            src = re.findall('src="(.*?)"',decoded,re.DOTALL)

          #  shwpu = shwpu[0].replace('%','')
          #  hex = '000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f202122232425262728292a2b2c2d2e2f393334313238373635303a3b3c3d3e3f404142434445464748494a4b4c4d4e4f505152535455565758595a5b5c5d5e5f606463626165666665696a6b6c6d6e6f707172737475767778797a7b7c7d7e7f808182838485868788898a8b8c8d8e8f909192939495969798999a9b9c9d9e9fa0a1a2a3a4a5a6a7a8a9aaabacadaeafb0b1b2b3b4b5b6b7b8b9babbbcbdbebfc0c1c2c3c4c5c6c7c8c9cacbcccdcecfd0d1d2d3d4d5d6d7d8d9dadbdcdddedfe0e1e2e3e4e5e6e7e8e9eaebecedeeeff0f1f2f3f4f5f6f7f8f9fafbfcfdfeff'.decode('hex')
          #  src = re.findall('src="(.*?)"', shwp.translate(hex).decode('hex'))
            if src:
                return src[0].replace('\n','')
        else:
            return ''		
    @staticmethod
    def search(text='dom'):
        urlx = 'http://ekinomaniak.tv/ajax/search?search_term='+urllib.quote_plus(text)
        content = getUrl(urlx)
        scan =re.findall('<a href="(.*?)">\\s*<img src="(.*?)".+?<a href=".*?">(.*?)</a>\\s*<br',content,re.DOTALL)
        out=[]
        for href,imag,title in scan:
            isFolder = True if 'tv-shows' in href else False
            IsPlayable = False if isFolder else True
            mode = 'getSeasons'  if isFolder else 'getLink'
            one = {'href'   : href,
                    'title'  : PLchar(title.strip()),
                    'img'    : imag.replace('thumbnails/',''),
                    'isFolder': isFolder,
                    'IsPlayable': IsPlayable,
                    'mode':mode,
                    }
            out.append(one)
        return out
