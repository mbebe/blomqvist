# -*- coding: utf-8 -*-
import requests
import re, base64
from urlparse import urljoin

TIMEOUT = 10
UA      = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36'
CT      = 'application/x-www-form-urlencoded'
s=requests.Session()
def getUrl(url, data = None, redirect = True, headers={}):
	if not headers:
		headers = {'szukaj': data, 'User-Agent': UA, 'Referer': url}
	else:
		pass
	r = s.post(url, data=headers, allow_redirects=redirect)
	return r.content

def unicodePLchar(txt):
    if isinstance(txt, unicode):
        txt = txt.encode('utf-8')
    txt = txt.replace('&lt;br/&gt;',' ')
    s='JiNcZCs7'
    txt = re.sub(s.decode('base64'),'',txt)
    txt = txt.replace('\n','').replace('\r','')
    txt = txt.replace('&nbsp;','')
    txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')
    return txt

class boxfilmpl:
	@staticmethod
	def getContent(url, data = None):
		if data:
			url= 'https://www.boxfilm.pl/szukaj'
			redirect = False
		else:
			redirect = True
	
		if not url:
			url = 'https://www.boxfilm.pl/'
		elif url.startswith('/'):
			url = urljoin('https://www.boxfilm.pl',url)
	
		content = getUrl(url, data, redirect)
	
		ids = [(a.start(), a.end()) for a in re.finditer('<div class="video_info">', content,re.IGNORECASE)]
	
		ids.append( (-1,-1) )
		out = []
	
		for i in range(len(ids[:-1])):
			cw = content[ ids[i][1]:ids[i+1][0] ]
			href = re.compile('<a href="(.*?)"',re.DOTALL).search(cw)
			title = re.compile('<h1>(.*?)</h1>',re.DOTALL).search(cw)
			img = re.compile('<img src="(.*?)"',re.DOTALL).search(cw)
			lektor = re.findall('Lektor:\s*<span style="[^>]*">(.*?)</span>',cw)
			dodany = re.findall('Dodany:\s*<span style="[^>]*">(.*?)</span>',cw)
			gatunek = re.findall('Gatunek:\s*<span style="[^>]*">(.*?)</span>',cw)
			lektor = lektor[0] if lektor else ''
			dodany = dodany[0] if dodany else ''
			gatunek = gatunek[0] if gatunek else ''
			plot = "Lektor: %s \nDodany: %s \nGatunek: %s \n" %(lektor,dodany,gatunek)
	
			if href and title:
				img = urljoin('https://www.boxfilm.pl',img.group(1)) if img else ''
				title = title.group(1)
				year =  re.findall('\((\d{4})\)',title)
				one = {'href'   : href.group(1),
					'title'  : unicodePLchar(title),
					'img'    : img,
					'plot'   : unicodePLchar(plot),
					'year'   : year[0] if year else '',
					'code'   : lektor,
						}
				out.append(one)
	
		nextPage = False
		previousPage = re.findall('<a href="([^"]*)"><div class="next_site">Poprzednia</div></a>',content)
		previousPage = previousPage[0] if previousPage else False
		nextPage = re.findall('<a href="([^"]*)"><div class="next_site">Nast.+pna</div></a>',content)
		nextPage = nextPage[0] if nextPage else False
		return (out, (previousPage,nextPage))
	
	@staticmethod
	def getCategory():
		content = getUrl('https://www.boxfilm.pl/kontakt')
		kat = re.findall('<a href="(/katalog/.*)" class="nav_link">(.*?)</a>',content)
		out = []
	
		for href, name in kat:
			out.append({'href': href,'title': name})
	
		return out
	
	@staticmethod
	def getVideos(url):
		url = urljoin('https://www.boxfilm.pl/',url)
		headers = {'User-Agent': UA, 'Referer': url}
		content = s.get(url,headers=headers)#.content
		content=content.content
		out = ''
		iframe = re.findall('<iframe(.*?)</iframe>',content,re.DOTALL|re.IGNORECASE)	
		if not iframe:
			content = s.get('https://www.boxfilm.pl/include/player.php',headers=headers).content
			iframe = re.findall('<iframe(.*?)</iframe>',content,re.DOTALL|re.IGNORECASE)
		if iframe:
			out = re.findall('src="(.*?)"',iframe[0],re.DOTALL|re.IGNORECASE)
			out = out[0] if out else ''
		return out
