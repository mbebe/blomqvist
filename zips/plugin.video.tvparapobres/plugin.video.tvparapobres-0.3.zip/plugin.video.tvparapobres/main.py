# -*- coding: UTF-8 -*-
from __future__ import division
import sys,re,os
import six
from six.moves import urllib_parse

#import json

import requests
from requests.compat import urlparse

import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc, xbmcvfs
from resources.lib.brotlipython import brotlidec

if six.PY3:
    basestring = str
    unicode = str
    xrange = range
    from resources.lib.cmf3 import parseDOM
else:
    from resources.lib.cmf2 import parseDOM
import resolveurl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(urllib_parse.parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.tvparapobres')

PATH            = addon.getAddonInfo('path')
if six.PY2:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
else:
    DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'../fanart.jpg'
ikona =RESOURCES+'../icon.png'

exlink = params.get('url', None)
nazwa= params.get('title', None)
rys = params.get('image', None)

page = params.get('page',[1])

UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0'
TIMEOUT=15
proxyport = addon.getSetting('proxyport')
playt = addon.getSetting('play')
headers = {'User-Agent': UA,}
sess = requests.Session()

def build_url(query):
    return base_url + '?' + urllib_parse.urlencode(query)

def add_item(url, name, image, mode, itemcount=1, page=1,fanart=FANART, infoLabels=False,contextmenu=None,IsPlayable=False, folder=False):
    list_item = xbmcgui.ListItem(label=name)
    if IsPlayable:
        list_item.setProperty("IsPlayable", 'True')    
    if not infoLabels:
        infoLabels={'title': name}    
    list_item.setInfo(type="video", infoLabels=infoLabels)    
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': fanart})
    
    if contextmenu:
        out=contextmenu
        list_item.addContextMenuItems(out, replaceItems=True)

    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url = build_url({'mode': mode, 'url' : url, 'page' : page, 'title':name,'image':image}),            
        listitem=list_item,
        isFolder=folder)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def home():

    add_item('https://tvparapobres.com/filmes/page/1', '[COLOR khaki][B]Filmes[/COLOR][/B]', ikona, "listmovies",fanart=FANART, folder=True)
    add_item('https://tvparapobres.com/genero/animacao/page/1', '[COLOR khaki][B]Animacao[/COLOR][/B]', ikona, "listmovies",fanart=FANART, folder=True)
    add_item('https://tvparapobres.com/series/page/1', '[COLOR khaki][B]Series[/COLOR][/B]', ikona, "listmovies",fanart=FANART, folder=True)
    add_item('genero', '[COLOR khaki][B]Genero[/COLOR][/B]', ikona, "listgenre",fanart=FANART, folder=True)
    add_item('https://tvparapobres.com/page/1/', '[COLOR yellowgreen][B]Pesquisar[/COLOR][/B]', ikona, "search",fanart=FANART, folder=True)
	
def listgenre(typ):
	url ='https://tvparapobres.com/'
	html = sess.get(url, headers = headers, verify=False).text
	if 'genero' in typ:
		result = parseDOM(html,'li', attrs={'id':"menu-item-85"} )[0]
		for x in parseDOM(result,'li'):
			ispla = False
			fold = True
			mod = 'listmovies'
			href = parseDOM(x,'a', ret="href")[0]
			tyt = parseDOM(x,'a')[0]
			add_item(href+'page/1/', tyt, ikona, mod,fanart=FANART, folder=fold, IsPlayable=ispla, infoLabels={'plot':tyt})

	xbmcplugin.endOfDirectory(addon_handle) 

def ListMovies(url, pg):

	if '/page/' in url:
		url = re.sub('/page/\\d+','/page/%d'%int(pg),url)
	else:
		url = url + '/page/%d' %int(pg)	
	html = sess.get(url, headers = headers, verify=False).text
	ntpage = re.sub('/page/\\d+','/page/%d'%(int(pg)+1),url)

	if '/genero/' in url or '/?s='  in url:
		result = html
	else:
		result = parseDOM(html,'div', attrs={'id':"archive-content"} )[0] 
	
	if '/?s='  in url:
		links = parseDOM(result,'div', attrs={'class':"result-item"} ) 
	else:
		links = parseDOM(result,'article', attrs={'id':"post\-\d+","class":"item.*?"} )
	
	
	
	
	for link in links:
	
		href = parseDOM(link,'a', ret="href")[0]
		plot =''
		if '/?s='  in url:
			tit_data = parseDOM(link,'div', attrs={'class':"details"} )[0]
			title = parseDOM(tit_data,'a')[0].replace('&#8211;','-').replace('&#038;','&')
			plot = parseDOM(link,'p')[0]
		else:
			title = parseDOM(link,'h4')[0].replace('&#8211;','-').replace('&#038;','&')
		href = 'https://tvparapobres.com'+href if href.startswith('/') else href
	

		img = parseDOM(link,'img', ret="src")#[0]
		try:
			img = ikona if img[0] == '' else img[0]
		except:
			img = ikona
		if not plot:
			plot = parseDOM(link,'div', attrs={'class':"texto"} )
			plot = plot[0] if plot else title
		plot = plot.replace('&#8211;','-').replace('&#8220;','"').replace('&#8221;','"').replace('&#8230;','...').replace('&#038;','&')
		ispla = False
		fold = True
		mod = 'listlinks'
		h2 = href+'|'+title
		if '/series/' in href:
			ispla = False
			fold = True
			mod = 'listserial'
			h2 = href
		add_item(h2, title, img, mod,fanart=FANART, folder=fold, IsPlayable=ispla, infoLabels={'plot':plot})

	if not '/?s='  in url:
		if not ntpage.endswith('/'): ntpage = ntpage+'/'

	ab = html.find(ntpage)>0

	if ab:

		nextpage = unicode(int(pg)+1)
		add_item(ntpage, '>> next page >>' ,RESOURCES+'right.png', "listmovies",fanart=FANART, page=nextpage, folder=True)
	xbmcplugin.endOfDirectory(addon_handle) 
	
def ListSerial(url):

	html = sess.get(url, headers = headers, verify=False).text

	img_main_dat = parseDOM(html,'div', attrs={'class':"poster" })[0] 
	img_main = parseDOM(img_main_dat,'img', ret="src")[0]
	orig_title = parseDOM(html,'span', attrs={'class':"valor"})[0]
	
	
	orig_title = orig_title.replace('&#8211;','-').replace('&#8220;','"').replace('&#8221;','"').replace('&#8230;','...').replace('&#038;','&')
	plot_data =  parseDOM(html,'div', attrs={'class':"wp-content"})
	plot = ''
	if plot_data:
		plot =  parseDOM(plot_data[0],'p')
		plot = plot[0] if plot else orig_title
	plot = plot.replace('&#8211;','-').replace('&#8220;','"').replace('&#8221;','"').replace('&#8230;','...').replace('&#038;','&')
	data = parseDOM(html,'div', attrs={'id':"seasons"} )[0]
	seasons = parseDOM(data,'div', attrs={'class':'se-c'} )
	out=[]
	
	for season in seasons:

		ses = parseDOM(season,'span', attrs={'class':'se-t.*?'} )[0]

		episodes = parseDOM(season,'li')

		for episode in episodes:

			episod = parseDOM(episode,'div', attrs={'class':'numerando'} )[0] 
			epis = re.findall('(\d+)',episod,re.DOTALL+re.I)[-1]
			img_epis = parseDOM(episode,'img', ret="src")[0]
			href_epis = parseDOM(episode,'a', ret="href")[0]
			epis_tyt = parseDOM(episode,'a')[0]
			epis_tyt = epis_tyt.replace('&#8211;','-').replace('&#8220;','"').replace('&#8221;','"').replace('&#8230;','...').replace('&#038;','&')
			jaki = ' - [COLOR khaki]%s[/COLOR] - (S%02dE%02d) '%(str(epis_tyt),int(ses),int(epis))
				
			tyt = orig_title+jaki
			out.append({'title':tyt,'href':href_epis+'|'+url,'img':img_epis, 'fnrt':FANART, 'plot':plot, 'season' : int(ses),'episode' : int(epis) })
	sezony =  splitToSeasons(out)

	for i in sorted(sezony.keys()):
		ac=urllib_parse.quote_plus(str(sezony[i]))
		add_item(ac, i, img_main, 'listepisodes',fanart=FANART, folder=True, IsPlayable=False, infoLabels={'plot':plot})
	xbmcplugin.endOfDirectory(addon_handle) 
		
		
def ListEpisodes(exlink):
	import ast

	episodes = ast.literal_eval(urllib_parse.unquote_plus(exlink))
	
	itemz=episodes
	items = len(episodes)
	
	for f in itemz:

		add_item(f.get('href')+'***'+f.get('title'), f.get('title'), f.get('img'), 'listlinks',fanart=FANART, folder=True, IsPlayable=False, infoLabels={'plot':f.get('plot')})

	xbmcplugin.endOfDirectory(addon_handle) 
	
def splitToSeasons(input):
	out={}
	seasons = [x.get('season') for x in input]

	xx= re.findall('^(.*?)\-',input[0].get('title', None))[0]
	for s in set(seasons):

		out[xx+ ' Season %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
	return out
	
def ListLinks(urlk, ima = None):

	
	playt = str(addon.getSetting('play'))
	add_item('xxxx', '===== playing: [COLOR khaki]%s[/COLOR] ====='%(playt), ikona, 'sett',fanart=FANART, folder=False, IsPlayable=False)
	url,tyt = urlk.split('|')	
	if '***' in tyt:
		url2,tyt =  tyt.split('***')
	
	response = sess.get(url, headers=headers).text
	
	xx=''

	html = response.replace("\'",'"')
	infodata = parseDOM(html,'div', attrs={'id':'info'} )
	img = ikona
	plot = tyt
	if infodata:
		try:
			plot = parseDOM(infodata[0],'p')[0]
		except:
			plot = tyt
		#try:
	imgdata = parseDOM(html,'div', attrs={'class':'poster'} )
	if imgdata:
		img = parseDOM(imgdata[0],'img', ret="src")#[0]
		img = img[0] if img else ''#ikona
	else:
		try:
			img = parseDOM(infodata,'img', ret="src")[0]
		except:
			img =''
	img = img if img else ima

	ids = [(a.start(), a.end()) for a in re.finditer('<li\s*id\s*=\s*"\s*player\-option', html)] 
	ids.append( (-1,-1) )
	l = 1
	ok = False
	mod = 'playvideo' 
	ispla = True
	fold = False
	for i in range(len(ids[:-1])):
		subset = html[ ids[i][1]:ids[i+1][0] ]
		try:
			x,y,z = re.findall('data\-type="([^"]+)"\s*data\-post="([^"]+)"\s*data\-nume="([^"]+)"',subset,re.DOTALL+re.I)[0]
		except:
			x=''
			y=''
			z=''
		if (x,y,z):
			host = re.findall('"\s*title\s*"\s*>([^<]+)<',subset,re.DOTALL+re.I)[0]
			ok = True
			#x=''
			tit = tyt+' - Link '+str(l)+ ' (%s)'%(str(host))
			player = 'https://tvparapobres.com/wp-json/dooplayer/v2/%s/%s/%s'%(str(y),str(x),str(z))

			add_item(player, tit, img, mod,fanart=FANART, folder=fold, IsPlayable=ispla, infoLabels={'plot':plot})#, 'year':year, 'duration':duration})
			l+=1
	if ok:
		xbmcplugin.endOfDirectory(addon_handle) 
	
	else:
		xbmcgui.Dialog().notification('[B]Info[/B]', 'Links are not available',xbmcgui.NOTIFICATION_INFO, 6000)
			
def PlayVideo(url):	
	link = None

	html = sess.get(url, headers = headers, verify=False).text
	if '"embed_url":"http' in html:
		import json
		data = json.loads(html)
		url = data.get('embed_url', None)
	
	try:
		link = resolveurl.resolve(url)
	except:
		link=None

	if link:
		video_url = link
		if pla():
			video_url = link
		else:
			if '|' in link:
				link = link.split('|')[0]
			video_url = 'http://127.0.0.1:{port}/dd='.format(port=proxyport)+link
		
		play_item = xbmcgui.ListItem(path=video_url)#

		#play_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
		#play_item.setProperty('inputstream.ffmpegdirect.mime_type', 'video/mp4')
		#play_item.setContentLookup(False)

		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
def pla():

	if addon.getSetting('play') == 'default':
		return True
	else:
		return False
	
def Resolve_Neo(url,ref)	:
	#from resolveurl by gujal
	#neohd plugin

	import json
	import codecs
	import time
	from resources.lib.jscrypto import jscrypto
	headers.update({'Referer': ref})
	zz=''
	response = sess.get(url, headers = headers, verify=False)
	cookies=dict(response.cookies)
	html = response.text
	r = re.search(r"var\s*playerConfig\s*=\s*({.*?})", html)  #will be updated
	host = urlparse(url).netloc
	if r:
		data = json.loads(r.group(1))
		ct = data.get('ct', False)
		salt = codecs.decode(data.get('s'), 'hex')
		html2 = jscrypto.decode(ct, 'F1r3b4Ll_GDP~5H', salt)
		html2 = html2[1:-1].replace('\\"', '"').replace('\\\\', '\\').replace('\\\\/','/')
	
		s = re.search(r'apiQuery":"([^"]+)', html2)
		s2 = re.search(r'apiURL":"([^"]+)', html2)
		if s or s2:
			murl = 'https://{0}/'.format(host)
			if s2:
				host = s2.group(1)
				s = re.search(r'kaken\s*=\s*"([^"]+)', html) #kaken = "
				murl = host
			headers.update({'Referer': url, 'X-Requested-With': 'XMLHttpRequest'})
			aurl = '{0}api/?{1}&_={2}'.format(murl, s.group(1), int(time.time() * 1000))
			jd = sess.get(aurl, headers=headers).json()
			urlk = jd.get('sources')[0].get('file').replace(' ', '%20')
			if urlk.startswith('//'):
				urlk = 'https:' + urlk
			link = urlk+'|User-Agent='+UA+'&Referer='+url
	return link

	
def Resolve_ninja(url,ref):
	headers.update({'Referer': ref})
	zz=''
	response = sess.get(url, headers = headers, verify=False)
	cookies=dict(response.cookies)
	html = response.text

	csrf = re.findall('csrf\-token"\s*content\s*=\s*"([^"]+)"',html,re.DOTALL)[0]
	xsrf = cookies.get('XSRF-TOKEN', None)

	headersx = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
		'Accept': 'application/json, text/plain, */*',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': url,
		'X-Requested-With': 'XMLHttpRequest',
		'X-CSRF-TOKEN': csrf,		'Content-Type': 'application/json;charset=utf-8',
		'X-XSRF-TOKEN': xsrf,
		'Origin': 'https://ninjastream.to',
		'DNT': '1',
		'Connection': 'keep-alive',
		'Sec-Fetch-Dest': 'empty',
		'Sec-Fetch-Mode': 'cors',
		'Sec-Fetch-Site': 'same-origin',
	}
	id_ = url.split('/')[-1]

	data = {'id':id_}

	html = sess.post('https://ninjastream.to/api/video/get', cookies=sess.cookies, headers=headersx, json=data).json()
	link = html.get('result', None).get('playlist', None)
	link = link+'|User-Agent='+UA+'&Referer='+url
	return link

def router(paramstring):
	params = dict(urllib_parse.parse_qsl(paramstring))
	if params:    
	
		mode = params.get('mode', None)
	
		if mode == 'listmovies':
			ListMovies(exlink, page)	
		elif mode == 'menu':
			menu(exlink)
		elif mode == 'listsubmenu':
			submenu(exlink)
			
			
		elif mode == 'playvideo':
			PlayVideo(exlink)
		elif mode == 'listserial':
			ListSerial(exlink)
		elif mode == 'listlinks':
			ListLinks(exlink, rys)
			
			
		elif mode == 'listepisodes':
			ListEpisodes(exlink)
		elif mode == 'search':
			query = xbmcgui.Dialog().input(u'Pesquisar: ', type=xbmcgui.INPUT_ALPHANUM)
			if query:   
				k=exlink+'?s='+query.replace(' ','+')
				ListMovies(k, '1')
		elif mode == 'listgenre':
			listgenre(exlink)
			
			
			
		elif mode == 'sett':
			addon.setSetting('play', 'default') if playt == 'proxy' else addon.setSetting('play', 'proxy')
			xbmc.executebuiltin('Container.Refresh')

	else:
		home()
		xbmcplugin.endOfDirectory(addon_handle)    
if __name__ == '__main__':
    router(sys.argv[2][1:])