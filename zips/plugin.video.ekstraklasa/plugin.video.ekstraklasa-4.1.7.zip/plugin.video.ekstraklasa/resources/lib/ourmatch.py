'''
    Our Match Add-on
    Copyright (C) 2016 123456

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import xbmcgui
import dom_parser2
import urllib2
import urllib
import re

TIMEOUT = 10
UA      = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'

def getUrl(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)
    if cookies:
        req.add_header("Cookie", cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()
        response.close()
    except:
        link=''
    return link

def main(name=None):
	out=[]
	c = getUrl('http://ourmatch.net')
	if name:
		r = dom_parser2.parse_dom(c, 'li', {'class': 'header'})
		r = [i for i in r if 'title="%s"' % name in i.content]
		r = dom_parser2.parse_dom(r, 'li', {'class': 'hover-tg'})
		r = dom_parser2.parse_dom(r, 'a')
		for i in r:
			out.append( {'title':i.content,'url':i.attrs['href']})
	else:
		r = dom_parser2.parse_dom(c, 'a', {'class': 'sub'})
		for i in r:
			out.append( {'title':i.attrs['title'],'url':i.attrs['title'],'img':i.attrs['title'].lower()+'.png'} )
	return out

def getMatches(url):
	out=[]
	np=False
	if url == 'search':
		term = xbmcgui.Dialog().input(u'Search Our Match', type=xbmcgui.INPUT_ALPHANUM)
		if term: c  = getUrl('http://ourmatch.net/?s=%s' % term.lower().replace(' ','+'))
		else: quit()
	else:
		c = getUrl(url)
	r = dom_parser2.parse_dom(c, 'div', {'class': 'vidthumb'})
	r = [(dom_parser2.parse_dom(i, 'span', {'class': 'time'}), \
		dom_parser2.parse_dom(i, 'a', req=['href','title']), \
		dom_parser2.parse_dom(i, 'img', req='src')) for i in r if i]
	r = [(re.sub('<.+?>', '', i[0][0].content), i[1][0].attrs['title'], i[1][0].attrs['href'], i[2][0].attrs['src']) for i in r]
	for i in r:
		out.append( {'title':'[COLOR blue]%s[/COLOR]   [COLOR khaki]%s[/COLOR]' % (i[1], i[0]), 'url':i[2],'img':i[3]} )
	try:
		np = re.findall('''<link\s*rel=['"]next['"]\s*href=['"]([^'"]+)''', c)[0]	
	except:
		pass
	return out,np

def getStreams(name,url,iconimage):
	out=[]
	c = getUrl(url)
	try: plot=re.findall('"description" content="(.+?)Full',c)[0].replace('.','[CR]')
	except: plot=''
	r = re.findall("\d+':\s*{embed:'([^}]+)", c)
	for i in r:
		try:
			src = re.findall('''src=['"]([^'"]+)''',i)[0]
			if '.jpg' in src:
				src= re.findall('''a href="(.+?)"''',i)[0]
			if not src.startswith('http'): src = 'https:' + src
			try: lang = re.findall('''lang:['"]([^'"]+)''',i)[0]
			except: lang = 'Unknown'
			try: name = re.findall('''['"]type['"]:['"]([^'"]+)''',i)[0]
			except: name = 'Unknown'
			try: quality = re.findall('''quality:['"]([^'"]+)''',i)[0]
			except: quality = 'Unknown'
			try: source = re.findall('''source:['"]([^'"]+)''',i)[0]
			except: source = 'Unknown'
			out.append( {'title':'%s - %s - %s - %s' % (name, quality, lang, source),'url':src,'img':iconimage,'plot':plot } )
		except: pass
	return out
	
def getUefa(url):
	html=getUrl(url)
	part2=re.findall('"hide">(.+?)<',html)[0]
	link2=urllib.unquote(url)
	link2=re.findall("sharingurl=(.+?)&skin",link2)[0]
	html=getUrl(link2)
	result=re.findall('"vpl-list-item js-vpl-video vpl-active "(.+?)application',html,re.DOTALL)[0].replace('&quot;','"')
	video_url=re.findall('"videoURLhls":"(.+?)"',result)[0]
	videourl=video_url+'?hdnea='+part2	
	return videourl
	
def play(name,url):
	import resolveurl as urlresolver
	if urlresolver.HostedMediaFile(url).valid_url() and 'viuclips' not in url: 
		try:
			url = urlresolver.HostedMediaFile(url).resolve()
		except:
			pass
	else:
		if 'PopUpIframe' in url:
			url=url.replace('/player/PopUpIframe/','/embed/')
		link  = getUrl(url)
		match = re.compile('<source src="(.+?)" type="video/mp4" class="mp4-source"/>').findall(link)
		match_cv = re.compile('hls:"//(.*?)"').findall(link) #.replace('0.m3u8','720p.m3u8')
		for url in match:
			name = name
			url  = 'https:'+url
		if 'media.content-ventures.com' in url:
			url='http://' + match_cv[0]
		if 'oms.matchat.online' in url or 'videostreamlet' in url or 'veuclips' in url or 'viuclips' in url:
			url='http://' + match_cv[0]
		if 'uefa.com' in url:
			url=getUefa(url)
	stream_url = url
	return stream_url
