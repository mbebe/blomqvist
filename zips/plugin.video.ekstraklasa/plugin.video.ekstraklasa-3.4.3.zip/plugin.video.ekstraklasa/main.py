# -*- coding: utf-8 -*-
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import resolveurl as urlresolver
import time
import threading
import resources.lib.ekstraklasa as ekstraklasa
import resources.lib.estadios as estadios

base_url         = sys.argv[0]
addon_handle     = int(sys.argv[1])
args             = urlparse.parse_qs(sys.argv[2][1:])
my_addon         = xbmcaddon.Addon()
addonName        = my_addon.getAddonInfo('name')
PATH             = my_addon.getAddonInfo('path')
DATAPATH         = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES        = PATH+'/resources/'
sys.path.append( os.path.join( RESOURCES, "lib" ) )
FANART           = RESOURCES+'fanart.jpg'
ekstraklasa.GATE = ''

if my_addon.getSetting('bramka') == 'true':
    ekstraklasa.GATE = 'https://www.justproxy.co.uk/index.php?q='

def addLinkItem(name, url, mode, params=1, iconimage='DefaultFolder.png', infoLabels=False, IsPlayable=True,fanart=FANART,contextmenu=1):
    u = buildUrl({'mode': mode, 'foldername': name, 'ex_link' : url, 'params':params})
    liz = xbmcgui.ListItem(name)
    art_keys = ['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconimage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    art['fanart'] = fanart if fanart else art['landscape']
    liz.setArt(art)

    if not infoLabels:
        infoLabels={"title": name}

    liz.setInfo(type="video", infoLabels=infoLabels)

    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')

    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=False,totalItems=contextmenu)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

    return ok

def addDir(name,ex_link=None, params=1, mode='folder',iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART,contextmenu=None):
    url = buildUrl({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'params' : params})
    li = xbmcgui.ListItem(name)

    if infoLabels:
        li.setInfo(type="video", infoLabels=infoLabels)

    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconImage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    art['fanart'] = fanart if fanart else art['landscape']
    li.setArt(art)

    if contextmenu:
        info = contextmenu
        li.addContextMenuItems(info, replaceItems=True)

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        out_dict[k] = v
    return out_dict

def buildUrl(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))

def getLinks(ex_link):
    linksL = ekstraklasa.getVideoLinks(ex_link)
    stream_url = ''

    if len(linksL):
        if len(linksL) > 1:
            lables = [x.get('label') for x in linksL]
            s = xbmcgui.Dialog().select('Dostępne jakości',lables)
        else:
            s = 0
        stream_url=linksL[s].get('url') if s > -1 else ''
        host=linksL[s].get('label') if s > -1 else ''

    if stream_url:
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

def estadios_getLinks(ex_link):
	link = estadios.getVideoLinks(ex_link)
	stream_url = ''
	
	if link:
		if 'extragoals' in link:
			import resources.lib.extragoalsresolver as extragoalsresolver
			stream_url = extragoalsresolver.getVideoUrls(link)
		elif 'onet.tv' in link:
			from resources.lib.ekstraklasatv import getVideos as _getVideos
			src = _getVideos(link)
			if src:
				stream_url = src[0].get('url','')
		elif 'matchat.online' in link:
			import meczykipl
			stream_url=meczykipl.getMatchat(link)		
			
		elif 'streamable.com' in link:
			stream_url=estadios.getStreamable(link)		
		
		else:
			try:
				stream_url = urlresolver.resolve(link)
			except Exception,e:
				stream_url=''
				s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))
	
	if stream_url:
		xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
	else:
		s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Link usunięty')
		xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

def import_mod(s):
    mod = {}
    if   s == 'laczynaspilka' : import laczynaspilka as mod
    elif s == 'ekstraklasatv' : import ekstraklasatv as mod
    elif s == 'meczykipl'     : import meczykipl as mod
    return mod

mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
params = args.get('params',[{}])[0]

if mode is None:
	addDir(name="[COLOR lime][B]Live[/B][/COLOR]",ex_link='',params={'user':'Ekstraklasa','sort':'live','page':'1'}, mode='getVideos',iconImage=RESOURCES+'../icon.png')
	addDir('[COLOR blue]Ekstraklasa.tv[/COLOR]',ex_link='',params={'_service':'ekstraklasatv','_act':'main'}, mode='site',iconImage=RESOURCES+'../icon.png')
	addDir('[COLOR yellow]Tabela Ekstraklasy[/COLOR]',ex_link='',params={}, mode='lechtv_tabela_',iconImage=RESOURCES+'../icon.png')
	addDir('[COLOR yellow]Terminarz[/COLOR]',ex_link='',params={}, mode='lechtv_terminarz_',iconImage=RESOURCES+'../icon.png') 	
	addDir('[COLOR yellow]Lista strzelców[/COLOR]',ex_link='',params={}, mode='lechtv_strzelcy_',iconImage=RESOURCES+'../icon.png') 
	addDir('[COLOR blue]Estadios.pl - Skróty meczów[/COLOR]',ex_link='http://estadios.pl/skroty-meczow',params={}, mode='Estadios_skroty_Liga',iconImage=RESOURCES+'estadios.png')
	addDir('[COLOR blue]Meczyki.pl - Skróty meczów[/COLOR]',ex_link='',params={'_service':'meczykipl','_act':'main'}, mode='site',iconImage=RESOURCES+'meczykipl.png')
	addDir('[COLOR blue]Polsat Sport[/COLOR]',ex_link='',params={}, mode='polsatsport',iconImage=RESOURCES+'polsatsport.png')
	addDir('[COLOR blue]Łączy nas piłka[/COLOR]',ex_link='',params={'_service':'laczynaspilka','_act':'content'}, mode='site',iconImage=RESOURCES+'laczynaspilka.png')
	addLinkItem('[COLOR gold]Opcje[/COLOR]','','Opcje',IsPlayable=False)

elif mode[0] =='site':
	params = eval(params)
	service = params.get('_service')
	act = params.get('_act')
	mod = import_mod(service)
	
	if act == 'main':
		items = mod.getMain()
		for one in items:
			np = one.get('params',{})
			np['_service']=service
			np['_act']='content'
			addDir(one.get('title'), ex_link=one.get('url'), params=np, mode='site',iconImage=one.get('img',RESOURCES+service+'.png'))
	elif act == 'content':
		params['_act']='play'
		items,pagination = mod.getContent(ex_link,**params)
		if pagination[0]:
			pagination[0].update({'_service':service,'_act':'page'})
			addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=pagination[0].get('urlp',''), params=pagination[0], mode='site', IsPlayable=False)
		for one in items:
			addLinkItem(one.get('title',''), one['url'], params=params, mode='site', IsPlayable=True,infoLabels=one, iconimage=one.get('img'))
		if pagination[1]:
			pagination[1].update({'_service':service,'_act':'page'})
			addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=pagination[1].get('urlp',''), params=pagination[1], mode='site', IsPlayable=False)
	elif act == 'page':
		params['_act']='content'
		url = buildUrl({'mode': 'site', 'foldername': fname, 'ex_link' : ex_link,'params':params, })
		xbmc.executebuiltin('XBMC.Container.Update(%s)'% url)
	elif act ==  'play' :
		streams = mod.getVideos(ex_link)
		resolved = False
		if isinstance(streams,list):
			if len(streams)>1:
				label = [x.get('title') for x in streams]
				s = xbmcgui.Dialog().select('Video',label)
				link = streams[s].get('url') if s>-1 else ''
				msg = streams[s].get('msg','')
				resolved = streams[s].get('resolved',False)
			else:
				try:
					link = streams[0].get('url',)
					msg = streams[0].get('msg','')
					resolved = streams[0].get('resolved',False)
				except:
					link = ''
					msg = 'Link not found at\n'+ex_link
		else:
			msg = streams.get('msg','')
			link = streams.get('url','')
		if link:
			if not resolved:
				try:
					
					if 'matchat.online' in link:
						import meczykipl
						stream_url=meczykipl.getMatchat(link)
					elif 'ekstraklasa.tv' in link:                       
						import ekstraklasatv
						stream=ekstraklasatv.getVideos(link)
						stream_url=stream[0].get('url',)
					elif 'polsatsport.pl' in link:                       
						import polsatsport
						stream=polsatsport.getVideos(link)
						stream_url=stream.get('url',)
					else:
						stream_url = urlresolver.resolve(link)
				except Exception,e:
					stream_url=''
					xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))
			else:
				stream_url=link
			if stream_url: xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
			else: xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
		else:
			xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',msg)
			xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

elif mode[0].startswith('polsatsport'):
	import polsatsport as polsatsport
	if '_play_' in mode[0]:
		stream_url = polsatsport.getVideos(ex_link)
		stream_url=stream_url.get('url',False)
		if stream_url: xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
		else: xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
	elif '_folder_' in mode[0]:
		params = eval(params)
		items = polsatsport.getContentDir(**params)
		for one in items:
			addDir(one.get('title'), ex_link=one.get('url'), params={}, mode='polsatsport_content_',iconImage=one.get('img'))
	elif '_content_' in mode[0]:
		items,pagination = polsatsport.getContentVideos(ex_link)
		if pagination[0]: addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url='', params=pagination[0], mode='polsatsport_page_', IsPlayable=False)
		for one in items: addLinkItem(one.get('title',''),  one['url'], mode='polsatsport_play_', IsPlayable=True,infoLabels=one, iconimage=one.get('img'))
		if pagination[1]: addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url='', params=pagination[1], mode='polsatsport_page_', IsPlayable=False)
	elif '_page_' in mode[0]:
		url = buildUrl({'mode': 'polsatsport_content_', 'foldername': '', 'ex_link' : params,'params':'', })
		xbmc.executebuiltin('XBMC.Container.Update(%s)'% url)
	else:
		addDir('Magazyny', ex_link='', params={'type':'magazyny'}, mode='polsatsport_folder_',iconImage=RESOURCES+'polsatsport.png')
		addDir('Dyscypliny', ex_link='', params={'type':'dyscypliny'}, mode='polsatsport_folder_',iconImage=RESOURCES+'polsatsport.png')

elif mode[0].startswith('lechtv'):
	import resources.lib.lechtv as lechtv

	if '_tabela_' in mode[0]:

		items = lechtv.tabela_ekstraklasy()
		for one in items: addLinkItem(one.get('title',''),  '', mode='', infoLabels=one,IsPlayable=False,iconimage=RESOURCES+'ekstraklasa.png',fanart=FANART)
	elif '_strzelcy_' in mode[0]:
		items = lechtv.strzelcy()
		for one in items: addLinkItem(one.get('title',''),  '', mode='', infoLabels=one,IsPlayable=False,iconimage=RESOURCES+'ekstraklasa.png',fanart=FANART)
	elif '_terminarz_' in mode[0]:
		
		items = lechtv.terminarz()
		for one in items: 
			addDir(one.get('title'), ex_link=one.get('url'), params={}, mode='lechtv_content_',iconImage=RESOURCES+'ekstraklasa.png',fanart=FANART)
	
	elif '_page_' in mode[0]:
		url = buildUrl({'mode': 'lechtv_content_', 'foldername': '', 'ex_link' : '','params':params, })
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
				
	elif '_content_' in mode[0]:
		items = lechtv.getContent(ex_link)
		for one in items:
			addLinkItem(one.get('title',''),  '', mode='', IsPlayable=False,infoLabels=one, iconimage=RESOURCES+'ekstraklasa.png')

elif mode[0] =='Estadios_skroty':
    out=estadios.get_skroty_meczow(ex_link)
    for f in out:
        addLinkItem(name=f.get('title'), url=f.get('url'), mode='Estadios_play', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,fanart=f.get('img'))

elif mode[0] =='Estadios_skroty_Liga':
    data = estadios.get_liga()
    if data:
        label = [estadios.unicodePLchar(x[1].strip()) for x in data]
        value = [x[0].strip() for x in data]
        for t,v in zip(label,value):
            addDir(t,ex_link=v,params={}, mode='Estadios_skroty',iconImage='DefaultFolder.png')

elif mode[0] =='Estadios_play':
    estadios_getLinks(ex_link)

elif mode[0] == 'Opcje':
    my_addon.openSettings()

elif mode[0] =='getLinks':
    getLinks(ex_link)

elif mode[0] =='getVideos':
    params = eval(params)
    Litems,pagination = ekstraklasa.getVideos(**params)
    if pagination[0]:
        addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__', params=pagination[0], IsPlayable=False)
    items=len(Litems)
    for f in Litems:
        f['code']= f.get('duration_formatted','')
        f['code']='[COLOR lightgreen]onAir[/COLOR]' if f.get('onair',False) else f['code']
        addLinkItem(name=f.get('title'), url=f.get('id'), mode='getLinks', iconimage=f.get('thumbnail_240_url'), infoLabels=f, IsPlayable=True,contextmenu=items,fanart=f.get('img'))
    if pagination[1]:
        addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__', params=pagination[1], IsPlayable=False)

elif mode[0] == '__page__':
    url = buildUrl({'mode': 'getVideos', 'foldername': '', 'ex_link' : ex_link, 'params': params})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == 'Opcje':
    my_addon.openSettings()

elif mode[0] == 'folder':
    pass

else:
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
xbmcplugin.endOfDirectory(addon_handle)
