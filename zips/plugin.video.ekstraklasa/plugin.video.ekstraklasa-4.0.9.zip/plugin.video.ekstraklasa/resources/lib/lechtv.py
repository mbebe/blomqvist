# -*- coding: utf-8 -*-
import urllib2,urllib,json
import re,os
import urlparse
from CommonFunctions import parseDOM
BASEURLTAB = 'https://sportowefakty.wp.pl/pilka-nozna/ekstraklasa/tabele'
urlstrz="https://ekstraklasa.tv/tabela?tid=v7gpy"
TIMEOUT = 10
UA      = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'
iteppp  = 25

def getUrl(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)

    if cookies:
        req.add_header("Cookie", cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()
        response.close()
    except:
        link=''

    return link

def mecz_replay(url):
	html = getUrl(url).replace("\'",'"')
	out=[]
	links = parseDOM(html,'div', attrs={'class': "container post-body entry-content"})#   "post-outer-container"}) #class="post-outer-container"container post-body entry-content
	for link in links:

		imag=parseDOM(link,'img', ret='src')[0]
		titleres=parseDOM(link,'div', attrs={'class': "snippet-item r-snippetized"})[0].replace('\n','<').replace('<b>','').replace('<strong>','').replace('</b>','').replace('</strong>','').replace('&#160;',' ')  #<div class='snippet-item r-snippetized'>
		title=re.findall('^(.+?)<',titleres)[0]
		href=parseDOM(link,'a', attrs={'class': ".+?"},ret='href')[0]
		out.append( {'title':title,'url':href,'img':imag} )
	try:
		pagin = parseDOM(html,'div', attrs={'class': "blog-pager container"})[0]
		np=parseDOM(pagin,'a', ret='href')[0]
	except:
		np=False
	return out,np

def mecz_replay_getLinks(url,plot,rys):
	html = getUrl(url).replace("\'",'"')
	out=[]	
	results=parseDOM(html,'div', attrs={'class': "post-body entry-content float-container"})[0].replace('</b>','').replace('<b>','').replace('<br />','').replace(':&nbsp;','').replace('\n<a','<a')
	#imag=re.findall('<a href="(.+?)" imag',results)[0]	
	results=results.split('\n')
	for result in results:
		try:
			title,link=re.findall('^(.+?)<a href="(.+?)">',result)[0]
			host= '( '+urlparse.urlsplit(link).netloc+' )'
			if 'blogspot.com' in host:
				pass
			else:
				out.append( {'title':title,'url':link,'img':rys,'plot':plot,'code':host} )
		except:
			pass
	return out
	
def get_d(html):
    d=re.findall('<span id="omg" class="(\d+)" style="display',html)[0]
    return int(d)* 2
	
def a(): 
    return 1
def b(): 

    return a() + 1
def c(): 

    return b() + 1
	
def mecz_replay_getZippy(url):
	html = getUrl(url).replace("\'",'"')
	cz1=urlparse.urlsplit(url).netloc
	czesc=re.findall('''\(['"]dlbutton['"]\).href = ['"](.+?)['"]\+(\(.+?\))\+['"](.+?)['"]''',html)[0]
	d=get_d(html)
	obl=int(eval(czesc[1]))
	video_url='https://'+cz1+czesc[0]+str(obl)+czesc[2]	+'|Referer='+url
	return video_url
	
def tabela_ekstraklasy():
    content= getUrl(BASEURLTAB)
    tabela = re.compile('<tr class="podium-first">(.*?)</tbody>',re.DOTALL).findall(content)
    out = []

    if tabela:	
        pos = re.compile('<td class="align--left"><span>(.*?)</span></td>').findall(tabela[0])
        pts = re.compile('<td class="align--left"><b>(.*?)</b></td>').findall(tabela[0])
        team = re.compile('<td class="align--left"><a href=".*?">(.*?)</a></td>').findall(tabela[0])
        for p,pt,name in zip(pos,pts,team):
            out.append({'title':'%s. [B]%s[/B]'%(p,name),'code':'[COLOR gold][B]%s[/B][/COLOR]'%unicodePLchar(pt)} )

    return out
def strzelcy():
	content= getUrl(urlstrz)
	out = []
	result=parseDOM(content,'div', attrs={'class': "tableWrapper "})[0] 	
	links = parseDOM(result, 'tr', attrs={'id': "row\d+"}) 
	for link in links:  
		bb=parseDOM(link,'span', attrs={'class': "itemName"}) #[0]
		poz=bb[0]
		nazw=bb[1]
		klub=bb[2]
		br=bb[4]	
		out.append({'title':poz+'. [B]'+nazw+' [COLOR lightblue]('+klub+')[/COLOR][/B]','code':'[COLOR gold][B]'+br+'[/B][/COLOR]'} )
	return out
def terminarz():
	out=[	
		{'url':"http://ekstraklasa.tv/tabela?tid=j4np6",'title':"1. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=2bz1f",'title':"2. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=ewjd3",'title':"3. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=zvwe0",'title':"4. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=d9en7",'title':"5. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=3m886",'title':"6. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=bf397",'title':"7. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=lbz65",'title':"8. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=xr9xp",'title':"9. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=z14k4",'title':"10. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=edksn",'title':"11. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=npe4e",'title':"12. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=9qge0",'title':"13. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=py5dm",'title':"14. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=pdzls",'title':"15. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=9g3bm",'title':"16. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=4p9pk",'title':"17. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=57whe",'title':"18. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=st9rr",'title':"19. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=s3p3n",'title':"20. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=zexf1",'title':"21. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=6pzy8",'title':"22. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=t096j",'title':"23. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=y1lc1",'title':"24. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=8fjrk",'title':"25. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=yp628",'title':"26. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=xcrv7",'title':"27. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=hy3ff",'title':"28. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=mpjzs",'title':"29. kolejka"},
		{'url':"http://ekstraklasa.tv/tabela?tid=be7lk",'title':"30. kolejka"},]
	return out
def getContent(url):
	content= getUrl(url)
	result=parseDOM(content,'table', attrs={'class': "otable collapse  tableDetai.*?"})[0]  
	links = parseDOM(result, 'tr', attrs={'id': "row\d+"}) 
	out=[]
	for link in links:
		gosp=parseDOM(link,'td', attrs={'class': "teamAndScorers crest"})[0]
		gosp=parseDOM(gosp,'span', attrs={'class': "itemName"})[0]
		gosc=parseDOM(link,'td', attrs={'class': "teamAndScorers crest"})[1]
		gosc=parseDOM(gosc,'span', attrs={'class': "itemName"})[0]
		try:
			wynik=parseDOM(link,'td', attrs={'class': " score "})[0]
			wc=parseDOM(wynik,'span', attrs={'class': "itemName"}) #[0]
			a=wc[1]
		except:
			date=parseDOM(link,'td', attrs={'class': "excludeExtra matchDate "})[0]  
			wc=parseDOM(date,'span', attrs={'class': "itemName"}) #[0]
		out.append({'title':gosp+' - '+gosc,'code':'[COLOR gold][B]'+wc[0]+' [/B][/COLOR]'+wc[1]} )
	return out
def unicodePLchar(txt):
    s='JiNcZCs7'
    txt = re.sub(s.decode('base64'),'',txt)
    txt = re.sub('&nbsp;','',txt)
    txt = re.sub('&.*;','',txt)
    txt = txt.replace('&nbsp;','')
    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&ndash;','-')
    txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')

    return txt
