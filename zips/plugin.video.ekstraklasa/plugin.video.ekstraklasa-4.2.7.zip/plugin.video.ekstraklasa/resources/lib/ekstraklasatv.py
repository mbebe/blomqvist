# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon
import urllib2,urllib,json
import re,os
import urlparse
import requests
import json

sess = requests.Session()

clsecret = 'PHb7Aw7KZXGMYvgfEz'
clid = "ClubWebClient"
UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0'

addon = xbmcaddon.Addon(id='plugin.video.ekstraklasa')

username = addon.getSetting('username')
password = addon.getSetting('password')
acctoken = addon.getSetting('acctoken')
jakwid = addon.getSetting('jakwid')
jakwid2 = addon.getSetting('jakwid2')


headers = {
    'User-Agent': UA,
    'Accept': 'application/json',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': 'https://www.ekstraklasa.tv/',
    'Content-Type': 'application/json',
    'Authorization': 'Bearer %s'%acctoken,
    'Origin': 'https://www.ekstraklasa.tv',
    'DNT': '1',
}

import threading

class Thread(threading.Thread):
    def __init__(self, target, *args):
        self._target = target
        self._args = args
        self.result = ''
        threading.Thread.__init__(self)
        
    def run(self):
        self.result = self._target(*self._args)


def Login():
	if username and password:
		data={
			"client_id": clid,
			"client_secret": clsecret,
			"grant_type": "password",
			"username": username,
			"password": password,
		}
		response = requests.post("https://core.oz.com/oauth2/token",data=data,headers={"User-Agent": UA},verify=False,).json()
		try:
			access_token = response["access_token"]
			addon.setSetting("acctoken",access_token)
			return True
		except:
			xbmcgui.Dialog().notification('[B]Nieudane logowanie[/B]', 'Sprawdź login i hasło w ustawieniach wtyczki.',xbmcgui.NOTIFICATION_INFO, 6000)
			return False
	xbmcgui.Dialog().notification('[B]Nieudane logowanie[/B]', 'Sprawdź login i hasło w ustawieniach wtyczki.',xbmcgui.NOTIFICATION_INFO, 6000)
	return False

def ListCategory():
	out=[]

	params = (
		('slug', 'ekstraklasa'),
	)
	
	response = requests.get('https://core.oz.com/channels', headers=headers, params=params,verify=False).json()

	nxturl= response['data'][0]['_links']['videosCollectionsV2']
	response = requests.get(nxturl, headers=headers,verify=False).json()

	for data in response['data']:
		img = data['collection']['posterUrl']
		title = data['collection']['name'] 
		count = data['collection']['videoCount']
		tytul = '%s [%s]'%(title,count)

		href = data['collection']['_links']['videosCollectionsV2']
		
		h = '%s|ilosc=%s|powtcol'%(href,count)
		out.append({'title':tytul,'url':h,'img':img,'params':{'type':'','page':0}})    
	return out

def getContent(url,type='skroty',page=1, category=7,**args):
	out=[]
	urlk = url.split('|')[0]
	for x in range(10):
		response = requests.get(urlk+'&page=%d'%x, headers=headers,verify=False)
		if (response.json())['data']:
			co=1
			for data in (response.json())['data']:
				
				if 'collection' in data.keys():
					h = data['collection']['_links']['videosCollectionsV2']
					t = data['collection']['name']
					i = data['collection']['posterUrl']
					ilosc = data['collection']['videoCount']
					h = '%s|ilosc=%s|powtcol'%(h,ilosc)
		
				else:
		
					ilosc=int(re.findall('(\d+)',url.split('|')[1])[-1])
					h  = data['video']['_links']['streamUrl']
					t= data['video']['title']
					i = data['video']['posterUrl']
				out.append({'url':h,'title':t,'img':i,'plot':'','code':''})	
				co+=1
		else:
			break
	np=False
	pp=False
	return out,(pp,np)

	
def crProxy():
	headers = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Connection': 'keep-alive',
		'Referer': 'https://proxyscrape.com/free-proxy-list',
		'Upgrade-Insecure-Requests': '1',
	}
	
	params = (
		('request', 'getproxies'),
		('proxytype', 'http'),
		('timeout', '10000'),
		('country', 'US'),
		('ssl', 'all'),
		('anonymity', 'all'),
	)
	
	response = requests.get('https://api.proxyscrape.com/', headers=headers, params=params).text
	linie = response.splitlines()
	linie = response.splitlines()
	proxies=['%s'%(x) for x in linie]
	return proxies
	
def searchproxy(url):
	stream_url=''

	timeout=15
	dialog  = xbmcgui.DialogProgress()
	dialog.create('Szukam darmowych serwerów proxy ...')
	proxies=crProxy()
	dialog.create('Znalazłem %d serwerów proxy'%len(proxies))
	
	proxies = [Thread(getVideosProxy, url,proxy,timeout) for proxy in proxies ]
	[i.start() for i in proxies]
	dialog.update(0,'Sprawdzam %d serwery ... '%(len(proxies)))
	while any([i.isAlive() for i in proxies]):
		xbmc.sleep(1000)
		done = [t for t in proxies if not t.isAlive()]
		dialog.update(int(1.0*len(done)/len(proxies)*100),'Sprawdzam, negatywnie odpowiedziało: %d, proszę czekać'%(len(done)))
		for t in done:
			stream_url = t.result
			if stream_url:
				break
			else:
				stream_url=''
		if stream_url or dialog.iscanceled():
			break
	dialog.close()
	return {"http": t._args[1], "https": t._args[1]}   

def getVideosProxy(url,proxy,timeout):
	
	try:
		proxy = {"http": proxy, "https": proxy}
		response = sess.get(url, headers=headers,proxies=proxy,verify=False,timeout=timeout).json()
		if response.has_key('message'):
			aa = response['message']
			if 'geo-blocked' in aa:
				return False
		else:
			return True

	except:
		return False
		
def getVideos(url):


	zagr = addon.getSetting('zagrproxy')
	out=[]
	response = requests.get(url, headers=headers,verify=False).json()
	if 'message' in response.keys():
		aa = response['message']
		if 'geo-blocked' in aa or 'geo blocked' in aa:
			if zagr=='true':
				proxy=searchproxy(url)
				response = sess.get(url, headers=headers,proxies=proxy,verify=False,timeout=30).json()
			else:

				xbmcgui.Dialog().notification('[B]Error[/B]', aa,xbmcgui.NOTIFICATION_INFO, 9000)
				return out
			
	streamData=response['data']	
	
	url = streamData["url"]
	#cookie = streamData["cookieName"]
	#token = streamData["token"]
	#ab=('%s=%s')%(cookie,token)
	#if 'AUTO' not in jakwid:
	listax={"480x270":"150","640x360":"300","768x432":"600","960x540":"1200","1280x720":"2200","1920x1080":"8200"}
	listax2={"360p":"/275/","432p":"/450/","540p":"/900/","720p":"1800","1080p":"3600"}
	listax3={"360p":"/350/","432p":"/700/","540p":"/1400/","720p":"2800","1080p":"5600"}
	if 'AUTO' not in jakwid:
		
		playlist = sess.get(url, headers=headers,verify=False).text
		playlist = playlist.replace('\n/content','/content')

		co2 = '%s'%jakwid.lower()
		co=listax2[co2]
		if not playlist.find(co)>0:
			co=listax3[co2]
		if playlist.find(co)>0:
			co = co
		else:
			co = '%s'%jakwid2.lower()
			co=listax[co]
		linie = playlist.splitlines()
		for linia in linie:
			if co in linia:
				try:
					if '/live/' in linia:# and 'cdn=beta' in linia:
						url1=linia
					else:
						url1=re.findall('(/co.+?)$',linia)[0]
					url='https://playlist.oz.com%s'%url1
					break
				except:
					continue
			else:
				continue
	pth=url+'|User-Agent='+urllib.quote(UA)#+'&Cookie='+ab

	out.append({'url':pth,'msg':'','resolved':True})
	return out

	
def getMain():
	logged = Login()
	out=[]
	if logged:
		out = ListCategory()
	return out

def unicodePLchar(txt):
    s='JiNcZCs7'
    txt = re.sub(s.decode('base64'),'',txt)
    txt = re.sub('&quot;','"',txt)
    txt = re.sub('&.*;','',txt)
    txt = txt.replace('&nbsp;','')
    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&ndash;','-')
    txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')
    return txt
