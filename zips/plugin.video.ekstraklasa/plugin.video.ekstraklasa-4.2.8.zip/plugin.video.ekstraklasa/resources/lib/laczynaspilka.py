# -*- coding: utf-8 -*-
#import urllib2,urllib,json
import re,os

import requests
BASEURL = "https://www.laczynaspilka.pl/lista-filmow,1.html"
TIMEOUT = 10
UA      = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'


def loguj(usrlnp, pwdlnp):
	return True
	
def GetCategory(url):
	import json
	headers = {
    'Host': 'www.laczynaspilka.pl',

    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36',

    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',

    'Accept-Language': 'en-US,en;q=0.9',}

	response = requests.get(url, headers=headers, verify=False).json()
	items = response["content"]["content"]["main"]["items"]
	out=[]
	for item in items:
		tytul = item["headline"]
		url = url#+'|'+tytul
		out.append({'url':url,'title':tytul,'img':'','code':''})
	return out
	
def getSubCateg(url,tyt):

	import json
	headers = {
    'Host': 'www.laczynaspilka.pl',

    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36',

    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',

    'Accept-Language': 'en-US,en;q=0.9',}

	response = requests.get('https://www.laczynaspilka.pl/biblioteka/api/biblioteka/multimedia/index/wideoteka', headers=headers, verify=False).json()
	items = response["content"]["content"]["main"]["items"]
	out=[]

	for item in items:
		if tyt.decode('utf-8') in item["headline"]:
			items2 = item["items"]
			for item2 in items2:
				tytul = item2["title"]
				url = item2['url']
				url = 'https://www.laczynaspilka.pl/biblioteka/api'+url
				img = item2["image"]["urls"]["article_teaser"]
				
				out.append({'url':url,'title':tytul,'img':img,'code':''})
	return out	

def getMaterial(url,tyt):

	import json
	headers = {
    'Host': 'www.laczynaspilka.pl',

    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36',

    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',

    'Accept-Language': 'en-US,en;q=0.9',}


	response = requests.get(url, headers=headers, verify=False).json()
	items = response["content"]["content"]["main"]["items"]
	out=[]
	for item in items:
		if tyt.decode('utf-8') in item["headline"]:
			items2 = item["playlist"]["items"]["teasers"]
			for item2 in items2:
				tytul = item2["title"]
				mediadata = item2["media"]
				img = mediadata["thumbnail"]["urls"]["player_cover"]
				img = img.replace(' ', '%20')
				video_id = mediadata["video_id"]
				filename= mediadata["filename"]
				distribution_platform = mediadata["distribution_platform"]
				url = 'https://cdn.laczynaspilka.pl/pz/{}/{}/{}'.format(distribution_platform, video_id, filename)

				out.append({'url':url,'title':tytul,'img':img,'code':''})

	return out	
	
	
	
	
def getUrl(url,data=None,cookies=None):
	
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)

    if cookies:
        req.add_header("Cookie", cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()
        response.close()
    except:
        link = ''

    return link

def getContent(url,**kwargs):
    if not url: url = BASEURL
    content = getUrl(url)
    out = []
    tds = re.compile('<a (href="//www.youtube.com.*?)</a>',re.DOTALL).findall(content)
    nextPage = False
    prevPage = False

    for td in tds:
        href = re.compile('href="(.*?)"').findall(td)
        title = re.compile('data-title="(.*?)"').findall(td)
        date = re.compile('data-date="(.*?)"').findall(td)
        img=re.compile('<img src="(.*?)"').findall(td)
        if href and title:
            h = 'http:'+href[0]
            t = title[0].strip()
            i = img[0] if img else ''
            code = date[0] if date else ''
            out.append({'url':h,'title':t,'img':i,'code':code})

    if out:
        nextPage = re.compile('<a href="(http.*?)">Następna').findall(content)
        nextPage = {'urlp': nextPage[0]} if nextPage else False
        prevPage = re.compile('<a href="(http.*?)"> &laquo; Poprzednia').findall(content)
        prevPage = {'urlp': prevPage[0]} if prevPage else False

    return (out,(prevPage,nextPage))

def getVideos(ex_link):
    return {'msg':'','url':ex_link}
