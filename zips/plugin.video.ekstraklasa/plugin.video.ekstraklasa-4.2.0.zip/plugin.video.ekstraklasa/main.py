# -*- coding: utf-8 -*-
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import resolveurl as urlresolver
import time
import threading
import resources.lib.ekstraklasa as ekstraklasa
import resources.lib.estadios as estadios
import resources.lib.ourmatch as ourmatch
import resources.lib.javafooty as javafooty
import requests
sess=requests.Session()

kukz=''
base_url         = sys.argv[0]
addon_handle     = int(sys.argv[1])
args             = urlparse.parse_qs(sys.argv[2][1:])
my_addon         = xbmcaddon.Addon()
addonName        = my_addon.getAddonInfo('name')
PATH             = my_addon.getAddonInfo('path')
DATAPATH         = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES        = PATH+'/resources/'
sys.path.append( os.path.join( RESOURCES, "lib" ) )
FANART           = RESOURCES+'fanart.jpg'
FANART2= RESOURCES+'fanart2.jpg'
ekstraklasa.GATE = ''
UA='Mozilla/5.0 (Linux; Android 7.0; PLUS Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36'

if my_addon.getSetting('bramka') == 'true':
    ekstraklasa.GATE = 'https://www.justproxy.co.uk/index.php?q='

def addLinkItem(name, url, mode, params=1, iconimage='DefaultFolder.png', infoLabels=False, IsPlayable=True, fanart=FANART,contextmenu=1):
	u = buildUrl({'mode': mode, 'foldername': name, 'ex_link' : url, 'params':params})
	liz = xbmcgui.ListItem(name)
	art_keys = ['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
	art = dict(zip(art_keys,[iconimage for x in art_keys]))
	art['landscape'] = fanart if fanart else art['landscape']
	art['fanart'] = fanart if fanart else art['landscape']
	liz.setArt(art)
	
	if not infoLabels:
		infoLabels={"title": name}
	
	liz.setInfo(type="video", infoLabels=infoLabels)
	
	if IsPlayable:
		liz.setProperty('IsPlayable', 'true')
	
	ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=False,totalItems=contextmenu)
	return ok

def addDir(name,ex_link=None, params=1, mode='folder',iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART,contextmenu=None,page=1):
    url = buildUrl({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'params' : params,'iconImage':iconImage,'mbebe':kukz,'page':page})
    li = xbmcgui.ListItem(name)

    if infoLabels:
        li.setInfo(type="video", infoLabels=infoLabels)

    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconImage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    art['fanart'] = fanart if fanart else art['landscape']
    li.setArt(art)

    if contextmenu:
        info = contextmenu
        li.addContextMenuItems(info, replaceItems=True)
		
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)

def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        out_dict[k] = v
    return out_dict

def buildUrl(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))

def getLinks(ex_link):
	linksL = ekstraklasa.getVideoLinks(ex_link)
	stream_url = ''
	
	if len(linksL):
		if len(linksL) > 1:
			lables = [x.get('label') for x in linksL]
			s = xbmcgui.Dialog().select('Dostępne jakości',lables)
		else:
			s = 0
		stream_url=linksL[s].get('url') if s > -1 else ''
		host=linksL[s].get('label') if s > -1 else ''
	
	if stream_url:
		xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
	else:
		xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

def estadios_getLinks(ex_link):
	link = estadios.getVideoLinks(ex_link)
	stream_url = ''
	
	if link:
		if 'extragoals' in link:
			import resources.lib.extragoalsresolver as extragoalsresolver
			stream_url = extragoalsresolver.getVideoUrls(link)
		elif 'onet.tv' in link:
			from resources.lib.ekstraklasatv import getVideos as _getVideos
			src = _getVideos(link)
			if src:
				stream_url = src[0].get('url','')
		elif 'matchat.online' in link:
			import meczykipl
			stream_url=meczykipl.getMatchat(link)	
		elif 'streamable' in link:
			stream_url= estadios.getStreamable(link)
		elif 'upclips' in link:      
			import meczykipl
			stream_url=meczykipl.getUpclips(link)	
		else:
			try:
				stream_url = urlresolver.resolve(link)
			except Exception,e:
				stream_url=''
				s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))
	
	if stream_url:
		xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
	else:
		s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Link usunięty')
		xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

def import_mod(s):
    mod = {}
    if   s == 'laczynaspilka' : import laczynaspilka as mod
    elif s == 'ekstraklasatv' : import ekstraklasatv as mod
    elif s == 'meczykipl'     : import meczykipl as mod
    return mod

mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
rys = args.get('iconImage',[''])[0]
params = args.get('params',[{}])[0]
page = args.get('page',[1])[0]

if mode is None:
	addDir('[COLOR blue]Ekstraklasa.tv[/COLOR]',ex_link='',params={}, mode='ektv',iconImage=RESOURCES+'EkstraklasaTV.png',fanart=FANART2)
	addDir('[COLOR blue]Polsat Sport[/COLOR]',ex_link='',params={}, mode='polsatsport',iconImage=RESOURCES+'polsatsport.png',fanart=FANART2)	
	addDir('[COLOR blue]Łączy nas piłka[/COLOR]',ex_link='',params={'_service':'laczynaspilka','_act':'content'}, mode='site',iconImage=RESOURCES+'laczynaspilka.png',fanart=FANART2)	
	addDir('[COLOR blue]Mecz Replay[/COLOR]',ex_link='http://meczreplay.blogspot.com/search',params={}, mode='meczreplay_main',iconImage=RESOURCES+'meczreplay.png',fanart=FANART2)	
	addDir('[COLOR yellow]Skróty meczów[/COLOR]',ex_link='',params={}, mode='skroty',iconImage=RESOURCES+'skroty.png',fanart=FANART2)
	addDir('[COLOR yellow]Tabele, terminarze, strzelcy[/COLOR]',ex_link='',params={}, mode='listtabterm',iconImage=RESOURCES+'tabela.png',fanart=FANART2)	
	addLinkItem('[COLOR gold]Opcje[/COLOR]','','Opcje',IsPlayable=False,fanart=FANART2,iconimage=RESOURCES+'ustaw.png',)
	xbmcplugin.endOfDirectory(addon_handle)
	
elif mode[0] =='site':
	params = eval(params)
	service = params.get('_service')
	act = params.get('_act')
	mod = import_mod(service)

	if act == 'main':
		items = mod.getMain()
		if len(items)>0:
			for one in items:
				if 'meczyki' in service or 'laczynaspilka' in service:
					fn=FANART2
					imagm=RESOURCES+one.get('img').replace('włochy','wlochy')+'.png'
				elif 'ekstraklasatv' in service:
					fn=FANART
					imagm=one.get('img')
					#imagm=RESOURCES+'../icon.png'				
				else:
					fn=FANART
					imagm=one.get('img',RESOURCES+service+'.png')
				np = one.get('params',{})
				np['_service']=service
				np['_act']='content'
				addDir(one.get('title'), ex_link=one.get('url'), params=np, mode='site',iconImage=imagm,fanart=fn)
			xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
			xbmcplugin.endOfDirectory(addon_handle)
		
	elif act == 'content':
		params['_act']='play'
		if 'meczyki' in service or 'laczynaspilka' in service:
			fn=FANART2
		else:
			fn=FANART
		items,pagination = mod.getContent(ex_link,**params)
		if pagination[0]:
			pagination[0].update({'_service':service,'_act':'page'})
			addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=pagination[0].get('urlp',''), params=pagination[0], mode='site', IsPlayable=False, iconimage=RESOURCES+'prevpage.png',fanart=fn)
		for one in items:
			if not one['url']:
				one['url']=''
			if 'powtcol' in one['url']:
				np = one.get('params',{})
				np['_service']=service
				np['_act']='content'
				dalej = one.get('url')
				imagm=one.get('img')
				addDir(one.get('title'), ex_link=dalej, params=np, mode='site',iconImage=imagm,fanart=fn)
			else:
				addLinkItem(one.get('title',''), one['url'], params=params, mode='site', IsPlayable=True,infoLabels=one, iconimage=one.get('img'),fanart=fn)
		if pagination[1]:
			pagination[1].update({'_service':service,'_act':'page'})
			addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=pagination[1].get('urlp',''), params=pagination[1], mode='site', IsPlayable=False,iconimage=RESOURCES+'nextpage.png',fanart=fn)
		xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
		xbmcplugin.setContent(int(sys.argv[1]), 'files')		
		xbmcplugin.endOfDirectory(addon_handle)
	elif act == 'page':
		params['_act']='content'
		url = buildUrl({'mode': 'site', 'foldername': fname, 'ex_link' : ex_link,'params':params, })
		xbmc.executebuiltin('XBMC.Container.Update(%s)'% url)
		xbmcplugin.endOfDirectory(addon_handle)
	elif act ==  'play' :
		if ex_link:
			streams = mod.getVideos(ex_link)
			resolved = False
			if isinstance(streams,list):
				if len(streams)>1:
					label = [x.get('title') for x in streams]
					s = xbmcgui.Dialog().select('Video',label)
					link = streams[s].get('url') if s>-1 else ''#quit()
					msg = streams[s].get('msg','')
					resolved = streams[s].get('resolved',False)
				else:
					try:
						link = streams[0].get('url',)
						msg = streams[0].get('msg','')
						resolved = streams[0].get('resolved',False)
					except:
						link = ''
						msg = 'Link not found at\n'+ex_link
			else:
				msg = streams.get('msg','')
				link = streams.get('url','')
			if link:
				if not resolved:
					try:
						if 'matchat.online' in link:
							import meczykipl
							stream_url=meczykipl.getMatchat(link)
							
						elif 'ekstraklasa.org' in link: 	
							import meczykipl
							stream_url=meczykipl.getEkstrOrg(link)
						elif 'ekstraklasa.tv' in link:                       
							import ekstraklasatv
							stream=ekstraklasatv.getVideos(link)
							stream_url=stream[0].get('url',)
						elif 'polsatsport.pl' in link:                       
							import polsatsport
							stream=polsatsport.getVideos(link)
							stream_url=stream.get('url',)
						elif 'videostreamlet' in link:      
							import meczykipl
							stream_url=meczykipl.getStreamlet(link)	
						elif 'veuclips' in link:      
							import meczykipl
							stream_url=meczykipl.getStreamlet(link)							
						elif 'viuclips' in link:      
							import meczykipl
							stream_url=meczykipl.getStreamlet(link)	
							
						elif 'upclips' in link:      
							import meczykipl
							stream_url=meczykipl.getUpclips(link)	
							
						else:
							
							stream_url = urlresolver.resolve(link)
					except Exception,e:
						stream_url=''
						xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))
				else:
					stream_url=link
				if stream_url: xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
				else: xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
			else:
				xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
		else:
			xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Brak linku... ',xbmcgui.NOTIFICATION_INFO, 6000)
			#xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
elif mode[0].startswith('polsatsport'):
	import polsatsport as polsatsport
	if '_play_' in mode[0]:
		stream_url = polsatsport.getVideos(ex_link)
		stream_url=stream_url.get('url',False)
		if stream_url: xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
		else: xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
	elif '_folder_' in mode[0]:
		params = eval(params)
		items = polsatsport.getContentDir(**params)
		for one in items:
			addDir(one.get('title'), ex_link=one.get('url'), params={}, mode='polsatsport_content_',iconImage=one.get('img'),fanart=FANART2)	
		xbmcplugin.endOfDirectory(addon_handle)
	elif '_content_' in mode[0]:
		items,pagination = polsatsport.getContentVideos(ex_link)
		if pagination[0]: addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url='', params=pagination[0], mode='polsatsport_page_', IsPlayable=False,iconimage=RESOURCES+'prevpage.png',fanart=FANART2)	
		for one in items: addLinkItem(one.get('title',''),  one['url'], mode='polsatsport_play_', IsPlayable=True,infoLabels=one, iconimage=one.get('img'),fanart=FANART2)	
		if pagination[1]: addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url='', params=pagination[1], mode='polsatsport_page_', IsPlayable=False,iconimage=RESOURCES+'nextpage.png',fanart=FANART2)	
		xbmcplugin.endOfDirectory(addon_handle)
	elif '_page_' in mode[0]:
		url = buildUrl({'mode': 'polsatsport_content_', 'foldername': '', 'ex_link' : params,'params':'', })
		xbmc.executebuiltin('XBMC.Container.Update(%s)'% url)
		xbmcplugin.endOfDirectory(addon_handle)		
	else:
		addDir('Magazyny', ex_link='', params={'type':'magazyny'}, mode='polsatsport_folder_',iconImage=RESOURCES+'polsatsport.png',fanart=FANART2)
		addDir('Dyscypliny', ex_link='', params={'type':'dyscypliny'}, mode='polsatsport_folder_',iconImage=RESOURCES+'polsatsport.png',fanart=FANART2)
		xbmcplugin.endOfDirectory(addon_handle)
elif mode[0].startswith('lechtv'):
	import resources.lib.lechtv as lechtv

	if '_tabela_' in mode[0]:

		items = lechtv.tabela_ekstraklasy()
		for one in items: addLinkItem(one.get('title',''),  '', mode='', infoLabels=one,IsPlayable=False,iconimage=RESOURCES+'ekstraklasa.png',fanart=FANART)
		xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
		xbmcplugin.setContent(int(sys.argv[1]), 'files')
	elif '_strzelcy_' in mode[0]:
		items = lechtv.strzelcy()
		for one in items: 
			addLinkItem(one.get('title',''),  '', mode='', infoLabels=one,IsPlayable=False,iconimage=RESOURCES+'ekstraklasa.png',fanart=FANART)
		xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")	
		xbmcplugin.setContent(int(sys.argv[1]), 'files')	
	elif '_terminarz_' in mode[0]:		
		items = lechtv.terminarz()
		for one in items: 
			addDir(one.get('title'), ex_link=one.get('url'), params={}, mode='lechtv_content_',iconImage=RESOURCES+'ekstraklasa.png',fanart=FANART)
		xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	elif '_page_' in mode[0]:
		url = buildUrl({'mode': 'lechtv_content_', 'foldername': '', 'ex_link' : '','params':params, })
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
				
	elif '_content_' in mode[0]:
		items = lechtv.getContent(ex_link)
		for one in items:
			addLinkItem(one.get('title',''),  '', mode='', IsPlayable=False,infoLabels=one, iconimage=RESOURCES+'ekstraklasa.png')
		xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
		xbmcplugin.setContent(int(sys.argv[1]), 'files')
	xbmcplugin.endOfDirectory(addon_handle)			

elif mode[0] =='meczreplay_main':	
	addDir('[COLOR yellow]Strona główna[/COLOR]',ex_link='http://meczreplay.blogspot.com/search',params={}, mode='meczreplay',iconImage=RESOURCES+'meczreplay.png',fanart=FANART2)
	addDir('[COLOR yellow]Szukaj[/COLOR]',ex_link='http://meczreplay.blogspot.com/search?q=',params={}, mode='meczreplay_search',iconImage=RESOURCES+'search.png',fanart=FANART2)
	addDir('   Ekstraklasa',ex_link='http://meczreplay.blogspot.com/search/label/ekstraklasa',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)	
	addDir('   Ekstraklasa po godzinach',ex_link='http://meczreplay.blogspot.com/search/label/ekstraklasa%20po%20godzinach',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)
	addDir('   Cafe Futbol',ex_link='http://meczreplay.blogspot.com/search/label/Cafe%20Futbol',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)
	addDir('   Liga Mistrzów',ex_link='http://meczreplay.blogspot.com/search/label/liga%20mistrz%C3%B3w',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)
	addDir('   Liga Europy',ex_link='http://meczreplay.blogspot.com/search/label/liga%20europy',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)
	addDir('   Liga Narodów',ex_link='http://meczreplay.blogspot.com/search/label/liga%20narod%C3%B3w',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)
	addDir('   Mundial 2018',ex_link='http://meczreplay.blogspot.com/search/label/mundial%202018',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)
	addDir('   Mecz',ex_link='http://meczreplay.blogspot.com/search/label/mecz',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)
	addDir('   Bundesliga',ex_link='http://meczreplay.blogspot.com/search/label/bundesliga',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)
	addDir('   Ligue 1',ex_link='http://meczreplay.blogspot.com/search/label/ligue1',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)
	addDir('   Premier League',ex_link='http://meczreplay.blogspot.com/search/label/premier%20league',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)
	addDir('   Serie A',ex_link='http://meczreplay.blogspot.com/search/label/seriea',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)
	addDir('   F1',ex_link='http://meczreplay.blogspot.com/search/label/F1',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)
	addDir('   Eleven F1',ex_link='http://meczreplay.blogspot.com/search/label/Eleven%20F1',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)
	addDir('   Boks',ex_link='http://meczreplay.blogspot.com/search/label/boks',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)	
	addDir('   MMA',ex_link='http://meczreplay.blogspot.com/search/label/mma',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)		
	addDir('   UFC',ex_link='http://meczreplay.blogspot.com/search/label/ufc',params={}, mode='meczreplay',iconImage=RESOURCES+'empty.png',fanart=FANART2)	
	xbmcplugin.endOfDirectory(addon_handle)		
	
elif mode[0] =='meczreplay_search':		
	query = xbmcgui.Dialog().input(u'Search... ', type=xbmcgui.INPUT_ALPHANUM,)
	if query:  	
		query=query.replace('+','%2B').replace(' ','+')
		import resources.lib.lechtv as lechtv
		itemz,np=lechtv.mecz_replay(ex_link+query)
		if itemz:
			for f in itemz:
				addDir(f.get('title'),f.get('url'), params={}, mode='meczreplay_getLinks',iconImage=f.get('img'),fanart=FANART2)			
			if np:
				np=np.replace('&amp;','&')
				addDir('[COLOR blue]>> następna strona >>[/COLOR]',ex_link=np,params={}, mode='meczreplay',iconImage=RESOURCES+'nextpage.png',fanart=FANART2)	
			xbmcplugin.endOfDirectory(addon_handle)	
			
		else:
			xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak wyników')
			quit()

elif mode[0] =='meczreplay':
	import resources.lib.lechtv as lechtv
	itemz,np=lechtv.mecz_replay(ex_link)
	for f in itemz:
		addDir(f.get('title'),f.get('url'), params={}, mode='meczreplay_getLinks',iconImage=f.get('img'),fanart=FANART2)	
	if np:
		np=np.replace('&amp;','&')
		addDir('[COLOR blue]>> następna strona >>[/COLOR]',ex_link=np,params={}, mode='meczreplay',iconImage=RESOURCES+'nextpage.png',fanart=FANART2)	
	xbmcplugin.endOfDirectory(addon_handle)	

elif mode[0] =='meczreplay_getLinks':
	import resources.lib.lechtv as lechtv
	itemz=lechtv.mecz_replay_getLinks(ex_link,fname,rys)
	
	for one in itemz:	
		tyt=one.get('title','')
		imag=one.get('img','')
		href=one.get('url','')		
		addLinkItem(name=tyt, url=href, mode='meczreplay_play', iconimage=imag, infoLabels=one, IsPlayable=True,fanart=FANART2)	
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%P, %G")	
	xbmcplugin.setContent(int(sys.argv[1]), 'files')	
	xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] =='meczreplay_play':	
	if 'zippyshare' in ex_link:
		import resources.lib.lechtv as lechtv
		stream_url=lechtv.mecz_replay_getZippy(ex_link)	
	else:
		try:
			stream_url = urlresolver.resolve(ex_link)
		except Exception,e:
			stream_url=''
			xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))
	
	if stream_url:
		xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
	else:
		quit()
	
elif mode[0] =='skroty':	
	addDir('[COLOR yellow]Estadios.pl[/COLOR]',ex_link='http://estadios.pl/skroty-meczow',params={}, mode='Estadios_skroty_Liga',iconImage=RESOURCES+'estadios.png',fanart=FANART2)
	addDir('[COLOR yellow]Meczyki.pl[/COLOR]',ex_link='',params={'_service':'meczykipl','_act':'main'}, mode='site',iconImage=RESOURCES+'meczykipl.png',fanart=FANART2)
	addDir('[COLOR yellow]OurMatch[/COLOR]',ex_link='',params={}, mode='our_match_main',iconImage=RESOURCES+'ourmatch.png',fanart=FANART2)		
	addDir('[COLOR yellow]Javafooty[/COLOR]',ex_link='https://www.javafooty.com/',params={}, mode='foothighlights',iconImage=RESOURCES+'javafooty.png',fanart=FANART2)	
	xbmcplugin.endOfDirectory(addon_handle)
	
elif mode[0] =='foothighlights':

	addDir('[COLOR orange][B]Search (club/team)[/COLOR][/B]','https://www.javafooty.com/', params={}, mode='javafooty_searchhigh',iconImage=RESOURCES+'search.png',fanart=FANART2)
	addDir('Europe','https://www.javafooty.com/', params={}, mode='javafooty_getcomp',iconImage=RESOURCES+'uefa.png',fanart=FANART2)	
	addDir('South America','https://www.javafooty.com/', params={}, mode='javafooty_getcomp',iconImage=RESOURCES+'conmebol.png',fanart=FANART2)	
	addDir('North & Central America','https://www.javafooty.com/', params={}, mode='javafooty_getcomp',iconImage=RESOURCES+'concacaf.png',fanart=FANART2)	
	addDir('Asia','https://www.javafooty.com/', params={}, mode='javafooty_getcomp',iconImage=RESOURCES+'afc.png',fanart=FANART2)	
	addDir('Africa','https://www.javafooty.com/', params={}, mode='javafooty_getcomp',iconImage=RESOURCES+'caf.png',fanart=FANART2)	
	addDir('Oceania','https://www.javafooty.com/', params={}, mode='javafooty_getcomp',iconImage=RESOURCES+'ofc.png',fanart=FANART2)	
	addDir('World','https://www.javafooty.com/', params={}, mode='javafooty_getcomp',iconImage=RESOURCES+'fifa.png',fanart=FANART2)	
	xbmcplugin.endOfDirectory(addon_handle)	

elif mode[0] =='javafooty_getcomp':	

	links = javafooty.getCompetition(fname)
	for f in links:
		ikonka = 'https://raw.githubusercontent.com/Proximus2000/mb-support/master/flags/%s.png'%(urllib.quote(f.get('title').lower()))
		addDir(f.get('title'),f.get('href'), params={}, mode='sportpieces',iconImage=ikonka,fanart=FANART2)	
	xbmcplugin.endOfDirectory(addon_handle)	
	
elif mode[0] =='sportpieces':	
	page = int(page) if page else 1	
	links,pagination = javafooty.getSportpieces(ex_link,page)
	if links:
		for f in links:
			addDir(f.get('title'),f.get('href'), mode='javafooty_getLinks2',iconImage=rys,fanart=FANART2)	
		if pagination[1]:	
			addDir('[COLOR blue]>> next page >>[/COLOR]',ex_link, params={}, mode='sportpieces',iconImage=RESOURCES+'nextpage.png',fanart=FANART2,page=pagination[1])	
		xbmcplugin.endOfDirectory(addon_handle)
	else:
		xbmcgui.Dialog().notification('Info,', 'Brak materiałów do wyświetlenia', RESOURCES+'javafooty.png', 6000)

	
elif mode[0] =='javafooty_searchhigh':	
	query = xbmcgui.Dialog().input(u'Search... ', type=xbmcgui.INPUT_ALPHANUM,)
	if query:  	
		out=javafooty.ListsearchhighNew(query)
		for one in out:	
			tyt=one.get('title','')
			imag=one.get('img','')
			href=one.get('href','')	
			addDir(one.get('title'),one.get('href'), mode='javafooty_getLinks2',iconImage=one.get('img',''),fanart=FANART2,infoLabels=one)
			#addLinkItem(name=tyt, url=href, mode='javafooty_getLinks', iconimage=imag, infoLabels=one, IsPlayable=True,fanart=FANART2)
		xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%P, %G")
		xbmcplugin.setContent(addon_handle, 'videos')	
		xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] =='javafooty_searchdate':	
	query = xbmcgui.Dialog().input(u'Enter date', type=xbmcgui.INPUT_DATE)	
	if query:			
		out=javafooty.Listdate(ex_link,query)
		for one in out:	
			tyt=one.get('title','')
			imag=one.get('img','')
			href=one.get('url','')	
			addLinkItem(name=tyt, url=href, mode='javafooty_getLinks', iconimage=imag, infoLabels=one, IsPlayable=True,fanart=FANART2)
		xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%P, %G")
		xbmcplugin.setContent(addon_handle, 'videos')	
		xbmcplugin.endOfDirectory(addon_handle)		

	
elif mode[0] == 'javafooty_getLinks2':		
	out,outw=javafooty.getLinks(ex_link,fname)
	if out:	
		for one in out:	
			tyt=one.get('title','')
			href=one.get('url','')	
			addLinkItem(name=tyt, url=href, mode='javafooty_getLinks', iconimage=rys, infoLabels=one, IsPlayable=True,fanart=FANART2)
		xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%P, %G")
		xbmcplugin.setContent(addon_handle, 'videos')	
		xbmcplugin.endOfDirectory(addon_handle)	
elif mode[0] == 'javafooty_getLinks':
	linkstr = ex_link
	linkstr = 'http:'+linkstr if linkstr.startswith('//') else linkstr
	if linkstr:
		nextlink=javafooty.getUrlReq(linkstr)	
		vido_url=''
		if 'emb.aplayer1.me/' in linkstr:
			vido_url=re.findall("file:.+?'(htt.+?),",nextlink)[0]
		elif 'emb.aplayer2.me/' in linkstr:
			vido_url=re.findall("file:.+?'(htt.+?),",nextlink)[0]
		elif 'mycujoo' in linkstr:
			vido_url=re.findall('"file".+?"(ht.+?m3u.+?)"',nextlink)[0]
			vido_url=vido_url.split('master')[0]+'480p/playlist.m3u8'
			vido_url+='|User-Agent='+UA+'&Referer='+linkstr
		elif 'matchat' in linkstr:
			vido_url=javafooty.getMatchat(linkstr)
		elif 'videostreamlet.net' in linkstr:
			vido_url=javafooty.getStreamlet(linkstr)
		elif 'veuclips' in linkstr:
			vido_url=javafooty.getStreamlet(linkstr)			
		elif 'streamable' in linkstr:
			try:
				vido_url=re.findall('"url": *"(.+?)"',nextlink)[0].replace('&amp;','&')
			except:
				vido_url=''
			if vido_url.startswith('//'):
				vido_url='https:'+vido_url
		elif 'streamja.com' in linkstr:
			vido_url=javafooty.getStreamja(linkstr)
	
		elif 'upclips' in linkstr:      
			import meczykipl
			vido_url=meczykipl.getUpclips(linkstr)
		else:
			try:
				vido_url = urlresolver.resolve(linkstr)
			except Exception,e:
				xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))
		if vido_url:
	
			li = xbmcgui.ListItem(offscreen=True)
			li.setPath(vido_url)
	
			xbmcplugin.setResolvedUrl(addon_handle, True, li)
	
		else:
			xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',"Can't resolve or no links")
			xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))	
	else:
		xbmcgui.Dialog().notification('[B][COLOR red]Problem[/COLOR][/B]', "Can't resolve or no link",RESOURCES+'javafooty.png', 6000)
		
elif mode[0] =='Estadios_skroty':
	mainesturl='https://estadios.pl/'
	sess.headers.update({'User-Agent': UA})
	kukz = args.get('mbebe',[{}])[0]
	if kukz:
		cookies={'PHPSESSID': kukz}
		html=sess.get(ex_link,cookies=cookies)
	else:
		cookies=''
		html=sess.get(ex_link)
		kukz= html.cookies['PHPSESSID']
	out,np=estadios.get_skroty_meczow(html.content)
	for f in out:
		addLinkItem(name=f.get('title'), url=f.get('url'), mode='Estadios_play', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,fanart=FANART2)	
	if np:
		addDir('[COLOR blue]>> następna strona >>[/COLOR]',ex_link=mainesturl+np,params={}, mode='Estadios_skroty',iconImage=RESOURCES+'nextpage.png',fanart=FANART2)	
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	xbmcplugin.setContent(int(sys.argv[1]), 'files')		
	xbmcplugin.endOfDirectory(addon_handle)
	
elif mode[0] =='Estadios_skroty_Liga':
	addDir('Szukanie','search', params={}, mode='Estadios_search',iconImage=RESOURCES+'search.png',fanart=FANART2)
	data = estadios.get_liga()
	if data:
		label = [estadios.unicodePLchar(x[1].strip()) for x in data]
		value = [x[0].strip() for x in data]
		for t,v in zip(label,value):
			imag=t.split(' ')[0].replace('Włochy','wlochy')
			addDir(t,ex_link=v,params={}, mode='Estadios_skroty',iconImage=RESOURCES+imag+'.png',fanart=FANART2)
	xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] =='Estadios_search':		

	query = xbmcgui.Dialog().input(u'Szukaj drużyny:', type=xbmcgui.INPUT_ALPHANUM,)
	if query:  	
		itemz=estadios.get_search(query)
		if itemz:
			for f in itemz:
				imag=f.get('img')
				if not imag:
					imag=RESOURCES+'empty.png'
				addDir(f.get('title'),f.get('url'), params={}, mode='Estadios_search_matches',iconImage=imag,fanart=FANART2)	
			xbmcplugin.endOfDirectory(addon_handle)	
		else:
			xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak wyników')
			quit()	
elif mode[0] =='Estadios_search_matches':	
	mainesturl='https://estadios.pl/'
	kukz = args.get('mbebe',[{}])[0]
	if kukz:
		cookies={'PHPSESSID': kukz}
		html=sess.get(ex_link,cookies=cookies)
	else:
		cookies=''
		html=sess.get(ex_link)
		kukz= html.cookies['PHPSESSID']
	out,np=estadios.get_skroty_meczow(html.content)
	if out:
		for f in out:
			addLinkItem(name=f.get('title'), url=f.get('url'), mode='Estadios_play', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,fanart=FANART2)	
		if np:
			addDir('[COLOR blue]>> następna strona >>[/COLOR]',ex_link=mainesturl+np,params={}, mode='Estadios_skroty',iconImage=RESOURCES+'nextpage.png',fanart=FANART2)	
		xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
		xbmcplugin.setContent(int(sys.argv[1]), 'files')		
		xbmcplugin.endOfDirectory(addon_handle)		
	else:
		quit()

elif mode[0] =='our_match_main':
	if not ex_link:
		addDir('Search...','search', params={}, mode='our_match_getMatches',iconImage=RESOURCES+'search.png',fanart=FANART2)
		addDir('Most Recent','http://ourmatch.net/', params={}, mode='our_match_getMatches',iconImage=RESOURCES+'new.png',fanart=FANART2)		
		out = ourmatch.main()
		for one in out:	
			tyt=one.get('title','')
			imag=one.get('img','')
			href=one.get('url','')		
			addDir(tyt, href, params={}, mode='our_match_main',iconImage=RESOURCES+imag,fanart=FANART2)
	else:
		ikon=rys
		out = ourmatch.main(name=ex_link)
		for one in out:	
			tyt=one.get('title','')
			imag=one.get('img','')
			href=one.get('url','')	
			addDir(tyt, href, params={}, mode='our_match_getMatches',iconImage=ikon,fanart=FANART2)				
	xbmcplugin.endOfDirectory(addon_handle)	
	
elif mode[0] =='our_match_getMatches':	

	out,np = ourmatch.getMatches(ex_link)
	for one in out:	
		tyt=one.get('title','')
		imag=one.get('img','')
		href=one.get('url','')		
		addDir(tyt, href, params={}, mode='our_match_getStreams',iconImage=imag,fanart=FANART2)	
	if np:
		addDir('[COLOR blue]>> next page >>[/COLOR]', np, params={}, mode='our_match_getMatches',iconImage=RESOURCES+'nextpage.png',fanart=FANART2)
	xbmcplugin.endOfDirectory(addon_handle)	
	
elif mode[0] =='our_match_getStreams':

	out = ourmatch.getStreams(fname,ex_link,rys)
	for one in out:	
		tyt=one.get('title','')
		imag=one.get('img','')
		href=one.get('url','')		
		addLinkItem(name=tyt, url=href, mode='our_match_play', iconimage=imag, infoLabels=one, IsPlayable=True,fanart=FANART2)
	xbmcplugin.endOfDirectory(addon_handle)	
	
elif mode[0] =='our_match_play':
	
	stream_url=ourmatch.play(fname,ex_link)
	if stream_url:
		xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
	else:
		quit()

elif mode[0] =='Estadios_play':
    estadios_getLinks(ex_link)

elif mode[0] == 'Opcje':
    my_addon.openSettings()

elif mode[0] =='getLinks':
    getLinks(ex_link)

elif mode[0] =='getVideos':
	params = eval(params)
	Litems,pagination = ekstraklasa.getVideos(**params)
	if pagination[0]:
		addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__', params=pagination[0], IsPlayable=False)
	items=len(Litems)
	for f in Litems:
		f['code']= f.get('duration_formatted','')
		f['code']='[COLOR lightgreen]onAir[/COLOR]' if f.get('onair',False) else f['code']
		addLinkItem(name=f.get('title'), url=f.get('id'), mode='getLinks', iconimage=f.get('thumbnail_240_url'), infoLabels=f, IsPlayable=True,contextmenu=items,fanart=f.get('img'))
	
	if pagination[1]:
		addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__', params=pagination[1], IsPlayable=False)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	xbmcplugin.setContent(int(sys.argv[1]), 'files')
	xbmcplugin.endOfDirectory(addon_handle)
	
elif mode[0] == '__page__':
	url = buildUrl({'mode': 'getVideos', 'foldername': '', 'ex_link' : ex_link, 'params': params})
	xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'Opcje':
    my_addon.openSettings()

elif mode[0] == 'folder':
    pass

elif mode[0] =='wybor':	
	import tabele	
	dane = tabele.getWybor(ex_link)
	stream_url=''
	t = [ x.get('title') for x in dane]
	u = [ x.get('url') for x in dane]
	sel = xbmcgui.Dialog().select('Co pokazać?', t)
	if sel>-1:
			nxturl = dane[sel].get('url')
			if 'terminarz' in nxturl:
				import tabele
				out= tabele.getTerminarz(nxturl)
				for one in out:	
					tyt=one.get('title','')
					imag=one.get('img','')
					href=one.get('url','')		
					addDir(tyt, href, params={}, mode='termincd',iconImage=rys,fanart=FANART2)
				xbmcplugin.endOfDirectory(addon_handle)			
			elif '/grupy/' in nxturl or '/tabela/' in nxturl:
				import tabele
				nxturl=nxturl.split('|')
				if 'no' in nxturl[1]:
					out= tabele.getTabelaGrupy(nxturl[0])
					for one in out:	
						tyt=one.get('title','')
						imag=one.get('img','')
						href=one.get('url','')		
						addDir(tyt, href, params={}, mode='grupycd',iconImage=rys,fanart=FANART2)
					xbmcplugin.endOfDirectory(addon_handle)	
				else:
					import tabele
					out= tabele.getTabelaKraj(nxturl[0])
					for one in out:	
						tyt=one.get('title','')
						imag=one.get('img','')
						href=one.get('url','')		
						addLinkItem(name=tyt, url=href, mode=' ', iconimage=rys, infoLabels=one, IsPlayable=False,fanart=FANART2)
					xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
					xbmcplugin.setContent(int(sys.argv[1]), 'videos')
					xbmcplugin.endOfDirectory(addon_handle)		
			elif 'strzelcy' in	nxturl:
				import tabele
				out= tabele.getStrzelcy(nxturl)
				for one in out:	
					tyt=one.get('title','')
					imag=one.get('img','')
					href=one.get('url','')		
					addLinkItem(name=tyt, url=href, mode=' ', iconimage=rys, infoLabels=one, IsPlayable=False,fanart=FANART2)
				xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
				xbmcplugin.setContent(int(sys.argv[1]), 'videos')
				xbmcplugin.endOfDirectory(addon_handle)					
				
elif mode[0] =='listtabterm':	
	import tabele
	out= tabele.getListTerminarz()
	for one in out:	
		tyt=one.get('title','')
		imag=one.get('img','')
		href=one.get('url','')	
		href=href.split('|')	
		addDir(tyt, href[0], params={}, mode='wybor',iconImage=RESOURCES+imag,fanart=FANART2)	
	xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] =='grupycd':	
	druz = eval(urllib.unquote(ex_link))
	for one in druz:	
		tyt=one.get('title','')
		imag=one.get('img','')
		href=one.get('url','')	
		if fname in href:
			addLinkItem(name=tyt, url=href, mode=' ', iconimage=rys, infoLabels=one, IsPlayable=False,fanart=FANART2)
		else:
			continue
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	xbmcplugin.setContent(int(sys.argv[1]), 'videos')
	xbmcplugin.endOfDirectory(addon_handle)	

elif mode[0] =='ytarchive':

	xbmc.executebuiltin('container.Update(plugin://plugin.video.youtube/channel/UC_DZQrnboIncQCBB7QdMKOg/playlists/)')

elif mode[0] =='ektv':
	addDir('[COLOR blue]Ekstraklasa.tv[/COLOR]',ex_link='',params={'_service':'ekstraklasatv','_act':'main'}, mode='site',iconImage=RESOURCES+'EkstraklasaTV.png')
	addLinkItem('[COLOR blue]Ekstraklasa Archives[/COLOR]','','ytarchive',IsPlayable=False,iconimage=RESOURCES+'EkstraklasaTV.png',)
	xbmcplugin.endOfDirectory(addon_handle)	
	
elif mode[0] =='termincd':	
	import tabele
	aa=re.findall('\[B\](.+?)\[\/CO',fname,re.DOTALL)[0]
	out= tabele.getTerminarzCD(ex_link,aa)
	for one in out:	
		tyt=one.get('title','')
		imag=one.get('img','')
		href=one.get('url','')	
		addLinkItem(name=tyt, url=href, mode=' ', iconimage=rys, infoLabels=one, IsPlayable=False,fanart=FANART2)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	xbmcplugin.setContent(int(sys.argv[1]), 'videos')
	xbmcplugin.endOfDirectory(addon_handle)	
	
else:
	
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=None))