# -*- coding: UTF-8 -*-
import sys,re,os
import urlparse
import hashlib
import base64
import urllib
import requests
from CommonFunctions import parseDOM
import resources.lib.pyaes as pyaes

UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0'
headersok = {
	'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
	'Connection': 'keep-alive',
	'Upgrade-Insecure-Requests': '1',}
	
main_url='https://www.hulkstream.com/'
s = requests.Session()

def __bytes_to_key(password, salt, output=48):
	try:
		seed = hashlib.md5(password + salt).digest()
		key = seed
	
		while len(key) < output:
			seed = hashlib.md5(seed + (password + salt)).digest()
			key += seed
	
		return key[:output]
	
	except Exception:
		return

def decryptaes(encrypt):
	encrypted=re.findall(r'(.+?)\,',encrypt)[0]
	password=re.findall(r'\,(.*$)',encrypt)[0]
	encrypted=urllib.unquote(encrypted).replace('"','')
	password=urllib.unquote(password).replace('"','')	
	password=str(password)
	try:
		encrypted = base64.b64decode(encrypted)
		salt = encrypted[8:16]
		key_iv = __bytes_to_key(password, salt)
		key = key_iv[:32]
		iv = key_iv[32:]
		decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(key, iv = iv))
		plaintext = decrypter.feed(encrypted[16:])
		plaintext += decrypter.feed()	
		return plaintext	
	except Exception:
		return

def getFoothighlights(url):
	html=getUrlReqok(url)	
	out=[]	
	zdek=''
	result=parseDOM(html,'ul', attrs={'class': "sidenav-inner py-1"})[0]	
	links = parseDOM(result, 'li', attrs={'class': "sidenav-item"})#[0] 
	if links:
	
		out=[]
		for link in links:
			link= link.replace('&nbsp;','')
			href = parseDOM(link, 'a', ret='href')[0] 
			title = re.findall('<span>([^<]+)<',link)[0]
			out.append({'title':title,'href':href})	
	else:
		alstrs=re.findall("""var\s+wwwjavafootycom.+?['"](.+?)['"]""",result)#[0]
		for alstr in alstrs:
			decoded=decodeAlan(alstr,False)
			decoded= urllib.unquote(decoded)
			zdek+=decoded.replace("\'",'"')
		links = parseDOM(zdek, 'li', attrs={'class': "sidenav-item"})#[0] 
		out=[]
		for link in links:
			link= link.replace('&nbsp;','')
			href = parseDOM(link, 'a', ret='href')[0] 
			title= parseDOM(link, 'div')[0] 
			out.append({'title':title,'href':href})	
	return out		

def checkNxtPg(url,page):
	html=getUrlReqok(url)
	result=parseDOM(html,'div', attrs={'class': "table-responsive"})[0] 
	links = parseDOM(result, 'tr') 
	if links:
		nextpage=page
	else:
		nextpage=False
	return nextpage
	
def getSportpieces(url,page):
	pgn=page+1
	urln=url + '%d/' %pgn
	url = url + '%d/' %page

	html=getUrlReqok(url)	
	out=[]	
	prevpage=False #gr=False

	if page>1:
		prevpage=page-1

	nextpage = checkNxtPg(urln,pgn)
	result=parseDOM(html,'div', attrs={'class': "table-responsive"})[0] 
	links = parseDOM(result, 'tr') 
	for link in links:	
		try:
			if 'javafooty' in url:
				resulty=parseDOM(html,'div', attrs={'class': "text-muted mt-1"})[0]
				categ= parseDOM(resulty, 'font')[0] .upper()
				href = parseDOM(link, 'a', ret='href')[0] 	
				titledata = re.findall('</span>([^<]+)<span class',link)
				if titledata:
					title=titledata[1]
					data=titledata[0]				
			else:
				categ= parseDOM(link, 'a')[0] .upper()
				href = parseDOM(link, 'a', ret='href')[1] 
				title=parseDOM(link,'td')[3]
				data = parseDOM(link, 'td')[1]
			imag = ''
			title1 = '[COLOR blue]%s[/COLOR]'%title
			plot='[COLOR khaki]'+categ+'[CR][COLOR blue]'+title+'[/COLOR][CR]'+data
			out.append({'title':title1,'href':href,'img':imag,'code':'[COLOR khaki]'+categ+'[/COLOR]', 'plot':plot,'genre':data})
		except:
			pass
	return (out,(prevpage,nextpage))

def getSportpiecesSearchDate(html,url):
	out=[]	
	result=parseDOM(html,'tbody')[0]
	trs=parseDOM(result,'tr')#[0]
	for tr in trs:
		if '"bg-primary"' in tr:
			
			if 'javafoot' in url:
				title=re.findall('>([^<]+)</span>',tr)[0]
				title='[COLOR khaki]'+title+'[/COLOR]'
				continue
			else:
				title=re.findall('>([^<]+)</span>',tr)[0]
				title='[COLOR khaki]'+title+'[/COLOR]'
				continue
		try:
			data = parseDOM(tr, 'td')[1]
			imag = ''
			href = parseDOM(tr, 'a', ret='href')[0]   
			titlem=parseDOM(tr,'td')[2]  		
			titlem = '[COLOR blue]%s[/COLOR]'%titlem
			plot='[COLOR khaki]'+title+'[CR][COLOR blue]'+titlem+'[/COLOR][CR]'+data			
		except:
			continue
		out.append({'title':titlem,'url':href,'img':imag,'code':title, 'plot':plot,'genre':data})
	return out
		
def getSportpiecesSearch(html,url):	
	out=[]
	result=parseDOM(html,'div', attrs={'class': "table-responsive"})[0] 
	links = parseDOM(result, 'tr') 
	for link in links:	
		try:
			if 'javafooty' in url:
				categ=re.findall('</span>([^<]+)<span',link)[0].upper()
				href = parseDOM(link, 'a', ret='href')[0] 	
				titledata=re.findall('<td>([^<]+)</td><td><span class="\w+"></span>([^<]+)<',link)#[0]
				if titledata:
					title=titledata[0][1]
					data=titledata[0][0]	
					categ2=''					
			else:
				categtitledata=re.findall('>([^<]\w+)<.+?>([^<]+)</span></a></td><td>([^<]+)</td><td>([^<]+)<',link)
				if categtitledata:
					categ2=categtitledata[0][0]
					categ2=', '+categ2
					categ=categtitledata[0][1]
					title=categtitledata[0][2]
					data=categtitledata[0][3]
				else:
					categ=''
					categ2=''
					title=''
					data= ''	
					continue					
				href = parseDOM(link, 'a', ret='href')[2] 
			imag = ''
			title1 = '[COLOR blue]%s[/COLOR]'%title
			plot='[COLOR khaki]'+categ+'[CR][COLOR blue]'+title+'[/COLOR][CR]'+data
			out.append({'title':title1,'url':href,'img':imag,'code':'[COLOR khaki]'+categ+categ2+'[/COLOR]', 'plot':plot,'genre':data})
		except:
			pass
	return out	
	
def Listdate(url,query):
	query=(str(query).replace(' ','0')).split('/')
	data='%s/%s/%s'%(query[1],query[0],query[2])
	typ=False
	html=postUrlReq(url,data,typ)
	links = getSportpiecesSearchDate(html,url)
	return links
	
def Listsearchhigh(url,query):
	query=query.replace(' ','+')
	typ=True
	html=postUrlReq(url,query,typ)
	links = getSportpiecesSearch(html,url)
	return links

def getUrlReqok(url):
	headers = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Connection': 'keep-alive',
		'Upgrade-Insecure-Requests': '1',}
	content=s.get(url,headers=headers, verify=False).text	
	return content	
	
def getUrlReq(url):
	headers = {
		'Connection': 'keep-alive',
		'Cache-Control': 'max-age=0',
		'Upgrade-Insecure-Requests': '1',
		'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 8_0_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12A366 Safari/600.1.4',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
		'Accept-Encoding': 'gzip, deflate',
		'Accept-Language': 'en-US,en;q=0.9',
		'Referer': url,
	}
	content=s.get(url,headers=headers, verify=False).text	
	return content	
def postUrlReq(url,data,typ):

	headerspo = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
		'Content-Type': 'application/x-www-form-urlencoded',
		'Upgrade-Insecure-Requests': '1',}
	if typ:
		data = {
		'inpsearch': data,
		'submit2': 'Submit'}
	else:
		data = {
		'datematchsport': data,
		'submit1': 'Submit'}
	response = s.post(url, data=data,headers=headerspo).text
	return response
	
def decodeAlan(alantvcom_streaminglive,data):
	ex1 = alantvcom_streaminglive.split('_javafooty_football_highlights_goals_video_');
	p = ex1[1].split('_');
	t0 = int(p[0]);
	t1 = int(p[0]) + int(p[1]);
	aaa=p[2]
	abac=t1+int(aaa)
	t2 = int(p[0]) + int(p[1]) + int(p[2]);
	j0 = ex1[0][0: int(t0)];
	j0 = ex1[0][0: int(t0)];
	k0 = int(ex1[0][int(t0) - 1]) + 1;
	j1 = ex1[0][int(t0): int(t0)+int(p[1])];
	k1 = int(ex1[0][int(t1) - 1]) + 1;
	j2 = ex1[0][int(t1):int(t1)+ int(p[2])];
	k2 = int(ex1[0][int(t2) - 1]) + 1;
	a = '';
	s0 = urllib.unquote(j0[0: len(j0) - k0]);
	abacad=int(len(j0)-k0)
	t = '';
	abacada=int(j0[len(j0)-k0:abacad+1])
	for i in range(0, len(s0)):
		t += chr(ord(s0[i])-abacada	)
	z = urllib.unquote(t);
	a0 = '';
	for ii in range(0, len(z)):
		qq=len(z) - ii
		a0 += z[len(z) - ii: qq+1];
	a = a + a0;
	s1 = urllib.unquote(j1[0: len(j1) - k1]);
	t = '';
	for i in range(0, len(s1)):
		abacad=int(len(j1) - k1)
		abacada=int(j1[len(j1) - k1:abacad+1])
		t += chr(ord(s1[i])-abacada	)
	z = urllib.unquote(t);
	a1 = '';
	for ii in range(0, len(z)):
		a1 += z[len(z) - ii:(len(z) - ii)+ 1];
	a = a + urllib.quote(a1);
	s2 = urllib.unquote(j2[0: len(j2) - k2]);
	t = '';
	for i in range(0, len(s2)):
		abacad=int(len(j2) - k2)
		abacada=int(j2[len(j2) - k2:abacad+1])
		t += chr(ord(s2[i])-abacada	)   
	z = urllib.unquote(t);
	a2 = '';
	for ii in range(0, len(z)):
		a2 += z[len(z) - ii:(len(z) - ii)+ 1];
	a = a + a2;
	return a	

def getJSlink4(url):
	html=getUrlReq(url)
	out=[]	
	try:
		result=parseDOM(html,'div', attrs={'class': "card mb-4"})[0]
		alstr=re.findall("""var wwwjavafootycom.+?['"](.+?)['"]""",result)[0]				
		counter=0
		decoded=decodeAlan(alstr,False)
		decoded= urllib.unquote(decoded)
		aespass=re.findall("decrypt\((.+?)\)",decoded) 		
		if aespass:	
			decoded=(decryptaes(aespass[0])).replace("\'",'"')
		results=parseDOM(decoded,'span')
		for result in results:
			title=parseDOM(result,'font')[0]
			href=parseDOM(result,'iframe',ret='src')#[0]
			if href:
				href=href[0]
			else:
				href=parseDOM(result,'a',ret='href')[0]
			href = 'https:'+href if href.startswith('//') else href
			if 'tinyurl' in href:
				r=s.get(href,headers=headersok,allow_redirects=False)
				href= r.headers['Location']	
			out.append({'title':title,'href':href})
		return out
	except:
		return out

def getMatchat(link):
	content = getUrlReq(link)
	content=content.replace("\'",'"')
	m3u8=re.findall('hls\:"(.+?)"',content,re.DOTALL)[0]
	str='https:'+m3u8
	return str	
	
def getStreamlet(url):
	html= getUrlReq(url)
	src = re.compile('hls:"(//.*?)"').findall(html)[0]	
	src = 'http:'+src if src.startswith('//') else src
	return src	

	
def getLinks(url):
	out=getJSlink4(url)
	vido_url=''
	return out