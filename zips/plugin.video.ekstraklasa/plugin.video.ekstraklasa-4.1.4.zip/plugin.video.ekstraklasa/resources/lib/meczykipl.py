# -*- coding: utf-8 -*-
import urllib2,urllib,json
import re
from urlparse import urlparse
TIMEOUT = 10
UA      = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'

def getUrl(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)
    if cookies:
        req.add_header("Cookie", cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()
        response.close()
    except:
        link=''
    return link

def getContent(url='',category='latest_highlights',page='1',**kwargs):
    return parseContent(category,page)

def parseContent(category='10', page=1):
    url = 'https://www.meczyki.pl/front/shortcut/get-shortcuts?category={}&page={}'.format(category,page)
    content = getUrl(url)
    out=[]
    data = json.loads(content.decode('utf-8'))
    wc = data.get('shortcuts',{})

    for i in sorted(wc.keys(),reverse=True):
        shortcuts = wc.get(i)

        for j in shortcuts.get('shortcuts',[]):
            out.append(
                {'title': '[COLOR blue]%s [/COLOR]([B]%s[/B])'%(re.sub('(<.+?>)','',j.get('title','')), j.get('score','')),
                  'url':j.get('url'),
                  'code': '[COLOR khaki]%s[/COLOR], %s'%( j.get('competition'),j.get('event_date'))
                  })

    nextPage = {'category': category, 'page': int(page)+1 } if len(out) > 5 else False
    prevPage = {'category': category, 'page': int(page)-1 } if int(page) > 1 else False

    return out,(prevPage,nextPage)
def getStreamlet(url):
	html= getUrl(url)
	src = re.compile('hls:"(//.*?)"').findall(html)[0]	
	src = 'http:'+src if src.startswith('//') else src
	return src
def getVideos(url):
	content = getUrl(url)
	#
	v=[]
	content=content.replace("\'",'"')
	if 'ekstraklasa.tv/skro' in content:	
		iframe = re.compile('href="(http[s].*?ekstraklasa.tv.*?)"').findall(content)
	elif 'www.polsatsport.pl/film/' in content or 'www.polsatsport.pl/wiadomo' in content:
		iframe = re.compile('href="(.+polsatsport.pl\/.+?\/.+?)"').findall(content)		
	else:
		iframe = re.compile('iframe\s*.*src="(.*?)"').findall(content)
	for src in iframe:
		v.append({'title':urlparse(src).netloc,'url':src})
	if not v:
		v={'msg':'Brak linku lub przekierowanie na inna strone.'}
	return v

def getMain():
	content = getUrl('https://www.meczyki.pl/najnowsze_skroty.html')
	cat = re.findall('ng-click="setCategory\((\d+)\).+?url\(\'(.+?)\'\).+?>(.*?)</a>',content,re.DOTALL)
	out=[{'title':'Najnowsze Skróty','url':'','img':'meczykipl','params':{'category':0,'page':1}}]
	for category,img,title in cat:
		print category
		if title:
			img=(title.strip()).lower()
			if 'liga' in img:
				img='liga'
			elif 'dzynarodowe' in img:
				img ='fifa'
			elif 'inne' in img:
				img ='meczykipl'				
			out.append({'title':title.strip(),'url':'','img':img,'params':{'category':category,'page':1}})
	return out
#def getDMotion(link):
#	content = getUrl(link)
#	content=content.replace("\'",'"')
#	m3u8=re.findall('"type":"video.+?","url":"(.+?)"',content,re.DOTALL)[-1].replace('\\/','/')
#	
#	#str='https:'+m3u8
#	return m3u8	+'|User-Agent'+urllib.quote(UA)+'&Referer=%s'%link
	
	
def getMatchat(link):
	content = getUrl(link)
	content=content.replace("\'",'"')
	m3u8=re.findall('hls\:"(.+?)"',content,re.DOTALL)[0]
	str='https:'+m3u8
	return str