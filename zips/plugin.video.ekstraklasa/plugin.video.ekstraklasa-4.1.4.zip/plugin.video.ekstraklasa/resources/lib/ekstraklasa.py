# -*- coding: utf-8 -*-

import urllib2,urllib,json
import re,os
from urlparse import urlparse
import base64
import cookielib
import requests

BASEURL= "https://api.dailymotion.com"
TIMEOUT = 10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'
GATE2='http://karmabydesign.com/ninja/?q='
def getUrl(url,data=None,cookies=None):
	if GATE:
		link=getUrlProxy5(url)
		return link
	req = urllib2.Request(url,data)
	req.add_header('User-Agent', UA)
	if cookies:
		req.add_header("Cookie", cookies)
	try:
		response = urllib2.urlopen(req,timeout=TIMEOUT)
		link = response.read()
		response.close()
	except:
		link=''
	return link

# user='Ekstraklasa'
# fields='id,uri,duration,record_status,duration_formatted,title,onair,private,views_total,created_time,thumbnail_240_url'

def getUrlProxy5(url):	

	import requests
	headers = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': 'http://karmabydesign.com/ninja/?q=',
		'Content-Type': 'application/x-www-form-urlencoded',
		'Connection': 'keep-alive',
		'Upgrade-Insecure-Requests': '1',
	}
	data = {
	'q': url,
	'hl[include_form]': '1',
	'hl[remove_scripts]': '0',
	'hl[accept_cookies]': '1',
	'hl[show_images]': '1',
	'hl[show_referer]': '1',
	'hl[base64_encode]': '1',
	'hl[strip_meta]': '1',
	'hl[session_cookies]': '1'
	}

	response = requests.post('http://karmabydesign.com/ninja/', headers=headers, data=data,verify=False,allow_redirects=False)

	if response.status_code==302:
		xxx= response.headers['Location']	
		xxx=urllib.unquote(xxx)
		req = urllib2.Request(xxx,None)
		req.add_header('User-Agent', UA)
    
		try:
			responsex = urllib2.urlopen(req,timeout=TIMEOUT)
			response = responsex.read()
			responsex.close()
		except:
			response=''
	else:
		response=response.content
    
	return response		

def getLive(user):
    url = BASEURL+"/user/"+user+"/videos?flags=live_onair&fields="+urllib.quote('id,duration,title,onair,private,thumbnail_240_url')
    content = getUrl(url)
    L=[]
    if content:
        data = json.loads(content)
        L = data.get('list',[])
        # for l in L:
        #     print l
    return L
    
def getVideos(user,sort='recent',page='1'):  #visited
    print 'user,sort,page'
    print user,sort,page
    fields='id,uri,duration,record_status,duration_formatted,title,onair,private,views_total,created_time,thumbnail_240_url'
    query = {  'fields':fields,
               'page':page,
               'thumbnail_ratio':'widescreen',
               'sort':sort,
               'limit':50,
               'localization':'pl_PL'
            }
    nextPage=False
    prevPage=False
    L=[]
    
    if sort =='live':
        L = getLive(user)

    else:
        url = BASEURL+"/user/"+user+"/videos?"+urllib.urlencode(query)
        content = getUrl(url)
        data = json.loads(content)
        L = data.get('list',[])
        nextPage = {'user':user,'sort':sort,'page':data.get('page',page)+1} if data.get('has_more',False) else False
        prevPage = {'user':user,'sort':sort,'page':data.get('page',page)-1} if data.get('page',page)>1 else False
    return (L,(prevPage,nextPage))

# GATE=''
# GATE='http://invisiblesurf.review/index.php?q='

# media_id='x4nrxj6'x2yclwl
def getVideoLinks(media_id='x4r4uoo'):
	content = getUrl('http://www.dailymotion.com/embed/video/%s' % media_id)
	srcs=re.compile('"(1080|720|480|380)":(\[{[^\]]*\])',re.DOTALL).findall(content)
	out=[]
	for quality,links in srcs:
		#print links
		url=''
		for type,href in re.compile('"type":"(.*?)","url":"(.*?)"').findall(links):
			if 'video' in type:
				url= href 
				break
		if url:
			if GATE:
				url = GATE+base64.b64encode(url.replace('\\',''))
			out.append({'label':quality,'url':url.replace('\\','')}) 
		
	if not out:
		srcs=re.compile('"(auto)":\[{"type":"(.*?)","url":"(.*?)"}\]',re.DOTALL).findall(content)
		for quality,type,url in srcs:
			print url
			m3u = getUrl(url.replace('\\','')+ '&redirect=0')
			if '#EXTM3U' in m3u:
				qq=re.compile('NAME="(.*?)"\n(.*?)\n').findall(m3u)
				for label,url in qq:
					out.append({'label':label,'url':url})    
			else:
				burl = m3u.split('live.m3u8')[0]
				m3u2 = getUrl(url.replace('\\',''))
				if '#EXTM3U' in m3u2:
					qq=re.compile('NAME="(.*?)"\n(.*?)\n').findall(m3u2)[::-1]
					for label,pp in qq:
						out.append({'label':label,'url':burl+pp})  
	return out
