﻿# -*- coding: UTF-8 -*-

import sys,re,os

import requests
import xbmcgui, xbmcvfs
import xbmcplugin
import xbmcaddon
import xbmc


PY3 = sys.version_info >= (3,0,0)

try:
    # For Python 3.0 and later
    from urllib.parse import parse_qsl, unquote, quote, urlencode
    import http.cookiejar as cookielib
    LOGNOTICE = xbmc.LOGINFO
except ImportError:
    # Python 2
    LOGNOTICE = xbmc.LOGNOTICE
    from urlparse import parse_qsl
    import  cookielib
    from urllib import unquote, quote, urlencode
    

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED, label2Mask = "%R, %Y, %P")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = "%R, %Y, %P")

xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE, label2Mask = "%R, %Y, %P")

xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL, label2Mask = "%R, %Y, %P")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LASTPLAYED, label2Mask = "%R, %Y, %P")

xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_EPISODE, label2Mask = "%R, %Y, %P")



addon = xbmcaddon.Addon(id='plugin.video.govodtv')

PATH            = addon.getAddonInfo('path')

try:
    DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
except:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')

if isinstance(DATAPATH, bytes):
    DATAPATH = DATAPATH.decode('utf-8')
if isinstance(PATH, bytes):
    PATH = PATH.decode('utf-8')
    
COOKIEFILE = os.path.join(DATAPATH,'govodtv.cookie')

RESOURCES       = PATH+'/resources/'

FANART=RESOURCES+'../fanart.jpg'
ikona = RESOURCES+'../icon.png'
BASE_URL ='https://govod.tv'


kukz=''
kukz2=''


if PY3:
# for Python 3
    from resources.lib.cmf3 import parseDOM
    from resources.lib.cmf3 import replaceHTMLCodes

else:
    # for Python 2
    from resources.lib.cmf2 import parseDOM
    from resources.lib.cmf2 import replaceHTMLCodes

exlink = params.get('url', None)
name= params.get('title', None)
rys= params.get('image', None)
favorite = params.get('fav', None)


logged = addon.getSetting('logged')
widok = addon.getSetting('widok')

try:
    opisb = eval(params.get('opisb', None))
except:
    opisb = params.get('opisb', None)
page = params.get('page',[1])[0]
sess=requests.Session()
sess.cookies = cookielib.LWPCookieJar(COOKIEFILE)
UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0'

def build_url(query):
    return base_url + '?' + urlencode(query)

def add_item(url, name, image, folder, mode, fav=None,context=[''], infoLabels=False, isplay=False,itemcount=1, page=1):
    list_item = xbmcgui.ListItem(label=name)    
        
    if folder:
        list_item.setProperty("IsPlayable", 'false')
    else:
        if isplay:
            list_item.setProperty("IsPlayable", 'true')
        else:
            list_item.setProperty("IsPlayable", 'false')
        
    if not infoLabels:
        infoLabels={'title': name,'plot':name}
    contextmenu=[]
    if 'dodaj' in context:
        contextmenu.append(('[B]Dodaj do ulubionych[/B]', 'RunPlugin(plugin://plugin.video.govodtv?mode=dodaj&fav=%s)'%(fav)))
    elif 'usun' in context:
        contextmenu.append(('[B]Usuń z ulubionych[/B]', 'RunPlugin(plugin://plugin.video.govodtv?mode=usun&fav=%s)'%(fav)))
        
    list_item.addContextMenuItems(contextmenu, replaceItems=False)
    list_item.setInfo(type="video", infoLabels=infoLabels)        
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': FANART})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,    
        url = build_url({'mode': mode, 'url' : url, 'page' : page,'opisb':infoLabels,'image':image, 'title':name,'fav':fav}),    
        listitem=list_item,
        isFolder=folder)

def home():
    login()
    if logged=='true':
        add_item('https://govod.tv/ulubione', 'ULUBIONE', ikona, True, "listmovies")    
    add_item('https://govod.tv/filmy-online', 'FILMY', ikona, True, "listmovies")    
    add_item('', '    - kategorie', ikona, True, "listcateg")    

    add_item('https://govod.tv/seriale-online', 'SERIALE', ikona, True, "listmovies")    

    add_item('https://govod.tv/dla-dzieci', '[COLOR green]D[/COLOR][COLOR yellow]L[/COLOR][COLOR violet]A[/COLOR] [COLOR yellow]D[/COLOR][COLOR violet]Z[/COLOR][COLOR green]I[/COLOR][COLOR yellow]E[/COLOR][COLOR violet]C[/COLOR][COLOR green]I[/COLOR]', ikona, True, "listmovies")    
    
    add_item('', '[COLOR lightblue]Szukaj[/COLOR]', ikona, True, "search")    
    add_item(name='[COLOR lightgreen]Opcje[/COLOR]', url='', mode='settings', image=ikona, folder=False, isplay = False ,infoLabels=None)

    if addon.getSetting('logged') =='true':
        add_item(name='Wyloguj', url='', mode='logout', image=ikona, folder=False, isplay = False ,infoLabels=None)

    xbmcplugin.endOfDirectory(addon_handle,True)
    
def cookieString(COOKIEFILE):
    sc=''
    if os.path.isfile(COOKIEFILE):
        sess.cookies.load(COOKIEFILE)
        sc=''.join(['%s=%s;'%(c.name, c.value) for c in sess.cookies])
    return sc    
    
def postUrl(url,data={}, redir=True):
    if os.path.isfile(COOKIEFILE):
        sess.cookies.load(COOKIEFILE, ignore_discard = True)
    headers = {
        'Host': 'govod.tv',
        'user-agent': UA,
        'accept': '*/*',
        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
        'x-requested-with': 'XMLHttpRequest',
        'origin': 'https://govod.tv',
        'dnt': '1',
        'referer': 'https://govod.tv/',
        'te': 'trailers',
    }
    url = BASE_URL +url if url.startswith('/') else url
    if data:
        response = sess.post(url, data=data, headers=headers,verify=False).json()
    else:
        response = sess.post(url, headers=headers,verify=False).json()
    return response
    
    
def getUrl(url,ref=None,redir=True):
    sess.headers.update({'User-Agent': UA})
    if ref:
        sess.headers.update({'Referer': ref})
    if os.path.isfile(COOKIEFILE):
        sess.cookies.load(COOKIEFILE, ignore_discard = True)
    if redir:
        html=sess.get(url,cookies=sess.cookies,verify=False,allow_redirects=redir,timeout=30).text
    else:
        html=sess.get(url,cookies=sess.cookies,verify=False,allow_redirects=redir,timeout=30)
    
    return html
    
def DodajUlub(link):
    link = 'https://govod.tv/ajax/favorite/' + link
    status = postUrl(link)
    status = status.get('status',None)

    if status==1:
        xbmcgui.Dialog().notification('[B]Super[/B]', 'Dodano do ulubionych.',xbmcgui.NOTIFICATION_INFO, 6000,False)
    else:
        xbmcgui.Dialog().notification('[B]Super[/B]', 'Usunięto z ulubionych.',xbmcgui.NOTIFICATION_INFO, 6000,False)

    return
    
def WyborProfilu():

    headers = {
        'Host': 'govod.tv',
        'user-agent': UA,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
        'referer': 'https://govod.tv/profil/dodaj',
        'dnt': '1',
        'upgrade-insecure-requests': '1',
        'te': 'trailers',
    }
    
    html = sess.get('https://govod.tv/profil/wybierz', headers=headers,verify=False, timeout=30).content
    if PY3:     
        html = html.decode(encoding='utf-8', errors='strict')

    result = parseDOM(html, 'div', attrs={'class': "ppm-content user-content profile"})[0]
    
    hrimgnazwa = re.findall('href="([^"]+)">\s*<img src="([^"]+)">\s*.*?>([^<]+)<\/h5>',result)

    out=[]
    for hr,img,nazwa in hrimgnazwa:
        out.append((hr, img, nazwa))
    
    naz = [x[2].strip() for x in out]
    url = [x[0].strip() for x in out]
    img = [x[1].strip() for x in out]

    s = xbmcgui.Dialog().select('Wybierz profil',naz)
    nazwa=''
    imag=''
    
    if s>-1:
        href = url[s]
        nazwa = naz[s]

        img = img[s]
        imag = 'https://govod.tv'+img if img.startswith('/images') else img
        
        html = sess.get('https://govod.tv'+href, headers=headers,verify=False, timeout=30).content

        return nazwa,imag
    else:
        nazwa=''
        imag=''
        return nazwa,imag

def login():
    if logged=='true':
        username = addon.getSetting('username')
        password = addon.getSetting('password')    
        logowanie = addon.getSetting('logowanie')

        if username and password and logowanie == 'true':
            headers = {
                'Host': 'govod.tv',
                'user-agent': UA,
                'accept': '*/*',
                'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
                'x-requested-with': 'XMLHttpRequest',
                'dnt': '1',
                'referer': 'https://govod.tv/',
                'te': 'trailers',
            }
    
            response = sess.get('https://govod.tv/logowanie', headers=headers,verify=False, timeout=30).content
            if PY3:     
                response = response.decode(encoding='utf-8', errors='strict')
            _csrf_token = re.findall('_csrf_token" value="([^+]+)"',response)
            if _csrf_token:
                
                headers = {
                    'Host': 'govod.tv',
                    'user-agent': UA,
                    'accept': '*/*',
                    'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'x-requested-with': 'XMLHttpRequest',
                    'origin': 'https://govod.tv',
                    'dnt': '1',
                    'referer': 'https://govod.tv/',
                    'te': 'trailers',
                }
                
                data = 'email='+username+'&password='+password+'&action=pt_login_member&_remember_me=on&_csrf_token='+_csrf_token[0]

                response = sess.post('https://govod.tv/logowanie', headers=headers, data=data,verify=False, timeout=30).text

                if '{"status":"ok"}' in response:

                    xbmcgui.Dialog().notification('[B]Super[/B]', 'Zalogowano poprawnie.',xbmcgui.NOTIFICATION_INFO, 6000,False)

                    nazwa,img = WyborProfilu()
                    if nazwa and img:
                        sess.cookies.save(COOKIEFILE, ignore_discard = True)
                        html = sess.get('https://govod.tv/twojprofil', headers=headers, cookies=sess.cookies,verify=False, timeout=30).text
                        prem=re.findall('subskrypcja\:<\/label>(.+?)<\/div>',html,re.DOTALL+re.IGNORECASE)
                        prem = re.sub('<[^<]+?>', '', prem[0]).lower() if prem else ''
                        if 'premium' in prem:
                            plot = re.findall('(do.+?)$',prem,re.DOTALL)[0]
                            plot = ' [COLOR gold](premium '+plot.strip()+')[/COLOR]'
                        else:
                            plot = ' [COLOR grey](darmowe)[/COLOR]'
                        zalog = 'Zalogowany jako [COLOR khaki]%s[/COLOR] %s'%(nazwa.strip(),plot)
                        add_item(name=zalog, url='', mode='   ', image=img, folder=False, isplay = False ,infoLabels=None)    
                        addon.setSetting('logged', 'true')
                    else:
                        sess.cookies.clear()
                        sess.cookies.save(COOKIEFILE, ignore_discard = True)
                        addon.setSetting('logged', 'false')
                        xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Musisz wybrać profil.',xbmcgui.NOTIFICATION_INFO, 6000,False)
                        add_item(name='Zaloguj się', url='', mode='zaloguj', image=ikona, folder=False, isplay = False ,infoLabels=None)    
                else:
            
                    xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Błędne dane logowania.',xbmcgui.NOTIFICATION_INFO, 6000,False)
                    addon.setSetting('logged', 'false')
                    add_item(name='Zaloguj się', url='', mode='zaloguj', image=ikona, folder=False, isplay = False ,infoLabels=None)
        else:
                #xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak danych logowania.',xbmcgui.NOTIFICATION_INFO, 6000,False)
                addon.setSetting('logged', 'false')
                add_item(name='Zaloguj się', url='', mode='zaloguj', image=ikona, folder=False, isplay = False ,infoLabels=None)
    else:
        addon.setSetting('logged', 'false')
        add_item(name='Zaloguj się', url='', mode='zaloguj', image=ikona, folder=False, isplay = False ,infoLabels=None)
            
def ListCateg():
    links=getCateg()    
    if links:
        itemz=links
        items = len(links)
        mud='getTvStream'
        fold=False
        ispla=False
        for f in itemz:
            add_item(name=f.get('title'), url=f.get('href'), mode='listmovies', image='', folder=True, itemcount=items)    

        xbmcplugin.endOfDirectory(addon_handle,True)

def getCateg():
    html=getUrl(BASE_URL)
    out=[]
    submenu = parseDOM(html, 'ul', attrs={'class': "sub-menu"})[0]
    hreflabel = re.findall('href="([^"]+)">(.+?)<',submenu)
    for href, label in hreflabel:
        href = BASE_URL + href if href.startswith('/') else href
        out.append({'title':PLchar(label),'href':PLchar(href)})
    return out

def ListMovies(exlink,page):
    page = int(page) if page else 1    
    if '/ulubione' in exlink and logged=='false':
        sys.exit(0)
    else:    
        linksf, linkss,pagin= getMovies(exlink,page)
        
        if pagin[0]:
            add_item(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__M', image='', folder=True,isplay=False, page=pagin[0])
    
        itemz=linksf
        items = len(linksf)
        mud='getLinks'
        fold=False
        for f in itemz:
            add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, fav=f.get('fav'), context=[f.get('menu')],isplay=False, infoLabels={'title':f.get('title'), 'plot':f.get('plot'),'year':f.get('year'),'rating':f.get('rating'),'genre':f.get('genre'),'country':f.get('country'),'duration':f.get('duration'),'code':f.get('code')},  itemcount=items)                        
    
        itemz2=linkss
        items2 = len(linkss)
        mud='listseasons'
        fold=True
        for f in itemz2:
            add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, fav=f.get('fav'), context=[f.get('menu')],infoLabels={'title':f.get('title'),'plot':f.get('plot'),'year':f.get('year'),'rating':f.get('rating'),'genre':f.get('genre'),'country':f.get('country'),'duration':f.get('duration'),'code':f.get('code')},  itemcount=items2)                        
    
            
        if pagin[1]:
        
           add_item(name='[COLOR blue]>> Nastepna strona >>[/COLOR]', url=exlink, mode='__page__M', image='', folder=True,isplay=False, page=pagin[1])  
        typ ='videos' if widok=='true' else 'movies'
        xbmcplugin.setContent(addon_handle, typ)    
        if items2>0 or items>0:
            xbmcplugin.endOfDirectory(addon_handle,True)
        else:
            xbmcgui.Dialog().notification('[B]Info[/B]', 'Brak materiału do wyświetlenia.',xbmcgui.NOTIFICATION_INFO, 6000,False)

def getMovies(url,page=1):
    if not 'szukaj?' in url:
        if '?page=' in url:
            url = url.replace('?page=','?page=%d' %page)
        else:
            url = url + '?page=%d' %page    
    html=getUrl(url)
    
    kuk=cookieString(COOKIEFILE)    
    out=[]
    sout=[]

    prevpage=False
    nextpage=False 
    if html.find('rel="next"')>0:
        nextpage = page+1
    
    links = parseDOM(html, 'div', attrs={'class': "ml-item"}) 

    for link in links:

        link=replaceHTMLCodes(link)
        imag= parseDOM(link, 'img', ret='src')#[0]
        if not imag:
            imag= parseDOM(link, 'img', ret='data-original')
        imag = imag[0] if imag else ''
        imag = 'https://govod.tv'+imag if imag.startswith('/') else imag
        title = parseDOM(link, 'h3')[0]
        dane = parseDOM(link, 'div', attrs={'class': "jtip-top"}) 
        menu = 'usun' if '/ulubione' in url else 'dodaj'
        menu = '' if addon.getSetting('logged') == 'false' else menu
        if dane:
            year = re.findall('rel="tag">([^<]+)<',dane[0])
            year = year[0] if year else ''
            rate =re.findall('(?:Filmweb\:|IMDb\:|Portal\:)\s*(.+?)<\/div',dane[0])
            try:
                rating = float(rate[0]) if rate else ''
            except:
                rating = ''
        try:
            jezyk = re.findall('33ff0069">([^<]+)',link,re.DOTALL)[0]
            dod = ' [COLOR yellowgreen](%s)[/COLOR]'%(jezyk)

        except:
            jezyk = ''
            dod = ''
        plot = parseDOM(link, 'p')
        plot =plot[0] if plot else ''
        durat = re.findall('"jt-info">\s*(\d+)\s*min',link)
        durat = int(durat[0])*60 if durat else ''

        country = re.findall('Kraj:\s*.*?rel="tag">([^<]+)<',link)
        country = country[0] if country else ''

        genres = re.findall('category tag">([^<]+)<',link)

        kateg = ','.join([(x.strip()).lower() for x in genres]) if genres else ''        
        href = parseDOM(link, 'a', ret='href')[0]
        href = BASE_URL +href if href.startswith('/') else href

        ulub = parseDOM(link, 'a', ret='data-href')#[0]
        ulub = ulub[0] if ulub else href.split('/')[-1]
        if '/film/' in href:
            out.append({'title':PLchar(title),'href':PLchar(href),'img':PLchar(imag),'menu':menu, 'fav':ulub, 'plot':PLchar(plot),'genre':PLchar(kateg),'year':year, 'duration':durat,'rating':rating, 'country':PLchar(country),'code':jezyk})
        else:
            sout.append({'title':PLchar(title)+PLchar(dod),'href':PLchar(href),'img':PLchar(imag),'menu':menu, 'fav':ulub, 'plot':PLchar(plot),'genre':PLchar(kateg),'year':year, 'duration':durat,'rating':rating, 'country':PLchar(country),'code':jezyk})
        
    prevpage = page-1 if page>1 else False
    return (out,sout, (prevpage,nextpage))

def ListSeasons(exlink):
    links = getSeasons(exlink)
    try:
        ab= links[0].get('href', None)
    except:
        ab=''
    if 'pusto' in ab:
        items = len(links)
        link = ab.split('|')[0]
        mud='getLinks'
        fold=False
        for f in links:
            add_item(name=f.get('title'), url=link, mode=mud, image=f.get('img'), folder=fold, fav=f.get('fav'), context=[f.get('menu')],isplay=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'rating':f.get('rating'),'genre':f.get('genre'),'country':f.get('country'),'duration':f.get('duration'),'code':f.get('code')},  itemcount=items)                        
        typ ='videos' if widok=='true' else 'movies'
        xbmcplugin.setContent(addon_handle, typ)    

    else:
        items = len(links)
        for i in sorted(links.keys()):
            add_item(name=name+' - '+i, url=quote(str(links[i])), mode='listepisodes', image=rys, folder=True,  infoLabels=i, itemcount=items)  
        typ ='videos' if widok=='true' else 'tvshows'	
        xbmcplugin.setContent(addon_handle, typ)    
    xbmcplugin.endOfDirectory(addon_handle,True)
        
def ListEpisodes(exlink):

    episodes = eval(unquote(exlink))[::-1]
    items=len(episodes)
    for f in episodes: 
        ses=f.get('season')
        epp=f.get('episode')
        tyt=f.get('title').split('Season')[0]
        tyt2 = '%s - odc.%02d'%(name,epp)
        add_item(name=tyt2, url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels={'title':f.get('title'),'plot':f.get('plot'),'year':f.get('year'),'rating':f.get('rating'),'genre':f.get('genre'),'country':f.get('country'),'duration':f.get('duration'),'code':f.get('code')}, itemcount=items)
 
    typ ='videos' if widok=='true' else 'episodes'
    xbmcplugin.setContent(addon_handle, typ)   
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_EPISODE, label2Mask = "%R, %Y, %P")
    xbmcplugin.endOfDirectory(addon_handle)    

def splitToSeasons(input):
    out={}
    seasons = [x.get('season') for x in input]
    for s in set(seasons):
        out['Sezon %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
    return out    
    
def getSeasons(url):
    html=getUrl(url)

    out=[]
    result = parseDOM(html, 'div', attrs={'class': "mvic-desc"})[0] 
    nazwt = parseDOM(result, 'h1')[0]
    genres = re.findall('category tag">([^<]+)<',result)
    kateg = ','.join([(x.strip()).lower() for x in genres]) if genres else ''    

    kraj = re.findall('Kraj\:(.*?)<\/p>',result,re.DOTALL)
    try:
        jezyk = re.findall('33ff0069">([^<]+)',html,re.DOTALL)[0]
        dod = ' [COLOR yellowgreen](%s)[/COLOR]'%(jezyk)
    
    except:
        jezyk = ''
        dod = ''

    country=''
    if kraj:
        country = re.findall('rel="tag">([^<]+)<',kraj[0])
    country=country[0] if country else ''
    durat = re.findall('"duration">(\d+)\smin',result)
    durat = int(durat[0])*60 if durat else ''

    opisplot = parseDOM(html, 'div', attrs={'itemprop': "description","class":"desc"})#[0]
    opisplot = opisplot[0] if opisplot else ''

    plot = parseDOM(opisplot, 'p', attrs={'class': "f-desc"})
    plot = plot[0] if plot else ''
    yeard = re.findall('rok produkcji:(.*?)<\/p>',result,re.DOTALL+re.I)
    year =''
    if yeard:
        year = re.findall('rel="tag">([^<]+)<',yeard[0])
        year = year[0] if year else ''
    
    rate=re.findall('class="imdb-r">([^<]+)<',result)
    
    try:
        rating = float(rate[0]) if rate else ''
    except:
        rating = ''

    episodes=[]
    links=parseDOM(html, 'div', attrs={'class':"seasons"}) 
    if not links:
        episodes.append({'title':name,'href':url+'|pusto','img':rys,'plot':PLchar(plot),'genre':PLchar(kateg),'year':year, 'duration':durat,'rating':rating, 'country':PLchar(country), 'code':jezyk})

        return     episodes
    else:    
        for link in links:
            subdata = parseDOM(link, 'tbody')[0]
    
            eps = parseDOM(subdata, 'tr')
            for ep in eps:
    
                href = parseDOM(ep, 'a', ret='data-href')[0]
                href = BASE_URL + href if href.startswith('/') else href
                
                ses = parseDOM(ep, 'a', ret='data-season')[0] 
                epis = parseDOM(ep, 'a', ret='data-episode')[0] 
                
                #href = 'idhash:%s|%s'%(href)
                tyt = parseDOM(ep, 'td')[0]
                href=href+'|'+url if 'govod.tv/player/' in href else href
                tyt = nazwt+' - '+tyt
    
                episodes.append({'title':tyt,'href':href,'img':rys,'plot':PLchar(plot),'genre':PLchar(kateg),'year':year, 'duration':durat,'rating':rating, 'country':PLchar(country),'season':int(ses),'episode':int(epis), 'code':jezyk})
        seasons = splitToSeasons(episodes)
    
    return seasons
    
def getLinks(exlink):
    try:
        exlink,ref = exlink.split('|')
    except:
        exlink = exlink
    exlink = BASE_URL + exlink if exlink.startswith('/') else exlink
    if not 'govod.tv/player/' in exlink:
		
        html=getUrl(exlink)
        stream=''
        
        movieplay = parseDOM(html, 'div', attrs={'class':"movieplay"}) 
        if movieplay:

            iframe = parseDOM(movieplay[0], 'iframe', ret='src')
    
            xbmc.sleep(1000)
            if not iframe and logged =='false':
                xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Wymagane jest zalogowanie.',xbmcgui.NOTIFICATION_INFO, 6000,False)
                sys.exit(0)

            else:
                if iframe:
                    nturl = BASE_URL+iframe[0] if iframe else ''
                    html=getUrl(nturl,exlink)
                    html = html if PY3 else html.encode('utf-8') 
                    if 'Limit osób zalogowanych jednocześnie do portalu został przekroczony. </p><p>Wyloguj się z innych urządzeń, aby korzystać z naszego serwisu!' in html :
                        xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Limit osób zalogowanych jednocześnie do portalu został przekroczony.\n Wyloguj się z innych urządzeń, aby korzystać z naszego serwisu! ',xbmcgui.NOTIFICATION_INFO, 7000,False)    
                        sys.exit(0)
                    elif 'aktywuj konto premium i ogl' in html.lower():
                        xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Duże obciązenie.\nTylko konta premium.',xbmcgui.NOTIFICATION_INFO, 6000,False)
                        sys.exit(0)
                    stream = parseDOM(html, 'source', ret='src')
                    
                    stream = stream[0].replace('&amp;','&') if stream else ''
                else:
                    xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Brak wideo.',xbmcgui.NOTIFICATION_INFO, 6000,False)
                    sys.exit(0)
        else:
            stream = parseDOM(html, 'source', ret='src')
            stream = stream[0].replace('&amp;','&') if stream else ''
    else:
        html=getUrl(exlink,ref)
        html = html if PY3 else html.encode('utf-8') 
        if 'Limit osób zalogowanych jednocześnie do portalu został przekroczony. </p><p>Wyloguj się z innych urządzeń, aby korzystać z naszego serwisu!' in html:
            xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Limit osób zalogowanych jednocześnie do portalu został przekroczony.\n Wyloguj się z innych urządzeń, aby korzystać z naszego serwisu! ',xbmcgui.NOTIFICATION_INFO, 7000,False)    
            sys.exit(0)

        stream = parseDOM(html, 'source', ret='src')
        
        stream = stream[0].replace('&amp;','&') if stream else ''
    if stream:    
    #    stream+='|User-Agent='+quote(UA)+'&Referer='+quote(exlink)
        hd= 'User-Agent='+quote(UA)+'&Referer='+quote(exlink)
        if '.mp4' in stream:
            stream+='|'+hd
		#else:
        play_item = xbmcgui.ListItem(path=stream,label=name)
        
        play_item.setProperty("IsPlayable", "true")
        opisb.update({"title": name})
        play_item.setInfo(type="Video", infoLabels=opisb)
        
        play_item.setArt({'thumb': rys, 'poster': rys, 'banner': rys, 'fanart': FANART})
        if not '.mp4' in stream:
            if PY3:
                play_item.setProperty('inputstream', 'inputstream.adaptive')
            else:
                play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.stream_headers', hd)
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            play_item.setMimeType('application/vnd.apple.mpegurl')
			
			
        Player = xbmc.Player()    
        
        Player.play(stream, play_item)

def Logout():
    addon.setSetting('logged', 'false')
    sess.cookies.clear()
    sess.cookies.save(COOKIEFILE, ignore_discard = True)
    xbmc.executebuiltin('Container.Refresh()')
def LogIn():
    addon.setSetting('logged', 'true')

    xbmc.executebuiltin('Container.Refresh()')    
    
def PLchar(char):
    if type(char) is not str:
        char=char.encode('utf-8')
    char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
    char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
    char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
    char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
    char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
    char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
    char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
    char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
    char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
    char = char.replace('&#8217;',"'")
    char = char.replace('&#8211;',"-")    
    char = char.replace('&#8230;',"...")        
    char = char.replace('&quot;','"')    
    char = char.replace('&#039;',"'")    
    char = char.replace('Napisy PL',"[COLOR lightblue](napisy pl)[/COLOR]")
    char = char.replace('Lektor PL',"[COLOR lightblue](lektor pl)[/COLOR]")
    char = char.replace('Dubbing PL',"[COLOR lightblue](dubbing pl)[/COLOR]")    
    return char    

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    logged = addon.getSetting('logged')
    if params:    
        mode = params.get('mode', None)
        if mode == 'listmovies':
            ListMovies(exlink,page)
        
        elif mode == 'listseasons':
            ListSeasons(exlink)            
        elif mode =='listepisodes':
            ListEpisodes(exlink)        
        
        elif mode == 'getLinks':
            getLinks(exlink)    
        
        elif mode == 'settings':
            addon.openSettings()
            xbmc.executebuiltin('Container.Refresh()')   
        
        elif mode == 'settings2':
            addon.openSettings()
            xbmc.executebuiltin('Container.Refresh()')   
        elif mode == '__page__M':
            url = build_url({'mode': 'listmovies',  'url' : exlink, 'page' : page})  
            xbmc.executebuiltin('Container.Refresh(%s)'% url)           
            xbmcplugin.endOfDirectory(addon_handle,True)    
         
        elif mode=='search':
            query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł:', type=xbmcgui.INPUT_ALPHANUM)
            if query: 
                link = 'https://govod.tv/szukaj?s='+query.replace(' ','+')
                ListMovies(link,1)
        
                    
        elif mode =='dodaj':
            DodajUlub(favorite)
            xbmc.executebuiltin('Container.Refresh()')
        elif mode =='usun':
            DodajUlub(favorite)
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'listcateg':
            ListCateg()
            
        elif mode=='logout':
            Logout()
        elif mode=='zaloguj':
            LogIn()    
    else:
        home()
                            
if __name__ == '__main__':
    router(sys.argv[2][1:])    
