# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl

import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import resolveurl as urlresolver

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.plusfilm')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=PATH+'fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('title', None)
page = params.get('page',[1])[0]

UA='Mozilla/5.0 (Linux; Android 7.0; PLUS Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36'
TIMEOUT=15

headers = {'User-Agent': UA,}
s = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=1):
	list_item = xbmcgui.ListItem(label=name)

	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')
		
	if not infoLabels:
		infoLabels={'title': name}
	list_item.setInfo(type="video", infoLabels=infoLabels)		
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	
def home():
	add_item('https://plusfilm.pl/serial/', 'Seriale', RESOURCES+'Seriale.png', True, "listserials")
	add_item('https://plusfilm.pl/film/', 'Filmy', RESOURCES+'Filmy.png', True, "listmovies")	
	add_item('kategorie:', '    kategorie', RESOURCES+'Filmy.png', True, "gatunek")		
	add_item('data produkcji:', '    rok', RESOURCES+'Filmy.png', True, "gatunek")				
	add_item('', '[COLOR lightblue]Szukaj[/COLOR]', '', True, "search")		

def getUrlReq(url):
	content=s.get(url, headers=headers,verify=False).text	
	return content	
	
def ListMovies(exlink,page):
	page = int(page) if page else 1	
	links,pagin = getMovies(exlink,page)
	if pagin[0]:
		add_item(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[0])	
	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)							
	if pagin[1]:
		add_item(name='[COLOR blue]>> Nastepna strona >>>[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[1])
	xbmcplugin.setContent(addon_handle, 'videos')	

def ListSerials(exlink):
	links = getSerials(exlink)
	itemz=links
	items = len(links)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listEpisodes', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)							
	xbmcplugin.setContent(addon_handle, 'videos')	

def getMovies(url,page=1):
	
	if page>1:
		if '?tags=' in url or '?q=' in url:
			url=url+'&page=%d'%page
		url = url + '/page/%d' %page	
	else:
		url=url		
	html=getUrlReq(url)
	out=[]
	serout=[]
	if '&tags=' in url or '?q=' in url:
		links = parseDOM(html, 'li', attrs={'data-timestamp': ".+?"})  #	
	else:
		links = parseDOM(html, 'article', attrs={'class': ".+?"})  #	
	prevpage=False #gr=False
	nextpage=False  # pr=False	
	if html.find('ipsPagination_next')>0:
		nextpage = page+1
	for link in links:
		try:
			imag= (parseDOM(link, 'img', ret='src')[2])#.replace('-130x73','')
			title= parseDOM(link, 'a')[1]    
			href = parseDOM(link, 'a', ret='href')[1]
			plot = parseDOM(link, 'section', attrs={'class': ".+?"})[0].replace('<br>','')		
			if 'Ankieta' in plot:
				continue	
		except:
			try:
				imag= parseDOM(link, 'img', ret='src')[1]#.replace('-130x73','')
			except:
				imag=''
			title= parseDOM(link, 'a')[1]    
			href = parseDOM(link, 'a', ret='href')[1]
			if 'serial/' in href:
				tyt2= parseDOM(link, 'a')[3]  
				title='%s - %s'%(tyt2,title)
			plot = re.findall('data-findTerm>(.+?)<',link,re.DOTALL)
			plot=plot[0] if plot else ''
			if 'Ankieta' in plot:
				continue		
		out.append({'title':PLchar(title),'href':href,'img':imag,'plot':plot})		
	prevpage = page-1 if page>1 else False
	return (out,(prevpage,nextpage))

def getSerials(url):	
	html=getUrlReq(url)

	serout=[]
	links = parseDOM(html, 'li', attrs={'data-categoryID': ".+?"})  
	for link in links:

		imag= ''
		title= parseDOM(link, 'a')[0]    
		href = parseDOM(link, 'a', ret='href')[0]
		plot1 = parseDOM(link, 'dl', attrs={'class': "ipsDataItem_stats ipsDataItem_statsLarge"}) 
		plot=''
		if plot1:	
			plot=re.findall('>([^>]+)</dt>',plot1[0])[0].strip()
			plot = u'Odcinków: %s'%plot
			
		serout.append({'title':PLchar(title),'href':href,'img':imag,'plot':plot})		
	return (serout)	

def ListEpisodes(exlink):
	links = getEpisodes(exlink)	
	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)							
	xbmcplugin.setContent(addon_handle, 'videos')	

def getEpisodes(url):	
	html=getUrlReq(url)
	plots=re.findall('"description" content="([^"]+)"',html)
	plot=''
	if plots:
		plot=plots[0]
	
	serout=[]
	links = parseDOM(html, 'li', attrs={'data-rowID': ".+?"})  
	for link in links:

		imag= ''
		title= parseDOM(link, 'a')[0]    
		href = parseDOM(link, 'a', ret='href')[0]
		
		serout.append({'title':PLchar(title),'href':href,'img':imag,'plot':plot})		
	return (serout)	
		
def getRodzinne(url):
	r = s.get(url=url, headers=headers, allow_redirects=False,verify=False)	
	strm = r.headers['Location']
	return strm

def getLinks(exlink):
	links=getVideosOk(exlink)
	if len(links)>1:
		linksAllb = [x.get('host') for x in links]
		s = xbmcgui.Dialog().select('Linki',linksAllb)	
	else:
		s=0
	hrefs=links[s].get('href') if s>-1 else quit()
	host=links[s].get('host') if s>-1 else quit()	
	if 'rodzinnekino.com' in hrefs:	
		stream=getRodzinne(hrefs)
	else:
		stream=hrefs
	try:
		stream_url = urlresolver.resolve(stream)
	except Exception,e:
			stream_url=''
			s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link bedzie działał?','ERROR: %s'%str(e))	
	if stream_url:	
		play_item = xbmcgui.ListItem(path=stream_url)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
	else:
		play_item = xbmcgui.ListItem(path='')
		xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)		
	
def getVideosOk(url):
	html=getUrlReq(url)	
	hreftyp=re.findall('<a class="myButton" href="(.+?)" target=".+?>(.+?)</a>',html,re.DOTALL)
	out=[]
	import urlparse
	for href,typ in hreftyp:	
		host = urlparse.urlsplit(href).netloc
		typ='%s (%s)'%(host,typ)
		film = {'href' : href,'host' : typ,}
		out.append(film)
	return out

def ListSearch(exlink,page):
	page = int(page) if page else 1	
	links,pagin = getSearch(exlink,page)
	if pagin[0]:
		add_item(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__S', image='', folder=True, page=pagin[0])	
	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)							
	if pagin[1]:
		add_item(name='[COLOR blue]>> Nastepna strona >>>[/COLOR]', url=exlink, mode='__page__S', image='', folder=True, page=pagin[1])
	xbmcplugin.setContent(addon_handle, 'videos')		
def getSearch(quer,page=1):
	url = 'https://videopenny.net/page/%d' %page +quer	
	html=getUrlReq(url)
	out=[]
	serout=[]	
	if html:
		links = parseDOM(html, 'div', attrs={'id': "post-\d+"})  #
		prevpage=False #gr=False
		nextpage=False  # pr=False	
		if html.find('class="nextpostslink"')>0:
			nextpage = page+1
		for link in links:
			dotyt = parseDOM(link, 'h3') [0]  
			imag= parseDOM(link, 'img', ret='src')[0]
			title= parseDOM(dotyt, 'a',ret='title')[0]    
			href = parseDOM(link, 'a', ret='href')[0]
			plot = parseDOM(link, 'p')[0]	
			out.append({'title':PLchar(title),'href':href,'img':imag,'plot':PLchar(plot)})
	prevpage = page-1 if page>1 else False
	return (out,(prevpage,nextpage))	
	
def getGatunek(exlink):
	out=[]
	url='https://plusfilm.pl/film/'
	html=getUrlReq(url)
	if 'data p' in exlink:
		k=0
	else:
		k=1
	result = parseDOM(html, 'table')[k]
	
	links = re.findall('rel="">(.+?)</a>',result,re.DOTALL)#parseDOM(result, 'li')
	for link in links:	
		if k:
			url='https://plusfilm.pl/search/?&tags=%s&search_and_or=or&sortby=relevancy'%link		
		else:
		
			url='https://plusfilm.pl/search/?q=%s&amp;search_and_or=or&amp;search_in=titles&amp;sortby=newest'%link
		out.append((PLchar(link), url))	
	return out		
	
def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	return char	

if __name__ == '__main__':
	mode = params.get('mode', None)
	if not mode:
		home()
	elif mode == 'listmovies':
		ListMovies(exlink,page)
		xbmcplugin.setContent(addon_handle, 'videos')
		
	elif mode == 'listserials':
		ListSerials(exlink)
		xbmcplugin.setContent(addon_handle, 'videos')		
		
	elif mode == 'getLinks':
		getLinks(exlink)	
	elif mode == 'listserials':
		ListSerials(exlink,page)
		xbmcplugin.setContent(addon_handle, 'videos')
		
	elif mode == 'listEpisodes':
		ListEpisodes(exlink)
		xbmcplugin.setContent(addon_handle, 'videos')		
		
		
		
	elif mode == 'gatunek':
		data = getGatunek(exlink)
		par= exlink.split('|')
		if data:
			label = [x[0].strip() for x in data]
			url = [x[1].strip() for x in data]
			s = xbmcgui.Dialog().select('Wybierz '+par[0],label)
			if s>-1:
				
				url = build_url({'mode': 'listmovies', 'foldername': name, 'url' : url[s]})
				xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)				
	elif mode == '__page__M':
		url = build_url({'mode': 'listmovies', 'foldername': name, 'url' : exlink, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
	elif mode == '__page__S'	:
		url = build_url({'mode': 'listsearch', 'foldername': name, 'url' : exlink, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)		
	elif mode=='listsearch':	
		ListSearch(exlink,page)
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			ListMovies('https://plusfilm.pl/search/?q=%s'%query,1)
			xbmcplugin.setContent(addon_handle, 'videos')
xbmcplugin.endOfDirectory(addon_handle)
