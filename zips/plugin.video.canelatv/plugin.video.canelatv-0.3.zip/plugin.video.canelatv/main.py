# -*- coding: UTF-8 -*-

import sys,re, ast , json
import six
from six.moves import urllib_parse

import requests
from requests.compat import urlparse
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc, xbmcvfs
import time

if six.PY3:
    basestring = str
    unicode = str
    xrange = range
    from resources.lib.cmf3 import parseDOM
else:
    from resources.lib.cmf2 import parseDOM
sess = requests.Session()    

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(urllib_parse.parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.canelatv')

PATH            = addon.getAddonInfo('path')
if six.PY2:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
else:
    DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))

RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'../fanart.jpg'
ikona =RESOURCES+'../icon.png'

exlink = params.get('url', None)
nazwa= params.get('title', None)
rys = params.get('image', None)

try:
    inflabel = ast.literal_eval(params.get('ilabel', None))
except:
    inflabel = params.get('ilabel', None)
    
page = params.get('page',[1])[0]
authtoken = addon.getSetting('canelatoken')
UAx = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0'
headers = {
    'Host': 'api-ott.canela.tv',
    'user-agent': UAx,
    'accept': '*/*',
    'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
    'ottera-referrer': 'canela.tv',
    'ottera-cs-auth': authtoken,
    'origin': 'https://www.canela.tv',
    'dnt': '1',
    'referer': 'https://www.canela.tv/',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
}





def build_url(query):
    return base_url + '?' + urllib_parse.urlencode(query)

def add_item(url, name, image, mode, itemcount=1, page=1,fanart=FANART, infoLabels=False,contextmenu=None,IsPlayable=False, folder=False):

    if six.PY3:    
        list_item = xbmcgui.ListItem(name)

    else:
        list_item = xbmcgui.ListItem(name, iconImage=image, thumbnailImage=image)
    if IsPlayable:
        list_item.setProperty("IsPlayable", 'True')    
        
    if not infoLabels:
        infoLabels={'title': name}    
    list_item.setInfo(type="video", infoLabels=infoLabels)    
    list_item.setArt({'thumb': image,'icon': image,  'poster': image, 'banner': image, 'fanart': fanart})
    
    if contextmenu:
        out=contextmenu
        list_item.addContextMenuItems(out, replaceItems=True)

    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url = build_url({'mode': mode, 'url' : url, 'page' : page, 'title':name,'image':image, 'ilabel':infoLabels}),            
        listitem=list_item,
        isFolder=folder)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
    
def resp_text(resp):
    """Return decoded response text."""
    
    if resp and resp.headers.get('content-encoding') == 'br':
        from resources.lib.brotlipython import brotlidec
        out = []
        # terrible implementation but it's pure Python
        return brotlidec(resp.content, out).decode('utf-8')
    response_content = resp.text

    return response_content.replace("\'",'"')
    
    
def request_sess(url, method='get', data={}, headers={}, result=True, json=False, allow=True , json_data = False):
    if method == 'get':
        resp = sess.get(url, headers=headers, timeout=15, verify=False, allow_redirects=allow)
        
    elif method == 'post':
        if json_data:
            resp = sess.post(url, headers=headers, json=data, timeout=15, verify=False, allow_redirects=allow)
        else:
            resp = sess.post(url, headers=headers, data=data, timeout=15, verify=False, allow_redirects=allow)

    if result:
        return resp.json() if json else resp_text(resp)
    else:
        return resp
        
def home():
    GetToken()
    add_item('', '[COLOR gold][B]Canela.tv[/B][/COLOR]', ikona, "latinohd", folder=True, IsPlayable=False)
    
def GetToken():

    headers = {
        'Host': 'www.canela.tv',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
        'upgrade-insecure-requests': '1',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'cross-site',
        'sec-fetch-user': '?1',
    }

    response = requests.get('https://www.canela.tv/', headers=headers, verify=False)  

    ab = response.text

    js = re.findall('settings-json">({.*?})<\/script>',ab,re.DOTALL)[0]
    js = json.loads(js)
    token = js.get('codesbasePublic', None).get('options', None).get('cs_auth_token', None)
    addon.setSetting('canelatoken',token)
    return



    
def LatinoHd():

    ts = str(int(time.time()))
    url ='https://api-ott.canela.tv/getconfiguration?version=14.0&device_type=desktop&platform=web&partner=internal&language=pl&connection=wifi&timestamp='+ts+'&timezone=0100'
    resp = request_sess(url, 'get', headers=headers, json=True)
    ok = False
    for sect in resp.get("sections", []):
    
        title = sect.get('title', None)
        if 'home_tab' in title:
            continue
        ok =True
        section = sect.get("section", None)

        logo = sect.get('logo', None)
        
        img = 'https://www.canela.tv/themes/custom/cnm/canela_tv/img/logo_alt/{}.png'.format(logo) if logo else ikona
        add_item(section, '[B]'+title+'[/B]', img, "listsubmenulatino",fanart=FANART, folder=True)

    if ok:
        xbmcplugin.endOfDirectory(addon_handle)
    
def checkurl(url):
    resp = request_sess(url, 'get', headers=headers, json=True)
    if len(resp.get("objects", None))>0:
        return True
    return False
    
def ListSubmenuLatino(sct):
    ok = False
    ts = str(int(time.time()))

    url ='https://api-ott.canela.tv/getconfiguration?version=14.0&device_type=desktop&platform=web&partner=internal&language=pl&connection=wifi&timestamp='+ts+'&timezone=0100'
    resp = request_sess(url, 'get', headers=headers, json=True)
    ok = False

    for sect in resp.get("sections", []):
        section = sect.get("section", None)
        if sct == section:

            break
            

    items = sect.get("items", None)
    for item in items:

        title = item.get('title', None)
        endpoint = item.get('endpoint', None)
        parent_id = item.get('parameters', None).get('parent_id', None)
        href = 'https://api-ott.canela.tv/'+endpoint+'?parent_id='+str(parent_id)+'&platform=web&timestamp='+str(int(time.time()))+'&timezone=0100&version=14.0'
        obj = checkurl(href)
        if obj:
            add_item(href, '[B]'+title+'[/B]', rys, "listcontent",fanart=FANART, folder=True)
            ok = True
    if ok:
        xbmcplugin.endOfDirectory(addon_handle)
        
def ListContent(url):
    resp = request_sess(url, 'get', headers=headers, json=True)
    ok = False
    objects = resp.get("objects", None)
    
    for ob in objects:
        typ = ob.get("type", None)
        idx = ob.get("id", None)

        ispla = True
        fold = False
        mod ='playvid'
        if 'epg_' in idx:
            idx1 = ob.get("link", None)
            idx = str(re.findall('(\d+)',idx1,re.DOTALL)[0])

            
        if typ == 'video':
            ispla = True
            fold = False
            idx = ob.get("id", None)

            mod ='playvid'
        elif typ =='show':
            ispla = False
            fold = True
            idx = 'https://www.canela.tv' + ob.get("url", None)
            mod ='listserial'
        elif typ =='character':
            ispla = False
            fold = True

            idx = urllib_parse.quote_plus(str(ob.get("packages", None)))
            mod ='listcharacter'
        title = ob.get("name", None)
        if ob.get("segment_start_time", None):
            from datetime import datetime
            st = ob.get("segment_start_time", None)
            en = ob.get("segment_end_time", None)
            st = datetime.fromtimestamp(int(st))
            czasst=st.strftime('%H:%M')
            en = datetime.fromtimestamp(int(en))
            czasen=en.strftime('%H:%M')
            title += ' [COLOR gold]({} - {})[/COLOR]'.format(czasst,czasen)
            
            avcvc=''
        desc = ob.get("long_description", None)
        logo = ob.get("logo", None)
        thumbnail_url = ob.get("thumbnail_url", None)
        if logo or thumbnail_url:
            img = logo if logo else thumbnail_url
        else:
            img = rys
        ilab = {'title':title, 'icon': img, 'plot':desc}
        
        add_item(idx, '[B]'+title+'[/B]', img, mod,fanart=FANART, infoLabels=ilab, folder=fold, IsPlayable=ispla)
        ok = True
    if ok:
        xbmcplugin.endOfDirectory(addon_handle)
        
def ListSerial(url):
    headers.pop('ottera-cs-auth')
    headers.pop('ottera-referrer')
    headers.pop('Host')
    html = request_sess(url, 'get', headers=headers)    

    dataseasons = parseDOM(html, 'div', attrs={'class': "show\-\-seasons"})[0]
    h2s = parseDOM(dataseasons, 'h2')
    seasons = parseDOM(html, 'div', attrs={'class': "show\-\-season\-episodes"})
    out =[]
    for i, season in enumerate(seasons):
        sestitle = h2s[i]
        for epis in parseDOM(season, 'div', attrs={'class': "show\-\-season\-\-episode"}):
            
            film = {
                'href'  : re.findall('ottera\-id="([^"]+)"', epis, re.DOTALL)[0],

                'dataseasepis': re.findall('href="([^"]+)"', epis, re.DOTALL)[0],
                'title' : parseDOM(epis, 'h3')[0], 
                'img' :  parseDOM(epis, 'img', ret='src')[0]}
            out.append(film)
        title = nazwa+' - '+sestitle
        ilab = {'title':title, 'icon': rys, 'plot':title}
        add_item(urllib_parse.quote_plus(str(out)), title, rys, 'listepisodes' ,fanart=FANART, infoLabels=ilab, folder=True, IsPlayable=False)
    xbmcplugin.endOfDirectory(addon_handle)

def ListEpisodes(data):
    episodes = ast.literal_eval(urllib_parse.unquote_plus(data))
    for epis in episodes:
        dataseasepis = epis.get('dataseasepis', None)
        ses,ep = re.findall('(\d+)',dataseasepis)
        t1 = epis.get('title', None)
        img = epis.get('img', None)
        t2 = re.findall('^(.*?\[\/B\])',nazwa,re.DOTALL)[0]
        title = t2+ ' - '+t1 + ' [COLOR khaki](S%02dE%02d)[/COLOR] '%(int(ses),int(ep))
        idx = epis.get('href', None)

        ilab = {'title':title, 'icon': img, 'plot':title}
        add_item(idx, title, img, 'playvid' ,fanart=FANART, infoLabels=ilab, folder=False, IsPlayable=True)
    xbmcplugin.endOfDirectory(addon_handle)
    
def PlayVid(idx):

    ts = str(int(time.time()))
    url = 'https://api-ott.canela.tv/embeddedVideoPlayer?version=14.0&device_type=desktop&platform=web&partner=internal&div_id=video_player&id={}&timestamp={}'.format(idx,ts)

    
    html = request_sess(url, 'get', headers=headers)    
    stream_url = re.findall('playersources.*?url\:\s*"([^"]+)"',html, re.DOTALL+re.I)

    if stream_url:

        stream_url = request_sess(stream_url[0], 'get', headers=headers, result=False).url

        import inputstreamhelper    
        is_helper = inputstreamhelper.Helper('hls')
        if is_helper.check_inputstream():

            play_item = xbmcgui.ListItem(path=stream_url+'|User-Agent='+UAx)
            if sys.version_info[0] > 2:
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
            else:
                play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)

            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            play_item.setMimeType('application/x-mpegurl')

            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item) 
            
def ListCharacter(data):

    ts = str(int(time.time()))
    packages = ast.literal_eval(urllib_parse.unquote_plus(data))
    for ob in packages:
        typ = ob.get("type", None)

        if typ == 'video':
            ispla = True
            fold = False
            idx = ob.get("id", None)
            mod ='playvid'
        elif typ =='show':
            ispla = False
            fold = True
            idx = 'https://www.canela.tv' + ob.get("url", None)
            mod ='listserial'
        elif typ =='character':
            ispla = False
            fold = True

            idx = urllib_parse.quote_plus(str(ob.get("packages", None)))
            mod ='listcharacter'
        elif typ =='collection':
            ispla = False
            fold = True
            id_ = ob.get("id", None)
            idx = 'https://api-ott.canela.tv/getreferencedobjects?&connection=wifi&device_type=desktop&group_by=video_type&group_filter=feature&image_format=widescreen&image_width=640&language=pl&parent_id={}&parent_type=collection&partner=internal&platform=web&timestamp={}&timezone=0100&use_device_width_widescreen=0&version=14.0'.format(str(id_), ts)

            mod ='listcontent'

        title = ob.get("name", None)
        desc = ob.get("long_description", None)
        logo = ob.get("logo", None)
        thumbnail_url = ob.get("thumbnail_url", None)
        if logo or thumbnail_url:
            img = logo if logo else thumbnail_url
        else:
            img = rys
        ilab = {'title':title, 'icon': img, 'plot':desc}
        
        add_item(idx, '[B]'+title+'[/B]', img, mod,fanart=FANART, infoLabels=ilab, folder=fold, IsPlayable=ispla)
        ok = True
    if ok:
        xbmcplugin.endOfDirectory(addon_handle)
def router(paramstring):
    params = dict(urllib_parse.parse_qsl(paramstring))
    if params:    
        mode = params.get('mode', None)

        if mode == 'latinohd':
            LatinoHd()
            
        elif mode =='listsubmenulatino':
            ListSubmenuLatino(exlink)
        elif mode =='listplaylatino':
            ListPlayLatino(exlink)
        elif mode =='listcontent':
            ListContent(exlink)
            
        elif mode == 'playvid':
            PlayVid(exlink)  

        elif mode == 'listserial':
            ListSerial(exlink)   
        elif mode == 'listepisodes':
            ListEpisodes(exlink)  
        elif mode == 'listcharacter':
            ListCharacter(exlink) 
            
    else:
        home()
        xbmcplugin.endOfDirectory(addon_handle)    
if __name__ == '__main__':
    router(sys.argv[2][1:])