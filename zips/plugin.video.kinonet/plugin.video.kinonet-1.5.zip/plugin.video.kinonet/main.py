# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import urlparse
import urllib
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import base64
import cookielib
from CommonFunctions import parseDOM
import resolveurl as urlresolver

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.kinonet')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )
main_url='http://kinonet.pl'
kukz=''

from aadecode import AADecoder
import recaptcha
exlink = params.get('url', None)
name= params.get('title', None)
page = params.get('page',[1])[0]

sortv = addon.getSetting('sortV')
sortn = addon.getSetting('sortN') if sortv else 'Data dodania - rosnąco'

katv = addon.getSetting('katV')
katn = addon.getSetting('katN') if katv else 'Wszystkie'

werv = addon.getSetting('werV')
wern = addon.getSetting('werN') if werv else 'Wszystkie'

latv = addon.getSetting('latV')
latn = addon.getSetting('latN') if latv else 'Wszystkie'

UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0'

headers = {
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'TE': 'Trailers',
}
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

	
	
def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=1,fanart=FANART,moviescount=0):
	list_item = xbmcgui.ListItem(label=name)

	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')
	if not infoLabels:
		infoLabels={'title': name,'plot':name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': FANART})
	ok=xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page, 'moviescount' : moviescount,'movie':movie,'name':name,'image':image}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	return ok
	

def home():
	login()

	add_item('', "[COLOR lightblue]Wersja językowa:[/COLOR] [B]"+wern+"[/B]",'DefaultRecentlyAddedMovies.png', 'setVer:wer', folder=False,fanart=FANART)
	add_item('', "[COLOR lightblue]Gatunki:[/COLOR] [B]"+katn+"[/B]",'DefaultRecentlyAddedMovies.png', 'setVer:kat', folder=False,fanart=FANART)
	add_item('', "[COLOR lightblue]Rok wydania:[/COLOR] [B]"+latn+"[/B]",'DefaultRecentlyAddedMovies.png', 'setVer:lat', folder=False,fanart=FANART)
	add_item('https://filme.pl/filmy', 'Filmy', 'DefaultMovies.png', "listmovies", True)		
	add_item('https://filme.pl/seriale', 'Seriale', 'DefaultTVShows.png', "listmovies", True)		
	add_item('', '[COLOR lightblue]Szukaj[/COLOR]', 'DefaultAddonsSearch.png', "search", True)		
	xbmcplugin.endOfDirectory(addon_handle)
	
def login():
	import requests
	global kukz
	username = addon.getSetting('username')
	password = addon.getSetting('password')
	data = 'login='+username+'&haslo='+password  
	headerslogin = {
		'Host': 'filme.pl',
		'user-agent': UA,
		'accept': 'application/json, text/javascript, */*; q=0.01',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'referer': 'https://filme.pl/',
		'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
		'x-requested-with': 'XMLHttpRequest',
		'dnt': '1',
		'te': 'trailers',
	}

	
	response = requests.post('https://filme.pl/ajax/logged.php', headers=headerslogin, data=data)
	kukz=response.cookies['PHPSESSID']
	return kukz #response.cookies['PHPSESSID']
	
def ListMovies(exlink,page):
	global kukz
	kukz = params.get('sessionid', None)
	links,serials,pagin = getMovies(exlink,page)
	if pagin[0]:
		add_item(name='[COLOR blue]<< poprzednia strona [/COLOR]', url=pagin[0], mode='__page__M', image='', folder=True, page=pagin[0])	
	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, infoLabels=f, itemcount=items, IsPlayable=True)	
	itemz=serials
	items = len(serials)
	mud='getepisodes'
	fold=True
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, infoLabels=f, itemcount=items)						
	if pagin[1]:
		add_item(name='[COLOR blue]>> Nastepna strona [/COLOR]', url=pagin[1], mode='__page__M', image='', folder=True, page=pagin[1])
	
	xbmcplugin.setContent(addon_handle, 'files')	

	xbmcplugin.endOfDirectory(addon_handle)		

def getMovies(url,page=1):
	if not url:
		url='https://filme.pl/filmy-d1,%s,%s,%s-%s'%(werv,katv,latv,page)

	global kukz
	kukz = params.get('sessionid', None)

	r = requests.get(url,verify=False,headers=headers, cookies={'PHPSESSID': kukz})
	html=r.content
	out=[]
	serout=[]
	links = parseDOM(html, 'div', attrs={'class': "p-2 col-lg-3 float-left"})  
	try:
		npage=re.findall('href="(.+?)">.+?<i class="fa fa-angle-right ml-2"></i>',html)[0]
		npage='http://filme.pl'+npage
	except:
		npage=False
	try:	
		ppage=re.findall('href="(.+?)"><i class="fa fa-angle-left mr-2">', html)[0]		
		ppage='http://filme.pl'+ppage
	except:
		ppage=False
	for link in links:
		imag= parseDOM(link, 'img', ret='src')[0]
		title= parseDOM(link, 'h2')[0]    
		href = parseDOM(link, 'a', ret='href')[0]
		plot = parseDOM(link, 'p')[0]		
		genre = parseDOM(link, 'p', attrs={'class': "opis-gatunki"})[0] 
		try:
			code = '[COLOR lightgreen]'+(parseDOM(link, 'span', attrs={'title': "Wersja filmu.+?"})[0].upper())+'[/COLOR]' 
		except:
			code=''
		try:
			year = parseDOM(link, 'span', attrs={'title': "Rok wydania.+?"})[0] 
			year=int(year)
		except:
			year=0000
		if 'seriale' in href:
			serout.append({'title':PLchar(title),'href':href,'img':imag,'plot':PLchar(plot),'genre':genre,'year':year,'code':code})
		else:
			out.append({'title':PLchar(title),'href':href,'img':imag,'plot':PLchar(plot),'genre':genre,'year':year,'code':code})
	return (out,serout,(ppage,npage)) 

def getLinks(exlink):
	global kukz
	kukz = params.get('sessionid', None)
	links=getVideosOk(exlink)
	if links:
		if len(links)>1:
			linksAllb = [x.get('host') for x in links]
			s = xbmcgui.Dialog().select('Linki',linksAllb)	
		else:
			s=0
		hrefs=links[s].get('href') if s>-1 else ''
		host=links[s].get('host') if s>-1 else ''	
	
		if 'seriale-online' in exlink:
			typ='serial'
		else:
			typ='film'
		stream=getStreams(hrefs,typ)
		if stream.startswith('//'):
			stream=stream.replace('//','http://')
	
		if 'upvid.co' in stream:
			stream_url=getUpvid(hrefs)
		else:
			try:
				stream_url = urlresolver.resolve(stream)
			except Exception,e:
				stream_url=''
				s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link bedzie działał?','ERROR: %s'%str(e))	
	
		if stream_url:	
			play_item = xbmcgui.ListItem(path=stream_url)
			xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
		else:
			play_item = xbmcgui.ListItem(path='')
			xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)		
	else:
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak materiałów do wyświetlenia.')	
		quit()
def getStreams(dane,typ):
	global kukz
	kukz = params.get('sessionid', None)
	headers2 = {
	'User-Agent': UA,
	'Accept': '*/*',
	'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
	'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
	'X-Requested-With': 'XMLHttpRequest',
	'Connection': 'keep-alive',}
	
	data = {'query': dane}
	if typ=='serial':
		iframeurl='https://filme.pl/iframe_s.php'
		embedurl='https://filme.pl/embed_s.php?v='
	else:
		iframeurl='https://filme.pl/iframe.php'
		embedurl='https://filme.pl/embed.php?v='	
	response = requests.post(iframeurl, headers=headers2, cookies={'PHPSESSID': kukz}, data=data).content
	nex= re.compile(':"(.*?)"').findall(response)[0].replace('\\','')
	response = requests.get(embedurl+nex, headers=headers, cookies={'PHPSESSID': kukz}).content
	try:
		stream= parseDOM(response, 'iframe', ret='src')[0]
	except:
		cookieJar = cookielib.LWPCookieJar()
		a=recaptcha.performCaptcha(embedurl+nex,cookieJar);
		stream= parseDOM(a, 'iframe', ret='src')[0]
	return stream
	
def getEpisodes(exlink):
	global kukz
	kukz = params.get('sessionid', None)
	links= getSerials(exlink)	
	items = len(links)
	for f in links:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items, IsPlayable=True)		
	xbmcplugin.setContent(addon_handle, 'files')	

	xbmcplugin.endOfDirectory(addon_handle)	
	
def getSerials(url):
	global kukz
	kukz = params.get('sessionid', None)
	out=[]
	r = requests.get(
		url,
		verify=False)
	html=r.content
	imag=parseDOM(html, 'img', ret='src')[2]
	result = parseDOM(html, 'div', attrs={'class': 'tabela_wiersz mb-1'})
	for link in result:
		title = parseDOM(link, 'span', attrs={'class': "tabela_text"})[0] 
		try:
			href = parseDOM(link, 'a', ret='href')[0]
		except:
			pass
		if href and title:
			film = {
				'href'   : main_url+href,
				'title'  : title,
				'img'    : imag,
					}
			out.append(film)		
	return out	

def getUpvid(hrefs):
	r = requests.get(hrefs,verify=False)
	html=r.content	
	iframe=parseDOM(html, 'iframe', ret='src')
	if 'upvid' in iframe[0] :
		url=iframe[0]
		headers1 = {
			'User-Agent': UA,
			'Referer': hrefs,
			'Upgrade-Insecure-Requests': '1',}        
		r = requests.get(url,verify=False,headers=headers1)
		html=r.content
		iframe=parseDOM(html, 'iframe', ret='src')
		if 'upvid' in iframe[0] :
			url2=iframe[0]
			headers2 = {
				'User-Agent': UA,
				'Referer': url,
				'Upgrade-Insecure-Requests': '1',}        
			r = requests.get(url2,verify=False,headers=headers2)
			html=(r.content) #.replace('\n','')   
			print html
			aResult = re.search('id="code".+?value="(.+?)"', html,re.DOTALL)
			if (aResult):
				sFunc = base64.b64decode(aResult.group(1))	
			aResult = re.search('(ﾟωﾟ.+?\(\'_\'\);)', html,re.DOTALL | re.UNICODE)
			
			if (aResult):
				sHtmlContent = AADecoder(aResult.group(1)).decode()
				if sHtmlContent:
					aResult = re.search("func.innerHTML.+?\('(.+?)',", sHtmlContent,re.DOTALL)
					if (aResult):
						chars = aResult.group(1)
						final = sDecode(chars,sFunc)
						sPattern = "source\.setAttribute\('src', '([^']+)'\)"	
						aResult = re.compile("source\.setAttribute\('src', '([^']+)'\)",re.DOTALL).findall(final)
						aResult=aResult[0] #+'|User-Agent='+UA+'&Referer='+url2'
	return aResult

def sDecode(r,o):
    t = []
    e = []
    n = 0
    a = ""
    for f in range(256): 
        e.append(f)

    for f in range(256):
        n = (n + e[f] + ord(r[f % len(r)])) % 256
        t = e[f]
        e[f] = e[n]
        e[n] = t

    f = 0
    n = 0
    for h in range(len(o)):
        f = f + 1
        n = (n + e[f % 256]) % 256
        if not f in e:
            f = 0
            t = e[f]
            e[f] = e[n]
            e[n] = t
            a += chr(ord(o[h]) ^ e[(e[f] + e[n]) % 256])
        else:
            t = e[f]
            e[f] = e[n]
            e[n] = t
            a += chr(ord(o[h]) ^ e[(e[f] + e[n]) % 256])

    return a
		
def getVideosOk(url):
	global kukz
	kukz = params.get('sessionid', None)
	out=[]
	
	r = requests.get(url,verify=False,headers=headers, cookies={'PHPSESSID': kukz})
	try:
		html=r.content
		try:
			mirrory= parseDOM(html, 'div', attrs={'class': 'tabela_zrodla'})[0]
		except:
			mirrory= parseDOM(html, 'article', attrs={'class': 'single-movie'})[1] #<article class="single-movie">
		azs= parseDOM(mirrory, 'div', attrs={'class': 'tabela_wiersz mb-1'})
		for az in azs:
			try:
				href = parseDOM(az, 'div', attrs={'data-player': '.+?'},ret='data-player')[0] #<div data-player="14976"
				hosty = re.findall('class="fa fa-link"></i>(.+?)</span>',az)[0]
				qualwer=re.findall('<span class="tabela_text">(.+?)</span>',az)
				qual = qualwer[0] 
				wersj = qualwer[1] 
				out.append({'href':href,'host':hosty+' '+qual+' '+wersj})
			except:
				pass
	except:
		pass
	return out

def search(q='batman'):
	global kukz
	kukz = params.get('sessionid', None)
	r = requests.get('http://filme.pl/?s='+q,verify=False)
	html=(r.content).replace("<span style='color:red'>"+q+"</span>",q)
	out=[]
	serout=[]
	links = parseDOM(html, 'div', attrs={'class': "p-2 col-lg-2 float-left"})
	for link in links:		
		imag= parseDOM(link, 'img', ret='src')[0]
		href = parseDOM(link, 'a', ret='href')[0] #[1]
		title= parseDOM(link, 'h2')[0]
		plot = parseDOM(link, 'p')[0]
		year = parseDOM(link, 'span', attrs={'title': "Rok wydania.+?"})
		if year:		
			year=int(year[0])
		else:
			year=0000
		if href and title:
			film = {
				'href'   : href,
				'title'  : PLchar(title),
				'plot'   : PLchar(plot),
				'img'    : imag,
				'year'	 : year,
					}
			if 'seriale' in href:
				serout.append(film)	
			else:
				out.append(film)		
	return out,serout
	
def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace("&gt;",">")	
	char = char.replace("&Iacute;","Í").replace("&iacute;","í")
	char = char.replace("&icirc;","î").replace("&Icirc;","Î")
	char = char.replace('&oacute;','ó').replace('&Oacute;','Ó')
	char = char.replace('&quot;','"').replace('&amp;quot;','"')
	char = char.replace('&bdquo;','"').replace('&rdquo;','"')
	char = char.replace("&Scaron;","Š").replace("&scaron;","š")
	char = char.replace("&ndash;","-").replace("&mdash;","-")
	char = char.replace("&Auml;","Ä").replace("&auml;","ä")
	char = char.replace('Napisy PL',"[COLOR lightblue](napisy pl)[/COLOR]")
	char = char.replace('Lektor PL',"[COLOR lightblue](lektor pl)[/COLOR]")
	char = char.replace('Dubbing PL',"[COLOR lightblue](dubbing pl)[/COLOR]")	
	return char	

	
if __name__ == '__main__':
	mode = params.get('mode', None)
	if not mode:
		home()
	elif mode == 'listmovies':
		ListMovies(exlink,page)
	elif mode == 'getLinks':
		getLinks(exlink)	
	elif mode =='getepisodes':
		getEpisodes(exlink)

	elif mode == '__page__M':
		global kukz
		kukz = params.get('sessionid', None)
		url = build_url({'mode': 'listmovies', 'foldername': name, 'url' : exlink, 'sessionid': kukz})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)		
		xbmcplugin.endOfDirectory(addon_handle)
	elif 'setVer' in mode:
		sst = mode.split(":")[-1]
		if 'wer' in sst:
			label=['Wszystkie',	'PL','LEKTOR',	'DUBBING',	'NAPISY',	'NAPISY ENG',	'ENG']
			value=['',			'pl','lektor',	'dubbing',	'napisy',	'napisy eng',	'eng']
		elif 'kat' in sst:
			label=['Wszystkie',	"Animacja","Dokumentalny","Dramat","Egzotyczny","Familijny","Fantasy","Film TV","Historyczny","Horror","Komedia","Kryminał","Muzyczny","Przygodowy","Romantyczny","SciFi","Tajemnica","Thriller","Western","Wojenny"]
			value=['',			"Animacja","Dokumentalny","Dramat","Egzotyczny","Familijny","Fantasy","Film TV","Historyczny","Horror","Komedia","Kryminał","Muzyczny","Przygodowy","Romantyczny","SciFi","Tajemnica","Thriller","Western","Wojenny"]
		elif 'lat' in sst:
			label=['Wszystkie','2019','2018','2017','2016','2015','2014','2013','2012','2011','2010','2009','2008','2007','2006','2005','2004','2003','2002','2001','2000','1999','1998','1997','1996','1995','1994','1993','1992','1991','1990','1989','1988','1987','1986','1985','1984','1981','1980','1979','1977','1976','1975','1974','1973','1971','1970','1969','1968','1966','1963']
			value=['','2019','2018','2017','2016','2015','2014','2013','2012','2011','2010','2009','2008','2007','2006','2005','2004','2003','2002','2001','2000','1999','1998','1997','1996','1995','1994','1993','1992','1991','1990','1989','1988','1987','1986','1985','1984','1981','1980','1979','1977','1976','1975','1974','1973','1971','1970','1969','1968','1966','1963']

		try:
			s = xbmcgui.Dialog().multiselect('Wersja językowa (multiselect)',label)
		except:
			s = xbmcgui.Dialog().select('Wersja językowa',label)
		if not s: quit()#s=0
		if isinstance(s,list):
			if 0 in s: s=[0]
			v = '%s'%(','.join( [ value[i] for i in s])) if s[0]!=0 else ''
			n = ', '.join( [ label[i] for i in s])
		else:
			s = s if s>-1 else quit()
			v = '%s'%value[s]
			n = label[s]
	
		addon.setSetting(sst+'V',v)
		addon.setSetting(sst+'N',n)
		xbmc.executebuiltin('XBMC.Container.Refresh')
		#xbmcplugin.endOfDirectory(addon_handle)
		
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			links,serials=search(query.replace(' ','+') )
			itemz=links
			items = len(links)
			mud='getLinks'
			fold=False
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, infoLabels=f, itemcount=items, IsPlayable=True)	
			itemz=serials
			items = len(serials)
			mud='getepisodes'
			fold=True
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, infoLabels=f, itemcount=items)	
			xbmcplugin.endOfDirectory(addon_handle)	
		else:
			quit()
		

