# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import urlparse
import urllib
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import base64
import cookielib
from CommonFunctions import parseDOM
import resolveurl as urlresolver

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.kinonet')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=PATH+'fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )
main_url='http://kinonet.pl'
kukz=''

from aadecode import AADecoder
import recaptcha
exlink = params.get('url', None)
name= params.get('title', None)
page = params.get('page',[1])[0]
UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0'
headers = {
    'Host': 'kinonet.pl',
    'User-Agent': UA,
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': 'http://kinonet.pl/index.php',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',}

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=1):
	list_item = xbmcgui.ListItem(label=name)

	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')
		
	if not infoLabels:
		infoLabels={'title': name}
	list_item.setInfo(type="video", infoLabels=infoLabels)		
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'foldername': name, 'page' : page, 'sessionid': kukz}),	
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = '%P, %Y')
	
def home():
	login()
	add_item('http://kinonet.pl/filmy', 'Filmy', '', True, "listmovies")	
	add_item('kategorie:|filmy', '    Kategorie Filmów', '', True, "gatunek")		
	add_item('rok:|filmy', '    Rok produkcji', '', True, "gatunek")	
	add_item('wersje:|filmy', '    Wersja językowa', '', True, "gatunek")		
	add_item('http://kinonet.pl/seriale', 'Seriale', '', True, "listmovies")	
	add_item('kategorie:|seriale', '    Kategorie (seriale)', '', True, "gatunek")		
	add_item('rok:|seriale', '    Rok produkcji (seriale)', '', True, "gatunek")	
	add_item('wersje:|seriale', '    Wersja językowa (seriale)', '', True, "gatunek")	
	add_item('', '[COLOR lightblue]Szukaj[/COLOR]', '', True, "search")		
	xbmcplugin.endOfDirectory(addon_handle)
	
def login():
	import requests
	global kukz
	username = addon.getSetting('username')
	password = addon.getSetting('password')
	data = 'login='+username+'&haslo='+password       
	response = requests.post('http://kinonet.pl/ajax/logged.php', headers=headers, data=data)
	kukz=response.cookies['PHPSESSID']
	return kukz #response.cookies['PHPSESSID']
	
def ListMovies(exlink,page):
	page = 1
	global kukz
	kukz = params.get('sessionid', None)
	links,serials,pagin = getMovies(exlink,page)
	if pagin[0]:
		add_item(name='[COLOR blue]<< poprzednia strona [/COLOR]', url=pagin[0], mode='__page__M', image='', folder=True, page=pagin[0])	
	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, infoLabels=f, itemcount=items)	
	itemz=serials
	items = len(serials)
	mud='getepisodes'
	fold=True
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, infoLabels=f, itemcount=items)						
	if pagin[1]:
		add_item(name='[COLOR blue]>> Nastepna strona [/COLOR]', url=pagin[1], mode='__page__M', image='', folder=True, page=pagin[1])
	
	xbmcplugin.setContent(addon_handle, 'files')	

	xbmcplugin.endOfDirectory(addon_handle)		

def getMovies(url,page=1):
	global kukz
	kukz = params.get('sessionid', None)
	r = requests.get(url,verify=False,headers=headers, cookies={'PHPSESSID': kukz})
	html=r.content
	out=[]
	serout=[]
	links = parseDOM(html, 'div', attrs={'class': "p-2 col-lg-3 float-left"})  #p-2 col-lg-3 float-left
	try:
		npage=re.findall('href="(.+?)">.+?<i class="fa fa-angle-right ml-2"></i>',html)[0]
		npage='http://kinonet.pl'+npage
	except:
		npage=False
	try:	
		ppage=re.findall('href="(.+?)"><i class="fa fa-angle-left mr-2">', html)[0]		
		ppage='http://kinonet.pl'+ppage
	except:
		ppage=False
	for link in links:
		imag= parseDOM(link, 'img', ret='src')[0]
		title= parseDOM(link, 'h2')[0]    
		href = parseDOM(link, 'a', ret='href')[0]
		plot = parseDOM(link, 'p')[0]		
		genre = parseDOM(link, 'p', attrs={'class': "opis-gatunki"})[0] #<div class="movie-genres"	
		try:
			code = '[COLOR lightgreen]'+(parseDOM(link, 'span', attrs={'title': "Wersja filmu.+?"})[0].upper())+'[/COLOR]' #  span title="Rok wydania
		except:
			code=''
		try:
			year = parseDOM(link, 'span', attrs={'title': "Rok wydania.+?"})[0] #  span title="Rok wydania
			year=int(year)
		except:
			year=0000
		if 'seriale' in href:
			serout.append({'title':PLchar(title),'href':href,'img':imag,'plot':PLchar(plot),'genre':genre,'year':year,'code':code})
		else:
			out.append({'title':PLchar(title),'href':href,'img':imag,'plot':PLchar(plot),'genre':genre,'year':year,'code':code})
	return (out,serout,(ppage,npage)) #,(popstr,nastr))

def getLinks(exlink):
	global kukz
	kukz = params.get('sessionid', None)
	links=getVideosOk(exlink)
	if links:
		if len(links)>1:
			linksAllb = [x.get('host') for x in links]
			s = xbmcgui.Dialog().select('Linki',linksAllb)	
		else:
			s=0
		hrefs=links[s].get('href') if s>-1 else ''
		host=links[s].get('host') if s>-1 else ''	
	
		if 'seriale-online' in exlink:
			typ='serial'
		else:
			typ='film'
		stream=getStreams(hrefs,typ)
		if stream.startswith('//'):
			stream=stream.replace('//','http://')
	
		if 'upvid.co' in stream:
			stream_url=getUpvid(hrefs)
		else:
			try:
				stream_url = urlresolver.resolve(stream)
			except Exception,e:
				stream_url=''
				s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link bedzie działał?','ERROR: %s'%str(e))	
	
		if stream_url:	
			play_item = xbmcgui.ListItem(path=stream_url)
			xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
		else:
			play_item = xbmcgui.ListItem(path='')
			xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)		
	else:
		xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak materiałów do wyświetlenia.')	
		quit()
def getStreams(dane,typ):
	global kukz
	kukz = params.get('sessionid', None)
	headers = {
	'User-Agent': UA,
	'Accept': '*/*',
	'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
	'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
	'X-Requested-With': 'XMLHttpRequest',
	'Connection': 'keep-alive',}
	
	data = {'query': dane}
	if typ=='serial':
		iframeurl='https://kinonet.pl/iframe_s.php'
		embedurl='https://kinonet.pl/embed_s.php?v='
	else:
		iframeurl='https://kinonet.pl/iframe.php'
		embedurl='https://kinonet.pl/embed.php?v='	
	response = requests.post(iframeurl, headers=headers, cookies={'PHPSESSID': kukz}, data=data).content
	nex= re.compile(':"(.*?)"').findall(response)[0].replace('\\','')
	response = requests.get(embedurl+nex, headers=headers, cookies={'PHPSESSID': kukz}).content
	try:
		stream= parseDOM(response, 'iframe', ret='src')[0]
	except:
		cookieJar = cookielib.LWPCookieJar()
		a=recaptcha.performCaptcha(embedurl+nex,cookieJar);
		stream= parseDOM(a, 'iframe', ret='src')[0]
	return stream
	
def getEpisodes(exlink):
	global kukz
	kukz = params.get('sessionid', None)
	links= getSerials(exlink)	
	items = len(links)
	for f in links:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)		
	xbmcplugin.setContent(addon_handle, 'files')	

	xbmcplugin.endOfDirectory(addon_handle)	
	
def getSerials(url):
	global kukz
	kukz = params.get('sessionid', None)
	out=[]
	r = requests.get(
		url,
		verify=False)
	html=r.content
	imag=parseDOM(html, 'img', ret='src')[2]
	result = parseDOM(html, 'div', attrs={'class': 'tabela_wiersz mb-1'})
	for link in result:
		title = parseDOM(link, 'span', attrs={'class': "tabela_text"})[0] #<div class="mirror-name-odcinki"> 
		try:
			href = parseDOM(link, 'a', ret='href')[0]
		except:
			pass
		if href and title:
			film = {
				'href'   : main_url+href,
				'title'  : title,
				'img'    : imag,
					}
			out.append(film)		
	return out	

def getUpvid(hrefs):
	r = requests.get(hrefs,verify=False)
	html=r.content	
	iframe=parseDOM(html, 'iframe', ret='src')
	if 'upvid' in iframe[0] :
		url=iframe[0]
		headers1 = {
			'User-Agent': UA,
			'Referer': hrefs,
			'Upgrade-Insecure-Requests': '1',}        
		r = requests.get(url,verify=False,headers=headers1)
		html=r.content
		iframe=parseDOM(html, 'iframe', ret='src')
		if 'upvid' in iframe[0] :
			url2=iframe[0]
			headers2 = {
				'User-Agent': UA,
				'Referer': url,
				'Upgrade-Insecure-Requests': '1',}        
			r = requests.get(url2,verify=False,headers=headers2)
			html=(r.content) #.replace('\n','')   
			print html
			aResult = re.search('id="code".+?value="(.+?)"', html,re.DOTALL)
			if (aResult):
				sFunc = base64.b64decode(aResult.group(1))	
			aResult = re.search('(ﾟωﾟ.+?\(\'_\'\);)', html,re.DOTALL | re.UNICODE)
			
			if (aResult):
				sHtmlContent = AADecoder(aResult.group(1)).decode()
				if sHtmlContent:
					aResult = re.search("func.innerHTML.+?\('(.+?)',", sHtmlContent,re.DOTALL)
					if (aResult):
						chars = aResult.group(1)
						final = sDecode(chars,sFunc)
						sPattern = "source\.setAttribute\('src', '([^']+)'\)"	
						aResult = re.compile("source\.setAttribute\('src', '([^']+)'\)",re.DOTALL).findall(final)
						aResult=aResult[0] #+'|User-Agent='+UA+'&Referer='+url2'
	return aResult

def sDecode(r,o):
    t = []
    e = []
    n = 0
    a = ""
    for f in range(256): 
        e.append(f)

    for f in range(256):
        n = (n + e[f] + ord(r[f % len(r)])) % 256
        t = e[f]
        e[f] = e[n]
        e[n] = t

    f = 0
    n = 0
    for h in range(len(o)):
        f = f + 1
        n = (n + e[f % 256]) % 256
        if not f in e:
            f = 0
            t = e[f]
            e[f] = e[n]
            e[n] = t
            a += chr(ord(o[h]) ^ e[(e[f] + e[n]) % 256])
        else:
            t = e[f]
            e[f] = e[n]
            e[n] = t
            a += chr(ord(o[h]) ^ e[(e[f] + e[n]) % 256])

    return a
		
def getVideosOk(url):
	global kukz
	kukz = params.get('sessionid', None)
	out=[]
	
	r = requests.get(url,verify=False,headers=headers, cookies={'PHPSESSID': kukz})
	try:
		html=r.content
		try:
			mirrory= parseDOM(html, 'div', attrs={'class': 'tabela_zrodla'})[0]
		except:
			mirrory= parseDOM(html, 'article', attrs={'class': 'single-movie'})[1] #<article class="single-movie">
		azs= parseDOM(mirrory, 'div', attrs={'class': 'tabela_wiersz mb-1'})
		for az in azs:
			try:
				href = parseDOM(az, 'div', attrs={'data-player': '.+?'},ret='data-player')[0] #<div data-player="14976"
				hosty = re.findall('class="fa fa-link"></i>(.+?)</span>',az)[0]
				qualwer=re.findall('<span class="tabela_text">(.+?)</span>',az)
				qual = qualwer[0] 
				wersj = qualwer[1] 
				out.append({'href':href,'host':hosty+' '+qual+' '+wersj})
			except:
				pass
	except:
		pass
	return out

def getGatunek(exlink):
	out=[]
	global kukz
	kukz = params.get('sessionid', None)
	par= exlink.split('|')
	if 'filmy' in par[1]:
		url_main='http://kinonet.pl/filmy'
	else:
		url_main='http://kinonet.pl/seriale'	
	r = requests.get(url_main,verify=False)
	html=r.content
	if 'kategorie:' in exlink:	
		result = parseDOM(html, 'div', attrs={'class': 'row justify-content-md-center'})[1]
		links = parseDOM(result, 'p')
		
		for link in links:				
			genre = link
			url = url_main+'-d1,'+genre
			genre=genre.upper()
			out.append((genre, url))
	if 'rok:' in exlink:
		result = parseDOM(html, 'div', attrs={'class': 'row justify-content-md-center'})[2]
		links = parseDOM(result, 'p')
		
		for link in links:				
			year = link
			url = url_main+'-d1,'+year
			out.append((year, url))	
	if 'wersje:' in exlink:
		result = parseDOM(html, 'div', attrs={'class': 'row justify-content-md-center'})[0]
		links = parseDOM(result, 'p')

		for link in links:	
			vers=link
			url = url_main+'-d1,'+vers
			out.append((vers, url))			
	return out	

def search(q='batman'):
	global kukz
	kukz = params.get('sessionid', None)
	r = requests.get('http://kinonet.pl/?s='+q,verify=False)
	html=(r.content).replace("<span style='color:red'>"+q+"</span>",q)
	out=[]
	serout=[]
	links = parseDOM(html, 'div', attrs={'class': "p-2 col-lg-2 float-left"})
	for link in links:		
		imag= parseDOM(link, 'img', ret='src')[0]
		href = parseDOM(link, 'a', ret='href')[0] #[1]
		title= parseDOM(link, 'h2')[0]
		plot = parseDOM(link, 'p')[0]
		year = parseDOM(link, 'span', attrs={'title': "Rok wydania.+?"})#[0]
		if year:		#<span title="Rok wydania filmu online" 
			year=int(year[0])
		else:
			year=0000
		if href and title:
			film = {
				'href'   : href,
				'title'  : PLchar(title),
				'plot'   : PLchar(plot),
				'img'    : imag,
				'year'	 : year,
					}
			if 'seriale' in href:
				serout.append(film)	
			else:
				out.append(film)		
	return out,serout
	
def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace("&gt;",">")	
	char = char.replace("&Iacute;","Í").replace("&iacute;","í")
	char = char.replace("&icirc;","î").replace("&Icirc;","Î")
	char = char.replace('&oacute;','ó').replace('&Oacute;','Ó')
	char = char.replace('&quot;','"').replace('&amp;quot;','"')
	char = char.replace('&bdquo;','"').replace('&rdquo;','"')
	char = char.replace("&Scaron;","Š").replace("&scaron;","š")
	char = char.replace("&ndash;","-").replace("&mdash;","-")
	char = char.replace("&Auml;","Ä").replace("&auml;","ä")
	char = char.replace('Napisy PL',"[COLOR lightblue](napisy pl)[/COLOR]")
	char = char.replace('Lektor PL',"[COLOR lightblue](lektor pl)[/COLOR]")
	char = char.replace('Dubbing PL',"[COLOR lightblue](dubbing pl)[/COLOR]")	
	return char	

	
if __name__ == '__main__':
	mode = params.get('mode', None)
	if not mode:
		home()
	elif mode == 'listmovies':
		ListMovies(exlink,page)
	elif mode == 'getLinks':
		getLinks(exlink)	
	elif mode =='getepisodes':
		getEpisodes(exlink)
	elif mode == 'gatunek':
		data = getGatunek(exlink)
		par= exlink.split('|')
		if data:
			label = [x[0].strip() for x in data]
			url = [x[1].strip() for x in data]
			s = xbmcgui.Dialog().select('Wybierz '+par[0],label)
			if s>-1:
				url = build_url({'mode': 'listmovies', 'foldername': name, 'url' : url[s], 'sessionid': kukz})
				xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)	
			else:
				quit()	
	elif mode == '__page__M':
		global kukz
		kukz = params.get('sessionid', None)
		url = build_url({'mode': 'listmovies', 'foldername': name, 'url' : exlink, 'sessionid': kukz})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)		
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			links,serials=search(query.replace(' ','+') )
			itemz=links
			items = len(links)
			mud='getLinks'
			fold=False
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, infoLabels=f, itemcount=items)	
			itemz=serials
			items = len(serials)
			mud='getepisodes'
			fold=True
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, infoLabels=f, itemcount=items)		
		else:
			quit()
		
xbmcplugin.endOfDirectory(addon_handle)
