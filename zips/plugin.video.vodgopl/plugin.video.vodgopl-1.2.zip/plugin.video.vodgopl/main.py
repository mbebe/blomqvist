# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import json
import urllib
import urllib2

import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import urlparse

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.vodgopl')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'

FANART=RESOURCES+'../fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

import cfdeco6
scraper = cfdeco6.create_scraper()

exlink = params.get('url', None)
name= params.get('name', None)
page = params.get('page','')
mcount= params.get('moviescount', None)
movie= params.get('movie', None)
rys= params.get('image', None)

katv = addon.getSetting('katV')
if not katv:
	addon.setSetting('katV','')
katn = addon.getSetting('katN') if katv else 'Wszystkie'

skatv = addon.getSetting('skatV')
if not skatv:
	addon.setSetting('skatV','')
skatn = addon.getSetting('skatN') if skatv else 'Wszystkie'

verv = addon.getSetting('verV')
if not verv:
	addon.setSetting('verV','')
vern = addon.getSetting('verN') if verv else 'Wszystkie'

UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0'
TIMEOUT=15
sess  = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=1,fanart=FANART,moviescount=0):
	list_item = xbmcgui.ListItem(label=name)

	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')
	if not infoLabels:
		infoLabels={'title': name,'plot':name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': FANART})
	ok=xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page, 'moviescount' : moviescount,'movie':movie,'name':name,'image':image}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %P")
	return ok

def home():
	setcookies()
	add_item('film', '[B][COLOR lightgreen]Popularne filmy[/COLOR][/B]', 'DefaultMovies.png', "listpopular", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('serial', '[B][COLOR lightgreen]Popularne seriale[/COLOR][/B]', 'DefaultTVShows.png', "listpopular", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', "[I][COLOR violet][B]Reset filtrów[/COLOR][/I][/B]",'DefaultAddonService.png', "resetfil", folder=False)	
	add_item('film', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "listFilmy3filmy", folder=True,fanart=RESOURCES+'fanart.png')

	add_item('', "-        [COLOR lime]Kategorie:[/COLOR] [B]"+katn+"[/B]",'DefaultRecentlyAddedMovies.png', "film:kateg", folder=False)
	add_item('', "-        [COLOR lime]Wersja językowa:[/COLOR] [B]"+vern+"[/B]",'DefaultRecentlyAddedMovies.png', "film:jezyk", folder=False)
	add_item('serial', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultTVShows.png', "listFilmy3filmy", folder=True,fanart=RESOURCES+'fanart.png')

	add_item('', "-        [COLOR lime]Kategorie:[/COLOR] [B]"+skatn+"[/B]",'DefaultRecentlyAddedMovies.png', "serial:skateg", folder=False)

	add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "listSearch", folder=True,fanart=RESOURCES+'fanart.png')
	
def setcookies():
	html = scraper.get('https://vodgo.pl/',verify=False)#.content
	sc=''.join(['%s=%s;'%(c.name, c.value) for c in scraper.cookies])
	addon.setSetting('kukiz',sc)
	return
	
def geturl(url,params=None):
	kukz = addon.getSetting('kukiz')
	headers = {
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Cookie':kukz,
		'DNT': '1',
		'Connection': 'keep-alive',
		'Upgrade-Insecure-Requests': '1',
		'TE': 'Trailers',
	}	
	html = sess.get(url,headers=headers,verify=False,params=params).content
	return html
	
def ListPopular(url):
	links = getPopular(url)
	if links:
		itemz=links
		items = len(links)
		fold=False
		mud='play3Filmy'
		if 'serial' in url:
			fold=True
			mud='listSerial'
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, infoLabels=f, itemcount=items)	
		if 'film' in url:
			xbmcplugin.setContent(addon_handle, 'videos')	
		xbmcplugin.endOfDirectory(addon_handle)			
	else:
		xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Brak materiałów do wyświetlenia.',xbmcgui.NOTIFICATION_INFO, 6000)
		
def getPopular(url):
	out=[]

	html = geturl('https://vodgo.pl/')

	id = 'menu1'
	if 'serial' in url:
		id = 'home'
	result = parseDOM(html, 'div', attrs={'class':'tab-pane.+?','id':id})[0]
	links = re.findall('(<a.+?<\/a>)',result,re.DOTALL)
	for link in links:
		href = parseDOM(link,'a',ret='href')[0]
		img = parseDOM(link,'img',ret='src')[0]
		href = 'https://vodgo.pl'+href
		img = 'https://vodgo.pl'+img
		tyt = parseDOM(link, 'div', attrs={'class':'text-white small'})[0]
		tytang = parseDOM(link, 'div', attrs={'class':'text-muted small'})[0]
		year = parseDOM(link, 'div', attrs={'class':'badge badge-primary'})[0]

		typ=''
		if 'film' in url:
			typ=",".join(parseDOM(link, 'div', attrs={'class':'badge badge-success'}))

		out.append({'title':PLchar(tyt),'href':href+'|'+urllib.quote(PLchar(tyt)),'img':img,'plot':PLchar(tyt),'year':year,'code':typ})

	return out

def ListSerial(url):
	seasons=getSerial(url)	
	if seasons:
		items = len(seasons)
		for f in seasons: 
			add_item(name=f.get('title'), url=f.get('href'), mode='listepisodes', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
		xbmcplugin.endOfDirectory(addon_handle)	
	

def getSerial(url):
	out=[]
	response = geturl(url)
	opis = parseDOM(response, 'div', attrs={'class':'bg-black p-2 shadow.+?'})#[0]# bg-black p-2 shadow
	opis = opis[0] if opis else ''
	dd = parseDOM(response, 'span', attrs={'class':'text-warning'})[0]
	categ=",".join(parseDOM(dd, 'div', attrs={'class':'badge badge-info'}))
	result = parseDOM(response, 'ul', attrs={'class':'nav nav-pills','role':'tablist'})[0] #<ul class="nav nav-pills" role="tablist">
	sezony = re.findall('(<a.+?<\/a>)',result)

	for sezon in sezony:
		refname=re.findall('ref="#(.+?)".+?toggle="tab">([^>]+)<',sezon)[0]
		href = url+'|'+refname[0]
		ses = re.findall('s(\d+)',refname[0])[0]
		ses = '%02d'%int(ses)
		tyt = name+ ' - Sezon '+str(ses)
		out.append({'title':tyt,'href':href,'img':rys,'genre':categ,'plot':opis,'season':int(ses)})
	return out
	
def ListEpisodes(url):
	
	episodes=getEpisodes(url)
	if episodes:
		items = len(episodes)
		for f in episodes: 
			add_item(name=f.get('name'), url=f.get('href'), mode='play3Filmy', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)
		xbmcplugin.setContent(addon_handle, 'videos')	
		xbmcplugin.endOfDirectory(addon_handle)	
		
def getEpisodes(url):
	out=[]
	url,id = url.split('|')

	html = geturl(url)

	opis = parseDOM(html, 'div', attrs={'class':'bg-black p-2 shadow.+?'})[0]
	dd = parseDOM(html, 'span', attrs={'class':'text-warning'})[0]
	categ=",".join(parseDOM(dd, 'div', attrs={'class':'badge badge-info'}))
	result = parseDOM(html, 'div', attrs={'class':'tab-pane.+?','id':id})[0]
	links  = parseDOM(result, 'div', attrs={'class':'row'})
	for link in links:
		href = parseDOM(link,'a',ret='href')[0]
		tyt = parseDOM(link,'a')[0]

		out.append({'title':tyt,'href':'https://vodgo.pl'+href+'|'+urllib.quote(PLchar(opis)),'img':rys,'genre':categ,'plot':PLchar(opis)})
	return out

def ListFilmy3filmy	(url,pg,katv,skatv,verv):
	page = int(pg)
	links, pagin=getFilmy3filmy(url,pg,katv,skatv,verv)
	
	
	if links:
		itemz=links
		items = len(links)
		fold=False
		mud='play3Filmy'
		if 'serial' in url:
			fold=True
			mud='listSerial'
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, infoLabels=f, itemcount=items)	
		if pagin:
			for f in pagin:	
				add_item(name=f.get('title'), url=f.get('href'), mode='listFilmy3filmy', image=f.get('img'), folder=True,page=f.get('page'))	
		if 'film' in url:
			xbmcplugin.setContent(addon_handle, 'videos')	
		xbmcplugin.endOfDirectory(addon_handle)		
	else:
		xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Brak materiałów do wyświetlenia.',xbmcgui.NOTIFICATION_INFO, 6000)
	
def getFilmy3filmy(url,page,katg,skatg,verg):
	out=[]
	npout=[]
	#kukz = addon.getSetting('kukiz')
	page=int(page)
	co='film'
	url2='https://vodgo.pl/filmy?c=on'+verg+katg+'&page=%s'%page

	if 'serial' in url:
		co='serial'
		url2='https://vodgo.pl/seriale-online?c=on'+skatg+'&page=%s'%page

	html = geturl(url2)
	result = parseDOM(html, 'div', attrs={'class':'col-12 col-md-9'})[0]
	links = re.findall('(<a class.+?)<\/a>',result,re.DOTALL)
	for link in links:
		try:
			href=parseDOM(link,'a',ret='href')[0]
			tyt = parseDOM(link,'div',ret='title')[0]
			try:
				tytorg=parseDOM(link,'div',ret='title')[1]
				tyt = tyt+' / '+tytorg if tytorg else tyt
			except:
				tytorg=''
				
			year=re.findall('calendar"><\/i>([^<>]+)<',link)[0]
			img=parseDOM(link,'img',ret='src')[0]
			categ=",".join(parseDOM(link, 'span', attrs={'class':'badge badge-primary'}))
			typ=",".join(parseDOM(link, 'span', attrs={'class':'badge badge-success'}))
			opis = re.findall('col\-12 small">([^>]+)<\/div>',link)
			opis = opis[0] if opis else ''
			out.append({'title':PLchar(tyt),'href':'https://vodgo.pl/'+href+'|'+urllib.quote(PLchar(opis)),'img':'https://vodgo.pl/'+img,'plot':PLchar(opis),'year':year,'genre':categ,'code':typ})
		except:
			continue
	if 'rel="next" aria-label="Next' in html:
		npout.append({'title':'Następna strona','href':co,'img':RESOURCES+'nextpage.png','plot':'','page':page+1}) 
	return out,npout
def getGoUnlim(url):
	headers = {'User-Agent': UA}
	html = (urllib2.urlopen(urllib2.Request(url, headers=headers)).read()).replace("\'",'"')
	import jsunpack as jsunpack
	web_pdb.set_trace()
	packed = packer.findall(html)[0]
	unpacked = (jsunpack.unpack(packed)).decode('string_escape')
	packer = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)')
	
	src=re.findall('<source src="(.+?)"',html)	
	return src[0] if src else ''
def Play3Filmy(url):
	url,opis=url.split('|')
	opis = urllib.unquote(opis)
	out=[]
	html = geturl(url)
	links = re.findall('<li dbid(.+?)<\/li>',html,re.DOTALL)#for lektor in lektors:
	for link in links:
		wer=(re.findall('dbver="(.+?)"',link)[0]).lower()
		host,jak = re.findall('>([^<]+)<\/button>',link)
		host=host.center(14)
		jak=jak.center(14)
		post="|".join(re.findall('set_url\("(.+?)","(.+?)"',link)[0])
		out.append({'host':host+'|'+jak+' | '+wer ,'href':post})
	if len(out)>1:
		hosts = [x.get('host') for x in out]

		sel = xbmcgui.Dialog().select('Wybierz źródło:   [host] | [jakość] | [wersja]',hosts)
		sel = sel if sel>-1 else quit()
		
	else:
		sel=0
	posturl,token=out[sel].get('href').split('|')

	params = (
		('url', posturl),
		('token', token),
	)
	html = geturl('https://vodgo.pl/frame',params=params)
	str_url = parseDOM(html,'iframe',ret='src')#[1]
	if str_url:
		import resolveurl
		str_url=str_url[0]
		try:
			hmf = resolveurl.HostedMediaFile(url=str_url)
			if not hmf:
				if 'upset' in str_url:
					stream_url=getUpset(str_url)
				else:
					xbmcgui.Dialog().notification('[COLOR red][B]Error[/B][/COLOR]', "[COLOR red][B]Can't resolve this link.[/B][/COLOR]", xbmcgui.NOTIFICATION_INFO, 5000)
					stream_url=''
			else:
				stream_url = resolveurl.resolve(str_url)
			#	if not stream_url and 'gounlimited.to' in str_url:
			#		stream_url=getGoUnlim(str_url)
		except Exception,e:
			stream_url=''
			s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))
	if stream_url:
		play_item = xbmcgui.ListItem(path=stream_url)#
		play_item.setInfo(type="Video", infoLabels={"title": name,'plot':opis})
		
		play_item.setArt({'thumb': rys, 'poster': rys, 'banner': rys, 'fanart': FANART})
		
		play_item.setProperty("IsPlayable", "true")
		Player = xbmc.Player()
		Player.play(stream_url, play_item)

def getUpset(url):
	headers = {'User-Agent': UA}
	html = urllib2.urlopen(urllib2.Request(url, headers=headers)).read()	
	src=re.findall('<source src="(.+?)"',html)	
	return src[0] if src else ''

def ListSearch():
	params = dict(parse_qsl(sys.argv[2][1:]))
	#d= params['d']#, None)
	d=params.get('d', None)

	if d is None:
		d = xbmcgui.Dialog().input(u'Szukaj...', type=xbmcgui.INPUT_ALPHANUM)
	if d:

		params = (
			('query', d),
		)
		html = geturl('https://vodgo.pl/search', params=params)
		links = parseDOM(html, 'div', attrs={'class':'col-12 row mt-1'})
		if links:
			for link in links:
				if '>zablokowany<' in link:
					continue
				href=parseDOM(link,'a',ret='href')[0]

				img=parseDOM(link,'img',ret='src')[0]
				href = 'https://vodgo.pl'+href
				img = 'https://vodgo.pl'+img
				tytpl = parseDOM(link, 'div', attrs={'class':''})[0]
				tytang = parseDOM(link, 'div', attrs={'class':'text-muted'})[0]
				tyt = tytpl+' / '+tytang
				fold=False
				mud='play3Filmy'
				if '/serial/' in href:
					fold=True
					mud='listSerial'
					tyt = tyt + '  [COLOR violet][B](serial)[/COLOR][/B]'
					href = PLchar(href)
				else:
					
					tyt = tyt + '  [COLOR violet][B](film)[/COLOR][/B]'
					href = PLchar(href)+'|'+PLchar(tyt)
				add_item(name=PLchar(tyt), url=href, mode=mud, image=img, folder=fold, infoLabels=False)
			xbmcplugin.endOfDirectory(addon_handle)	
		else:
			xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Nic nie znaleziono.',xbmcgui.NOTIFICATION_INFO, 6000)

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&#039;',"'")
	char = char.replace('&quot;','"').replace('&oacute;','ó').replace('&rsquo;',"'")
	char = char.replace('&nbsp;',".").replace('&amp;','&').replace('&eacute;','e')
	return char	

def router(paramstring):
	params = dict(parse_qsl(paramstring))
	if params:
		mode = params.get('mode', None)
		
		if mode == 'listFilmy3filmy':
			ListFilmy3filmy	(exlink,page,katv,skatv,verv)
		elif mode == 'listSerial':
			ListSerial(exlink)

		elif mode == 'listepisodes':	
			ListEpisodes(exlink)

		
		elif mode == 'getEpisodes':	
			getEpisodes(exlink)
		
		elif mode == 'listSeriale':
			ListSeriale(exlink,page)
				
		elif mode == 'listSearch':
			ListSearch()			

		elif mode == 'resetfil':
			n='Wszystkie'
			v=''
			addon.setSetting('katV',v)
			addon.setSetting('skatV',v)
			addon.setSetting('verV',v)

			
			addon.setSetting('katN',n)
			addon.setSetting('skatN',n)
			addon.setSetting('verN',n)

			xbmc.executebuiltin("Container.Refresh") 
		
		elif 'kateg' in mode:
			if 'film' in mode:
				myMode = 'kat'
			else:
				myMode = 'skat'
			
			label =["Wszystkie","Akcja","Dramat","Fantasy","Horror","Komedia","Kryminał","Obyczajowy","Przygodowy","Sci-Fi","Sensacyjny","Psychologiczny","Thriller","Western","Wojenny","Anime","Baśń","Biblijny","Biograficzny","Czarna komedia","Dla młodzieży","Dramat historyczny","Dramat obyczajowy","Dramat sądowy","Dramat społeczny","Dreszczowiec","Edukacyjny","Erotyczny","Etiuda","Familijny","Film-Noir","Gangsterski","Groteska filmowa","Historyczny","Karate","Katastroficzny","Komedia kryminalna","Komedia obycz.","Komedia rom.","Kostiumowy","Krótkometrażowy","Kulinarny","Lifestylowy","Melodramat","Motoryzacyjny","Musical","Muzyczny","Naukowy","Niemy","Nowele filmowe","Podróżniczy","Poetycki","Polityczny","Prawniczy","Propagandowy","Przyrodniczy","Płaszcza i szpady","Randkowy","Reality-show","Religijny","Romans","Rozrywkowy","Satyra","Sportowy","Surrealistyczny","Szpiegowski","Sztuki walki","Talent-show","Teleturniej"]
			value = ["","g[]=Akcja","g[]=Dramat","g[]=Fantasy","g[]=Horror","g[]=Komedia","g[]=Kryminał","g[]=Obyczajowy","g[]=Przygodowy","g[]=Sci-Fi","g[]=Sensacyjny","g[]=Psychologiczny","g[]=Thriller","g[]=Western","g[]=Wojenny","g[]=Anime","g[]=Baśń","g[]=Biblijny","g[]=Biograficzny","g[]=Czarna komedia","g[]=Dla młodzieży","g[]=Dramat historyczny","g[]=Dramat obyczajowy","g[]=Dramat sądowy","g[]=Dramat społeczny","g[]=Dreszczowiec","g[]=Edukacyjny","g[]=Erotyczny","g[]=Etiuda","g[]=Familijny","g[]=Film-Noir","g[]=Gangsterski","g[]=Groteska filmowa","g[]=Historyczny","g[]=Karate","g[]=Katastroficzny","g[]=Komedia kryminalna","g[]=Komedia obycz.","g[]=Komedia rom.","g[]=Kostiumowy","g[]=Krótkometrażowy","g[]=Kulinarny","g[]=Lifestylowy","g[]=Melodramat","g[]=Motoryzacyjny","g[]=Musical","g[]=Muzyczny","g[]=Naukowy","g[]=Niemy","g[]=Nowele filmowe","g[]=Podróżniczy","g[]=Poetycki","g[]=Polityczny","g[]=Prawniczy","g[]=Propagandowy","g[]=Przyrodniczy","g[]=Płaszcza i szpady","g[]=Randkowy","g[]=Reality-show","g[]=Religijny","g[]=Romans","g[]=Rozrywkowy","g[]=Satyra","g[]=Sportowy","g[]=Surrealistyczny","g[]=Szpiegowski","g[]=Sztuki walki","g[]=Talent-show","g[]=Teleturniej"]
			msg = 'kategorie'
			
			try:
				sel = xbmcgui.Dialog().multiselect('Wybierz '+msg,label)
			except:
				sel = xbmcgui.Dialog().select('Wybierz '+msg,label)
			if not sel: sel=quit()
			if isinstance(sel,list):

				n = '%s'%','.join( [ label[i] for i in sel]) if sel[0]>-1 else ''			
				v= ''.join('&{0}'.format(value[i]) for i in sel) if sel[0]>-1 else ''
				if 'Wszystkie' in n:	
					n='Wszystkie'
					v=''

			else:
				sel = sel if sel>-1 else quit()
				
				v = '&%s'%(value[sel])
				n = '%s'%(label[sel])

			addon.setSetting(myMode+'V',v)
			addon.setSetting(myMode+'N',n)		
			xbmc.executebuiltin("Container.Refresh") 	

		elif 'jezyk' in mode:
		
			label =["Wszystkie","PL","Lektor","Napisy","Dubbing","ENG","Brak"]
			value = ["","v[]=PL","v[]=Lektor","v[]=Napisy","v[]=Dubbing","v[]=ENG","v[]=Brak"]
			msg = 'wersję językową'
			myMode = 'ver'
			try:
				sel = xbmcgui.Dialog().multiselect('Wybierz '+msg,label)
			except:
				sel = xbmcgui.Dialog().select('Wybierz '+msg,label)
			if not sel: sel=quit()
			if isinstance(sel,list):
				n = '%s'%','.join( [ label[i] for i in sel]) if sel[0]>-1 else ''		
				v= ''.join('&{0}'.format(value[i]) for i in sel) if sel[0]>-1 else ''
				if 'Wszystkie' in n:	
					n='Wszystkie'
					v=''
			else:
				sel = sel if sel>-1 else quit()
				v = '&%s'%(value[sel])
				n = '%s'%(label[sel])
			addon.setSetting(myMode+'V',v)
			addon.setSetting(myMode+'N',n)		
			xbmc.executebuiltin("Container.Refresh") 

		elif mode == 'listpopular':	
			ListPopular(exlink)
		elif mode == 'play3Filmy':	
			Play3Filmy(exlink)
		
	else:
		home()
		xbmcplugin.endOfDirectory(addon_handle)	
if __name__ == '__main__':
    router(sys.argv[2][1:])
