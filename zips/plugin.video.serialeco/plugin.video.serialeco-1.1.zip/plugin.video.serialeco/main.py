# -*- coding: UTF-8 -*-
import sys,re,os
import urlparse
from urlparse import parse_qsl
import base64
import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import resolveurl as urlresolver

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.serialeco')
dalej=''
PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=PATH+'fanart.jpg'
blad=PATH+'error.png'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

from filmweb.filmweb import Filmweb
fw = Filmweb()

exlink = params.get('url', None)
name= params.get('title', None)
licz= params.get('licz', None)
page = params.get('page',[1])[0]

main_url='http://seriale.co'
s = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=1, licz=1):
	list_item = xbmcgui.ListItem(label=name)

	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')
		
	if not infoLabels:
		infoLabels={'title': name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page,'licz':licz}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	
def home():
	add_item('http://seriale.co/', 'Strona główna', '', True, "listserialco")
	add_item('http://seriale.co/', 'Lista seriali', '', True, "listalfabet")			
	add_item('', '[COLOR lightblue]Szukaj[/COLOR]', '', True, "search")		
	xbmcplugin.endOfDirectory(addon_handle)

def ListSerialCo(exlink,page):
	page = int(page) if page else 1		
	links, pagin = getListSerialCo(exlink,page)
	if pagin[0]:
		add_item(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[0])	
	itemz=links
	if itemz:
		items = len(links)
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='listsezony', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	else:
		add_item(name='[COLOR red]Brak materiałów[/COLOR]', url='', mode=' ', image='', folder=False, infoLabels='', itemcount=1)			
	if pagin[1]:
		add_item(name='[COLOR blue]>> Nastepna strona >>>[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[1])
	xbmcplugin.setContent(addon_handle, 'movies')	

def getListSerialCo(url,page=1):
	url = url + 'page/%d' %page
	html=getUrlReq(url)
	out=[]
	prevpage=False #gr=False
	nextpage=False  # pr=False	
	np=str(page+1)
	if html.find('td-icon-menu-right')>0:
		nextpage = page+1		
	result=parseDOM(html,'div', attrs={'class': "td-ss-main-content"})[0] 
	links = parseDOM(result, 'div', attrs={'class':"td-block-span6"})
	plot=''
	for link in links:	
		imag = parseDOM(link, 'img', ret='src')[0]#.sub('-\d+x\d+', '')
		imag= re.sub('-\d+x\d+', '', imag)
		href = parseDOM(link, 'a', ret='href')[0]   
		title=parseDOM(link,'a')[1]
		if 'true' in addon.getSetting('showPosters'):
			zdj,plot=getImag(title)			
		out.append({'title':PLchar(title),'href':href,'img':imag,'plot':plot})	
	prevpage = page-1 if page>1 else False
	return (out,(prevpage,nextpage))
	
def ListOdcinki(exlink):
	
	aaa=exlink.split(' - sezon ')#[1]
	links=getOdcinki(aaa[0],aaa[1],licz)
	itemz=links
	if itemz:
		items = len(links)
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items,licz=int(f.get('snum')))
	xbmcplugin.setContent(addon_handle, 'movies')

def getOdcinki(tyt,sez,ilosc):
	ilosc=int(ilosc)
	sez=int(sez)
	nrsez='{:>02d}'.format(sez)
	out=[]
	imag=''
	plot=''
	if 'true' in addon.getSetting('showPosters'):
		imag,plot=getImag(tyt)	
	for x in range(ilosc):
		eNum = str(x + 1)
		title='[B][COLOR blue]'+tyt+'[/B][/COLOR] - s'+nrsez+'e'+'{:>02d}'.format(int(eNum))
		out.append({'title':title,'href':tyt+'|'+str(sez)+'|'+eNum,'img':imag,'plot':plot,'snum':eNum})			
	return out

def ListSezony(exlink):

	links=getSezony(exlink)
	itemz=links
	if itemz:
		items = len(links)
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='listodcinki', image=f.get('img'), folder=True, infoLabels=f, itemcount=items,licz=int(f.get('snum')))
	xbmcplugin.setContent(addon_handle, 'movies')

def getSezony(url):
	html=getUrlReq(url)	
	es={}
	items=re.findall("<input.+?/>",html,re.DOTALL)
	for item in items:
		try:			
			id=re.findall('''id=['"]([^'^"]+?)['"]''',item)[0]
			val=re.findall('''value=['"]([^'^"]+?)['"]''',item)[0]   
			es[id]=val
		except:
			continue
	es['odc'] = es.get('lista_odcinkow','').split(',')
	out=[]
	seasons = es.get('odc', '') #.split(',')
	an=es.get('fid', '')
	imag=''
	plot=''
	if 'true' in addon.getSetting('showPosters'):
		imag,plot=getImag(an)	
	for idx in range(len(seasons)):
		if seasons[idx] == '' : continue
		sNum = str(idx + 1)
		title=es.get('fid', '')+' - sezon '+sNum	
		ilodc=seasons[idx]
		out.append({'title':PLchar(title),'href':PLchar(title),'img':imag,'plot':plot,'snum':ilodc})	
	return out
	
def ListSearch(exlink):	
	links= getSearch(exlink)
	itemz=links
	if itemz:
		items = len(links)
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='listsezony', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	else:
		add_item(name='[COLOR red]Brak materiałów[/COLOR]', url='', mode=' ', image='', folder=False, infoLabels='', itemcount=1)			
	xbmcplugin.setContent(addon_handle, 'movies')	

def getSearch(url):
	html=getUrlReq(url)
	out=[]
	links = parseDOM(html, 'div', attrs={'class': "td_module_16.+?"})
	for link in links:	
		plot= parseDOM(link, 'div', attrs={'class': "td-excerpt"})#$<div class="td-excerpt">
		if plot:
			plot=PLchar(plot[0].strip())
		else:
			plot=''
		if '>News<' not in link:
			imag = parseDOM(link, 'img', ret='src')[0]
			imag= re.sub('-\d+x\d+', '', imag)
			href = parseDOM(link, 'a', ret='href')[0]   
			title=parseDOM(link,'a')[1]	
			out.append({'title':PLchar(title),'href':href,'img':imag,'plot':plot})			
		else:
			continue
	return out	

def ListAlfabet(exlink):	
	links= getAlfabet(exlink)
	itemz=links
	if itemz:
		items = len(links)
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='listsezony', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	else:
		add_item(name='[COLOR red]Brak materiałów[/COLOR]', url='', mode=' ', image='', folder=False, infoLabels='', itemcount=1)			
	xbmcplugin.setContent(addon_handle, 'movies')	

def getAlfabet(url):
	html=getUrlReq(url)
	out=[]
	results = parseDOM(html, 'ul', attrs={'class': "dpe-flexible-posts"})[0]
	links = parseDOM(results, 'li')
	for link in links:	

		href = parseDOM(link, 'a', ret='href')[0]   
		title= parseDOM(link, 'div', attrs={'class': "title"})[0]
		imag=''
		plot=''
		if 'true' in addon.getSetting('showPosters'):
			imag,plot=getImag(title)
		out.append({'title':PLchar(title),'href':href,'img':imag,'plot':plot})
		
	return out	
	
def getImag(title):

###                   https://github.com/lopezloo/pyfilmweb

	titlemain=title.split(' (')
	title=PLchar(titlemain[0])
	tyt=repr(title)
	tyt=tyt.encode("utf8").replace("'",'').lower()
	items = fw.search(title)
	imag=''
	plot=''
	for item in items:
		try:
			ab=item.name
		
			if 'serial' in item.type:
				ab= repr(ab.encode('utf-8')).replace("'",'').lower()
				if tyt in ab:
					imag= item.get_poster(size='big')
					plot= item.get_description()				
					return imag,plot
		except:
			pass
	return imag,plot
		
def getUrlReq(url):
	headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',}
	content=s.get(url,headers=headers, verify=False).text	
	return content	
	
def getLinks(ex_link):
	dal=ex_link.split('|')
	fid=PLchar(dal[0])
	sezn=str(dal[1])
	odcin=str(dal[2])
	headers = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0',
		'Accept': '*/*',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
		'Origin': 'http://seriale.co',
		'Connection': 'keep-alive',}
	data = {'title': fid,'sezon': sezn,'odcinek': odcin}
	html = (s.post('http://178.19.110.218/forumserialeco/skrypt/szukaj3.php', headers=headers, data=data).text).replace("\'",'"')
	items=[]
	links=re.findall("""na['"]\s+url=['"](.+?)['"]\s+host=['"](.+?)['"]\s+wersja=['"](.+?)['"]""",html)
	for href,host,wersja in links:	
		items.append({'href' : href,'host' : host.strip()+' ('+wersja+')',})
	if len(items)>0:
		select = xbmcgui.Dialog().select('Wyb\xc3\xb3r', [ x.get('host') for x in items])
		if select>-1:
			link = items[select].get('href')
	if link:

		link=getTrueLink(link)
		try:
			stream_url = urlresolver.resolve(link)
		except Exception,e:
			stream_url=''
			sel = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link bedzie działał?','ERROR: %s'%str(e))
		if stream_url:
			xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
		else:
			xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
	else:
		xbmcgui.Dialog().notification('Ups...', 'Wystąpił błąd.', blad, 6000)

def getTrueLink(link):	
	html=getUrlReq('http://seriale.co/frame.php?src='+link)
	link= parseDOM(html, 'iframe', ret='src')[0]
	return link

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86') #E9
	char = char.replace('\\u00e9','\xc3\xa9').replace('\\u00C9','\xc3\x89') #E9	
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&nbsp;',".").replace('&amp;','&')
	return char	

if __name__ == '__main__':
	mode = params.get('mode', None)
	if not mode:
		home()
	elif mode == 'listpopular':
		ListPopular(exlink)			
	elif mode == 'getLinks':
		getLinks(exlink)	
	elif mode == 'listalfabet':
		ListAlfabet(exlink)
	elif mode == 'listserialco':
		ListSerialCo(exlink,page)	
	elif mode == 'listodcinki':
		ListOdcinki(exlink)	
	elif mode == 'listsezony':
		ListSezony(exlink)		
	elif mode == '__page__M':
		url = build_url({'mode': 'listserialco', 'foldername': '', 'url' : exlink, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Szukaj, Czego szukasz', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			q=query.replace(' ','+')
			elink='http://seriale.co/?s='+q
			ListSearch(elink)		
xbmcplugin.endOfDirectory(addon_handle)
