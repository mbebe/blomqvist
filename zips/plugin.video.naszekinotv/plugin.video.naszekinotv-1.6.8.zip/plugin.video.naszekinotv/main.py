# -*- coding: utf-8 -*-
import sys,re,os,json
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import resolveurl as urlresolver
import time,threading

try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
  
cache = StorageServer.StorageServer("nktv")

import resources.lib.naszekinotv as nktv

base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonName       = my_addon.getAddonInfo('name')
addonId         = my_addon.getAddonInfo('id')
PATH            = my_addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART          = RESOURCES+'fanart.png'
nktv.COOKIEFILE = os.path.join(DATAPATH,'cookie')

def addLinkItem(name, url, mode, page=1, iconimage='DefaultFolder.png', infoLabels=False, contextO=[''], IsPlayable=True,fanart=FANART, itemcount=1):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'page':page})
    liz = xbmcgui.ListItem(name)
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconimage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    liz.setArt(art)

    if not infoLabels:
        infoLabels={"title": name}

    liz.setInfo(type="video", infoLabels=infoLabels)

    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')

    isp = []
    content = urllib.quote_plus(json.dumps(infoLabels))

    if 'DOWNLOAD' in contextO:
        isp.append(('[B]Download[/B]', 'RunPlugin(plugin://%s?mode=DOWNLOAD&ex_link=%s)'%(addonId,content)))

    liz.addContextMenuItems(isp, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=False,totalItems=itemcount)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

    return ok

def addDir(name,ex_link=None, page=1, mode='folder',iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART,contextmenu=None):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'page' : page})
    li = xbmcgui.ListItem(name)

    if infoLabels:
        li.setInfo(type="video", infoLabels=infoLabels)

    art_keys=['thumb','poster','banner','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconImage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    li.setArt(art)

    if contextmenu:
        isp=contextmenu
        li.addContextMenuItems(isp, replaceItems=True)

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        out_dict[k] = v
    return out_dict

def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))

def listMovies(ex_link,page):
	page = int(page) if page else 1
	group = ''
	
	if '|'in ex_link:
		ex_link,group = ex_link.split('|')
	
	mlinks,mparams = nktv.getMovies(ex_link,page,group)
	
	if mparams[0]:
		addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__M', page=mparams[0], IsPlayable=False)
	
	items = len(mlinks)
	
	for f in mlinks:
		addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD'], IsPlayable=True, itemcount=items)
	
	if mparams[1]:
		addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__M', page=mparams[1], IsPlayable=False)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
def listSeries(ex_link,page):
	page = int(page) if page else 1
	group=''
	
	if '|'in ex_link:
		ex_link,group = ex_link.split('|')
	
	if group:
		mlinks,mparams = nktv.getSeries(ex_link,int(page),group)
	else:
		mlinks,mparams = nktv.getSeries(ex_link)
	
	my_mode = 'getEpisodes'
	
	if 'true' in my_addon.getSetting('groupEpisodes'):
		my_mode = 'getSeasons'
	
	if mparams[0]:
		addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__S', page=mparams[0], IsPlayable=False)
	
	items=len(mlinks)
	
	for f in mlinks:
		addDir(name=f.get('title'), ex_link=f.get('href'), mode=my_mode, iconImage=f.get('img'), infoLabels=f)
	
	if mparams[1]:
		addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__S', page=mparams[1], IsPlayable=False)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	
def getSeasons(ex_link):
	episodes = nktv.scanEpisodes(ex_link)
	seasons = nktv.splitToSeasons(episodes)
	
	for i in sorted(seasons.keys()):
		addDir(name=i, ex_link=urllib.quote(str(seasons[i])), mode='getEpisodes2')
	
	xbmcplugin.setContent(addon_handle, 'season')
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = "%R, %Y, %P")
def getEpisodes(ex_link):
	episodes = nktv.scanEpisodes(ex_link)
	
	for f in episodes:
		addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD'], IsPlayable=True)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = "%R, %Y, %P")
def getEpisodes2(ex_link):
	episodes = eval(urllib.unquote(ex_link))
	
	for f in episodes:
		addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD'], IsPlayable=True, fanart=f.get('img'))
	
	xbmcplugin.setContent(addon_handle, 'episodes')
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = "%R, %Y, %P")
def listFS(ex_link):
    mlinks,match = nktv.search(ex_link)

    for f in mlinks:
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD'], IsPlayable=True, itemcount=len(mlinks))

    for f in match:
        addDir(name=f.get('title'), ex_link=f.get('href'), mode='getEpisodes', iconImage=f.get('img'), infoLabels=f)

def getLinks(ex_link, get_download = False, name = '', image = ''):
	streams = nktv.getVideos(ex_link)
	stream_url = ''
	if streams:
		t = [ x.get('title') for x in streams]
		u = [ x.get('url') for x in streams]
		h = [ x.get('host') for x in streams]
		al = "Z jakiego źródla pobieramy?" if get_download else "Wersja | Ocena | [Host] "
	
		select = xbmcgui.Dialog().select(al, t)
	
		if select > -1:
			link = u[select];
			link = nktv.parseVideoLink(link,[select])
	
			if not stream_url:
				try:
					stream_url = urlresolver.resolve(link)
				except Exception,e:
					stream_url=''
					s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link będzie działał?','Urlresolver ERROR: [%s]'%str(e))
		else:
			xbmc.executebuiltin('XBMC.Container.Refresh()')	
		if stream_url:
			if get_download:
				downloadPath = my_addon.getSetting('download.path')
				if downloadPath and downloadPath != '':
					import resources.lib.downloader as dw
					try:
						dw.download(name, image, stream_url, downloadPath)
					except:
						xbmc.executebuiltin( "XBMC.Notification(%s,%s,%i,%s)" % ( '[COLOR red] Bląd pobierania [/COLOR]', name, 5000, image))
				else:
					xbmcgui.Dialog().ok("Nasze-Kino.tv", "Ustaw docelowy folder!")
					xbmc.executebuiltin("Addon.OpenSettings(%s)"%addonId)
		
			xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
		else:
			xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
			
def getHistory():
    return cache.get('history').split(';')

def setHistory(entry):
    history = getHistory()
    if history == ['']:
        history = []
    history.insert(0, entry)
    cache.set('history',';'.join(history[:50]))

def remCache(entry):
    history = getHistory()
    if history:
        cache.set('history',';'.join(history[:50]))
    else:
        delHistory()

def delHistory():
    cache.delete('history')

mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]

page = args.get('page',[1])[0]
sortv = my_addon.getSetting('sortV')
sortn = my_addon.getSetting('sortN') if sortv else 'Daty dodania'
qualityv = my_addon.getSetting('qualityV')
qualityn = my_addon.getSetting('qualityN') if qualityv else 'Wszystkie'
versionv = my_addon.getSetting('versionV')
versionn = my_addon.getSetting('versionN') if versionv else 'Wszystkie'

if mode is None:
    addLinkItem("[COLOR lightblue]Sortowanie:[/COLOR] [B]"+sortn+"[/B]",'',mode='filtr:sort',iconimage='',IsPlayable=False)
    addLinkItem("[COLOR lightblue]Jakość:[/COLOR] [B]"+qualityn+"[/B]",'',mode='filtr:quality',iconimage='',IsPlayable=False)
    addLinkItem("[COLOR lightblue]Wersja:[/COLOR] [B]"+versionn+"[/B]",'',mode='filtr:version',iconimage='',IsPlayable=False)
    addDir(name="[COLOR blue]Filmy[/COLOR]",ex_link='https://nasze-kino.tv/filmy-online/',page=1, mode='ListMovies',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name=" Ostatnio dodane filmy",ex_link='https://nasze-kino.tv/|Ostatnio dodane filmy',page=1, mode='ListMovies',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name=" Ranking nowości",ex_link='https://nasze-kino.tv/|Ranking now',page=1, mode='ListMovies',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name=" [Kategoria]",ex_link='film|category',page=1, mode='GatunekRok',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name=" [Rok]",ex_link='film|year',page=1, mode='GatunekRok',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name=" [Kraj]",ex_link='film|country',page=1, mode='GatunekRok',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name="[COLOR blue]Seriale (Lista)[/COLOR]",ex_link='https://nasze-kino.tv/seriale-online/',page=1, mode='ListSeriale',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name=" Ostatnio dodane seriale",ex_link='https://nasze-kino.tv/seriale-online/|Ostatnio dodane seriale',page=1, mode='ListSeriale',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name=" Popularne seriale",ex_link='https://nasze-kino.tv/seriale-online/|Popularne seriale',page=1, mode='ListSeriale',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name="[COLOR blue]Dla dzieci[/COLOR]",ex_link='https://nasze-kino.tv/dla-dzieci/',page=1, mode='ListMovies',iconImage='DefaultFolder.png',fanart=FANART)
    addDir('[COLOR lightblue]Szukaj[/COLOR]','',mode='Szukaj')
    addLinkItem('[COLOR gold]-=Opcje=-[/COLOR]','','Opcje')
    xbmcplugin.endOfDirectory(addon_handle)
elif 'filtr' in mode[0]:
    myMode = mode[0].split(":")[-1]

    if myMode=='sort':
        label=[u'Daty dodania',u'Liczba głosów',u'Premiera',u'Odsłony',u'Ocena']
        value=['sort:date','sort:vote','sort:premiere','sort:view','sort:rate']
        msg = 'Sortowanie'
    elif myMode=='quality':
        label=[u'Wszystkie',u'Kamera',u'Niska',u'Średnia',u'Wysoka']
        value=['','quality:4','quality:2','quality:2','quality:3']
        msg = 'Jakość'
    elif myMode=='version':
        label=['Wszystkie','Dubbing','Lektor','Lektor Amator','Lektor IVO','Napisy','PL','Oryginalna']
        value=['',    'version:2','version:1','version:8','version:6','version:3','version:4','version:7']
        msg = 'Wersja'

    if myMode in ['quality','version']:
        try:
            s = xbmcgui.Dialog().select('Wybierz wersje językową',label) #l1l1l11ll11l1l11_nktv_
        except:
            s = xbmcgui.Dialog().select('Wybierz wersje językową',label)
        if isinstance(s,list):
            if 0 in s: s=[0]
            v = myMode+':'+','.join( [ value[i].replace(myMode+':','') for i in s])
            n = ','.join( [ label[i] for i in s])
        else:
            s = s if s>-1 else 0
            v = value[s]
            n = label[s]
    else:
        s = xbmcgui.Dialog().select(msg,label)
        s = s if s>-1 else 0
        v = value[s]
        n = label[s]

    my_addon.setSetting(myMode+'V',v)
    my_addon.setSetting(myMode+'N',n)
    xbmc.executebuiltin('XBMC.Container.Refresh')
    #xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'ListMovies':
    sr = '/'.join([x for x in [sortv,qualityv,versionv] if x]) if '/filmy-online/' in ex_link else ''
    listMovies(ex_link+sr,page)

    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'ListMoviesKids':
    listMovies(ex_link,page)
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'Opcje':
	my_addon.openSettings()
	xbmc.executebuiltin('XBMC.Container.Refresh()')	
elif mode[0] == '__page__M':
    url = build_url({'mode': 'ListMovies', 'foldername': '', 'ex_link' : ex_link, 'page': page})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == '__page__S':
    url = build_url({'mode': 'ListSeriale', 'foldername': '', 'ex_link' : ex_link, 'page': page})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'getEpisodes':
    getEpisodes(ex_link)
    xbmcplugin.setContent(addon_handle, 'episodes')
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'getEpisodes2':
    getEpisodes2(ex_link)
    xbmcplugin.setContent(addon_handle, 'episodes')
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'ListSeriale':
    listSeries(ex_link,page)
    xbmcplugin.setContent(addon_handle, 'tvshows')
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'getSeasons':
    getSeasons(ex_link)
    xbmcplugin.setContent(addon_handle, 'tvshows')
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'ListFS':
    listFS(ex_link)
    xbmcplugin.setContent(addon_handle, 'tvshows')
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'getLinks':
    getLinks(ex_link)
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'DOWNLOAD':
    data = eval(ex_link)
    download_path = my_addon.getSetting('download.path')

    if download_path:
        getLinks(data.get('href'), True, data.get('title'), data.get('img'))
    else:
        xbmcgui.Dialog().ok('Ustaw docelowy folder', 'Pobieranie nie powiodło się')
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'GatunekRok':
    param = ex_link.split('|')
    label,value = nktv.getSort(mv = param[0], sc = param[1])

    try:
        s = xbmcgui.Dialog().select('Wybierz ',label)
    except:
        s = xbmcgui.Dialog().select('Wybierz',label)

    if isinstance(s,list):
        v = param[1]+':'+','.join([ value[i] for i in s])
    else:
        s = s if s>-1 else 0
        v = param[1]+':'+value[s]

    sr = '/'.join([x for x in [sortv,qualityv,versionv,v] if x])
    listMovies('https://nasze-kino.tv/filmy-online/'+sr,1)
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] =='Szukaj':
    addDir('[COLOR green]Nowe Szukanie[/COLOR]','',mode='SzukajNowe')
    history = getHistory()
    if not history == ['']:
        for entry in history:
            contextmenu = []
            contextmenu.append((u'Usun', 'XBMC.Container.Refresh(%s)'% build_url({'mode': 'SzukajUsun', 'ex_link' : entry})),)
            contextmenu.append((u'Usun cała historie', 'XBMC.Container.Update(%s)' % build_url({'mode': 'SzukajUsunAll'})),)
            addDir(name=entry, ex_link=entry.replace(' ','+'), mode='ListFS', fanart=None, contextmenu=contextmenu)
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] =='SzukajNowe':
    d = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu/serialu', type=xbmcgui.INPUT_ALPHANUM)
    if d:
        setHistory(d)
        ex_link=d.replace(' ','+')
        listFS(ex_link)
        xbmcplugin.setContent(addon_handle, 'tvshows')
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] =='SzukajUsun':
    remCache(ex_link)
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'SzukajUsunAll':
    delHistory()
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'folder':
    pass
else:
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
xbmcplugin.endOfDirectory(addon_handle)
