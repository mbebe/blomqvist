# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import base64
import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import resolveurl as urlresolver

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.bajeczkiorg')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=PATH+'fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )
from aadecode import AADecoder
exlink = params.get('url', None)
name= params.get('title', None)
page = params.get('page',[1])[0]

UA='Mozilla/5.0 (Linux; Android 7.0; PLUS Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36'
TIMEOUT=15

headers = {'User-Agent': UA,}
s = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=1):
	list_item = xbmcgui.ListItem(name)
	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')		
	if not infoLabels:
		infoLabels={'title': name}		
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'foldername': name, 'url' : url, 'page' : page}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	
def home():
	add_item('http://bajeczki.org/all-categories/', 'Wszystkie bajki', RESOURCES+'icon.png', True, "listbajki")	
	add_item('http://bajeczki.org/page/%d/?s=', 'Ostatnio dodane', RESOURCES+'icon.png', True, "ostdodane")			
	add_item('', '[COLOR lightblue]Szukaj[/COLOR]', '', True, "search")		
	xbmcplugin.endOfDirectory(addon_handle)

def ListBajki(exlink):
	links= getBajki(exlink)
	itemz=links
	items = len(links)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listodcinki', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)

def getBajki(url):		
	html=getUrlReq(url)
	out=[]
	try:
		result=parseDOM(html,'div', attrs={'class': "all-categories"})[0] #	<div class="content-block clear">
		links=parseDOM(result,'div', attrs={'class': "category-bar"})
		for link in links:
			href = parseDOM(link, 'a', ret='href')[0] 
			tit=parseDOM(link,'span')[0]
			ilosc=parseDOM(link,'strong')[0]
			title=tit+' ['+ilosc+']'
			out.append({ 'href'  : href,'img': '','title' : PLchar(title),'mediatype': 'movie'})					
	except:
		pass
	return out

def ListOdcinki(exlink):
	links= getOdcinki(exlink)
	itemz=links
	items = len(links)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)	

def getOdcinki(url):
	html=getUrlReq(url)
	out=[]
	try:
		result=parseDOM(html,'div', attrs={'class': "content-block clear"})[0] #	<div class="content-block clear">
		links=parseDOM(result,'div', attrs={'class': "hentry "})
		for link in links:
			href = parseDOM(link, 'a', ret='href')[0] 
			title=parseDOM(link,'a')[1]
			imag = parseDOM(link, 'img', ret='src')[0]
			out.append({ 'href'  : href,'img': imag,'title' : PLchar(title),'mediatype': 'movie', 'plot':PLchar(title)})					
	except:
		pass
	return out

def ListDodane(exlink,page):
	page = int(page) if page else 1	
	links, pagin = getDodane(exlink,page)
	if pagin[0]:
		add_item(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[0])	
	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
	if pagin[1]:
		add_item(name='[COLOR blue]>> Nastepna strona >>>[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[1])
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)	

def getDodane(url,page=1):	
	url=url%page
	html=getUrlReq(url)
	out=[]
	prevpage=False #gr=False
	nextpage=False  # pr=False	
	nxtpag=re.findall('<a class="next page-numbers" href="(.+?)">',html)	
	if nxtpag:
		nextpage = page+1
	links = parseDOM(html, 'article', attrs={'class': "hentry clear"})  #<article class="">
	for link in links:		
		href = parseDOM(link, 'a', ret='href')[0] #[1]
		imag = parseDOM(link, 'img', ret='src')[0]
		imag = re.sub('p/w(\d+)', 'p/w500', imag)		
		title = parseDOM(link, 'a')[1] #[1]
		out.append({'title':PLchar(title),'href':href,'img':imag})
	prevpage = page-1 if page>1 else False
	return (out,(prevpage,nextpage))	
		
def getUrlReq(url):
	content=s.get(url, headers=headers,verify=False).content
	return content

def __replaceSpecialCharacters(sString):
	return sString.replace('\\/','/').replace('&amp;','&').replace('\xc9','E').replace('&#8211;', '-').replace('&#038;', '&').replace('&rsquo;','\'').replace('\r','').replace('\n','').replace('\t','').replace('&#039;',"'").replace('&quot;','"').replace('&gt;','>').replace('&lt;','<').replace('&nbsp;','')

def abParse(sHtmlContent,start,end,startoffset=''):
	#usage oParser.abParse(sHtmlContent,"start","end")
	#startoffset (int) décale le début pour ne pas prendre en compte start dans le résultat final si besoin
	#usage2 oParser.abParse(sHtmlContent,"start","end",6)
	#ex youtube.py
	if startoffset:
		return sHtmlContent[startoffset + sHtmlContent.find(start):sHtmlContent.find(end)]
	else:
		return sHtmlContent[sHtmlContent.find(start):sHtmlContent.find(end)]
		
def parse(sHtmlContent, sPattern, iMinFoundValue = 1):
	sHtmlContent = __replaceSpecialCharacters(str(sHtmlContent))
	aMatches = re.compile(sPattern, re.IGNORECASE).findall(sHtmlContent)
	if (len(aMatches) >= iMinFoundValue):                
		return True, aMatches
	return False, aMatches
	
def Cdecode(sHtmlContent,encodedC):
	from jjdecode import JJDecoder

	sPattern =  '<([0-9a-zA-Z]+)><script>([^<]+)<\/script>'
	
	aResult = parse(sHtmlContent, sPattern)
	
	z = []
	y = []
	if (aResult[0] == True):
		for aEntry in aResult[1]:
			#z.append(JJDecoder(aEntry[1]).decode())
			z.append((aEntry[1]).decode())

		for x in z:
			r1 = re.search("atob\(\'([^']+)\'\)", x, re.DOTALL | re.UNICODE)
			if r1:
				y.append(base64.b64decode(r1.group(1)))
				
		for w in y:
	
			r2 = re.search(encodedC + "='([^']+)'", w)
			if r2:
				return r2.group(1)

def decode(urlcoded,a,b,c):
    TableauTest = {}
    key = ''

    l = a
    n = "0123456789"
    h = b
    j = 0

    while j < len(l) :
        k = 0
        while k < len(n):
            TableauTest[l[j] + n[k]] = h[int(j + k)]

            k+=1

        j+=1

    hash = c
    i = 0
    while i < len(hash):
        key = key + TableauTest[hash[i] + hash[i + 1]]
        i+= 2


    chain = base64.b64decode(urlcoded)

    secretKey = {}
    y = 0
    temp = ''
    url = ""

    x = 0
    while x < 256:
        secretKey[x] = x
        x += 1

    x = 0
    while x < 256:
        y = (y + secretKey[x] + ord(key[x % len(key)])) % 256
        temp = secretKey[x]
        secretKey[x] = secretKey[y]
        secretKey[y] = temp
        x += 1

    x = 0
    y = 0
    i = 0
    while i < len(chain):
        x += 1 % 256
        y = (y + secretKey[x]) % 256
        temp = secretKey[x]
        secretKey[x] = secretKey[y]
        secretKey[y] = temp

        url = url + (chr(ord(chain[i]) ^ secretKey[(secretKey[x] + secretKey[y]) % 256]))

        i += 1
        
    return url

def dekodujLink(sHtmlContent,urlcoded):
	reducesHtmlContent = abParse(sHtmlContent, '<z9></z9><script>','{if(document')
	sPattern =  '(\w+)'
	aResult = parse(reducesHtmlContent, sPattern)
	if aResult[0]:
		mlist = sorted(aResult[1], key=len)
		mlist = mlist[-2:]
		a = mlist[0]
		b = mlist[1]
	sPattern =  "=\['getAttribute','*([^']+)'*\]"
	
	aResult = parse(sHtmlContent, sPattern)
	api_call=''
	if aResult[0]:
		encodedC = aResult[1][0].replace('window.','')

		c = Cdecode(sHtmlContent,encodedC)
		if c:
			api_call = decode(urlcoded,a,b,c)
	if (api_call):
		return api_call + '|User-Agent=' + UA
	else:
		return ''

def getLinks(exlink):
	html=getUrlReq(exlink)	
	stream=''
	result=parseDOM(html,'div', attrs={'class': "entry-content"})#[0]	
	if result:
		src = parseDOM(result[0],'iframe', ret='src')[0]
		stream= 'https:'+src if src.startswith('//') else src
		if 'embed.mystream' in html:
			src=re.findall('"(http.+?mystream.to.+?)"',html)[0]
			html=getUrlReq(src)
			aResult = re.search('(ﾟωﾟ.+?\(\'_\'\);)', html,re.DOTALL | re.UNICODE)		
			if (aResult):
				sHtmlContent = AADecoder(aResult.group(1)).decode()
				
				try:
					stream_url=re.findall("""['"](http.+?.mp4)['"]""",sHtmlContent)[0]
					stream=''
				except:
					atob = re.findall("""atob\(['"](.+?)['"]""",sHtmlContent)#[0]
					if atob:
						urlcoded=atob[0]
						stream=''
						stream_url=dekodujLink(html,urlcoded)
	if stream:
		try:
			stream_url = urlresolver.resolve(stream)
		except Exception,e:
			stream_url=''
			sel = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Link nie działa.','ERROR: %s'%str(e))	
	if stream_url:	
		play_item = xbmcgui.ListItem(path=stream_url)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
	else:
		play_item = xbmcgui.ListItem(path='')
		sel = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Link nie działa.')
		xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)		

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&nbsp;',".").replace('&amp;','&')
	return char	

if __name__ == '__main__':
	mode = params.get('mode', None)
	if not mode:
		home()
	elif mode == 'listbajki':
		ListBajki(exlink)		
	elif mode == 'listodcinki':
		ListOdcinki(exlink)			
	elif mode == 'ostdodane':
		ListDodane(exlink,page)		
	elif mode == 'getLinks':
		getLinks(exlink)				
	elif mode == '__page__M':
		url = build_url({'mode': 'ostdodane', 'foldername': name, 'url' : exlink, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			query=query.replace(' ','+')
			elink='http://bajeczki.org/page/%d/?s='+query 		
			ListDodane(elink,page)	
