# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import base64
import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import resolveurl as urlresolver

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.bajeczkiorg')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=PATH+'fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )
from aadecode import AADecoder
exlink = params.get('url', None)
name= params.get('title', None)
page = params.get('page',[1])

UA='Mozilla/5.0 (Linux; Android 7.0; PLUS Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36'
TIMEOUT=15

headers = {'User-Agent': UA,}
s = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=1):
	list_item = xbmcgui.ListItem(name)
	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')		
	if not infoLabels:
		infoLabels={'title': name}		
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'foldername': name, 'url' : url, 'page' : page}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	
def home():
	add_item('http://bajeczki.org/all-categories/', 'Wszystkie bajki', RESOURCES+'icon.png', True, "listbajki")	
	add_item('http://bajeczki.org/page/%d/?s=', 'Ostatnio dodane', RESOURCES+'icon.png', True, "ostdodane")			
	add_item('', '[COLOR lightblue]Szukaj[/COLOR]', '', True, "search")		
	xbmcplugin.endOfDirectory(addon_handle)

def ListBajki(exlink):
	links= getBajki(exlink)
	itemz=links
	items = len(links)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listodcinki', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)

def getBajki(url):		
	html=getUrlReq(url)
	out=[]
	try:
		result=parseDOM(html,'div', attrs={'class': "all-categories"})[0] #	<div class="content-block clear">
		links=parseDOM(result,'div', attrs={'class': "category-bar"})
		for link in links:
			href = parseDOM(link, 'a', ret='href')[0] 
			tit=parseDOM(link,'span')[0]
			ilosc=parseDOM(link,'strong')[0]
			title=tit+' ['+ilosc+']'
			out.append({ 'href'  : href,'img': '','title' : PLchar(title),'mediatype': 'movie'})					
	except:
		pass
	return out

def ListOdcinki(exlink,page=1):
	page = int(page) if page else 1
	links, pagin= getOdcinki(exlink,page)

	itemz=links
	items = len(links)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	

	for x,y in getPageLinks(pagin).items():
		add_item(name=y, url=exlink, mode='listodcinki', image='', folder=True, page=x)
	add_item('http://bajeczki.org/all-categories/', 'Wszystkie bajki', RESOURCES+'icon.png', True, "listbajki")
	add_item('http://bajeczki.org/page/%d/?s=', 'Główna', RESOURCES+'icon.png', True, "")

	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle)	

def getOdcinki(url,page=1):
	url=url+'/page/%d/'%page
	html=getUrlReq(url)
	out=[]
	pages = getPages(html)

	try:
		result=parseDOM(html,'div', attrs={'class': "content-block clear"})[0] #	<div class="content-block clear">
		links=parseDOM(result,'div', attrs={'class': "hentry.*?"})
		for link in links:
			href = parseDOM(link, 'a', ret='href')[0] 
			title=parseDOM(link,'a')[1]
			imag = parseDOM(link, 'img', ret='data-src')[0]
			out.append({ 'href'  : href,'img': imag,'title' : PLchar(title),'mediatype': 'movie', 'plot':PLchar(title)})					
	except:
		pass
	return (out,pages)

def ListDodane(exlink,page):
	page = int(page) if page else 1	
	links, pagin = getDodane(exlink,page)

	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	

	for x,y in getPageLinks(pagin).items():
		add_item(name=y, url=exlink, mode='ostdodane', image='', folder=True, page=x)
	add_item('http://bajeczki.org/page/%d/?s=', 'Główna', RESOURCES+'icon.png', True, "")

	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)	

def getDodane(url,page=1):	
	url=url%page
	html=getUrlReq(url)
	pages = getPages(html)

	out=[]
	links = parseDOM(html, 'article', attrs={'class': "hentry clear"})  #<article class="">
	for link in links:		
		href = parseDOM(link, 'a', ret='href')[0] #[1]
		imag = parseDOM(link, 'img', ret='data-src')[0]
		imag = re.sub('p/w(\d+)', 'p/w500', imag)		
		title = parseDOM(link, 'a')[1] #[1]
		out.append({'title':PLchar(title),'href':href,'img':imag})
	return (out, pages)

def getPages(content):
	nav = re.findall('<nav class="navigation pagination".+?>(.+?)</nav>', content, re.DOTALL);
	if len(nav) != 0:
		nav = nav[0]
	else:
		return (False,False,False)

	currentPageStr = re.findall('<span .+? class="page-numbers current">(.+?)</span>', nav)
	allStr = re.findall('<a class=".*?page-numbers".*?>(.+?)</a>',nav)
	allStr = allStr + currentPageStr

	allInt = []
	for i in range(0, len(allStr)):
		if allStr[i].isdigit():
			allInt.append( int(allStr[i]) )

	if len(allInt) == 0:
		return (False,False,False)

	minPage = min(allInt)
	currentPage = int(currentPageStr[0])
	maxPage = max(allInt)
	return (minPage, currentPage, maxPage)

def getPageLinks(pages):
	if pages[0] == False:
		return {}

	min = pages[0]
	current = pages[1]
	max = pages[2]

	links = {}
	for x in range(min,max+1):
		if x == current:
			links[x]='[COLOR blue]>> Strona '+str(x)+' <<[/COLOR]'
		else:
			links[x]= 'Strona '+str(x)

	return links


def getUrlReq(url):
	content=s.get(url, headers=headers,verify=False).content
	return content

	
# https://github.com/Kodi-vStream/venom-xbmc-addons
# https://github.com/Kodi-vStream/venom-xbmc-addons
# https://github.com/Kodi-vStream/venom-xbmc-addons

def temp_decode(data):
    startpos = data.find('"\\""+') + 5
    endpos = data.find('"\\"")())()')

    first_group = data[startpos:endpos]

    l = re.search("(\(!\[\]\+\"\"\)\[.+?\]\+)", first_group, re.DOTALL)
    if l:
        first_group = first_group.replace(l.group(1), 'l').replace('$.__+', 't').replace('$._+', 'u').replace('$._$+', 'o')

        tmplist = []
        js = re.search('(\$={.+?});', data, re.DOTALL)
        if js:
            js_group = js.group(1)[3:][:-1]

            second_group = js_group.split(',')

            i = -1

            for x in second_group:
                a, b = x.split(':')

                if b == '++$':
                    i += 1
                    tmplist.append(("{}{}{}".format('$.', a, '+'), i))

                elif b == '(![]+"")[$]':
                    tmplist.append(("{}{}{}".format('$.', a, '+'), 'false'[i]))

                elif b == '({}+"")[$]':
                    tmplist.append(("{}{}{}".format('$.', a, '+'), '[object Object]'[i]))

                elif b == '($[$]+"")[$]':
                    tmplist.append(("{}{}{}".format('$.',a,'+'),'undefined'[i]))

                elif b == '(!""+"")[$]':
                    tmplist.append(("{}{}{}".format('$.', a, '+'), 'true'[i]))


            tmplist = sorted(tmplist, key=lambda x: x[1])

            for x in tmplist:
                first_group = first_group.replace(x[0], str(x[1]))

            first_group = first_group.replace(r'\\"' , '\\').replace("\"\\\\\\\\\"", "\\\\").replace('\\"', '\\').replace('"', '').replace("+", "")



    try:
        final_data = unicode(first_group, encoding = 'unicode-escape')
        return final_data
    except:
        return False

# https://github.com/Kodi-vStream/venom-xbmc-addons
# https://github.com/Kodi-vStream/venom-xbmc-addons
# https://github.com/Kodi-vStream/venom-xbmc-addons

def getLinks(exlink):
	html=getUrlReq(exlink)	
	stream=''
	result=parseDOM(html,'div', attrs={'class': "entry-content"})#[0]	
	
	if result:
		try:
			src = parseDOM(result[0],'iframe', ret='data-src')[0]
			stream= 'https:'+src if src.startswith('//') else src
			if 'embed.mystream' in html:
				src=re.findall('"(http.+?mystream.to.+?)"',html)[0]
				html=getUrlReq(src)
				aResult = re.findall('([$]=.+?\(\)\)\(\);)', html,re.DOTALL)	
				
				if (aResult):
					for i in aResult:
						decoded = temp_decode(i)
					
						if decoded:
							r = re.search("setAttribute\(\'src\', *\'([^']+)\'\)", decoded, re.DOTALL)
							if r:
								api_call = r.group(1)
					if (api_call):
						stream=''
						stream_url= api_call + '|User-Agent=' + UA + '&Referer=' + exlink + '&Origin=https://embed.mystream.to'
		except:
			import json
			new=re.findall('data-item="([^"]+)"',result[0])[0].replace('&quot;','"')
			new2=json.loads(new)
			stream=new2['sources'][0]['src']

	if stream:
		try:
			if 'mp4' not in stream:
				stream_url = urlresolver.resolve(stream)
			else:
				stream_url=stream
		except Exception,e:
			stream_url=''
			sel = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Link nie działa.','ERROR: %s'%str(e))	
	if stream_url:	
		play_item = xbmcgui.ListItem(path=stream_url)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
	else:
		play_item = xbmcgui.ListItem(path='')
		sel = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Link nie działa.')
		xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)		

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&nbsp;',".").replace('&amp;','&')
	return char	

if __name__ == '__main__':
	mode = params.get('mode', None)
	if not mode:
		home()
	elif mode == 'listbajki':
		ListBajki(exlink)		
	elif mode == 'listodcinki':
		ListOdcinki(exlink,page)
	elif mode == 'ostdodane':
		ListDodane(exlink,page)		
	elif mode == 'getLinks':
		getLinks(exlink)				
	elif mode == 'pageM':
		url = build_url({'mode': 'ostdodane', 'foldername': name, 'url' : exlink, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			query=query.replace(' ','+')
			elink='http://bajeczki.org/page/%d/?s='+query 		
			ListDodane(elink,page)	
