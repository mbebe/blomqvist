# -*- coding: utf-8 -*-
import sys
import os,re,urllib
import xbmc,xbmcaddon,xbmcgui,xbmcvfs
addonInfo    = xbmcaddon.Addon().getAddonInfo
file_open     = xbmcvfs.File
file_delete   = xbmcvfs.delete
dataPath     = xbmc.translatePath(addonInfo('profile')).decode('utf-8')
control        = xbmcgui.ControlImage
dialog = xbmcgui.WindowDialog()
KEYBOARD     = xbmc.Keyboard
def keyboard(response):
    i = os.path.join(dataPath,'captcha.png')
    f = file_open(i, 'w')
    f.write(response)
    f.close()
    f = control(450,5,375,115, i)
    d = dialog
    d.addControl(f)
    file_delete(i)
    d.show()
    k = xbmc.Keyboard('', '')
    k.doModal()
    c = k.getText() if k.isConfirmed() else None
    if c == '': c = None
    d.removeControl(f)
    d.close()
    return c