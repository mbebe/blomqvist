# -*- coding: utf-8 -*-

import sys
import urllib2,urllib
import os
import re
import base64,json
import cookielib
import cfcookie #cfcookie
import random
import unpackstd	
import control

import cfscrape
import xbmcgui
scraper = cfscrape.CloudflareScraper()

try:
    import captcha #recaptcha
except:
    pass
BASEURL='http://www.efilmy.tv/'
TIMEOUT = 10
bramka=''
UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0'
BRAMKA  = 'http://bramka.proxy.net.pl/index.php'
header={
    'User-Agent':UA,
 #   'Host':'www.efilmy.tv',
#    'Upgrade-Insecure-Requests':'1',
 #   'Connection': 'keep-alive',
 #   'Accept':'text/html,application/xhtml+xml,application/',
    }
kuka = control.setting('cfCookies')
logcok = control.setting('logcok')
dod='|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuka)
#import cfdeco7
#scrap = cfdeco7.create_scraper()
def getProksy():
    proksy = None
    if control.setting('proxy') == "true":
        try:
            proksy = control.setting('proxy_ip')
            if not proksy:
                proksy = None  
        except:
            proksy = None
	return proksy
	
def _getUrl(url,data=None,cookies=None):
	import ssl
	context = ssl._create_unverified_context()
	req = urllib2.Request(url,data)
	req.add_header('User-Agent', UA)
	if cookies:
		req.add_header('Cookie', cookies)
	try:
		response = urllib2.urlopen(req,context=context,timeout=TIMEOUT)
		content = response.read()
		response.close()
	except:
		content=''
	return content
	
def getUrl(url,data=None,header=None):
	cookies=cookieString(COOKIEFILE)
	control.setSetting('cfCookies',cookies)
	
	cookies=logcok
	
	
	content=_getUrl(url,data,cookies)
	
	if not content:
		cj=cf_setCookiesX(BASEURL)
		cookies=cookieString(COOKIEFILE)
		control.setSetting('cfCookies',cookies)
		content=_getUrl(url,data,cookies)
		if not content and BRAMKA:
			content = getUrlh(url,data,cookies)
			content = urllib.unquote(content)
	return content
	
def getUrlh(url, data = None, cookies = None):
    proksy=getProksy()
    proxies = {"https": proksy}
    header = {'User-Agent': UA, 'Cookie': cookies}
    print 'GATE in USE'
    import requests
    content = requests.get(url, headers=header, proxies=proxies).content
    return content
	
def cf_setCookies(content,cfile):
    cj = cookielib.LWPCookieJar()
    content=BASEURL
    cookieJar = cfcookie.createCookie(content,cj,UA)
    dataPath=os.path.dirname(cfile)
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    if cj:
        cj.save(cfile, ignore_discard = True)
    return cj
def logowanie():
	password = control.setting('password')
	username = control.setting('username')
	logowanie = control.setting('logowanie')
	premk='false'
	dod=''
	if password and username and logowanie=='true':
		import requests
		headers = {
			'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
		}
	
		response = scraper.get('http://www.efilmy.tv/').content
	
		hh=re.findall('"antycsrf" value="(.+?)"',response)[0]
		
		data = {
		'ok': '',
		'ga10': username,
		'gb10': password,
		'goto': 'Lw==',
		'cmd': 'glogin',
		'antycsrf': hh
		}
	
		response = scraper.post('http://www.efilmy.tv/user.html', data=data)
		sc=''.join(['%s=%s;'%(c.name, c.value) for c in scraper.cookies])
		control.setSetting('logcok',sc)
		if 'buj ponownie lub skorzystaj z funkcji <' in response.content:
			premk='false'
			xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Błędne dane logowania',xbmcgui.NOTIFICATION_INFO, 8000,False)
		elif '"user,logout.html">Wyloguj<' in response.content:
			if 'crown.png' in response.content:
				dok=re.findall('<span>premium:<\/span>(.+?)<',response.content,re.I)[0]
				dod='(Premium %s)'%dok
				premk='true'
			else:	
				dod='darmowe'
		control.setSetting('premka',premk)
	return premk,dod
def cf_setCookiesX(url):
	scraper.cookies = cookielib.LWPCookieJar(COOKIEFILE)
	#check = scraper.get(url)

	dataPath=os.path.dirname(COOKIEFILE)

	if not os.path.exists(dataPath):
		os.makedirs(dataPath)
	if scraper.cookies:
		scraper.cookies.save(COOKIEFILE, ignore_discard = True)
	return 	 	
	
def cookieString(COOKIEFILE):
    sc=''
    if os.path.isfile(COOKIEFILE):
        cj = cookielib.LWPCookieJar()
        cj.load(COOKIEFILE)
        for c in cj:
            sc+='%s=%s;'%(c.name, c.value)
    return sc
	
def get_content(url,data=None):
	out=[]
	nextPage=''
	prevPage=''
	header['Referer']=url,
	url=url.replace('efilmy.net/','efilmy.tv/')
	content = getUrl(url,data)
	items = re.compile('<div class="list-item">(.*?)</div>',re.DOTALL).findall(content)
	len(items)
	for item in items:
		href = re.compile('<a title=".*?" href="(.*?)" class="title_pl">(.*?)</a>').findall(item)
		href = re.compile('href="(.*?)" class="title_pl">(.*?)</a>').findall(item)
		en_title = re.compile('class="title_en">(.*?)</a>').findall(item)
		genre = re.compile('<span class="dst">Kategoria: <a title=".*?" href=".*?">(.*?)</a>').findall(item)
		plot = re.compile('<p>(.*?)</p>', re.DOTALL).findall(item)
		image = re.compile('<img class="poster" src="(.*?)"').findall(item)
		if href and image:
			h= BASEURL+href[0][0]
			t= href[0][1]
			i= 'http://www.efilmy.tv/'+image[0].replace('/small/','/big/')
			d= genre[0] if genre else ''
			o= plot[0] if plot else ''
			year=''
			audio=''
			tytul=''
			if en_title:
				year,audio = en_title[0].split('|')[-1].split(',')
				tytul=en_title[0].split('|')[0].strip()
				year = year.strip()
				audio = ' %s '%audio.strip()
			out.append({'title':charPL(t),'title_en':charPL(tytul),'code':audio,'url':h,'img':i+dod,'year':year,'plot':o})
		#	out.append({'title':charPL(t),'title_en':charPL(tytul),'audio':audio,'url':h,'img':i,'year':year,'plot':o})
	pagination = re.compile('<div class="pagin">(.*?)</div>',re.DOTALL).findall(content)
	if pagination:
		nextPage=re.compile('<a href="(.*?)".*?>\&laquo;</a>').findall(pagination[0])
		prevPage=re.compile('<a href="(.*?)"').findall(pagination[0])
		if nextPage:
			nextPage = BASEURL + nextPage[0]
		if prevPage:
			prevPage = BASEURL + prevPage[-1]
	return (out, (nextPage,prevPage))
	
def get_movie_cat_year(typF='year'):
    out=[]
    url='http://www.efilmy.tv/filmy.html'
    header['Referer']=url
    content = getUrl(url)
    subset = re.compile('<ul class="movie-%s">(.*?)</ul>'%typF,re.DOTALL).findall(content)
    if subset:
        if typF=='cat':
            items = re.compile('<a title=".*?" href="(.*?)">(.*?)</a><span>(.*?)</span>').findall(subset[0])
            for k in items:
                out.append( (' '.join(k[1:]),BASEURL+k[0]) )
        else:
            items = re.compile('<a title="(.*?)" href="(.*?)">').findall(subset[0])
            for k in items:
                out.append((k[0],BASEURL+k[1]))
    return out
	
def get_Serial_list(page=0):
    out=[]
    url='http://www.efilmy.tv/seriale.php?cmd=slist&page=%d'%page
    content = getUrl(url)
    items= re.compile('<a title=".*?" href="(.*?)">(.*?)</a>').findall(content)
    for item in items:
        out.append({'title':charPL(item[1]),'url':BASEURL+item[0]})
    return out
	
def get_Episode_list(url):
	out=[]
	content = getUrl(url)
	idx = content.find('<div class="holder">')
	imag = re.compile('<img alt.+src="(.+?)"').findall(content)
	if imag:
		img=BASEURL+imag[0]
	else:
		img=''
	plot = re.compile('<p class="dsc">(.+?)<').findall(content)	
	if plot:
		plot=plot[0]
	else:
		plot=''
	#<img alt=
	items = re.compile('<li>(.*?)</li>',re.DOTALL).findall(content[idx:])
	len(items)
	for e in items:
		href=re.compile('href="(.*?)"').findall(e)
		title=re.compile('>(.*?)<').findall(e)
		if href and title:
			h= BASEURL+href[0]
			t=''.join(title).replace('-->','').strip()
			out.append({'title':charPL(t),'url':h,'img':img,'plot':charPL(plot)})
	return out
	
def get_top(url):
    out=[]
    content = getUrl(url)
    divs= re.compile('(<div class=.*?</div>)',re.DOTALL).findall(content)
    for item in divs:
        href = re.compile('href="(.*?)" class="pl">(.*?)</a>').findall(item)
        en_title = re.compile('class="en">(.*?)</a>').findall(item)
        genre = re.compile('<span class="(cat|dsc)">.*?<a title=".*?" href=".*?">(.*?)</a>(.*?)<').findall(item)
        plot = re.compile('<p>(.*?)</p>',re.DOTALL).findall(item)
        image = re.compile('src="(.*?)"').findall(item)
        one={}
        if href :
            one['url']= BASEURL+href[0][0]
            one['title']= charPL(href[0][1])
            one['img']= 'http://www.efilmy.tv/'+image[0]+dod.replace('/small/','/big/') if image else ''
            one['year']=''
            if genre:
                if len(genre[0])==3:
                    one['genre']= genre[0][1] if genre else ''
                    try:
                        audio,year = genre[0][-1].split('|')[-1].split(',')
                        one['year'] = year.strip()
                        one['code'] = ' %s '%audio.strip()
                    except:
                        pass
            one['plot']= plot[0] if plot else ''
            if len(en_title)==2:
                one['title'] += ' [COLOR lightblue]%s[/COLOR]' %(' '.join(en_title))
            out.append(one)
    return out
	
def search(letter='teoria wielkiego'):
    url='http://www.efilmy.tv/szukaj.html'
    data='word=%s&as_values_movie_title=hidden' % (letter.replace(' ','+'))
    out=[]
    out, pagination = get_content(url,data)
    return out, pagination
	
	
def getGoUnlim(url):
	content=getUrl(url)
	packer = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)')
	import jsunpack as jsunpack
	packed = packer.findall(content)
	unpacked = jsunpack.unpack(packed[0])	
	src=re.findall("""sources:\[['"](.+?)['"]""",unpacked)[0]
	return src	
	
def getStreamin(url='http://streamin.to/embed-vz5xqczivdb8.html'):

    import jsunpack as jsunpack
    content=getUrl(url)
    packeds = re.compile('eval(.*?\)\)\))',re.DOTALL).findall(content)
    for packed in packeds:
        packed=re.sub('  ',' ',packed)
        packed=re.sub('','',packed)
        try:
            unpacked = jsunpack.unpack(packed)
        except:
            unpacked=''
        if unpacked:
            unpackedCont=unpacked
            try:
                stream_url = re.compile("""file\s*:\s*['|"](http.+?)['|"]""").findall(unpackedCont)[0]
                r = urllib2.Request(stream_url, headers={'User-Agent': UA})
                r = urllib2.urlopen(r, timeout=15).headers['Content-Length']
                return stream_url
            except:
                pass
            try:
                streamerEK = re.search('streamer:\s*"([^"]+)",', unpackedCont).group(1).replace(':1935', '')
                fileEK = re.search('file:\s*"([^"]+)",', unpackedCont).group(1).replace('.flv', '')
                return '%s playpath=%s' % (streamerEK, fileEK)
            except:
                pass
    return ''
def getVideoLinks(url):   #serialLinks
	premka = control.setting('premka')
	out=[]
	a={}
	content = getUrl(url)
	odtwarzacz = re.compile('Odtwarzacz <em>(.*?)</em>').findall(content)
	wersja = re.compile('Wersja: <em>(.*?)</em>').findall(content)
	ur_kVal = re.compile('name="ur_k" value="(.*?)"').findall(content)
	fphp='filmy.php'
	if ur_kVal:
		fphp = base64.b64decode(ur_kVal[0])
		fphp = fphp.split('?')[0]
	divId = re.compile('<div id="(.*?)" alt=".+?" class="embedbg">').findall(content)
	nturl='http://www.efilmy.tv/%s?cmd=show_regular&id=%s'
	if 'input class="green"' in content and premka=='true':
		nturl='http://www.efilmy.tv/%s?cmd=show_premium&id=%s'
	for id,odtwN,wersja in zip(divId,odtwarzacz,wersja):
		content = nturl%(fphp,id)
		kukz=logcok
		header['Cookie']=kukz
		headers = {

			'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
			'Cookie':kukz,
		}

		data = scraper.get(content,headers=headers).text

		if 'vidzer' in odtwN:
			href =re.compile('<a href="(.*?)".*?id="player">').search(data).group(1)
			if href:
				str_url = href +'|Referer=http://www.vidzer.net/media/flowplayer/flowplayer.commercial-3.2.18.swf'
				out.append({'href':str_url,'player':odtwN,'cmd':'regular','msg': '%s (regular)' %odtwN})
		elif '/stream/watch/' in data:
			str_url=re.findall('source src="(.+?)"',data)[0]
			out.append({'href':str_url,'player':odtwN,'cmd':'regular','msg': '%s [%s] (regular)' %(odtwN,wersja)})
		else:
			if 'streamin.to' in odtwN:
				href = re.compile('<a href="(.*?)" target="_blank">(.*?)</a>').findall(data)
				if href:
					href = href[0]
					if 'www.vidzer' in href[0] and  href[1].islower():
						str_url='http://%s/embed-%s.html'%(odtwN,href[1])
						out.append({'href':str_url,'player':odtwN,'cmd':'regular','msg': '%s [%s] (regular)' %(odtwN,wersja)})
			out.append({'href':'','player':odtwN,'cmd':'show','id':id,'typfs':fphp,'msg': '%s [%s] ([COLOR red]captcha to solve[/COLOR])' %(odtwN,wersja)})
	return out
def cfCookieSav(content,cfile):
    cj = cookielib.LWPCookieJar()
    cookieJar = cfcookie.createCookie(content.replace('efilmy.net/','efilmy.tv/'),cj,UA)
    dataPath=os.path.dirname(cfile)
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    if cookieJar:
        cookieJar.save(cfile, ignore_discard = True)
    return cj
def getMovieLinkEK(data):  #movieLinks
    str_url=''
    bs= re.compile("""document.write\(Base64.decode\("(.*?)"\)""").findall(data)
    if not bs:
        packed = re.compile("""eval(.*?)\{\}\)\)""",re.DOTALL).findall(data)
        try:
            unpacked = unpackstd.unpack(packed[0])			
			
        except:
            unpacked = ''
        bs= re.compile("""document.write\(Base64.decode\("(.*?)"\)""").findall(unpacked)
    if bs:
        a = bs[0].replace("\\\\x","").decode("hex") if "\\x" in bs[0] else bs[0]
        src = base64.b64decode(a)
        href = re.compile("""["'](http.*?)["']""").findall(src)
        if href:
            str_url=href[0]
    return str_url
def getLink_show_player(fphp,id,odtwN,**args):
	str_url=''
	bs=[]
	content = 'http://www.efilmy.tv/%s?cmd=show_player&id=%s'%(fphp,id)
	kukz = cookieString(COOKIEFILE)
	kukz=logcok
	if kukz:
		header['Accept']='text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
		header['Cookie']=kukz
		header['Referer']=content

	headers = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
		'Cookie':kukz,

	}
	
	
	
	data = scraper.get(content,headers=headers).text
	str_url=getMovieLinkEK(data)
	if not str_url:
		cj=cf_setCookiesX(content)
		strCookies = cookieString(COOKIEFILE)
		header['Accept']='image/webp,image/*,*/*;q=0.8'
		header['Cookie']=strCookies
		url='http://www.efilmy.tv/mirrory.php?cmd=generate_captcha&time=%f'%random.random()
		data = getUrl(url,header=header)
		r=captcha.keyboard(data)
		print r
		header['Accept']='text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
		header['Cookie']=strCookies
		content = 'http://www.efilmy.tv/mirrory.php?cmd=check_captcha'
		idEK=id.split('_')[0]
		mode = 's' if '_s' in id else 'f'
		capUrl = 'captcha=%s&id=%s&mode=%s'%(r,idEK,mode)
		data = getUrl(content,capUrl,header=header)
		str_url=getMovieLinkEK(data)
	return str_url
def charPL(letter):
    if type(letter) is not str:
        letter=letter.encode('utf-8')
    letter = letter.replace('&lt;br/&gt;',' ')
    letter = letter.replace('&quot;','"').replace('&amp;quot;','"')
    letter = letter.replace('&oacute;','ó').replace('&Oacute;','Ó')
    letter = letter.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    letter = letter.replace('&amp;','&')
    letter = letter.replace('\u0105','ą').replace('\u0104','Ą')
    letter = letter.replace('\u0107','ć').replace('\u0106','Ć')
    letter = letter.replace('\u0119','ę').replace('\u0118','Ę')
    letter = letter.replace('\u0142','ł').replace('\u0141','Ł')
    letter = letter.replace('\u0144','ń').replace('\u0144','Ń')
    letter = letter.replace('\u00f3','ó').replace('\u00d3','Ó')
    letter = letter.replace('\u015b','ś').replace('\u015a','Ś')
    letter = letter.replace('\u017a','ź').replace('\u0179','Ź')
    letter = letter.replace('\u017c','ż').replace('\u017b','Ż')
    return letter