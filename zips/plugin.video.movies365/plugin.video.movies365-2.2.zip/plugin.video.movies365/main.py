# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import base64
import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import json
import cookielib
import traceback
import urlparse
import js2py

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.movies365')
napisy = xbmc.translatePath('special://temp/napisyMOVIES365.txt')
napisyLos = xbmc.translatePath('special://temp/napisyLosMovies.txt')
PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'

FANART=RESOURCES+'fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

import magic_aes
exlink = params.get('url', None)
name= params.get('name', None)
page = params.get('page','')
mcount= params.get('moviescount', None)
movie= params.get('movie', None)
rys= params.get('image', None)

kukz=''
kkey = addon.getSetting('keyk')
sortv = addon.getSetting('sortV')
if not sortv:
	addon.setSetting('sortV','-')
sortn = addon.getSetting('sortN') if sortv else 'All'

katv = addon.getSetting('katV')
if not katv:
	addon.setSetting('katV','-')
katn = addon.getSetting('katN') if katv else 'All'

UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'
TIMEOUT=15

s = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=1,fanart=FANART,moviescount=0):
	list_item = xbmcgui.ListItem(label=name)

	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')
	if not infoLabels:
		infoLabels={'title': name,'plot':name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': FANART})
	ok=xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page, 'moviescount' : moviescount,'movie':movie,'name':name,'image':image}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	return ok

def home():	
	add_item('', '[B][COLOR khaki]Movies365[/COLOR][/B]', RESOURCES+'mov365.png', "homeMovies365", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR khaki]Los Movies[/COLOR][/B]', RESOURCES+'losm.png', "homeLosMovies", folder=True,fanart=RESOURCES+'fanart.png')
	
def homeMovies365():
	getKey()
	add_item('http://www.365movies.tv/en/movies/-/1/-/-/-/', '[B][COLOR khaki]Movies[/COLOR][/B]', 'DefaultMovies.png', "listmovies365", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('http://www.365movies.tv/en/movies/-/1/-/-/-/', '[B][COLOR khaki]Serials[/COLOR][/B]', 'DefaultTVShows.png', "listserials365", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', "[COLOR lightblue]Language:[/COLOR] [B]"+sortn+"[/B]",'DefaultRecentlyAddedMovies.png', "filtr:sort", folder=False)	
	add_item('', "[COLOR lightblue]Genre:[/COLOR] [B]"+katn+"[/B]",'DefaultRecentlyAddedMovies.png', "filtr:kateg", folder=False)	
	add_item('http://www.365movies.tv/en/movies/-/1/-/-/-/', '[B][COLOR khaki]Search[/COLOR][/B]', 'DefaultAddonsSearch.png', "listSearch", folder=True,fanart=RESOURCES+'fanart.png')

def homeLosMovies():
	add_item('http://losmovies.fun/latest-movies', '[B][COLOR khaki]Movies - latest[/COLOR][/B]', 'DefaultMovies.png', "listlosmovies", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film|category', '[B][COLOR khaki]Movies - genres[/COLOR][/B]', 'DefaultMovies.png', "GatunekRok", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film|country', '[B][COLOR khaki]Movies - countries[/COLOR][/B]', 'DefaultMovies.png', "GatunekRok", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('film|language', '[B][COLOR khaki]Movies with subtitles[/COLOR][/B]', 'DefaultMovies.png', "GatunekRok", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('http://losmovies.fun/watch-latest-tv-shows', '[B][COLOR goldenrod]TV shows - latest[/COLOR][/B]', 'DefaultTVShows.png', "listlosmovies", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('serial|category', '[B][COLOR goldenrod]TV shows - genres[/COLOR][/B]', 'DefaultTVShows.png', "GatunekRok", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('serial|country', '[B][COLOR goldenrod]TV shows - countries[/COLOR][/B]', 'DefaultTVShows.png', "GatunekRok", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('serial|language', '[B][COLOR goldenrod]TV shows with subtitles[/COLOR][/B]', 'DefaultTVShows.png', "GatunekRok", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR steelblue]Search[/COLOR][/B]', 'DefaultAddonsSearch.png', "szukaj", folder=True,fanart=RESOURCES+'fanart.png')

	
def getRequests(url):
	headers = {
		'User-Agent': UA,
		'Accept': 'text/html, */*; q=0.01',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': 'http://www.365movies.tv/en/home',
		'X-Requested-With': 'XMLHttpRequest',
		'Connection': 'keep-alive',
	}
	content=s.get(url,headers=headers,verify=False).content
	return content
	
def getRequests2(url):
	headers = {
		'User-Agent': UA,
		'Accept': 'text/html, */*; q=0.01',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': 'http://www.365movies.tv/en/home',
		'X-Requested-With': 'XMLHttpRequest',
		'Connection': 'keep-alive',
	}
	content=s.get(url,headers=headers,verify=False).content
	c=''
	return content,c
	
	
	
def ListLosMovies(url,pg):

	page = int(pg)
	links, pagin=getLosMovies(url,page)	
	itemz=links
	items = len(links)
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listLinkslosmovies', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	if pagin:
		for f in pagin:	
			add_item(name=f.get('title'), url=f.get('href'), mode='listlosmovies', image='', folder=True,page=f.get('page'))	

	xbmcplugin.endOfDirectory(addon_handle)		
	
def getLosMovies(url,page):
	if 'search?type' in url:
		url=url
	else:
		if '?page=' in url:
			url = re.sub(r'\?page=\d+', '?page=%d'%page,   url)  
		else:
			url = url + '?page=%d' %page
		
	out=[]
	npout=[]

	html,c=getUrlc(url)
	
	if html.find('class="nextLink">Next<')>0:
		npout.append({'title':'NEXT_PAGE','href':url,'img':'','plot':'','page':page+1}) 
	links=parseDOM(html,'div', attrs={'id': "movie-\d+"})
	for link in links:

		link=PLchar(link)
		qual=parseDOM(link,'div', attrs={'class': "movieQuality.+?"})[0]
		href= parseDOM(link, 'a', ret='href')[0]
		href = 'http://losmovies.fun'+href if href.startswith('/') else href
		imag= parseDOM(link, 'img', ret='src')[1]
		imag = 'http://losmovies.fun'+imag if imag.startswith('/') else imag
		tyt= parseDOM(link, 'h4')[0]
		plot='%s[CR]%s'%(tyt,qual)
		out.append({'title':tyt,'href':href,'img':imag,'code':qual,'plot':plot})
	return out,npout
	
def ListLinksLosmovies(url):
	movies, seasons=getLinksLosmovies(url)	
	if movies:
		itemz=movies
		items = len(movies)
		fold=False
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='getVideosLos', image=f.get('img'), IsPlayable=True, folder=False, infoLabels=f, itemcount=items)	
	elif seasons:
		items = len(seasons)
		for i in sorted(seasons.keys()):
			add_item(name=i, url=urllib.quote(str(seasons[i])), mode='getEpisodesLosmovies', image='', folder=True, infoLabels=i, itemcount=items)	
	xbmcplugin.endOfDirectory(addon_handle)	
	
def scanEpisLos(result,url,imag):
	out=[]
	links=parseDOM(result,'div', attrs={'id': "tabs.+?"})
	for link in links:
		ac=parseDOM(link,'div', attrs={'class': "season",'id': "season.+?"},ret='id')[0]
		ses=re.findall('(\d+)',ac)[0]
		eps=parseDOM(link,'h3')
		for ep in eps:
			epis=re.findall('(\d+)',ep)[-1]
			tyt=ep.replace('Watch Online: ','')
			out.append({'title':tyt,'href':url,'img':imag,'code':'','plot':'','season':int(ses),'episode':int(epis)})
	return out

def splitToSeasons(input):
    out={}
    seasons = [x.get('season') for x in input]
    for s in set(seasons):
        out['Sezon %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
	
def getEpisodesLosmovies(seasons):
	episodes = eval(urllib.unquote(seasons))[::-1]
	items=len(episodes)

	for f in episodes: 
		ses=f.get('season')
		epp=f.get('episode')
		tyt=f.get('title').split('Season')[0]
		tyt2='%sS%02dE%02d'%(tyt,ses,epp)
		add_item(name=tyt2, url=f.get('href')+'|'+f.get('title'), mode='listLinksSerial', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)

def ListLinksSerial(url):
	links=getLinksSerial(url)	
	if links:
		itemz=links
		items = len(links)
		fold=False
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='getVideosLos', image=f.get('img'), IsPlayable=True, folder=False, infoLabels=f, itemcount=items)

	xbmcplugin.endOfDirectory(addon_handle)
	
def getLinksSerial(url):	
	
	out=[]
	url,ids=url.split('|')
	orgtit,sezony=ids.split('Season')
	sez,epiz=re.findall('(\d+)',sezony,re.DOTALL)
	content,c =getUrlc(url)
	tyt2='%sS%02dE%02d'%(orgtit,int(sez),int(epiz))
	imag=re.findall('showRowImage"><img src="([^"]+)"',content,re.DOTALL)[0]
	reg='%s(.+?)</table>'%ids
	result=re.findall(reg,content,re.DOTALL)[0]

	links=parseDOM(result,'tr', attrs={'class': "linkTr"})
	co=1
	for link in links:
		href=parseDOM(link,'td', attrs={'class': "linkHidden linkHiddenUrl"})[0]
		tyt=parseDOM(link,'span', attrs={'data-server': ".+?"},ret='data-server')[0]
		if 'entervideo' in tyt.lower():
			tyt+=' (subtitles)'
		tytul='[B]%s[/B] - Link %s - %s'%(tyt2,co,tyt)
		qual=parseDOM(link,'td', attrs={'class': "linkQuality li.+?"})[0]
		plot='%s[CR]%s'%(tyt,qual)
		out.append({'title':tytul,'href':href,'img':imag,'code':qual,'plot':plot})
		co+=1
	return out
	
def getLinksLosmovies(url):
	content,c =getUrlc(url)
	movs=[]
	seasons=None

	orgtitle=parseDOM(content,'div', attrs={'id': "hiddenMovieName"})[0]
	imag=re.findall('showRowImage"><img src="([^"]+)"',content,re.DOTALL)[0]
	imag = 'http://losmovies.fun'+imag if imag.startswith('/') else imag
	descr=parseDOM(content,'div', attrs={'class': "showRow showRowDescription showRowText"})
	descr=descr[0] if descr else ''
	result=parseDOM(content,'div', attrs={'id': "seasons"})

	cod=re.findall('(function dec.+?</script>)', content, re.DOTALL)[0] 
	functs=cod.replace('function dec_','###function dec_').replace('</script>','###</script>')

	if result:
		result=result[0]
		episodes=scanEpisLos(result,url,imag)
		seasons = splitToSeasons(episodes)
			
	else:
		result=parseDOM(content,'table', attrs={'class': "table table-striped tableLinks"})[0]
		
		links=parseDOM(result,'tr', attrs={'class': "linkTr"})
		co=1

		for link in links:
			ids = parseDOM(link, 'span', attrs={'id': "serverLink.+?"},ret='id')[0] # <tr class="linkTr">
			servlink = re.findall('(\d+)',ids)
			lhid=parseDOM(link, 'td', attrs={'class': "linkHidden linkHiddenCode"})[0]#<td class="linkHidden linkHiddenCode">
			cdlink = parseDOM(link, 'td', attrs={'class': "linkHidden linkHiddenFormat"})[0]
			lhid=lhid.replace('&amp;','&')

			if servlink:
				slink = servlink[0]
				regex='###(function dec_%s.+?)###'%slink
				kod = re.findall(regex,functs,re.DOTALL)
				uruc = js2py.eval_js(kod[0])
				abc=uruc(lhid)   
				href = cdlink.replace('%s',abc)
				tyt=parseDOM(link,'span', attrs={'data-server': ".+?"},ret='data-server')[0]
				if 'entervideo' in tyt.lower():
					tyt+=' (subtitles)'
				tytul='[B]%s[/B] - Link %s - %s'%(orgtitle,co,tyt)
				qual=parseDOM(link,'td', attrs={'class': "linkQuality li.+?"})[0]
				plot='%s[CR]%s[CR]%s'%(tyt,qual,descr)
				movs.append({'title':tytul,'href':href,'img':imag,'code':qual,'plot':plot})
				co+=1
	return movs,seasons

def ListSerials365(url,pg,katv,sortv):
	page = int(pg)
	links, pagin=getSerials365(url,page,katv,sortv)	
	itemz=links
	items = len(links)
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listEpisodes365', image=f.get('img'), folder=True, infoLabels=f, itemcount=items,movie=False)	
	
	if pagin:
		for f in pagin:	
			add_item(name=f.get('title'), url=f.get('href'), mode='listserials365', image='', folder=True,page=f.get('page'),movie=False)	
			
	xbmcplugin.endOfDirectory(addon_handle)		

def getSerials365(url,page,katg,lang):

	out=[]
	npout=[]
	url='http://www.365movies.tv/en/movies/-/2/%s/%s/-/%d'%(katg,lang,page)
	url2='http://www.365movies.tv/en/pages/-/2/%s/%s/-/%d'%(katg,lang,page)
	html=getRequests(url)
	html=html.replace("\'",'"')
	html2=getRequests(url2)	
	
	lastpage=re.findall('>(.+?)</div>',html2,re.DOTALL)
	if lastpage:
		if page<int(lastpage[-1]):
			npout.append({'title':'NEXT_PAGE','href':'','img':'','plot':'','page':page+1}) 
	links=re.findall('<tr style="background: #EEEBDA;(.+?)Torrent download',html,re.DOTALL)

	for link in links:
		t=re.findall('>([^<]+)<',link,re.DOTALL)
		imag=re.findall('src="([^"]+poster.+?png)"',link)[0]
		links=re.findall('\("([^"]+)", "([^"]+)", "[^"]+", 1\)',link)
		if t and links:
			event,urlenc=links[0]	
			title,x1,x2,qual= t[:4]
			qual=qual.replace('&nbsp;|&nbsp;','')
			ftitle='%s (%s)'%(title,qual)
			plot=re.findall('Story: </b>(.+?)<br>',link)[0]
			href=re.findall('href="(\/[^"]+)"',link)[0]
			href=re.findall('_(.+?)$',event)[0]
			href='http://www.365movies.tv/en/links/'+href 

			out.append({'title':ftitle,'href':href,'img':imag,'plot':PLchar(plot),'code':qual})
	return out,npout
	
def ListEpisodes365(url,title):
	links=getEpisodes365(url,title)
	itemz=links
	items = len(links)

	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks365', image=f.get('img'), folder=True, infoLabels=f, itemcount=items,movie=False)	
	
	xbmcplugin.endOfDirectory(addon_handle)		
	
def getEpisodes365(url,title):
	out=[]
	html=getRequests(url)
	links=re.findall("""onclick="showEpisode\('.+?', '(.+?)', '.+?', '.+?'\)"><b>(.+?)</b>""",html)
	for epi,num in links:
		
		urlk= parseDOM(html, 'div', attrs={'id': epi})[0]
		urlk=urlk.replace("\'",'"')	
		urlk=urlk.encode('utf-8')

		href=urllib.quote(str(urlk))
		title=re.findall('^(.+?Episode\s*)',title)[0]		
		ftitle='%s%02d'%(title,int(num))
		out.append({'title':ftitle,'href':href,'img':rys,'plot':'','code':''})
	return out
	

def ListMovies365(url,pg,katv,sortv):
	page = int(pg)
	links, pagin=getMovies365(url,page,katv,sortv)	
	itemz=links
	items = len(links)
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks365', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	if pagin:
		for f in pagin:	
			add_item(name=f.get('title'), url=f.get('href'), mode='listmovies365', image='', folder=True,page=f.get('page'))	

	xbmcplugin.endOfDirectory(addon_handle)		
	
def getMovies365(url,page,katg,lang):
	out=[]
	npout=[]
	url='http://www.365movies.tv/en/movies/-/1/%s/%s/-/%d'%(katg,lang,page)
	url2='http://www.365movies.tv/en/pages/-/1/%s/%s/-/%d'%(katg,lang,page)
	html=getRequests(url)
	html=html.replace("\'",'"')
	html2=getRequests(url2)	
	lastpage=re.findall('>(.+?)</div>',html2,re.DOTALL)
	if lastpage:
		if page<int(lastpage[-1]):
			npout.append({'title':'NEXT_PAGE','href':'','img':'','plot':'','page':page+1}) 
		
	links=re.findall('<tr style="background: #EEEBDA;(.+?)border-bottom-width: 0px;"></td></tr>',html,re.DOTALL)
	for link in links:
		t=re.findall('>([^<]+)<',link,re.DOTALL)
		imag=re.findall('src="([^"]+poster.+?png)"',link)[0]
		links=re.findall('\("([^"]+)", "([^"]+)", "[^"]+", 1\)',link)
		if t and links:
			event,urlenc=links[0]	
			title,x1,x2,qual= t[:4]
			qual=qual.replace('&nbsp;|&nbsp;','')
			ftitle='%s (%s)'%(title,qual)
			plot=re.findall('Story: </b>(.+?)<br>',link)[0]
			href=re.findall('href="(\/[^"]+)"',link)[0]
			href=re.findall('_(.+?)$',event)[0]
			href='http://www.365movies.tv/en/links/'+href 
			out.append({'title':ftitle,'href':href,'img':imag,'plot':PLchar(plot),'code':qual})
	return out,npout
def ListSearch(pg):
	d = xbmcgui.Dialog().input(u'Search...', type=xbmcgui.INPUT_ALPHANUM)
	if d:
		pg = int(pg)
		movies,serials,pagin=getSearch(pg,d)
		if movies:
			itemz=movies
			items = len(movies)
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode='getLinks365', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)
		if serials:
			itemz=serials
			items = len(serials)

			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode='listEpisodes365', image=f.get('img'), folder=True, infoLabels=f, itemcount=items,movie=False)	
		if not serials and not movies:
			return
		else:
			xbmcplugin.endOfDirectory(addon_handle)	
def getSearch(pg,d):
	fout=[]
	sout=[]
	npout=[]
	url='http://www.365movies.tv/en/movies/-/-/-/-/%s/%s'%(d,pg)
	url2='http://www.365movies.tv/en/pages/-/-/-/-/%s/%s'%(d,pg)
	html=getRequests(url)
	html=html.replace("\'",'"')
	html2=getRequests(url2)	
	
	lastpage=re.findall('>(.+?)</div>',html2,re.DOTALL)

	if lastpage:
		ab=int(lastpage[-1])
		if pg<int(lastpage[-1]):
			npout.append({'title':'NEXT_PAGE','href':'','img':'','plot':'','page':pg+1}) 
	links=re.findall('<tr style="background: #EEEBDA;(.+?)"More info"',html,re.DOTALL)
	for link in links:
		link=link.replace('<span style="background-color:yellow;"><font color="red">','[COLOR orange]').replace('</font></span>','[/COLOR]')
		
		t=re.findall('>([^<]+)<',link,re.DOTALL)
		imag=re.findall('src="([^"]+poster.+?png)"',link)[0]
		links=re.findall('\("([^"]+)", "([^"]+)", "[^"]+", 1\)',link)
		if t and links:
			event,urlenc=links[0]	
			title,x1,x2,qual= t[:4]
			if 'IMDb' not in x1:
				qual=x1
			qual=qual.replace('&nbsp;|&nbsp;','')
			ftitle='%s (%s)'%(title,qual)
			plot=re.findall('Story: </b>(.+?)<br>',link)[0]
			href=re.findall('href="(\/[^"]+)"',link)[0]
			#href=re.findall('(\w+$)',href)[0]
			href=re.findall('_(.+?)$',event)[0]
			href='http://www.365movies.tv/en/links/'+href 
			typ=re.findall('href=".+?">([^>]+)</a>',link)[0]
			if 'serial' in typ.lower():
				sout.append({'title':ftitle,'href':href,'img':imag,'plot':PLchar(plot),'code':qual})
			else:
				fout.append({'title':ftitle,'href':href,'img':imag,'plot':PLchar(plot),'code':qual})
	return fout,sout,npout
					
def getKey():	
	ret =''
	content = getRequests('http://www.365movies.tv/en/')
	wrapper = re.compile('(http[^"]+/advertisement.js\?\d+)').findall(content)
	wrappers = re.compile('<script type="text/javascript" src="(http://m1.medianetworkinternational.com/js/\w+.js)"').findall(content)
	for wrapper in wrappers:
		wc = getRequests(wrapper)
		content=JsUnwiser().unwiseAll(wc)
		ret = content
		ret = re.compile('return "(.*?)"').findall(content)
		if ret:
			ret = ret[0]
	addon.setSetting('keyk',ret)
	return ret	
	
def getLinks365(url,movie,rys,nme):
	movie=eval(movie)
	links = getVideos365(url,movie,rys,nme)	

	itemz=links
	items = len(links)
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='Play365', image=f.get('image'), folder=False,IsPlayable=True, itemcount=items)	
	xbmcplugin.setContent(addon_handle, 'videos')	
	xbmcplugin.endOfDirectory(addon_handle)			
		
def getVideos365(url,movie,rys,nme):
	out=[]
	if movie:
		html=getRequests(url)
		html=html.replace("\'",'"')	
	else:
		html= urllib.unquote(url)
	links=re.findall('onClick=.*?,\s*"([^"]+)".',html,re.DOTALL)
	co=1
	for link in links:
		try:
			enc_data=json.loads(base64.b64decode(link))    
			ciphertext = 'Salted__' + enc_data['s'].decode('hex') + base64.b64decode(enc_data['ct'])	
			src= magic_aes.decrypt(kkey,base64.b64encode(ciphertext))
			src=src.strip('"').replace('\\','')	
			src=re.findall("""src=['"](.+?)['"]""",src)[0]
			ftitle='[COLOR blue]%s - [/COLOR]Link %s'%(nme, co)
			out.append({'title':ftitle,'href':src,'image':rys})
			co+=1
		except:
			pass
	return out
	
	
def vtttostrLos(vtt):
    subs=re.findall('^(.+?-->\s+.+)',vtt,re.MULTILINE)
    row=0
    for sub in subs:
        row = row + 1
        d=re.findall('(\d+:\d+:\d+.\d+ -->)',sub) 
        if not d:
            sub2='%02d:%s'%(0,sub)
        else:
            d=re.findall('(\d+):\d+:\d+.\d+ -->',sub)
            sub2='%02d:%s'%(int(d[0]),sub)
        p1=re.findall('(\d+:\d+:\d+.\d+ -->)',sub2)
        p2=re.findall('--> (.+?)$',sub)
        d=re.findall('(\d+:\d+:\d+.\d+)',p2[0])
        if not d:
            sub2='%s%02d:%s'%(p1[0],0,p2[0])       
        else:
            p2ok=re.findall('-->\s*\d+:(.+?)$',sub)[0]
            d=re.findall('(\d+):\d+:\d+.\d+',p2[0])
            d=int(d[0])
            sub2='%s %02d:%s'%(p1[0],d,p2ok)
        nx=sub2
        nx=nx.replace(".",',')

        vtt=vtt.replace(sub,nx)
    vtt = re.sub(r'WEBVTT\n\n', '', vtt)
	
	
    vtt = re.sub(r'WEBVTT FILE\r\n\r\n', '', vtt)
	
	
    vtt = re.sub(r'WEBVTT FILE\n', '', vtt)
    vtt = re.sub(r'Kind:[ \-\w]+\n', '', vtt)
    vtt = re.sub(r'Language:[ \-\w]+\n', '', vtt)
    vtt = re.sub(r'<c[.\w\d]*>', '', vtt)
    vtt = re.sub(r'</c>', '', vtt)
    vtt = re.sub(r'<\d\d:\d\d:\d\d.\d\d\d>', '', vtt)
    vtt = re.sub(r'::[\-\w]+\([\-.\w\d]+\)[ ]*{[.,:;\(\) \-\w\d]+\n }\n', '', vtt)
    vtt = re.sub(r'Style:\n##\n', '', vtt)    
    return vtt
	
def EnterVidSub(link):
	content,c =getUrlc(link)
	
	sout=[]
	hrefsubt=re.findall('<[^<]+src="(.+?)".+?label="(.+?)">',content)
	for uri,subtitle in hrefsubt:

		sout.append((subtitle,uri))
	if len(sout)>0:
		
		label = [x[0].strip() for x in sout]
		stream = [x[1].strip() for x in sout]
		sel = xbmcgui.Dialog().select('Select subtitle',label)
		
		if sel>-1:
			napis=stream[sel]
			content , c = getUrlc(napis)
			poprawiony=vtttostrLos(content)
			open(napisyLos, 'w').write(poprawiony)		
			nap=True
		else:
			nap=False
	else:
		nap=False
	return nap

def getVideosLos(link):
	import resolveurl
	try:
		hmf = resolveurl.HostedMediaFile(url=link)
		if not hmf:
			xbmcgui.Dialog().notification('[COLOR red][B]Error[/B][/COLOR]', "[COLOR red][B]Can't resolve this link.[/B][/COLOR]", xbmcgui.NOTIFICATION_INFO, 5000)
			return
		else:
			stream_url = resolveurl.resolve(link)
	except Exception,e:
		stream_url=''
		s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))
	
	if stream_url:
		play_item = xbmcgui.ListItem(path=stream_url)
		if 'entervideo' in link:
			napis=EnterVidSub(link)
			if napis:
				play_item.setSubtitles([napisyLos])

		xbmcplugin.setResolvedUrl(addon_handle, True, play_item)	
	else:
		xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
	
	
def getUrlc(url, data=None, header={}, usecookies=True):
    cj = cookielib.LWPCookieJar()
    if usecookies:
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        urllib2.install_opener(opener)
    if not header:
        header = {'User-Agent': UA}
    req = urllib2.Request(url, data, headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        link = response.read()
        response.close()
    except:
        link=''
    c = ';'.join(['%s=%s' % (c.name, c.value) for c in cj]) if cj else ''
    return link, c	

def vtttostr(vtt):
    subs=re.findall('^(.+?-->\s+.+)',vtt,re.MULTILINE)
    row=0
    for sub in subs:
        row = row + 1
        d=re.findall('(\d+:\d+:\d+.\d+ -->)',sub) 
        if not d:
            sub2='%02d:%s'%(0,sub)
        else:
            d=re.findall('(\d+):\d+:\d+.\d+ -->',sub)
            sub2='%02d:%s'%(int(d[0]),sub)
        p1=re.findall('(\d+:\d+:\d+.\d+ -->)',sub2)
        p2=re.findall('--> (.+?)$',sub)
        d=re.findall('(\d+:\d+:\d+.\d+)',p2[0]) 
        if not d:
            sub2='%s%02d:%s'%(p1[0],0,p2[0])       
        else:
            p2ok=re.findall('-->\s*\d+:(.+?)$',sub)[0]
            d=re.findall('(\d+):\d+:\d+.\d+',p2[0])
            d=int(d[0])
            sub2='%s %02d:%s'%(p1[0],d,p2ok)
        nx=str(row) +'\n'+sub2
        nx=nx.replace(".",',')

        vtt=vtt.replace(sub,nx)
    vtt = re.sub(r'WEBVTT\n\n', '', vtt)
    vtt = re.sub(r'Kind:[ \-\w]+\n', '', vtt)
    vtt = re.sub(r'Language:[ \-\w]+\n', '', vtt)
    vtt = re.sub(r'<c[.\w\d]*>', '', vtt)
    vtt = re.sub(r'</c>', '', vtt)
    vtt = re.sub(r'<\d\d:\d\d:\d\d.\d\d\d>', '', vtt)
    vtt = re.sub(r'::[\-\w]+\([\-.\w\d]+\)[ ]*{[.,:;\(\) \-\w\d]+\n }\n', '', vtt)
    vtt = re.sub(r'Style:\n##\n', '', vtt)    
    return vtt
	
def selM3U8(stream_url,playlist):
	lout=[]
	sout=[]
	o = urlparse.urlparse(stream_url).query
	kk2=stream_url.replace('index.m3u8?','').replace(o,'')
	lektors=re.findall('TYPE=AUDIO.+?NAME="(.+?)".+?URI="(.+?)"',playlist,re.DOTALL)
	subtitles=re.findall('TYPE=SUBTITLE.+?NAME="(.+?)".+?URI="(.+?)"',playlist,re.DOTALL)

	for lektor,uri in lektors:
		m3u8=kk2+uri
		lout.append((lektor,m3u8))
	for subtitle,uri2 in subtitles:
		m3u82=kk2+uri2+'|'+kk2
		sout.append((subtitle,m3u82))	
	return lout,sout	
	
	
def Play3651st(url):
	header = {'User-Agent': UA,
			'Referer': url}	
	html = s.get(url, headers=header).content
	#import uuid
	#hash = uuid.uuid4().hex
	#url = re.findall(r'location.replace\(\'([^\']+)', html)[0]
	#uri = url + hash
	#html = s.get(uri, headers=header).content
	link=re.findall('src="([^"]+embed.+?)"',html,re.DOTALL)[0]
	data = s.get(link, headers=header).content
	f = re.compile('.*?name="f"\s*value=["\']([^"\']+)["\']').findall(data)
	d = re.compile('.*?name="d"\s*value=["\']([^"\']+)["\']').findall(data)
	r = re.compile('.*?name="r"\s*value=["\']([^"\']+)["\']').findall(data)
	b = re.compile('.*?name="b"\s*value=["\']([^"\']+)["\']').findall(data)
	action = re.compile('[\'"]action[\'"][,\s]*[\'"](http.*?)[\'"]').findall(data)
	srcs = re.compile('src=[\'"](.*?)[\'"]').findall(data)
	if f and r and d and action:
	
	
		head = {
			'Host': 'h6.adshell.net',
			'User-Agent': UA,
			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
			'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
			'Referer': link,
			'Upgrade-Insecure-Requests': '1',}
		if b:
			data = {'b': b[0],'r': r[0],'d': d[0],'f': f[0]}
		else:
			data = {'r': r[0],'d': d[0],'f': f[0]}
		data2 = s.post(action[0], headers=head, cookies=s.cookies, data=data).content
	
		bheaders = header
		bheaders['Referer'] = action[0]
		banner = re.findall(r'videojs.*?script\s+src="([^"]+)', data2)[0]
		bsrc = s.get(banner, headers=bheaders).content
		
		banner = re.findall(r"url:'([^']+)", bsrc)[0]
		bsrc = s.get(banner, headers=bheaders).content
		bheaders['Referer'] = banner
		banner = re.findall(r'window.location.replace\("([^"]+)"\);\s*}\)<\/script><div', bsrc)[0]
		bsrc = s.get(banner,verify=False).content
		bsrc=bsrc.replace("\'",'"')
		try:
			hh, c = getUrlc("https://adbetnet.advertserve.com/servlet/view/dynamic/javascript/zone?zid=281&pid=4&resolution=1920x1080&random=11965377&millis=1473441350879&referrer=http%3A%2F%2Fwww.365movies.tv%2Fen%2Fhome", header=header, usecookies=True)
			hh=hh.replace('\\"',"'")
			nxturl=re.findall("var URL\s*=\s*'(.+?)'",hh)[0]
			datax, c2 = getUrlc(nxturl, header=header, usecookies=True)	
		except:
			pass
		
		link = re.compile('\([\'"][^"\']+[\'"], [\'"][^"\']+[\'"], [\'"]([^"\']+)[\'"], 1\)').findall(data2)
		enc_data = json.loads(base64.b64decode(link[0]))
		ciphertext = 'Salted__' + enc_data['s'].decode('hex') + base64.b64decode(enc_data['ct'])
		src = magic_aes.decrypt(kkey,base64.b64encode(ciphertext))
		src = src.replace('"','').replace('\\','').encode('utf-8')
		a, c = getUrlc(srcs[-1], header=header, usecookies=True) if srcs else '', ''
		a, c = getUrlc(src, header=header, usecookies=True)
		lektors,subtitles=selM3U8(src,a)
		if len(subtitles)>0:
			if subtitles:
				label = [x[0].strip() for x in subtitles]
				stream = [x[1].strip() for x in subtitles]
				sel = xbmcgui.Dialog().select('Select subtitle',label)
				if sel>-1:
					napis=stream[sel].split('|')
					
					dla=napis[1]
					
					rid = re.findall('(&rid=\w+)',napis[0])
					
					content , c = getUrlc(napis[0], header=header, usecookies=True)
					nxturl=re.findall('(\d+.\d+.vtt.+?[b|s]id=\w+)',content,re.DOTALL)[0]
					if rid:
						content , c = getUrlc(dla+nxturl+rid[0], header=header, usecookies=True)
					else:
						content , c = getUrlc(dla+nxturl, header=header, usecookies=True)
					poprawiony=vtttostr(content)
					open(napisy, 'w').write(poprawiony)		
					nap=True
				else:
					nap=False	
		else:
			nap=False
		playlist=''		

		if src.startswith('http'):
			stream_url = src + '|Referer=%s&User-Agent=%s&Cookie=%s' % (action[0],UA,c)
			return stream_url,nap
		else:
			stream_url = magic_aes.decode_hls(src)
			if stream_url:
				stream_url += '|Origin=http://h6.adshell.net&Referer=%s&User-Agent=%s&Cookie=%s' % (action[0],UA,c)
				return stream_url,nap

def idle():

    if float(xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')[:4]) > 17.6:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    else:
        xbmc.executebuiltin('Dialog.Close(busydialog)')


def busy():

    if float(xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')[:4]) > 17.6:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    else:
        xbmc.executebuiltin('ActivateWindow(busydialog)')


def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&#039;',"'")
	char = char.replace('&quot;','"')
	char = char.replace('&nbsp;',".").replace('&amp;','&')
	return char	
class JsUnwiser:
    def unwiseAll(self, data):
        try:
            in_data=data
            sPattern = 'eval\\(function\\(w,i,s,e\\).*?}\\((.*?)\\)'
            wise_data=re.compile(sPattern).findall(in_data)
            for wise_val in wise_data:
                unpack_val=self.unwise(wise_val)
                in_data=in_data.replace(wise_val,unpack_val)
            return re.sub(re.compile("eval\(function\(w,i,s,e\).*?join\(''\);}", re.DOTALL), "", in_data, count=1)
        except: 
            traceback.print_exc(file=sys.stdout)
            return data
        
    def containsWise(self, data):
        return 'w,i,s,e' in data
        
    def unwise(self, sJavascript):
        page_value=""
        try:        
            ss="w,i,s,e=("+sJavascript+')' 
            exec (ss)
            page_value=self.__unpack(w,i,s,e)
        except: traceback.print_exc(file=sys.stdout)
        return page_value
        
    def __unpack( self,w, i, s, e):
        lIll = 0;
        ll1I = 0;
        Il1l = 0;
        ll1l = [];
        l1lI = [];
        while True:
            if (lIll < 5):
                l1lI.append(w[lIll])
            elif (lIll < len(w)):
                ll1l.append(w[lIll]);
            lIll+=1;
            if (ll1I < 5):
                l1lI.append(i[ll1I])
            elif (ll1I < len(i)):
                ll1l.append(i[ll1I])
            ll1I+=1;
            if (Il1l < 5):
                l1lI.append(s[Il1l])
            elif (Il1l < len(s)):
                ll1l.append(s[Il1l]);
            Il1l+=1;
            if (len(w) + len(i) + len(s) + len(e) == len(ll1l) + len(l1lI) + len(e)):
                break;
            
        lI1l = ''.join(ll1l)
        I1lI = ''.join(l1lI)
        ll1I = 0;
        l1ll = [];
        for lIll in range(0,len(ll1l),2):
            ll11 = -1;
            if ( ord(I1lI[ll1I]) % 2):
                ll11 = 1;
            l1ll.append(chr(    int(lI1l[lIll: lIll+2], 36) - ll11));
            ll1I+=1;
            if (ll1I >= len(l1lI)):
                ll1I = 0;
        ret=''.join(l1ll)
        if 'eval(function(w,i,s,e)' in ret:
            ret=re.compile('eval\(function\(w,i,s,e\).*}\((.*?)\)').findall(ret)[0] 
            return self.unwise(ret)
        else:
            return ret
			
def Play365(url):	
	stream_url,napis = Play3651st(url)	
	play_item = xbmcgui.ListItem(path=stream_url)
	if napis:
		play_item.setSubtitles([napisy])
	if stream_url:
		xbmcplugin.setResolvedUrl(addon_handle, True, play_item)	
	else:
		xbmcplugin.setResolvedUrl(addon_handle, False,  xbmcgui.ListItem(path=''))	

def getSort(mv='film',sc='category'):
	label=[]
	value=[]
	
	if mv=='film':
		
		if sc=='category':
			url = 'http://losmovies.fun/movie-genres'
		elif sc=='country': 
			url = 'http://losmovies.fun/countries'
		elif sc=='language': 
			url = 'http://losmovies.fun/watch-movies-with-subtitles'
			
		content,c =getUrlc(url)
		result=parseDOM(content,'div', attrs={'class': "showEntities.+?"})[0]
		result=result.replace('&nbsp;',' ').replace('With ','')
		label=re.findall('showRowText">([^>]+)</div>',result) 
		value=re.findall('href="([^"]+)"\s*class="showRow showRowLinkMovies">',result)
		
	elif mv=='serial':
		if sc=='category':
			url = 'http://losmovies.fun/movie-genres'
		elif sc=='country': 
			url = 'http://losmovies.fun/countries'
		elif sc=='language': 
			url = 'http://losmovies.fun/watch-movies-with-subtitles'

		content,c =getUrlc(url)
		result=parseDOM(content,'div', attrs={'class': "showEntities.+?"})[0]
		result=result.replace('&nbsp;',' ').replace('With ','')
		label=re.findall('showRowText">([^>]+)</div>',result)
		value=re.findall('href="([^"]+)"\s*class="showRow showRowLinkTvShows">',result)
	return (label,value)	
			
if __name__ == '__main__':
	mode = params.get('mode', None)
	
	if not mode:
		home()
		xbmcplugin.endOfDirectory(addon_handle)		

	elif mode == 'homeMovies365':
		homeMovies365()
		xbmcplugin.endOfDirectory(addon_handle)		
		
	elif mode == "homeLosMovies":
		homeLosMovies()
		xbmcplugin.endOfDirectory(addon_handle)	
		
	elif mode == 'Play365':
		Play365(exlink)			
	elif mode == 'getLinks365':
		getLinks365(exlink,movie,rys,name)			


	elif mode == 'getVideosLos':
		getVideosLos(exlink)		
		
	elif mode == 'listLinkslosmovies':
		ListLinksLosmovies(exlink)	
	elif mode == 'listLinksSerial':
		ListLinksSerial(exlink)	
		
	elif mode == 'listSearch':
		ListSearch(page)	
	
	elif mode == 'listserials365':
		ListSerials365(exlink,page,katv,sortv)	
		
	elif mode == 'listmovies365':
		ListMovies365(exlink,page,katv,sortv)			
	
	elif mode == 'listEpisodes365':
		ListEpisodes365	(exlink,name)	
	
	elif 'kateg' in mode:
		myMode = 'kat'

		label=['All','Action','Adventure','Animation','Biography','Comedy','Crime','Documentary','Drama','Family','Fantasy','History','Horror','Mystery','Romance','Sci-Fi','Sport','Thriller','War','Western']
		value=['-','12','15','13','14','16','17','18','19','20','21','22','23','24','26','27','28','29','30','31']

		msg = 'Genre'
		sel = xbmcgui.Dialog().select(msg,label)
		if sel>-1:
		
			addon.setSetting(myMode+'V',value[sel])
			addon.setSetting(myMode+'N',label[sel])
			
			xbmc.executebuiltin("Container.Refresh") 
		else:
			pass	

	elif 'filtr' in mode:
	
		myMode = 'sort'	
		label=['All','Bahasa Indonesia','Dansk','Deutsch','English','Español','Français','Italiano','Lietuvių','Magyar','Nederlands, Vlaams','Norsk','Polski','Svenska','Русский','Українська','עברית','हिन्दी, हिंदी','中文 (Zhōngwén)','日本語']
		value=['-','id','da','de','en','es','fr','it','lt','hu','nl','no','pl','sv','ru','uk','he','hi','zh','ja']
		msg = 'Language'
		sel = xbmcgui.Dialog().select(msg,label)
		if sel>-1:
		
			addon.setSetting(myMode+'V',value[sel])
			addon.setSetting(myMode+'N',label[sel])		
			xbmc.executebuiltin("Container.Refresh") 
		else:
			pass	

	elif mode == 'getEpisodesLosmovies':	
		getEpisodesLosmovies(exlink)
		xbmcplugin.endOfDirectory(addon_handle,True)
	
	elif mode == 'listlosmovies':	
		ListLosMovies(exlink,page)
		xbmcplugin.endOfDirectory(addon_handle,True)
			
	elif mode == 'GatunekRok':
		param = exlink.split('|')
		label,value = getSort(mv = param[0], sc = param[1])
		what='Select %s'%param[1]
		try:
			sel = xbmcgui.Dialog().select(what,label)
		except:
			sel = xbmcgui.Dialog().select(what,label)

		if sel>-1:
			v = value[sel]
			ListLosMovies('http://losmovies.fun'+v,1)
			xbmcplugin.endOfDirectory(addon_handle,True)
		else:
			xbmc.executebuiltin('XBMC.Container.Refresh()')		
	elif mode == 'szukaj':
		query = xbmcgui.Dialog().input(u'Search... ', type=xbmcgui.INPUT_ALPHANUM,)
		if query:
			query=query.replace('+','%2B').replace(' ','+')
			urlnxt='http://losmovies.fun/123movies-search?type=movies&q=%s'%query
			ListLosMovies(urlnxt,1)
