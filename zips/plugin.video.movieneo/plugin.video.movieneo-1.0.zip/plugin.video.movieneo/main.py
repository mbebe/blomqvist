# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import cookielib

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.movies365')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
FANART=RESOURCES+'fanart.jpg'

exlink = params.get('url', None)
name= params.get('name', None)
page = params.get('page','')
mcount= params.get('moviescount', None)
movie= params.get('movie', None)
rys= params.get('image', None)

UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'
TIMEOUT=15

s = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=1,fanart=FANART,moviescount=0):
	list_item = xbmcgui.ListItem(label=name)

	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')
	if not infoLabels:
		infoLabels={'title': name,'plot':name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': FANART,'icon':image})
	ok=xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page, 'moviescount' : moviescount,'movie':movie,'name':name,'image':image}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	return ok

def home():	
	add_item('https://movieneo.com/films-latest/1', '[B][COLOR khaki]Filmy (najnowsze)[/COLOR][/B]', RESOURCES+'mov.png', "Latests", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://movieneo.com/films/1', '[B][COLOR khaki]Filmy (najpopularniejsze)[/COLOR][/B]', RESOURCES+'mov.png', "Latests", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://movieneo.com/tvseries-latest/1', '[B][COLOR khaki]Seriale (najnowsze)[/COLOR][/B]', RESOURCES+'mov.png', "Latests", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://movieneo.com/tv-series/1', '[B][COLOR khaki]Seriale (najpopularniejsze)[/COLOR][/B]', RESOURCES+'mov.png', "Latests", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://movieneo.com/films/short/1', '[B][COLOR khaki]Krótkie filmiki[/COLOR][/B]', RESOURCES+'mov.png', "Latests", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('https://movieneo.com/music/1', '[B][COLOR khaki]Muzyka[/COLOR][/B]', RESOURCES+'mov.png', "Latests", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', '[B][COLOR steelblue]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "szukajMovieneo", folder=True,fanart=RESOURCES+'fanart.png')

def getUrlc(url, data=None, header={}, usecookies=True):
    cj = cookielib.LWPCookieJar()
    if usecookies:
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        urllib2.install_opener(opener)
    if not header:
        header = {'User-Agent': UA}
    req = urllib2.Request(url, data, headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        link = response.read()
        response.close()
    except:
        link=''
    c = ';'.join(['%s=%s' % (c.name, c.value) for c in cj]) if cj else ''
    return link, c	

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&#039;',"'")
	char = char.replace('&quot;','"')
	char = char.replace('&nbsp;',".").replace('&amp;','&')
	return char	

def ListLatest(url,page):
	page = int(page)
	if 'search-results' in url:
		links, pagin=getListSearch(url,page)	
		url =url+'?sort=null&order=asc&page=%d'%page
	else:
		links, pagin=getLatest(url,page)	
	itemz=links
	items = len(links)
	if items>0:
		for f in itemz:
			add_item(name=f.get('title'), url=f.get('href'), mode='playMovieneo', image=f.get('img'), IsPlayable=True, folder=False, infoLabels=f, itemcount=items)	
		if pagin:
			for f in pagin:	
				add_item(name=f.get('title'), url=f.get('href'), mode='Latests', image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))	
		xbmcplugin.setContent(addon_handle, 'videos')	
		xbmcplugin.endOfDirectory(addon_handle)	
	else:
		xbmcgui.Dialog().notification('[COLOR red][B]Błąd[/B][/COLOR]', "[COLOR red][B]Brak materiałów do wyświetlenia.[/B][/COLOR]", xbmcgui.NOTIFICATION_INFO, 5000)

def getLatest(url,page):
	if re.findall('/(\d+)',url)[-1]:
		url = re.sub(r'/\d+', '/%d'%page,   url)  
	else:
		url = url + '/%d' %page
		
	out=[]
	npout=[]

	html,c=getUrlc(url)
	if html.find('">Dalej</a>')>0:
		npout.append({'title':'Następna strona','href':url,'img':'','plot':'','page':page+1}) 
	result = parseDOM(html,'div', attrs={'class': "col-sm-12 col-md-10 col-lg-8"})[0] 
	links = parseDOM(result,'div', attrs={'class': "item col-lg-12 clearfix media-list-item"}) 
	for link in links:
		trwa=parseDOM(link,'div', attrs={'class': "video-length"})[0] 
		href= parseDOM(link, 'a', ret='href')[0]
		href = 'https://movieneo.com'+href if href.startswith('/') else href

		imag = parseDOM(link, 'img', ret='src')[0]
		imag = 'https://movieneo.com'+imag.replace('&amp;','&') if imag.startswith('/') else imag.replace('&amp;','&')
		tyt = parseDOM(link, 'img', ret='alt')[0]
		plot = parseDOM(link,'div', attrs={'class': "item-detail-bigblock description"})
		if plot:
			plot= plot[0].strip()
			if plot:
				plot = plot
			else:
				plot =tyt
		else:
			plot = tyt
		out.append({'title':PLchar(tyt),'href':PLchar(href),'img':imag,'code':trwa,'plot':PLchar(plot)})
	return out,npout
	
def getListSearch(url,page):

	url = re.sub(r'&page=\d+', '?&page=%d'%page,   url)  
	out=[]
	npout=[]
	html,c=getUrlc(url)
	
	if html.find('">Dalej</a>')>0:
		npout.append({'title':'Następna strona','href':url,'img':'','plot':'','page':page+1}) 
	result = parseDOM(html,'div', attrs={'class': "row search-results"})[0]
	links = parseDOM(result,'div', attrs={'class': "item col-lg-12 clearfix"}) 
	for link in links:

		trwa=parseDOM(link,'div', attrs={'class': "video-length"})[0]
		href= parseDOM(link, 'a', ret='href')[0]
		href = 'https://movieneo.com'+href if href.startswith('/') else href
		imag = parseDOM(link, 'img', ret='src')[0]
		imag = 'https://movieneo.com'+imag.replace('&amp;','&') if imag.startswith('/') else imag.replace('&amp;','&')
		tyt = parseDOM(link, 'img', ret='alt')[0]
		plot = parseDOM(link,'div', attrs={'class': "item-detail-bigblock description"})
		if plot:
			plot= plot[0].strip()
			if plot:
				plot = plot
			else:
				plot =tyt
		else:
			plot = tyt
		out.append({'title':PLchar(tyt),'href':PLchar(href),'img':imag,'code':trwa,'plot':PLchar(plot)})
	return out,npout
	
	
def PlayMovieneo(url):
	html,c=getUrlc(url)
	html=html.replace("\'",'"')
	src = re.findall('src:\s*"([^"]+)',html)
	if src:
		play_item = xbmcgui.ListItem(path=src[0])
		xbmcplugin.setResolvedUrl(addon_handle, True, play_item)

if __name__ == '__main__':
	mode = params.get('mode', None)
	
	if not mode:
		home()
		xbmcplugin.endOfDirectory(addon_handle)		

	elif mode == 'playMovieneo':	
		PlayMovieneo(exlink)		

	elif mode == "Latests":	
		ListLatest(exlink,page)
		xbmcplugin.endOfDirectory(addon_handle,True)	
		
	elif mode == 'szukajMovieneo':
		query = xbmcgui.Dialog().input(u'Szukaj... ', type=xbmcgui.INPUT_ALPHANUM,)
		if query:
			urlnxt='https://movieneo.com/search-results/%s?sort=null&order=asc&page=1'%query 
			ListLatest(urlnxt,1)