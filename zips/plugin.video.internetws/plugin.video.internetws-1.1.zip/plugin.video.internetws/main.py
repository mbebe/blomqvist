# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import urlparse
import urllib
import urllib2
#import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import base64
import string
from CommonFunctions import parseDOM
from CommonFunctions import replaceHTMLCodes

import cookielib
import json

#urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.internetws')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
COOKIEFILE = os.path.join(DATAPATH,'intws.cookie')

sess = requests.Session()
sess.cookies = cookielib.LWPCookieJar(COOKIEFILE)

RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )
prem=''
exlink = params.get('url', None)
name= params.get('title', None)
page = params.get('page',[1])[0]


UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0'


def add_items(url,name, mode, iconimage=None, infoLabels=False, IsPlayable=True, isFolder = False, fanart=FANART,itemcount=1, page=1):
	u = build_url({'mode': mode, 'url' : url, 'foldername': '', 'page':page,'prem':prem})
	if iconimage==None:
		iconimage='DefaultFolder.png'
	liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
	art=dict(zip(art_keys,[iconimage for x in art_keys]))
	liz.setArt(art)
	if not infoLabels:
		infoLabels={'title': name}
	liz.setInfo(type='video', infoLabels=infoLabels)
	if IsPlayable:
		liz.setProperty('IsPlayable', 'true')
	if fanart:
		liz.setProperty('fanart_image',fanart)
	ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=isFolder,totalItems=itemcount)
	return ok

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


def build_url(query):
    return base_url + '?' + urllib.urlencode(query)
	

def home():
	loging()
	add_items('','[B]Telewizja[/B]','listtv', IsPlayable=False, isFolder=True, fanart=FANART)	
	add_items('','[B]Transmisje sportowe[/B]','listsport', IsPlayable=False, isFolder=True, fanart=FANART)
	add_items('https://vod.internetowa.tv/filmy-online/','[B]Filmy[/B]','listmovies', IsPlayable=False, isFolder=True, fanart=FANART)	
	add_items('kategorię','[I]-   kategorie[/I]','gatunek', IsPlayable=False, isFolder=False, fanart=FANART)	
	add_items('rok','[I]-   rok[/I]','gatunek', IsPlayable=False, isFolder=False, fanart=FANART)	
	add_items('jakość','[I]-   jakość[/I]','gatunek', IsPlayable=False, isFolder=False, fanart=FANART)		
	add_items('wersję','[I]-   wersja[/I]','gatunek', IsPlayable=False, isFolder=False, fanart=FANART)	
	add_items('https://vod.internetowa.tv/seriale-online/','[B]Seriale[/B]','listserials', IsPlayable=False, isFolder=True, fanart=FANART)	
	add_items('https://vod.internetowa.tv/dla-dzieci/','[B]Dla dzieci[/B]','listmovies', IsPlayable=False, isFolder=True, fanart=FANART)	
	add_items('','[COLOR blue][B]Szukaj (filmy/seriale)[/B][/COLOR]','search', IsPlayable=False, isFolder=True, fanart=FANART)	
	
def loging():
	global prem
	
	username = addon.getSetting('userws')
	password = addon.getSetting('passws')	
	
	if username and password:
		sess.headers = {
			'User-Agent': UA,
			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
			'Referer': 'https://internetowa.tv/logowanie/',
			'Content-Type': 'application/x-www-form-urlencoded',
			'Connection': 'keep-alive',
			'Upgrade-Insecure-Requests': '1',}	
		
		html = sess.get('https://internetowa.tv/logowanie/', headers=sess.headers)#.content
		captcha = re.search('https://internetowa.tv/captcha/',html.content)
		if captcha:	
			import mc
			headers = {
				'Host': 'internetowa.tv',
				'user-agent': UA,
				'accept': 'image/webp,*/*',
				'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
				'referer': 'https://internetowa.tv/logowanie/',
				'dnt': '1',
				'te': 'trailers',
			}
			
			response = sess.get('https://internetowa.tv/captcha/', cookies=html.cookies,headers=headers,verify=False)
			rx=mc.keyboard(response.content)
		data = {'email': username,'password': password,'captcha':rx}
		
		response = sess.post('https://internetowa.tv/logowanie/#', headers=sess.headers, data=data,allow_redirects=False)	
		
		if response.cookies.get('login') is not None:
			sess.cookies.save()	
	
		html=sess.get('https://internetowa.tv/konto/',cookies=sess.cookies).content
		datkon=re.findall('Konto premium, wa.+?ne do (.+?). Masz',html)
		darm=re.findall('Brak konta premium',html)
		
		if datkon:
			info=datkon[0]
			add_items('','[B][COLOR orange](%s)[/COLOR] - [COLOR green]premium do %s[/COLOR][/B]'%(username,info),'settings', IsPlayable=False, isFolder=False, fanart=FANART)	
			prem=True
			
		elif darm:			
			add_items('','[B][COLOR orange](%s)[/COLOR] - [COLOR red]konto darmowe[/COLOR][/B]'%username,'settings', IsPlayable=False, isFolder=False, fanart=FANART)
			prem=False		
			
		else:
			xbmcgui.Dialog().notification('Błąd', 'Niepoprawne dane logowania.', xbmcgui.NOTIFICATION_INFO, 5000)
			add_items('','[B]Zaloguj[/B]','settings', IsPlayable=False, isFolder=False, fanart=FANART)	
			prem=False				
	else:
		xbmcgui.Dialog().notification('Błąd', 'Brak danych logowania.', xbmcgui.NOTIFICATION_INFO, 5000)
		add_items('','[B]Zaloguj[/B]','settings', IsPlayable=False, isFolder=False, fanart='')	
		prem=False	
	
def ListMovies(exlink,page):
	page = int(page) if page else 1	
	links,pagin= getMovies(exlink,page)
	
	if pagin[0]:
		add_items(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__M', iconimage='', isFolder=True, page=pagin[0])
	itemz=links
	items = len(links)
	my_mode	='playvideo'
	fold=False
	isplay=True
	for f in itemz:
	
		add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), fanart=f.get('img'), infoLabels=f, IsPlayable=isplay, isFolder=fold,itemcount=items)
	if pagin[1]:
		add_items(name='[COLOR blue]>> Nastepna strona >>[/COLOR]', url=exlink, mode='__page__M', iconimage='', isFolder=True, page=pagin[1])

def getMovies(url,page=1):
	if '&page=' in url:
		url = url.replace('&page=','&page=%d' %page)
	else:
		url = url + '&page=%d' %page			

	r = sess.get(url)
	html=r.content
	out=[]
	serout=[]
	
	prevpage=False #gr=False
	nextpage=False  # pr=False	
	if html.find("<li class='next'>")>0:
		nextpage = page+1

	links = parseDOM(html, 'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"})  #<div class="col-lg-3 col-md-4 col-sm-6 col-12 p-3">

	for link in links:
		link=replaceHTMLCodes(link)
		imag= parseDOM(link, 'img', ret='src')[0]
		title= parseDOM(link, 'div', attrs={'class': "title"})[0]	
		year = parseDOM(link, 'div', attrs={'class': "year"})[0]
		href = parseDOM(link, 'a', ret='href')[0]
		plot = ''
		out.append({'title':PLchar(title),'href':href,'img':imag,'plot':'','year':int(year)})
	prevpage = page-1 if page>1 else False
	return (out, (prevpage,nextpage))
	
def ListSerials(exlink):
	linksser = getSerials(exlink)
	if linksser:
		itemz=linksser
		items = len(linksser)
		my_mode	='listsezon'
		fold=True	
		isplay=False
		xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = '%R, %Y, %P')	
	for f in itemz:
		add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), fanart=f.get('img'), infoLabels=f, IsPlayable=isplay, isFolder=fold,itemcount=items)
	
def getSerials(url):
	out=[]
	html = sess.get(url).text
	first = parseDOM(html, 'div', attrs={'id': "item-list"})[0] #<div id="item-list"
	second = parseDOM(html, 'div', attrs={'id': "item-list"})[1]	
	content=first+second
	result = parseDOM(html, 'ul', attrs={'id': "series-list"})[0]
	hreftitle=re.findall('<a href="(.+?)" title="(.+?)">',result)
	for href,title in hreftitle:
		title=PLchar(title)
		regex='img src="(.+?)" alt="'+title+'"'
		aa=re.findall(regex,content)#[0]
		if aa:
			imag=aa[0]	
		else:
			imag=getImag(href)
			title=PLchar(title)	

		out.append({'title':title,'href':href,'img':imag})
	return out

def getImag(url):
	html = sess.get(url).text
	imagsub=parseDOM(html,'div', attrs={'id': "single-poster"})[0]# <div id="single-poster" class="col-sm-3">
	imag = parseDOM(imagsub, 'img', ret='src')[0]
	return imag
	
def ListSezon(exlink):
	links=getSezons(exlink)	
	items = len(links)
	my_mode	='listepisod'
	fold=True	
	isplay=False
	for f in links:
		aa=f.get('img').split('|')
		add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=aa[0], fanart=aa[1], infoLabels=f, IsPlayable=isplay, isFolder=fold,itemcount=items)
	
def getSezons(exlink):
	out=[]
	html = sess.get(exlink).text
	
	plot=parseDOM(html,'p', attrs={'class': "description"})[0] #<p class="description">
	imagsub=parseDOM(html,'div', attrs={'id': "single-poster"})[0]# <div id="single-poster" class="col-sm-3">
	imag = parseDOM(imagsub, 'img', ret='src')[0]
	fanartsub=parseDOM(html,'div', attrs={'style': "background-size.+?"},ret='style')[0]#<div id="item-headline
	fimage=re.findall('url\((.+?)\)',fanartsub)[0]
	result=parseDOM(html,'ul', attrs={'id': "episode-list"})[0]  #<table class="streamtable">
	subset=parseDOM(result,'span')
	imag=imag+'|'+fimage
	for subs in subset:
		out.append({'title':subs,'href':exlink+'|'+subs,'img':imag,'plot':PLchar(plot)})
	return out	

def ListEpisod(exlink):
	links=getEpisodes(exlink)	
	if links:
		items = len(links)
		my_mode	='playvideo'
		fold=False	
		isplay=True
		for f in links:	
			aa=f.get('img').split('|')
			add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=aa[0], fanart=aa[1], infoLabels=f, IsPlayable=isplay, isFolder=fold,itemcount=items)
	
def getEpisodes(exlink):
	out=[]
	urlsez=exlink.split('|')
	html = sess.get(urlsez[0]).text	
	plot=parseDOM(html,'p', attrs={'class': "description"})[0] #<p class="description">
	imagsub=parseDOM(html,'div', attrs={'id': "single-poster"})[0]# <div id="single-poster" class="col-sm-3">
	imag = parseDOM(imagsub, 'img', ret='src')[0]
	fanartsub=parseDOM(html,'div', attrs={'style': "background-size.+?"},ret='style')[0]#<div id="item-headline
	fimage=re.findall('url\((.+?)\)',fanartsub)[0]
	imag=imag+'|'+fimage	
	regex='<span>'+urlsez[1]+'<\/span>.+?<\/ul>'
	result=re.findall(regex,html,re.DOTALL)[0]
	subset=parseDOM(result,'li') 
	for subs in subset:
		href = parseDOM(subs, 'a', ret='href')[0]
		title = parseDOM(subs, 'a')[0]	
		out.append({'title':PLchar(title),'href':href,'img':imag,'plot':PLchar(plot)})
	return out	
	
def ListTv(exlink):
	global prem	
	
	premk = params.get('prem', None)
	if 'True' in premk:
		items=getTVprem()
		isFolder = False
		IsPlayable = True
		my_mode = 'playTV'	
		for f in items:	
			add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,itemcount=len(items))
		xbmcplugin.endOfDirectory(addon_handle,True)
	else:
		ab = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Tylko konta premium')
	
	
def getEpg(subset,dane):
	plot=''
	for subs in subset:
		if dane in subs:		
			ass=re.findall('<span class="bigTitle">(.+?)<\/span>.+?<span class="bigTime">(.+?)</span>',subs,re.DOTALL)
			for tyt,czas in ass:
				plot+='[B][COLOR khaki]'+czas+'[/B][/COLOR][COLOR blue] '+tyt+'[/COLOR][CR]'
		else:
			pass
	return plot
	
def PlayTV(exlink):
	if 'm3u8' in exlink:
		stream_url=exlink
	else:
		try:
			if os.path.isfile(COOKIEFILE):
				sess.cookies.load()	
			html=sess.get(exlink).content
			iframe = parseDOM(html, 'iframe', ret='src')[0]
			sess.headers.update({'Referer': exlink})
			html=(sess.get(iframe).content).replace("\'",'"')
			if 'js/hls.js' in html:
				stream_u=re.findall("""hls.loadSource\(['"](.+?)['"]\)""",html)[0]
			else:
				stream_u=re.findall('src="(.+?m3u8.+?)"',html)[0]
			stream_url=stream_u +'|Referer='+iframe	 
		except:
			ab = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Tylko konta premium')	
			return
	play_item = xbmcgui.ListItem(path=stream_url)
	xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def PlayVideo(exlink):

	streams = getVideos(exlink);
	stream_url = ''

	if len(streams) > 1:
		t = [ x.get('title') for x in streams]
		u = [ x.get('url') for x in streams]
		h = [ x.get('host') for x in streams]
		al = "   [ HOST ] "
		select = xbmcgui.Dialog().select(al, t)
	else:
		select = -1
		u = [ x.get('url') for x in streams]
 #   if select > -1:

	stream = u[select];
	if 'internetowa' in stream:
		stream_url=stream
	else:
		import resolveurl #as urlresolver
		stream_url = resolveurl.resolve(stream)		
		
	if stream_url:	
		play_item = xbmcgui.ListItem(path=stream_url)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
	else:
		play_item = xbmcgui.ListItem(path='')
		xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)	
		
def getVideos(url):
	out=[]
	html=sess.get(url).content
	results=parseDOM(html,'tr')#[0]
	for result in results:
		href = parseDOM(result, 'a', ret='href')#[0]
		if href:
			href=href[0]
			host = parseDOM(result, 'img', ret='alt')[0]		
			verqual = parseDOM(result, 'td')#[0]
			title='[%s] [%s] [%s]'%(host,verqual[0],verqual[1])
			if 'internetowa.tv' in href:
				
				if os.path.isfile(COOKIEFILE):
					sess.cookies.load()
				html=sess.get(href).content
				nxthref=re.findall('source: "(.+?)"',html)[0]
				href=nxthref+'|Referer=' +href
			out.append({'title':title,'url':href,'host':host})
		else:
			pass
	return out
		
def ListSport():
	links=getSport()	
	
	if links:
		items=links
		isFolder = False
		IsPlayable = True
		my_mode = 'playTV'			
		for f in items:	
			add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,itemcount=len(items))
		xbmcplugin.endOfDirectory(addon_handle,True)		
	else:
		s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Tylko konta premium :-(')	
		
	#xbmcplugin.endOfDirectory(addon_handle,True)	
	
def getSport():
	out=[]
	html = sess.get('https://internetowa.tv/transmisje/').text
	
	result=parseDOM(html,'table', attrs={'class': "streamtable"})[0]  #<table class="streamtable">
	subset=parseDOM(result,'tr')
	plot=''
	for subs in subset:
		imag = parseDOM(subs, 'img', ret='src')[0]	
		dysc= parseDOM(subs, 'img', ret='alt')[0]
		href = parseDOM(subs, 'a', ret='href')[0]	
		title = parseDOM(subs, 'a')[0]	
		czas = parseDOM(subs, 'td')	
		czas=czas[2]+' - '+czas[3]
		plot='[B][COLOR orange]'+PLchar(dysc)+'[/B][/COLOR][CR][B][COLOR khaki]'+PLchar(czas)+'[/B][/COLOR][COLOR blue] '+PLchar(title)+'[/COLOR][CR]'
		out.append({'title':'[B][COLOR yellowgreen]'+PLchar(czas)+' - [/B][/COLOR] '+PLchar(title),'href':href,'img':imag,'plot':plot})
	return out
	
	
def getTVprem():
	out=[]
	html = sess.get('https://internetowa.tv/').text		
	result=parseDOM(html,'div', attrs={'id': "allhome"})[0] 
	items=parseDOM(html,'div', attrs={'class': "channelb"})#[0] 
	html = sess.get('https://internetowa.tv/program-tv/').content
	result=parseDOM(html,'div', attrs={'id': "epgBig"})[0] 
	subset=parseDOM(result,'tr')		
	for item in items:
		#imag=item['stationLogo']
		href = parseDOM(item, 'a', ret='href')[0]
		imag = parseDOM(item, 'img', ret='src')[0]
		title = parseDOM(item, 'a', ret='title')[0]		
		plot=getEpg(subset,imag)	
		one={
			'href': href,
			'img': imag,
			'title': PLchar(title),
			'plot':PLchar(plot),}
		out.append(one)
	return out

def getGatunek(exlink):
	
	out=[]
	url_main='https://vod.internetowa.tv/filmy-online/'
	html = sess.get(url_main,verify=False).content
	result= parseDOM(html, 'div', attrs={'class': "col-sm-3"})[1] 
	if 'kategorię' in exlink:	
		link=parseDOM(result, 'ul', attrs={'id': "filter-category"})[0] 
		dane=re.findall('data-id="(.+?)" ><a href="#">(.+?)<\/a',link,re.DOTALL)
		for dan in dane:
			genre=dan[1]
			url=url_main+'/sort:date/category:%s/'%dan[0]
			out.append((genre, url))
	if 'rok' in exlink:
		link=parseDOM(result, 'ul', attrs={'id': "filter-year"})[0] 
		dane=re.findall('data-id="(.+?)" ><a href="#">(.+?)<\/a',link,re.DOTALL) 
		for dan in dane:
			year=dan[1]
			url=url_main+'/sort:date/year:%s/'%dan[0]
			out.append((year, url))	
	if 'wersję' in exlink:
		link=parseDOM(result, 'ul', attrs={'id': "filter-version"})[0]
		dane=re.findall('data-id="(.+?)" ><a href="#">(.+?)<\/a',link,re.DOTALL)
		for dan in dane:
			vers=dan[1]
			url=url_main+'/sort:date/version:%s/'%dan[0]
			out.append((vers, url))	
	if 'jakość' in exlink:
		link=parseDOM(result, 'ul', attrs={'id': "filter-quality"})[0]
		dane=re.findall('data-id="(.+?)" ><a href="#">(.+?)<\/a',link,re.DOTALL)
		for dan in dane:
			chan=dan[1]
			url=url_main+'/sort:date/quality:%s/'%dan[0]
			out.append((chan, url))		
	return out	

def search(q='batman'):
	out=[]
	serout=[]
	data = {'phrase': q}
	html = sess.post('https://vod.internetowa.tv/szukaj',data=data).content
	links = parseDOM(html, 'div', attrs={'class': "col-xs-3 col-lg-2"})
	for link in links:
		link=replaceHTMLCodes(link)
		imag= parseDOM(link, 'img', ret='src')[0]
		title = parseDOM(link, 'div', attrs={'class': "title"})[0]
		year = parseDOM(link, 'div', attrs={'class': "year"})#[0]
		if year:
			try:
				year=int(year[0])
			except:
				year=''
		else:
			year=''
		href = parseDOM(link, 'a', ret='href')[0]
		if 'serial-online' in href:
			serout.append({'title':PLchar(title),'href':href,'img':imag})	
		else:
			out.append({'title':PLchar(title),'href':href,'img':imag,'year':year})
	return out,serout	

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")		
	char = char.replace('Napisy PL',"[COLOR lightblue](napisy pl)[/COLOR]")
	char = char.replace('Lektor PL',"[COLOR lightblue](lektor pl)[/COLOR]")
	char = char.replace('Dubbing PL',"[COLOR lightblue](dubbing pl)[/COLOR]")	
	return char	

if __name__ == '__main__':
	mode = params.get('mode', None)
	
	if not mode:
		home()		
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		xbmcplugin.endOfDirectory(addon_handle,True)	
		
	elif mode == 'settings':
		addon.openSettings()
		xbmc.executebuiltin('XBMC.Container.Refresh()')
		
	elif mode == 'listtv':
		ListTv(exlink)
		
	elif mode == 'listmovies':
		ListMovies(exlink,page)		
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		xbmcplugin.endOfDirectory(addon_handle,True)	
		
	elif mode == 'listsport':
		ListSport()

	elif mode == 'listserials':
		ListSerials	(exlink)				
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		xbmcplugin.endOfDirectory(addon_handle,True)	
		
	elif mode == 'listepisod':
		ListEpisod(exlink)
		xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = '%R, %Y, %P')			
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		xbmcplugin.endOfDirectory(addon_handle,True)	
		
	elif mode == 'listsezon':
		ListSezon(exlink)
		xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = '%R, %Y, %P')			
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		xbmcplugin.endOfDirectory(addon_handle,True)		
		
	elif mode == 'gatunek':
		data = getGatunek(exlink)
		if data:
			label = [x[0].strip() for x in data]
			url = [x[1].strip() for x in data]
			s = xbmcgui.Dialog().select('Wybierz '+exlink,label)
			if s>-1:
				url = build_url({'mode': 'listmovies', 'foldername': '', 'url' : url[s]})

				xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)	
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')				
		xbmcplugin.endOfDirectory(addon_handle,True)
			
	elif mode == '__page__M':
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		url = build_url({'mode': 'listmovies', 'foldername': name, 'url' : exlink, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)	
		
		xbmcplugin.endOfDirectory(addon_handle,True)		
		
	elif mode == 'playvideo':
		PlayVideo(exlink)	
		
	elif mode == 'playTV':
		PlayTV(exlink)
		
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			links,linkser=search(query.replace(' ','+') )
			if links:
			
				itemz=links
				items = len(links)
				my_mode	='playvideo'
				fold=False
				isplay=True
				for f in itemz:			
					add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), fanart=f.get('img'), infoLabels=f, IsPlayable=isplay, isFolder=fold,itemcount=items)
			if linkser:
				itemz=linkser
				items = len(linkser)
				my_mode	='listsezon'
				fold=True	
				isplay=False
					
				for f in itemz:
					add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), fanart=f.get('img'), infoLabels=f, IsPlayable=isplay, isFolder=fold,itemcount=items)		
		xbmcplugin.setContent(addon_handle, 'movies')
		xbmcplugin.endOfDirectory(addon_handle,True)	
	