# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import urlparse
import urllib
import urllib2
#import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import base64
import string
from CommonFunctions import parseDOM
from CommonFunctions import replaceHTMLCodes
import cookielib
import json

import xml.etree.ElementTree as ET
#urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.internetws')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
if not os.path.exists(DATAPATH):
		os.makedirs(DATAPATH)
COOKIEFILE = os.path.join(DATAPATH,'intws.cookie')

sess = requests.Session()
sess.cookies = cookielib.LWPCookieJar(COOKIEFILE)

RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'fanart.jpg'
ikonka = RESOURCES+'icon.png'
inf=RESOURCES+'../icon.png'
sys.path.append( os.path.join( RESOURCES, "lib" ) )
prem=''


exlink = params.get('url', None)
name= params.get('title', None)
page = params.get('page',[1])[0]

url_konto = 'https://internetowa.tv/konto/'

UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0'

def add_items(url,name, mode, iconimage=None, infoLabels=False, IsPlayable=False, isFolder = False, contextmenu=None,fanart=FANART,itemcount=1, page=1):

	u = build_url({'mode': mode, 'url' : url, 'foldername': '', 'page':page,'prem':prem})
	if iconimage==None:
		iconimage='DefaultFolder.png'
	liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
	art=dict(zip(art_keys,[iconimage for x in art_keys]))
	liz.setArt(art)
	if not infoLabels:
		infoLabels={'title': name}
	liz.setInfo(type='video', infoLabels=infoLabels)
	if IsPlayable:
		liz.setProperty('IsPlayable', 'true')
		contextMenuItems = []
		contextMenuItems.append(('Informacja', 'XBMC.Action(Info)'))
		liz.addContextMenuItems(contextMenuItems, replaceItems=False)
	if fanart:
		liz.setProperty('fanart_image',fanart)
	if contextmenu:
		isp=contextmenu
		liz.addContextMenuItems(isp, replaceItems=True)
	ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=isFolder,totalItems=itemcount)

	return ok

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def home():
	loging()
	add_items('tv','[B]Telewizja[/B]','listtv', IsPlayable=False, isFolder=True, fanart=FANART)	
	add_items('','[B]Transmisje sportowe[/B]','listsport', IsPlayable=False, isFolder=True, fanart=FANART)
	add_items('https://internetowa.tv/?c=moviesKodi&page=1','[B]Filmy[/B]','listmovies', IsPlayable=False, isFolder=True, fanart=FANART)	
	add_items('https://internetowa.tv/?c=categoriesKodi','[I]-   kategorie[/I]','gatunek', IsPlayable=False, isFolder=False, fanart=FANART)	
	add_items('https://internetowa.tv/?c=yearsKodi','[I]-   rok[/I]','gatunek', IsPlayable=False, isFolder=False, fanart=FANART)	
	add_items('https://internetowa.tv/?c=versionsKodi','[I]-   wersja językowa[/I]','gatunek', IsPlayable=False, isFolder=False, fanart=FANART)	
	add_items('https://vod.internetowa.tv/seriale-online/','[B]Seriale[/B]','listserials', IsPlayable=False, isFolder=True, fanart=FANART)	
	add_items('https://internetowa.tv/?c=moviesKodi&category=2','[B]Dla dzieci[/B]','listmovies', IsPlayable=False, isFolder=True, fanart=FANART)	
	add_items('','[COLOR blue][B]Szukaj (filmy/seriale)[/B][/COLOR]','search', IsPlayable=False, isFolder=True, fanart=FANART)	
	add_items('','[COLOR khaki][B]Ustawienia[/B][/COLOR]','opcje', IsPlayable=False, isFolder=False, fanart=FANART)

def loging():
	global prem
	
	username = addon.getSetting('userws')
	password = addon.getSetting('passws')	
	lastl = addon.getSetting('lastl')
	lastp = addon.getSetting('lastp')	
	
	if username and password:
		sess.headers = {
			'User-Agent': UA,
			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
			'Referer': 'https://internetowa.tv/logowanie/',
			'Content-Type': 'application/x-www-form-urlencoded',
			'Connection': 'keep-alive',
			'Upgrade-Insecure-Requests': '1',}	
		if lastl==username and password==lastp:
		
			if os.path.isfile(COOKIEFILE):
				sess.cookies.load()	
		else:
			sess.cookies.clear()	
		html = sess.get('https://internetowa.tv/logowanie/', headers=sess.headers,cookies=sess.cookies)#.content
		captcha = re.search('https://internetowa.tv/captcha/',html.content)
		if captcha:	
			import mc
			headers = {
				'Host': 'internetowa.tv',
				'user-agent': UA,
				'accept': 'image/webp,*/*',
				'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
				'referer': 'https://internetowa.tv/logowanie/',
				'dnt': '1',
				'te': 'trailers',
			}
			
			response = sess.get('https://internetowa.tv/captcha/', cookies=html.cookies,headers=headers,verify=False)
			rx=mc.keyboard(response.content)
			data = {'email': username,'password': password,'captcha':rx}
		else:
			data = {'email': username,'password': password}
		response = sess.post('https://internetowa.tv/logowanie/#', headers=sess.headers, data=data,allow_redirects=False)	

		if response.cookies.get('login') is not None:
			sess.cookies.save()	
			addon.setSetting("lastl",username)
			addon.setSetting("lastp",password)
		#if os.path.isfile(COOKIEFILE):
			sess.cookies.load()		
		#sess.cookies.load()	
		html=sess.get('https://internetowa.tv/konto/',cookies=sess.cookies).content
		datkon=re.findall('Konto premium, wa.+?ne do (.+?). Masz',html)

		darm=re.findall('Brak konta premium',html)
		
		if datkon:
			info=datkon[0]
			add_items('','[B][COLOR orange](%s)[/COLOR] - [COLOR green]premium do %s[/COLOR][/B]'%(username,info),'settings', IsPlayable=False, isFolder=False, fanart=FANART)	
					
			prem=True
			add_items('ulubione','[B]Ulubione kanały[/B]','listtv', IsPlayable=False, isFolder=True, fanart=FANART)	
		elif darm:			
			add_items('','[B][COLOR orange](%s)[/COLOR] - [COLOR red]konto darmowe[/COLOR][/B]'%username,'settings', IsPlayable=False, isFolder=False, fanart=FANART)
			prem=False		
			
		else:
			xbmcgui.Dialog().notification('Błąd', 'Niepoprawne dane logowania.', xbmcgui.NOTIFICATION_INFO, 5000)
			add_items('','[B]Zaloguj[/B]','settings', IsPlayable=False, isFolder=False, fanart=FANART)	
			sess.cookies.clear()
			sess.cookies.save()	
			prem=False				
	else:
		xbmcgui.Dialog().notification('Błąd', 'Brak danych logowania.', xbmcgui.NOTIFICATION_INFO, 5000)
		sess.cookies.clear()
		sess.cookies.save()	
		add_items('','[B]Zaloguj[/B]','settings', IsPlayable=False, isFolder=False, fanart='')	
		prem=False	
	
def ListMovies(exlink,page):
	page = int(page) if page else 1	
	links,pagin= getMovies(exlink,page)
	
	if pagin[0]:
		add_items(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__M', iconimage='', isFolder=True, page=pagin[0])
	itemz=links
	items = len(links)
	my_mode	='playvideo'
	fold=False
	isplay=True
	for f in itemz:
	
		add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), fanart=f.get('img'), infoLabels=f, IsPlayable=isplay, isFolder=fold,itemcount=items)
	if pagin[1]:
		add_items(name='[COLOR blue]>> Nastepna strona >>[/COLOR]', url=exlink, mode='__page__M', iconimage='', isFolder=True, page=pagin[1])
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
def getMovies(url,page=1):

	if '&page=' in url:
		url = re.sub(r'&page=\d+', '&page=%d'%page,   url)  
	else:
		url = url + '&page=%d' %page			

	np = page+1
	npurl = re.sub(r'&page=\d+', '&page=%d'%np,   url)
	out=[]
	#serout=[]
	
	prevpage=False
	nextpage=False 
	html=requests.get(npurl).content
	if html.find('<movie>')>0:
		nextpage = page+1
	html=requests.get(url).content
	root = ET.fromstring(html)
	for movies in root:
		resultz={}
		result = dict((k.tag.lower(), k.text) for k in list(movies))
		categs = movies.find("categories")
		genre = [z.text for z in list(categs)]
		if genre == []: genre = ' '
		genre = ', '.join(genre)  
		resultz['img'] = result['image']
		id = result['id']
		resultz['href'] = 'https://vod.internetowa.tv/film-online/%s/aaa'%id
		resultz['title'] = result['title']
		resultz['year'] = result['year']
		resultz['genre'] = genre
		resultz['code'] = result['version']
		resultz['plot'] = result['description']
		out.append(resultz)
	prevpage = page-1 if page>1 else False
	return (out, (prevpage,nextpage))
	
def ListSerials(exlink):
	linksser = getSerials(exlink)
	if linksser:
		itemz=linksser
		items = len(linksser)
		my_mode	='listsezon'
		fold=True	
		isplay=False
	for f in itemz:
		add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), fanart=f.get('img'), infoLabels=f, IsPlayable=isplay, isFolder=fold,itemcount=items)
	
def getSerials(url):
	out=[]
	url='https://internetowa.tv/?c=seriesApi&limit=1000'
	html = sess.get(url).content
	root = ET.fromstring(html)
	for series in root:
		result = dict((k.tag.lower(), k.text) for k in series.getchildren())
		result['img'] = result['image'].replace('.jpg','-series.jpg')
		result['href'] = 'https://vod.internetowa.tv/serial-online/%s/aaa'%result['id']
		result['title'] = result['title']
		result['plot'] = result['description']
		out.append(result)
	return out

def getImag(url):
	html = sess.get(url).text
	imagsub=parseDOM(html,'div', attrs={'id': "single-poster"})[0]
	imag = parseDOM(imagsub, 'img', ret='src')[0]
	return imag
	
def ListSezon(exlink):
	links=getSezons(exlink)	
	items = len(links)
	my_mode	='listepisod'
	fold=True	
	isplay=False
	for f in links:
		aa=f.get('img').split('|')
		add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=aa[0], fanart=aa[1], infoLabels=f, IsPlayable=isplay, isFolder=fold,itemcount=items)
	
def getSezons(exlink):
	out=[]
	html = sess.get(exlink).text
	
	plot=parseDOM(html,'p', attrs={'class': "description"})[0] #<p class="description">
	imagsub=parseDOM(html,'div', attrs={'id': "single-poster"})[0]# <div id="single-poster" class="col-sm-3">
	imag = parseDOM(imagsub, 'img', ret='src')[0]
	fanartsub=parseDOM(html,'div', attrs={'style': "background-size.+?"},ret='style')[0]#<div id="item-headline
	fimage=re.findall('url\((.+?)\)',fanartsub)[0]
	result=parseDOM(html,'ul', attrs={'id': "episode-list"})[0]  #<table class="streamtable">
	subset=parseDOM(result,'span')
	imag=imag+'|'+fimage
	for subs in subset:
		out.append({'title':subs,'href':exlink+'|'+subs,'img':imag,'plot':PLchar(plot)})
	return out	

def ListEpisod(exlink):
	links=getEpisodes(exlink)	
	if links:
		items = len(links)
		my_mode	='playvideo'
		fold=False	
		isplay=True
		for f in links:	
			aa=f.get('img').split('|')
			add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=aa[0], fanart=aa[1], infoLabels=f, IsPlayable=isplay, isFolder=fold,itemcount=items)
	
def getEpisodes(exlink):
	out=[]
	urlsez=exlink.split('|')
	html = sess.get(urlsez[0]).text	
	plot=parseDOM(html,'p', attrs={'class': "description"})[0] #<p class="description">
	imagsub=parseDOM(html,'div', attrs={'id': "single-poster"})[0]# <div id="single-poster" class="col-sm-3">
	imag = parseDOM(imagsub, 'img', ret='src')[0]
	fanartsub=parseDOM(html,'div', attrs={'style': "background-size.+?"},ret='style')[0]#<div id="item-headline
	fimage=re.findall('url\((.+?)\)',fanartsub)[0]
	imag=imag+'|'+fimage	
	regex='<span>'+urlsez[1]+'<\/span>.+?<\/ul>'
	result=re.findall(regex,html,re.DOTALL)[0]
	subset=parseDOM(result,'li') 
	for subs in subset:
		href = parseDOM(subs, 'a', ret='href')[0]
		title = parseDOM(subs, 'a')[0]	
		out.append({'title':PLchar(title),'href':href,'img':imag,'plot':PLchar(plot)})
	return out	
	
	
def dodUlub(url):	
	sess.cookies.load()	
	html = sess.get(url).text
	id=re.findall("""favButton" onclick="addFav\('(.+?)'\)""",html)
	if id:
		id = id[0]
		addurl='https://internetowa.tv/addFav/%s'%id
		html = sess.get(addurl).text	
		xbmcgui.Dialog().notification('[B]Dodano...[/B]', '', xbmcgui.NOTIFICATION_INFO, 5000)
	else:
		xbmcgui.Dialog().notification('[B]Już dodane...[/B]', '', xbmcgui.NOTIFICATION_INFO, 5000)
	
def usunUlub(url):	
	
	sess.cookies.load()	
	html = sess.get(url).text
	id=re.findall("""onclick="removeFav\('(.+?)'\)""",html)#[0]
	if id:
		id=id[0]
		delurl='https://internetowa.tv/removeFav/%s'%id 
		html = sess.get(delurl).text
		nk = build_url({'mode': 'listtv', 'url' : 'ulubione', 'foldername': '', 'page':1,'prem':True})
		xbmc.executebuiltin('XBMC.Container.Update(%s)'% nk)	
		xbmcplugin.endOfDirectory(addon_handle,True)	
		
		xbmcgui.Dialog().notification('[B]Usunięto...[/B]', ' ', xbmcgui.NOTIFICATION_WARNING, 5000)
	else:
		pass


	
def ListTv(exlink):
	global prem	
	premk = params.get('prem', None)
	if 'True' in premk:
		items=getTVprem(exlink)
		if len(items)>0:
			isFolder = False
			IsPlayable = True
			my_mode = 'playTV'	
			for f in items:	
				contextmenu = []
				if 'ulubione' in exlink:
					contextmenu.append(('Usuń z ulubionych', 'XBMC.Container.Refresh(%s)'%  build_url({'mode': 'usunulub', 'url' : f.get('href')})),)  
				else:
					contextmenu.append(('Dodaj do ulubionych', 'XBMC.Container.Update(%s)'%  build_url({'mode': 'dodulub', 'url' : f.get('href')})),) 
	
				add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,itemcount=len(items),contextmenu=contextmenu)
			xbmcplugin.endOfDirectory(addon_handle,True)
		else:
			ab = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak kanałów do wyświetlenia')
	else:
		ab = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Tylko konta premium')
	
	
def getEpg(subset,dane):
	plot=''
	for subs in subset:
		if dane in subs:		
			ass=re.findall('<span class="bigTitle">(.+?)<\/span>.+?<span class="bigTime">(.+?)</span>',subs,re.DOTALL)
			for tyt,czas in ass:
				plot+='[B][COLOR khaki]'+czas+'[/B][/COLOR][COLOR blue] '+tyt+'[/COLOR][CR]'
		else:
			pass
	return plot
	
def PlayTV(exlink):
	head = {
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Connection': 'keep-alive',
		'Referer': 'https://internetowa.tv/',
		'Upgrade-Insecure-Requests': '1',
		'TE': 'Trailers',
	}
	if 'm3u8' in exlink:
		stream_url=exlink
		#head5 = {}
		hea= '&'.join(['%s=%s' % (name, value) for (name, value) in head.items()])
	else:
		try:
			
			if os.path.isfile(COOKIEFILE):
				sess.cookies.load()	
			html=sess.get(exlink,headers=head,verify=False).content
			hlsToken = re.findall("""hlsToken\s*=\s*['"](.+?)['"]""",html)
			chromecastUrl = re.findall("""chromecastUrl\s*=\s*['"](.+?)['"]""",html)
			if chromecastUrl and hlsToken:
				stream_url = chromecastUrl[0]+urllib.quote(hlsToken[0])#+'|Referer='+urllib.quote(exlink)
				head.update({'Referer': exlink})
				hea= '&'.join(['%s=%s' % (name, value) for (name, value) in head.items()])
			else:
				trick=re.findall('vid1.src([^<]+)<',html)
				if trick:
					stream_url=re.findall("""src: ['"]([^'"]+)['"]""",trick[0].replace("\'",'"'))[0]
					band = sess.get(stream_url,headers=head,verify=False).content
					stream_url= re.findall("(http.+?)\\r", band.decode('utf-8'), re.MULTILINE)[0]
					head.update({'Referer': exlink})
					hea= '&'.join(['%s=%s' % (name, value) for (name, value) in head.items()])
					#stream_url+='|Referer='+exlink	 
				else:
					iframe = parseDOM(html, 'iframe', ret='src')[0]
					head.update({'Referer': exlink})
					html=(sess.get(iframe,headers=head,verify=False).content).replace("\'",'"')
					head.update({'Referer': iframe})
					hea= '&'.join(['%s=%s' % (name, value) for (name, value) in head.items()])
					if 'js/hls.js' in html:
						stream_u=re.findall("""hls.loadSource\(['"](.+?)['"]\)""",html)[0]
					else:
						stream_u=re.findall('src="(.+?m3u8.+?)"',html)[0]
					stream_url=stream_u #+'|Referer='+iframe	 
		except:
			ab = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Tylko konta premium')	
			return
	play_item = xbmcgui.ListItem(path=stream_url)
			#listitem = xbmcgui.ListItem(path=stream_url)
	play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
	play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
	play_item.setMimeType('application/vnd.apple.mpegurl')
	play_item.setProperty('inputstream.adaptive.stream_headers', hea)
	play_item.setContentLookup(False)	
	xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def PlayVideo(exlink):

	streams = getVideos(exlink);
	stream_url = ''
	if streams:
		if len(streams) > 1:
			t = [ x.get('title') for x in streams]
			u = [ x.get('url') for x in streams]
			h = [ x.get('host') for x in streams]
			al = "   [ HOST ] "
			select = xbmcgui.Dialog().select(al, t)
		else:
			select = -1
			u = [ x.get('url') for x in streams]
			des= [ x.get('descr') for x in streams]
	
		stream_url = u[select];
		descr= des[select];

	if stream_url:	
		play_item = xbmcgui.ListItem(path=stream_url)
		if descr:
			infoLabels={'plot':descr}
			play_item.setInfo(type='video', infoLabels=infoLabels)
		
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
	else:
		ab = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Tylko konta premium')	
		play_item = xbmcgui.ListItem(path='')
		xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)	
		
def getVideos(url):
	out=[]
	html=sess.get(url).content
	descr=parseDOM(html,'p', attrs={'class': "description"})#
	if descr:
		descr=descr[0].strip()
	try:
		results=parseDOM(html,'tr')#[0]
		for result in results:
			href = parseDOM(result, 'a', ret='href')#[0]
			if href:
				href=href[0]
				host = parseDOM(result, 'img', ret='alt')[0]		
				verqual = parseDOM(result, 'td')#[0]
				title='[%s] [%s] [%s]'%(host,verqual[0],verqual[1])
				
				if 'internetowa.tv' in href:
					
					if os.path.isfile(COOKIEFILE):
						sess.cookies.load()
					html=sess.get(href).content
					try:
						nxthref=re.findall('source: "(.+?)"',html)[0]
					except:
						nxthref=re.findall('source src="([^"]+)"',html)[0]
					href=nxthref+'|Referer=' +href
				out.append({'title':title,'url':href,'host':host,'descr':descr})
			else:
				pass
	except:
		pass
	return out
		
def ListSport():
	links=getSport()	
	
	if links:
		items=links
		isFolder = False
		IsPlayable = True
		my_mode = 'playTV'			
		for f in items:	
			add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,itemcount=len(items))
		xbmcplugin.endOfDirectory(addon_handle,True)		
	else:
		s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Tylko konta premium :-(')	
		

def getSport():
	out=[]
	html = sess.get('https://internetowa.tv/transmisje/').text
	
	result=parseDOM(html,'table', attrs={'class': "streamtable"})[0]  
	subset=parseDOM(result,'tr')
	plot=''
	for subs in subset:
		imag = parseDOM(subs, 'img', ret='src')[0]	
		dysc= parseDOM(subs, 'img', ret='alt')[0]
		href = parseDOM(subs, 'a', ret='href')[0]	
		title = parseDOM(subs, 'a')[0]	
		czas = parseDOM(subs, 'td')	
		czas=czas[2]+' - '+czas[3]
		plot='[B][COLOR orange]'+PLchar(dysc)+'[/B][/COLOR][CR][B][COLOR khaki]'+PLchar(czas)+'[/B][/COLOR][COLOR blue] '+PLchar(title)+'[/COLOR][CR]'
		out.append({'title':'[B][COLOR yellowgreen]'+PLchar(czas)+' - [/B][/COLOR] '+PLchar(title),'href':href,'img':imag,'plot':plot})
	return out
	
	
def getTVprem(exlink):
	out=[]
	sess.cookies.load()	
	html = sess.get('https://internetowa.tv/',cookies=sess.cookies).text		
	result=parseDOM(html,'div', attrs={'id': "allhome"})[0] 
	if 'ulubione' in exlink:
		result=parseDOM(html,'div', attrs={'id': "favhome"})[0] 

	items=parseDOM(result,'div', attrs={'class': "channelb"})#[0] 
	html = sess.get('https://internetowa.tv/program-tv/').content
	result=parseDOM(html,'div', attrs={'id': "epgBig"})[0] 
	subset=parseDOM(result,'tr')		
	for item in items:

		href = parseDOM(item, 'a', ret='href')[0]
		imag = parseDOM(item, 'img', ret='src')[0]
		title = parseDOM(item, 'a', ret='title')[0]		
		plot=getEpg(subset,imag)	
		one={
			'href': href,
			'img': imag,
			'title': PLchar(title),
			'plot':PLchar(plot),}
		out.append(one)
	return out

def getGatunek(exlink):
	out=[]
	if exlink:
		html = sess.get(exlink,verify=False).content
		root = ET.fromstring(html)
		if 'years' in exlink:
			for k in list(root):
				out.append((k.text,'https://internetowa.tv/?c=moviesKodi&page=1&year=%s'%k.text))
				msg = 'rok produkcji'
		elif 'https://internetowa.tv/?c=categoriesKodi' in exlink:
			for movies in root:
				
				result = dict((k.tag.lower(), k.text) for k in list(movies))
				id=result['id']
				nam=result['name']
				out.append((nam,'https://internetowa.tv/?c=moviesKodi&page=1&category=%s'%id))
				msg = 'kategorię'
		elif 'https://internetowa.tv/?c=versionsKodi' in exlink:
			resultz={}
			for movies in root:
				result = dict((k.tag.lower(), k.text) for k in list(movies))
				id=result['id']
				nam=result['name']
				out.append((nam,'https://internetowa.tv/?c=moviesKodi&page=1&version=%s'%id)) #https://internetowa.tv/?c=moviesKodi&page=1&year=2019
				msg = 'wersję'
	return out,msg

def search(q='batman'):
	out=[]
	serout=[]
	data = {'phrase': q}
	html = sess.post('https://vod.internetowa.tv/szukaj',data=data).content
	links = parseDOM(html, 'div', attrs={'class': "col-xs-3 col-lg-2"})
	for link in links:
		link=replaceHTMLCodes(link)
		imag= parseDOM(link, 'img', ret='src')[0]
		title = parseDOM(link, 'div', attrs={'class': "title"})[0]
		year = parseDOM(link, 'div', attrs={'class': "year"})#[0]
		if year:
			try:
				year=int(year[0])
			except:
				year=''
		else:
			year=''
		href = parseDOM(link, 'a', ret='href')[0]
		if 'serial-online' in href:
			serout.append({'title':PLchar(title),'href':href,'img':imag})	
		else:
			out.append({'title':PLchar(title),'href':href,'img':imag,'year':year})
	return out,serout	

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")		
	char = char.replace('Napisy PL',"[COLOR lightblue](napisy pl)[/COLOR]")
	char = char.replace('Lektor PL',"[COLOR lightblue](lektor pl)[/COLOR]")
	char = char.replace('Dubbing PL',"[COLOR lightblue](dubbing pl)[/COLOR]")	
	return char	
def M3uDownload():

	mesag = ''
	if mesag:
		xbmcgui.Dialog().notification('[COLOR red]ERROR[/COLOR]', mesag, xbmcgui.NOTIFICATION_ERROR, 1000)
	else:

		html = sess.get(url_konto,verify=False).content
		try:
			lista = re.findall('href="([^"]+)">Lista m3u',html)[0]
			addon.setSetting('npliku',lista)
			
			npliku2 = addon.getSetting('npliku')
			xbmcgui.Dialog().notification('Lista utworzona w IPTV CLIENT', lista, xbmcgui.NOTIFICATION_INFO, 10000)
		except:
			xbmcgui.Dialog().notification('Problem z utworzeniem listy', lista, xbmcgui.NOTIFICATION_ERROR, 10000)

			
			
def get_addon(wtyk="pvr.iptvsimple"):
    """
    Check if inputstream is installed, attempt to install if not.
    Enable inpustream addon.
    """
    addon = None

    try:
        enabled_json = ('{"jsonrpc":"2.0","id":1,"method":'
                        '"Addons.GetAddonDetails","params":'
                        '{"addonid":"%s", '
                        '"properties": ["enabled"]}}'%wtyk)
        result = json.loads(xbmc.executeJSONRPC(enabled_json))
    except RuntimeError:
        return False

    if 'error' in result:  # not installed
        try:  # see if there's an installed repo that has it
            xbmc.executebuiltin('InstallAddon(%s)'%wtyk, True)
            addon = xbmcaddon.Addon('%s'%wtyk)
            return addon
        except RuntimeError:
            xbmcgui.Dialog().ok('%s not installed'%wtyk,
                                '%s not installed. This '
                                'addon now comes supplied with newer builds '
                                'of Kodi 18 for Windows/Mac/LibreELEC/OSMC, '%wtyk)
        return False

    else:  # installed but not enabled. let's enable it.
        if result['result']['addon'].get('enabled') is False:
            json_string = ('{"jsonrpc":"2.0","id":1,"method":'
                           '"Addons.SetAddonEnabled","params":'
                           '{"addonid":"%s",'
                           '"enabled":true}}'%wtyk)
            try:
                xbmc.executeJSONRPC(json_string)
            except RuntimeError:
                xbmcgui.Dialog().ok('Unable to enable %s'%wtyk,
                                    'Unable to enable %s, '
                                    'please try to enable manually '
                                    'and try again'%wtyk)
                return False
        addon = xbmcaddon.Addon('%s'%wtyk)

    return addon		
			
			
			
			
def addon_enable_and_set(addonid='pvr.iptvsimple',settings={'m3uUrl': 'dupa'}):

	get_addon(wtyk="pvr.iptvsimple")
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}'%addonid )
	xbmc.sleep(500)
	msg=''
	try:
		pvr_addon = xbmcaddon.Addon(addonid)
		pvr_addon.setSetting('m3uUrl',str(settings.get('m3uUrl','')))
		msg='[COLOR green][B]OK[/COLOR] Uruchom ponownie Kodi jeśli lista kanałów PVR się nie uaktualniła[/B]'
	except:
		msg='[COLOR red]ERROR[/COLOR] Nieudana aktualizacja ustawie\xc5\x84 PVR'
	pvr_addon = xbmcaddon.Addon(addonid)
	dataPath = xbmc.translatePath(pvr_addon.getAddonInfo('profile')).decode('utf-8')
	ustawienia="""
<settings>
    <setting id="epgCache" value="true" />
    <setting id="epgPath" value="" />
    <setting id="epgPathType" value="{epgPathType}" />
    <setting id="epgTSOverride" value="true" />
    <setting id="epgTimeShift" value="{epgTimeShift}" />
    <setting id="epgUrl" value="{epgUrl}" />
    <setting id="logoBaseUrl" value="" />
    <setting id="logoFromEpg" value="{logoFromEpg}" />
    <setting id="logoPath" value="" />
    <setting id="logoPathType" value="1" />
    <setting id="m3uCache" value="true" />
    <setting id="m3uPath" value="" />
    <setting id="m3uPathType" value="{m3uPathType}" />
    <setting id="m3uUrl" value="{m3uUrl}" />
    <setting id="sep1" value="" />
    <setting id="sep2" value="" />
    <setting id="sep3" value="" />
    <setting id="startNum" value="1" />
</settings>
	"""
	ustawienia = ustawienia.format(**settings)

	try:
		if not os.path.exists(dataPath):
			os.makedirs(dataPath)
	except:
		pass
	with open(os.path.join(dataPath,'settings.xml'),'w') as setxml:
		print('addon_enable_and_set','writing settings.xml')
		setxml.write(ustawienia)
	return msg			
def update_iptvx(epgTimeShift,epgUrl):
    m3uPath = addon.getSetting('npliku')
    if m3uPath:
        xbmc.executebuiltin('StopPVRManager')
        xbmc.executebuiltin('PVR.StopManager')
        new_settings={'m3uUrl': m3uPath,'m3uPathType':'1','epgUrl':epgUrl,'epgTimeShift':epgTimeShift,'epgPathType':'1','logoFromEpg':'2'}
        msg=addon_enable_and_set(addonid='pvr.iptvsimple',settings=new_settings)
        xbmcgui.Dialog().notification('', msg, ikonka, 10000)
        version = int(xbmc.getInfoLabel('System.BuildVersion' )[0:2])
        print 'Kodi version: %d, checking if PVR is active' % version
        if version<17:
            try:
                json_response = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue","params":{"setting":"pvrmanager.enabled"},"id":9}')
                decoded_data = json.loads(json_response)
                pvrmanager = decoded_data.get('result',{}).get('value','')
                if not pvrmanager:
                    xbmcgui.Dialog().ok('[COLOR red]Telewizja nie jest aktywna![/COLOR] ','Telewizja PVR nie jest aktywaowana', 'Aktywuj i uruchom ponownie jak Telewizja si\xc4\x99 nie pojawi')
                    xbmc.executebuiltin('ActivateWindow(10021)')
            except:
                pass
        else:
            pass
    else:
        xbmcgui.Dialog().notification('ERROR', '[COLOR red[Lista m3u jeszcze nie istnieje![/COLOR]', xbmcgui.NOTIFICATION_ERROR, 3000)			
			
def UPDATE_IPTV():

   # npliku
    path =  addon.getSetting('path').decode('utf-8')
    epgTimeShift = addon.getSetting('epgTimeShift')
    epgUrl = addon.getSetting('epgUrl')
    update_iptvx(epgTimeShift,epgUrl)

if __name__ == '__main__':
	mode = params.get('mode', None)
	
	if not mode:
		home()		
		xbmcplugin.setContent(int(sys.argv[1]), 'videos')
		xbmcplugin.endOfDirectory(addon_handle,True)	
		
	elif mode == 'settings':
		addon.openSettings()
		xbmc.executebuiltin('XBMC.Container.Refresh()')
		
	elif mode == 'listtv':
		ListTv(exlink)
		
	elif mode == 'listmovies':
		ListMovies(exlink,page)		
		xbmcplugin.setContent(int(sys.argv[1]), 'videos')
		xbmcplugin.endOfDirectory(addon_handle,True)	
		
	elif mode == 'listsport':
		ListSport()

	elif mode == 'listserials':
		ListSerials	(exlink)				
		xbmcplugin.setContent(int(sys.argv[1]), 'videos')
		xbmcplugin.endOfDirectory(addon_handle,True)	
		
	elif mode == 'listepisod':
		ListEpisod(exlink)
		xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = '%R, %Y, %P')			
		xbmcplugin.setContent(int(sys.argv[1]), 'videos')
		xbmcplugin.endOfDirectory(addon_handle,True)	
		
	elif mode == 'listsezon':
		ListSezon(exlink)
		xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = '%R, %Y, %P')			
		xbmcplugin.setContent(int(sys.argv[1]), 'videos')
		xbmcplugin.endOfDirectory(addon_handle,True)		
		
	elif mode == 'gatunek':

		data,msg = getGatunek(exlink)

		if data:
			label = [x[0].strip() for x in data]
			url = [x[1].strip() for x in data]
			sel = xbmcgui.Dialog().select('Wybierz '+msg,label)
			if sel>-1:

				url = build_url({'mode': 'listmovies', 'foldername': '', 'url' : url[sel]})
				xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)	
			else:
				pass

			
	elif mode == '__page__M':
		xbmcplugin.setContent(int(sys.argv[1]), 'videos')
		url = build_url({'mode': 'listmovies', 'foldername': name, 'url' : exlink, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)	
		
		xbmcplugin.endOfDirectory(addon_handle,True)		
		
	elif mode == 'playvideo':
		PlayVideo(exlink)	
		
	elif mode == 'playTV':
		PlayTV(exlink)
		
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			links,linkser=search(query)
			if links or linkser:
				if links:
				
					itemz=links
					items = len(links)
					my_mode	='playvideo'
					fold=False
					isplay=True
					for f in itemz:			
						add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), fanart=f.get('img'), infoLabels=f, IsPlayable=isplay, isFolder=fold,itemcount=items)
				if linkser:
					itemz=linkser
					items = len(linkser)
					my_mode	='listsezon'
					fold=True	
					isplay=False
						
					for f in itemz:
						add_items(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), fanart=f.get('img'), infoLabels=f, IsPlayable=isplay, isFolder=fold,itemcount=items)		
				xbmcplugin.setContent(addon_handle, 'videos')
				xbmcplugin.endOfDirectory(addon_handle,True)	
			else:
				xbmcgui.Dialog().notification('Informacja', 'Brak materiałów do wyświetlenia', inf, 5000)
		
	elif mode=='dodulub':
		dodUlub(exlink)	

	elif mode=='usunulub':
		usunUlub(exlink)	
		
	elif mode=='opcje':
		addon.openSettings()

	elif mode=='PVR_SETTINGS':
		try: xbmcaddon.Addon('pvr.iptvsimple').openSettings()
		except: pass
		
	elif mode=='UPDATE_IPTV':
		UPDATE_IPTV()
		
	elif mode=='m3uDownload':
		loging()
		if prem:
			M3uDownload()
		else:
			xbmcgui.Dialog().notification('Uwaga', 'Działa tylko dla PREMIUM', xbmcgui.NOTIFICATION_ERROR, 10000)
	
	else:
		xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
		

