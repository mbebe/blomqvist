# -*- coding: UTF-8 -*-
import sys,re,os
import urlparse
from urlparse import parse_qsl
import base64
import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import resolveurl as urlresolver
import cookielib

try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
  
cache = StorageServer.StorageServer("virpec")

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.virpecom')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=PATH+'fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )
import cfdeco6
exlink = params.get('url', None)
name= params.get('title', None)
page = params.get('page',[1])[0]
rys = params.get('img', None)
main_url = 'https://virpe.com/'

UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0'
TIMEOUT=15

headers = {'User-Agent': UA,}
COOKIEFILE = os.path.join(RESOURCES,'virpe.cookie')
sess = cfdeco6.create_scraper()

sess.cookies = cookielib.LWPCookieJar(COOKIEFILE)

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=0,contextmenu=None):
	list_item = xbmcgui.ListItem(label=name)
	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')
		
	if not infoLabels:
		infoLabels={'title': name}
	if contextmenu:
		isp=contextmenu
		list_item.addContextMenuItems(isp, replaceItems=True)
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page,'img':image}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	
def cfandsave():
	sess.cookies.clear()
	url_test = 'https://virpe.com'
	content=sess.get(url_test,verify=False)#.content
	sess.cookies.save()
	return
def home():
	cfandsave()
	add_item('https://virpe.com', 'Strona głowna', '', True, "listmain")
	add_item('https://virpe.com/filmy-polskie-online-za-darmo/polskie-filmy/', 'Filmy polskie', RESOURCES+'Filmy.png', True, "listmovies")
	add_item('https://virpe.com/online-filmy-zagraniczne-za-darmo/filmy-online-za-darmo/', 'Filmy zagraniczne', RESOURCES+'Filmy.png', True, "listmovies")
	add_item('4', 'Seriale TVP', RESOURCES+'Seriale.png', True, "listserials")	
	add_item('5', 'Seriale Polsat', RESOURCES+'Seriale.png', True, "listserials")	
	add_item('6', 'Seriale TVN', RESOURCES+'Seriale.png', True, "listserials")	
	add_item('7', 'Programy rozrywkowe', RESOURCES+'Seriale.png', True, "listserials")	
	add_item('9', 'Programy i audycje', RESOURCES+'Seriale.png', True, "listserials")	
	add_item('10', 'Archiwa Telewizji', '', True, "listserials")	
	add_item('8', 'Seriale zagraniczne', RESOURCES+'Seriale.png', True, "listserials")		
	add_item('', '[COLOR lightblue]Szukaj[/COLOR]', '', True, "Szukaj")		
	xbmcplugin.endOfDirectory(addon_handle)

def ListMain(exlink):
	links= getMain(exlink)
	itemz=links
	items = len(links)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listepisodes', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)

def getMain(url):		
	html=getUrlReq(url)
	out=[]
	sc=''.join(['%s=%s;'%(c.name, c.value) for c in sess.cookies])
	try:
		result=parseDOM(html,'div', attrs={'class': "cuatro"})[0] #	<div class="content-block clear">
		links=parseDOM(result,'div', attrs={'class': "col-md-6"})
		for link in links:
			href = parseDOM(link, 'a', ret='href')[0] 
			href=main_url+href
			imag= parseDOM(link, 'img', ret='src')[0] 
			imag = 'https:' + imag if imag.startswith('//') else imag
			title=parseDOM(link,'h2')[0]
			out.append({ 'href'  : href,'img': '','title' : PLchar(title),'mediatype': 'movie','img':imag+'|User-Agent='+urllib.quote(UA)+'&Cookie='+urllib.quote(sc)})					
	except:
		pass
	return out	
	
def ListMovies(exlink,page):
	page = int(page) if page else 0	
	links, pagin = getMovies(exlink,page)
	if pagin[0]:
		add_item(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[0])	
	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
	if pagin[1]:
		add_item(name='[COLOR blue]>> Nastepna strona >>>[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[1])
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)

def getMovies(url,page=0):
	url = url + '?page=%d' %page #
	html=getUrlReq(url)
	out=[]
	serout=[]
	try:
		prevpage=False #gr=False
		nextpage=False  # pr=False	
		pages = parseDOM(html, 'div', attrs={'class': "sectiontablefooter"})[0]
		if pages.find('title="Dalej">Dalej')>0:
			nextpage = str(page+1)
		else:
			nextpage = ''
		result=parseDOM(html,'ul', attrs={'class': "table"})[0]
		links = parseDOM(result,'li')
		imag=''
		for link in links:			
			href = parseDOM(link, 'a', ret='href')[0] #[1]
			title = parseDOM(link, 'a', ret='title')[0] #[1]
			out.append({'title':PLchar(title),'href':href,'img':imag})
	except:
		pass
	prevpage = str(page-1) if page>0 else ''
	return (out,(prevpage,nextpage))	
	
def ListSerials(exlink):
	serials = getSerials(exlink)
	itemz=serials
	items = len(serials)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listepisodes', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)			
	xbmcplugin.setContent(addon_handle, 'tvshows')	
	xbmcplugin.endOfDirectory(addon_handle)
	
def ListEpisodes(exlink,rys):	
	episodes = getEpisodes(exlink)	
	itemz=episodes
	items = len(episodes)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=rys, folder=False, infoLabels=f, itemcount=items)			
	xbmcplugin.setContent(addon_handle, 'episodes')	
	xbmcplugin.endOfDirectory(addon_handle)
	
def getUrlReq(url):
	if os.path.isfile(COOKIEFILE):
		sess.cookies.load()
	sess.headers.update({'User-Agent': UA})
	aa=sess.cookies
	#my_cookies = requests.utils.dict_from_cookiejar(aa)
	#found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]
	#kukz= ';'.join(found)	
	content=sess.get(url,cookies=aa).content
	return content

def getEpisodes(url):	
	html=getUrlReq(url)
	out=[]
	result=parseDOM(html,'ul', attrs={'class': "table"})[0]
	links = parseDOM(result,'li')	  
	imag=''
	for link in links:
		href = parseDOM(link, 'a', ret='href')[0]   
		title = parseDOM(link, 'a', ret='title')[0] 
		out.append({ 'href'  : href,'title' : title,'img': imag})					
	return out
	
def getSerials(co):	
	html=getUrlReq(main_url)
	out=[]
	co=int(co)
	result=parseDOM(html,'div', attrs={'class': "moduletable"})[co]
	imag=''
	hreftitle=re.findall('href="(.+?)"\s+title="(.+?)"',result)
	for href,title in hreftitle:		
		out.append({'title':title,'href':href,'img':imag})	
	return out
	
def getVevio(url):
	try:
		r=requests.get(url,headers=headers,verify=False)
		html=r.content
		id=re.findall('{"video_code":"(.+?)"}',html)[0]
		headers2 = {
		'User-Agent': UA,
		'Accept': 'application/json',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': url,
		'Content-Type': 'application/json;charset=utf-8',
		'referrer': url,
		'Connection': 'keep-alive',
		'TE': 'Trailers',}
		data = '{}'
		posturl='https://vev.io/api/serve/video/%s'%id
		response = requests.post(posturl, headers=headers2, data=data)
		html=response.text
		links=getVevioVids(html)
		if len(links)>1:
			linksAllb = [x.get('host') for x in links]
			s = xbmcgui.Dialog().select('Wybierz jakość',linksAllb)	
		else:
			s=0
		hrefs=links[s].get('href') if s>-1 else ''
		host=links[s].get('host') if s>-1 else ''
	except:
		hrefs=''
	return hrefs
		
def getLinks(exlink):
	stream=''
	stream_url=''
	links=getVideosOk(exlink)
	if links:
		print''
		if len(links)>1:
			linksAllb = [x.get('host') for x in links]
			s = xbmcgui.Dialog().select('Linki',linksAllb)	
		else:
			s=0
		hrefs=links[s].get('href') if s>-1 else ''
		host=links[s].get('host') if s>-1 else ''
		if not hrefs:
			return
		if 'vev.io' in hrefs:	
			stream_url=getVevio(hrefs)
		else:
			stream=hrefs	
		if stream:
			try:
				stream_url = urlresolver.resolve(stream)
			except Exception,e:
				stream_url=''
				#s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link bedzie działał?','ERROR: %s'%str(e))	
		if stream_url:	
			play_item = xbmcgui.ListItem(path=stream_url)
			xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
		else:
			#play_item = xbmcgui.ListItem(path='')
			#xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)	
			xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link bedzie działał?')
			#quit()
	else:
		s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak linków')
	return
def getVevioVids(content):
	out=[]
	qualhref=re.findall('"(\d+p)":"(.+?)"',content)
	for qual,href in qualhref:
		try:
			film = {'href' : href,'host' : qual,}
			out.append(film)
		except:
			pass
	return out	
	
def getVideosOk(url):
	html=getUrlReq(url)	
	result=parseDOM(html,'div', attrs={'id': "elxisarticle.+?"})[0]
	players=parseDOM(html,'p', attrs={'class': "server"})
	out=[]
	for player in players:
		try:
			url = parseDOM(player, 'a', ret='href')[0]
			host = (urlparse.urlsplit(url).netloc).upper()
			film = {'href' : url,'host' : host,}
			out.append(film)
		except:
			pass
	return out
	
def getHistory():
    return cache.get('history').split(';')

def setHistory(entry):
    history = getHistory()
    if history == ['']:
        history = []
    history.insert(0, entry)
    cache.set('history',';'.join(history[:50]))

def remCache(entry):
    history = getHistory()
    if history:
        cache.set('history',';'.join(history[:50]))
    else:
        delHistory()

def delHistory():
    cache.delete('history')
	
def ListSearch(exlink,page):
	
	page = int(page) if page else 0	
	links,serials, pagin = search(exlink,page)
	if pagin[0]:
		add_item(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__S', image='', folder=True, page=pagin[0])	
	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
	itemz=serials
	items = len(serials)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listepisodes', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)		
	if pagin[1]:
		add_item(name='[COLOR blue]>> Nastepna strona >>>[/COLOR]', url=exlink, mode='__page__S', image='', folder=True, page=pagin[1])
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)

def search(q,page):
	url='https://virpe.com/search.html?searchword=%s&ordering=category&page=%d'%(q,page)
	html=getUrlReq(url)	
	out=[]
	serout=[]
	prevpage=False #gr=False
	nextpage=False  # pr=False	
	if html.find('title="Dalej">Dalej')>0:
		nextpage = str(page+1) #else ''
	else:
		nextpage = ''
	results = parseDOM(html, 'ul', attrs={'class': "table"})[0]
	links = parseDOM(results, 'li')
	imag=''
	for link in links:	
	
		rodz = parseDOM(link, 'span', attrs={'class': "small"})[0]

		if 'Newsflashes' in rodz:
			continue
		href = parseDOM(link, 'a', ret='href')[0] #[1]		
		title = parseDOM(link, 'a', ret='title')[0]
		if '(Category List)' in rodz:
			title=title+' [COLOR khaki] (serial) [/COLOR]'
		if href and title:
			film = {
				'href'   : href,
				'title'  : PLchar(title),
				'img'    : '',}
			if '(Category List)' in rodz:
				serout.append(film)	
			else:
				out.append(film)
	prevpage = str(page-1) if page>0 else ''
	return (out,serout,(prevpage,nextpage))					

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&nbsp;',".").replace('&amp;','&')
	return char	

if __name__ == '__main__':
	mode = params.get('mode', None)
	
	if not mode:
		home()
	elif mode == 'listmovies':
		ListMovies(exlink,page)
	elif mode == 'listmain':
		ListMain(exlink)	
	elif mode == 'getLinks':
		getLinks(exlink)	
	elif mode == 'listserials':
		ListSerials(exlink)
	elif mode == 'listepisodes':
		ListEpisodes(exlink,rys)
	elif mode == 'listsearch':
		ListSearch(exlink,page)
	elif mode == '__page__M':
		url = build_url({'mode': 'listmovies', 'foldername': name, 'url' : exlink, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
	elif mode == '__page__S':
		url = build_url({'mode': 'listsearch', 'foldername': name, 'url' : exlink, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			links,serials=search(query.replace(' ','+') )
			itemz=links
			items = len(links)
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
			itemz=serials
			items = len(serials)
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode='listepisodes', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)				
		xbmcplugin.setContent(addon_handle, 'movies')
		xbmcplugin.endOfDirectory(addon_handle)
		
	elif mode =='Szukaj':
		add_item('', '[COLOR green]Nowe Szukanie[/COLOR]', '', True, "SzukajNowe")	
		history = getHistory()
		if not history == ['']:
			for entry in history:
				contextmenu = []
				contextmenu.append((u'Usun', 'XBMC.Container.Refresh(%s)'% build_url({'mode': 'SzukajUsun', 'ex_link' : entry})),)
				contextmenu.append((u'Usun cała historie', 'XBMC.Container.Update(%s)' % build_url({'mode': 'SzukajUsunAll'})),)
				add_item(entry,entry, '', True, 'listsearch', contextmenu=contextmenu)	
				
		xbmcplugin.setContent(addon_handle, 'movies')				
		xbmcplugin.endOfDirectory(addon_handle)
		
	elif mode =='SzukajNowe':
		d = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu/serialu', type=xbmcgui.INPUT_ALPHANUM)
		if d:
			setHistory(d)
			ex_link=d.replace(' ','+')
			ListSearch(ex_link,page)
			xbmcplugin.setContent(addon_handle, 'movies')		
			
	elif mode =='SzukajUsun':
		remCache(ex_link)
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))
	
	elif mode == 'SzukajUsunAll':
		delHistory()
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))


		

