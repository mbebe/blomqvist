# -*- coding: utf-8 -*-
import urllib2,urllib
import re,os
import base64,json
import urlparse
import cfcookie
import cookielib
import xbmcgui

BASEURL='http://alltube.tv'
TIMEOUT = 15
UA = 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.472.63 Safari/534.3'

BRAMKA = 'https://proxiak.eu'

def getUrl(url, data = None, header={}):
    cookies = cfcookie.cookieString(COOKIEFILE)
    content = _getUrl(url,data,cookies)

    if not content:
        cj = cf_setCookies(url,COOKIEFILE)
        cookies = cfcookie.cookieString(COOKIEFILE)
        content = _getUrl(url, data, cookies)
        if not content and BRAMKA:
            content = getUrlh(url,header)
            content = urllib.unquote(content)

    return content

def _getUrl(url, data = None, cookies = None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)
    if cookies:
        req.add_header("Cookie", cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()
        response.close()
    except:
        link=''

    return link

def getUrlh(url, header={}):
    link=''
    global cookie
    cookie = ''

    if not cookie:
        req = urllib2.Request(BRAMKA,data=None,headers={'User-Agent': UA,'Upgrade-Insecure-Requests':1})
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        cookies=response.headers.get('set-cookie',' ').split(' ')[0]
        response.close()
        cookie = cookies
    else:
        cookies = cookie

    data = 'u=%s&allowCookies=on'%urllib.quote_plus(url)
    kurl = BRAMKA+'/includes/process.php?action=update'
    headers={'User-Agent': UA,'Upgrade-Insecure-Requests':1,'Cookie':cookies}
    headers.update(header)
    req = urllib2.Request(kurl,data,headers)
    response = urllib2.urlopen(req,timeout=TIMEOUT)
    link = response.read()

    if 'sslagree' in link:
        kurl = BRAMKA+'/includes/process.php?action=sslagree'
        req = urllib2.Request(kurl,data,headers)
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()

    response.close()
    print 'GATE in USE'

    return link

def cf_setCookies(link,cfile):
    cj = cookielib.LWPCookieJar()
    cookieJar = cfcookie.createCookie(BASEURL,cj,UA)
    dataPath=os.path.dirname(cfile)

    if not os.path.exists(dataPath):
        os.makedirs(dataPath)

    if cookieJar:
        cookieJar.save(cfile, ignore_discard = True)

    return cj

def getHref(href):
    url = href.replace('/browse.php?u=','')
    url = url.split('&amp;')[0]

    return urllib.unquote(url)

def scanMainpage(url,page=1,data=None):
    if 'strona' in url:
        url = re.sub(r'strona\[\d+\]','strona[%d]'%page,url)

    elif '/aktor/' not in url and page>1:
        url = url[:-1] if url[-2:] == '+/' else url
        url = url + 'strona[%d]+'%page

    content = getUrl(url,data)
    ids = [(a.start(), a.end()) for a in re.finditer('<div class="item-block clearfix">', content)]

    if not ids:
        ids = [(a.start(), a.end()) for a in re.finditer('<div class="cartoon">', content)]

    ids.append( (-1,-1) )
    out=[]

    for i in range(len(ids[:-1])):
        subset = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile('<a href="(.*?)"',re.DOTALL).search(subset)
        title = re.compile('<h3>(.*?)</h3>',re.DOTALL).search(subset)
        title2= re.compile('<div class="second-title">(.*?)</div>').search(subset)
        plot = re.compile('<p[^>]*>(.*?)</p>',re.DOTALL).search(subset)
        img = re.compile('<img src="(.*?)"',re.DOTALL).search(subset)
        year = re.compile('<div class="item-details">(.*?)<',re.DOTALL).search(subset)
        lang = re.compile('aria-hidden="true"></i>(.*?)<').search(subset)

        if year:
            year =  re.compile('(\d{4})',re.DOTALL).search(year.group(1))

        lang = lang.group(1).replace('&nbsp;','').strip() if lang else ''

        if href and title:
            img = img.group(1).strip() if img else ''
            one = {'href'   : getHref(href.group(1).strip()),
                'title'  : unicodePLchar(title.group(1)),
                'plot'   : unicodePLchar(plot.group(1)) if plot else '',
                'img'    : getHref(img),
                'year'   : year.group(1) if year else '?',
                'code'   : lang,
                    }
            out.append(one)

    nextPage=False

    if content.find('strona[%d]'%(page+1))>-1:
        nextPage = page+1

    prevPage = page-1 if page>1 else False

    return (out, (prevPage,nextPage))

def scanFun(url,page=1,data=None):
    urlpage = url + '%d'%page
    content = getUrl(urlpage,data)
    ids = [(a.start(), a.end()) for a in re.finditer('<div class="fun-block clearfix">', content)]
    ids.append( (-1,-1) )
    out=[]

    for i in range(len(ids[:-1])):
        subset = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile('<a href="(.*?)"',re.DOTALL).search(subset)
        img = re.compile('<img src="(.*?)"',re.DOTALL).search(subset)
        title_1 = re.compile('<h3.*>(.*?)<').search(subset)
        title_2 = re.compile('<div class="bottom-belt">(.*?)<').search(subset)

        if href and title_1:
            title = unicodePLchar(title_1.group(1))
            plot = unicodePLchar(title_2.group(1)) if title_2 else ''
            one = {'href'   : getHref(href.group(1)),
                'title'  : title,
                'plot'   : plot,
                'img'    : getHref(img.group(1)) if img else '',
                    }
            out.append(one)

    nextPage=False

    if content.find('href="%d"'%(page+1))>-1:
        nextPage = page+1

    prevPage = page-1 if page>1 else False

    return (out, (prevPage,nextPage))

def getSeries(data=None,page=1):
    url='http://alltube.tv/seriale-online/'
    urlpage = url + '%d'%page
    content = getUrl(urlpage,data)
    ids = [(a.start(), a.end()) for a in re.finditer('<div class="item-block clearfix">', content)]
    ids.append( (-1,-1) )
    out=[]

    for i in range(len(ids[:-1])):
        subset = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile('<a href="(.*?)"',re.DOTALL).search(subset)
        img = re.compile('<img src="(.*?)"',re.DOTALL).search(subset)
        title_1 = re.compile('<div class="top-belt">(.*?)<').search(subset)
        title_2 = re.compile('<div class="bottom-belt">(.*?)<').search(subset)

        if href and title_1:
            title = unicodePLchar(title_1.group(1))
            if title_2:
               title = unicodePLchar(title_2.group(1)) +', ' + title
            one = {
                'href'   : getHref(href.group(1)),
                'title'  : title,
                'img'    : getHref(img.group(1)) if img else '',
                    }
            out.append(one)

    nextPage=False

    if content.find('href="%d"'%(page+1))>-1:
        nextPage = page+1

    prevPage = page-1 if page>1 else False

    return (out, (prevPage,nextPage))

def scanEpisodes(url):
    content = getUrl(url)
    episodes = re.compile('<li class="episode"><a href="(.*?)">(.*?)</a></li>').findall(content)
    out=[]

    for e in episodes:
        season = re.findall('s(\d+)',e[1],flags=re.I)
        season = int(season[0]) if season else ''
        episode = re.findall('e(\d+)',e[1],flags=re.I)
        episode = int(episode[0]) if episode else ''
        one = { 'href'      : getHref(e[0]),
                'season'    : season,
                'episode'   : episode,
                'mediatype' : 'episode',
                'title'     : unicodePLchar(e[1].strip()),
                'img'       : '',
              }
        out.append(one)

    return out

def splitToSeasons(out):
    out_s={}
    seasons = [x.get('season') for x in out]
    for s in set(seasons):
        out_s['Sezon %02d'%s]=[out[i] for i, j in enumerate(seasons) if j == s]

    return out_s

def parseVideoLink(url, host = ''):
    if 'cda' in host:
        return 'http://www.cda.pl/video/%s'%(url.split('id=')[-1])
    elif 'alltube' in url:
        content = getUrl(url)
        outurl=''
        href= re.compile('src="(.*?)"').findall(content)
        if href:
            href = [h for h in href if BRAMKA not in h]
            outurl = getHref(href[0])
            if outurl.startswith('//'):
                outurl = 'http:'+outurl
        return outurl
    elif 'youtube' in url:
        if url.startswith('//'):
            url = 'http:' + url
    elif str(host) in url:
        if url.startswith('//'):
            url = 'http:' + url
        return url
    else:
        return url

def getVideos(url):
    content = getUrl(url)
    tbody = re.compile('<tbody>(.*?)</tbody>',re.DOTALL).findall(content)
    tbody = tbody[0] if tbody else ''
    ids = [(a.start(), a.end()) for a in re.finditer('<tr>', tbody)]
    ids.append( (-1,-1) )
    out=[]

    for i in range(len(ids[:-1])):
        subset = tbody[ ids[i][1]:ids[i+1][0] ]
        href = re.compile('data-iframe="(.*?)"').search(subset)
        data = re.compile('class="text-center">(.*?)<',re.DOTALL).search(subset)
        host = re.compile('<img src=".*?"\s*alt=".*?">(.*?)<').search(subset)
        rating =re.compile('class="rate">(.*?)</div>',re.DOTALL).search(subset)

        if href and host:
            wersja = data.group(1) if data else ''
            rt = rating.group(1) if rating else ''
            host  = host.groups()[-1].strip()
            if 'youtube' in href.group(1):
               dlink = href.group(1)
            else:
               dlink = base64.b64decode(href.group(1))

            if dlink:
                one = {
                    'url' : dlink,
                    'title': "[COLOR blue]%s[/COLOR] | Ocena Linku: %s | [%s]" %(wersja,rt,host),
                    'host': host,
                    'rate': int(rt.strip('%')),
                    'wersja': wersja,
                    }
                out.append(one)
            else:
                xbmcgui.Dialog().ok('[COLOR red]Błąd[/COLOR]','Problem z linkiem: %s'%dlink)

    if not out:
        iframe= re.compile('<iframe(.*?)</iframe>',re.DOTALL).findall(content)

        if iframe:
            src = re.compile('src="(.*?)"',re.DOTALL).findall(iframe[0])
            if src:
                host = urlparse.urlparse(src[0]).netloc
                out.append( {
                    'url' : src[0],
                    'title': "[%s]" %(host),
                    'host': host,
                    'rate':0,
                    'wersja':'',
                    })

    return out

def search(txt='futurama'):
    out_f=[]
    out_s=[]
    out3=[]
    url='http://alltube.tv/index.php?url=search/autocomplete/&phrase=%s'%urllib.quote_plus(txt)
    content= getUrl(url)

    if content:
        items=json.loads(content)
        for item in items.get('suggestions',[]):
            href  = item.get('data','')
            title = unicodePLchar(item.get('value',''))
            if 'serial' in href:
                out_s.append({'title':title,'href':href})
            elif '/aktor/' in href:
                out3.append({'title':title,'href':href})
            else:
                out_f.append({'title':title,'href':href})

    return (out_f,out_s,out3)

def getPlaylist():
    content=getUrl('http://alltube.tv/playlist/')
    ids = [(a.start(), a.end()) for a in re.finditer('<div class="playlist-item', content)]
    ids.append( (-1,-1) )
    out=[]

    for i in range(len(ids[:-1])):
        offset = 200
        subset = content[ ids[i][1]-offset:ids[i+1][0] ]
        href = re.compile('<a href="(http://alltube.tv/playlista.*?)"').search(subset)
        title = re.compile('<h3>(.*?)</h3>').search(subset)
        inside = re.compile('<div class="col-sm-6 text-right">(.*?)</div>',re.DOTALL).search(subset)
        inside = inside.group(1).replace('&nbsp;','').strip().replace('  ',' ') if inside else ''

        if href and title:
            title= unicodePLchar(title.group(1)) if title else ''
            inside = unicodePLchar(inside)
            href_url = href.group(1)
            one = {'href' : href_url,
                   'title': "[COLOR cyan]%s[/COLOR] [%s]" %(title,inside),
                    }
            out.append(one)

    return out

def getPlaylistContent(url, page = 1):
    page = int(page)
    out_f = []
    out_s = []
    url = re.sub('L1xkKyQ='.decode('base64'),'/%d'%page,url)
    content = getUrl(url)
    ids = [(a.start(), a.end()) for a in re.finditer('<div class="item-block clearfix">', content)]
    ids.append( (-1,-1) )

    for i in range(len(ids[:-1])):
        subset = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile('<a href="(.*?)"',re.DOTALL).search(subset)
        title = re.compile('<h3>(.*?)</h3>',re.DOTALL).search(subset)
        title2= re.compile('<div class="second-title">(.*?)</div>').search(subset)
        plot = re.compile('<p[^>]*>(.*?)</p>',re.DOTALL).search(subset)
        img = re.compile('<img src="(.*?)"',re.DOTALL).search(subset)
        year = re.compile('<div class="item-details">(.*?)<',re.DOTALL).search(subset)
        if year:
            year =  re.compile('(\d{4})',re.DOTALL).search(year.group(1))
        if href and title:
            img = img.group(1) if img else ''
            one = {'href'   : href.group(1),
                'title'  : unicodePLchar(title.group(1)),
                'plot'   : unicodePLchar(plot.group(1)) if plot else '',
                'img'    : img,
                'year'   : year.group(1) if year else '?',
                    }
            if '/film/' in one.get('href'):
                out_f.append(one)
            else:
                out_s.append(one)

    nextPage = False

    if content.find('strona" href="%d"'%(page+1))>-1:
        nextPage = page+1

    prevPage = page-1 if page>1 else False

    return ((out_f,out_s), (prevPage,nextPage))

def filter(what):
    content = getUrl('http://alltube.tv/filmy-online/')
    if   what == 'kategoria':
        filter = re.compile('<ul class="filter-list filter-category">(.*?)</ul>',re.DOTALL).findall(content)
        pattern = 'kategoria[%s]+'
    elif what =='rok':
        filter = re.compile('<ul class="filter-list" id="filter-year">(.*?)</ul>',re.DOTALL).findall(content)
        pattern = 'rok[%s]+'
    elif what =='wersja':
        filter = re.compile('<ul class="filter-list" id="filter-version">(.*?)</ul>',re.DOTALL).findall(content)
        pattern = 'wersja[%s]+'
    else:
        filter = []
    if filter:
        items = re.compile('<li data-id="(.*?)"[^>]*>(.*?)</li>',re.DOTALL).findall(filter[0])
        kat = [x[0] for x in items]
        display = [x[1] for x in items]
        return (display,kat)
    return (None,None)

def funKategorie():
    content = getUrl('http://alltube.tv/fun/')
    filter = re.compile('<li><a href="(http[s]*://alltube.tv/fun/[^"]+)">(.*?)</a></li>',re.DOTALL).findall(content)
    return filter

def unicodePLchar(txt):
    if type(txt) is not str:
        txt=txt.encode('utf-8')

    txt = txt.replace('''&nbsp;''','')
    txt = txt.replace('''&quot;''','"')
    txt = txt.replace('''&bdquo;''','\'')
    txt = txt.replace('''&rdquo;''','\'')
    txt = txt.replace('''&oacute;''','ó').replace('''&Oacute;''','Ó')
    txt = txt.replace('''&rsquo;''','\'')
    txt = txt.replace('''[''','')
    txt = txt.replace(''']''','')
    s='26235c642b3b'
    t='265b5e3b5d3b'
    txt = re.sub(s.decode('hex'),'',txt)
    txt = re.sub(t.decode('hex'),'',txt)
    txt = txt.replace('''&amp;''','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')

    return txt
