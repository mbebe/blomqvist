# -*- coding: utf-8 -*-
import sys,re,os,json
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import resolveurl as urlresolver
import time

try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
 
cache = StorageServer.StorageServer("alltubetv")
import resources.lib.alltube as alltube

base_url		   = sys.argv[0]
addon_handle	   = int(sys.argv[1])
args			   = urlparse.parse_qs(sys.argv[2][1:])
my_addon		   = xbmcaddon.Addon()
addonName		  = my_addon.getAddonInfo('name')
addonId			= my_addon.getAddonInfo('id')
PATH			   = my_addon.getAddonInfo('path')
DATAPATH		   = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES		  = PATH+'/resources/'
alltube.COOKIEFILE = os.path.join(DATAPATH,'alltube.cookie')
FANART			 = RESOURCES+'fanart.png'

BASEURL = 'http://alltube.pl'
TIMEOUT = 15
UA	  = 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.472.63 Safari/534.3'


def addLinkItem(name, url, mode, page=1, iconimage=None, infoLabels=False, contextO=[''], IsPlayable=True,fanart=FANART,itemcount=1):
	u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'page':page})
	if iconimage==None:
		iconimage='DefaultFolder.png'

	liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)

	if not infoLabels:
		infoLabels={"title": name}

	liz.setInfo(type="video", infoLabels=infoLabels)

	if IsPlayable:
		liz.setProperty('IsPlayable', 'true')

	if fanart:
		liz.setProperty('fanart_image',fanart)

	isp = []
	content=urllib.quote_plus(json.dumps(infoLabels))

	if 'DOWNLOAD' in contextO:
		isp.append(('[B]Download[/B]', 'RunPlugin(plugin://%s?mode=DOWNLOAD&ex_link=%s)'%(addonId,content)))

	liz.addContextMenuItems(isp, replaceItems=False)
	ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=False,totalItems=itemcount)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

	return ok

def addDir(name,ex_link=None, page=1, mode='folder',iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART,contextmenu=None):
	url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'page' : page})
	li = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)

	if infoLabels:
		li.setInfo(type="movie", infoLabels=infoLabels)

	if fanart:
		li.setProperty('fanart_image', fanart )

	if contextmenu:
		isp=contextmenu
		li.addContextMenuItems(isp, replaceItems=True)
	else:
		isp = []
		isp.append(('Informacja', 'XBMC.Action(Info)'),)
		li.addContextMenuItems(isp, replaceItems=False)

	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def encoded_dict(in_dict):
	out_dict = {}
	for k, v in in_dict.iteritems():
		if isinstance(v, unicode):
			v = v.encode('utf8')
		elif isinstance(v, str):
			v.decode('utf8')
		out_dict[k] = v
	return out_dict

def build_url(query):
	return base_url + '?' + urllib.urlencode(encoded_dict(query))

def listMovies(ex_link,page):
	url,data = ex_link.split('?') if '?' in ex_link else (ex_link,None)
	out,pagination = alltube.scanMainpage(url,int(page),data)
	kuk=alltube.cookieString(alltube.COOKIEFILE)
	if pagination[0]:
		addLinkItem(name='[COLOR red][B]<< poprzednia strona <<[/B][/COLOR]', url=ex_link, mode='__page__M', page=pagination[0], IsPlayable=False)

	items=len(out)

	for f in out:
		addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img')+'|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuk), infoLabels=f, contextO=['DOWNLOAD'], IsPlayable=True,itemcount=items,fanart=f.get('img')+'|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuk))

	if pagination[1]:
		addLinkItem(name='[COLOR blue][B]>> następna strona >>[/B][/COLOR]', url=ex_link, mode='__page__M', page=pagination[1], IsPlayable=False)

	xbmcplugin.setContent(addon_handle, 'movies')

def ListFun(ex_link,page):
	url,data = ex_link.split('?') if '?'in ex_link else (ex_link,None)
	out,pagination = alltube.scanFun(url,int(page),data)
	if pagination[0]:
		addLinkItem(name='[COLOR red][B]<< poprzednia strona <<[/B][/COLOR]', url=ex_link, mode='__page__F', page=pagination[0], IsPlayable=False)

	items=len(out)

	for f in out:
		addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,itemcount=items,fanart=f.get('img'))

	if pagination[1]:
		addLinkItem(name='[COLOR blue][B]>> następna strona >>[/B][/COLOR]', url=ex_link, mode='__page__F', page=pagination[1], IsPlayable=False)

	xbmcplugin.setContent(addon_handle, 'movies')

	
	
def ListLetters():

	out = alltube.getLetters()	
	for f in out:
	
	
	
		addDir(name=f.get('title'), ex_link=f.get('href'), mode='ListSerialeAlf', iconImage=f.get('img'), infoLabels=f, fanart=f.get('img'))	

def ListSerialeAlf(ex_link):
	out = alltube.getSerialeAlf(ex_link)	
	my_mode = 'getEpisodes3'
	
	if 'true' in my_addon.getSetting('groupEpisodes'):
		my_mode = 'getSeasons2'	
	for f in out:
		addDir(name=f.get('title'), ex_link=f.get('href'), mode=my_mode, iconImage=f.get('img'), infoLabels=f, fanart=f.get('img'))	

	xbmcplugin.setContent(addon_handle, 'tvshows')
	
def ListSeriale(ex_link,page):
	out,pagination = alltube.getSeries(ex_link,int(page))
	my_mode = 'getEpisodes'
	if pagination[0]:
		addLinkItem(name='[COLOR red][B]<< poprzednia strona <<[/B][/COLOR]', url=ex_link, mode='__page__S', page=pagination[0], IsPlayable=False)
	if 'true' in my_addon.getSetting('groupEpisodes'):
		my_mode = 'getSeasons'	
		for f in out:
			addDir(name=f.get('title'), ex_link=f.get('href'), mode=my_mode, iconImage=f.get('img'), infoLabels=f, fanart=f.get('img'))
	else:
		for f in out:
			addLinkItem(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), infoLabels=f, IsPlayable=True,fanart=f.get('img'))
	
	if pagination[1]:
		addLinkItem(name='[COLOR blue][B]>> następna strona >>[/B][/COLOR]', url=ex_link, mode='__page__S', page=pagination[1], IsPlayable=False)

	xbmcplugin.setContent(addon_handle, 'tvshows')

def getSeasons(ex_link):
	episodes = alltube.scanEpisodes(ex_link)
	seasons = alltube.splitToSeasons(episodes)
	for i in sorted(seasons.keys()):
		addDir(name=i, ex_link=urllib.quote(str(seasons[i])), mode='getEpisodes2')

	xbmcplugin.setContent(addon_handle, 'season')

def getSeasons2(ex_link):
	episodes = alltube.scanEpisodes3(ex_link)
	seasons = alltube.splitToSeasons(episodes)

	for i in sorted(seasons.keys()):
		addDir(name=i, ex_link=urllib.quote(str(seasons[i])), mode='getEpisodes2')

	xbmcplugin.setContent(addon_handle, 'season')

def getEpisodes(ex_link):
	episodes = alltube.scanEpisodes(ex_link)

	for f in episodes:
		addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f,contextO=['DOWNLOAD'], IsPlayable=True,fanart=f.get('img'))

	xbmcplugin.setContent(addon_handle, 'episodes')

def getEpisodes2(ex_link):
	episodes = eval(urllib.unquote(ex_link))
	for f in episodes:
		addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f,contextO=['DOWNLOAD'], IsPlayable=True,fanart=f.get('img'))

	xbmcplugin.setContent(addon_handle, 'episodes')

def getEpisodes3(ex_link):
	episodes = alltube.scanEpisodes3(ex_link)

	for f in episodes:
		addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f,contextO=['DOWNLOAD'], IsPlayable=True,fanart=f.get('img'))

	xbmcplugin.setContent(addon_handle, 'episodes')
def FSLinks(ex_link,tryb='search',page=1):
	pagination = (None, None)
	my_mode = 'getEpisodes3'
	kuk=alltube.cookieString(alltube.COOKIEFILE)
	link = []

	if 'true' in my_addon.getSetting('groupEpisodes'):
		my_mode = 'getSeasons2'

	if  tryb == 'search':
		filmy, seriale, link = alltube.search(ex_link)

	elif tryb=='playlist':
		out, pagination = alltube.getPlaylistContent(ex_link,page)
		filmy, seriale = out

	else:
		filmy = seriale = []

	if pagination[0]:
		addLinkItem(name='[COLOR red][B]<< poprzednia strona <<[/B][/COLOR]', url=ex_link, mode='__page__P', page=pagination[0], IsPlayable=False)

	for f in filmy:
		f['title'] = '[B](F)[/B] '+f.get('title')
		if f.get('img'):
			imag=f.get('img')+'|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuk)
		else:
			imag=''
		addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=imag, infoLabels=f, contextO=['DOWNLOAD'],IsPlayable=True,fanart=imag)

	for f in seriale:
		if f.get('img'):
			imag=f.get('img')+'|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuk)
		else:
			imag=''	
		f['title']='[B](S)[/B] '+f.get('title')
		addDir(name=f.get('title'), ex_link=f.get('href'), mode=my_mode, iconImage=imag, infoLabels=f, fanart=imag)

	for f in link:
		if f.get('img'):
			imag=f.get('img')+'|User-Agent='+urllib.quote(UA)+'&Referer='+BASEURL+'&Cookie='+urllib.quote(kuk)
		else:
			imag=''
		f['title']='[B](A)[/B] '+f.get('title')
		addDir(name=f.get('title'), ex_link=f.get('href'), mode='ListMovies', iconImage=imag, infoLabels=f, fanart=imag)

	if pagination[1]:
		addLinkItem(name='[COLOR blue][B]>> następna strona >>[/B][/COLOR]', url=ex_link, mode='__page__P', page=pagination[1], IsPlayable=False)
	xbmcplugin.endOfDirectory(addon_handle)
def getLinks(ex_link, get_download = False, name = '', image = ''):
	if 'filmik/' in ex_link:
		streams = alltube.getVideosFun(ex_link);
	else:
		streams = alltube.getVideos(ex_link);
	stream_url = ''

	if len(streams) > 0:
	   t = [ x.get('title') for x in streams]
	   u = [ x.get('url') for x in streams]
	   h = [ x.get('host') for x in streams]
	   al = "Z jakiego źródla pobieramy?" if get_download else "Wersja | Ocena | [Host] "
	   select = xbmcgui.Dialog().select(al, t)
	else:
	   select = -1

	if select > -1:
		link = u[select];
		if 'youtube' in h[select]: 
		   link = link.replace('www.youtube.com/embed','youtu.be')

		link = alltube.parseVideoLink(link,[select])

		if not stream_url:
			try:
				stream_url = urlresolver.resolve(link)
			except Exception,e:
				stream_url=''
				s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link będzie działał?','Urlresolver ERROR: [%s]'%str(e))
				xbmcplugin.endOfDirectory(addon_handle,False)	
	if stream_url:
		if get_download:
			import resources.lib.downloader as dw
			try:
				if 'sezon' in ex_link:
				   transtitle = ex_link.split('/')
				   stitle = transtitle[3].capitalize()
				else:
				   stitle = ''
				dw.download(name, image, stream_url, stitle)
			except:
			   xbmc.executebuiltin( "XBMC.Notification(%s,%s,%i,%s)" % ( '[COLOR red] Bląd pobierania [/COLOR]', name, 5000, image))

		xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
	else:
		xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
		xbmcplugin.endOfDirectory(addon_handle,False)	
def getHistory():
	return cache.get('history').split(';')

def setHistory(entry):
	history = getHistory()
	if history == ['']:
		history = []
	history.insert(0, entry)
	cache.set('history',';'.join(history[:50]))

def remCache(entry):
	history = getHistory()
	if history:
		cache.set('history',';'.join(history[:50]))
	else:
		delHistory()

def delHistory():
	cache.delete('history')

xbmcplugin.setContent(addon_handle, 'movies')
f_filtrV = my_addon.getSetting('f_filtrV')
f_filtrN = my_addon.getSetting('f_filtrN') if f_filtrV else 'Nowe'
s_filtrV = my_addon.getSetting('s_filtrV')
s_filtrN = my_addon.getSetting('s_filtrN') if s_filtrV else 'Nowe'
f_verV   = my_addon.getSetting('f_verV')
f_verN   = my_addon.getSetting('f_verN') if f_verV else 'Wszystkie'

mode	 = args.get('mode', None)
fname	= args.get('foldername',[''])[0]
ex_link  = args.get('ex_link',[''])[0]
page	 = args.get('page',[1])[0]

if mode is None:
	addLinkItem("[B]Wersja językowa: [/B] [B]%s[/B]"%f_verN,'',mode='setVer:f_ver',iconimage=RESOURCES+'filmy.png',IsPlayable=False)
	addDir(name="[B]Filmy nowe[/B]",ex_link='http://alltube.pl/filmy-online/',page=1, mode='ListMovies',iconImage=RESOURCES+'filmy.png')
	addDir(name="  [B] [Gatunek][/B]",ex_link='kategoria',page=1, mode='GatunekRok',iconImage=RESOURCES+'filmy.png',fanart=FANART)
	addDir(name="  [B] [Rok][/B]",ex_link='rok',page=1, mode='GatunekRok',iconImage=RESOURCES+'filmy.png',fanart=FANART)
	addDir(name="[B]Seriale alfabetycznie[/B]",ex_link=None,page=1, mode='ListLetters',iconImage=RESOURCES+'seriale.png')
	addDir(name="[B]Seriale nowe[/B]",ex_link=None,page=1, mode='ListSeriale',iconImage=RESOURCES+'seriale.png')
	addDir(name="[B]DLA DZIECI[/B]",ex_link='http://alltube.pl/filmy-online/kategoria[5]+wersja[Lektor,Dubbing,PL]+', mode='ListMovies',iconImage=RESOURCES+'dzieci.png')
	addDir(name="Anime",ex_link='http://alltube.pl/anime/',page=1, mode='ListAnime',iconImage=RESOURCES+'anime.png',fanart=FANART)
	addDir(name="Fun",ex_link='http://alltube.pl/fun/', mode='ListFun',iconImage=RESOURCES+'fun.png')
	addDir(name="Fun [Kategorie]",ex_link='',page=1, mode='FunKategorie',iconImage=RESOURCES+'fun.png',fanart=FANART)
	addDir(name="[B]Playlisty[/B]",ex_link='', mode='Playlist',iconImage=RESOURCES+'playlisty.png')
	addDir('Szukaj','',mode='Szukaj',iconImage=RESOURCES+'szukaj.png')
	xbmcplugin.endOfDirectory(addon_handle)
elif 'setFiltr' in mode[0]:
	sst = mode[0].split(":")[-1]
	label=['Nowe','Nowe linki','Najpopularniejsze','Najwyżej oceniane']
	value=['?filter=new','?filter=updated','?filter=popular','?filter=rate']
	s = xbmcgui.Dialog().select('Wybierz Filtr',label)
	s = s if s>-1 else 0
	my_addon.setSetting(sst+'V',value[s])
	my_addon.setSetting(sst+'N',label[s])
	xbmc.executebuiltin('XBMC.Container.Refresh')

elif 'setVer' in mode[0]:
	sst = mode[0].split(":")[-1]
	label=['Wszystkie','Lektor', 'Dubbing', 'Napisy', 'PL', 'ENG']
	value=['','Lektor', 'Dubbing', 'Napisy', 'PL', 'ENG']
	try:
		s = xbmcgui.Dialog().multiselect('Wersja językowa (multiselect)',label)
	except:
		s = xbmcgui.Dialog().select('Wersja językowa',label)
	if not s: s=0
	if isinstance(s,list):
		if 0 in s: s=[0]
		v = 'wersja[%s]+'%(','.join( [ value[i] for i in s])) if s[0]!=0 else ''
		n = ','.join( [ label[i] for i in s])
	else:
		s = s if s>-1 else 0
		v = 'wersja[%s]+'%value[s]
		n = label[s]

	my_addon.setSetting(sst+'V',v)
	my_addon.setSetting(sst+'N',n)
	xbmc.executebuiltin('XBMC.Container.Refresh')

elif mode[0] == '__page__M':
	url = build_url({'mode': 'ListMovies', 'foldername': '', 'ex_link' : ex_link, 'page': page})
	xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == '__page__S':
	url = build_url({'mode': 'ListSeriale', 'foldername': '', 'ex_link' : ex_link, 'page': page})
	xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == '__page__P':
	url = build_url({'mode': 'PlaylistLinks', 'foldername': '', 'ex_link' : ex_link, 'page': page})
	xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == '__page__F':
	url = build_url({'mode': 'ListFun', 'foldername': '', 'ex_link' : ex_link, 'page': page})
	xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == 'Playlist':
	items = alltube.getPlaylist()
	for f in items:
		addDir(name=f.get('title'), ex_link=f.get('href'), mode='PlaylistLinks', iconImage=f.get('img'), infoLabels=f, fanart=f.get('img'))
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'PlaylistLinks':
	FSLinks(ex_link,tryb='playlist',page=page)
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'ListMovies':
	if f_verV not in ex_link: ex_link+= f_verV
	if f_filtrV not in ex_link:
		ex_link += '' if ex_link[-1]=='/' else '/'
		ex_link += f_filtrV

	listMovies(ex_link,page)
	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'ListAnime':
	listMovies(ex_link,page)
	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'ListFun':
	ListFun(ex_link,page)
	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'getSeasons':
	getSeasons(ex_link)
	xbmcplugin.setContent(addon_handle, 'tvshows')
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'getSeasons2':
	getSeasons2(ex_link)
	xbmcplugin.setContent(addon_handle, 'tvshows')
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'getEpisodes':
	getEpisodes(ex_link)
	xbmcplugin.setContent(addon_handle, 'episodes')
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'getEpisodes2':
	getEpisodes2(ex_link)
	xbmcplugin.setContent(addon_handle, 'episodes')
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'getEpisodes3':
	getEpisodes3(ex_link)
	xbmcplugin.setContent(addon_handle, 'episodes')
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'ListSeriale':
	ListSeriale(s_filtrV.strip('?'),page)
	xbmcplugin.setContent(addon_handle, 'tvshows')
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'getLinks':
	getLinks(ex_link)

elif mode[0] == 'ListSerialeAlf':	
	ListSerialeAlf(ex_link)
	xbmcplugin.setContent(addon_handle, 'tvshows')
	xbmcplugin.endOfDirectory(addon_handle)	
elif mode[0] == 'ListLetters':	
	ListLetters()	
	xbmcplugin.setContent(addon_handle, 'tvshows')
	xbmcplugin.endOfDirectory(addon_handle)	
	
elif mode[0] == 'DOWNLOAD':
	data = eval(ex_link)
	download_path_movie = my_addon.getSetting('movie.download.path')
	download_path_tv	= my_addon.getSetting('tv.download.path')

	if 'sezon' in ex_link:
		if download_path_tv:
		   getLinks(data.get('href'), True, data.get('title'), data.get('img'))
		else:
		   xbmcgui.Dialog().ok('Ustaw docelowy folder dla seriali', 'Pobieranie nie powiodło się')
		   xbmc.executebuiltin("Addon.OpenSettings(%s)"%addonId)
	else:
		if download_path_movie:
		   getLinks(data.get('href'), True, data.get('title'), data.get('img'))
		else:
		   xbmcgui.Dialog().ok('Ustaw docelowy folder dla filmów', 'Pobieranie nie powiodło się')
		   xbmc.executebuiltin("Addon.OpenSettings(%s)"%addonId)

elif mode[0] == 'searchItems':
	FSLinks(ex_link,'search')

elif mode[0] == 'FunKategorie':
	data = alltube.funKategorie()
	for one in data:
		title = alltube.unicodePLchar(one[1])
		addDir(name=title,ex_link=one[0], mode='ListFun',iconImage=RESOURCES+'fun.png')
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'GatunekRok':
	data = alltube.filter(ex_link)
	if data:
		label=data[0]
		value=data[1]
		v=''
		try:
			s = xbmcgui.Dialog().multiselect('Wybierz '+ex_link,label)
		except:
			s = xbmcgui.Dialog().select('Wybierz '+ex_link,label)
		if not s: s=quit()
		if isinstance(s,list):
			v = '%s[%s]+'%(ex_link,','.join( [ value[i] for i in s])) if s[0]>-1 else ''
		else:
			s = s if s>-1 else quit()
			v = '%s[%s]+'%(ex_link,value[s])
		if v:
		
			href = 'http://alltube.pl/filmy-online/'+v
			url = build_url({'mode': 'ListMovies', 'foldername': '', 'ex_link' : href, 'page': 1})
			xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'Opcje':
	my_addon.openSettings()

elif mode[0] =='Szukaj':
	addDir('[B]Nowe Szukanie(Film,Serial)[/B]','',mode='SzukajNowe')
	historia = getHistory()
	if not historia == ['']:
		for entry in historia:
			contextmenu = []
			contextmenu.append(('Usuń', 'XBMC.Container.Refresh(%s)'% build_url({'mode': 'SzukajUsun', 'ex_link' : entry})),)
			contextmenu.append(('Usuń całą historię', 'XBMC.Container.Update(%s)' % build_url({'mode': 'SzukajUsunAll'})),)
			addDir(name=entry, ex_link=entry.replace(' ','+'), mode='searchItems', fanart=None, contextmenu=contextmenu)
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] =='SzukajNowe':
	d = xbmcgui.Dialog().input('Szukaj, Podaj tytul filmu/serialu/bajki Imie aktora', type=xbmcgui.INPUT_ALPHANUM)
	if d:
		setHistory(d)
		url = build_url({'mode': 'searchItems', 'foldername': '', 'ex_link' : d.replace(' ','+'), 'page': 1})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
		
	else:
		quit()
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] =='SzukajUsun':
	remCache(ex_link)
	xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'SzukajUsunAll':
	delHistory()
	xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0] == 'folder':
	pass
else:
	xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
	xbmcplugin.endOfDirectory(addon_handle)
