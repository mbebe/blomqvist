# -*- coding: UTF-8 -*-

from resources.lib.freedisc import Freedisc

if __name__ == '__main__':
    Freedisc()