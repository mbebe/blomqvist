# -*- coding: UTF-8 -*-
from __future__ import division
import sys,re,os
import six, ast
from six.moves import urllib_parse


import requests

import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc, xbmcvfs
from resources.lib.brotlipython import brotlidec
import inputstreamhelper

if six.PY3:
    basestring = str
    unicode = str
    xrange = range
    from resources.lib.cmf3 import parseDOM
else:
    from resources.lib.cmf2 import parseDOM

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(urllib_parse.parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.uktvlivecom')

PATH            = addon.getAddonInfo('path')
if six.PY2:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
else:
    DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'../fanart.jpg'
ikona =RESOURCES+'../icon.png'

exlink = params.get('url', None)
nazwa= params.get('title', None)
rys = params.get('image', None)

page = params.get('page',[1])#[0]

UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0'
TIMEOUT=15

headers = {
    'Host': 'uktvlive.com',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'DNT': '1',
    'Upgrade-Insecure-Requests': '1',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
}
sess = requests.Session()
main_url = 'https://uktvlive.com'#

def build_url(query):
    return base_url + '?' + urllib_parse.urlencode(query)

def add_item(url, name, image, mode, itemcount=1, page=1,fanart=FANART, infoLabels=False,contextmenu=None,IsPlayable=False, folder=False):
    list_item = xbmcgui.ListItem(label=name)
    if IsPlayable:
        list_item.setProperty("IsPlayable", 'True')    
    if not infoLabels:
        infoLabels={'title': name}    
    list_item.setInfo(type="video", infoLabels=infoLabels)    
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': fanart})
    
    if contextmenu:
        out=contextmenu
        list_item.addContextMenuItems(out, replaceItems=True)
    else:
        out = []
        out.append(('Informacja', 'XBMC.Action(Info)'),)
        list_item.addContextMenuItems(out, replaceItems=False)

    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url = build_url({'mode': mode, 'url' : url, 'page' : page, 'title':name,'image':image}),            
        listitem=list_item,
        isFolder=folder)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
   

def home():
    add_item('', 'List channels', ikona, "listtv",fanart=FANART, folder=True)

def ListTV():
    html=getUrlReqOk(main_url)

    tvs = parseDOM(html,'div', attrs={'class':"fusion\-post\-wrapper"})
    zz=''

    for tv in tvs:
        href = parseDOM(tv,'a', ret="href")[0]

        imgs = re.findall('data\-lazy\-srcset\s*=\s*"([^"]+)"',tv,re.DOTALL)[-1]
        img = re.findall('(http.*?\.png)',imgs,re.DOTALL)[-1]
        title = re.findall('aria\-label\s*=\s*"([^"]+)"',tv,re.DOTALL)[-1]
        if ' Live Online' in title:
            title = title.split(' Live Online')[0].replace('Watch ','')

        add_item(href, title ,img, 'playvid',fanart=FANART, folder=False, IsPlayable=True)
    xbmcplugin.endOfDirectory(addon_handle)

def PlayVid(url):
    html=getUrlReqOk(url).replace("\'",'"')
    encr = re.findall('encrypt\:(.+?)"',html,re.DOTALL)
    vid=''

    if encr:
        import base64
        vid = base64.b64decode(encr[0])
        if six.PY3:
            vid = vid.decode(encoding='utf-8', errors='strict')
    if vid:        

        vid+='|User-Agent='+urllib_parse.quote(UA)
        is_helper = inputstreamhelper.Helper('hls')
        play_item = xbmcgui.ListItem(path=vid)
        if is_helper.check_inputstream():
            
            play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            play_item.setMimeType('application/x-mpegurl')
            play_item.setContentLookup(False)

        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)   

def getUrlReqOk(url,ref=''):    

    headersok = {
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Connection': 'keep-alive',

    'Referer': ref,}

    content=sess.get(url, headers=headersok,verify=False, timeout=30).content
    if six.PY3:
        content= (content).decode(encoding='utf-8', errors='strict') 
    else:
        content = content
    return content

 
def router(paramstring):
    params = dict(urllib_parse.parse_qsl(paramstring))
    if params:    
    
        mode = params.get('mode', None)

        if mode =='listtv':
            ListTV()

        elif mode == 'playvid':
            PlayVid(exlink)

    else:
        home()
        xbmcplugin.endOfDirectory(addon_handle)    
if __name__ == '__main__':
    router(sys.argv[2][1:])