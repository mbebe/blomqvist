# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import base64
import urllib
import urllib2

import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import json
import cookielib
import traceback
import urlparse
import resolveurl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.filmdomfun')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'

FANART=RESOURCES+'fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('name', None)
page = params.get('page','')
mcount= params.get('moviescount', None)
movie= params.get('movie', None)
rys= params.get('image', None)

kukz=''

katv = addon.getSetting('katV')
katn = addon.getSetting('katN') if katv else 'Wszystkie'

rokv = addon.getSetting('rokV')
rokn = addon.getSetting('rokN') if rokv else 'Wszystkie'

TIMEOUT=15
MAIN_URL='https://filmdom.fun'
import cfscrape
scraper = cfscrape.CloudflareScraper()
UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0'
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=1,fanart=FANART,moviescount=0):
	list_item = xbmcgui.ListItem(label=name)

	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')
	if not infoLabels:
		infoLabels={'title': name,'plot':name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	
	art_keys = ['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
	art = dict(zip(art_keys,[image for x in art_keys]))
	art['landscape'] = fanart if fanart else art['landscape']
	art['fanart'] = fanart if fanart else art['landscape']
	list_item.setArt(art)
	if 'Następna strona' not in infoLabels.get('title',''):
		isp = []
		isp.append(('Informacja', 'XBMC.Action(Info)'),)
		list_item.addContextMenuItems(isp, replaceItems=False)
	
	
	ok=xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page, 'moviescount' : moviescount,'movie':movie,'name':name,'image':image}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	return ok

def home():

	setCfCookie()
	add_item('', '[B][COLOR khaki]Filmy[/COLOR][/B]', 'DefaultMovies.png', "listmovies", folder=True,fanart=RESOURCES+'fanart.png')
	add_item('', "[COLOR lightblue]Kategoria:[/COLOR] [B]"+katn+"[/B]",'DefaultRecentlyAddedMovies.png', "filtr:kateg", folder=False,fanart=RESOURCES+'fanart.png')
	add_item('', "[COLOR lightblue]Rok produkcji:[/COLOR] [B]"+rokn+"[/B]",'DefaultRecentlyAddedMovies.png', "filtr:rok", folder=False,fanart=RESOURCES+'fanart.png')
	add_item('1', '[B][COLOR khaki]Seriale[/COLOR][/B]', 'DefaultMovies.png', "listserials", folder=True,fanart=RESOURCES+'fanart.png')
	add_item(' ', '[B][COLOR khaki]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "getsearch", folder=True,fanart=RESOURCES+'fanart.png')

	
def setCfCookie():
	url ='https://filmdom.fun/videos/all?type=movie'
	kk=scraper.get(url,verify=False)
	sc=''.join(['%s=%s;'%(c.name, c.value) for c in scraper.cookies])
	addon.setSetting('cfCookies',sc)
	return sc
	
	
	
	#sc,uacf = cfdeco6.get_cookie_string(url)
	#addon.setSetting('cfCookies',sc)	
	#addon.setSetting('uaCF',uacf)
	#return sc
	
	
def getRequests(url,data={},ref=None):
	kukz =  addon.getSetting('cfCookies')
	#UA=addon.getSetting('uaCF')
	
	headers = {
		'User-Agent': UA,
		'Accept': 'text/html, */*; q=0.01',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Cookie':kukz,
		'Connection': 'keep-alive',}
	if data:
		headers = {
			'User-Agent': UA,
			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
			'Referer': 'https://www.filmy321.pl/',
			'Content-Type': 'application/x-www-form-urlencoded',
			'Connection': 'keep-alive',
			'Upgrade-Insecure-Requests': '1',
			'TE': 'Trailers',}

		content=requests.post(url,headers=headers,data=data,verify=False).content
	else:
		if ref:
			ab=requests.get(ref,headers=headers)
			headersx = {
				'User-Agent': UA,
				'Accept': 'text/html, */*; q=0.01',
				'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
				'Referer': ref,
				'X-Requested-With': 'XMLHttpRequest',
				'Connection': 'keep-alive',
				'TE': 'Trailers',
			}
			headers=headersx
		
		content=requests.get(url,headers=headers).content
	return content
	
def getVideos(url):
	import base64
	html=getRequests(url)
	out=[]
	result = parseDOM(html, 'tbody')[0]
	links = parseDOM(result, 'tr')
	for link in links:
		href=''
		href = re.findall("""set_url\(['"](.+?)['"]\)""",link)
		if href:
			href=base64.b64decode(href[0])
		#href = parseDOM(link, 'a', ret='href')[0]
		hosting = parseDOM(link, 'a')[0]
		typ = parseDOM(link, 'td')[1]
		host = '%s - %s'%(hosting,typ)
		film = {'href' : href,'host' : host.strip(),}
		out.append(film)
	return out
	
def getStream(url):
	html=getRequests('https://filmdom.fun/watch?id='+url)
	src = parseDOM(html, 'iframe', ret='src')#[0]
	stream_url = src[0] if src else ''
	
	return stream_url

def PlayVids(exlink):

	items=getVideos(exlink)
	if not items:
		xbmc.executebuiltin('Notification(Problem, ' + 'Brak źródeł' + ', 1200)')
		return
	if len(items) > 0:
		u = [ x.get('href') for x in items]
		h = [ x.get('host') for x in items]
		al = "Host - Wersja"
		select = xbmcgui.Dialog().select(al, h)
	else:
		select = -1
	if select > -1:
		vid_url = getStream(u[select])

		if vid_url:
			try:
				stream_url = resolveurl.resolve(vid_url)
			except Exception,e:
				stream_url=''
				play_item = xbmcgui.ListItem(path=None)

				xbmc.executebuiltin('Notification(Problem, ' + str(e) + ', 1200)')

			if stream_url:
				play_item = xbmcgui.ListItem(path=stream_url)
				ok=xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
				return ok
		else:
			xbmc.executebuiltin('Notification(Problem, ' + 'Brak źródeł' + ', 1200)')
			return

def ListMovies(url,pg,katv,rokv):
	page = int(pg)
	links, pagin=getMovies(url,page,katv,rokv)
	itemz=links
	items = len(links)
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='playVids', image=f.get('img'), folder=False, infoLabels=f, itemcount=items, IsPlayable=True)	
	if pagin:
		for f in pagin:	
			add_item(name=f.get('title'), url=f.get('href'), mode='listmovies', image='', folder=True,page=f.get('page'))	
	xbmcplugin.setContent(addon_handle, 'videos')	
	xbmcplugin.endOfDirectory(addon_handle)		
	
def getMovies(url,page,katg,rok):
	kukz =  addon.getSetting('cfCookies')
	#UA=addon.getSetting('uaCF')
	dod='|User-Agent='+urllib.quote(UA)+'&Cookie='+kukz

	out=[]
	npout=[]
	
	url='https://filmdom.fun/videos/all?type=movie%s%s&page=%s'%(katg,rok,page)

	html=getRequests(url)
	
	if html.find('<li class="disabled"><span aria-label="Nast')>0:
		pass
	else:
		npout.append({'title':'Następna strona','href':'','img':'','plot':'','page':page+1}) 
	result = parseDOM(html, 'div', attrs={'class': "col-md-8"})[0]# <div class="col-md-8">
	links = parseDOM(result, 'div', attrs={'class': "col-xs-6"})
	for link in links:
		link=link.replace('\n','')
		href = parseDOM(link, 'a', ret='href')[0]
		imag = parseDOM(link, 'img', ret='src')[0]
		tyt = (re.findall('>([^>]+)</a></p>',link)[0]).strip()
		
		year = re.findall('\((\d+)\)',tyt)
		tyt = re.sub('\(\d+\)','',tyt)
		year = int(year[0]) if year else ''

		genre = re.findall('"label label-default">([^>]+)<',link)
		kateg = ','.join([x.strip() for x in genre]) if genre else ''
		plot = re.findall('</p><p>([^>]+)</p><p>',link)
		plot = PLchar(plot[0]) if plot else ''

		href = MAIN_URL+href if href.startswith('/') else href
		imag = MAIN_URL+imag if imag.startswith('/') else imag
		
		out.append({'title':PLchar(tyt),'href':href,'img':imag+dod,'genre':kateg,'plot':plot,'year':year})

	return out,npout


def ListSerials(url,pg):
	page = int(pg)
	links, pagin=getSerials(url,page)
	itemz=links
	items = len(links)
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listseasons', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)	
	if pagin:
		for f in pagin:	
			add_item(name=f.get('title'), url=f.get('href'), mode='listserials', image='', folder=True,page=f.get('page'))	
	xbmcplugin.setContent(addon_handle, 'tvshows')	
	xbmcplugin.endOfDirectory(addon_handle)		
	
def getSerials(url,page):
	kukz =  addon.getSetting('cfCookies')
#	UA=addon.getSetting('uaCF')
	dod='|User-Agent='+urllib.quote(UA)+'&Cookie='+kukz
	out=[]
	npout=[]
	
	url='https://filmdom.fun/videos/all?type=tv_show&page=%s'%(page)

	html=getRequests(url)
	
	if html.find('<li class="disabled"><span aria-label="Nast')>0:
		pass
	else:
		npout.append({'title':'Następna strona','href':'','img':'','plot':'','page':page+1}) 
	result = parseDOM(html, 'div', attrs={'class': "col-md-8"})[0]# <div class="col-md-8">
	links = parseDOM(result, 'div', attrs={'class': "col-xs-6"})

	for link in links:
		link = link.replace('\n','')
		href = parseDOM(link, 'a', ret='href')[0]
		imag = parseDOM(link, 'img', ret='src')[0]
		tyt = (re.findall('>([^>]+)</a></p>',link)[0]).strip()
		
		year = re.findall('\((\d+)\)',tyt)
		tyt = re.sub('\(\d+\)','',tyt)
		year = int(year[0]) if year else ''

		genre = re.findall('"label label-default">([^>]+)<',link)
		kateg = ','.join([x.strip() for x in genre]) if genre else ''
		plot = re.findall('</p><p>([^>]+)</p><p>',link)
		plot = PLchar(plot[0]) if plot else ''

		href = MAIN_URL+href if href.startswith('/') else href
		imag = MAIN_URL+imag if imag.startswith('/') else imag
		out.append({'title':PLchar(tyt),'href':href,'img':imag+dod,'genre':kateg,'plot':plot,'year':year})

	return out,npout


def splitToSeasons(input):
    out={}
    seasons = [x.get('season') for x in input]
    for s in set(seasons):
        out['Sezon %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
    return out
	
def ListSeasons(exlink):

	tt = params.get('name')
	episodes=getSeasons(exlink)
	if episodes:
		imag=episodes[0].get('img')

		seasons = splitToSeasons(episodes)
	
		for i in sorted(seasons.keys()):
			tit = '%s - %s'%(tt,i)
			add_item(name=tit, url=urllib.quote(str(seasons[i])), mode='listepisodes', image=imag, folder=True)
		
		xbmcplugin.setContent(addon_handle, 'seasons')	
		xbmcplugin.endOfDirectory(addon_handle)		
	else:
		sel = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak odcinków','')

def getSeasons(url):
	kukz =  addon.getSetting('cfCookies')
	dod='|User-Agent='+urllib.quote(UA)+'&Cookie='+kukz
	out=[]
	html=getRequests(url)
	
	dane  = parseDOM(html, 'div', attrs={'class': "container"})[1]
	dane = dane.replace('\n','')
	tytul = re.findall('<a href="[^"]+">([^>]+)</a>',dane, re.DOTALL)[0]
	
	year = re.findall('\((\d+)\)',tytul)
	year = int(year[0]) if year else ''
	tyt2 = re.sub('\(\d+\)','',tytul)
	orgtit = re.findall('</h1><p>([^>]+)<',dane)
	orgtyt=''
	opis=''
	if orgtit:
		if not year:
			year = re.findall('\((\d+)\)',orgtit[0])
			year = int(year[0]) if year else ''
		orgtyt = re.sub('\(\d+\)','',orgtit[0])
		opis = parseDOM(dane, 'p')[1]
	imag = parseDOM(dane, 'img', ret='src')[0]
	imag = MAIN_URL+imag if imag.startswith('/') else imag
	if not opis:
		
		opis = parseDOM(dane, 'p')[0]

	result = re.findall('<h2>Lista odcink(.+?)<fo',html,re.DOTALL)[0]
	links = re.findall('<a href="([^"]+)">([^>]+)</a>',result, re.DOTALL)
	
	for h,t in links:
		h = MAIN_URL+h if h.startswith('/') else h
		data = re.compile('[sS](\d+)[Ee](\d+)').findall(t)
		tyt='%s %s'%(tyt2,t)
		film = {
			'href'  : h.strip(),
			'plot' : PLchar(opis),
			'title' : PLchar(tyt),
			'img' : imag+dod,
			'originaltitle': orgtyt,
			'season' : int(data[0][0]) if data else '',
			'episode' : int(data[0][1]) if data else '',
			'aired' : year}
		out.append(film)
	return out
	
def ListEpisodes(exlink):
	episodes = eval(urllib.unquote(exlink))
	items = len(episodes)
	for f in episodes:
		add_item(name=f.get('title'), url=f.get('href'), mode='playVids', image=f.get('img'), folder=False, infoLabels=f, itemcount=items, IsPlayable=True)	
	xbmcplugin.setContent(addon_handle, 'episodes')
	xbmcplugin.endOfDirectory(addon_handle)

def getSearch():	
	d = xbmcgui.Dialog().input(u'Szukaj...', type=xbmcgui.INPUT_ALPHANUM)
	if d:
		d=d.replace(' ','+')
		url='https://filmdom.fun/videos/search?q=%s'%d
		ListSearch(url,1)

def ListSearch(url,page):

	filmy,seriale,strony=getListSearch(url,page)
	if not filmy and not seriale:
		xbmc.executebuiltin('Notification(Uwaga, ' + 'Nic nie znaleziono' + ', 1200)')
		return
	else:

		items = len(seriale)
		for fs in seriale:
			add_item(name=fs.get('title'), url=fs.get('href'), mode='listseasons', image=fs.get('img'), folder=True, infoLabels=fs, itemcount=items)	

		itemsf = len(filmy)
		for f in filmy:
			add_item(name=f.get('title'), url=f.get('href'), mode='playVids', image=f.get('img'), folder=False, infoLabels=f, itemcount=itemsf, IsPlayable=True)	

		if strony:
			for fst in strony:	
				add_item(name=fst.get('title'), url=fst.get('href'), mode='listsearch', image='', folder=True,page=fst.get('page'))	
	
	xbmcplugin.setContent(addon_handle, 'videos')
	xbmcplugin.endOfDirectory(addon_handle)	
	

def getListSearch(url,page):
	
	if 'page=' in url:
		url = re.sub('page=\d+','page=%d'%int(page),url)
	else:
		url = url + '&page=%d' %int(page)	
	
	outf=[]
	outs=[]
	npage=[]

	html=getRequests(url)
	if html.find('<li class="disabled"><span aria-label="Nast')>0:
		pass
	else:
		npage.append({'title':'Następna strona','href':url,'img':'','plot':'','page':int(page)+1}) 
	
	
	if html.find('"alert">Niestety nie znaleziono')>0:
		return outf,outs,npage
	else:
		links = parseDOM(html, 'div', attrs={'class': "col-xs-4"})

		for link in links:
			link = link.replace('\n','')
			href = parseDOM(link, 'a', ret='href')[0]
			imag = parseDOM(link, 'img', ret='src')[0]
			tyt = (re.findall('>([^>]+)</a></p>',link)[0]).strip()
			
			year = re.findall('\((\d+)\)',tyt)
			tyt = re.sub('\(\d+\)','',tyt)
			year = int(year[0]) if year else ''
	
			genre = re.findall('"label label-default">([^>]+)<',link)
			kateg = ','.join([x.strip() for x in genre]) if genre else ''
			plot = re.findall('</p><p>([^>]+)</p><p>',link)
			plot = PLchar(plot[0]) if plot else ''
			rodz = re.findall('<p><a href="([^"]+)"',link)[1]
			
			
			href = MAIN_URL+href if href.startswith('/') else href
			imag = MAIN_URL+imag if imag.startswith('/') else imag
			if 'type=movie' in rodz:
				outf.append({'title':PLchar(tyt),'href':href,'img':imag,'genre':kateg,'plot':plot,'year':year})
			else:
				outs.append({'title':PLchar(tyt),'href':href,'img':imag,'genre':kateg,'plot':plot,'year':year})
				
	return outf,outs,npage

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&#039;',"'")
	char = char.replace('&quot;','"')
	char = char.replace('&nbsp;',".").replace('&amp;','&').replace('&prime;',"'")
	return char	

if __name__ == '__main__':
	mode = params.get('mode', None)
	
	if not mode:
		home()
		xbmcplugin.endOfDirectory(addon_handle)		

	elif mode == 'getsearch':
		getSearch()	
		
	elif mode == 'listsearch':
		ListSearch(exlink,page)
		
	elif mode == 'listmovies':
		ListMovies(exlink,page,katv,rokv)			
	
	elif mode == 'listserials':
		ListSerials(exlink,page)	
		
	elif mode == 'listseasons':
		ListSeasons(exlink)	
	
	elif mode == 'listepisodes':
		ListEpisodes(exlink)	

	elif 'kateg' in mode:
	
		myMode = 'kat'

		value=['&genre=','&genre=98', '&genre=92', '&genre=105', '&genre=88', '&genre=90', '&genre=93', '&genre=97', '&genre=101', '&genre=89', '&genre=102', '&genre=85', '&genre=106', '&genre=1', '&genre=100', '&genre=99', '&genre=86', '&genre=87', '&genre=104', '&genre=94', '&genre=96', '&genre=103', '&genre=95', '&genre=109', '&genre=91']
		label=['Wszystkie','Akcja','Animowane','Biografie','Dokumentalne','Dramat','Familijne','Fantasty','Historyczne','Horror','Katastroficzne','Komedia','Kostiumowe','Krymina\xc5\x82','Musical','Obyczajowy','Polskie','Przygodowe','Romans','Sci-fi','Sensacyjne','Sport','Thriller','Western','Wojenne']

		msg = 'Kategorie'
		sel = xbmcgui.Dialog().select(msg,label)
		if sel>-1:
		
			addon.setSetting(myMode+'V',value[sel])
			addon.setSetting(myMode+'N',label[sel])
			
			xbmc.executebuiltin("Container.Refresh") 
		else:
			pass	

	elif 'rok' in mode:
	
		myMode = 'rok'	

		value=['&year=','&year=2019', '&year=2018', '&year=2017', '&year=2016', '&year=2015', '&year=2014', '&year=2013', '&year=2012', '&year=2011', '&year=2010', '&year=2009', '&year=2008', '&year=2007', '&year=2006', '&year=2005', '&year=2004', '&year=2003', '&year=2002', '&year=2001', '&year=2000', '&year=1999', '&year=1998', '&year=1997', '&year=1996', '&year=1995', '&year=1994', '&year=1993', '&year=1992', '&year=1991', '&year=1990', '&year=1989', '&year=1988', '&year=1987', '&year=1986', '&year=1985', '&year=1984', '&year=1983', '&year=1982', '&year=1981', '&year=1980', '&year=1979', '&year=1978', '&year=1977', '&year=1976', '&year=1975', '&year=1974', '&year=1973', '&year=1972', '&year=1971', '&year=1970', '&year=1969', '&year=1968', '&year=1967', '&year=1966', '&year=1965', '&year=1964', '&year=1963', '&year=1962', '&year=1961', '&year=1960', '&year=1959', '&year=1958', '&year=1957', '&year=1956', '&year=1955', '&year=1954', '&year=1953', '&year=1952', '&year=1951', '&year=1950', '&year=1949', '&year=1948', '&year=1947', '&year=1946', '&year=1945', '&year=1944', '&year=1943', '&year=1942', '&year=1941', '&year=1940', '&year=1939', '&year=1938', '&year=1937', '&year=1936', '&year=1935', '&year=1934', '&year=1933', '&year=1932', '&year=1931', '&year=1930', '&year=1929', '&year=1928', '&year=1927', '&year=1926', '&year=1925', '&year=1924', '&year=1923', '&year=1922', '&year=1921', '&year=1920', '&year=1919', '&year=1918', '&year=1917', '&year=1916', '&year=1915', '&year=1914', '&year=1913', '&year=1912', '&year=1911', '&year=1910', '&year=1909', '&year=1908', '&year=1907', '&year=1906', '&year=1905', '&year=1904', '&year=1903', '&year=1902']
		label=['Wszystkie','2019', '2018', '2017', '2016', '2015', '2014', '2013', '2012', '2011', '2010', '2009', '2008', '2007', '2006', '2005', '2004', '2003', '2002', '2001', '2000', '1999', '1998', '1997', '1996', '1995', '1994', '1993', '1992', '1991', '1990', '1989', '1988', '1987', '1986', '1985', '1984', '1983', '1982', '1981', '1980', '1979', '1978', '1977', '1976', '1975', '1974', '1973', '1972', '1971', '1970', '1969', '1968', '1967', '1966', '1965', '1964', '1963', '1962', '1961', '1960', '1959', '1958', '1957', '1956', '1955', '1954', '1953', '1952', '1951', '1950', '1949', '1948', '1947', '1946', '1945', '1944', '1943', '1942', '1941', '1940', '1939', '1938', '1937', '1936', '1935', '1934', '1933', '1932', '1931', '1930', '1929', '1928', '1927', '1926', '1925', '1924', '1923', '1922', '1921', '1920', '1919', '1918', '1917', '1916', '1915', '1914', '1913', '1912', '1911', '1910', '1909', '1908', '1907', '1906', '1905', '1904', '1903', '1902']

		msg = 'Rok produkcji'
		sel = xbmcgui.Dialog().select(msg,label)
		if sel>-1:
		
			addon.setSetting(myMode+'V',value[sel])
			addon.setSetting(myMode+'N',label[sel])		
			xbmc.executebuiltin("Container.Refresh") 
		else:
			pass
			
	elif 'playVids' in mode:
		PlayVids(exlink)
