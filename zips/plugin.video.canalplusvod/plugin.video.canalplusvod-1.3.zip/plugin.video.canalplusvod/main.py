﻿# -*- coding: UTF-8 -*-
from __future__ import absolute_import
import sys, re, os

try:
    import http.cookiejar
    import urllib.request, urllib.parse, urllib.error
    from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl
except ImportError:
    import cookielib
    import urllib
    import urlparse
    from urllib import urlencode, quote_plus, quote, unquote
    from urlparse import parse_qsl

import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import xbmcvfs

import json

import inputstreamhelper

import datetime

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.canalplusvod')

PATH            = addon.getAddonInfo('path')
if sys.version_info[0] > 2:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile'))#.decode('utf-8')
else:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile'))
RESOURCES       = PATH+'/resources/'


ikona = RESOURCES+'../icon.png'
FANART=RESOURCES+'../fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('name', None)
page = params.get('page','')

rys= params.get('image', None)

kukz=''

TIMEOUT=15

sess = requests.Session()

def build_url(query):
    try:
        urlencode = urllib.urlencode(query)
    except:
        urlencode = urllib.parse.urlencode(query)

    return base_url + '?' + urlencode

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=1,fanart=FANART,moviescount=0):
    list_item = xbmcgui.ListItem(label=name)

    if IsPlayable:
        list_item.setProperty("IsPlayable", 'True')
    if not infoLabels:
        infoLabels={'title': name,'plot':name}
    list_item.setInfo(type="video", infoLabels=infoLabels)    
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': FANART})
    ok=xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url = build_url({'mode': mode, 'url' : url, 'page' : page, 'moviescount' : moviescount,'movie':movie,'name':name,'image':image}),            
        listitem=list_item,
        isFolder=folder)

    return ok
    
    
    
def setView(typ):
    if addon.getSetting('auto-view') == 'false':
        xbmcplugin.setContent(addon_handle, 'videos')
    else:
        xbmcplugin.setContent(addon_handle, typ)
    
def home():
    CANALvod().logowanie()

    add_item('', '[B][COLOR blue]Kanaly TV[/COLOR][/B]', ikona, "listkanaly", folder=True,IsPlayable=False, infoLabels=False,fanart=FANART)
    add_item('', '[B][COLOR blue]VOD[/COLOR][/B]', ikona, "listvodmenu", folder=True,IsPlayable=False, infoLabels=False,fanart=FANART)

    add_item('', '[B][COLOR khaki]Szukaj[/COLOR][/B]', ikona, "szukaj", folder=True,fanart=FANART)
    add_item('', 'Opcje', ikona, "opcje", folder=False,fanart=FANART)
    if CANALvod().LOGGED == 'true':
        add_item('', '[B][COLOR blue]Wyloguj[/COLOR][/B]', ikona, "logout", folder=False,fanart=FANART)

def ListVodMenu():


    add_item(CANALvod().cinemaURL, '[B][COLOR blue]Filmy[/COLOR][/B]', ikona, "listContent", folder=True,IsPlayable=False, infoLabels=False,fanart=FANART)
    add_item(CANALvod().seriesURL, '[B][COLOR blue]Seriale[/COLOR][/B]', ikona, "listContent", folder=True,IsPlayable=False, infoLabels=False,fanart=FANART)
    add_item(CANALvod().kidsURL, '[B][COLOR blue]Dzieci[/COLOR][/B]', ikona, "listContent", folder=True,IsPlayable=False, infoLabels=False,fanart=FANART)
    
    add_item(CANALvod().funURL, '[B][COLOR blue]Fun & Info[/COLOR][/B]', ikona, "listContent", folder=True,IsPlayable=False, infoLabels=False,fanart=FANART)
   # add_item(CANALvod().documentsURL, '[B][COLOR blue]Dokumenty[/COLOR][/B]', ikona, "listContent", folder=True,IsPlayable=False, infoLabels=False,fanart=FANART)
    #add_item(CANALvod().demandURL, '[B][COLOR blue]Kanały na życzenie[/COLOR][/B]', ikona, "listContent", folder=True,IsPlayable=False, infoLabels=False,fanart=FANART)

    

    
    add_item(CANALvod().documentsURL, '[B][COLOR blue]Dokumenty[/COLOR][/B]', ikona, "listContent", folder=True,IsPlayable=False, infoLabels=False,fanart=FANART)
    add_item(CANALvod().sportURL, '[B][COLOR blue]Sport[/COLOR][/B]', ikona, "listContent", folder=True,IsPlayable=False, infoLabels=False,fanart=FANART)
  #  setView('videos')
    xbmcplugin.endOfDirectory(addon_handle) 
def ListKanaly():
    items  = CANALvod().TVinit()
    if items:
        fold=True
        mud='listContent'
        ispla=False
        for item in items:
            if item['typ'] == 'live':
                fold=False
                mud='playCANvod'
                ispla=True
            add_item(item['url'], item['title'], item['image'], mud, folder=fold, IsPlayable=ispla, infoLabels={'title':item['title'], 'image': item['image'], 'plot':item['plot']},fanart=FANART)

    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%Y")

    xbmcplugin.endOfDirectory(addon_handle) 
def PLAYvodCANAL(urlid):
    url,id_ = urlid.split('|')
    
    headers2 = {

        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
        'Accept': '*/*',

        'Accept-Language': 'en-US,en;q=0.9,pl;q=0.8',
    }
    
    headers = {

        'Accept': 'application/json, text/plain, */*',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
        'Origin': 'https://www.canalplus.com',
        'Accept-Language': 'en-US,en;q=0.9,pl;q=0.8',
    }
    response = requests.get(url, headers=headers, verify=False).text

    str_url = re.findall('src="([^"]+)"',response)[0]
    stream_url = requests.get(str_url, headers=headers2, verify=False).url
    
    stream_url = re.sub('(\?token.+?)$','/manifest',stream_url)
    
    
    
    data = quote('{"ServiceRequest":{"InData":{"EpgId":'+id_+',"LiveToken":"'+ CANALvod().LIVEtoken+'","UserKeyId":"'+CANALvod().DEVICE_ID+'","DeviceKeyId":"'+CANALvod().DEVID+'","ChallengeInfo":"b{SSM}"}}}')

    
    headers3 = {
        'Host': 'secure-webtv.canal-plus.com',
        'Accept': 'application/json, text/plain, */*',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
        'Content-Type': 'application/json;charset=UTF-8',
        'Origin': 'https://www.canalplus.com',
        'Sec-Fetch-Site': 'cross-site',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',

        'Accept-Language': 'en-US,en;q=0.9,pl;q=0.8',
    }
    LICKEY = "https://secure-webtv.canal-plus.com/WebPortal/ottlivetv/api/V4/zones/cppol/devices/31/apps/1/jobs/GetLicence|"+urlencode(headers3)+"|"+data+"|JBLicenseInfo"#%(urlencode(headers3),data)
    PROTOCOL = 'ism'
    DRM = 'com.widevine.alpha'
    is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)#
        play_item.setMimeType('application/x-ms-manifest')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.license_type', DRM)
        play_item.setProperty('inputstream.adaptive.license_key',LICKEY)   

        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)    
    

def PLAYvod2(urlid):
    HAPI_BASE_URL = 'https://secure-gen-hapi.canal-plus.com'
    
    
    
    HAPI_BASE_URL2 = 'https://secure-mycanal-player-pc-ws3.canal-plus.com'

    URL_VIDEO_DATAS = 'https://secure-gen-hapi.canal-plus.com/conso/playset/unit/%s'
    
    URL_STREAM_DATAS = 'https://secure-gen-hapi.canal-plus.com/conso/view'
    
    URL_DEVICE_ID = 'https://pass.canal-plus.com/service/HelloJSON.php'
    header_device_id = {
        'referer':
        'https://secure-player.canal-plus.com/one/prod/v2/',
    }
    resp_device_id = sess.get(URL_DEVICE_ID, headers=header_device_id, verify=False)
    device_id = re.compile(
        r'deviceId\"\:\"(.*?)\"').findall(resp_device_id.text)[0]

    video_id = urlid.split('|')[-1]
    pass_token = quote(CANALvod().PASStoken)
    headers = {
        'Accept':
        'application/json, text/plain, */*',
        'Authorization':
        'PASS Token="%s"' % pass_token,
        'Content-Type':
        'application/json; charset=UTF-8',
        'XX-DEVICE':
        'pc %s' % device_id,
        #'pc 1591192622564-fda238f6746e',# % device_id,
        'XX-DOMAIN':
        'cppol',
        'XX-OPERATOR':
        'pc',
        'XX-Profile-Id':
        '0',
        'XX-SERVICE':
        'mycanal',
        'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36'
    }
    
    
    
    ###z chrome

    value_datas_json = sess.get(URL_VIDEO_DATAS % video_id, headers=headers,verify=False)
    a= value_datas_json.text

    value_datas_jsonparser = json.loads(value_datas_json.text)

    comMode_value = ''
    contentId_value = ''
    distMode_value = ''
    distTechnology_value = ''
    drmType_value = ''
    functionalType_value = ''
    hash_value = ''
    idKey_value = ''
    quality_value = ''

    for stream_datas in value_datas_jsonparser["available"]:
        if 'DRM_COMMON_ENCRYPTION' in stream_datas["drmType"]:
            comMode_value = stream_datas['comMode']
            contentId_value = stream_datas['contentId']
            distMode_value = stream_datas['distMode']
            distTechnology_value = stream_datas['distTechnology']
            drmType_value = stream_datas['drmType']
            functionalType_value = stream_datas['functionalType']
            hash_value = stream_datas['hash']
            idKey_value = stream_datas['idKey']
            quality_value = stream_datas['quality']
    
    payload = {
        'comMode': comMode_value,
        'contentId': contentId_value,
        'distMode': distMode_value,
        'distTechnology': distTechnology_value,
        'drmType': drmType_value,
        'functionalType': functionalType_value,
        'hash': hash_value,
        'idKey': idKey_value,
        'quality': quality_value
    }
    payload = json.dumps(payload)

    resp_stream_datas = sess.put(
        URL_STREAM_DATAS, data=payload, headers=headers)
    jsonparser_stream_datas = json.loads(resp_stream_datas.text)
    
    resp_real_stream_datas = sess.get(
        HAPI_BASE_URL+jsonparser_stream_datas['@medias'], headers=headers)
    jsonparser_real_stream_datas = json.loads(
        resp_real_stream_datas.text)

    
    stream_urls = jsonparser_real_stream_datas[0]['files']
    for st_url in stream_urls:
        if '.ism' in st_url["distribURL"]:
            stream_url = st_url["distribURL"] + '/manifest'
        else:
            continue

    value_pass_token = 'PASS Token="%s"' % quote(pass_token)

    headers2 = {
        'Accept':
        quote('application/json, text/plain, */*'),
        'Authorization':
        value_pass_token,
        'Content-Type':
        'text/plain',
        'User-Agent': quote('Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36'),
        'XX-DEVICE':
        'pc %s' % device_id,
        'XX-DOMAIN':
        'cppol',
        'XX-OPERATOR':
        'pc',
        'XX-Profile-Id':
        '0',
        'XX-SERVICE':
        'mycanal',
    }

    PROTOCOL = 'ism'
    DRM = 'com.widevine.alpha'
    is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
    PROXY_PATH='http://127.0.0.1:50153/license='
    ab= HAPI_BASE_URL+jsonparser_stream_datas['@licence']+ '?drmType=DRM_WIDEVINE' 
    set_setting('hea', str(headers2))
    set_setting('licurl', str(ab))
    url = PROXY_PATH + ab
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)#

        play_item.setContentLookup(False)
        play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.license_type', DRM)
        
        
        play_item.setProperty('inputstream.adaptive.license_key',url + '|%s|b{SSM}|B' % urlencode(headers2) )

    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    

def getInfoLabel(item):
    out={}
    out['plot'] = item['plot'] if item['plot'] else item['title']
    out['title'] = item['title']

    return out
    
def ListContent(url):
    #xbmc.log('@#@responseurl: %s'%(str(url)), xbmc.LOGNOTICE)
    items  = CANALvod().getContent(url)
    if items:

        for item in items:
            inflabel = getInfoLabel(item)
            #xbmc.log('@#@item: %s'%(str(item)), xbmc.LOGNOTICE)
            if item['typ'] == 'VoD':
                fold=False
                mud='playCANvod2'
                ispla=True
            else:
                fold=True
                mud='listContent'
                ispla=False
            img1 =     item['image'] if item['image'] else ikona
            if not 'objectType=person' in item['url']:
                add_item(item['url'], item['title'], img1, mud, folder=fold, IsPlayable=ispla, infoLabels=inflabel,fanart=FANART)
        if mud != 'listContent':
            setView('movies')

    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%Y")

    xbmcplugin.endOfDirectory(addon_handle) 


def get_addon():
    return addon

def set_setting(key, value):
    return get_addon().setSetting(key, value)
    
def get_setting(key):
    return get_addon().getSetting(key)
    
def dialog_progress():
    return xbmcgui.DialogProgress()
    
def xbmc_sleep(time):
    return xbmc.sleep(time)

def getRequests(url, data="", headers={}, params ={}, allo=None):
    if data:
        if allo:
            content=sess.get(url,headers=headers, data=data, params=params, verify=False).url
        else:
            content=sess.post(url,headers=headers,data=data, params=params, verify=False)#.json()
            try:
                content=content.json()
            except:
                content=content.text
    else:
        if allo:
            content=sess.get(url,headers=headers, params=params, verify=False).url
        else:
            content=sess.get(url,headers=headers, params=params, verify=False)
            try:
                content=content.json()
            except:
                content=content.text
    return content

def PLchar(char):
    if type(char) is not str:
        char=char.encode('utf-8')
    char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
    char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
    char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
    char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
    char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
    char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
    char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
    char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
    char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
    char = char.replace('&#8217;',"'")
    char = char.replace('&#8211;',"-")  
    char = char.replace('&#8230;',"...")    
    char = char.replace('&#8222;','"').replace('&#8221;','"')   
    char = char.replace('[&hellip;]',"...")
    char = char.replace('&#038;',"&")   
    char = char.replace('&#039;',"'")
    char = char.replace('&quot;','"')
    char = char.replace('&nbsp;',".").replace('&amp;','&')
    return char 

class CANALvod(object):

    def __init__(self):
              
        self.OAUTH = 'https://dev.canalplus.com/pl/oauth'
        self.CREATE_TOKEN = 'https://pass-api-v2.canal-plus.com/provider/services/PL/public/createToken'
        self.mainLOGINurl = 'https://logowanie.pl.canalplus.com/login'
        self.OAUTH_HEADERS = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
                'Host': 'dev.canalplus.com',}

    
        self.HEADERS2 = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
                'Host': 'logowanie.pl.canalplus.com',}

        self.HEADERS3 = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
                'Host': 'www.canalplus.com',}
                
                
        self.HEADERS4 = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
                'Host': 'pass.canal-plus.com',}    

        self.PASSheaders = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
            'Host': 'pass-api-v2.canal-plus.com',
        }
            
            
        self.HODORheaders = {
            'Host': 'hodor.canalplus.pro',
            'user-agent': 'myCANAL/ 4.6.6 (440010924) - Android/9 - android - SM-J330F',
        }

            
        self.cinemaURL = "https://hodor.canalplus.pro/api/v2/mycanalint/page/{}/102783.json"
        self.seriesURL = "https://hodor.canalplus.pro/api/v2/mycanalint/page/{}/102782.json"
        self.kidsURL = "https://hodor.canalplus.pro/api/v2/mycanalint/page/{}/102826.json"
        self.funURL = "https://hodor.canalplus.pro/api/v2/mycanalint/page/{}/102965.json"
        self.demandURL = "https://hodor.canalplus.pro/api/v2/mycanalint/page/{}/102961.json" 
            
        self.searchURL = 'https://hodor.canalplus.pro/api/v2/mycanalint/search/mycanal_channel_discover/{}/query/{}?distmodes=[%22catchup%22,%22svod%22,%22tvod%22]&displayNBOLogo=true'    
            
            
            
        self.documentsURL = "https://hodor.canalplus.pro/api/v2/mycanalint/page/{}/102964.json"
        self.sportURL = "https://hodor.canalplus.pro/api/v2/mycanalint/page/{}/102957.json"
            

        self.CMStoken = get_setting('CMStoken')
            
        self.clientid = get_setting('clientid')
        self.portailId = get_setting('portailId')
        
        self.PASStoken = get_setting('PASStoken')
        self.PASSid = get_setting('PASSid')

        self.MACROel = get_setting('MACROel')
        self.MICROel = get_setting('MICROel')
        self.EPGid = get_setting('EPGid')

        self.LIVEtoken = addon.getSetting('livetoken')
        self.DEVID = addon.getSetting('devid')
            
            
        self.DEVICE_ID = addon.getSetting('device_id')
        self.CLIENT_ID = addon.getSetting('client_id')
        self.ID_ = addon.getSetting('id_')
        
        self.LOGIN = addon.getSetting('username')
        self.PASSWORD = addon.getSetting('password')
        self.LOGUJ = addon.getSetting('logowanie')

        self.LOGGED = addon.getSetting('logged')

        self.settingsFix()

    def settingsFix(self):
        from os import sep as osSeparator
        
        try:
            if sys.version_info[0] < 3:
                copy = xbmcaddon.Addon().getAddonInfo('path') + osSeparator + 'resources' + osSeparator + 'format' + osSeparator + 'settings_py2.xml'
                dest = xbmcaddon.Addon().getAddonInfo('path') + osSeparator + 'resources' + osSeparator + 'settings.xml'

                stat = os.stat(dest)
                size = stat.st_size
                
                if size > int(1000):
                    success = xbmcvfs.copy(copy, dest)

            else:
                copy = xbmcaddon.Addon().getAddonInfo('path') + osSeparator + 'resources' + osSeparator + 'format' + osSeparator + 'settings_py3.xml'
                dest = xbmcaddon.Addon().getAddonInfo('path') + osSeparator + 'resources' + osSeparator + 'settings.xml'

                stat = os.stat(dest)
                size = stat.st_size

                if size < int(1754):
                    success = xbmcvfs.copy(copy, dest)
        except Exception as ex:
            xbmc.log('No need to change settings.xml')

    def logowanie(self):
        a = self.PASStoken
        v = self.PASSid
        
        c = self.MACROel
        d = self.MICROel
        e = self.EPGid

        if self.LOGGED == 'true':
            if not self.PASStoken or not self.PASSid:
                if self.LOGIN and self.PASSWORD and self.LOGUJ == 'true':
                

                    response = sess.get(self.OAUTH, headers=self.OAUTH_HEADERS, verify=False)

                    response = sess.get(response.url, headers=self.HEADERS3, verify=False)

                    response = sess.get(response.url, headers=self.HEADERS4, verify=False)

                    response = sess.get(response.url, headers=self.HEADERS4, verify=False)

                    response = sess.get(response.url, headers=self.HEADERS4, verify=False)

                    headers = {
                        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; SM-J330F Build/PPR1.180610.011)',
                        'Host': 'logowanie.pl.canalplus.com',
                    }
                    response = sess.get(response.url, headers=self.HEADERS2, verify=False)

                    execution = re.findall('execution" value="([^"]+)',response.text)#[0]
                    if execution:
                        execution = execution[0]
                        headers = {
                            'Host': 'logowanie.pl.canalplus.com',
                            'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
                            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                            'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
                            'content-type': 'application/x-www-form-urlencoded',
                            'origin': 'https://logowanie.pl.canalplus.com',
                            'referer': response.url,
                            'upgrade-insecure-requests': '1',
                            'te': 'trailers',
                        }
                        
                        data = 'username='+self.LOGIN+'&password='+self.PASSWORD+'&execution='+execution+'&_eventId=submit&geolocation='
                        
                        response = sess.post(self.mainLOGINurl, headers=headers, data=data, verify=False)
                        
                        adres = unquote(response.url)
                        clientid = re.findall('client_id=(.+?)\&',adres)
                        portailId = re.findall('portailId=(.+?)\&',adres)
                        if clientid and portailId:
                            set_setting('clientid', clientid[0])
                            set_setting('portailId', portailId[0])
                        
                        response = sess.get(response.url, headers=sess.headers, verify=False)
                        
                        response = sess.get(response.url, headers=sess.headers, verify=False)
                        
                        response = sess.get(response.url, headers=sess.headers, verify=False)
                        
                        response = response.text
                        
                        authresponse = re.findall('setAuthResponse\((.+?)\)\;\<\/script',response)#[0]
                        response = json.loads(authresponse[0])
                        
                        self.PASSid=response["response"]["passId"]
                        self.PASStoken=response["response"]["passToken"]
                        data = response["response"]["userData"]
                        self.MACROel=data["macroEligibility"]
                        self.MICROel = data["microEligibility"]
                        self.EPGid = data["epgid_OTT"]
                        set_setting('PASSid', self.PASSid)
                        set_setting('PASStoken', self.PASStoken)
                        set_setting('MACROel', self.MACROel)
                        set_setting('MICROel', self.MICROel)
                        set_setting('EPGid', self.EPGid)
                        
                        
                        
                        params = (
                            ('appLocation', 'PL'),
                            ('offerZone', 'cppol'),
                            ('isActivated', '1'),
                            ('collectUserData', '1'),
                            ('pdsNormal', '['+self.EPGid+']'),
                            ('macros', self.MACROel),
                            ('micros', self.MICROel),
                            ('isAuthenticated', '1'),
                            ('paired', '0'),
                        )
                        response = getRequests('https://hodor.canalplus.pro/api/v2/mycanalint/authenticate.json/android/4.1', headers=self.HODORheaders, params=params)
                        self.CMStoken = response['token']
                        set_setting('CMStoken', self.CMStoken)
                        
                        URL_DEVICE_ID = 'https://pass.canal-plus.com/service/HelloJSON.php'
                        
                        header_device_id = {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
                            'referer':'https://secure-player.canal-plus.com/one/prod/v2/',
                            'Cookie': 's_pass_token='+self.PASStoken
                        }
                        resp_device_id = sess.get(URL_DEVICE_ID, headers=header_device_id, verify=False)
                        
                        self.DEVICE_ID = re.compile(
                                    r'deviceId\"\:\"(.*?)\"').findall(resp_device_id.text)[0]
                        set_setting('device_id', self.DEVICE_ID)
                        
                        
                        
                        LOGGED = 'true'
                        set_setting('logged', LOGGED)
                        xbmcgui.Dialog().notification('[B]Ok.[/B]', 'Zalogowano poprawnie.',ikona, 8000,False)
                    else:
                        set_setting('PASSid', self.PASSid)
                        set_setting('PASStoken', self.PASStoken)
                        xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Niepoprawne dane logowania',ikona, 8000,False)
                        add_item('', '[B][COLOR blue]Zaloguj[/COLOR][/B]', ikona, "login", folder=False,fanart=FANART)
                else:
                    xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Brak danych logowania.',ikona, 8000,False)
            else:
                try:
                    self.RefreshPassToken()
                    xbmcgui.Dialog().notification('[B]Ok.[/B]', 'Zalogowano poprawnie.',ikona, 8000,False)
                except:
                    set_setting('logged', 'false')
                    set_setting('PASSid', self.PASSid)
                    set_setting('PASStoken', self.PASStoken)
                    xbmcgui.Dialog().notification('[B]Błąd[/B]', 'Nie udało się zalogować',ikona, 8000,False)
                    add_item('', '[B][COLOR blue]Zaloguj[/COLOR][/B]', ikona, "login", folder=False,fanart=FANART)
        elif self.LOGGED != 'true':
            add_item('', '[B][COLOR blue]Zaloguj[/COLOR][/B]', ikona, "login", folder=False,fanart=FANART)
        return True

    def gen_hex_code(self, myrange=6):
        import random
        return ''.join([random.choice('0123456789abcdef') for x in range(myrange)])
        
        
    def czs(self, czas, trwa):
    
        import time
        import datetime
        try:
            format_date=datetime.datetime.strptime(czas, '%Y-%m-%dT%H:%M:%S.%fZ')
        except TypeError:
            format_date=datetime.datetime(*(time.strptime(czas, '%Y-%m-%dT%H:%M:%S.%fZ')[0:6]))
        format_date = format_date+ datetime.timedelta(hours=2)
        tstampnow= int('{:0}'.format(int(time.mktime(format_date.timetuple()))))
        durat = tstampnow+(int(trwa)/1000)
        dt_object = datetime.datetime.fromtimestamp(durat)
        pocz = format_date.strftime("%H:%M")
        koniec =  dt_object.strftime("%H:%M")
        return pocz,koniec
        
    def getch(self, ch):
        out={}
        fff=''
        for event_ in ch['events']:
            starttime = event_["timecodes"][0]["start"]
            duration = event_["timecodes"][0]["duration"] 
            pocz, koniec =self.czs(starttime, duration)
            fff+='%s - %s %s [CR]'%(pocz,koniec,PLchar(event_["title"]))
            out['title']=fff
        return out
        
    def epgLive(self):
        headers = {
            'Host': 'secure-webtv-static.canal-plus.com',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        }
        
        out={}
        epgresponse = requests.get('https://secure-webtv-static.canal-plus.com/metadata/cppol/all/v2.2/globalchannels.json',headers=headers,verify=False).json()
        for channel in epgresponse['channels']:
            id_ = str(channel['id'])
            out[id_]=self.getch(channel)  
        return out    

    def TVinit(self):
    
        headers = {
            'User-Agent': 'myCANAL/4.6.6(440010924) - Android/9 - android - SM-J330F',
            'Content-Type': 'application/json; charset=utf-8',
            'Host': 'secure-mobiletv.canal-plus.com',
        }
        import time
        ts = int(time.time())*100
        a = str(ts)
        if not self.DEVID:
            self.DEVID = '%s-%s'%( a, self.gen_hex_code(12))
            set_setting('devid', self.DEVID)

        data ={"ServiceRequest":{"InData":{"PassData":{"Id":0,"Token":self.PASStoken},"UserKeyId":self.DEVICE_ID,"DeviceKeyId":self.DEVID,"PDSData":{"GroupTypes":"1;4"}}}}

        epgs = self.epgLive()

        response = sess.post('https://secure-mobiletv.canal-plus.com/WebPortal/ottlivetv/api/V4/zones/cppol/devices/71/apps/1/jobs/InitLiveTV', headers=headers, json=data,verify=False).json()

        outdata = response["ServiceResponse"]["OutData"]
        self.LIVEtoken = outdata["LiveToken"]
        set_setting('livetoken', self.LIVEtoken)
        grupy = outdata["PDS"]["ChannelsGroups"]["ChannelsGroup"]
        out=[]
        for grupa in grupy:
            channels = grupa["Channels"]
            for channel in channels:
                epgid_ = channel["EpgId"]
                try:
                    plot = epgs[str(epgid_)]['title']
                except:
                    plot = ''

                tytul_ = channel["Name"]
                urllogo_ = channel["LogoUrl"]

                urlpage_ = channel["WSXUrl"]
                urlpage_= urlpage_+'|'+ epgid_
                out.append({"title": PLchar(tytul_), "url": urlpage_,'image':urllogo_, "code": '', "plot": plot,'typ':'live'})
        return out    

        
    def RefreshPassToken(self):
        headers = {
            'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; SM-J330F Build/PPR1.180610.011)',
            'Host': 'pass-api-v2.canal-plus.com',
        }
        
        data = {
        'analytics': 'true',
        'noCache': 'false',
        'distributorId': 'C22021',
        'passId': self.PASSid,
        'vect': 'Internet',
        'media': 'Android Phone',
        'trackingPub': 'true',
        'portailId': self.portailId
        }

        response = sess.post(self.CREATE_TOKEN, headers=self.PASSheaders, data=data, verify=False).json()
       # xbmc.log('@#@response2x: %s'%(str(response)), xbmc.LOGNOTICE)
        self.PASSid=response["response"]["passId"]
        self.PASStoken=response["response"]["passToken"]

        set_setting('PASSid', self.PASSid)
        set_setting('PASStoken', self.PASStoken)
        
        params = (
            ('appLocation', 'PL'),
            ('offerZone', 'cppol'),
            ('isActivated', '1'),
            ('collectUserData', '1'),
            ('pdsNormal', '['+self.EPGid+']'),
            ('macros', self.MACROel),
            ('micros', self.MICROel),
            ('isAuthenticated', '1'),
            ('paired', '0'),
        )
        response = getRequests('https://hodor.canalplus.pro/api/v2/mycanalint/authenticate.json/android/4.1', headers=self.HODORheaders, params=params)
        #xbmc.log('@#@response: %s'%(str(response)), xbmc.LOGNOTICE)
        self.CMStoken = response['token']
        set_setting('CMStoken', self.CMStoken)

        return

    def getContent(self,url):

        out =[]

        typ2=''

        if '|' in url:
            url,typ2 = url.split('|')
        if '/query/' in url:
            response = getRequests(url, headers=self.HODORheaders)
        else:
            response = getRequests(url.format(self.CMStoken), headers=self.HODORheaders)
        
        #xbmc.log('@#@response: %s'%(str(response)), xbmc.LOGNOTICE)
        if 'strates' in response:

            strates = response['strates']

            try:
                boa = response['currentPage']['BOName']
            except:
                boa = ''
            for strate in strates:

                if 'title' in strate or boa=='Channels':
                    
                    if strate['strateMode'] =='standard':
                    
                        if not typ2:

                            if boa=='Channels':
                                tytul_='    Na zyczenie'
                            else:
                                tytul_ = strate['title']
                            if 'button' in strate:
                                urlpage_ = strate['button']['onClick']['URLPage']
                                typ = 'cdn'
                                urlpage_ = urlpage_+'|'+ typ
                            else:
                                typ = strate['context']['contextDetail']
                                urlpage_ = url+'|'+ typ

                            out.append({"title": PLchar(tytul_), "url": urlpage_,'image':'', "code": '', "plot": '','typ':typ})
                        else:
                            
                            if strate['context']['contextDetail'] == typ2 or typ2=='cdn':

                                contents = strate['contents']

                                for content in contents:
                                    
                                    try:
                                        tytul_ = content['title']    
                                    except:
                                        tytul_ = content['onClick']['BOName']

                                    contentID = content['contentID']

                                    try:
                                        urllogo_ = content['URLImage']
                                    except:
                                        urllogo_ = content['URLLogoChannel']

                                    urllogo_ = urllogo_.replace('{imageQualityPercentage}','70')
                                    urlpage_ = content['onClick']['URLPage']
                                    typ = content['type']
                                    urlpage_ = urlpage_+'|'+ contentID
                                    if 'subtitle' in content:
                                        tytul_+=' [COLOR lightgreen]%s[/COLOR]'%(content['subtitle'])
                                   # xbmc.log('@#@content: %s'%(str(PLchar(tytul_))), xbmc.LOGNOTICE)
                                    out.append({"title": PLchar(tytul_), "url": urlpage_,'image':urllogo_, "code": '', "plot": '','typ':typ})

                            elif strate['context']['contextType']=='edito': 
                                if typ2=='24376' or typ2=='70025' or typ2== '70028' or typ2=='70027' : #105007.json' in url or '104796.json' in url or '105158.json' in url or '105162.json':
                                    contents = strate['contents']
                                    for content in contents:
                                       # xbmc.log('@#@contentcaly: %s'%(str(content)), xbmc.LOGNOTICE)
                                        try:
                                            tytul_ = content['title']    
                                        except:
                                            tytul_ = content['onClick']['BOName']
                                    
                                        contentID = content['contentID']
                                      #  xbmc.log('@#@contentID: %s'%(str(contentID)), xbmc.LOGNOTICE)
                                        try:
                                            urllogo_ = content['URLImage']
                                        except:
                                            urllogo_ = content['URLLogoChannel']
                                    
                                        urllogo_ = urllogo_.replace('{imageQualityPercentage}','70')
                                        urlpage_ = content['onClick']['URLPage']
                                        typ = content['type']
                                        urlpage_ = urlpage_+'|'+ typ
                                        if 'subtitle' in content:
                                            tytul_+=' [COLOR lightgreen]%s[/COLOR]'%(content['subtitle'])
                                        #xbmc.log('@#@content2: %s'%(str(PLchar(tytul_))), xbmc.LOGNOTICE)
                                        out.append({"title": PLchar(tytul_), "url": urlpage_,'image':urllogo_, "code": '', "plot": '','typ':typ})
                            else:
                                continue

                    else:
                        continue

        elif 'currentPage' in response:
            if 'contents' in response:
                contents = response['contents']
                for content in contents:
                    tytul_ = content['title']    
                    contentID = content['contentID']
                    try:
                        urllogo_ = content['URLImage']
                    except:
                        urllogo_ = content['URLLogoChannel']

                    urllogo_ = urllogo_.replace('{imageQualityPercentage}','70')
                    urlpage_ = content['onClick']['URLPage']
                    typ = content['type']
                    urlpage_ = urlpage_+'|'+ contentID
                    if 'subtitle' in content:
                        if 'Odcinek' in content['subtitle']:
                            tytul_+=' [COLOR lightgreen]%s[/COLOR]'%(content['subtitle'])
                   # xbmc.log('@#@content3: %s'%(str(PLchar(tytul_))), xbmc.LOGNOTICE)
                    out.append({"title": PLchar(tytul_), "url": urlpage_,'image':urllogo_, "code": '', "plot": '','typ':typ})
            elif 'detail' in response and not 'episodes' in response:
                detail = response['detail']
                information = detail['informations']
                if 'seasons' in detail:
                    seasons = detail['seasons']

                    for sezon in seasons:
                      #  xbmc.log('@#@dalej2: ', xbmc.LOGNOTICE)
                        try:
                            tytul_ = sezon['title']    
                        except:
                            tytul_ = sezon['onClick']['displayName']    
                        contentID = sezon['contentID']
                        try:
                            urllogo_ = information['URLImage']
                        except:
                            urllogo_ = information['URLLogoChannel']
                        try:
                            plot = information['summary']
                        except:
                            plot=''

                        urllogo_ = urllogo_.replace('{imageQualityPercentage}','70')
                        urlpage_ = sezon['onClick']['URLPage']
                        try:
                            typ = sezon['type']
                        except:
                            typ=''
                        urlpage_ = urlpage_+'|'+ contentID
                        #xbmc.log('@#@content4: %s'%(str(PLchar(tytul_))), xbmc.LOGNOTICE)
                        out.append({"title": PLchar(tytul_), "url": urlpage_,'image':urllogo_, "code": '', "plot": plot,'typ':typ})
            elif 'episodes' in response:
                detail = response['detail']
                information = detail['informations']
                contents = response['episodes']['contents']
                for content in contents:
                    #xbmc.log('@#@dalej3: ', xbmc.LOGNOTICE)
                    tytul_ = content['title']    
                    contentID = content['contentID']
                    try:
                        urllogo_ = content['URLImage']
                    except:
                        urllogo_ = content['URLLogoChannel']
                    try:
                        plot = content['summary']
                    except:
                        plot=''
                    try:
                        maintitle = information['title']
                    except:
                        maintitle=''

                    urllogo_ = urllogo_.replace('{imageQualityPercentage}','70')
                    urlpage_ = content['URLPage']
                    try:
                        typ = content['type']
                    except:
                        typ = 'VoD'
                    urlpage_ = urlpage_+'|'+ contentID
                    tytul_='%s - [COLOR lightgreen]%s[/COLOR]'%(maintitle,tytul_)
                    #xbmc.log('@#@content5: %s'%(str(PLchar(tytul_))), xbmc.LOGNOTICE)
                    out.append({"title": PLchar(tytul_), "url": urlpage_,'image':urllogo_, "code": '', "plot": plot,'typ':typ})

        return out    
  
if __name__ == '__main__':

    mode = params.get('mode', None)

    if not mode:
        
        home()
        xbmcplugin.endOfDirectory(addon_handle)     

    elif mode=='search':
        if CANALvod().LOGGED == 'true':
            query = xbmcgui.Dialog().input(u'Szukaj..., Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
            if query:   
                PLAYERPL().ListSearch(query.replace(' ','+'))
            else:
                pass
        else:
            xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Nie jesteś zalogowany.',xbmcgui.NOTIFICATION_INFO, 6000,False)

    elif mode=='login':
        set_setting('logged', 'true')
        addon.openSettings()
        xbmc.executebuiltin('Container.Refresh') 

        
    elif mode=='logout':

        yes = xbmcgui.Dialog().yesno("[COLOR orange]Uwaga[/COLOR]", 'Czy na pewno chcesz się wylogować?',yeslabel='TAK', nolabel='NIE')
        if yes:
            set_setting('sesstoken', '')
            set_setting('sessexpir', '')
            set_setting('sessexpir', '')
            set_setting('logged', 'false')
            CANALvod().LOGGED = addon.getSetting('logged')
            
            CANALvod().SESSTOKEN = addon.getSetting('sesstoken')
            CANALvod().SESSEXPIR = addon.getSetting('sessexpir')
            CANALvod().SESSKEY= addon.getSetting('sesskey')
            
            set_setting('device_id', '')
            set_setting('client_id', '')
            set_setting('id_', '')     
            set_setting('PASStoken', '')   
            set_setting('PASSid', '')   
        
            xbmc.executebuiltin('Container.Refresh') 
    
    elif mode == 'listContent':
        #xbmc.log('@#@exlink : %s'%(str(PLchar(exlink))), xbmc.LOGNOTICE)
        ListContent(exlink)
            
    elif mode == 'szukaj':
        if CANALvod().LOGGED == 'true':
            query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł...', type=xbmcgui.INPUT_ALPHANUM)
            if query:   
                query=quote(query)
                urlquery = (CANALvod().searchURL).format(CANALvod().CMStoken,query)
                ListContent( urlquery)
        else:
            xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Nie jesteś zalogowany.',xbmcgui.NOTIFICATION_INFO, 6000,False)
    elif mode == 'opcje':
        addon.openSettings()   

    elif mode == 'listkanaly':
        ListKanaly()
        
    elif mode =='playCANvod':
        PLAYvodCANAL(exlink)
        
    elif mode =='listvodmenu':
        ListVodMenu()
        
    elif mode =='playCANvod2':
        PLAYvod2(exlink)
        