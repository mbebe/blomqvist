# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import base64
import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import resolveurl as urlresolver

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.filmlink')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'fanart.png'
sys.path.append( os.path.join( RESOURCES, "lib" ) )
import cdapl
exlink = params.get('url', None)
name= params.get('title', None)
page = params.get('page',[1])[0]
kukz=''

sortv = addon.getSetting('sortV')
sortn = addon.getSetting('sortN') if sortv else 'Wszystkie'

UA= 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
TIMEOUT=15

headers = {'User-Agent': UA,}
s = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=1,fanart=FANART):
	list_item = xbmcgui.ListItem(label=name)

	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')
		
	if not infoLabels:
		infoLabels={'title': name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': fanart})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page,'laravel_session':kukz}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	
def getCookies():
	global kukz
	kukz = params.get('laravel_session', None)
	mainurl='http://filmlink.pl/'
	html=s.get(mainurl,verify=False,headers=headers).text
	kukz=re.findall('page_access=(.+?);',html)[0]
	return kukz
	
def home():
	getCookies()
	add_item('', "[COLOR lightblue]Sortowanie:[/COLOR] [B]"+sortn+"[/B]", None, False, "filtr:sort")	
	add_item('http://filmlink.pl/filmy-online/', '[B][COLOR khaki]Filmy[/COLOR][/B]', RESOURCES+'Filmy.png', True, "listmovies",fanart=RESOURCES+'fanart.png')	
	add_item('kategorie:', '    kategorie', RESOURCES+'Filmy.png', True, "gatunek")	
	add_item('ostatnio', '    ostatnio dodane', RESOURCES+'Filmy.png', True, "listfilmy")
	add_item('ogladane', '    najczęściej oglądane', RESOURCES+'Filmy.png', True, "listfilmy")
	add_item('http://filmlink.pl/seriale-online/', '[B][COLOR khaki]Seriale[/COLOR][/B] (alfabetycznie)', RESOURCES+'Seriale.png', True, "listseralf")
	add_item('najlepsze', '    najlepsze seriale', RESOURCES+'Seriale.png', True, "listseriale")	
	add_item('najnowsze', '    najnowsze seriale', RESOURCES+'Seriale.png', True, "listseriale")	
	add_item('odcinki', '    ostatnio dodane ocinki', RESOURCES+'Seriale.png', True, "listseriale")		
	add_item('', '[B][COLOR khaki]Dla dzieci[/COLOR][/B]', RESOURCES+'dzieci.png', True, "bajki")		
	add_item('', '[COLOR lightblue]Szukaj[/COLOR]', RESOURCES+'szukaj.png', True, "search")		

def ListBajki():
	add_item('http://filmlink.pl/kategoria/12+familijny/', 'Filmy dla dzieci',  RESOURCES+'dzieci.png', True, "listmovies")	
	add_item('http://filmlink.pl/kategoria/2+animacja/', 'Bajki dla dzieci', '', True, "listmovies")		

def ListFilmy(exlink):
	filmy=getFilmy(exlink)
	itemz=filmy
	items = len(filmy)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)		
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)	

def getFilmy(typ):
	out=[]
	url='http://filmlink.pl/'
	html=getUrlReq(url)
	if 'ostatnio' in typ:
		k=0
	elif 'ogladane' in typ:
		k=1
	result=parseDOM(html,'div', attrs={'class': "half"})[k] 
	links=parseDOM(result,'div', attrs={'class': "list-movie"})
	for link in links:
		imag = parseDOM(link, 'img', ret='src')[0]
		href = parseDOM(link, 'a', ret='href')[0]	
		title = parseDOM(link, 'a')[1]
		plot = parseDOM(link,'div', attrs={'class': "list-movie-description"})[0] #<div class="list-movie-description">
		ftitle=PLchar(title)
		out.append({'title':ftitle,'href':href,'img':imag,'plot':PLchar(plot)})

	return out	

def ListMovies(exlink,sortuj,page):
	page = int(page) if page else 1	
	links,serials, pagin = getMovies(exlink,sortuj,page)
	if pagin[0]:
		add_item(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[0])	
	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
	itemz=serials
	items = len(serials)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listepisodes', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)		
	if pagin[1]:
		add_item(name='[COLOR blue]>> Nastepna strona >>>[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[1])
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)
	
def getMovies(url,typs,page=1):	
	url = url + '%d/' %page +typs
	html=getUrlReq(url)
	out=[]
	serout=[]
	try:
		prevpage=False #gr=False
		nextpage=False  # pr=False	
		
		if html.find(u'<a title="Następna strona"')>0:
			nextpage = page+1	

		result=parseDOM(html,'div', attrs={'id': "movie-list"})[0] 
		links = parseDOM(result, 'div', attrs={'class': "movie"})
		for link in links:		
			title = parseDOM(link, 'a')[0]
			href = parseDOM(link, 'a', ret='href')[0]			
			imag = parseDOM(link, 'img', ret='src')[0]
			genre = parseDOM(link, 'a')[2]
			try:
				plot = parseDOM(link, 'div', attrs={'class': "movie-description"})[0] #<div class="movie-description">
			except:
				plot=''
			ftitle=PLchar(title)
			out.append({'title':ftitle,'href':href,'img':imag,'plot':PLchar(plot), 'genre':genre})
	except:
		pass
	prevpage = page-1 if page>1 else False
	return (out,serout,(prevpage,nextpage))

def ListSerialsAlf(litera,html):
	regex='<a href="(http://filmlink.pl/serial.+?)">('+litera+'.+?)<'
	links=re.findall(regex,html,re.DOTALL)
	items = len(links)
	for href,title in links:
		if title.startswith(litera+':'):
			continue
		add_item(name=PLchar(title), url=href, mode='listepisodes', image='', folder=True, infoLabels='', itemcount=items)	
	xbmcplugin.setContent(addon_handle, 'tvshows')	
	xbmcplugin.endOfDirectory(addon_handle)		

def ListEpisodes(exlink,page):
	page = int(page) if page else 1	
	episodes = getEpisodes(exlink,page)	
	itemz=episodes
	items = len(episodes)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)			
	xbmcplugin.setContent(addon_handle, 'tvshows')	
	xbmcplugin.endOfDirectory(addon_handle)	
	
def getUrlReq(url):
	global kukz
	kukz = params.get('laravel_session', None)
	cooki = {'page_access': kukz,}	
	content=s.get(url, headers=headers,verify=False,cookies=cooki).text	
	return content.replace("\'",'"')

def getUrlReqPost(url):
	global kukz
	kukz = params.get('laravel_session', None)
	cooki = {'page_access': kukz,}	
	content=s.post(url, headers=headers,verify=False,cookies=cooki).text	
	return content.replace("\'",'"')
	
def getEpisodes(url,page=1):	
	html=getUrlReq(url)
	out=[]
	try:
		plot = PLchar(re.findall('/>(.+?)</p>',html)[0])
		imag = parseDOM(html, 'img', ret='src')[1]
		result=parseDOM(html,'div', attrs={'id': "big-left"})[0]
		tit=PLchar(parseDOM(html,'div', attrs={'class': "big-right-headline"})[0])
		links = re.findall('<a href="(.+?)">\[(.+?)\].+?\[(.+?)\]',result,re.DOTALL)			
		for href,tyt,typ in links:
			title='[B][COLOR blue]%s[/COLOR] -%s (%s)[/B]'%(tit,tyt,typ)
			out.append({ 'href'  : href,'img': imag,'plot':plot,'mediatype': 'tvshows','title' : title})					
	except:
		pass
	prevpage = page-1 if page>1 else False
	return out
	

def ListSeriale(exlink):
	if 'odcinki' in exlink:
		moda='getLinks'
		serials= getOdcinki(exlink)	
		fold=False
	else:
		moda='listepisodes'
		serials= getSeriale(exlink)	
		fold=True	
	itemz=serials
	items = len(serials)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode=moda, image=f.get('img'), folder=fold, infoLabels=f, itemcount=items)			
	xbmcplugin.setContent(addon_handle, 'tvshows')	
	xbmcplugin.endOfDirectory(addon_handle)	

def getSeriale(typ):	
	serout=[]
	url = 'http://filmlink.pl/seriale-online/'	
	html=getUrlReq(url)
	if 'najlepsze' in typ:
		k=2
	elif 'najnowsze' in typ:
		k=3
	result=parseDOM(html,'div', attrs={'class': "big-right"})[k] 
	links =re.findall('<a href="(.+?)"><img src="(.+?)"',result)
	for href,imag in links:
		title=(re.findall('serial\,(.+?)online',href)[0]).upper().replace('+',' ')
		serout.append({'title':title,'href':href,'img':imag})
	return serout

def getOdcinki(typ):	
	serout=[]
	url = 'http://filmlink.pl/seriale-online/'	
	html=getUrlReq(url)
	result=parseDOM(html,'div', attrs={'class': "big-right"})[1] 
	links=parseDOM(result,'tr')#[1] 
	for link in links:
		try:
			href = parseDOM(link, 'a', ret='href')[1] 
			tit=parseDOM(link,'a')[0]	
			odcsez=parseDOM(link,'td')#[0]
			sez=odcsez[1]		
			odc=odcsez[2]
			dane='sez. %s odc. %s'%(sez,odc)
			try:
				typ1=odcsez[3]
				typ=re.findall('\[(.+?)\]',typ1)[0]
			except:
				typ=''
			title='[B][COLOR blue]%s[/COLOR] - %s (%s)[/B]'%(tit,dane,typ)
			serout.append({'title':title,'href':href,'img':''})
		except:
			pass
	return serout

def getGatunek(exlink):
	out=[]
	url='http://filmlink.pl/filmy-online/'
	html=getUrlReq(url)
	result = parseDOM(html, 'div', attrs={'id': 'small-left'})[0]
	links = parseDOM(result, 'li')
	for link in links:	
		url = str(parseDOM(link, 'a', ret='href')[0])	
		url = 'https:'+url if url.startswith('//') else url
		genre = PLchar(parseDOM(link, 'a')[0])	
		out.append((PLchar(genre), url))	
	return out	
	
def getAlfabet(exlink):
	out=[]
	html=getUrlReq(exlink)
	result = parseDOM(html, 'div', attrs={'id': 'letters'})[0]
	result2 = parseDOM(html, 'div', attrs={'id': 'big-left'})[0]
	links = parseDOM(result, 'a')
	for link in links:	
		out.append((PLchar(link), PLchar(link)))
	return out,result2	
	
def getLinks(exlink):
	exlink = 'https:'+exlink if exlink.startswith('//') else exlink	
	links=getVideosOk(exlink)
	stream_url=''	
	if not links:
		stream_url=''
		s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak linków')	
		return		
	if len(links)>1:
		linksAllb = [x.get('host') for x in links]
		s = xbmcgui.Dialog().select('Linki',linksAllb)	
	else:
		s=0
	if s>-1:
		hrefs=links[s].get('href')
		host=links[s].get('host')
		hrefs=getOrgVid(hrefs)
		if hrefs:
			stream=hrefs	
			if 'cda.pl' in hrefs:
				stream_urlCDA = cdapl.getLinkCda(hrefs)
				if len(stream_urlCDA)>1:		
					qual = [x[1] for x in stream_urlCDA]
					select = xbmcgui.Dialog().select('Wybierz jakość (cda)', qual)
				else:
					select=0
				if select>-1:
					stream_url = stream_urlCDA[select][0]
				else:
					stream_url=''	
			else:
				try:
					stream_url = urlresolver.resolve(stream)
				except Exception,e:
					stream_url=''
					s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link bedzie działał?','ERROR: %s'%str(e))	
					xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
					return					
		else:
			xbmcgui.Dialog().notification('[COLOR red][B]Problem[/COLOR][/B]', '[COLOR red][B]Link nie działa.[/COLOR][/B]', xbmcgui.NOTIFICATION_INFO, 6000)
			xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
			return	
	else:
		xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))	
		return

	if stream_url:	
		play_item = xbmcgui.ListItem(path=stream_url)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
	else:
		xbmcplugin.setResolvedUrl(addon_handle, False,  xbmcgui.ListItem(path=''))	
	
def getVideosOk(url):
	html=getUrlReq(url)		
	out=[]
	result=parseDOM(html,'div', attrs={'id': "free"})[0]
	hrefs=re.findall('<.+?load\("(.+?)"\)',result,re.DOTALL)

	for href in hrefs:
		host= href.split('/')[-1]
		film = {'href' : href,'host' : host,}
		out.append(film)		
	return out
	
def getOrgVid(url):
	html=getUrlReq(url)	
	try:
		vid = parseDOM(html, 'iframe', ret='src')[0]
	except:
		vid=''
	return vid
	
def search(q='batman'):
	url='http://filmlink.pl/autocomplete/'+q
	html=getUrlReqPost(url)	
	out=[]
	links = parseDOM(html, 'div', attrs={'class': "suggest"})
	for link in links:	
		imag = parseDOM(link, 'img', ret='src')[0]
		href = parseDOM(link, 'a', ret='href')[0] #[1]	
		href = 'https:'+href if href.startswith('//') else href	
		title = parseDOM(link, 'a')[0]
		plot = parseDOM(link, 'p')[0]
		if href and title:
			film = {
				'href'   : href,
				'title'  : PLchar(title),
				'plot'   : PLchar(plot),
				'img'    : imag,
					}
			out.append(film)				
	return out	

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&#039;',"'")
	char = char.replace('&quot;','"')
	char = char.replace('&nbsp;',".").replace('&amp;','&')
	return char	
if __name__ == '__main__':
	mode = params.get('mode', None)
	
	if not mode:
		home()
		xbmcplugin.setContent(addon_handle, 'files')	
		xbmcplugin.endOfDirectory(addon_handle)		

	elif mode == 'listmovies':
		ListMovies(exlink,sortv,page)
	elif mode == 'bajki':
		ListBajki()
		xbmcplugin.setContent(addon_handle, 'files')	
		xbmcplugin.endOfDirectory(addon_handle)		
	elif mode == 'getLinks':
		getLinks(exlink)	
	elif mode == 'listfilmy':
		ListFilmy(exlink)
	elif mode == 'listseriale':	
		ListSeriale(exlink)
	elif mode == 'listepisodes':
		ListEpisodes(exlink,page)	
	elif mode == 'listseralf':
		data,html=getAlfabet(exlink)	
		if data:
			label = [x[0].strip() for x in data]
			litera = [x[1].strip() for x in data]
			sel = xbmcgui.Dialog().select('Wybierz literę',label)
			if sel>-1:
				ListSerialsAlf(litera[sel],html)
			else:
				pass	
	elif mode == 'gatunek':
		data = getGatunek(exlink)
		par= exlink.split('|')
		if data:
			label = [x[0].strip() for x in data]
			url = [x[1].strip() for x in data]
			sel = xbmcgui.Dialog().select('Wybierz '+par[0],label)
			if sel>-1:
				ListMovies(url[sel],sortv,1)
			else:
				pass
	elif mode == '__page__M':
		url = build_url({'mode': 'listmovies', 'foldername': name, 'url' : exlink, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
		xbmcplugin.endOfDirectory(addon_handle)	
		
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			links=search(query.replace(' ','+') )
			itemz=links
			items = len(links)
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
			xbmcplugin.setContent(addon_handle, 'movies')
			xbmcplugin.endOfDirectory(addon_handle)	
		else:
			pass
	elif 'filtr' in mode:
	
		myMode = 'sort'
	
		label=['Wszystkie','Ocena',     'Alfabetycznie',     'Ilość odsłon','Data premiery','Lektor',    'Napisy',        'Dubbing']
		value=['',         'sort,rate','sort,alphabetically','sort,view',   'sort,date',   'sort,lector','sort,subtitles','sort,dubbing']	
			
		msg = 'Sortowanie'
		sel = xbmcgui.Dialog().select(msg,label)
		if sel>-1:
		
			addon.setSetting(myMode+'V',value[sel])
			addon.setSetting(myMode+'N',label[sel])
			
			xbmc.executebuiltin("Container.Refresh") 
			xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))	
		else:
			pass	