# -*- coding: utf-8 -*-

import sys,re,os,time
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonName       = my_addon.getAddonInfo('name')
PATH            = my_addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=''
import resources.lib.serialosy as serialosy
serialosy.COOKIEFILE=os.path.join(DATAPATH,'my.cookie')

def addLinkItem(name, url, mode, params={}, iconimage='DefaultFolder.png', infoLabels=False, isFolder=False, IsPlayable=True,fanart=FANART,itemcount=1):
	u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'params':params})
	liz = xbmcgui.ListItem(name)
	art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
	art = dict(zip(art_keys,[iconimage for x in art_keys]))
	art['landscape'] = fanart if fanart else art['landscape']
	art['fanart'] = fanart if fanart else art['landscape']
	liz.setArt(art)
	if not infoLabels:
		infoLabels={'title': name}
	liz.setInfo(type='video', infoLabels=infoLabels)
	if IsPlayable:
		liz.setProperty('IsPlayable', 'true')
	isp = []
	isp.append(('Informacja', 'XBMC.Action(Info)'))
	liz.addContextMenuItems(isp, replaceItems=False)
	ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=isFolder,totalItems=itemcount)
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = '%R, %Y, %P')
	return ok
def addDir(name,ex_link=None, params={}, mode='folder',iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART,contextmenu=None):
	url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'params' : params})
	li = xbmcgui.ListItem(name)
	if infoLabels:
		li.setInfo(type='video', infoLabels=infoLabels)
	art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
	art = dict(zip(art_keys,[iconImage for x in art_keys]))
	art['landscape'] = fanart if fanart else art['landscape']
	art['fanart'] = fanart if fanart else art['landscape']
	li.setArt(art)
	if contextmenu:
		isp=contextmenu
		li.addContextMenuItems(isp, replaceItems=True)
	else:
		isp = []
		isp.append(('Informacja', 'XBMC.Action(Info)'),)
		li.addContextMenuItems(isp, replaceItems=False)
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = '%R, %Y, %P')
def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        out_dict[k] = v
    return out_dict
def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))
def getContent(ex_link,data):
    slinks,pagination = serialosy.scanPage(ex_link,data)
    if pagination[0]:
        addLinkItem(name='[COLOR blue]<< Poprzednia strona <<[/COLOR]', url=pagination[0], params={}, mode='page:getContent', IsPlayable=False)
    items=len(slinks)
    for f in slinks:
        addLinkItem(name=f.get('title'), url=f.get('url',''), mode='getLinks', iconimage=f.get('img'), infoLabels=f, isFolder=False, IsPlayable=True,itemcount=items)
    if pagination[1]:
        addLinkItem(name='[COLOR blue]>> Następna strona >>[/COLOR]', url=pagination[1], params={}, mode='page:getContent', IsPlayable=False)
    xbmcplugin.setContent(addon_handle, 'tvshows')
def getVideoLinks24(streams):
	link=''
	if not link:
		try:
			import resolveurl as urlresolver
			link = urlresolver.resolve(streams)
		except Exception,e:
			xbmcgui.Dialog().notification('Error', 'Błąd resolvera [COLOR red][B][%s][/COLOR][/B]'%str(e), xbmcgui.NOTIFICATION_INFO, 6000)
			link=''
	return link
def getPlayvid(streams):
    return link
def getLinks(ex_link):
	link=''
	streams = serialosy.getVideos(ex_link)
	if len(streams)>1:
	
		t = [ x.get('title') for x in streams]
		u = [ x.get('url') for x in streams]
		dlg_select = xbmcgui.Dialog().select('Sources', t)
		if dlg_select>-1:
			link = streams[dlg_select].get('url')
			host=streams[dlg_select].get('title')
			if 'playerdrive' in host:
				link=link
			else:
				link=getVideoLinks24(link) if link else ''
		
	else:
		link=streams[0].get('url')
		if 'playerdrive' in link:
			link=link
		else:
			link=getVideoLinks24(link)
	if link:
		xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=link))
	else:
		quit()

mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
params = args.get('params',[{}])[0]
sortv = my_addon.getSetting('sortV')
sortn = my_addon.getSetting('sortN') if sortv else 'Brak'
if mode is None:
	addLinkItem('[COLOR blue]Sortowanie:[/COLOR] [B]'+sortn+'[/B]','',mode='filtr:sort',iconimage='',IsPlayable=False)
	addDir(name='Strona g\xc5\x82\xc3\xb3wna',ex_link='http://www.serialosy24.pl/',params={}, mode='getContent',iconImage='')
	addDir(name='Zagraniczne seriale',ex_link='http://www.serialosy24.pl',params={'menu':'Zagraniczne'}, mode='getSeriale',iconImage='')
	addDir(name='Polskie seriale',ex_link='http://www.serialosy24.pl',params={'menu':'Polskie'}, mode='getSeriale',iconImage='')
	addDir(name='Dokumentalne',ex_link='http://www.serialosy24.pl',params={'menu':'Dokumentalne'}, mode='getSeriale',iconImage='')
	xbmcplugin.endOfDirectory(addon_handle)	
elif 'filtr' in mode[0]:
	_myMode = mode[0].split(':')[-1]
	if _myMode=='sort':
		label=['Brak','Data dodania','Ocena','Wyświetlenia','Komentarze','Alfabetycznie A-Z','Alfabetycznie Z-A']
		value=['','dlenewssortby=date&dledirection=desc&set_new_sort=dle_sort_main&set_direction_sort=dle_direction_main','dlenewssortby=rating&dledirection=desc&set_new_sort=dle_sort_main&set_direction_sort=dle_direction_main','dlenewssortby=news_read&dledirection=desc&set_new_sort=dle_sort_main&set_direction_sort=dle_direction_main','dlenewssortby=comm_num&dledirection=desc&set_new_sort=dle_sort_main&set_direction_sort=dle_direction_main','dlenewssortby=title&dledirection=asc&set_new_sort=dle_sort_main&set_direction_sort=dle_direction_main','dlenewssortby=title&dledirection=desc&set_new_sort=dle_sort_main&set_direction_sort=dle_direction_main']
	msg = 'Sortowanie'
	s = xbmcgui.Dialog().select(msg,label)
	s = s if s>-1 else quit()#0
	my_addon.setSetting(_myMode+'V',value[s])
	my_addon.setSetting(_myMode+'N',label[s])
	xbmc.executebuiltin('XBMC.Container.Refresh')
elif mode[0]=='getSeriale':
	params=eval(params)
	ser = serialosy.getSeriale(ex_link,params.get('menu','Zagraniczne'))
	items=len(ser)
	for f in ser:
		addLinkItem(name=f.get('title'), url=f.get('url',''), mode='getContent', iconimage=f.get('img'), infoLabels=f, isFolder=True, IsPlayable=False,itemcount=items)
	xbmcplugin.setContent(addon_handle, 'tvshows')
	xbmcplugin.endOfDirectory(addon_handle)		
elif mode[0]=='getContent':
	getContent(ex_link,sortv)
	xbmcplugin.endOfDirectory(addon_handle)	
elif mode[0]=='getLinks':
    getLinks(ex_link)
elif mode[0].startswith('page'):
	l1ll1l1_sy_,myMode = mode[0].split(':')
	url = build_url({'mode': myMode, 'foldername': '', 'ex_link' : ex_link, 'params':params})
	xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
	xbmcplugin.endOfDirectory(addon_handle)		
else:
    quit()#xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
