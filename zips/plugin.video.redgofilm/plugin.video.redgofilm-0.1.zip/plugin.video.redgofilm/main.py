# -*- coding: UTF-8 -*-

from resources.lib.redgofilm import RedgoFilm

if __name__ == '__main__':
    RedgoFilm()