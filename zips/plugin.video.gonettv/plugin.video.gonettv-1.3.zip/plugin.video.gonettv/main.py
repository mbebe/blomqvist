# -*- coding: UTF-8 -*-

import sys, os, re
if sys.version_info >= (3,0,0):
# for Python 3
    from urllib.parse import urlencode, parse_qsl, quote
    import http.cookiejar as cookielib
    from urllib.parse import urlparse
    from resources.lib.cmf3 import parseDOM
    
else:
    # for Python 2
    from urllib import urlencode, quote
    from urlparse import parse_qsl
    import cookielib
    from urlparse import urlparse
    from resources.lib.cmf2 import parseDOM

import xbmc, xbmcvfs

import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib3

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
exlink = params.get('url', None)
try:
    ilnr = int(params.get('moviescount', None))
except:
    ilnr = 0
addon = xbmcaddon.Addon(id='plugin.video.gonettv')

PATH            = addon.getAddonInfo('path')
try:
    DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
except:
    DATAPATH    = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
  
if not os.path.exists(DATAPATH):
    os.makedirs(DATAPATH)
RESOURCES       = PATH+'/resources/'

FANART=RESOURCES+'../fanart.jpg'
ikona = RESOURCES+'../icon.png'


UA ='Mozilla/5.0 (SMART-TV; LINUX; Tizen 5.5) AppleWebKit/537.36 (KHTML, like Gecko) 69.0.3497.106.1/5.5 TV Safari/537.36'
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

sess = requests.Session()

COOKIEFILE = os.path.join(DATAPATH,'gonet.cookie')

sess.cookies = cookielib.LWPCookieJar(COOKIEFILE)
cj = sess.cookies

main_url = addon.getSetting('sitemain')
auth = addon.getSetting('authkey')
url_overeni = addon.getSetting('url_overeni')
url_system = addon.getSetting('url_system')
url_program = addon.getSetting('url_program')

datav = addon.getSetting('dataV')
if not datav:
    import datetime

    a=datetime.datetime.utcnow()
    dtnow = a.strftime('%Y-%m-%d') 
    addon.setSetting('dataV',str(dtnow))
    addon.setSetting('dataN',str(dtnow))
    
datan = addon.getSetting('dataN') if datav else 'Dzisiaj'

krajv = addon.getSetting('krajV')
if not krajv:

    addon.setSetting('krajN','wszystkie')
krajn = addon.getSetting('krajN')# if krajv else 'Polska'

fkrajv = addon.getSetting('fkrajV')
if not fkrajv:
    addon.setSetting('fkrajV','&requests[3][filtr_zeme]=Polsko') 
    addon.setSetting('fkrajN','Polska')
    fkrajv = addon.getSetting('fkrajV')
fkrajn = addon.getSetting('krajN')# if krajv else 'Polska'

fulldata = addon.getSetting('fulldata')


#gatv = addon.getSetting('gatV')
#gatn = addon.getSetting('gatN') if gatv else 'Wszystkie'
#jezykv = addon.getSetting('jezykV')
#jezykn = addon.getSetting('jezykN') if jezykv else 'Wszystkie'


codectyp = 'h265' 
urlforapi = 'https://{}/api/systemP2.php?auth={}&zarizeni=&zarizeni_id=&zarizeni_model=&zarizeni_token=&k=1&c='+codectyp+'&api_verze=3'

czeskikat = {u'Rodinn\xfd': u'Familijny', u'Paralympi\xe1da': u'Paraolimpiada', u'Olympijsk\xe9 hry': u'Igrzyska Olimpijskie', u'Bungee Jumping': u'Skoki na bungee', u'Talk Show': u'Talk Show', u'M\xf3da': u'Moda', u'Kr\xe1tk\xfd film': u'Kr\xf3tkometra\u017cowy', u'Shinty': u'Shinty', u'Soul/R&B': u'Soul/R&B', u'S\xe1\u0148kov\xe1n\xed': u'Sanki', u'Medic\xedna': u'Medycyna', u'Bruslen\xed na led\u011b': u'Jazda na \u0142y\u017cwach', u'Minis\xe9rie': u'Mini seria', u'Motoristick\xe9': u'Motoryzacja', u'Volejbal': u'Siatk\xf3wka', u'Jednoduch\xfd poslech': u'Muzyka lekka', u'Cricket': u'Cricket', u'Business': u'Biznes', u'Reality TV': u'Reality TV', u'Technologie': u'Technologie', u'Kule\u010dn\xedk': u'Bilard', u'P\xe1ka': u'Ci\u0119\u017cary', u'Sky Surfing': u'Podniebny surfing', u'Science Fiction': u'Science Fiction', u'Evropa': u'Europejski', u'Mlad\u0161\xed 5 let': u'Dzieci do 5lat', u'Western': u'Western', u'\u017divotn\xed prost\u0159ed\xed': u'\u015arodowisko', u'Kino': u'Kino', u'Showbyznys': u'Show biznes', u'Thriller': u'Thriller', u'Snakeboarding': u'Snakeboarding', u'Aktu\xe1ln\xed d\u011bn\xed': u'Aktualne wydarzenia', u'Romantick\xe1 komedie': u'Komedia romantyczna', u'Architektura': u'Architektura', u'Plav\xe1n\xed': u'P\u0142ywanie', u'Melodrama': u'Melodramat', u'Hudebn\xed komedie': u'Muzyczna komedia', u'Sitcom': u'Sitcom', u'Rychlobruslen\xed': u'\u0141y\u017cwiarstwo szybkie', u'Base Jumping': u'Base Jumping', u'Americk\xfd fotbal': u'Futbol ameryka\u0144ski', u'Para\u0161utismus': u'Spadochroniarstwo', u'Ledn\xed hokej': u'Hokej na lodzie', u'Zlat\xe1 klasika': u'Z\u0142ota klasyka', u'R\u016fzn\xe9': u'R\xf3\u017cne', u'Australsk\xfd fotbal': u'Futbol australijski', u'Um\u011bleck\xe1 \u0159emesla': u'Sztuka i rzemios\u0142o', u'Amat\xe9\u0159i': u'Amatorski', u'Snowboarding': u'Snowboard', u'Sumo Wrestling': u'Zapasy sumo', u'Skydiving': u'Spadochroniarstwo', u'Cyklistika': u'Jazda na rowerze', u'Jeskynn\xed pot\xe1p\u011bn\xed': u'Nurkowanie w jaskiniach', u'Basebal': u'Baseball', u'Va\u0159en\xed': u'Kulinarne', u'Zimn\xed Paralympi\xe1da': u'Zimowe Igrzyska Paraolimpijskie', u'Seri\xe1l': u'Serial', u'Sport': u'Sport', u'Sout\u011b\u017e': u'Konkurs', u'Skoky z \xfates\u016f': u'Skoki z klif\xf3w', u'Interaktivn\xed hazardn\xed hra': u'Hazard interaktywny', u'Hry na p\xf3diu': u'Gra na scenie', u'Klasick\xe1 hudba': u'Muzyka klasyczna', u'Tanec': u'Tanic', u'Pot\xe1p\u011bn\xed': u'Nurkowanie', u'Klus\xe1ck\xe9 dostihy': u'Wy\u015bcigi k\u0142usak\xf3w', u'Jazykov\xe9': u'J\u0119zykowy', u'Z\xe1bavn\xfd': u'Rozrywkowe', u'Um\u011bn\xed': u'Sztuka', u'Hurling': u'Hurling', u'Z\xe1vod motorov\xfdch \u010dlun\u016f': u'Wy\u015bcig motor\xf3wki', u'Expedice': u'Wyprawy', u'Biblick\xfd': u'Biblijny', u'Poker': u'Poker', u'Extr\xe9mn\xed sporty': u'Sporty ekstremalne', u'Neza\u0159azeno': u'Nie dopasowano', u'Vzd\u011bl\xe1vac\xed': u'Edukacyjny', u'Zahradni\u010den\xed': u'Ogrodnictwo', u'Squash': u'Squash', u'Slavn\xed lid\xe9': u'S\u0142awni ludzie', u'Z\xe1jmy': u'Zainteresowania', u'Z\xe1hadn\xe9 vra\u017edy': u'Tajemnicze morderstwa', u'Faktick\xfd': u'Na faktach', u'Drama seri\xe1l': u'Serial dramatyczny', u'Kultura mlad\xfdch': u'Kultura dla m\u0142odych', u'Bandy hokej': u'Bandy hokej', u'Basketbal': u'Koszyk\xf3wka', u'Civilizace': u'Cywilizacje', u'Box': u'Boks', u'Hokej': u'Hokej', u'Judo': u'Judo', u'Modern\xed p\u011btiboj': u'Pi\u0119ciob\xf3j nowoczesny', u'Dal\u0161\xed vzd\u011bl\xe1v\xe1n\xed': u'Dalsza edukacji', u'Vodn\xed sporty': u'Sporty wodne', u'Telenovela': u'Telenowela', u'Lukost\u0159elba': u'\u0141ucznictwo', u'Commonwealthsk\xe9 hry': u'Gry Wsp\xf3lnoty Narod\xf3w', u'N\xe1bo\u017eenstv\xed': u'Relogia', u'Po\u010das\xed': u'Pogoda', u'Atletika': u'Lekkoatletyka', u'Drama': u'Dramat', u'Rodeo': u'Rodeo', u'Z\xe1vody ps\u016f': u'Wy\u015bcigi ps\xf3w', u'Sportovn\xed l\xe9t\xe1n\xed': u'Latanie sportowe', u'Muzik\xe1ly': u'Musical', u'Dokument\xe1rn\xed': u'Dokumentalny', u'Snooker': u'Snooker', u'\u0160erm': u'Szermierka', u'V\xe1le\u010dn\xfd': u'Wojenny', u'Tenpin Bowling': u'Kr\u0119gielnia Tenpin', u'Tenis': u'Tenis', u'Gay': u'Gej', u'Hip-Hop': u'Hip-Hop', u'Hororov\xfd': u'Horror', u'Dokument': u'Dokumentalny', u'\u017divotopisn\xfd': u'Biograficzny', u'Komick\xe1 opereta': u'Komiczna operetka', u'Nakupov\xe1n\xed': u'Zakupy', u'\u017divotopisn\xfd muzik\xe1l': u'Biograficzny musical', u'Gaelsk\xe9 hry': u'Gry gaelickie', u'Vzp\xedr\xe1n\xed': u'Podnoszenie ci\u0119\u017car\xf3w', u'Motorov\xe9 sporty': u'Sporty motorowe', u'Um\u011bleck\xfd magaz\xedn': u'Program artystyczny', u'Fotbal': u'Pi\u0142ka no\u017cna', u'Netball': u'Netball', u'K\xe1noe': u'Kajak', u'Kick Boxing': u'Kick Boxing', u'Voln\xfd \u010das': u'Czas wolny', u'Sv\u011btov\xfd poh\xe1r': u'Mistrzostwa \u015awiata', u'Skoky na trampol\xedn\u011b': u'Skoki na tramlopinie', u'Cestov\xe1n\xed': u'Podr\xf3\u017ce', u'Hern\xed show': u'Teleturniej', u'Gymnastika': u'Gimnastyka', u'Zdrav\xed': u'Zdrowie', u'Docusoap': u'serial paradokumentalny', u'Literatura': u'Literatura', u'Zpr\xe1vy': u'Informacje', u'Animovan\xfd': u'Animowany', u'Hudba & Um\u011bn\xed': u'Muzyka & Art', u'Ryba\u0159en\xed': u'W\u0119dkarstwo', u'Divadlo, inscenace': u'Teatr, produkcja', u'Pl\xe1\u017eov\xfd volejbal': u'Siatk\xf3wka pla\u017cowa', u'P\u0159\xedrodn\xed sv\u011bt': u'Przyrodniczy', u'Roller Hockey': u'Hokej na rolkach', u'Katastrofick\xfd': u'Katastroficzny', u'Bojov\xe1 um\u011bn\xed': u'Sztuki walki', u'Ak\u010dn\xed': u'Akcji', u'Zimn\xed Olympijsk\xe9 hry': u'Zimowe Igrzyska Olimpijskie', u'Poh\xe1dka': u'Bajka', u'Staro\u017eitnosti': u'Antyki', u'Vodn\xed p\xf3lo': u'Pi\u0142ka wodna', u'Triatlon': u'Triathlon', u'P\xf3lo': u'Polo', u'Stoln\xed tenis': u'Tenis sto\u0142owy', u'Opera': u'Opera', u'Horor': u'Horror', u'\u010cern\xe1 komedie': u'Czarna komedia', u'Ko\u0148sk\xe9 dostihy': u'Wy\u015bcigi konne', u'Body Building': u'Kulturystyka', u'Mysteri\xf3zn\xed': u'Tajemniczy', u'Speci\xe1ln\xed touhy': u'Specjalne pragnienia', u'Curling': u'Curling', u'J\xedzda na san\xedch': u'Kulig', u'H\xe1zen\xe1': u'Pi\u0142ka r\u0119czna', u'Golf': u'Golf', u'Jachting': u'\u017beglarstwo', u'V\u011bda': u'Wiedza', u'Wrestling': u'Zapasy', u'Bowls': u'kr\u0119gle', u'Pro n\xe1ctilet\xe9': u'Dla nastolatk\xf3w', u'Horolezectv\xed': u'Alpinizm', u'Pro dosp\u011bl\xe9': u'Dla doros\u0142ych', u'Skateboarding': u'Jazda na deskorolce', u'\u0160ipky': u'Strzelnictwo', u'Placht\u011bn\xed': u'\u017beglarstwo', u'Balet': u'Balet', u'Dobov\xe9 drama': u'Dramat z epoki', u'Aerobik': u'Aerobik', u'Romantick\xe9': u'Romantyczny', u'Spot\u0159ebn\xed': u'Konsument', u'Alpsk\xe9 ly\u017eov\xe1n\xed': u'Narciarstwo alpejskie', u'Divadlo': u'Teatr', u'Alternativn\xed': u'Alternatywa', u'US Glamour': u'Glamour', u'Erotika': u'Erotyczny', u'Romantick\xfd': u'Romantyczny', u'Motocykly': u'Motocykle', u'Ly\u017eov\xe1n\xed': u'Narciarstwo', u'Windsurfing': u'Windsurfing', u'Skotsk\xe9 hry': u'Gry szkockie', u'Florbal': u'Unihokej', u'Folk & lidov\xe9': u'Folklor i ludowe', u'Open University': u'Otwarty uniwestytet', u'Detektivn\xed': u'Detektywistyczny', u'Lakros': u'Lakros', u'Jazz': u'Jazz', u'Gaelsk\xfd fotbal': u'Futbol gaelicki', u'Magaz\xedn': u'Magazyn', u'Dobov\xfd': u'Historyczny', u'Zdravotnictv\xed': u'O zdrowiu', u'Tane\u010dn\xed hudba': u'Muzyka taneczna', u'Badminton': u'Badminton', u'Historie': u'Historia', u'Softbal': u'Softball', u'\u0160pion\xe1\u017en\xed': u'Szpiegowski', u'Biatlon': u'Biathlon', u'Historick\xfd': u'Historyczny', u'Dobov\xe9': u'Historyczny', u'Komedie': u'Komedia', u'St\u0159elba': u'Strzelanie', u'Socha\u0159stv\xed': u'Rze\u017aba', u'Kole\u010dkov\xe9 brusle': u'Wrotki', u'Surfing': u'surfowanie', u'Rugby': u'Rugby', u'Hudba': u'Muzyka', u'B\u011bh na ly\u017e\xedch': u'Narciarstwo biegowe', u'D\u011btem': u'Dzieci', u'Real tenis': u'Real tenis', u'Pop & Rock': u'Pop & Rock', u'Z\xe1vody na bobech': u'Wy\u015bcig bobslejowy', u'Dobrodru\u017en\xfd': u'Przygodowy', u'Skoky na ly\u017e\xedch': u'Skoki narciarskie', u'Veslov\xe1n\xed': u'Wio\u015blarstwo', u'Doprava': u'Transport', u'Krimi': u'Kryminalny', u'Sportovn\xed drama': u'Dramat sportowy', u'Camogie': u'Camogie', u'Rugby Union': u'Rugby Union', u'Fantasy': u'Fantasy', u'Politika': u'Polityka', u'Rugby Liga': u'Rugby Liga', u'Film': u'Film', u'Zalo\u017eeno na skute\u010dnosti': u'Oparty na faktach', u'Interaktivn\xed seznamka': u'Interaktywny serwis randkowy', u'Jezdectv\xed': u'Je\u017adziectwo', u'Film noir': u'Czarne kino', u'Billiard': u'Bilard', u'Pro d\u011bti': u'Dla dzieci'}
czeskikraj ={u'Ma\u010farsko': u'Austria', u'Lybie': u'Libia', u'Spojen\xe9 kr\xe1lovstv\xed': u'Wielka Brytania', u'Dominika': u'Dominika', u'Jamajka': u'Jamajka', u'Nizozemsko': u'Niderlandy', u'Lichten\u0161tejnsko': u'Liechtenstein', u'Guinea': u'Gwinea', u'Asie': u'Azja', u'Nep\xe1l': u'Nepal', u'Dominik\xe1nsk\xe1 republika': u'Republika Dominikany', u'It\xe1lie': u'W\u0142ochy', u'Svat\xe1 Lucie': u'Saint Lucia', u'\u0160v\xe9dsko': u'Szwecja', u'\u0160pan\u011blsko': u'Hiszpania', u'Rumunsko': u'Rumunia', u'\u010cesko': u'Czechy', u'Palestina': u'Autonomia Palesty\u0144ska', u'Faersk\xe9 ostrovy': u'Wyspy Owcze', u'Mexiko': u'Meksyk', u'Brunej': u'Brunei', u'B\u011blorusko': u'Bia\u0142oru\u015b', u'Berl\xedn': u'Berlin', u'Al\u017e\xedrsko': u'Algieria', u'Mongolsko': u'Mongolia', u'Pob\u0159e\u017e\xed slonoviny': u'Wybrze\u017ce Ko\u015bci S\u0142oniowej', u'Fid\u017ei': u'Fid\u017ci', u'Kapverdy': u'Wyspy Zielonego Przyl\u0105dka', u'Evropa': u'Europa', u'Rwanda': u'Rwanda', u'Nov\xfd Z\xe9land': u'Nowa Zelandia', u'T\xe1d\u017eikist\xe1n': u'Tad\u017cykistan', u'Spojen\xe9 arabsk\xe9 emir\xe1ty': u'Zjednoczone Emiraty Arabskie', u'Seychely': u'Seszele', u'Kuba': u'Kuba', u'Nikaragua': u'Nikaragua', u'Georgie': u'Gruzja', u'Estonsko': u'Estonia', u'Island': u'Islandia', u'Finsko': u'Finlandia', u'Ukrajina': u'Ukraina', u'North Macedonia': u'Macedonia P\xf3\u0142nocna', u'Monako': u'Monako', u'Belgie': u'Belgia', u'Gr\xf3nsko': u'Grenlandia', u'Filip\xedny': u'Filipiny', u'Papua-Nov\xe1 Guinea': u'Papua-Nowa Gwinea', u'Loty\u0161sko': u'\u0141otwa', u'Grenada': u'Grenada', u'Nizozem\xed': u'Niderlandy', u'Vatik\xe1n': u'Watykan', u'Kajmansk\xe9 ostrovy': u'Kajmany', u'Andorra': u'Andora', u'Kyrgyst\xe1n': u'Kirgistan', u'Indie': u'Indie', u'Jord\xe1nsko': u'Jordania', u'Kongo': u'Kongo', u'Ji\u017en\xed Korea': u'Korea Po\u0142udniowa', u'\xcdr\xe1n': u'Iran', u'Slovensko': u'S\u0142owacja', u'Rakousko': u'Austria', u'Ke\u0148a': u'Kenia', u'\u010c\xedna': u'Chiny', u'\u010cern\xe1 Hora': u'Czarnog\xf3ra', u'Guam': u'Guam', u'\u0158ecko': u'Grecja', u'Austr\xe1lie a Oce\xe1nie': u'Australia i Oceania', u'Bol\xedvie': u'Boliwia', u'Slovinsko': u'S\u0142owenia', u'USA': u'Stany Zjednoczone', u'Kanada': u'Kanada', u'Litva': u'Litwa', u'Nig\xe9rie': u'Nigeria', u'Bermudy': u'Bermudy', u'Ostrov Man': u'Wyspa Man', u'Pensylv\xe1nie': u'Pensylwania', u'\u010cesk\xe1 republika': u'Czechy', u'Mosambik': u'Mozambik', u'Singapur': u'Singapur', u'Afrika': u'Afryka', u'Srbsko': u'Serbia', u'N\u011bmecko': u'Niemcy', u'Thajsko': u'Tajlandia', u'Ir\xe1k': u'Irak', u'Nov\xe1 Kaledonie': u'Nowa Kaledonia', u'Amerika': u'Ameryka', u'Bavorsko': u'Bawaria', u'Arm\xe9nie': u'Armenia', u'Austr\xe1lie': u'Australia', u'Turecko': u'Turcja', u'Mauricius': u'Mauritius', u'Baskitsko': u'Kraj Bask\xf3w', u'Francie': u'Francja', u'Japonsko': u'Japonia', u'D\xe1nsko': u'Dania', u'Praha': u'Praga', u'Kypr': u'Cypr', u'Jihoafrick\xe1 republika': u'Republika Po\u0142udniowej Afryki', u'Norsko': u'Norwegia', u'Tonga': u'Tonga', u'Moldavsko': u'Mo\u0142dawia', u'Kazachst\xe1n': u'Kazachstan', u'Salvador': u'San Salwador', u'Polsko': u'Polska', u'Ekv\xe1dor': u'Ekwador', u'Saudsk\xe1 ar\xe1bie': u'Arabia Saudyjska', u'Nizozemsk\xe9 Antily': u'Antyle Holenderskie', u'Trinidad a Tobago': u'Trinidad i Tobago', u'Tanz\xe1nie': u'Tanzania', u'Gambie': u'Gambia', u'Braz\xedlie': u'Brazylia', u'Bahamy': u'Bahamy', u'Izrael': u'Izrael', u'Britsk\xe1 Kolumbie': u'Kolumbia Brytyjska', u'Guyana': u'Gujana', u'Mali': u'Mali', u'Kambod\u017ea': u'Kambod\u017ca', u'Malajsie': u'Malezja', u'Namibie': u'Namibia', u'Petrohrad': u'Petersburg', u'Velk\xe1 Brit\xe1nie': u'Wielka Brytania', u'Portugalsko': u'Portugalia', u'Rusko': u'Rosja', u'Myanmar': u'Mjanma', u'Alb\xe1nie': u'Albania', u'Kolumbie': u'Kolumbia', u'Sic\xedlie': u'Sycylia', u'Chorvatsko': u'Chorwacja', u'Indon\xe9sie': u'Indonezja', u'Peking': u'Pekin', u'Severn\xed Karolina': u'Karolina P\xf3\u0142nocna', u'Uzbekist\xe1n': u'Uzbekistan', u'Kalifornie': u'Kalifornia', u'Irsko': u'Irlandia', u'Rusk\xe1 federace': u'Rosja', u'Bulharsko': u'Bu\u0142garia', u'\u0160v\xfdcarsko': u'Szwajcaria', u'Madagaskar': u'Madagaskar', u'Maroko': u'Maroko', u'Lucembursko': u'Luksemburg', u'Moskva': u'Moskwa'}





def build_url(query):
    return base_url + '?' + urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=1,fanart=FANART,moviescount=0):
    list_item = xbmcgui.ListItem(label=name)

    if IsPlayable:
        list_item.setProperty("IsPlayable", 'True')
    if not infoLabels:
        infoLabels={'title': name,'plot':name}
    list_item.setInfo(type="video", infoLabels=infoLabels)    
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': FANART})
    ok=xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url = build_url({'mode': mode, 'url' : url, 'page' : page, 'moviescount' : moviescount,'movie':movie,'title':name,'image':image}),            
        listitem=list_item,
        isFolder=folder)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
    return ok
    

def login2():
    username = addon.getSetting('usernamex')
    password = addon.getSetting('passwordx')
    headers = {
        'Host': 'www.gonet.tv',
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Upgrade-Insecure-Requests': '1',
    }

    response = sess.get('https://www.gonet.tv/pl/', headers=headers, verify=False)
    
    headers = {
        'Host': 'www.gonet.tv',
        'User-Agent': UA,
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Origin': 'https://www.gonet.tv',
        'Referer': 'https://www.gonet.tv/pl/',
    }
    
    data={'page':'login','action':'login','user_name':username,'user_password':password}

    response = sess.post('https://www.gonet.tv/web/ajax.php', headers=headers, cookies=cj, data=data,verify=False).json()

    if response.get('status',None)=='ok':
        logged=True
        
        
        headers = {
            'Host': 'www.gonet.tv',
            'User-Agent': UA,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            'Upgrade-Insecure-Requests': '1',
            'Cache-Control': 'max-age=0',
        }
        
        response = sess.get('https://www.gonet.tv/pl/', headers=headers, cookies=cj,verify=False)
        html = (response.text).replace("\'",'"')
        sitemain=re.findall('CONST_WWW_ONLINETV\s*=\s"([^"]+)',html)[0]

        headers = {
            'Host': 'www.gonet.tv',
            'User-Agent': UA,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            'Referer': 'https://www.gonet.tv/pl/',
            'Upgrade-Insecure-Requests': '1',
        }
        ag = response.cookies
        az = sess.cookies

        response = sess.get(sitemain, headers=headers, cookies=cj,verify=False)

        html = (response.text).replace("\'",'"')
        
        key,valu = re.findall('setcookie\("(.+?)",\s*"(.+?)"\)',html,re.DOTALL+re.IGNORECASE)[0]
        
        addon.setSetting('authkey',valu)

        cj.save(COOKIEFILE, ignore_discard = True)
        parsed_url = urlparse(sitemain)
        sitemain = parsed_url.netloc
        addon.setSetting('sitemain',sitemain)
        main_url = addon.getSetting('sitemain')
        url = urlforapi.format(main_url,auth)
        response = sess.get(url, headers=headers, cookies=cj,verify=False)

        jsdata = response.json()
        url_overeni = jsdata.get('url_overeni',None)
        url_system = jsdata.get('url_system',None)
        url_program = jsdata.get('url_program',None)
        
        addon.setSetting('url_overeni',url_overeni)
        addon.setSetting('url_system',url_system)
        addon.setSetting('url_program',url_program)
        
        response = sess.get('https://www.gonet.tv/pl/uzytkownik/uzytkownik_uslugi/', headers=headers, cookies=cj,verify=False)
        html = (response.text).replace("\'",'"')

        nick = re.findall('name global_bold">(.*?)<',html,re.DOTALL)
        nick = (nick[0].replace('\r','').replace('\n','')).strip(' ') if nick else ''
        dane = parseDOM(html, 'div', attrs={'class': "global_tableR"})

        for d in dane:
            d= d.replace('\r','').replace('\n','')
            if 'aktywna' in d.lower():
                usl = re.findall('global_bold">([^<]+)',d,re.DOTALL)[0].strip()
                usl2 = re.findall('<span title=.*?>([^<]+)',d,re.DOTALL)[0].replace('  ','')
                
                plot = usl+': '+   '[COLOR gold]'+usl2+'[/COLOR]'    
                nick = '[COLOR gold][B]'+nick+'[/COLOR][/B]'+   ' [COLOR violet]('+usl2.replace('do ','')+')[/COLOR]' 
                dod = {'nick':nick,'plot':plot}
                break
            else:
                plot ='brak ważnej usługi'
                dod = {'nick':nick+' (brak pakietu)','plot':plot}
                break
    else:
        logged=False
        dod = None
    return logged,dod
    
    
    
def home():
    logged,dod = login2()
    if not logged:
        add_item('film', 'Zaloguj', 'DefaultUser.png', "loguj", folder=False,fanart=FANART)
    else:
    
        add_item('film', 'Zalogowany jako: '+dod.get('nick',None), 'DefaultUser.png', "  ", folder=True, infoLabels={'plot':PLchar(dod.get('plot',None))}, fanart=FANART)
        add_item('film', 'Telewizja', 'DefaultMovies.png', "play5", folder=True,fanart=FANART)

        add_item('film', 'Nagrania', 'DefaultMovies.png', "listnagrania", folder=True,fanart=FANART)
        
        add_item('film', 'Radio', 'DefaultMusicSongs.png', "radio", folder=True,fanart=FANART)
        
        add_item('film', 'Wideoteka', 'DefaultMovies.png', "widmenu", folder=True,fanart=FANART)
        
    xbmcplugin.endOfDirectory(addon_handle)

def WideotekaMenu():
    add_item('F', 'Film', 'DefaultMovies.png', "wideoteka", folder=True,fanart=FANART)
    add_item('S', 'Serial', 'DefaultMovies.png', "wideoteka", folder=True,fanart=FANART)
    add_item('O', 'Sport', 'DefaultMovies.png', "wideoteka", folder=True,fanart=FANART)
    add_item('Z', 'Wiadomości', 'DefaultMovies.png', "wideoteka", folder=True,fanart=FANART)
    add_item('L', 'Zabawa', 'DefaultMovies.png', "wideoteka", folder=True,fanart=FANART)
    add_item('D', 'Dokumenty', 'DefaultMovies.png', "wideoteka", folder=True,fanart=FANART)
    add_item('Q', 'Dla dzieci', 'DefaultMovies.png', "wideoteka", folder=True,fanart=FANART)
    xbmcplugin.endOfDirectory(addon_handle)
    
def Wideotekaxx(typ):
    cntryV = addon.getSetting(typ.lower()+'krajV')
    cntryN = addon.getSetting(typ.lower()+'krajN')
    #https://www.xn--lep-tma39c.tv/api/program0.php?auth=60b74028d8dd03.75542764&profil=&zobrazeno=&network=&k=1&c=h264&no_alternative=&zarizeni=&verze=3&requests[0][ts]=I&requests[0][te]=I&requests[0][limit]=13&requests[0][limit2]=100&requests[0][archiv]=0&requests[0][seskupit]=true&requests[0][filtr_typprg]={}
    ab = Filtry(typ)
    url = '{0}?auth={1}&profil=&zobrazeno=&network=&k=1&c='+codectyp+'&no_alternative=&zarizeni=&verze=3&requests[0][ts]=I&requests[0][te]=I&requests[0][limit]=13&requests[0][limit2]=100&requests[0][archiv]=0&requests[0][seskupit]=true&requests[0][filtr_typprg]={2}'
    url = url.format(url_program,auth,typ)
    #if typ=='F':
    if cntryN:
        add_item('F|zeme', '[COLOR lightblue][I][B]-    kraj:[/COLOR][/I][/B]        [COLOR lightgreen][B]'+cntryN+'[/B] [/COLOR]' , 'DefaultMovies.png', 'filtry', folder=False,fanart=FANART)
    add_item(typ, '[B]Wyświetl[/B]' , 'DefaultMovies.png', 'listwideoteka', folder=True,fanart=FANART)
    
    
    xbmcplugin.endOfDirectory(addon_handle)
def Wideoteka(typ,nr,skupina=False):

    import datetime
    if '|' in typ:
        typ,skupina = typ.split('|')
        url = '{0}?auth={1}&profil=&zobrazeno=&network=&k=1&c='+codectyp+'&no_alternative=&zarizeni=&verze=3'+skupina

    else:
        skupina = False

        url = '{0}?auth={1}&profil=&zobrazeno=&network=&k=1&c='+codectyp+'&no_alternative=&zarizeni=&verze=3&requests[3][filtr_typprg]={2}&requests[3][radit]=sledovanost2'

    
    
        url = '{0}?auth={1}&profil=&zobrazeno=&network=&k=1&c='+codectyp+'&no_alternative=&zarizeni=&verze=3&requests[0][ts]=I&requests[0][te]=I&requests[0][archiv]=0&requests[0][seskupit]=true&requests[0][filtr_typprg]={2}'
        url = url+'&requests[0][s]=1398,1399,1402,1401,692,1400,1311,1474,1440,547,1445,1360,34,1259,50,12,13,1371,546,1391,1375,1392'
    url = url.format(url_program,auth,typ)
    
    headers = {
    'Host': main_url,
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Upgrade-Insecure-Requests': '1',
    'Cache-Control': 'max-age=0',
    }
    
    response = sess.get(url, headers=headers, cookies=cj,verify=False)

    data = response.json() if skupina else (response.json())[0]

    data = sorted(data, key=lambda items: items['nazev'])
    data = data[nr::]
    
    timenow = getTstamp()

    kon = nr+25
    
    wielk =len(data)
    
    for link in data:
        

        czasod = link.get('casod',None)

        dod = '[COLOR red][B] (-) [/COLOR][/B]'  if timenow<czasod else ''
        tit = link.get('nazev',None)
        
        wygasa = '[COLOR lightgreen][I]do '+datetime.datetime.fromtimestamp(link.get('platnost',None)).strftime('%Y-%m-%d %H:%M')+'[/COLOR][/I]'
        dod = dod+ ' ' +wygasa if not dod else dod
        
        plot =''
        plot1 = link.get('info1',None)
        plot2 = link.get('info2',None)
        if plot1 or plot2:
            plot = plot1 if plot1 else plot2
        imag = link.get('obr',None)
        rok = link.get('rok_vyroby',None)
        genres = link.get('zanry',None) 

        kateg = ','.join([(x[0].strip()).lower() for x in genres]) if genres else '' 
        mud ='playgonetnagr'
        fold =False
        ispla =True

        
        
        
        
        
        id = link.get( 'id',None)

        href = str(id) if id else ''

        tyt='%s'%(tit)+dod
        
        if 'nejnovejsiId' in link:
            mud ='wideoteka'
            fold =True
            ispla =False
            skupina_hash= link.get( "skupina_hash",None)
            stanice_id = link.get( "stanice_id",None)
            gg = '&filtr_typprg=vse&filtr_skupina_hash=%s&ts=I&te=I&radit=dil&archiv=0&detail2=1&s2=%s'%(str(skupina_hash),str(stanice_id))
            href = typ+'|'+gg
        
        

        add_item(name=PLchar(tyt), url=href, mode=mud, image=imag, folder=fold, IsPlayable=ispla, infoLabels={'plot':PLchar(plot), 'year':rok, 'genre':kateg})
        nr+=1
        if nr==kon:
            break

    if data:
        if nr<wielk:
            typ=typ+'|'+skupina if skupina else typ
            add_item(name='Nast. strona', url=typ, mode='wideoteka', image='', folder=True, IsPlayable=False, infoLabels={}, moviescount=nr+1)

    
        xbmcplugin.endOfDirectory(addon_handle)  
    

def Filtry(typ):

    url = '{0}?auth={1}&profil=&zobrazeno=&network=&k=1&c='+codectyp+'&no_alternative=&zarizeni=&verze=3&filtr_typprg={2}&retfilters=2&seskupit=true&archiv=0&ts=I&te=I'#+requests%5B0%5D%5Bstations%5D=1&requests%5B1%5D%5Bpreklady%5D=1
    url = url.format(url_program,auth,typ)
    headers = {
    'Host': main_url,
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Upgrade-Insecure-Requests': '1',
    'Cache-Control': 'max-age=0',
    }

    response = sess.get(url, headers=headers, cookies=cj,verify=False).json()
    
    
def Radio():

    add_item('film', '[COLOR lightblue][I][B]-    kraj:[/COLOR][/I][/B]        [COLOR lightgreen][B]'+krajn+'[/B] [/COLOR]' , 'DefaultMusicSongs.png', 'kraj', folder=False,fanart=FANART)

    url = '{0}?auth={1}&profil=&zobrazeno=&network=&k=1&c='+codectyp+'&no_alternative=&zarizeni=&verze=3&requests[0][radia]=1&requests[0][filtr_radio_save]=1'
    url = url.format(url_program,auth)
    if krajn!='wszystkie':
        url = url + krajv
        
    headers = {
    'Host': main_url,
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Upgrade-Insecure-Requests': '1',
    'Cache-Control': 'max-age=0',
    }
    
    response = sess.get(url, headers=headers, cookies=cj,verify=False)
    
    radios = (response.json())[0].get('radia',None)
    for radio in radios:
        tyt = radio.get('nazev',None)
        kraj = radio.get('zeme',None)
        
        cod = ''.join(['%s' % (value) for (name, value) in kraj.items()]) if kraj else ''
        plot = tyt
        href = radio.get('url',None)
        fold = False
        ispla = True
        mud = 'playradio'
        
        
        add_item(name=PLchar(tyt), url=href, mode=mud, image=ikona, folder=fold, IsPlayable=ispla, infoLabels={'plot':PLchar(plot), 'code':cod})
    if radios:
        xbmcplugin.endOfDirectory(addon_handle)   


def PlayRadio(stream_url):
    play_item = xbmcgui.ListItem(path=stream_url)

    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def play5(nagr=False):
    ab=getEPG()
    cj.load(COOKIEFILE)
    main_url = addon.getSetting('sitemain')
    auth = addon.getSetting('authkey')
    url_overeni = addon.getSetting('url_overeni')
    url_system = addon.getSetting('url_system')
    url_program = addon.getSetting('url_program')
    
    url = '{0}?auth={1}&profil=&zobrazeno=&network=&k=1&c='+codectyp+'&no_alternative=&zarizeni=&m3u8_test=1&requests[0][stations]=1&requests[1][preklady]=1'#+requests%5B0%5D%5Bstations%5D=1&requests%5B1%5D%5Bpreklady%5D=1
    url = url.format(url_program,auth)
    
    headers = {
        'Host': main_url,
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
    }
    
    response = sess.get(url, headers=headers, cookies=cj,verify=False)
    html = (response.text).replace("\'",'"')
    
    jsdata = response.json()[0]
    if len(jsdata)>0:
        for link in jsdata:
            plot = link.get('popis',None)
            imag = link.get('stanice_logo',None)
            tyt = link.get( 'stanice',None)
            
            foreign = link.get( 'foreign',None)
            hd = link.get( 'hd',None)
            typ_poradi = link.get( 'typ_poradi',None)
            id_typ = link.get( 'id_typ',None)
            typ_preklad = link.get( 'typ_preklad',None)
            id = link.get( 'id',None)
            
            if not nagr:
                ff = CreateEPG((ab.json()).get(str(id),None).get('porady',None))
                plot = ff if ff else plot
                mud = 'playgonet'
                fold = False
                ispla = True
            else:
                mud = 'listnagrania2'
                fold = True
                ispla = False
            href = str(id) if id else ''
            
            add_item(name=PLchar(tyt), url=href, mode=mud, image=imag, folder=fold, IsPlayable=ispla, infoLabels={'plot':PLchar(plot), 'code':typ_preklad})
    
        xbmcplugin.endOfDirectory(addon_handle)    
def CreateEPG(data):
    import datetime
    timenow = getTstamp()
    try:
        # Python 2
        iter_dict = data.iteritems()
    except AttributeError:
        # Python 3
        iter_dict = data.items()

    plot=''

    pokolei = sorted(iter_dict, key=lambda items: items[1]['casod'])
    for a,b in pokolei:
        if not b.get('casdo',None) < timenow:
            tit= b.get('nazev',None) 
            czasod = datetime.datetime.fromtimestamp(b.get('casod',None)).strftime('%H:%M')
            czasdo = datetime.datetime.fromtimestamp(b.get('casdo',None)).strftime('%H:%M')
            plot+='[COLOR khaki]%s - %s[/COLOR] %s[CR]'%(czasod, czasdo, tit)
    return plot

def getTstamp(dif=False):
    import datetime
    import time
    
    
    
    a=datetime.datetime.utcnow()
    readable1 = a.strftime('%Y-%m-%dT%H:%M')
    inne = a.strftime('%Y-%m-%d %H:%M:%S') 
    if dif:
        try:
            date_time_obj=datetime.datetime.strptime(inne, '%Y-%m-%d %H:%M:%S')
        
        except TypeError:
            date_time_obj=datetime.datetime(*(time.strptime(inne, '%Y-%m-%d %H:%M:%S')[0:6]))
        modified_date = date_time_obj + datetime.timedelta(hours=4) 
        inne = 'ts='+quote(str(inne))+'&te='+quote(str(modified_date))
        tst4 =''
    else:    
        try:
            date_time_obj=datetime.datetime.strptime(readable1, '%Y-%m-%dT%H:%M')
        
        except TypeError:
            date_time_obj=datetime.datetime(*(time.strptime(readable1, '%Y-%m-%dT%H:%M')[0:6]))
        
        
            
        def to_timestamp(a_date):
            from datetime import datetime
            try:
                import pytz
            except:
                pass
            if a_date.tzinfo:
                epoch = datetime(1970, 1, 1, tzinfo=pytz.UTC)
                diff = a_date.astimezone(pytz.UTC) - epoch
            else:
                epoch = datetime(1970, 1, 1)
                diff = a_date - epoch
            return int(diff.total_seconds())#*1000    
        tst4 =     int(to_timestamp(date_time_obj))

    return str(inne) if dif else tst4

def getEPG():

    a = getTstamp(dif=True)
    auth = addon.getSetting('authkey')
    url_overeni = addon.getSetting('url_overeni')
    url_system = addon.getSetting('url_system')
    url_program = addon.getSetting('url_program')

    url = '{0}?auth={1}&profil=&zobrazeno=&network=&k=1&c='+codectyp+'&no_alternative=&zarizeni=&verze=3&s=&{2}&info_dily=0'
    url = url.format(url_program,auth,a)
    headers = {
        'Host': main_url,
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
    }

    response = sess.get(url, headers=headers, cookies=cj,verify=False)

    ab = response
    return ab

def PlayGonet(id,nagr=False):

    headers = {
        'Host': main_url,
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
    }

    cj.load(COOKIEFILE)
    if nagr:

        id1,id2 = id.split('_')
        url = '{0}?auth={1}&profil=&zobrazeno=&network=&k=1&c='+codectyp+'&no_alternative=&zarizeni=&verze=3&s={2}&porad={3}&force_stream='
        url = url.format(url_program,auth,id1,id)
        
        
    else:    
        url = '{0}?auth={1}&profil=&zobrazeno=&network=&k=1&c='+codectyp+'&no_alternative=&zarizeni=&m3u8_test=1&s={2}&force_stream=&offset=-1&tdif=1'
        url = url.format(url_program,auth,id)
    
        #
        
        timenow = getTstamp()
        response = sess.get(url, headers=headers, cookies=cj,verify=False)
        jsdata = response.json()
        dt = jsdata.get(id,None).get('porady',None)
        
        porad=''
        for key, value in dt.items():
            if value.get('casod',None) < timenow and timenow < value.get('casdo',None):
                porad = key
                break
        
        a=''
        offs = timenow-value.get('casod',None)
        url=url+'&porad='+porad 
    response = sess.get(url, headers=headers, cookies=cj,verify=False)

    jsdata = response.json()
    xbmc.log('jsdatajsdatajsdata: %s' % str(jsdata), xbmc.LOGINFO)
    try:
        stream = jsdata.get('stream',None).get('auto',None)
    except:
        xbmcgui.Dialog().notification('[B]Uwaga[/B]', '[B]Stream niedostępny[/B]',xbmcgui.NOTIFICATION_INFO, 8000,False) 
        return
    parsed_url = urlparse(stream)
    server = parsed_url.netloc
    
    
    url = url_overeni+'?auth={0}&profil=&token=&server={1}'
    url = url.format(auth,server)
    if nagr:
        url=url+'&stanice='+id1
    headers = {
        'Host': main_url,
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
    }
    response = sess.get(url, headers=headers, cookies=cj,verify=False)
    token=response.text

    if not nagr:
        url =     'https://'+server+'/tt.php'
        response = sess.get(url, headers=headers, cookies=cj,verify=False)
        tt = (response.text).replace(' ','%20').replace('"','')
        
        stream = stream.split('&offset=')[0]
        stream_url = stream+'&tt=%40TT%40&offset=%40OFFSET%40&u='+token+'&offset='+str(offs)+'&tt='+tt+'&a='
    else:
    
    
        stream_url = stream+'&u='+token+'&offset=100&a='
    
    
    xbmc.log('stream_urlstream_urlstream_url: %s' % (stream_url), xbmc.LOGINFO)
    play_item = xbmcgui.ListItem(path=stream_url)
    
    
    if sys.version_info >= (3,0,0):
        play_item.setProperty('inputstream', 'inputstream.adaptive')
    else:
        play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
    
    play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
    
    play_item.setMimeType("application/x-mpegURL")
    
    
    
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
    
def Nagrania():
    numdays = 30
    import datetime
    base = datetime.datetime.today()
    date_list = [(base - datetime.timedelta(days=x)).strftime('%Y-%m-%d') for x in range(numdays)]
    q = xbmcgui.Dialog().select('Wybierz datę', [q for q in date_list])
    data = None
    if q!=-1:

        data = date_list[q]
        addon.setSetting('dataN',str(data))
    
    return data

def ListNagrania(id):

    tit = params.get('title', None)
    rys = params.get('image', None)

    add_item('film', '[COLOR gold] ..--==***** '+tit + ' *****==--..[/COLOR] ' , rys, '  ', folder=False,fanart=FANART)
    add_item('film', '[COLOR lightblue][I][B]-    wybór daty:[/COLOR][/I][/B]        [COLOR lightgreen][B]'+datan+'[/B] [/COLOR]' , 'DefaultMovies.png', 'nagrania', folder=False,fanart=FANART)
    add_item('film', '' , rys, '  ', folder=False,fanart=FANART)


    import datetime

    pocz = datan+ ' 00:00:01'
    kon  = datan+ ' 23:59:59'
    inne = 'ts='+quote(pocz)+'&te='+quote(kon)

    auth = addon.getSetting('authkey')
    url_overeni = addon.getSetting('url_overeni')
    url_system = addon.getSetting('url_system')
    url_program = addon.getSetting('url_program')
    
    url = '{0}?auth={1}&profil=&zobrazeno=&network=&k=1&c='+codectyp+'&no_alternative=&zarizeni=&verze=3&s={2}&{3}&info_dily=0'
    url = url.format(url_program,auth,id, inne)
    headers = {
        'Host': main_url,
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
    }
    
    response = sess.get(url, headers=headers, cookies=cj,verify=False)

    data = (response.json()).get(id,None).get('porady',None)
    try:
        # Python 2
        iter_dict = data.iteritems()
    except AttributeError:
        # Python 3
        iter_dict = data.items()
    
    pokolei = sorted(iter_dict, key=lambda items: items[1]['casod'])
    for a,link in pokolei:

        czasod = datetime.datetime.fromtimestamp(link.get('casod',None)).strftime('%Y-%m-%d %H:%M')
        czasdo = datetime.datetime.fromtimestamp(link.get('casdo',None)).strftime('%H:%M')

        tit = link.get('nazev',None)
        plot =''
        plot1 = link.get('info1',None)
        plot2 = link.get('info2',None)
        if plot1 or plot2:
            plot = plot1 if plot1 else plot2
        imag = link.get('obr',None)
        rok = link.get('rok_vyroby',None)
        genres = link.get('zanry',None) 

        kateg = ','.join([(x[0].strip()).lower() for x in genres]) if genres else '' 
        mud ='playgonetnagr'
        fold =False
        ispla =True

        id = link.get( 'id',None)

        href = str(id) if id else ''

        tyt='[COLOR khaki]%s - %s[/COLOR] %s[CR]'%(czasod, czasdo, tit)

        add_item(name=PLchar(tyt), url=href, mode=mud, image=imag, folder=fold, IsPlayable=ispla, infoLabels={'plot':PLchar(plot), 'year':rok, 'genre':kateg})

    if pokolei:    
        xbmcplugin.endOfDirectory(addon_handle)    

    
def PLchar(char):
    if type(char) is not str:
        char=char.encode('utf-8')
    char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
    char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
    char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
    char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
    char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
    char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
    char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
    char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
    char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
    char = char.replace('&#8217;',"'").replace('&#215;',"x")
    char = char.replace('&#8211;',"-")    
    char = char.replace('&#8230;',"...")    
    char = char.replace('&#8222;','"').replace('&#8221;','"').replace('&#8220;','"')        
    char = char.replace('[&hellip;]',"...")
    char = char.replace('&#038;',"&")    
    char = char.replace('&#039;',"'")
    char = char.replace('&quot;','"').replace('&oacute;','รณ').replace('&rsquo;',"'")
    char = char.replace('&nbsp;',".").replace('&amp;','&').replace('&eacute;','e')

    return char    
    
def router(paramstring):
    args = dict(parse_qsl(paramstring))
    
    if args:
        mode = args.get('mode', None)
    
        if mode == 'testcaptcha':
            testCaptcha()
            
        elif mode  == 'loguj':
            addon.openSettings()
            xbmc.executebuiltin('Container.Refresh()')
            
        elif mode  == 'play5':
            play5()
            
        elif mode  == 'play6':
            play6()
            
        elif mode == 'playgonet':
            PlayGonet(exlink)
            
        elif mode == 'playgonetnagr':
            PlayGonet(exlink,True)
            
        elif mode == 'nagrania':

            Nagrania()
            xbmc.executebuiltin('Container.Refresh()')
            
        elif mode == 'listnagrania':
            play5(True)
            
        elif mode == 'listnagrania2':
            ListNagrania(exlink)
            
        elif mode == 'radio':
            Radio()
            
        elif mode == 'widmenu':
            WideotekaMenu()
            
        elif mode == 'wideoteka':
            Wideoteka(exlink,ilnr)
            
        elif mode == 'listwideoteka':
            ListWideoteka(exlink,ilnr)

        elif mode == 'kraj':
            value=['&requests[0][filtr_radio][zeme][]=poland',""]
            label=["Polska", "wszystkie"]
                

            sel = xbmcgui.Dialog().select('Wybierz kraj:',label)

            if sel>-1:
                av=value[sel]
                av1=label[sel]
                addon.setSetting('krajV',value[sel])
                addon.setSetting('krajN',label[sel])
                xbmc.executebuiltin('Container.Refresh()')

        elif mode == 'playradio':
            PlayRadio(exlink)
                
    else:
        home()    
if __name__ == '__main__':
    router(sys.argv[2][1:])
