# -*- coding: UTF-8 -*-
from __future__ import division
import sys, re, os, io
import six
from six.moves import urllib_parse

import time

import requests
from requests.compat import urlparse

import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc, xbmcvfs

from resources.lib.brotlipython import brotlidec
import json




if six.PY3:
    basestring = str
    unicode = str
    xrange = range
    from resources.lib.cmf3 import parseDOM
else:
    from resources.lib.cmf2 import parseDOM

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(urllib_parse.parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.nfmirror')

PATH            = addon.getAddonInfo('path')
if six.PY2:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
else:
    DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))

RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'../fanart.jpg'
ikona =RESOURCES+'../icon.png'

exlink = params.get('url', None)
nazwa= params.get('title', None)
rys = params.get('image', None)

page = params.get('page',[1])

UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0'
TIMEOUT=15
mainurl = 'https://netflixmirror.com/{}'


proxyport = addon.getSetting('proxyport')
playt = addon.getSetting('play')
headers = {'User-Agent': UA,}
sess = requests.Session()










def build_url(query):
    return base_url + '?' + urllib_parse.urlencode(query)

def add_item(url, name, image, mode, itemcount=1, page=1,fanart=FANART, infoLabels=False,contextmenu=None,IsPlayable=False, folder=False):
    list_item = xbmcgui.ListItem(label=name)
    if IsPlayable:
        list_item.setProperty("IsPlayable", 'True')    
    if not infoLabels:
        infoLabels={'title': name}    
    list_item.setInfo(type="video", infoLabels=infoLabels)    
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': fanart})
    
    if contextmenu:
        out=contextmenu
        list_item.addContextMenuItems(out, replaceItems=True)

    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url = build_url({'mode': mode, 'url' : url, 'page' : page, 'title':name,'image':image}),            
        listitem=list_item,
        isFolder=folder)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def home():

    add_item('movies', '[COLOR khaki][B]Movies[/COLOR][/B]', ikona, "listmenus",fanart=FANART, folder=True)
    add_item('series', '[COLOR khaki][B]Series[/COLOR][/B]', ikona, "listmenus",fanart=FANART, folder=True)
    add_item('series', '[COLOR gold][B]Search[/COLOR][/B]', ikona, "search",fanart=FANART, folder=False,IsPlayable=False)
	
def ListMenus(cd):

	url = mainurl.format(cd)

	html = sess.get(url, headers = headers, verify=False).text
	
	hash_ = re.findall('data-hash="([^"]+)"',html,re.DOTALL)
	hash_ = hash_[0] if hash_ else ''
	addon.setSetting('hash_', str(hash_)) 

	ids = [(a.start(), a.end()) for a in re.finditer('<h2', html)] 
	ids.append( (-1,-1) )
	l = 1
	ok = False
	mod = 'listmovies' 
	ispla = False
	fold = True
	for i in range(len(ids[:-1])):
		subset = html[ ids[i][1]:ids[i+1][0] ]
		tit = ''
		sliders = parseDOM(subset,'div', attrs={'class':"sliderMask.*?"} )[0]
		tit = re.findall('\-title">([^<]+)<',subset,re.DOTALL+re.I)[0]
		dod = 'filmy|' if '/movies' in url else 'serial|'
		filename = DATAPATH+urllib_parse.quote_plus(dod+tit)
		
		save_file(file=filename, data=sliders, isJSON=False)
		add_item(filename, tit, ikona, mod,fanart=FANART, folder=fold, IsPlayable=ispla, infoLabels={'plot':tit})

	xbmcplugin.endOfDirectory(addon_handle) 
	
def save_file(file, data, isJSON=False):
	with io.open(file, 'w', encoding="utf-8") as f:
		if isJSON == True:
			str_ = json.dumps(data,indent=4, sort_keys=True,separators=(',', ': '), ensure_ascii=False)
			f.write(str(str_))
		else:
			f.write(data)
	return
	
	
def load_file(file, isJSON=False):
	import collections
	if not os.path.isfile(file):
		return None
	
	with io.open(file, 'r', encoding='utf-8') as f:
		if isJSON == True:
			return json.load(f, object_pairs_hook=collections.OrderedDict)
		else:
			return f.read() 
def loadinfo(id):
	ts = str(int(time.time()))
	headers = {
		'Host': 'netflixmirror.com',
		'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
		'accept': '*/*',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'x-requested-with': 'XMLHttpRequest',
		'dnt': '1',
		'referer': 'https://netflixmirror.com/movies',
		'sec-fetch-dest': 'empty',
		'sec-fetch-mode': 'cors',
		'sec-fetch-site': 'same-origin',

	}

	params = {
		'id': id,
		't': ts
	}
	
	response = requests.get('https://netflixmirror.com/post.php', params=params, headers=headers, verify=False)#.json()
	cookies = (response.cookies).get_dict()
	save_file(file=DATAPATH+'kukis', data=cookies, isJSON=True)

	return response.json()
def ListSearch(query):
	playt = str(addon.getSetting('play'))
	if playt == '':
		playt = 'default'
	add_item('xxxx', '[B]===== playing: [COLOR khaki]%s[/COLOR] =====[/B]'%(playt), ikona, 'sett',fanart=FANART, folder=False, IsPlayable=False)
	ts = str(int(time.time()))
	headers = {
		'Host': 'netflixmirror.com',
		'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
		'accept': '*/*',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'x-requested-with': 'XMLHttpRequest',
		'dnt': '1',
		'referer': 'https://netflixmirror.com/home?utm_source=home_page',
		'sec-fetch-dest': 'empty',
		'sec-fetch-mode': 'cors',
		'sec-fetch-site': 'same-origin',

	}

	params = {
		's': query,
		't': ts
	}
	
	response = requests.get('https://netflixmirror.com/search.php', params=params, headers=headers, verify=False).json()
	ok = False
	for item in  response.get("searchResult", None):
		id_ = item.get('id', None)
		tit = item.get('t', None)
		data = loadinfo(id_)
		episodes = data.get('episodes', None)
		serial = True if episodes[0] else False

		title = data.get('title', None)
		plot = data.get('desc', None)
		year = data.get('year', None)
		plot = plot if plot else title
		year = year if year else ''

		img = "https://i0.wp.com/img.netflixmirror.com/poster/h/"+id_+".jpg"
		ispla = True
		fold = False
		mod = 'listlinks'

		if serial:
			ispla = False
			fold = True
			mod = 'listserial'

			title = title + ' [COLOR gold][B](series)[/B][/COLOR]'
		h2 = id_+'||'+title
		add_item(h2, title, img, mod,fanart=FANART, folder=fold, IsPlayable=ispla, infoLabels={'plot':plot, 'year':year})
		ok = True
	if ok:
		xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=True)
		
	
def ListMovies(url, pg):
	playt = str(addon.getSetting('play'))
	if playt == '':
		playt = 'default'
	add_item('xxxx', '[B]===== playing: [COLOR khaki]%s[/COLOR] =====[/B]'%(playt), ikona, 'sett',fanart=FANART, folder=False, IsPlayable=False)
	html = load_file(file=url, isJSON=False)
	ids = [(a.start(), a.end()) for a in re.finditer('<div class\s*=\s*"slider\-item', html)] 
	ids.append( (-1,-1) )
	for i in range(len(ids[:-1])):
		subset = html[ ids[i][1]:ids[i+1][0] ]

		id_ = re.findall('data\-post="([^"]+)"',subset,re.DOTALL+re.I)[0]
		data = loadinfo(id_)
		episodes = data.get('episodes', None)
		serial = True if episodes[0] else False

		title = data.get('title', None)
		plot = data.get('desc', None)
		year = data.get('year', None)
		plot = plot if plot else title
		year = year if year else ''
		img = parseDOM(subset,'img', ret="data-src")[0]# data-src
		img = "https://i0.wp.com/img.netflixmirror.com/poster/h/"+id_+".jpg"
		ispla = True
		fold = False
		mod = 'listlinks'

		if serial:
			ispla = False
			fold = True
			mod = 'listserial'

		h2 = id_+'||'+title
		add_item(h2, title, img, mod,fanart=FANART, folder=fold, IsPlayable=ispla, infoLabels={'plot':plot, 'year':year})

	xbmcplugin.endOfDirectory(addon_handle) 
	
def ListSerial(urlk,img):
	url,main_tit = urlk.split('||')

	html = loadinfo(url)
	plot = html.get('desc', None)
	

	main_title = html.get('title', None)

	seasons = html.get('season', None)
	ok = False
	for seas in html.get('season', None):
		ses = seas.get('s', None)
		idses = seas.get('id', None)
		nrepis = seas.get('ep', None)
		
		tit = main_title+ ' - Season %02d '%(int(ses))+ '[%s]'%str(int(nrepis))
		ispla = False
		fold = True
		mod = 'listepisodes'
		h2 = url+'|'+idses+'|'+main_title
		add_item(h2, tit, img, mod,fanart=FANART, folder=fold, IsPlayable=ispla, infoLabels={'plot':plot,'season':ses})
		ok = True
	if ok:
		xbmcplugin.endOfDirectory(addon_handle) 

def ListEpisodes(idmain):
	playt = str(addon.getSetting('play'))
	if playt == '':
		playt = 'default'
	add_item('xxxx', '[B]===== playing: [COLOR khaki]%s[/COLOR] =====[/B]'%(playt), ikona, 'sett',fanart=FANART, folder=False, IsPlayable=False)
	id_,id_ses, main_tit = idmain.split('|')
	headers = {
		'Host': 'netflixmirror.com',
		'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
		'accept': '*/*',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'x-requested-with': 'XMLHttpRequest',
		'dnt': '1',
		'referer': 'https://netflixmirror.com/movies',
		'sec-fetch-dest': 'empty',
		'sec-fetch-mode': 'cors',
		'sec-fetch-site': 'same-origin',

	}
	pg = 1
	npage = True

	ok = False
	while pg:
		ts = str(int(time.time()))
		params = {
			's' : id_ses,
			'series' : id_,
			't' : ts,
			'page' : pg
		}

		response = requests.get('https://netflixmirror.com/episodes.php', params=params, headers=headers, verify=False).json()
		for jsdata in response.get('episodes', None):
			tit = jsdata.get('t', None)
			idepis = jsdata.get('id', None)
			plot = jsdata.get('ep_desc', None)

			img = "https://i0.wp.com/img.netflixmirror.com/epimg/"+idepis+".jpg"
			ses = re.findall('(\d+)',jsdata.get('s', None))
			ses = int(ses[0]) if ses else ''
			epis = jsdata.get('ep', None)
			epis = int(epis) if epis else ''
			ispla = True
			fold = False
			mod = 'listlinks'
			title = tit + ' (S%02dE%02d) '%(int(ses),int(epis))
			czas = jsdata.get('time', None)
			godz = re.findall('(\d+)h',czas,re.DOTALL+re.I)
			godz = int(godz[0])*60 if godz else 0
			min = re.findall('(\d+)m',czas,re.DOTALL+re.I)
			min = int(min[0]) if min else 0 
			durat = int(godz)+int(min)
			add_item(idepis+'||'+main_tit, title, img, mod,fanart=FANART, folder=fold, IsPlayable=ispla, infoLabels={'plot':plot,'season':ses,'episode':epis, 'duration':durat})
			ok = True
		pg = response.get('nextPage', None)
		if not response.get('nextPageShow', None):
			pg = 0
	if ok:
		xbmcplugin.endOfDirectory(addon_handle) 
def pla():
	#tt=True
	if addon.getSetting('play') == 'default':
		return True
	else:
		return False
def ListLinks(urlk, ima = None):

	id_,tit = urlk.split('||')
	headers = {
		'Host': 'netflixmirror.com',
		'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
		'accept': '*/*',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'x-requested-with': 'XMLHttpRequest',
		'dnt': '1',
		'referer': 'https://netflixmirror.com/movies',
		'sec-fetch-dest': 'empty',
		'sec-fetch-mode': 'cors',
		'sec-fetch-site': 'same-origin',

	}


	ts = str(int(time.time()))
	params = {
		'id' : id_,
		't' : tit,
		'tm' : ts
	}

	hash_ = str(addon.getSetting('hash_'))
	
	response = requests.get('https://netflixmirror.com/playlist.php', params=params, headers=headers, verify=False).json()

	source = response[0].get('sources', None)[1].get('file', None)
	urlk = 'https://netflixmirror.com'+source

	kukis = load_file(DATAPATH+'kukis', isJSON=True)
	url = requests.get(urlk, headers=headers, cookies=kukis, verify=False).url
	ref = 'https://netflixmirror.com/series' if '/epimg/' in ima else 'https://netflixmirror.com/movies'
	
	headersx = {

		'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
		'accept': '*/*',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'origin': 'https://netflixmirror.com',
		'dnt': '1',
		'referer': ref,
		'sec-fetch-dest': 'empty',
		'sec-fetch-mode': 'cors',
		'sec-fetch-site': 'cross-site',

	}
	abcv=str(urllib_parse.urlencode(headersx))+'&Cookie='+urllib_parse.urlencode(kukis)
	if pla():
		video_url = url+'|'+abcv
		xbmc.log('@#@playing default', xbmc.LOGINFO) 
	else:
		#if '|' in link:
		#	link = link.split('|')[0]
		video_url = 'http://127.0.0.1:{port}/dd='.format(port=proxyport)+url+'|'+abcv
		xbmc.log('@#@playing via proxy', xbmc.LOGINFO) 
	
	
	
#	import inputstreamhelper
	#video_url = 'http://127.0.0.1:{port}/dd='.format(port=proxyport)+url+'|'+abcv
	#play_item = xbmcgui.ListItem(path=url+'|'+abcv)
	#video_url = url+'|'+abcv
	play_item = xbmcgui.ListItem(path=video_url)
	
	

	#is_helper = inputstreamhelper.Helper('hls')
	#if is_helper.check_inputstream():
	##	#play_item = xbmcgui.ListItem(path=url)
	##
	#if sys.version_info >= (3,0,0):
	#	play_item.setProperty('inputstream', 'inputstream.adaptive')
	#else:
	#	play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
	#
	#
	#$play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
	play_item.setMimeType('application/vnd.apple.mpegurl')
	#play_item.setMimeType('application/x-mpegurl')
	#play_item.setProperty('inputstream.adaptive.manifest_headers', abcv)
	#play_item.setContentLookup(False)
	xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def pla():

	if addon.getSetting('play') == 'default':
		return True
	else:
		return False


def router(paramstring):
	params = dict(urllib_parse.parse_qsl(paramstring))
	if params:    
	
		mode = params.get('mode', None)
	
		if mode == 'listmovies':
			ListMovies(exlink, page)	
		elif mode == 'menu':
			menu(exlink)
		elif mode == 'listsubmenu':
			submenu(exlink)

		elif mode == 'listserial':
			ListSerial(exlink,rys)
		elif mode == 'listlinks':
			ListLinks(exlink, rys)
			
			
		elif mode == 'listepisodes':
			ListEpisodes(exlink)
		elif mode == 'listsearch':
			ListSearch(exlink)
		elif mode == 'search':
			query = xbmcgui.Dialog().input(u'Search: ', type=xbmcgui.INPUT_ALPHANUM)
			if query:   
				query=urllib_parse.quote_plus(query)#(#.replace(' ','%20')
				urlk = build_url({'mode': 'listsearch', 'url' : query})
				xbmc.executebuiltin('Container.Update(%s)'% urlk)

		elif mode == 'listgenre':
			listgenre(exlink)
			
			
		

		elif mode == 'listmenus':
			ListMenus(exlink)
		
		elif mode == 'sett':
			addon.setSetting('play', 'default') if playt == 'proxy' else addon.setSetting('play', 'proxy')
			xbmc.executebuiltin('Container.Refresh')

	else:
		home()
		xbmcplugin.endOfDirectory(addon_handle)    
if __name__ == '__main__':
    router(sys.argv[2][1:])