# coding: UTF-8
import xbmc, xbmcgui

import sys, re

import json
import requests, urllib3

from datetime import datetime, timedelta

import base64


if sys.version_info >= (3,0,0):
# for Python 3
    to_unicode = str

    from urllib.parse import unquote, quote

else:
    # for Python 2
    to_unicode = unicode

    from urllib import unquote, quote

    
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

sess = requests.Session()


        
class Televio:
    def __init__(self, plugin, fanartx, ikona ):

    
        self.plugin = plugin
        self.fanart  = fanartx
        self.ikona  = ikona
        self.datapath = self.plugin.translate_path(self.plugin.get_path('profile'))
        try:
            self.kukis = self.plugin.load_file(self.datapath+'kukis', isJSON=True)
        except:
            self.kukis = {}

        self.UA ='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:93.0) Gecko/20100101 Firefox/93.0'

        self.headers = {
            'User-Agent': self.UA,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',}

        self.login = self.plugin.get_setting('login')
        self.password = self.plugin.get_setting('password')

    def home(self):

        dod, logged = self.logowanie()
    
        if not logged:
            self.plugin.add_item('film', 'Zaloguj', 'DefaultUser.png', "loguj", folder=False,fanart=self.fanart)
        else:
        
            self.plugin.add_item('film', 'Zalogowany jako: '+dod, 'DefaultUser.png', "  ", folder=True, infoLabels={'plot':dod}, fanart=self.fanart)
            self.plugin.add_item('film', 'Telewizja', 'DefaultMovies.png', "listtv", folder=True,fanart=self.fanart)
            self.plugin.add_item('film', 'Radio', 'DefaultMovies.png', "listradio", folder=True,fanart=self.fanart)


        self.plugin.EOD()

        
        
    def request_sess(self, url, method='get', headers = {}    , data = ''    , cookies = {},result=True, json=False, allow=True):
        if method == 'get':
            data = requests.get(url, headers=headers, cookies = cookies, timeout = 15, verify=False, allow_redirects=allow)
        elif method == 'post':
            data = requests.post(url, headers=headers, data = data, cookies = cookies, timeout = 15, verify=False, allow_redirects=allow)
        elif method == 'delete':
            data = requests.delete(url, headers=headers, cookies = cookies, timeout = 15, verify=False, allow_redirects=allow)
        if result and allow:
            
            return data.text if not json else data.json()
        else:
            
            return data
        
        
    def logowanie(self):
        ok = False
    
        if self.login and self.password:

            data = 'username='+quote(self.login)+'&password='+quote(self.password)+'&save=on&login=Zaloguj+si%C4%99&_do=userLoginControl-signInForm-submit'

            self.headers.update({'Content-Type': 'application/x-www-form-urlencoded','Referer': 'https://televio.pl/welcome/login'})
            
            
            resp= self.request_sess('https://televio.pl/welcome/login', 'post', headers=self.headers, data=data,result = False, allow = False)

            src=resp.headers['Location']

            html = self.request_sess(src, 'get', headers=self.headers, cookies = (resp.cookies).get_dict(),result=True)

            
            
            
            if self.login in html:
                self.plugin.save_file(file=self.datapath+'kukis', data=(resp.cookies).get_dict(), isJSON=True)
                return self.login, True

            else:
                self.plugin.notification_dialog('[B]Uwaga[/B]', '[B]Błąd logowania[/B]',xbmcgui.NOTIFICATION_INFO, 8000,False) 

                return None,False
        else:
            self.plugin.notification_dialog('[B]Uwaga[/B]', '[B]Brak danych logowania[/B]',xbmcgui.NOTIFICATION_INFO, 8000,False) 

            return None,False

    def listTV(self):

        html = self.request_sess('https://televio.pl/home', 'get', headers=self.headers, cookies = self.kukis)

        
        
        
        js = re.findall('var options = ({.*?});.*?var PLAYBACK',html,re.DOTALL)
        js = js[0].replace("\'",'"').replace("\n            ",'').replace("\n",'')
        js = json.loads(js)

        drmId = js.get('drmId', None)
        format = js.get('format', None)
        playSession = js.get('playSession', None)
        licenseUrl = (js.get('drmData', None).get('licenseUrl', None)).split('{')[0]

        epglist = self.request_sess('https://televio.pl/playback/epg-playing?playlist=1', 'get', headers=self.headers, cookies = self.kukis, json=True)
        
        livePlaylist = re.findall('var liveplaylist = ({.*?});.*?playback.set',html,re.DOTALL+re.I)
        livePlaylist = livePlaylist[0].replace("\'",'"').replace("\n            ",'').replace("\n",'')
        livePlaylist = json.loads(livePlaylist)

        snippet = re.findall('snippet\-\-channels(.*?)class="grid"',html,re.DOTALL)[0]
        items = re.findall('item_(.*?)".*?url\((\/.*?)\)',snippet,re.DOTALL)
        for x,y in items:
            val=livePlaylist.get(x,None)

            name = val.get('name', None)
            url = val.get('url', None)
            drm = val.get('drm', None)
            canSeek = val.get('canSeek', None)
            plotmain = epglist.get(x, None)#name
            if plotmain:
                p1 = plotmain.get("title", None)
                p2 = re.findall('(\d+\:.*?)$',plotmain.get("startTime", None))[0]
                p3 = re.findall('(\d+\:.*?)$',plotmain.get("endTime", None))[0]
                plot = '[COLOR khaki]%s - %s[/COLOR] : %s '%(p2, p3, p1)
            else:
                plot =''
            kukz=''.join(['%s=%s;'%(cn, cv) for (cn,cv) in (self.kukis).items()])
            hea= '&'.join(['%s=%s' % (xz, yz) for (xz, yz) in (self.headers).items()])  
            id = url+'|'+hea+'&Cookie='+kukz
            
            poster = 'https://televio.pl/cache/logos/%s.png'%x

            if drm:
            
                if sys.version_info >= (3,0,0):
                    ad = base64.b64encode(url.encode(encoding='utf-8', errors='strict'))
                

                    ad = ad.decode(encoding='utf-8', errors='strict')
                else:
                    ad = base64.b64encode(url)
                id +='#'+licenseUrl + ad#base64.b64encode(url)

            mode = 'playvid'
            fold = False
            ispla = True
            if canSeek:
                mode = 'listkeczup'
                fold = True
                ispla = False
                id+='!!'+x
                name+=' [COLOR gold](+)[/COLOR]'
            self.plugin.add_item(name=self.plugin.PLchar(name), url=id, mode=mode, image=poster, folder=fold, IsPlayable=ispla, fanart = self.fanart, infoLabels={'plot':self.plugin.PLchar(plot)})

        self.plugin.EOD()
        
    def ListRadio(self):
        
        url = 'https://televio.pl/home/radio'
        html = self.request_sess(url, 'get', headers=self.headers, cookies = self.kukis)

        js = re.findall('var options = ({.*?});.*?var PLAYBACK',html,re.DOTALL)
        js = js[0].replace("\'",'"').replace("\n            ",'').replace("\n",'')
        js = json.loads(js)

        drmId = js.get('drmId', None)
        format = js.get('format', None)
        playSession = js.get('playSession', None)
        licenseUrl = (js.get('drmData', None).get('licenseUrl', None)).split('{')[0]

        livePlaylist = re.findall('var liveplaylist = ({.*?});.*?playback.set',html,re.DOTALL+re.I)
        livePlaylist = livePlaylist[0].replace("\'",'"').replace("\n            ",'').replace("\n",'')
        livePlaylist = json.loads(livePlaylist)

        snippet = re.findall('snippet\-\-channels(.*?)class="grid"',html,re.DOTALL)[0]
        items = re.findall('item_(.*?)".*?url\((\/.*?)\)',snippet,re.DOTALL)
        for x,y in items:
            val=livePlaylist.get(x,None)
        
            name = val.get('name', None)
            url = val.get('url', None)
            drm = val.get('drm', None)
            canSeek = val.get('canSeek', None)

            plot = name
            kukz=''.join(['%s=%s;'%(cn, cv) for (cn,cv) in (self.kukis).items()])
            hea= '&'.join(['%s=%s' % (xz, yz) for (xz, yz) in (self.headers).items()])  
            id = url+'|'+hea+'&Cookie='+kukz
            
            poster = 'https://televio.pl/cache/logos/%s.png'%x

            if drm:
                if sys.version_info >= (3,0,0):
                    ad = base64.b64encode(url.encode(encoding='utf-8', errors='strict'))
                    ad = ad.decode(encoding='utf-8', errors='strict')
                else:
                    ad = base64.b64encode(url)
                
                id +='#'+licenseUrl + ad#base64.b64encode(url)
            mode = 'playvid'
            fold = False
            ispla = True

            self.plugin.add_item(name=self.plugin.PLchar(name), url=id, mode=mode, image=poster, folder=fold, IsPlayable=ispla, fanart = self.fanart, infoLabels={'plot':self.plugin.PLchar(plot)})

        self.plugin.EOD()
    
    
    
    
    def CreateDays(self):

        out = []
        dnitygodnia = ("poniedziałek","wtorek","środa","czwartek","piątek","sobota","niedziela")
        for a in range(7):
            
        
            x=datetime.utcnow()+timedelta(days=-a)
            day = x.weekday()
        
            dzientyg = dnitygodnia[day]
            
            dzien = (x.strftime('%d.%m.'))
            dzien2 = x.strftime('%Y-%m-%d')
            out.append({'dzien':dzientyg+ ' '+dzien, 'tstamp':dzien2}) 
        return out

    def listKeczup(self, idt, program, img):
        program = program.replace('(+)','(na żywo)')

        id,x = idt.split('!!')
        epglist = self.request_sess('https://televio.pl/playback/epg-playing?playlist=1', 'get', headers=self.headers, cookies = self.kukis, json=True)
        plotmain = epglist.get(x, None)
        p1 = plotmain.get("title", None)
        p2 = re.findall('(\d+\:.*?)$',plotmain.get("startTime", None))[0]
        p3 = re.findall('(\d+\:.*?)$',plotmain.get("endTime", None))[0]
        plot = '[COLOR khaki]%s - %s[/COLOR] : %s '%(p2, p3, p1)

        self.plugin.add_item(name=program , url=id, mode='playvid', image=self.ikona, folder=False, IsPlayable=True, fanart = self.fanart, infoLabels={'plot':plot})
        
        out = self.CreateDays()
        for x in out:
            uid = idt+'!!'+str(x.get('tstamp',None))
            self.plugin.add_item(name=x.get('dzien',None) , url=uid, mode='listekczup2', image=img, folder=True, IsPlayable=False, fanart = self.fanart, infoLabels={})

        self.plugin.EOD()
    
    
    def listKeczup2(self, idts, img):
        
        id,id1,id2 = idts.split('!!')# = 
        url = 'https://televio.pl/epg/part-epg/'+id2+'?limit=12000' 
        html = self.request_sess(url, 'get', headers=self.headers, cookies = self.kukis, result=False)
        data = re.findall('id\="channel\-'+id1+'(.*?)<\/tr>',html.text,re.DOTALL)[0]

        epgs=re.findall('time">([^<]+).*?">(.*?)<\/a>.*?href="([^"]+)',data,re.DOTALL)
        for epg in epgs:

            uid = id+'!!'+epg[2]#+'|'+referenceProgramId
            tit = '[COLOR khaki]%s [/COLOR] %s'%(epg[0], epg[1])
            self.plugin.add_item(name=self.plugin.PLchar(tit) , url=uid, mode='playvid', image=img, folder=False, IsPlayable=True, fanart = self.fanart, infoLabels={'plot':self.plugin.PLchar(tit) })
        self.plugin.EOD()

    def PlayVid(self, id):

        lic_url=''
        license_url = ''
        protocol = 'hls' if not '.mp3' in id else ''
        drm = ''
        mpdurl = id

        if '#' in id:
            if '/home#event' in id:
                mpdurl, id2 = mpdurl.split('!!/home#event%3A')
                mpdurl = re.sub('\/channel\/.+?\?','/timeshift-info?event='+id2+'&',mpdurl)
                mpdurl = re.sub('format\=m3u8','format=m3u8%2Fm3u8',mpdurl)  #  format=m3u8

                url,hea = mpdurl.split('|')#[0]

                html = self.request_sess(url, 'get', headers=self.headers, cookies = self.kukis, json=True)
                mpdurl = html.get( 'url', None)
                if '#' in hea:
                    hea,license_url = hea.split('#')

                    if sys.version_info >= (3,0,0):
                        mpdx = base64.b64encode(mpdurl.encode(encoding='utf-8', errors='strict'))
                        mpdx = mpdx.decode(encoding='utf-8', errors='strict')
                    else:
                        mpdx = base64.b64encode(mpdurl)
                    license_url = re.sub('streamURL=.+?','streamURL='+mpdx,license_url)
                mpdurl+='|'+hea

            else:
            
                mpdurl,license_url = mpdurl.split('#')#
            if license_url:    
                lic_url = license_url+'|Content-Type=|R{SSM}|'
                drm = 'com.widevine.alpha'

        self.plugin.PlayVid(mpdurl, lic_url = lic_url, PROTOCOL = protocol, DRM = drm)    

