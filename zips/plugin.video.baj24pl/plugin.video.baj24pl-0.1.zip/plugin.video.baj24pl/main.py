# -*- coding: UTF-8 -*-
from __future__ import division
import sys,re,os
import six
from six.moves import urllib_parse

import json

import requests
from requests.compat import urlparse

import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc, xbmcvfs
from resources.lib.brotlipython import brotlidec

if six.PY3:
    basestring = str
    unicode = str
    xrange = range
    from resources.lib.cmf3 import parseDOM
else:
    from resources.lib.cmf2 import parseDOM
import resolveurl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(urllib_parse.parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.baj24pl')

PATH            = addon.getAddonInfo('path')
if six.PY2:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
else:
    DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'../fanart.jpg'
ikona =RESOURCES+'../icon.png'

exlink = params.get('url', None)
nazwa= params.get('title', None)
rys = params.get('image', None)

page = params.get('page',[1])#[0]

UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36'
TIMEOUT=15

headers = {'User-Agent': UA,}
sess = requests.Session()

def build_url(query):
    return base_url + '?' + urllib_parse.urlencode(query)

def add_item(url, name, image, mode, itemcount=1, page=1,fanart=FANART, infoLabels=False,contextmenu=None,IsPlayable=False, folder=False):
    list_item = xbmcgui.ListItem(label=name)
    if IsPlayable:
        list_item.setProperty("IsPlayable", 'True')    
    if not infoLabels:
        infoLabels={'title': name}    
    list_item.setInfo(type="video", infoLabels=infoLabels)    
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': fanart})
    
    if contextmenu:
        out=contextmenu
        list_item.addContextMenuItems(out, replaceItems=True)
    else:
        out = []
        out.append(('Informacja', 'XBMC.Action(Info)'),)
        list_item.addContextMenuItems(out, replaceItems=False)

    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url = build_url({'mode': mode, 'url' : url, 'page' : page, 'title':name,'image':image}),            
        listitem=list_item,
        isFolder=folder)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
   

def home():

    add_item('https://bajeczki24.pl/filmy/', 'Filmy', ikona, "listmenu",fanart=FANART, folder=True)
    add_item('https://bajeczki24.pl/bajki/', 'Bajki', ikona, "listmenu",fanart=FANART, folder=True)
    add_item('https://bajeczki24.pl/seriale/', 'Seriale', ikona, "listmenu",fanart=FANART, folder=True)
   # add_item('https://bajeczki24.pl/', 'Szukaj', ikona, "szukaj",fanart=FANART, folder=True)
	
	
def ListMenu(url):

	html = getUrlReqOk(url)
	ids = [(a.start(), a.end()) for a in re.finditer('<a class\s*=\s*"pb\-\d+"', html)]
	ids.append( (-1,-1) )
	out=[]
	
	for i in range(len(ids[:-1])):
		subset = html[ ids[i][1]:ids[i+1][0] ]
		tyt = re.findall('>([^<]+)<\/h2', subset,re.DOTALL)[0]
		href = re.findall('href\s*=\s*"([^"]+)"', subset,re.DOTALL)[0]
		href = 'https://bajeczki24.pl'+href if href.startswith('/') else href
		add_item(href, tyt, ikona, 'listpage',fanart=FANART, folder=True, IsPlayable=False, infoLabels={'plot':tyt})
		
	xbmcplugin.endOfDirectory(addon_handle)  
	
def ListPage(url):

	html = getUrlReqOk(url)
	ids = [(a.start(), a.end()) for a in re.finditer('<article class', html)]
	ids.append( (-1,-1) )
	out=[]
	pagin = parseDOM(html,'nav', attrs={'aria\-label':".*?navigation"})[0]
	
	try:

		li= [(i) for i in parseDOM(pagin,'li') if '&raquo;' in i][0]

	except:
		li = ''
	if li:
		npage = re.findall('href\s*=\s*"([^"]+)"', li,re.DOTALL)
		
	npage = npage[0] if npage else ''
	npage = 'https://bajeczki24.pl'+npage if npage.startswith('/') else npage
	
	for i in range(len(ids[:-1])):
		subset = html[ ids[i][1]:ids[i+1][0] ]
		href = re.findall('href\s*=\s*"([^"]+)"', subset,re.DOTALL)[0]
		href = 'https://bajeczki24.pl'+href if href.startswith('/') else href
		img = parseDOM(subset,'img', ret="src")[0]
		tyt = parseDOM(subset,'h3')[0].replace('&#39;',"'")
		opis = parseDOM(subset,'p')##[0]
		opis = opis[0] if opis else tyt
		opis = opis.replace('&#39;',"'")
		add_item(href, tyt, img, 'playlink',fanart=FANART, folder=False, IsPlayable=True, infoLabels={'plot':opis})
		
	if npage:
		add_item(npage, '>> następna strona >>', ikona, 'listpage',fanart=FANART, folder=True, IsPlayable=False, infoLabels={'plot':'>> następna strona >>'})
		
	xbmcplugin.endOfDirectory(addon_handle) 
	
def ResolveFilemoon(url, refer):

	link =''
	html = getUrlReqOk(url,ref=refer)
	if 'iframe.mediadelivery' in url:

		link=re.findall('source.*?src\s*=\s*"([^"]+)',html,re.DOTALL)

	else:
		from resources.lib import jsunpack
		packer = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)')
		packeds= packer.findall(html)
		stream_url = None
		
		for i in packeds: 
			try: html += jsunpack.unpack(i)
			except: pass
		
		link=re.findall('''sources:\s*\[{file:\s*["'](?P<url>[^"']+)''',html,re.DOTALL)	
		stream_url = ''
		
	if link:
		stream_url = link[0]+'|User-Agent='+UA+'&Referer='+url
		
	return stream_url

def PlayLink(url):

	html = getUrlReqOk(url)
	iframe = parseDOM(html,'iframe', ret="src")
	link =''
	
	if iframe:
		try:
			link = resolveurl.resolve(iframe[0])

		except Exception as som:
			link =''
			xbmc.log('resolveurl error: %s'%str(som), level=xbmc.LOGINFO)
	
	if not link and 'filemoon' in iframe[0]:
		link = ResolveFilemoon(iframe[0], url)
	elif 'iframe.mediadelivery' in iframe[0]:
		link = ResolveFilemoon(iframe[0], url)
	if link:
		Playlin(link)

def getUrlReqOk(url,ref=''):    

    headersok = {
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Connection': 'keep-alive',

    'Referer': ref,}

    content=sess.get(url, headers=headersok,verify=False, timeout=30).content
    if six.PY3:
        content= (content).decode(encoding='utf-8', errors='strict') 
    else:
        content = content
    return content


def PLchar(char):
    if type(char) is not str:
        char = char if six.PY3 else char.encode('utf-8')
    char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
    char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
    char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
    char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
    char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
    char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
    char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
    char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
    char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
    char = char.replace('&#8217;',"'")
    char = char.replace('&#8211;',"-")    
    char = char.replace('&#8230;',"...")    
    char = char.replace('&#8222;','"').replace('&#8221;','"')    
    char = char.replace('[&hellip;]',"...")
    char = char.replace('&#038;',"&")    
    char = char.replace('&#039;',"'")
    char = char.replace('&quot;','"').replace('&oacute;','ó').replace('&rsquo;',"'")
    char = char.replace('&nbsp;',".").replace('&amp;','&').replace('&eacute;','e')
    return char    
def PLcharx(char):
    char=char.replace("\xb9","ą").replace("\xa5","Ą").replace("\xe6","ć").replace("\xc6","Ć")
    char=char.replace("\xea","ę").replace("\xca","Ę").replace("\xb3","ł").replace("\xa3","Ł")
    char=char.replace("\xf3","ó").replace("\xd3","Ó").replace("\x9c","ś").replace("\x8c","Ś")
    char=char.replace("\x9f","ź").replace("\xaf","Ż").replace("\xbf","ż").replace("\xac","Ź")
    char=char.replace("\xf1","ń").replace("\xd1","Ń").replace("\x8f","Ź");
    return char    
 
def Playlin(link) :
    play_item = xbmcgui.ListItem(path=link)

    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)    

 
def router(paramstring):
	params = dict(urllib_parse.parse_qsl(paramstring))
	if params:    
	
		mode = params.get('mode', None)
	
		if mode =='listmenu':
			ListMenu(exlink)

		elif mode =="listpage":
			ListPage(exlink)
			
		elif mode == 'playlink':
			PlayLink(exlink)

	else:
		home()
		xbmcplugin.endOfDirectory(addon_handle)    
if __name__ == '__main__':
    router(sys.argv[2][1:])