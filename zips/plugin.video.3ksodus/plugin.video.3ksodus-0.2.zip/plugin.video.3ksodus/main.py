# -*- coding: UTF-8 -*-

import sys,re,os
import six
from six.moves import urllib_parse

import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc, xbmcvfs
if six.PY3:
    basestring = str
    unicode = str
    xrange = range
    from resources.lib.cmf3 import parseDOM
else:
    from resources.lib.cmf2 import parseDOM
import resolveurl

try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
cache = StorageServer.StorageServer("ccccccccccccccc")

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(urllib_parse.parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.3ksodus')

PATH            = addon.getAddonInfo('path')
if six.PY2:
    DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
else:
    DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
RESOURCES       = PATH+'/resources/'
FANART=RESOURCES+'../fanart.jpg'
ikona =RESOURCES+'../icon.png'

exlink = params.get('url', None)
nazwa= params.get('title', None)
rys = params.get('image', None)

page = params.get('page',[1])#[0]


UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36'
TIMEOUT=15

headers = {'User-Agent': UA,}
sess = requests.Session()

def build_url(query):
    return base_url + '?' + urllib_parse.urlencode(query)

def add_item(url, name, image, mode, itemcount=1, page=1,fanart=FANART, infoLabels=False,contextmenu=None,IsPlayable=False, folder=False):

    if six.PY3:    
        list_item = xbmcgui.ListItem(name)

    else:
        list_item = xbmcgui.ListItem(name, iconImage=image, thumbnailImage=image)

    if IsPlayable:
        list_item.setProperty("IsPlayable", 'True')    
    if not infoLabels:
        infoLabels={'title': name}   
    if contextmenu:
        isp=contextmenu
        list_item.addContextMenuItems(isp, replaceItems=True)
    list_item.setInfo(type="video", infoLabels=infoLabels)    
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': fanart})

    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url = build_url({'mode': mode, 'url' : url, 'page' : page, 'title':name,'image':image}),            
        listitem=list_item,
        isFolder=folder)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
    
def home():
    add_item('', '[COLOR lightblue]Szukaj[/COLOR]', 'DefaultAddonsSearch.png', "search", folder=True)   

def PlayLink(url):

    if 'cda.pl' in url:
        from resources.lib import cdapl 
        stream_url = cdapl.getLinkCda(url)
        if len(stream_url)==1:
            stream_url = stream_url[0][0]
        else:
            if type(stream_url) is list:
                qual = [x[1] for x in stream_url]
                select = xbmcgui.Dialog().select('Wybierz jakość (cda)', qual)
                
                if select>-1:
                    stream_url = stream_url[select][0]
                else:
                    
                    stream_url=''

        link = stream_url
    else:
        try:
            link = resolveurl.resolve(url)
        except Exception as e:
            link =''
            xbmcgui.Dialog().notification('[COLOR red][B]Error[/B][/COLOR]', "[COLOR red][B]"+str(e)+"[/B][/COLOR]", xbmcgui.NOTIFICATION_INFO, 5000)
    if link:
        play_item = xbmcgui.ListItem(path=link)

        play_item.setInfo(type="Video", infoLabels={"title": nazwa,'plot':nazwa})
        
        
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)  
    else:
        host = re.findall(' \- (.*?)$',nazwa,re.DOTALL)[0]
        xbmcgui.Dialog().notification('[COLOR red][B]Error[/B][/COLOR]', "[COLOR red][B]Video from:[/COLOR][COLOR whie]%s[/COLOR][COLOR red]\nis not working.[/B][/COLOR]"%(host), xbmcgui.NOTIFICATION_INFO, 5000)
        sys.exit(1)
def ListToPlay(exlink):

    parts=getListToPlay(exlink)

    items = len(parts)
    
    for f in parts:
        modemy='playLink'
        isplay=True
        fold=False

        add_item(name=f.get('title'), url=f.get('href'), mode=modemy, image=f.get('img'), infoLabels={'plot':f.get('plot')}, itemcount=items,folder=fold, IsPlayable=isplay)    
    
    
    xbmcplugin.endOfDirectory(addon_handle)
    
def getListToPlay(links):
    out=[]

    links = (links.replace('&#39;','')).split(',')

    for linkx in links:
        link,tt = linkx.split('|')
        
        host = (urllib_parse.urlparse(urllib_parse.unquote(link))).netloc
        tyt = nazwa + ' - [COLOR khaki][B]'+tt+'[/COLOR][/B][COLOR gold] - [I]'+host+' [/I][/COLOR]'
        out.append({'title':PLchar(tyt),'href':urllib_parse.unquote(link),'img':rys,'plot':PLchar(tyt)})    
    return out

def ListSubsMov(szuk):

    filmy,seriale=getSubsMov(szuk)

    if filmy or seriale:
        itemz=seriale
        items = len(seriale)
        
        itemz2=filmy
        items2 = len(filmy)

        for f in itemz:

            modemy='listepisodes'
            isplay=False
            fold=True
            add_item(name=f.get('title'), url=f.get('href'), mode=modemy, image=f.get('img'), infoLabels={}, itemcount=items,folder=fold, IsPlayable=isplay)    
            
        for f in itemz2:
            modemy='listtoplay'
            isplay=False
            fold=True
            if 'braklink' in f.get('href'):
                isplay=False
                fold=True
                href = 'brak'
                tit = f.get('title')
                tit += ' - [COLOR pink]brak linków[/COLOR]'
                modemy='xxx'
            else:
                href = f.get('href')
                tit = f.get('title')

            add_item(name=tit, url=href, mode=modemy, image=f.get('img'), infoLabels={}, itemcount=items2,folder=fold, IsPlayable=isplay)    

        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmcgui.Dialog().notification('[COLOR red][B]Info[/B][/COLOR]', "[COLOR red][B]No results.[/B][/COLOR]", xbmcgui.NOTIFICATION_INFO, 5000)
    
def getSubsMov(szuk):
    import json
    out=[]
    outs=[]
    headers = {
        'Host': '3ksodus.com',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
        'accept': 'text/html',#,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
        'dnt': '1',
        'referer': 'https://3ksodus.com/',
        'upgrade-insecure-requests': '1',
        'te': 'trailers',
    }

    response = sess.get('https://3ksodus.com/search?value=%s'%(szuk), headers=headers, verify=False).content

    if six.PY3:
        response= response.decode(encoding='utf-8', errors='strict') 
    response = response.replace("\'",'"').replace('\n','').replace('\\"',"'").replace('\xc2\xae','!').replace('\\u00ae','')

    response = re.sub('(>\s*<p)','><p',response)

    dts = re.findall('(links_array = \[\].*?\);)',response,re.DOTALL)

    for dt in dts:
        if 'movies.push(' in dt:
            movs1 = re.findall('movie\s*=\s*(\{.*?\})',dt,re.DOTALL)
            if movs1:
                mov11=movs1[0]
            mov1 = mov11.replace("\'",'"').replace('\n','').replace('JSON.parse("','').replace('"")','"').replace('links_array','""')
            chng = re.findall('description"\:\s*(".*?\w+.*?"")\,',mov1,re.DOTALL)
            if chng:
    
                chng1 = chng[0].replace('""','"')

                chng2 = re.findall('"(.*?)"$',chng1,re.DOTALL)[0]#.replace('"',"'")
                if '"' in chng2:
                    chng1 = '"'+chng2.replace('"',"'")+'"'

                mov1 = mov1.replace(chng[0],chng1)

            cc=json.loads(mov1)

            ftitle = cc.get('title',None)

            links = re.findall("""\["link"\]\s*=\s*"([^"]+).+?\["version"\]\s*=\s*"([^"]+)""",dt,re.DOTALL)
            href=','.join( [ urllib_parse.quote(i)+'|'+h for i,h in links])

            href = 'braklink' if not links else href

            ll = cc.get('link',None)
            
            imag = re.findall('src="([^"]+)"><p class="title-info" link="%s'%(ll),response,re.DOTALL)[0]
            
            imag = 'https://3ksodus.com'+imag if imag.startswith('/') else imag
            out.append({'title':PLchar(ftitle),'href':href,'img':imag})

    serials = re.findall('episodes_list(.*?movies.push\(serie\);)',response,re.DOTALL)#[0]

    for serial in serials:

        eps = re.findall('(links_array = \[\].*?\);)',serial,re.DOTALL)

        n = ','.join( [ urllib_parse.quote(i) for i in eps])

        serie = re.findall('serie\s*=\s*(\{.*?\})',serial,re.DOTALL)[0].replace('episodes_list','"episodes_list"').replace('JSON.parse("','').replace('"")','"')#.replace('""','"')

        chng = re.findall('description"\:\s*(".*?\w+.*?"")\,',serie,re.DOTALL)
        if chng:
            chng1 = chng[0].replace('""','"')
            serie = serie.replace(chng[0],chng1)

        serie = json.loads(serie)
        href = serie.get("link",None)
        tyt = serie.get("title",None)+' - [B]serial[/B]'
        imag = re.findall('src="([^"]+)"><p class="title-info" link="%s'%(href),response,re.DOTALL)[0]
        imag = 'https://3ksodus.com'+imag if imag.startswith('/') else imag

        outs.append({'title':PLchar(tyt),'href':n,'img':imag})

    return out,outs

def ListEpisodes(exlink):
    episodes= getEpisodes(exlink)
    itemz=episodes
    items = len(episodes)
    for f in itemz:
        modemy='listtoplay'
        isplay=False
        fold=True
        if 'braklink' in f.get('href'):
            isplay=False
            fold=True
            href = 'brak'
            tit = f.get('title')
            tit += ' - [COLOR pink]brak linków[/COLOR]'
            modemy='xxx'
        else:
            href = f.get('href')
            tit = f.get('title')
    
    
        add_item(name=PLchar(tit), url=href, mode=modemy, image=f.get('img'), folder=fold, infoLabels={'title':f.get('title'),'plot':f.get('title')}, itemcount=items, IsPlayable=isplay)        

    xbmcplugin.endOfDirectory(addon_handle)
    
def getEpisodes(url):
    import json
    out=[]

    eps = urllib_parse.unquote(url)

    eps = re.findall('(links_array = \[\].*?\);)',eps,re.DOTALL)
    

    for ep in eps[::-1]:
        links = re.findall("""\["link"\]\s*=\s*"([^"]+).+?\["version"\]\s*=\s*"([^"]+)""",ep,re.DOTALL)
        href=','.join( [ urllib_parse.quote(i)+'|'+h for i,h in links])
        href = 'braklink' if not links else href
        ep = re.findall('episode\s*=\s*({.*?})',ep,re.DOTALL)[0]
        if '"link"' in ep:

            ep = ep.replace('links_array','""').replace('\t','')

            ep=json.loads(ep)

            ff=''
            tit = ep.get('title',None)

            ftitle = PLchar(nazwa).replace(' [B]serial[/B]','')  + ' [COLOR khaki]'+PLchar(tit)+'[/COLOR]'

            out.append({'title':PLchar(ftitle),'href':href,'img':rys})
    return out 

def PLchar(char):
    if type(char) is not str:
        char=char.encode('utf-8')
    char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
    char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
    char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
    char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
    char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
    char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
    char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
    char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
    char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
    char = char.replace('&#8217;',"'")
    char = char.replace('&#8211;',"-")    
    char = char.replace('&#8230;',"...")    
    char = char.replace('&#8222;','"').replace('&#8221;','"')    
    char = char.replace('[&hellip;]',"...")
    char = char.replace('&#038;',"&")    
    char = char.replace('&#039;',"'").replace('&#39;',"'")
    char = char.replace('&quot;','"').replace('&oacute;','ó').replace('&rsquo;',"'")
    char = char.replace('&nbsp;',".").replace('&amp;','&').replace('&eacute;','e')
    return char    
def PLcharx(char):
    char=char.replace("\xb9","ą").replace("\xa5","Ą").replace("\xe6","ć").replace("\xc6","Ć")
    char=char.replace("\xea","ę").replace("\xca","Ę").replace("\xb3","ł").replace("\xa3","Ł")
    char=char.replace("\xf3","ó").replace("\xd3","Ó").replace("\x9c","ś").replace("\x8c","Ś")
    char=char.replace("\x9f","ź").replace("\xaf","Ż").replace("\xbf","ż").replace("\xac","Ź")
    char=char.replace("\xf1","ń").replace("\xd1","Ń").replace("\x8f","Ź");
    return char    
    
def getHistory():
    return cache.get('history_').split(';')

def setHistory(entry):
    historyLits = getHistory()
    if historyLits == ['']:
        historyLits = []
    historyLits.insert(0, entry)
    historyLits =  ';'.join(historyLits[:50])
    cache.set('history_', historyLits)

def remCache(entry):
    history = getHistory()
    history.remove(entry)
    if history:
        cache.set('history_',';'.join(history[:50]))
    else:
        delHistory()

def delHistory():
    cache.delete('history_')
def router(paramstring):
    params = dict(urllib_parse.parse_qsl(paramstring))
    if params:    
    
        mode = params.get('mode', None)
    
        if mode =='listtoplay':
            ListToPlay(exlink)
    
    
        elif mode == 'playLink':
            PlayLink(exlink)
    
        elif mode == 'listsubsmov':
            ListSubsMov(exlink)    
    
        elif mode == 'listepisodes':
            ListEpisodes(exlink)    
        elif mode=='search':
    
            add_item("","[COLOR gold]Nowe Szukanie[/COLOR]",ikona, "noweszukanie",fanart=FANART, folder=False)
            history = getHistory()
            if not history == ['']:
                for entry in history:
                    contextmenux = []
                    contextmenux.append((u'Usuń', 'Container.Refresh(%s)'% build_url({'mode': 'SzukajUsun', 'url' : entry})),) 
                    contextmenux.append((u'Usuń całą historię', 'Container.Update(%s)' % build_url({'mode': 'SzukajUsunAll'})),)
    
                    add_item(entry.replace(' ','+'),entry,ikona,'listsubsmov',fanart=FANART, folder=True,contextmenu=contextmenux)
            xbmcplugin.endOfDirectory(addon_handle,True)
    
        elif mode =='SzukajUsun':
            remCache(exlink)
            xbmc.executebuiltin('Container.Refresh(%s)'%  build_url({'mode': 'search'}))
            xbmcplugin.endOfDirectory(addon_handle,True)
        elif mode == 'SzukajUsunAll':
            delHistory()
            xbmc.executebuiltin('Container.Refresh(%s)'%  build_url({'mode': 'search'}))
            xbmcplugin.endOfDirectory(addon_handle,True)    
                
                
        elif mode =='noweszukanie':
    
            kuery = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu/serialu', type=xbmcgui.INPUT_ALPHANUM)
            if kuery:
    
                setHistory(kuery)
                kuery=kuery.replace(' ','%20')
                xbmc.executebuiltin('Container.Refresh(%s)' % build_url({'mode': 'search'}))

    else:
        home()
        xbmcplugin.endOfDirectory(addon_handle)    
if __name__ == '__main__':
    router(sys.argv[2][1:])