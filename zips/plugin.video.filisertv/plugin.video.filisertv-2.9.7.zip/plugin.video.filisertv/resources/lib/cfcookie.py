# coding: UTF-8
#import sys
#l1111_fi_ = sys.version_info [0] == 2
#l1lll1_fi_ = 2048
#l1l11_fi_ = 7
#def l11l_fi_ (ll_fi_):
#	global l1l11l_fi_
#	l1l1l1_fi_ = ord (ll_fi_ [-1])
#	l11ll_fi_ = ll_fi_ [:-1]
#	l1l_fi_ = l1l1l1_fi_ % len (l11ll_fi_)
#	l11_fi_ = l11ll_fi_ [:l1l_fi_] + l11ll_fi_ [l1l_fi_:]
#	if l1111_fi_:
#		l1llll_fi_ = unicode () .join ([unichr (ord (char) - l1lll1_fi_ - (l1l1l_fi_ + l1l1l1_fi_) % l1l11_fi_) for l1l1l_fi_, char in enumerate (l11_fi_)])
#	else:
#		l1llll_fi_ = str () .join ([chr (ord (char) - l1lll1_fi_ - (l1l1l_fi_ + l1l1l1_fi_) % l1l11_fi_) for l1l1l_fi_, char in enumerate (l11_fi_)])
#	return eval (l1llll_fi_)

import urlparse,cookielib,urllib2,urllib
import time,re,os
url='https://fili.cc/'
cj= cookielib.LWPCookieJar()
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'
userAgent=UA
def createCookie(url,cj=cj,userAgent=UA):
    urlDATA=''
    try:
        class NoRedirection(urllib2.HTTPErrorProcessor):
            def http_response(self, request, response):
                return response
        def ParseJSstring(s):
            try:
                offset=1 if s[0]=='+' else 0
                val = int(eval(s.replace('!+[]','1').replace('!![]','1').replace('[]','0').replace('(','str(')[offset:]))
                return val
            except:
                pass
        if cj==None:
            cj = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(NoRedirection, urllib2.HTTPCookieProcessor(cj))
        opener.addheaders = [('User-Agent', userAgent)]
        try:
            response = opener.open(url)
            result=urlDATA = response.read()
            response.close()
        except urllib2.HTTPError as e:
            result=urlDATA = e.read()
        jschl = re.compile('name="jschl_vc" value="(.+?)"/>').findall(result)[0]
        init = re.compile('setTimeout\\(function\\(\\){\\s*.*?.*:(.*?)};').findall(result)[0]
        builder = re.compile("challenge-form\\'\\);\\s*(.*)a.v").findall(result)[0]
        decryptVal = ParseJSstring(init)
        lines = builder.split(';')
        if jschl:
            for line in lines:
                if len(line)>0 and '=' in line:
                    sections=line.split('=')
                    line_val = ParseJSstring(sections[1])
                    decryptVal = int(eval(str(decryptVal)+sections[0][-1]+str(line_val)))
            answer = decryptVal + len(urlparse.urlparse(url).netloc)
            u=url
            query = '%s/cdn-cgi/l/chk_jschl?jschl_vc=%s&jschl_answer=%s' % (u, jschl, answer)
            if 'type="hidden" name="pass"' in result:
                passval=re.compile('name="pass" value="(.*?)"').findall(result)[0]
                query = '%s/cdn-cgi/l/chk_jschl?pass=%s&jschl_vc=%s&jschl_answer=%s' % (u,urllib.quote_plus(passval), jschl, answer)
                time.sleep(5)
            cookie =''.join(['%s=%s;'%(c.name, c.value) for c in cj])
            opener = urllib2.build_opener(NoRedirection,urllib2.HTTPCookieProcessor(cj))
            opener.addheaders = [('User-Agent', userAgent)]
            opener.addheaders.append(('cookie',cookie))
            opener.addheaders.append(('Referer','https://fili.cc/'))
            try:
                response = opener.open(query)
                response.close()
            except urllib2.HTTPError as e:
                response = e.read()
        return cj
    except:
        return None
def cookieString(COOKIEFILE):
    sc=''
    if os.path.isfile(COOKIEFILE):
        cj = cookielib.LWPCookieJar()
        cj.load(COOKIEFILE)
        for c in cj:
            sc+='%s=%s;'%(c.name, c.value)
    return sc