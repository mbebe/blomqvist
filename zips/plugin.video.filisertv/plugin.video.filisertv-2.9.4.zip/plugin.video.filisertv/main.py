# -*- coding: utf-8 -*-

import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin

base_url		= sys.argv[0]
addon_handle	= int(sys.argv[1])
args			= urlparse.parse_qs(sys.argv[2][1:])
my_adoon		= xbmcaddon.Addon()
PATH			= xbmcaddon.Addon().getAddonInfo('path')
DATAPATH		= xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode('utf-8')
RESOURCES	   = PATH+'/resources/'
blad=RESOURCES+'error.png'
import resources.lib.filicc as filiser
import time,threading
filiser.COOKIEFILE=os.path.join(DATAPATH,'file.cookie')
if 'true' in my_adoon.getSetting('useProxy'):
	filiser.GATE = True
	attent = ' [COLOR gold][Proxy aktywne][/COLOR]'
else:
	filiser.GATE = False
	attent = ''
FANART=''
def addDir(name, url, mode, page=1, iconimage=None, infoLabels=False, IsPlayable=True, isFolder = False, fanart=FANART,itemcount=1):
	u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'page':page})
	if iconimage==None:
		iconimage='DefaultFolder.png'
	liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
	art=dict(zip(art_keys,[iconimage for x in art_keys]))
	liz.setArt(art)
	if not infoLabels:
		infoLabels={'title': name,'plot':name}
	liz.setInfo(type='video', infoLabels=infoLabels)
	if IsPlayable:
		liz.setProperty('IsPlayable', 'true')
	if fanart:
		liz.setProperty('fanart_image',fanart)
	ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=isFolder,totalItems=itemcount)
	xbmcplugin.setContent(addon_handle, 'files')
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = '%R, %Y, %P')
	return ok
def encoded_dict(in_dict):
	out_dict = {}
	for k, v in in_dict.iteritems():
		if isinstance(v, unicode):
			v = v.encode('utf8')
		elif isinstance(v, str):
			v.decode('utf8')
		out_dict[k] = v
	return out_dict
def build_url(query):
	return base_url + '?' + urllib.urlencode(encoded_dict(query))
def getLinksFili(ex_link,downloadFili=False,name='',downPath=''):
	strFili = filiser.getStrFili(ex_link)
	if strFili:
		
		streamFili=''
		t = [ x.get('label') for x in strFili]
		dlg_select = xbmcgui.Dialog().select('Linki', t)
		if dlg_select>-1:
			linkFili = filiser.getStreamsFili(strFili[dlg_select].get('url',''),strFili[dlg_select].get('host',''))
			if linkFili:
				if '.mp4' in linkFili:
					streamFili=linkFili
				else:
					try:
						import resolveurl as urlresolver
						streamFili = urlresolver.resolve(linkFili)
					except Exception,e:
						streamFili=''
						s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link będzie działać?','ResolveUrl ERROR: [%s]'%str(e))
			else:
				s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Link usunięty. Może inny link będzie działać?','')
				xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
				quit()
				xbmcplugin.endOfDirectory(addon_handle,False)
		else:
			quit()
			xbmcplugin.endOfDirectory(addon_handle,False)
		if streamFili:
			if downloadFili:
				filename = xbmcgui.Dialog().input('Nazwa Pliku', name+'.mp4', type=xbmcgui.INPUT_ALPHANUM)
				if filename:
					params = { 'url': streamFili, 'download_path': downPath}
					l1llll11_fi_.downloadFili(filename.encode('utf-8','ignore'), params)
			xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=streamFili))
		else:
			xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
			quit()	
			xbmcplugin.endOfDirectory(addon_handle,False)			
	else:
		xbmcgui.Dialog().notification('Ups...', 'Brak linków', blad, 6000)
def getEpisodes(ex_link):
	serialLinkFili = filiser.getSerialLink(ex_link)
	if 'true' in my_adoon.getSetting('groupEpisodes'):
		select =filiser.getSezonFili(serialLinkFili)
		iconimageFili = serialLinkFili[0].get('img','') if serialLinkFili else ''
		for titleFili in sorted(select.keys()):
			addDir(name=titleFili, url=urllib.quote(str(select[titleFili])), mode='getEpisodesGrouped', iconimage=iconimageFili, infoLabels={}, IsPlayable=False, isFolder=True,itemcount=len(select))
	else:
		for f in serialLinkFili:
			addDir(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True, isFolder=False,itemcount=len(serialLinkFili))
def getEpisodesGrouped(ex_link):
	serialLinkFili = eval(urllib.unquote(ex_link))
	for f in serialLinkFili:
		addDir(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True, isFolder=False,itemcount=len(serialLinkFili))
def login():
	u = my_adoon.getSetting('user')
	p = my_adoon.getSetting('pass')
	l = my_adoon.getSetting('login')
	logged=False
	if u and p and l == 'true':
		logged,nametyp =  filiser.getLogin(u,p)
		if logged:
			addDir(name='[B]Fili.cc  ([COLOR blue]%s[/COLOR]  - [COLOR lightgreen]%s[/COLOR])[/B]'%(nametyp[0],nametyp[1]), url='', mode='',iconimage='', IsPlayable=False)
		else:	
			xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Błąd logowania.')
			addDir(name='[B]Zaloguj[/B]', url='', mode='Opcje', iconimage='',IsPlayable=False)
	else:
		addDir(name='[B]Zaloguj[/B]', url='', mode='Opcje', iconimage='',IsPlayable=False)
		
def ListPopular(url,typ):
	urk='https://fili.cc/'
	if 'filmy' in url:
		typ=typ+':1'
		outItems1,hrefFili =  filiser.getFilmyFili(urk,typ)		
		items=outItems1
		isFolder = False
		IsPlayable = True
		my_mode = 'getLinks'			
	else:
		typ=typ+':0'
		outItems2,hrefFili =  filiser.getFilmyFili(urk,typ)	
		items=outItems2
		isFolder = True
		IsPlayable = False
		my_mode = 'getEpisodes'		
	for f in items: addDir(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,itemcount=len(items))
	xbmcplugin.endOfDirectory(addon_handle)			
		
mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
page = args.get('page',[1])[0]
fverV = my_adoon.getSetting('f_verV')
fverN = my_adoon.getSetting('f_verN') if fverV else 'Wszystkie'
fsortV = my_adoon.getSetting('f_sortV')
fsortN = my_adoon.getSetting('f_sortN') if fsortV else 'Data dodania (od najnowszego)'
sverV = my_adoon.getSetting('s_verV')
sverN = my_adoon.getSetting('s_verN') if sverV else 'Wszystkie'
ssortV = my_adoon.getSetting('s_sortV')
ssortN = my_adoon.getSetting('s_sortN') if ssortV else 'Data dodania (od najnowszego)'

fkatV = my_adoon.getSetting('f_katV')
fkatN = my_adoon.getSetting('f_katN') if fkatV else 'wszystkie'
skatV = my_adoon.getSetting('s_katV')
skatN = my_adoon.getSetting('s_katN') if skatV else 'wszystkie'

if mode is None:
	if filiser.GATE==False:
		login()
	addDir('[COLOR lightblue]Filmy Wersja: [/COLOR] [COLOR whilte]%s[/COLOR]'%fverN,'',mode='setFiltr:f_ver',iconimage='',IsPlayable=False)
	addDir('[COLOR lightblue]Filmy Sortuj  : [/COLOR] [COLOR whilte]%s[/COLOR]'%fsortN,'',mode='setSort:f_sort',iconimage='',IsPlayable=False)
	addDir('[COLOR lightblue]Filmy Gatunki  : [/COLOR] [COLOR whilte]%s[/COLOR]'%fkatN,'',mode='setKat:f_kat',iconimage='',IsPlayable=False)
	addDir('[B][COLOR lightgreen]Filmy[/B][/COLOR]', url='https://fili.cc/filmy', mode='getContent', page=1, iconimage='',IsPlayable=False, isFolder=True, fanart='')
	addDir('  Popularne', url='filmy', mode='listpopular', page=1, iconimage='',IsPlayable=False, isFolder=True, fanart='')	
	addDir('  Ostatnio Dodane', url='https://fili.cc/filmy?&sort_by=date&type=desc', mode='scanMain:f', page=1, iconimage='',IsPlayable=False, isFolder=True, fanart='')
	addDir('[COLOR lightblue]Seriale Sortuj: [/COLOR] [COLOR whilte]%s[/COLOR]'%ssortN,'',mode='setSort:s_sort',iconimage='',IsPlayable=False)
	addDir('[COLOR lightblue]Seriale Gatunki  : [/COLOR] [COLOR whilte]%s[/COLOR]'%skatN,'',mode='setKat:s_kat',iconimage='',IsPlayable=False)
	addDir('[B][COLOR lightgreen]Seriale[/B][/COLOR]', url='https://fili.cc/seriale', mode='getContent', page=1, iconimage='',IsPlayable=False, isFolder=True, fanart='')
	addDir('  Popularne', url='seriale', mode='listpopular', page=1, iconimage='',IsPlayable=False, isFolder=True, fanart='')		
	addDir('  Ostatnio Dodane', url='https://fili.cc/seriale?&sort_by=date&type=desc', mode='scanMain:s', page=1, iconimage='',IsPlayable=False, isFolder=True, fanart='')	
	addDir('[COLOR lightblue]Szukaj[/COLOR]', url='', mode='search', page=1, iconimage='',IsPlayable=False, isFolder=True, fanart='')
	addDir('Opcje'+attent, url='', mode='Opcje', page=1, iconimage='',IsPlayable=False, isFolder=False, fanart='')
	xbmcplugin.setContent(addon_handle, 'videos')	
	xbmcplugin.endOfDirectory(addon_handle)
	
elif 'setFiltr' in mode[0]:
	filtrSetFili = mode[0].split(':')[-1]
	label=['Wszystkie','Polski','Dubbing','Lektor PL','Napisy PL','Napisy Eng','Eng']
	value=['','ver=0','ver=1','ver=2','ver=4','ver=5','ver=6']
	try:
		s = xbmcgui.Dialog().multiselect('Wybierz wersję językową',label)
	except:
		s = xbmcgui.Dialog().select('Wybierz wersję językową',label)
	if isinstance(s,list):
		if 0 in s: s=[0]
		v = '&'.join( [ value[i] for i in s])
		n = ','.join( [ label[i] for i in s])
	else:
		s = s if s>-1 else quit()
		v = value[s]
		n = label[s]
	my_adoon.setSetting(filtrSetFili+'V',v)
	my_adoon.setSetting(filtrSetFili+'N',n)
	xbmc.executebuiltin('XBMC.Container.Refresh')

elif 'setKat' in mode[0]:
	filtrSetFili = mode[0].split(':')[-1]
	label=['wszystkie','akcja', 'animacja', 'anime', 'ba\xc5\x9b\xc5\x84', 'biblijny', 'biograficzny', 'czarna komedia', 'dla dzieci', 'dla m\xc5\x82odzie\xc5\xbcy', 'dokumentalizowany', 'dokumentalny', 'dramat', 'dramat historyczny', 'dramat obyczajowy', 'dramat s\xc4\x85dowy', 'dramat spo\xc5\x82eczny', 'dreszczowiec', 'edukacyjny', 'erotyczny', 'etiuda', 'fabularyzowany dok.', 'familijny', 'fantasy', 'fikcja literacka', 'film-noir', 'gangsterski', 'groteska filmowa', 'historyczny', 'horror', 'karate', 'katastroficzny', 'komedia', 'komedia dokumentalna', 'komedia kryminalna', 'komedia obycz.', 'komedia rom.', 'kostiumowy', 'kr\xc3\xb3tkometra\xc5\xbcowy', 'krymina\xc5\x82', 'melodramat', 'musical', 'muzyczny', 'niemy', 'nowele filmowe', 'obyczajowy', 'poetycki', 'polityczny', 'prawniczy', 'propagandowy', 'przygodowy', 'przyrodniczy', 'psychologiczny', 'p\xc5\x82aszcza i szpady', 'religijny', 'romans', 'satyra', 'sci-fi', 'sensacyjny', 'sportowy', 'surrealistyczny', 'szpiegowski', 'sztuki walki', 'thriller', 'western', 'wojenny']
	value=['','kat=akcja', 'kat=animacja', 'kat=anime', 'kat=ba\xc5\x9b\xc5\x84', 'kat=biblijny', 'kat=biograficzny', 'kat=czarna komedia', 'kat=dla dzieci', 'kat=dla m\xc5\x82odzie\xc5\xbcy', 'kat=dokumentalizowany', 'kat=dokumentalny', 'kat=dramat', 'kat=dramat historyczny', 'kat=dramat obyczajowy', 'kat=dramat s\xc4\x85dowy', 'kat=dramat spo\xc5\x82eczny', 'kat=dreszczowiec', 'kat=edukacyjny', 'kat=erotyczny', 'kat=etiuda', 'kat=fabularyzowany dok.', 'kat=familijny', 'kat=fantasy', 'kat=fikcja literacka', 'kat=film-noir', 'kat=gangsterski', 'kat=groteska filmowa', 'kat=historyczny', 'kat=horror', 'kat=karate', 'kat=katastroficzny', 'kat=komedia', 'kat=komedia dokumentalna', 'kat=komedia kryminalna', 'kat=komedia obycz.', 'kat=komedia rom.', 'kat=kostiumowy', 'kat=kr\xc3\xb3tkometra\xc5\xbcowy', 'kat=krymina\xc5\x82', 'kat=melodramat', 'kat=musical', 'kat=muzyczny', 'kat=niemy', 'kat=nowele filmowe', 'kat=obyczajowy', 'kat=poetycki', 'kat=polityczny', 'kat=prawniczy', 'kat=propagandowy', 'kat=przygodowy', 'kat=przyrodniczy', 'kat=psychologiczny', 'kat=p\xc5\x82aszcza i szpady', 'kat=religijny', 'kat=romans', 'kat=satyra', 'kat=sci-fi', 'kat=sensacyjny', 'kat=sportowy', 'kat=surrealistyczny', 'kat=szpiegowski', 'kat=sztuki walki', 'kat=thriller', 'kat=western', 'kat=wojenny']
	try:
		s = xbmcgui.Dialog().multiselect('Wybierz kategorie',label)
	except:
		s = xbmcgui.Dialog().select('Wybierz kategorię',label)
	if isinstance(s,list):
		if 0 in s: s=[0]
		v = '&'.join( [ value[i] for i in s])
		n = ','.join( [ label[i] for i in s])
	else:
		s = s if s>-1 else quit()
		v = value[s]
		n = label[s]
	my_adoon.setSetting(filtrSetFili+'V',v)
	my_adoon.setSetting(filtrSetFili+'N',n)
	xbmc.executebuiltin('XBMC.Container.Refresh')

	
	
elif mode[0] == 'listpopular':
	mymod=''
	data1=[u'24 h',u'7 dniach',u'30 dniach']
	data2=['day1','day7','day30']
	s = xbmcgui.Dialog().select('Popularne w ostatnich %s'%mymod,data1)		
	d=data2[s] if s>-1 else quit()
	typ = d
	ListPopular(ex_link,typ)
	
elif 'setSort' in mode[0]:
	filtrSetFili = mode[0].split(':')[-1]
	label=[u'Data dodania (od najnowszego)',u'Wyswietleń (od największej)',u'Oceny (od najwyższej) ',u'Data dodania (od najstarszego)',u'Wyswietleń (od najmniejszej)',u'Oceny (od najniższej)']
	value=['sort_by=date&type=desc','sort_by=views&type=desc','sort_by=rate&type=desc','sort_by=date&type=asc','sort_by=views&type=asc','sort_by=rate&type=asc']

	s = xbmcgui.Dialog().select('Sortuj według ',label)
	s = s if s>-1 else quit()
	my_adoon.setSetting(filtrSetFili+'V',value[s])
	my_adoon.setSetting(filtrSetFili+'N',label[s] )
	xbmc.executebuiltin('XBMC.Container.Refresh')

elif mode[0].startswith('scanMain'):
	typ=False
	if 'filmy' in ex_link:
		url = ex_link
		outItems1,hrefFili =  filiser.getFilmyFili(url,typ)
	else:
		url = ex_link
		outItems2,hrefFili =  filiser.getFilmyFili(url,typ)
	filtrSetFili = mode[0].split(':')[-1]
	if 'f' in filtrSetFili:
		items=outItems1
		isFolder = False
		IsPlayable = True
		my_mode = 'getLinks'
	else:
		items=outItems2
		isFolder = True
		IsPlayable = False
		my_mode = 'getEpisodes'
	for f in items: addDir(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,itemcount=len(items))
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0]=='getContent':
	if 'filmy' in ex_link:
		isFolder = False
		IsPlayable = True
		my_mode = 'getLinks'
		sortowanieFili = '&'.join([fverV,fsortV,fkatV]) if fverV or fsortV or fkatV else ''
	else:
		isFolder = True
		IsPlayable = False
		my_mode = 'getEpisodes'
		sortowanieFili = '&'.join([sverV,ssortV,skatV]) if sverV or ssortV or skatV else ''
	url = ex_link+'?'+sortowanieFili if sortowanieFili and 'page' not in ex_link else ex_link
	items,hrefFili =  filiser.getFilmyFili(url)
	if hrefFili[0]:addDir(name='[COLOR gold]<< poprzednia strona <<[/COLOR]', url=hrefFili[0], mode='__page:getContent', page=1, IsPlayable=False)
	for f in items: addDir(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,itemcount=len(items))
	if hrefFili[1]: addDir(name='[COLOR gold]>> następna strona >>[/COLOR]', url=hrefFili[1], mode='__page:getContent', page=1, IsPlayable=False)
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0]=='search':
	query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu/serialu', type=xbmcgui.INPUT_ALPHANUM)
	if query:  	
		moviesFili,serialsFili=filiser.search(query.replace(' ','+') )
		if moviesFili or serialsFili:
			isFolder = False
			IsPlayable = True
			my_mode = 'getLinks'
			for f in moviesFili: addDir(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,itemcount=len(moviesFili))
			isFolder = True
			IsPlayable = False
			my_mode = 'getEpisodes'
			for f in serialsFili: addDir(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,itemcount=len(serialsFili))
			xbmcplugin.endOfDirectory(addon_handle)	
		else:
			xbmcgui.Dialog().ok('[COLOR red]Ups...[/COLOR]','Nic nie znaleziono.','')
			quit()
	else:
		quit()
	#
elif mode[0]=='getEpisodes':
	getEpisodes(ex_link)
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0]=='getEpisodesGrouped':
	getEpisodesGrouped(ex_link)
	xbmcplugin.endOfDirectory(addon_handle)
elif mode[0].startswith('__page:'):
	url = build_url({'mode': mode[0].split(':')[-1], 'foldername': '', 'ex_link' : ex_link, 'page': page})
	xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
elif mode[0] == 'Opcje':
	my_adoon.openSettings()
	xbmc.executebuiltin('XBMC.Container.Refresh()')
elif mode[0] == 'getLinks':
	getLinksFili(ex_link)
	
else:
	xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))


