# -*- coding: utf-8 -*-

import sys,re,os
import urllib2,urllib
import urlparse
import cookielib
import cfcookie
import requests
from CommonFunctions import parseDOM
import xbmc,xbmcgui,xbmcaddon
main_url='https://fili.cc/'
TIMEOUT = 15

GATE = False

my_addon	 = xbmcaddon.Addon()
DATAPATH	 = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
COOKIEFILE = os.path.join(DATAPATH,'fili.cookie')
UA= 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:64.0) Gecko/20100101 Firefox/64.0'

s=requests.Session()
s.headers.update({'User-Agent':  UA})
s.cookies = cookielib.LWPCookieJar(COOKIEFILE)

def _getUrl(url,data=None,cookies=None):
	req = urllib2.Request(url,data)
	req.add_header('User-Agent', UA)
	if cookies:
		req.add_header('Cookie', cookies)
		req.add_header('Referer', main_url)
	try:
		response = urllib2.urlopen(req,timeout=TIMEOUT)
		linkFili = response.read()
		response.close()
	except:
		linkFili=''
	return linkFili
def getUrl(url,data=None):
	global GATE
	content=''
	if GATE==True:
		if 'embed?type' in url:
			content = getUrlProxy(url)
		else:
			content = _getUrlProxy(url)
	else:
	
		if os.path.isfile(COOKIEFILE):
			s.cookies.load(COOKIEFILE, ignore_discard = True)
		kukz=''
		
		
		headers = {
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer': 'https://fili.cc/',
		'Connection': 'keep-alive',
		'Upgrade-Insecure-Requests': '1',}
		content=s.get(url,verify=False).content
	return kukz,content
	
def getLogin(u='',p=''):
	s.cookies.clear()
	main1_url='https://fili.cc/'
	s.headers.update({'User-Agent': UA})
	check = s.get(main1_url,verify=False)	
	main2_url='https://fili.cc/modals/login'
	check = s.get(main2_url,verify=False)
	dataPath=os.path.dirname(COOKIEFILE)
	if not os.path.exists(dataPath):
		os.makedirs(dataPath)
		
	data = 'username=%s&pass=%s'%(u,p)
	headersok = {
		'Host': 'fili.cc',
		'user-agent': UA,
		'accept': '*/*',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'referer': 'https://fili.cc/',
		'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
		'x-requested-with': 'XMLHttpRequest',
		'dnt': '1',
		'te': 'trailers',
	}
	html = s.post('https://fili.cc/user/login', headers=headersok, data=data).content
	
	if html.find('"error":false')>0:
		out=True
		html=s.get(main_url,verify=False).content
		name=re.findall('>Witaj,(.+?)<',html)[0].strip()
		try:
			typ=re.findall('class="premiumColor" title="(.+?)">',html)[0]
		except:
			typ='Darmowe'	
	else:
		out=False
		name=''
		typ=''
	s.cookies.save(COOKIEFILE, ignore_discard = True)
	return out,(name,typ)
	
	
def cf_setCookies(linkFili,cfile):
	cookie = cookielib.LWPCookieJar()
	cookieJar = cfcookie.createCookie(linkFili,cookie,UA)
	dataPath=os.path.dirname(cfile)
	if not os.path.exists(dataPath):
		os.makedirs(dataPath)
	if cookie:
		cookie.save(cfile, ignore_discard = True)
	return cookie
def scanMain(id='premiereMovies'):
	kukz,content = getUrl(main_url)
	ids = [(a.start(), a.end()) for a in re.finditer('<section id="', content)]
	ids.append( (-1,-1) )
	out=[]
	sezOut=[]
	for i in range(len(ids[:-1])):
		subset = content[ ids[i][1]:ids[i+1][0] ]
		if subset.startswith(id):
			items = re.compile('<section class="item">(.*?)</section>',re.DOTALL).findall(subset)
			for item in items:
				href = re.compile('href="(.*?)"').findall(item)
				iconimageFili = re.compile('img src="(.*?)"').findall(item)
				title = re.compile('class="title">(.*?)</').findall(item)
				orgTitle = re.compile('class="title_org">(.*?)</').findall(item)
				if not title:
					title = re.compile('title="(.*?)"').findall(item)
				year = re.compile('<span class="year">(.*?)</span>').findall(item)
				type = re.compile('<span class="type">(.*?)</span>').findall(item)
				rate = re.compile('<span class="num">(.*?)</span>').findall(item)
				plot = re.compile('<p class="desc">(.*?)</p>').findall(item)
				if href and title:
					try: rate = eval('1.0*'+rate[0])*10
					except: rate = ''
					one={
						'href':urlparse.urljoin(main_url,href[0]),
						'img':urlparse.urljoin(main_url,iconimageFili[0]) if iconimageFili else '',
						'title': title[0],
						'originaltitle': orgTitle[0] if orgTitle else '',
						'year': year[0].split('.')[-1] if year else '',
						'plot':plot[0].replace('&hellip;','...') if plot else '',
						'code' : type[0] if type else '',
						'rating' : rate,
						}
					if 'serial' in href[0]:
						sezOut.append(one)
					else:
						out.append(one)
	return out,sezOut
def search(q='ania'):
	kukz,content = getUrl('https://fili.cc/szukaj?q='+q)
	out=[]
	sezOut=[]
	resList = re.compile('<ul id="resultList."(.*?)</ul>',re.DOTALL).findall(content)
	for result in resList:
		items = re.compile('<li>(.*?)</li>',re.DOTALL).findall(result)
		for item in items:
			href = re.compile('href="(.*?)"').findall(item)
			iconimageFili = re.compile('img src="(.*?)"').findall(item)
			title = re.compile('class="title">(.*?)</').findall(item)
			orgTitle = re.compile('class="title_org">(.*?)</').findall(item)
			year = re.compile('<div class="info">.*(\\d{4}).*</div>').findall(item)
			if href and title:
				one={
					'href':urlparse.urljoin(main_url,href[0]),
					'img':urlparse.urljoin(main_url,iconimageFili[0]) if iconimageFili else '',
					'title': title[0],
					'originaltitle': orgTitle[0] if orgTitle else '',
					'year': year[0] if year else '',
					'code' : 'Serial' if 'serial' in href[0] else 'Film',
					}
				if 'serial' in href[0]:
					sezOut.append(one)
				else:
					out.append(one)
	return out,sezOut
def getFilmyFili(url='https://fili.tv/filmy',typ=False):
	kukz,content = getUrl(url)
	prevPage = False
	nextPage = False
	if typ:
		a=typ.split(':')
		ty=a[0]
		k=int(a[1])
		content=parseDOM(content,'div', attrs={'id': ty})[k]
	else:
		content=content
	hrefFili = re.compile('<div class="pagineteBox">(.*?)<div class="clear"></div>',re.DOTALL).findall(content)
	if hrefFili:
		prevPage = re.compile('<a class="pBtn" href="(.*?)" style="padding: 0 10px">Poprzednia</a>').findall(hrefFili[0])
		prevPage = prevPage[0].replace('&amp;','&') if prevPage else False
		nextPage = re.compile('<a class="pBtn" href="(.*?)"').findall(hrefFili[0])
		nextPage = nextPage[-1].replace('&amp;','&') if 'Nast' in hrefFili[0] else False
	items = re.compile('<section class="item">(.*?)</section>',re.DOTALL).findall(content)
	out=[]
	for item in items:
		href = re.compile('href="(.*?)"').findall(item)
		iconimageFili = re.compile('img src="(.*?)"').findall(item)
		title = re.compile('class="title">(.*?)</').findall(item)
		orgTitle = re.compile('class="title_org">(.*?)</').findall(item)
		year = re.compile('<span class="year">(.*?)</span>').findall(item)
		type = re.compile('<span class="type">(.*?)</span>').findall(item)
		rate = re.compile('<span class="num">(.*?)</span>').findall(item)
		plot = re.compile('<p class="desc">(.*?)</p>').findall(item)
		if href and title:
			try: rate = eval(rate[0])*10
			except: rate = ''
			one={
				'href':urlparse.urljoin(main_url,href[0]),
				'img':urlparse.urljoin(main_url,iconimageFili[0]) if iconimageFili else '',
				'title': title[0],
				'originaltitle': orgTitle[0] if orgTitle else '',
				'year': year[0] if year else '',
				'plot':plot[0].replace('&hellip;','...') if plot else '',
				'code' : type[0] if type else '',
				'rating' : rate,
				}
			out.append(one)
	return out,(prevPage,nextPage)
def getSerialLink(url='https://fili.tv/serial/wikingowie/28'):
	kukz,content = getUrl(url)
	out=[]
	iconimageFili = re.compile('<img id="poster" src="(.*?)"').findall(content)
	iconimageFili = urlparse.urljoin(main_url,iconimageFili[0]) if iconimageFili else ''
	plot = re.compile('<section id="desc_box"><h3 id="sub_title">Opis serialu:</h3><div class="clear"></div><p id="desc">(.*?)</p></section>').findall(content)
	plot = plot[0] if plot else ''
	episNameFili=re.compile('class="episodeName" href="(.*?)">(.*?)</a>').findall(content)
	for href,title in episNameFili:
		season = re.findall('s(\\d+)',href,flags=re.I)
		season = int(season[0]) if season else ''
		episode = re.findall('e(\\d+)',href,flags=re.I)
		episode = int(episode[0]) if episode else ''
		one = { 'href'  : urlparse.urljoin(main_url,href),
				'season' : season,
				'episode' : episode,
				'mediatype': 'episode',
				'title' : '%dx%d %s'%(season,episode,title),
				'plot':plot,
				'img': iconimageFili }
		out.append(one)
	return out
def getSezonFili(out):
	sezOut={}
	select = [x.get('season') for x in out]
	for s in set(select):
		sezOut['Sezon %02d'%s]=[out[i] for i, j in enumerate(select) if j == s]
	return sezOut
url='https://fili.cc/film/indiana-jones-i-ostatnia-krucjata-1989/185'
def getStrFili(url):
	if 'serial' in url:
		typ='episode'
	else:
		typ='movie'
	kukz,content = getUrl(url)
	out=[]
	datacad=re.compile('data-code="(.*?)"').findall(content)
	datacad2=re.compile('data-code2="(.*?)"').findall(content)
	tyt=re.compile('<h2 class="title" title="(.+?)">').findall(content)
	tyt1=urllib.quote(tyt[0])
	if datacad2:
		datacad2=datacad2[0]
	else:
		datacad2='undefined'
	subset = re.compile('<ul [style="display:none" ]*data-type="(.*?)">(.*?)</ul>',re.DOTALL).findall(content)
	for lang,strFili in subset:
		subsetLI = re.compile('<li(.*?)</li>').findall(strFili)
		for scanLI in subsetLI:
			data = re.compile('data-ref="(.*?)"').findall(scanLI)			
			quality = re.compile('<span class="quality">(.*?)</span>').findall(scanLI)
			host = re.compile('<span class="host">(.*?)</span>').findall(scanLI)
			if data:
				quality = quality[0] if quality else '?'
				host = host[0] if host else '?'
				one = {'url' : 'https://fili.cc/embed?type='+typ+'&code='+datacad[0]+'&code2='+datacad2+'&salt='+data[0]+'&title='+tyt1+'&title2=',
					'label': '[COLOR blue]%s[/COLOR] | %s | [%s]' %(lang,quality,host),
					'host': host,
					'lang':lang,
					}
				out.append(one)
	return out
proxyUrl2=''
proxyUrl2='http://www.bramka-proxy.pl'
cookiez=''
def getUrlProxy(url,header={}):
	linkFili='{}'
	global cookiez
	if not cookiez:
		req = urllib2.Request(proxyUrl2,data=None,headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'})
		response = urllib2.urlopen(req,timeout=TIMEOUT)
		cookies=response.headers.get('set-cookie',' ').split(' ')[0]
		response.close()
		cookiez = cookies
	else:
		cookies=cookiez
	data = 'u=%s&allowCookies=on'%urllib.quote_plus(url)
	proxyUpdate = proxyUrl2+'/includes/process.php?action=update'
	c=''
	headers={'User-Agent': UA,'Upgrade-Insecure-Requests':1,'Cookie':cookies+c}
	headers.update(header)
	req = urllib2.Request(proxyUpdate,data,headers)
	response = urllib2.urlopen(req,timeout=TIMEOUT)
	linkFili=response.read()
	if 'sslagree' in linkFili:
		proxyUpdate = proxyUrl2+'/includes/process.php?action=sslagree'
		req = urllib2.Request(proxyUpdate,data,headers)
		response = urllib2.urlopen(req,timeout=TIMEOUT)
		linkFili=response.read()
	response.close()
	print 'GATE in USE'
	return linkFili
def _getUrlProxy(url,head={}):
	try:
		proxyUrl ='http://bramka.proxy.net.pl/index.php?q=%s&hl=0'%urllib.quote_plus(url)
		headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36','Upgrade-Insecure-Requests':1,
		'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'}
		if head:
			headers.update(head)
		req = urllib2.Request(proxyUrl,None,headers)
		response = urllib2.urlopen(req,timeout=TIMEOUT)
		l1111111l_fi_ = response.headers.dict
		linkFili=response.read()
		response.close()
	except:
		linkFili=''
		l1111111l_fi_={}
	return linkFili
def getStreamsFili(url,host):
	kukz,content = getUrl(url)
	if 'Link usuni' in content:
		return ''
	linkFili = re.search('b="(http[^"\'<]+)"',content)
	search1 = re.search('b="([^"\'<]+)"',content)
	if linkFili:
		return linkFili.group(1).replace('#WIDTH','320').replace('#HEIGHT','240')
	elif search1:
		search1 = search1.group(1)
		if host=='cda':			 out='https://www.cda.pl'+search1.replace('#WIDTHx','video').replace('#HEIGHT','')
		elif host=='openload':	  out='https://openload.co'+search1.replace('#WIDTHx','').replace('#HEIGHT','')
		elif host=='streamango':	out='https://streamango.com'+search1.replace('#WIDTHx','').replace('#HEIGHT','')
		elif host=='vidoza':		out='https://vidoza.net'+search1.replace('#WIDTHx','').replace('#HEIGHT','')
		elif host=='anyfiles':	  out='https://anyfiles.pl'+search1.replace('#WIDTH','640').replace('#HEIGHT','360')
		else:
			host +='.com'
			out='http://'+host+search1.replace('#WIDTHx','').replace('#HEIGHT','')
		return out
	else:
		strFili = re.findall('[\'"](http[^"\'<]+)[\'"]',content)
		l1111l11l_fi_=['googleapis','//fili.cc','spolecznosci','gstatic.com']
		for l1llll11l1_fi_ in l1111l11l_fi_:
			for one in strFili:
				if l1llll11l1_fi_ in one:
					strFili.pop(strFili.index(one))
					continue
		if strFili:
			return strFili[0].replace('#WIDTH','320').replace('#HEIGHT','240')
	return ''
