# -*- coding: UTF-8 -*-
import sys,re,os
from urlparse import parse_qsl
import base64
import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM
import resolveurl as urlresolver

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.filmowo')

PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=PATH+'fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )
import cdapl
exlink = params.get('url', None)
name= params.get('title', None)
page = params.get('page',[1])[0]

UA='Mozilla/5.0 (Linux; Android 7.0; PLUS Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36'
TIMEOUT=15

headers = {'User-Agent': UA,}
s = requests.Session()

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=1):
	list_item = xbmcgui.ListItem(label=name)

	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')
		
	if not infoLabels:
		infoLabels={'title': name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
	
def home():
	
	add_item('https://filmowo.co/filmy/', 'Filmy', RESOURCES+'Filmy.png', True, "listmovies")	
	add_item('https://filmowo.co/trending/', 'Popularne filmy', RESOURCES+'Filmy.png', True, "listmovies")
	add_item('https://filmowo.co/seriale/', 'Seriale', RESOURCES+'Seriale.png', True, "listserials")
	add_item('https://filmowo.co/trending/', 'Popularne seriale', RESOURCES+'Seriale.png', True, "listserials")	
	add_item('kategorie:', '    Kategorie', '', True, "gatunek")		
	add_item('rok:', '    Rok produkcji', '', True, "gatunek")		
	add_item('', '[COLOR lightblue]Szukaj[/COLOR]', '', True, "search")		

def ListMovies(exlink,page):
	page = int(page) if page else 1	
	links,serials, pagin = getMovies(exlink,page)
	if pagin[0]:
		add_item(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[0])	
	itemz=links
	items = len(links)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
	itemz=serials
	items = len(serials)
	mud='getLinks'
	fold=False
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listepisodes', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)		
	if pagin[1]:
		add_item(name='[COLOR blue]>> Nastepna strona >>>[/COLOR]', url=exlink, mode='__page__M', image='', folder=True, page=pagin[1])
	xbmcplugin.setContent(addon_handle, 'movies')	
	
def ListSerials(exlink,page):
	page = int(page) if page else 1	
	serials,pagin = getSerials(exlink,page)
	if pagin[0]:
		add_item(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=exlink, mode='__page__S', image='', folder=True, page=pagin[0])	
	itemz=serials
	items = len(serials)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listepisodes', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)			
	if pagin[1]:
		add_item(name='[COLOR blue]>> Nastepna strona >>>[/COLOR]', url=exlink, mode='__page__S', image='', folder=True, page=pagin[1])
	xbmcplugin.setContent(addon_handle, 'tvshows')	

def ListEpisodes(exlink,page):
	page = int(page) if page else 1	
	episodes = getEpisodes(exlink,page)	
	itemz=episodes
	items = len(episodes)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)			
	xbmcplugin.setContent(addon_handle, 'tvshows')	
	
def getUrlReq(url):
	content=s.get(url, headers=headers,verify=False).text	
	return content

def getEpisodes(url,page=1):	
	html=getUrlReq(url)
	out=[]
	serout=[]
	try:
		prevpage=False #gr=False
		nextpage=False  # pr=False		
		opisy=parseDOM(html,'div', attrs={'id': "info1"})[0]
		plot=parseDOM(opisy,'p')[0]
		premier=parseDOM(opisy,'span')[1]
		result=parseDOM(html,'div', attrs={'id': "seasons"})[0]
		links = parseDOM(result,'li')	
		for link in links:
			imag = parseDOM(link, 'img', ret='src')[0]
			imag = re.sub('p/w(\d+)', 'p/w500', imag)
			href = parseDOM(link, 'a', ret='href')[0]   
			nam=parseDOM(link,'div', attrs={'class': "numerando"})[0]
			name=nam.split('-')
			tit=parseDOM(link,'a')[1]
			sez=name[0].strip()
			epiz=name[1].strip()
			title='Sez. '+name[0].strip()+', odc.'+name[1].strip()+' : "'+tit+'"'
			out.append({ 'href'  : href,'season' : int(sez),'img': imag,'episode' : int(epiz),'plot':PLchar(plot),'mediatype': 'tvshows','title' : title})					
	except:
		pass
	prevpage = page-1 if page>1 else False
	return out
	
def getSerials(url,page=1):
	if 'trending' in url:
		url = url + 'page/%d' %page +'/?get=tv'
	else:
		url = url + '/page/%d' %page	
	html=getUrlReq(url)
	out=[]
	serout=[]
	try:
		prevpage=False #gr=False
		nextpage=False  # pr=False	
		pages = parseDOM(html, 'div', attrs={'class': "pagination"})[0]
		pag = parseDOM(pages, 'span')[0].split(' z ')
		if page<int(pag[1]):
			nextpage = page+1
		if 'trending' in url:
			result=parseDOM(html,'div', attrs={'class': "items"})[0]
		else:
			result=parseDOM(html,'div', attrs={'id': "archive-content"})[0] 
		links = parseDOM(result, 'article', attrs={'class': "item tvshows"})
		for link in links:	
			imag = parseDOM(link, 'img', ret='src')[0]
			imag = re.sub('p/w(\d+)', 'p/w500', imag)		
			href = parseDOM(link, 'a', ret='href')[0] 
			title = parseDOM(link, 'img', ret='alt')[0] 
			year = parseDOM(link, 'span')[0]
			kategor= parseDOM(link, 'div', attrs={'class': "genres"}) 
			genre=''
			kategs = parseDOM(kategor, 'a')
			for kateg in kategs:
				genre+=kateg+' '
			try:
				plot = parseDOM(link, 'div', attrs={'class': "texto"})[0]
			except:
				plot=''
			ftitle=PLchar(title) 
			year=int(year)
			serout.append({'title':ftitle,'href':href,'img':imag,'plot':PLchar(plot),'year':year, 'genre':genre})	
	except:
		pass 
	prevpage = page-1 if page>1 else False
	return (serout,(prevpage,nextpage))	
		
def getMovies(url,page=1):

	if 'trending' in url:
		url = url + 'page/%d' %page +'/?get=movies'
	else:
		url = url + '/page/%d' %page
	html=getUrlReq(url)
	out=[]
	serout=[]
	try:
		prevpage=False #gr=False
		nextpage=False  # pr=False	
		pages = parseDOM(html, 'div', attrs={'class': "pagination"})[0]
		pag = parseDOM(pages, 'span')[0].split(' z ')
		if page<int(pag[1]):
			nextpage = page+1	
		if 'rok/' in url:
			result=parseDOM(html,'div', attrs={'class': "items"})[0] #archive-content
		elif 'gatunek/' in url:
			result=parseDOM(html,'div', attrs={'class': "items"})[0] #archive-content
		elif 'filmy/' in url:
			result=parseDOM(html,'div', attrs={'id': "archive-content"})[0] #archive-content
		elif 'trending' in url:
			result=parseDOM(html,'div', attrs={'class': "items"})[0] #archive-content
		links = parseDOM(result, 'article', attrs={'class': "item.*?"})
		for link in links:		
			imag = parseDOM(link, 'img', ret='src')[0]
			imag = re.sub('p/w(\d+)', 'p/w500', imag)		
			href = parseDOM(link, 'a', ret='href')[0] #[1]
			title = parseDOM(link, 'img', ret='alt')[0] #[1]
			year = parseDOM(link, 'span')[0]
			kategor= parseDOM(link, 'div', attrs={'class': "genres"}) #class="original_name_sub">
			genre=''
			kategs = parseDOM(kategor, 'a')
			for kateg in kategs:
				genre+=kateg+' '
			try:
				plot = parseDOM(link, 'div', attrs={'class': "texto"})[0]
			except:
				plot=''
			ftitle=PLchar(title) #+' | '+orgtitle
			year=int(year)
			if 'seriale/' in href:
				serout.append({'title':ftitle,'href':href,'img':imag,'plot':PLchar(plot),'year':year, 'genre':genre})
			else:
				out.append({'title':ftitle,'href':href,'img':imag,'plot':PLchar(plot),'year':year, 'genre':genre})
	except:
		pass
	prevpage = page-1 if page>1 else False
	return (out,serout,(prevpage,nextpage))

def getGatunek(exlink):
	out=[]
	url='https://filmowo.co'
	html=getUrlReq(url)
	if 'kategorie:' in exlink:	
		result = parseDOM(html, 'ul', attrs={'class': 'genres scrolling'})
		links = parseDOM(result[0], 'li')
		for link in links:	
			url = str(parseDOM(link, 'a', ret='href')[0])	
			genre = PLchar(parseDOM(link, 'a')[0])	
			ilosc = str(parseDOM(link, 'i')[0])	
			out.append((PLchar(genre)+' ('+PLchar(ilosc)+')', url))
	else:
		result = parseDOM(html, 'ul', attrs={'class': 'releases scrolling'})
		links = parseDOM(result[0], 'li')
		for link in links:	
			url = str(parseDOM(link, 'a', ret='href')[0])	
			year = str(parseDOM(link, 'a')[0])		
			out.append((year, url))		
	return out		
	
def getLinks(exlink):
	links=getVideosOk(exlink)
	if len(links)>1:
		linksAllb = [x.get('host') for x in links]
		s = xbmcgui.Dialog().select('Linki',linksAllb)	
	else:
		s=0
	hrefs=links[s].get('href') if s>-1 else ''
	host=links[s].get('host') if s>-1 else ''	
	stream=hrefs	
	if 'cda.pl' in hrefs:
		stream_urlCDA = cdapl.getLinkCda(hrefs)
		if len(stream_urlCDA)>1:		
			qual = [x[1] for x in stream_urlCDA]
			select = xbmcgui.Dialog().select('Wybierz jakość (cda)', qual)
		else:
			select=0
		if select>-1:
			stream_url = stream_urlCDA[select][0]
		else:
			stream_url=''	
	else:
		try:
			stream_url = urlresolver.resolve(stream)
		except Exception,e:
				stream_url=''
				s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link bedzie działał?','ERROR: %s'%str(e))	
	if stream_url:	
		play_item = xbmcgui.ListItem(path=stream_url)
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
	else:
		play_item = xbmcgui.ListItem(path='')
		xbmcplugin.setResolvedUrl(addon_handle, False, listitem=play_item)		
	
def getVideosOk(url):
	html=getUrlReq(url)	
	result=parseDOM(html,'ul', attrs={'class': "idTabs sourceslist"})[0]
	player=parseDOM(html,'div', attrs={'class': "playex"})[0]
	namehost=re.findall('</b>(\w+).(\w+).</a>',result)
	hrefs=parseDOM(player,'iframe', ret='src')
	co=0
	out=[]
	for href in hrefs:
		url=re.findall('url=(...+)',href)[0]
		host=namehost[co][0].upper()+' - '+namehost[co][1].upper()
		url = base64.b64decode(url)
		film = {'href' : url,'host' : host,}
		out.append(film)
		co+=1
	return out

def search(q='batman'):
	url='https://filmowo.co/?s='+q
	html=getUrlReq(url)	
	out=[]
	serout=[]
	results = parseDOM(html, 'div', attrs={'class': "module"})[0]
	links = parseDOM(results, 'div', attrs={'class': "result-item"})
	for link in links:	
		imag = parseDOM(link, 'img', ret='src')[0]
		imag = re.sub('p/w(\d+)', 'p/w500', imag)	
		year = parseDOM(link, 'span')[1]
		year=int(year)
		href = parseDOM(link, 'a', ret='href')[0] #[1]		
		title = parseDOM(link, 'img', ret='alt')[0]
		if href and title:
			film = {
				'href'   : href,
				'title'  : PLchar(title),
				'plot'   : '',
				'img'    : imag,
				'year'   : year,
					}
			if '/seriale/' in href:
				serout.append(film)	
			else:
				out.append(film)				
	return out,serout	

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&nbsp;',".").replace('&amp;','&')
	return char	

if __name__ == '__main__':
	mode = params.get('mode', None)
	if not mode:
		home()
	elif mode == 'listmovies':
		ListMovies(exlink,page)
	elif mode == 'getLinks':
		getLinks(exlink)	
	elif mode == 'listserials':
		ListSerials(exlink,page)
	elif mode == 'listepisodes':
		ListEpisodes(exlink,page)
	elif mode == 'gatunek':
		data = getGatunek(exlink)
		par= exlink.split('|')
		if data:
			label = [x[0].strip() for x in data]
			url = [x[1].strip() for x in data]
			s = xbmcgui.Dialog().select('Wybierz '+par[0],label)
			if s>-1:
				url = build_url({'mode': 'listmovies', 'foldername': name, 'url' : url[s]})
				xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)				
	elif mode == '__page__M':
		url = build_url({'mode': 'listmovies', 'foldername': name, 'url' : exlink, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
	elif mode == '__page__S':
		url = build_url({'mode': 'listserials', 'foldername': name, 'url' : exlink, 'page' : page})
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
	elif mode=='search':
		query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
		if query:  	
			links,serials=search(query.replace(' ','+') )
			itemz=links
			items = len(links)
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)	
			itemz=serials
			items = len(serials)
			for f in itemz:
				add_item(name=f.get('title'), url=f.get('href'), mode='listepisodes', image=f.get('img'), folder=True, infoLabels=f, itemcount=items)				
		xbmcplugin.setContent(addon_handle, 'movies')		
xbmcplugin.endOfDirectory(addon_handle)
