# -*- coding: utf-8 -*-

import urllib2
import re
import jsunpack as jsunpack
import string
BASEURL='http://www.cda.pl'
TIMEOUT = 5
rot13 = string.maketrans(
    "ABCDEFGHIJKLMabcdefghijklmNOPQRSTUVWXYZnopqrstuvwxyz",
    "NOPQRSTUVWXYZnopqrstuvwxyzABCDEFGHIJKLMabcdefghijklm")

def getUrl(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36')
    if cookies:
        req.add_header('Cookie', cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link =  response.read()
        response.close()
    except:
        link=''
    return link
def _videoLink(content):
    src =''
    evals = re.compile('eval(.*?)\\{\\}\\)\\)',re.DOTALL).findall(content)
    for eval in evals:
        eval=re.sub('  ',' ',eval)
        eval=re.sub('\n','',eval)
        try:
            unp = jsunpack.unpack(eval)
        except:
            unp=''
        if unp:
            unp=re.sub('\\\\','',unp)
            match = re.compile('["\']*file["\']*\\s*:\\s*["\'](.+?)["\'],',  re.DOTALL).search(content)
            match2 = re.compile('["\']file["\']:["\'](.*?\\.mp4)["\']',  re.DOTALL).search(content)
            if match:   src = match.group(1)
            elif match2: src = match2.group(1)
            if src:
                break
    return src

def getLinkCda(url):
  #  "\n    returns \n        - ulr http://....\n        - or list of [('720p', 'http://www.cda.pl/video/1946991f?wersja=720p'),...]\n         \n    "
	added='|Cookie=PHPSESSID=1&Referer=http://static.cda.pl/flowplayer/flash/flowplayer.commercial-3.2.18.swf'
	url=url.split('?wersja=')
	content = getUrl(url[0])
	if 'ebd.cda' in url[0]:
		url=re.findall('href="(.+?)".target=',content)#[0]
		content = getUrl(url[0])
	out=[]
	try:
		qua = re.compile('a data-quality="(.*?)"(.*?)</div>', re.DOTALL).findall(content)
		srce = re.compile('href="(.*?)"', re.DOTALL).findall(qua[0][1])		 
		for h1 in srce:
			if h1.startswith('/'):
				h1=BASEURL+h1
			else:
				h1=h1
			content2 = getUrl(h1)	
			un=_videoLink(content2)
			if str(un).startswith("uggc"):			
				un = (string.translate(un, rot13)).replace('\\','')
				un = un[:-7] + un[-4:]			
				un+=added
			h1=h1.split('wersja=')				
			out.append((un,h1[1]))
	except:
		#content2 = getUrl(h1)	
		un=_videoLink(content)
		if str(un).startswith("uggc"):			
			un = (string.translate(un, rot13)).replace('\\','')
			un = un[:-7] + un[-4:]			
			un+=added
		#h1=h1.split('wersja=')				
		out.append((un,'aut'))		
	return out
