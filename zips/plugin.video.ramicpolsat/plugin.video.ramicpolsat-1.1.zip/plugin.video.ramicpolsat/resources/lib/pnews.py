# -*- coding: utf-8 -*-

import urllib2,urllib,json
import re,os
from urlparse import urlparse
import base64
import cookielib
mainurl= 'www.polsatnews.pl'
TIMEOUT = 10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'
def getUrl(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)
    if cookies:
        req.add_header('Cookie', cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()
        response.close()
    except:
        link=''
    return link
def getContentDir(type='magazyny'):
    if type=='magazyny':
        return getMagazyny()
    elif type == 'dyscypliny':
        return getDyscypliny()
    return []
def getDyscypliny():
    url='http://www.polsatnews.pl/wideo-lista/'
    content = getUrl(url)
    out=[]
    ids = [(a.start(), a.end()) for a in re.finditer('<li class="disciplines-aside-', content)]
    ids.append( (-1,-1) )
    out=[]
    mTitle=['[COLOR blue][B]%s[/B][/COLOR]','[COLOR green][B]%s[/B][/COLOR]']
    sTitle=['   [COLOR lightblue]%s[/COLOR]','   [COLOR lightgreen]%s[/COLOR]']
    for i in range(len(ids[:-1])):
        subset = content[ ids[i][1]:ids[i+1][0] ]
        d = re.compile('<a href="(http://www.polsatsport.pl/wideo-kategoria.*)">(.*)</a>').findall(subset)
        if d:
            maind = d.pop(0)
            t=mTitle[i%2]%PLchar(maind[1])
            out.append({'title':t,'url':maind[0],'img':''})
            for item in d:
                    t=sTitle[i%2]%PLchar(item[1])
                    out.append({'title':t,'url':item[0],'img':''})
    return out
def getContent(url,type='magazyny',nextUrl='',prevUrl='',**kwargs):
    if type == 'magazyny':
        return getMagazyny()
    return []
def getVideoList():
    url='http://www.polsatnews.pl/wideo-lista/'
    content = getUrl(url)
    tds = re.compile('<article class="wideo-news-medium-2 fl-left news-video">(.*?)</article>',re.DOTALL).findall(content)
    out=[]
    nextPage=False
    prevPage=False
    for td in tds:
        href = re.compile('<a href="(.*?)"',).findall(td)
        code = re.compile('<a class="news_label" href=".*?" title=".*?">(.*?)</a>').findall(td)
        title = re.compile('title="(.*?)"').findall(td)
        imag = re.compile('src="(.*?)"').findall(td)
        if href and title:
            h = href[0]
            t = PLchar(title[0].strip())
            i = imag[0] if imag else ''
            c = code[0] if code else ''
            out.append({'url':h,'title':t,'img':i,'code':c})
    return (out,(prevPage,nextPage))
url='http://www.polsatnews.pl/wjdmhk/module34275/page2/wystarczy-chciec_2855/'
url='http://www.polsat.pl/program/idol/'
def getContentVideos(url):
    content = getUrl(url)
    tds = re.compile('<article(.*?)</article>',re.DOTALL).findall(content)
    out=[]
    nextPage=False
    prevPage=False
    for td in tds:
        href = re.compile('<a href="(.*?)"',).findall(td)
        title = re.compile('title="(.*?)"').findall(td)
        imag = re.compile('src="(.*?)"').findall(td)
        if href and title:
            h = href[0]
            t = PLchar(title[0].strip())
            i = imag[0] if imag else ''
            out.append({'url':h,'title':t,'img':i})
    if out:
        nextPage = re.compile('<a href="(.*?)" class="next-page ico"></a>').findall(content)
        nextPage = nextPage[0] if nextPage else False
        nextPage = nextPage.split('data-href="')[-1] if nextPage and 'data-href' in nextPage else nextPage
        prevPage = re.compile('<a href="(.*?)" class="prev-page ico"></a>').findall(content)
        prevPage = prevPage[0] if prevPage else False
        prevPage = prevPage.split('data-href="')[-1] if prevPage and 'data-href' in prevPage else prevPage
    return (out,(prevPage,nextPage))
url='http://www.polsatsport.pl/magazyn/cafe-futbol-06092015-dogrywka_6345047/'
url='http://www.polsatnews.pl/wideo-program/20170429-wydarzenia-2200_6399340/'
def getVideos(url):
    content = getUrl(url)
    v={'msg':'Video link not found or not supported yet'}
    src = re.compile('<source src="(.*?)" type="video/mp4">').findall(content)
    if src:
        v={'msg':'','url':src[0]}
    return v
def test():
    out,pagination = l1l111l1l_po_('http://www.livefootballol.me/video/england/')
    for item in out:
        l1l11ll1l_po_=getVideos(item.get('url'))
        print l1l11ll1l_po_
def _1l11l1ll_po_():
    url='http://www.polsatnews.pl/program/dorotagawrylukzaprasza/'
    content = getUrl(url)
    out=[]
    l11llllll_po_ = re.compile('<ul class="wideo-menu-list">(.*)</ul>',re.DOTALL).findall(content)
    l11llllll_po_ = l11llllll_po_[0] if l11llllll_po_ else ''
    l11lll11l_po_ = re.compile('<a href="(.*?)"').findall(l11llllll_po_)
    for href in l11lll11l_po_:
        if 'http://www.polsatnews.pl/program/' in href:
            print href
            content=getUrl(href)
            title = re.compile('<h1 [^>]*>(.*?)</h1>').findall(content)
            title= title[0] if title else ''
            code= re.compile('<div class="np-date">(.*?)</div>').findall(content)
            code= code[0] if code else ''
            plot = re.compile('<p>(.*?)</p>',re.DOTALL).findall(content)
            plot = plot[0] if plot else ''
            imag=re.compile('<figure>\\s*<img src="(.*?)"',re.DOTALL).findall(content)
            imag = imag[0] if imag else ''
            url = re.compile('jQuery.ajax\\(\\{url: [\'"](http://www.polsatnews.pl/.*?)[\'"]').findall(content)
            if url and title:
                out.append({'title':PLchar(title),'url':url[0],'plot':PLchar(plot),'img':imag,'code':code})
    return out
def scanStrony():
    out=[
        {'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/r4/r412vb83za8aj3jm3mbmzhjsjj6fdui6.jpg',
        'plot': 'Flagowy program Telewizji Polsat i kana\xc5\x82u informacyjnego Polsat News. Zesp\xc3\xb3\xc5\x82 "Wydarze\xc5\x84" przedstawia wiarygodne i obiektywne informacje dotycz\xc4\x85ce bie\xc5\xbc\xc4\x85cych zdarze\xc5\x84. Wiele przedstawionych materia\xc5\x82\xc3\xb3w po\xc5\x9bwi\xc4\x99conych jest problematyce spo\xc5\x82ecznej.&nbsp;',
        'title': 'Wydarzenia','mode':'polsatnews_content',
        'url': 'http://www.polsatnews.pl/wjdmhk/wydarzenia-1850_1491632/'},
        {'img': 'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSVVDeAFFcJiLVgAhAmOGRAAJqKk-7PrBDTte9ea2Fiu-v0PNo2sQ','plot': '','mode':'polsatnews_content_najnowsze',
        'title': ' [COLOR blue]Najnowsze[/COLOR]', 'url': ''},
        {'img': 'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSVVDeAFFcJiLVgAhAmOGRAAJqKk-7PrBDTte9ea2Fiu-v0PNo2sQ','plot': '','mode':'polsatnews_content',
        'title': ' [COLOR blue]Kraj[/COLOR]', 'url': 'http://www.polsatnews.pl/wideo-kategoria/kraj/'},
        {'img': 'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSVVDeAFFcJiLVgAhAmOGRAAJqKk-7PrBDTte9ea2Fiu-v0PNo2sQ','plot': '','mode':'polsatnews_content',
        'title': ' [COLOR blue]\xc5\x9awiat[/COLOR]', 'url': 'http://www.polsatnews.pl/wideo-kategoria/swiat/'},
   #     {'img': 'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSVVDeAFFcJiLVgAhAmOGRAAJqKk-7PrBDTte9ea2Fiu-v0PNo2sQ','plot': '','mode':'polsatnews_content',
   #     'title': ' [COLOR blue]Sport[/COLOR]', 'url': 'http://www.polsatnews.pl/wideo-kategoria/sport/'},
   #     {'img': 'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSVVDeAFFcJiLVgAhAmOGRAAJqKk-7PrBDTte9ea2Fiu-v0PNo2sQ','plot': '','mode':'polsatnews_content',
    #    'title': ' [COLOR blue]Sport[/COLOR]', 'url': 'http://www.polsatsport.pl/wideo/'},
        {'img': 'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSVVDeAFFcJiLVgAhAmOGRAAJqKk-7PrBDTte9ea2Fiu-v0PNo2sQ','plot': '','mode':'polsatnews_content',
        'title': ' [COLOR blue]Biznes[/COLOR]', 'url': 'http://www.polsatnews.pl/wideo-kategoria/biznes/'},
        {'img': 'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSVVDeAFFcJiLVgAhAmOGRAAJqKk-7PrBDTte9ea2Fiu-v0PNo2sQ','plot': '','mode':'polsatnews_content',
        'title': ' [COLOR blue]Technologie i Medycyna[/COLOR]', 'url': 'http://www.polsatnews.pl/wideo-kategoria/nauka-technologie-medycyna/'},
        {'img': 'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSVVDeAFFcJiLVgAhAmOGRAAJqKk-7PrBDTte9ea2Fiu-v0PNo2sQ','plot': '','mode':'polsatnews_content',
        'title': ' [COLOR blue]Rozrywka[/COLOR]', 'url': 'http://www.polsatnews.pl/wideo-kategoria/rozrywka/'},
        ]
    return out
def getProgramy():
    out=[
        {'code': '\xc5\x9aRODA 21:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/71/719v1f1c8a8e9kq2fxyys33d89ddeqv7.jpg',
        'plot': 'Co tydzie\xc5\x84, w \xc5\x9brodowe wieczory, na antenie Polsat News, zaproszeni go\xc5\x9bcie zetr\xc4\x85 si\xc4\x99 w merytorycznej dyskusji po\xc5\x9bwi\xc4\x99conej najwa\xc5\xbcniejszym tematom politycznym, spo\xc5\x82ecznym oraz gospodarczym. Dzi\xc4\x99ki programowi widzowie sami b\xc4\x99d\xc4\x85 mogli wyrobi\xc4\x87 sobie opini\xc4\x99 w sprawie&nbsp;omawianych kwestii. W dniu&nbsp;programu na portalu polsatnews.pl dost\xc4\x99pna jest sonda, dzi\xc4\x99ki&nbsp;kt\xc3\xb3rej&nbsp;u\xc5\xbcytkownicy mog\xc4\x85&nbsp;wskaza\xc4\x87 tego go\xc5\x9bcia, kto przekona\xc5\x82 ich do swoich argument\xc3\xb3w.&nbsp;',
        'title': ' DorotaGawryluk Zaprasza',
        'url': 'http://www.polsatnews.pl/wjdmhk/dorotagawrylukzaprasza_1492502/'},
        {'code': 'PON-PT 18:30',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/4f/4f5efo4as9p125wa9rxiq3ms2enum3xa.jpg',
        'plot': 'Najwa\xc5\xbcniejsze informacje gospodarcze dnia z kraju i ze \xc5\x9bwiata, relacje reporter\xc3\xb3w, znamienici go\xc5\x9bcie - od poniedzia\xc5\x82ku do pi\xc4\x85tku.&nbsp;',
        'title': 'Biznes informacje',
        'url': 'http://www.polsatnews.pl/wjdmhk/biznes-informacje_141142/'},
        {'code': 'CZWARTEK 21:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/dz/dzgxhaziktz5ko2r1deozas4dgc127qk.jpg',
        'plot': '',
        'title': 'Brutalna prawda. Durczok ujawnia',
        'url': 'http://www.polsatnews.pl/wjdmhk/brutalna-prawda-durczok-ujawnia_1492281/'},
        {'code': 'SOBOTA 13:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/ga/ga1fdagxkjugxvs5u1m1mi34kisp285q.jpg',
        'plot': 'W&nbsp;programie pytamy kobiety, w jaki spos\xc3\xb3b to, co dzieje si\xc4\x99 w kraju ma wp\xc5\x82yw na nie same, na ich&nbsp;rodziny, jak zmienia si\xc4\x99 to ich \xc5\xbcycie prywatne i zawodowe. Chcemy si\xc4\x99 dowiedzie\xc4\x87, o czym kobiety chc\xc4\x85 rozmawia\xc4\x87, jak wygl\xc4\x85da ich \xc5\x9bwiat. Kobiety wyr\xc3\xb3\xc5\xbcnia - odmienna od m\xc4\x99skiej - wra\xc5\xbcliwo\xc5\x9b\xc4\x87, spos\xc3\xb3b&nbsp;formu\xc5\x82owania my\xc5\x9bli, stawianie pyta\xc5\x84, ocena zdarze\xc5\x84 i ludzi. Szukanie porozumienia i rozwi\xc4\x85zanie problemu jest bardziej interesuj\xc4\x85ce ni\xc5\xbc sp\xc3\xb3r dla samego sporu. St\xc4\x85d tytu\xc5\x82 programu. Jolanta Fajkowska zaprasza kobiety o r\xc3\xb3\xc5\xbcnych pogl\xc4\x85dach, ekspertki, autorytety, gwiazdy, aby porozmawia\xc4\x87 i z kobiecego punktu widzenia oceni\xc4\x87 mijaj\xc4\x85cy tydzie\xc5\x84.',
        'title': 'Fajka pokoju',
        'url': 'http://www.polsatnews.pl/wjdmhk/fajka-pokoju_1138698/'},
        {'code': 'CODZIENNIE 19:15',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/4d/4dfd2r9cyepmzm7ho39ncbc9djs3f9gs.jpg',
        'plot': 'Program, w kt\xc3\xb3rym Beata Lubecka, Joanna Wrze\xc5\x9bniewska-Sieger&nbsp;i Magdalena Kaliniak&nbsp;przeprowadzaj\xc4\x85 wywiady z najwa\xc5\xbcniejszymi bohaterami dnia. "Go\xc5\x9b\xc4\x87 Wydarze\xc5\x84" nadawany jest codziennie po g\xc5\x82\xc3\xb3wnym wydaniu "Wydarze\xc5\x84" na antenie Polsat News.',
        'title': 'Go\xc5\x9b\xc4\x87 Wydarze\xc5\x84',
        'url': 'http://www.polsatnews.pl/wjdmhk/gosc-wydarzen_1491634/'},
        {'code': 'PON-PT 08:45',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/gm/gm8hoao3wnriigx118a4hkaxf5nkjb4b.jpg',
        'plot': 'Rozmowa z najbardziej wp\xc5\x82ywowymi osobami na temat bie\xc5\xbc\xc4\x85cych wydarze\xc5\x84 spo\xc5\x82eczno-politycznych.',
        'title': 'Graffiti',
        'url': 'http://www.polsatnews.pl/wjdmhk/graffiti_110623/'},
        {'code': 'PON-PT 17:30',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/13/13a493txaejeam3y6esvirfcwccqt9rd.jpg',
        'plot': 'Rozmowa z najbardziej wp\xc5\x82ywowymi osobami na temat aktualnych&nbsp;i najbardziej kontrowersyjnych wydarze\xc5\x84 dnia. Prowadzi: Piotr Witwicki.',
        'title': 'Graffiti Popo\xc5\x82udniowe',
        'url': 'http://www.polsatnews.pl/wjdmhk/graffiti-popoludniowe_1492607/'},
        {'code': 'SOBOTA 18:20',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/jd/jdj3fop9z35856jrieowfsg9sawfhhkj.jpg',
        'plot': 'Program Polsat News podsumowuj\xc4\x85cy najciekawsze wydarzenia z zakresu nauki i nowoczesnych technologii. Wojciech Brzezi\xc5\x84ski i zaproszeni przez niego eksperci zaprezentuj\xc4\x85 najnowsze odkrycia, wynalazki i gad\xc5\xbcety z r\xc3\xb3\xc5\xbcnych dziedzin - od informatyki, przez telekomunikacj\xc4\x99, a\xc5\xbc po medycyn\xc4\x99.',
        'title': 'Horyzont zdarze\xc5\x84',
        'url': 'http://www.polsatnews.pl/wjdmhk/horyzont-zdarzen_211612/'},
        {'code': 'SOBOTA 21:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/8v/8v6tyj5zcshbs11nfbqoiwmh9v4rsnan.jpg',
        'plot': 'Magazyn "Interwencja. Taka jest Polska" to cotygodniowy program na \xc5\xbcywo na antenie Polsat News w soboty o godzinie 21:10. W 40- minutowym programie wracamy do najciekawszych reporta\xc5\xbcy dziennikarzy "Interwencji". W ka\xc5\xbcdym magazynie rozmowa z reporterem wzbogacona o nowe w\xc4\x85tki i dodatkowe informacje na temat naszych reporta\xc5\xbcy. Program prowadz\xc4\x85 Micha\xc5\x82 Beb\xc5\x82o i Marcin \xc5\x81ukasik.',
        'title': 'Interwencja. Taka jest Polska',
        'url': 'http://www.polsatnews.pl/wjdmhk/interwencja-taka-jest-polska_1491636/'},
        {'code': 'POLSAT, PON-PT 16:15, POLSAT NEWS, PON-PT 00:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/jr/jrqrwz6yf7k46mmbv9xqwgc44i5rkp8p.jpg',
        'plot': 'Autorzy programu s\xc4\x85 dla wielu widz\xc3\xb3w ostatni\xc4\x85 szans\xc4\x85 na sprawiedliwo\xc5\x9b\xc4\x87 i pomoc. Ka\xc5\xbcda sprawa jest przez nich dog\xc5\x82\xc4\x99bnie analizowana i \xc5\xbcadna pro\xc5\x9bba nie jest lekcewa\xc5\xbcona.&nbsp;Dzi\xc4\x99ki "Interwencji", m.in.&nbsp;w cyklu materia\xc5\x82\xc3\xb3w broni\xc4\x85cych konsument\xc3\xb3w, widzowie poznaj\xc4\x85 dramatyczne historie&nbsp;os\xc3\xb3b, kt\xc3\xb3re walcz\xc4\x85 z nieuczciwymi pracodawcami i urz\xc4\x99dnikami. Na pomoc mog\xc4\x85 te\xc5\xbc liczy\xc4\x87 ci najs\xc5\x82absi, kt\xc3\xb3rzy bez wsparcia nie&nbsp;s\xc4\x85 w stanie walczy\xc4\x87 o swoje prawa: dzieci, biedne rodziny i prze\xc5\x9bladowane zwierz\xc4\x99ta.',
        'title': 'Interwencja',
        'url': 'http://www.polsatnews.pl/wjdmhk/interwencja_1745/'},
        {'code': 'SOBOTA 17:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/q5/q5ogmyz753hqohff1uyczu3cbytrpwj4.jpg',
        'plot': '"Kultura do Kwadratu" czyli spot\xc4\x99gowana dawka kultury wysokiej i popularnej w autorskim, podw\xc3\xb3jnym wyborze: Anny Sa\xc5\x84czuk i Macieja Ulewicza. Rozmowy kulturalne i dyskusje kulturowe, aktualno\xc5\x9bci i zjawiska. 45 minut o najciekawszych i najoryginalniejszych wydarzeniach w muzyce, teatrze, filmie, sztukach wizualnych i literaturze. Premiera w ka\xc5\xbcd\xc4\x85 sobot\xc4\x99 o godzinie 17.00 na antenie Polsat News 2. Powt\xc3\xb3rka w niedziel\xc4\x99 o godzinie 12:00.',
        'title': 'Kultura do kwadratu',
        'url': 'http://www.polsatnews.pl/wjdmhk/kultura-do-kwadratu_513978/'},
        {'code': 'NIEDZIELA 13:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/pj/pjoyxtdsoyhtp1uqfb967z17bg1r8rkz.jpg',
        'plot': 'Program, w kt\xc3\xb3rym redaktorzy naczelni czo\xc5\x82owych gazet, portali informacyjnych i rozg\xc5\x82o\xc5\x9bni radiowych skomentuj\xc4\x85 najwa\xc5\xbcniejsze wydarzenia minionego tygodnia, dowiemy si\xc4\x99 czym \xc5\xbcy\xc5\x82a opinia publiczna, a najwa\xc5\xbcniejsze wydarzenia zostan\xc4\x85 ocenione okiem znanych komentator\xc3\xb3w i publicyst\xc3\xb3w jakimi bez w\xc4\x85tpienia s\xc4\x85 Naczelni. Program poprowadzi Miros\xc5\x82aw Majeran.',
        'title': 'Naczelni',
        'url': 'http://www.polsatnews.pl/wjdmhk/naczelni_513979/'},
        {'code': 'PONIEDZIA\xc5\x81EK-PI\xc4\x84TEK 15:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/fx/fxsg5gvo3prhx6e4vmo1bkmsf1nn1676.jpg',
        'plot': '',
        'title': 'Newstelegraf',
        'url': 'http://www.polsatnews.pl/wjdmhk/newstelegraf_1491651/'},
        {'code': 'CODZIENNIE 05:58',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/c6/c6vuinxbxeef8ir1w632usbz16xdxhpz.jpg',
        'plot': 'Rozmowy polityczne pochodz\xc4\x85ce z porannego pasma informacyjnego Nowy Dzie\xc5\x84 z Polsat News.',
        'title': 'Nowy Dzie\xc5\x84',
        'url': 'http://www.polsatnews.pl/wjdmhk/nowy-dzien_1491897/'},
        {'code': 'PI\xc4\x84TEK 19:30. Emitowany do 24 czerwca',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/95/95h2m3y3zsctr93uaaepkyiab2kx1mfr.jpg',
        'plot': 'Jaros\xc5\x82aw Guga\xc5\x82a rozmawia z osobami piastuj\xc4\x85cymi kluczowe stanowiska w Polsce o najwa\xc5\xbcniejszych tematach politycznych i spo\xc5\x82ecznych. Program urozmaicaj\xc4\x85 felietony i aktualne dane statystyczne.',
        'title': 'Pa\xc5\x84stwo to My',
        'url': 'http://www.polsatnews.pl/wjdmhk/panstwo-to-my_1491643/'},
        {'code': 'NIEDZIELA 19:30',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/e3/e3fweha2kkurjk5fnhvrx6a32ogfuvjq.jpg',
        'plot': '',
        'title': 'Pa\xc5\x84stwo w Pa\xc5\x84stwie',
        'url': 'http://www.polsatnews.pl/wjdmhk/panstwo-w-panstwie_138472/'},
        {'code': 'NIEDZIELA 17:30',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/g8/g87jwjdj7fk1dfdergw4y6sijaeogbqi.jpg',
        'plot': '',
        'title': 'Poci\xc4\x85g do polityki',
        'url': 'http://www.polsatnews.pl/wjdmhk/pociag-do-polityki_988987/'},
        {'code': 'PON-PT 20:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/3c/3crgw8oywo8d6ta1bo1sufqxv3646u4h.jpg',
        'plot': 'Program publicystyczny, w kt\xc3\xb3rym prowadz\xc4\x85cy&nbsp;- o przeciwstawnych pogl\xc4\x85dach&nbsp;- rozmawiaj\xc4\x85 z go\xc5\x9b\xc4\x87mi, pog\xc5\x82\xc4\x99biaj\xc4\x85c istotne spo\xc5\x82ecznie i cywilizacyjnie tematy, analizuj\xc4\x85c je z r\xc3\xb3\xc5\xbcnych stron. Rozm\xc3\xb3wcami&nbsp;s\xc4\x85 ekonomi\xc5\x9bci, socjologowie, dzia\xc5\x82acze spo\xc5\x82eczni, publicy\xc5\x9bci. Program emitowany od poniedzia\xc5\x82ku do pi\xc4\x85tku o godz. 20:00. Prowadz\xc4\x85 go:&nbsp;Mariusz Ziomecki i Witold Jurasz.',
        'title': 'Prawy do Lewego. Lewy do Prawego',
        'url': 'http://www.polsatnews.pl/wjdmhk/prawy-do-lewego-lewy-do-prawego_513976/'},
        {'code': 'PI\xc4\x84TEK 20:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/r8/r824on2va2d26q7k2hgc1yqma7z14b7c.jpg',
        'plot': 'Program porusza najbardziej istotne problemy ze \xc5\x9bwiata polityki, gospodarki, dotycz\xc4\x85cej m.in. zasad funkcjonowania pa\xc5\x84stwa, pozycji Polski na arenie mi\xc4\x99dzynarodowej. W ka\xc5\xbcdy pi\xc4\x85tkowy&nbsp;wiecz\xc3\xb3r swoich komentarzy udziel\xc4\x85 politycy najwi\xc4\x99kszego formatu, kt\xc3\xb3rzy na co dzie\xc5\x84 przygl\xc4\x85daj\xc4\x85 si\xc4\x99 z boku dynamicznie zmieniaj\xc4\x85cym si\xc4\x99 wydarzeniom. W programie goszcz\xc4\x85 osoby, kt\xc3\xb3re by\xc5\x82y premierami i prezydentami Polski. Program prowadzi Jaros\xc5\x82aw Guga\xc5\x82a.',
        'title': 'Prezydenci i Premierzy',
        'url': 'http://www.polsatnews.pl/wjdmhk/prezydenci-i-premierzy_1491650/'},
        {'code': 'PON-PT 18:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/kk/kk5pw8zqgt5rcnfjew4bgs58ro8cavxg.jpg',
        'plot': 'Rozmowa Polityczna - od poniedzia\xc5\x82ku do pi\xc4\x85tku o godz. 18:00 w Polsat News 2 wydarzenia dnia komentuj\xc4\x85 politycy i eksperci. Program prowadz\xc4\x85 reporterki polityczne Polsat News 2: Dominika D\xc5\x82ugosz i Beata Lubecka.',
        'title': 'Rozmowa polityczna',
        'url': 'http://www.polsatnews.pl/wjdmhk/rozmowa-polityczna_513975/'},
        {'code': 'PON-PT 16:10',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/fm/fm42ou34ixjx9ymkns94oqroxk1e4j57.jpg',
        'plot': 'Przedstawiciele ugrupowa\xc5\x84 partyjnych komentuj\xc4\x85 w studiu lub ze studia w Sejmie bie\xc5\xbc\xc4\x85ce i najwa\xc5\xbcniejsze wydarzenia dnia. Odpowiadaj\xc4\x85 na pytania prowadz\xc4\x85cego &bdquo;Wydarzenia 15:50&rdquo;, wyja\xc5\x9bniaj\xc4\x85, uzupe\xc5\x82niaj\xc4\x85 kwestie dotycz\xc4\x85ce aktualnych temat\xc3\xb3w politycznych, spo\xc5\x82ecznych i gospodarczych, w tym istotnych problem\xc3\xb3w zagranicznych. Program rozpoczyna si\xc4\x99 tu\xc5\xbc&nbsp;po "Wydarzeniach 15:50" i jest ich publicystycznym uzupe\xc5\x82nieniem.&nbsp;',
        'title': 'Rozmowa Wydarze\xc5\x84',
        'url': 'http://www.polsatnews.pl/wjdmhk/rozmowa-wydarzen_1491646/'},
        {'code': 'SOBOTA 20:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/ak/akkiu5yrsyzj78xf1n484qpw1yk28w1f.jpg',
        'plot': '',
        'title': 'Skandali\xc5\x9bci',
        'url': 'http://www.polsatnews.pl/wjdmhk/skandalisci_1491448/'},
        {'code': 'PON-PT 15:35',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/po/po7qrndm1kadjk2sseqr63ybo4pr1aho.jpg',
        'plot': 'Codzienny magazyn najciekawszych informacji zagranicznych. Rozrywka i nauka, przyroda i technologia, kultura oraz tabu. Program dla ludzi ciekawych \xc5\x9bwiata. Emisja codziennie od poniedzia\xc5\x82ku do pi\xc4\x85tku o godz. 15:38 na antenie Polsat News i Polsat News 2. Prowadz\xc4\x85 Magdalena Woro\xc5\x84 i Paulina Witek.',
        'title': '\xc5\x9awiatowidz',
        'url': 'http://www.polsatnews.pl/wjdmhk/swiatowidz_1491637/'},
        {'code': 'PONIEDZIA\xc5\x81EK-\xc5\x9aRODA, PI\xc4\x84TEK 21:30',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/m3/m3ehdtq7spc5e6ncyz1b9j4w3enej9f5.jpg',
        'plot': '',
        'title': 'Tak czy Nie',
        'url': 'http://www.polsatnews.pl/wjdmhk/tak-czy-nie_942396/'},
        {'code': 'PON-CZW 20:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/d3/d325a1bqq96e16qbnkjfc9qgi7hn3j2j.jpg',
        'plot': 'To program publicystyczny Polsat News o&nbsp;najwa\xc5\xbcniejszych wydarzeniach dnia. Stanowi podsumowanie wydarze\xc5\x84 politycznych i spo\xc5\x82ecznych w Polsce oraz na \xc5\x9bwiecie. Daje widzom obiektywny obraz rzeczywisto\xc5\x9bci. Jest pe\xc5\x82en komentarzy i analiz zapraszanych do studia go\xc5\x9bci. Program emitowany jest od poniedzia\xc5\x82ku do czwartku o godzinie 20:00.',
        'title': 'To by\xc5\x82 dzie\xc5\x84',
        'url': 'http://www.polsatnews.pl/wjdmhk/to-byl-dzien_942398/'},
        {'code': 'PON-PT 21:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/dj/djf7sm94qcbww2r1dbtysgc5dn723o69.jpg',
        'plot': 'Magazyn To By\xc5\x82 Dzie\xc5\x84 Na \xc5\x9awiecie. Aktualno\xc5\x9bci polityki mi\xc4\x99dzynarodowej w autorskim wyborze, komentowane przez ekspert\xc3\xb3w. Polsat News 2, poniedzia\xc5\x82ek - pi\xc4\x85tek, godz. 21.00.',
        'title': 'To by\xc5\x82 dzie\xc5\x84 na \xc5\x9bwiecie',
        'url': 'http://www.polsatnews.pl/wjdmhk/to-byl-dzien-na-swiecie_1491638/'},
        {'code': 'SOBOTA 10:30',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/g4/g41pb3p3bivrwxstyey4b2t9jdq5otad.jpg',
        'plot': 'W programie TOP WTOP z przymru\xc5\xbceniem oka przygl\xc4\x85damy si\xc4\x99 wydarzeniom z kraju i ze \xc5\x9bwiata, wyci\xc4\x85gaj\xc4\x85c przy okazji najwi\xc4\x99ksze "topy" i "wtopy" tygodnia. W magazynie prezentowane s\xc4\x85 barwne, intryguj\xc4\x85ce lub zaskakuj\xc4\x85ce wypowiedzi m.in. polityk\xc3\xb3w, ekspert\xc3\xb3w, celebryt\xc3\xb3w oraz zdarzenia i sytuacje z ich udzia\xc5\x82em. Satyryczny przegl\xc4\x85d tygodnia uzupe\xc5\x82nia rozmowa z nietuzinkowymi go\xc5\x9b\xc4\x87mi. Zapraszamy w ka\xc5\xbcd\xc4\x85 sobot\xc4\x99 o 10:30 do Polsat News.',
        'title': 'Top wtop',
        'url': 'http://www.polsatnews.pl/wjdmhk/top-wtop-_1491639/'},
        {'code': 'PONIEDZIA\xc5\x81EK-PI\xc4\x84TEK 22:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/i8/i8j24u6xbqcvu6k72w34j412kvcgvs3s.jpg',
        'plot': '',
        'title': 'Widzimisi\xc4\x99',
        'url': 'http://www.polsatnews.pl/wjdmhk/widzimisie_513977/'},
        {'code': 'PONIEDZIA\xc5\x81EK-PI\xc4\x84TEK',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/3u/3uhk2anurzoxo4m6crnwwke143gjce2m.jpg',
        'plot': 'Flagowy program Telewizji Polsat i kana\xc5\x82u informacyjnego Polsat News. Zesp\xc3\xb3\xc5\x82 "Wydarze\xc5\x84" przedstawia wiarygodne i obiektywne informacje dotycz\xc4\x85ce bie\xc5\xbc\xc4\x85cych zdarze\xc5\x84. Wiele przedstawionych materia\xc5\x82\xc3\xb3w po\xc5\x9bwi\xc4\x99conych jest problematyce spo\xc5\x82ecznej.',
        'title': 'Wydarzenia 15:50',
        'url': 'http://www.polsatnews.pl/wjdmhk/wydarzenia-1550_1491631/'},
        {'code': 'CODZIENNIE',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/r4/r412vb83za8aj3jm3mbmzhjsjj6fdui6.jpg',
        'plot': 'Flagowy program Telewizji Polsat i kana\xc5\x82u informacyjnego Polsat News. Zesp\xc3\xb3\xc5\x82 "Wydarze\xc5\x84" przedstawia wiarygodne i obiektywne informacje dotycz\xc4\x85ce bie\xc5\xbc\xc4\x85cych zdarze\xc5\x84. Wiele przedstawionych materia\xc5\x82\xc3\xb3w po\xc5\x9bwi\xc4\x99conych jest problematyce spo\xc5\x82ecznej.&nbsp;',
        'title': 'Wydarzenia 18:50',
        'url': 'http://www.polsatnews.pl/wjdmhk/wydarzenia-1850_1491632/'},
        {'code': 'CODZIENNIE 22:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/xo/xo7ipp73oh9zpr3cv89va55v4cmn3bnu.jpg',
        'plot': 'Flagowy program Telewizji Polsat i kana\xc5\x82u informacyjnego Polsat News. Zesp\xc3\xb3\xc5\x82 "Wydarze\xc5\x84" przedstawia wiarygodne i obiektywne informacje dotycz\xc4\x85ce bie\xc5\xbc\xc4\x85cych zdarze\xc5\x84. Wiele przedstawionych materia\xc5\x82\xc3\xb3w po\xc5\x9bwi\xc4\x99conych jest problematyce spo\xc5\x82ecznej.&nbsp;',
        'title': 'Wydarzenia 22:00',
        'url': 'http://www.polsatnews.pl/wjdmhk/wydarzenia-2200_1491648/'},
        {'code': 'NIEDZIELA 17:00',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/b6/b6m86t4a76kp838hjmbejwcsu4atzah8.jpg',
        'plot': 'Autorski magazyn Ma\xc5\x82gorzaty Zi\xc4\x99tkiewicz, kt\xc3\xb3ra zaprosi nas do \xc5\x9bwiata kultury z najwy\xc5\xbcszej p\xc3\xb3\xc5\x82ki. \xc5\x9awiatowe malarstwo, rze\xc5\xbaba, performance, sztuki teatralne, opera&nbsp;- zobaczymy wszystko to co znawcy kultury wysokiej ceni\xc4\x85 najbardziej, co jest najbardziej trendy, a co jest uznane za ponadczasowe pi\xc4\x99kno. Autorski przewodnik Ma\xc5\x82gorzaty Zi\xc4\x99tkiewicz po kulturze wysokiej.',
        'title': 'Wysokie C',
        'url': 'http://www.polsatnews.pl/wjdmhk/wysokie-c_514052/'},
        {'code': 'NIEDZIELA 13:30',
        'img': 'http://s.redefine.pl/dcs/o2/redefine/cp/pv/pvftdhyqwbeoiuw1a5duai5g4x3qa2a6.jpg',
        'plot': 'Celem nadrz\xc4\x99dnym tego programu jest walka o dobro i zdrowie dzieci, edukacja spo\xc5\x82ecze\xc5\x84stwa w tym zakresie i walka z patologiami dotykaj\xc4\x85cymi s\xc5\x82u\xc5\xbcb\xc4\x99 zdrowia.',
        'title': 'Wystarczy Chcie\xc4\x87',
        'url': 'http://www.polsatnews.pl/wjdmhk/wystarczy-chciec_2855/'}
  ]
    return out
def PLchar(char):
    s='JiNcZCs7'
    char = re.sub(s.decode('base64'),'',char)
    char = char.replace('&nbsp;','')
    char = char.replace('&lt;br/&gt;',' ')
    char = char.replace('&quot;','"').replace('&amp;quot;','"')
    char = char.replace('&oacute;','\xc3\xb3').replace('&Oacute;','\xc3\x93')
    char = char.replace('&amp;oacute;','\xc3\xb3').replace('&amp;Oacute;','\xc3\x93')
    char = char.replace('&amp;','&')
    char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
    char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
    char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
    char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
    char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
    char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
    char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
    char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
    char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
    return char

