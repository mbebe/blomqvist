# -*- coding: utf-8 -*-

import sys,re,os
import urllib,urllib2
import urlparse,json
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
base_url		= sys.argv[0]
addon_handle	= int(sys.argv[1])
args			= urlparse.parse_qs(sys.argv[2][1:])

my_addon		= xbmcaddon.Addon()
addonName	   = xbmcaddon.Addon().getAddonInfo('name')
addonId	 = xbmcaddon.Addon().getAddonInfo('id')
PATH			= xbmcaddon.Addon().getAddonInfo('path')
DATAPATH		= xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode('utf-8')
RESOURCES	   = PATH+'/resources/'
FANART=PATH+'/fanart.jpg'
ICON = PATH+'/icon.png'
import resources.lib.pnews as psnews
def addLinkItem(name, url, mode, params={}, iconImage=None, infoLabels={}, IsPlayable=True,fanart=FANART,itemcount=1):
	u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'params':params})
	liz = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
	liz.setArt({ 'poster': infoLabels.get('poster',iconImage), 'thumb' : iconImage, 'icon' : iconImage ,'fanart':infoLabels.get('fanart',iconImage),'banner':infoLabels.get('banner',iconImage)})
	infoLabels['url']=str(infoLabels.get('url'))
	liz.setInfo(type='video', infoLabels=infoLabels)
	if IsPlayable:liz.setProperty('IsPlayable', 'true')
	if fanart:liz.setProperty('fanart_image',fanart)
	ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=False,totalItems=itemcount)
	xbmcplugin.setContent(addon_handle, 'videos')	
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = '%R, %Y, %P')
	return ok
def addDir(name,url=None, mode='',params={},iconImage=ICON,fanart=FANART,infoLabels={},totalItems=1):
	u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'params':params})
	print u
	if iconImage==None:
		iconImage='DefaultFolder.png'
	li = xbmcgui.ListItem(label=name,iconImage=iconImage)
	li = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
	li.setArt({ 'poster': infoLabels.get('poster',iconImage), 'thumb' : iconImage, 'icon' : iconImage ,'fanart':infoLabels.get('fanart',iconImage),'banner':infoLabels.get('banner',iconImage)})
	if infoLabels: li.setInfo(type='video', infoLabels=infoLabels)
	if fanart:li.setProperty('fanart_image', fanart )
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=u,listitem=li, isFolder=True)
def encoded_dict(in_dict):
	out_dict = {}
	for k, v in in_dict.iteritems():
		if isinstance(v, unicode):
			v = v.encode('utf8')
		elif isinstance(v, str):
			v.decode('utf8')
		out_dict[k] = v
	return out_dict
def build_url(query):
	return base_url + '?' + urllib.urlencode(encoded_dict(query))
def play(url):
	qual=url.keys();
	stream_url=url.get(qual[0]) if qual else ''
	select = xbmcgui.Dialog().select('Jako\xc5\x9b\xc4\x87', qual)
	if select>-1: stream_url = url.get(qual[select])
	if stream_url: xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
	else: xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
def getUrl(url):
	req = urllib2.Request(url, data=None, headers={'User-Agent':'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.472.63 Safari/534.3'})
	try:
		response = urllib2.urlopen(req,timeout=10)
		link = response.read()
		response.close()
	except:
		link=''
	return link

mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
params = args.get('params',[{}])[0]
if mode is None:

	for item in psnews.scanStrony():
		addDir(item.get('title',''), url=item.get('url'), mode=item.get('mode'), infoLabels=item,  iconImage=item.get('img',''))
	addDir('Programy','',mode='polsatnews_programy',iconImage=ICON)
elif mode[0] == 'polsatnews_programy':
	items = psnews.getProgramy()
	for item in items:
		addDir(item.get('title'), item.get('url'), params={}, mode='polsatnews_content',infoLabels=item ,iconImage=item.get('img'))
elif mode[0] == 'polsatnews_content':
	items,pagination = psnews.getContentVideos(ex_link)
	for item in items: addLinkItem(item.get('title',''),  item['url'], mode='polsatnews_play', IsPlayable=True, infoLabels=item, iconImage=item.get('img',''))
	if pagination[1]: addDir('[COLOR blue]>> nast\xc4\x99pna strona >>[/COLOR]', pagination[1], params={}, mode='polsatnews_page',iconImage=RESOURCES+'polsatnews.png')#addLinkItem(name='[COLOR blue]>> nast\xc4\x99pna strona >>[/COLOR]', url=pagination[1], params=pagination[1], mode='polsatnews_page', IsPlayable=False)
elif mode[0] == 'polsatnews_content_najnowsze':
	items,pagination = psnews.getVideoList(ex_link)
	for item in items: addLinkItem(item.get('title',''),  item['url'], mode='polsatnews_play', IsPlayable=True, infoLabels=item, iconImage=item.get('img',''))
elif mode[0] == 'polsatnews_page':
	items,pagination = psnews.getContentVideosJson(ex_link)
	for item in items: addLinkItem(item.get('title',''),  item['url'], mode='polsatnews_play', IsPlayable=True, infoLabels=item, iconImage=item.get('img',''))
	if pagination[1]: addDir('[COLOR blue]>> nast\xc4\x99pna strona >>[/COLOR]', pagination[1], params={}, mode='polsatnews_page',iconImage=RESOURCES+'polsatnews.png')
elif mode[0] == 'polsatnews_play':
	stream_url = psnews.getVideos(ex_link)
	stream_url=stream_url.get('url',False)
	if stream_url: xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
	else: xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
elif mode[0].startswith('polsatnews'):
	import resources.lib.psport as psport
	if '_play_' in mode[0]:
		stream_url = psport.getVideos(ex_link)
		stream_url=stream_url.get('url',False)
		if stream_url: xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
		else: xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
	elif '_folder_' in mode[0]:
		params = eval(params)
		items = psport.getContentDir(**params)
		for item in items:
			addDir(item.get('title'), ex_link=item.get('url'), params={}, mode='polsatnews_content_',iconImage=item.get('img'))
	elif '_content_' in mode[0]:
		items,pagination = psport.getContentVideos(ex_link)
		if pagination[0]: addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url='', params=pagination[0], mode='polsatnews_page_', IsPlayable=False)
		for item in items: addLinkItem(item.get('title',''),  item['url'], mode='polsatnews_play_', IsPlayable=True,infoLabels=item, l1ll1l_po_=item.get('img'))
		if pagination[1]: addLinkItem(name='[COLOR blue]>> nast\xc4\x99pna strona >>[/COLOR]', url='', params=pagination[1], mode='polsatnews_page_', IsPlayable=False)
	elif '_page_' in mode[0]:
		url = build_url({'mode': 'polsatnews_content_', 'foldername': '', 'ex_link' : params,'params':'', })
		xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
	else:
		addDir('Magazyny', ex_link='', params={'type':'magazyny'}, mode='polsatnews_folder_',iconImage=RESOURCES+'polsatnews.png')
		addDir('Dyscypliny', ex_link='', params={'type':'dyscypliny'}, mode='polsatnews_folder_',iconImage=RESOURCES+'polsatnews.png')
xbmcplugin.endOfDirectory(addon_handle)