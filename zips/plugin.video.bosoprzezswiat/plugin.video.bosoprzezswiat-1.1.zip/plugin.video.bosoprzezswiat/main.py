# -*- coding: UTF-8 -*-
import sys,re,os
import urlparse
from urlparse import parse_qsl

import urllib
import urllib2
import urllib3
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from CommonFunctions import parseDOM

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.bosoprzezswiat')
mainurl="http://www.bosoprzezswiat.kinofabryka.pl/"
nexturl="http://www.kinofabryka.pl"
PATH            = addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART=PATH+'fanart.jpg'
blad=PATH+'error.png'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('title', None)
page = params.get('page',[1])[0]

s = requests.Session()
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_item(url, name, image, folder, mode, infoLabels=False, itemcount=1, page=1):
	list_item = xbmcgui.ListItem(label=name)

	if folder:
		list_item.setProperty("IsPlayable", 'false')
	else:
		list_item.setProperty("IsPlayable", 'true')
		
	if not infoLabels:
		infoLabels={'title': name}
	list_item.setInfo(type="video", infoLabels=infoLabels)	
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})
	xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url = build_url({'mode': mode, 'url' : url, 'page' : page}),			
		listitem=list_item,
		isFolder=folder)
	xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def home():	
	ListMain()
	xbmcplugin.endOfDirectory(addon_handle)
	
def ListMain():
	html=getUrlReq(mainurl)
	out=[]
	links=parseDOM(html,'dt')
	for link in links:
		title=parseDOM(link,'a', attrs={'title': ".+?"})[0] 
		out.append({'title':title,'href':PLchar(title)})
	itemz=out
	items = len(out)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='listStrona', image='', folder=True, infoLabels=f, itemcount=items)		
	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle)

def getStrona(tyt):	
	html=getUrlReq(mainurl)
	tyt=tyt.replace('(','\(').replace(')','\)')
	regex=PLchar(tyt)+'(.+?)</dl>'
	result=re.findall(regex,html,re.DOTALL)[0]
	result= parseDOM(result, 'dl')[0]

	out=[]
	dal=[]
	links=parseDOM(result,'dd')

	for link in links:
		href= parseDOM(link, 'a', ret='href')[0]
		title= parseDOM(link, 'a', ret='title')[0] 
		film = {
			'href'   : href,
			'title'  : title,
			'img'	:	'',}
		if 'http' in film['href']:
			dal.append(film)
		else:
			out.append(film)
	return out,dal	
		
def ListStrona(exlink):
	links,links2= getStrona(exlink)
	itemz=links
	items = len(links)
	itemz2=links2
	items2 = len(links2)	
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)
	for f in links2:
		add_item(name=f.get('title'), url=f.get('href'), mode='scanPage', image=f.get('img'), folder=True, infoLabels=f, itemcount=items2)		
	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle)

def scanPage(exlink):
	links = ListPage(exlink)
	itemz=links
	items = len(links)
	for f in itemz:
		add_item(name=f.get('title'), url=f.get('href'), mode='Play', image=f.get('img'), folder=False, infoLabels=f, itemcount=items)
	xbmcplugin.setContent(addon_handle, 'movies')
	xbmcplugin.endOfDirectory(addon_handle)	
	
def ListPage(url):
	html=getUrlReq(url) 
	check=re.findall('Refresh.+?url=..(.+?)"',html)
	if check:
		html=getUrlReq(nexturl+check[0]) 

	out=[]
	result=parseDOM(html,'p', attrs={'align': "justify"})[0] 
	
	tithref=re.findall('<\/a>(.+?\)).+?"(http.+?)\?rel',result,re.DOTALL)#[0]	
	tithref=tithref if tithref else re.findall('<b>(.+?)<.+?"(http.+?)\?rel',result,re.DOTALL)#[0]
	for title,href in tithref:
		if 'youtube' in href:		
			vid=urlparse.urlparse(href).path.split('/')[-1]
			href = 'plugin://plugin.video.youtube/play/?video_id=' + vid
		film = {
			'href'   : href,
			'title'  : 'Odc. '+PLchar(title),
			'img'	:	'',}	
		out.append(film)
	return out

def getLinks(ex_link):
	url=mainurl+exlink
	items = getVideos(url)
	if len(items)>0:
		select = xbmcgui.Dialog().select('Wybór jakości', [ x.get('host') for x in items])
		if select>-1:
			link = items[select].get('href')
	Play(link)
	
def	Play(link):
	if link:	
		stream_url=link
		if stream_url:
			xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
		else:
			xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
	else:
            xbmcgui.Dialog().notification('Ups...', 'Wystąpił błąd.', blad, 6000)	
	
def getVideos(url):
	html=getUrlReq(url)
	iframes= parseDOM(html, 'iframe', ret='src')#[0]
	out=[]
	for iframe in iframes:
		if 'gloria.tv' in iframe:
			link_url=iframe
	html=getUrlReq(link_url)
	jako=re.findall('source type=".+?mp4.+src="(.+?)".+width="(\d+)".+height="(\d+)"',html)
	for href,szer,wys in jako:		
		film = {'href' : PLchar(href),'host' : szer+'x'+wys,}
		out.append(film)	
	return out	

def getUrlReq(url):
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',}
	content=s.get(url, headers=headers, verify=False, ).content.decode("iso-8859-2").encode("UTF-8")
	return content

def PLchar(char):
	if type(char) is not str:
		char=char.encode('utf-8')
	char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
	char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86') #E9
	char = char.replace('\\u00e9','\xc3\xa9').replace('\\u00C9','\xc3\x89') #E9	
	char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
	char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
	char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
	char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
	char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
	char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
	char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
	char = char.replace('&#8217;',"'")
	char = char.replace('&#8211;',"-")	
	char = char.replace('&#8230;',"...")	
	char = char.replace('&#8222;','"').replace('&#8221;','"')	
	char = char.replace('[&hellip;]',"...")
	char = char.replace('&#038;',"&")	
	char = char.replace('&nbsp;'," ").replace('&amp;','&').replace('&quot;','"')
	return char	

if __name__ == '__main__':
	mode = params.get('mode', None)
	if not mode:
		home()
	elif mode == 'listStrona':
		ListStrona(exlink)  
	elif mode == 'scanPage':
		scanPage(exlink)  
	elif mode == 'Play':
		Play(exlink)  	
		
	elif mode == 'getLinks':
		getLinks(exlink)		
xbmcplugin.endOfDirectory(addon_handle)
