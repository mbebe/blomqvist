# -*- coding: utf-8 -*-

import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_adoon        = xbmcaddon.Addon()
PATH            = xbmcaddon.Addon().getAddonInfo('path')
DATAPATH        = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode('utf-8')
import resources.lib.filicc as filiser
import time,threading
filiser.COOKIEFILE=os.path.join(DATAPATH,'file.cookie')
if 'true' in my_adoon.getSetting('useProxy'):
    filiser.GATE = True
    attent = ' [COLOR gold][Proxy aktywne][/COLOR]'
else:
    filiser.GATE = False
    attent = ''
FANART=''
def addDir(name, url, mode, page=1, iconimage=None, infoLabels=False, IsPlayable=True, isFolder = False, fanart=FANART,itemcount=1):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'page':page})
    if iconimage==None:
        iconimage='DefaultFolder.png'
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art=dict(zip(art_keys,[iconimage for x in art_keys]))
    liz.setArt(art)
    if not infoLabels:
        infoLabels={'title': name}
    liz.setInfo(type='video', infoLabels=infoLabels)
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')
    if fanart:
        liz.setProperty('fanart_image',fanart)
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=isFolder,totalItems=itemcount)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = '%R, %Y, %P')
    return ok
def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        out_dict[k] = v
    return out_dict
def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))
def getLinksFili(ex_link,downloadFili=False,name='',downPath=''):
    strFili = filiser.getStrFili(ex_link)
    streamFili=''
    t = [ x.get('label') for x in strFili]
    dlg_select = xbmcgui.Dialog().select('Linki', t)
    if dlg_select>-1:
        linkFili = filiser.getStreamsFili(strFili[dlg_select].get('url',''),strFili[dlg_select].get('host',''))
        try:
            import resolveurl as urlresolver
            streamFili = urlresolver.resolve(linkFili)
        except Exception,e:
            streamFili=''
            s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link będzie działać?','ResolveUrl ERROR: [%s]'%str(e))
    if streamFili:
        if downloadFili:
            filename = xbmcgui.Dialog().input('Nazwa Pliku', name+'.mp4', type=xbmcgui.INPUT_ALPHANUM)
            if filename:
                params = { 'url': streamFili, 'download_path': downPath}
                l1llll11_fi_.downloadFili(filename.encode('utf-8','ignore'), params)
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=streamFili))
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
def getEpisodes(ex_link):
    serialLinkFili = filiser.getSerialLink(ex_link)
    if 'true' in my_adoon.getSetting('groupEpisodes'):
        select =filiser.getSezonFili(serialLinkFili)
        iconimageFili = serialLinkFili[0].get('img','') if serialLinkFili else ''
        for titleFili in sorted(select.keys()):
            addDir(name=titleFili, url=urllib.quote(str(select[titleFili])), mode='getEpisodesGrouped', iconimage=iconimageFili, infoLabels={}, IsPlayable=False, isFolder=True,itemcount=len(select))
    else:
        for f in serialLinkFili:
            addDir(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True, isFolder=False,itemcount=len(serialLinkFili))
def getEpisodesGrouped(ex_link):
    serialLinkFili = eval(urllib.unquote(ex_link))
    for f in serialLinkFili:
        addDir(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True, isFolder=False,itemcount=len(serialLinkFili))
mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
page = args.get('page',[1])[0]
fverV = my_adoon.getSetting('f_verV')
fverN = my_adoon.getSetting('f_verN') if fverV else 'Wszystkie'
fsortV = my_adoon.getSetting('f_sortV')
fsortN = my_adoon.getSetting('f_sortN') if fsortV else 'Data dodania (od najnowszego)'
sverV = my_adoon.getSetting('s_verV')
sverN = my_adoon.getSetting('s_verN') if sverV else 'Wszystkie'
ssortV = my_adoon.getSetting('s_sortV')
ssortN = my_adoon.getSetting('s_sortN') if ssortV else 'Data dodania (od najnowszego)'
if mode is None:
    addDir('[COLOR lightblue]Filmy Wersja: [/COLOR] [COLOR whilte]%s[/COLOR]'%fverN,'',mode='setFiltr:f_ver',iconimage='',IsPlayable=False)
    addDir('[COLOR lightblue]Filmy Sortuj: [/COLOR] [COLOR whilte]%s[/COLOR]'%fsortN,'',mode='setSort:f_sort',iconimage='',IsPlayable=False)
    addDir('Filmy', url='https://fili.cc/filmy', mode='getContent', page=1, IsPlayable=False, isFolder=True, fanart='')
    addDir('  Ostatnio Dodane', url='newSeriesMovies', mode='scanMain:f', page=1, IsPlayable=False, isFolder=True, fanart='')
#    addDir('[COLOR lightblue]Seriale Wersja: [/COLOR] [COLOR whilte]%s[/COLOR]'%sverN,'',mode='setFiltr:s_ver',iconimage='',IsPlayable=False)
    addDir('[COLOR lightblue]Seriale Sortuj: [/COLOR] [COLOR whilte]%s[/COLOR]'%ssortN,'',mode='setSort:s_sort',iconimage='',IsPlayable=False)
    addDir('Seriale', url='https://fili.cc/seriale', mode='getContent', page=1, IsPlayable=False, isFolder=True, fanart='')
    addDir('  Ostatnio Dodane', url='newSeriesMovies', mode='scanMain:s', page=1, IsPlayable=False, isFolder=True, fanart='')
    addDir('[COLOR lightblue]Szukaj[/COLOR]', url='', mode='search', page=1, IsPlayable=False, isFolder=True, fanart='')
    addDir('Opcje'+attent, url='', mode='Opcje', page=1, IsPlayable=False, isFolder=False, fanart='')
elif 'setFiltr' in mode[0]:
    filtrSetFili = mode[0].split(':')[-1]
    label=['Wszystkie','Polski','Dubbing','Lektor PL','Napisy PL','Napisy Eng','Eng']
    value=['','ver=0','ver=1','ver=2','ver=4','ver=5','ver=6']
    try:
        s = xbmcgui.Dialog().multiselect('Wybierz wersję językową',label)
    except:
        s = xbmcgui.Dialog().select('Wybierz wersję językową',label)
    if isinstance(s,list):
        if 0 in s: s=[0]
        v = '&'.join( [ value[i] for i in s])
        n = ','.join( [ label[i] for i in s])
    else:
        s = s if s>-1 else 0
        v = value[s]
        n = label[s]
    my_adoon.setSetting(filtrSetFili+'V',v)
    my_adoon.setSetting(filtrSetFili+'N',n)
    xbmc.executebuiltin('XBMC.Container.Refresh')
elif 'setSort' in mode[0]:
    filtrSetFili = mode[0].split(':')[-1]
    label=[u'Data dodania (od najnowszego)',u'Wyswietleń (od największej)',u'Oceny (od najwyższej) ',u'Data dodania (od najstarszego)',u'Wyswietleń (od najmniejszej)',u'Oceny (od najniższej)']
    value=['sort_by=date&type=desc','sort_by=views&type=desc','sort_by=rate&type=desc','sort_by=date&type=asc','sort_by=views&type=asc','sort_by=rate&type=asc']

    s = xbmcgui.Dialog().select('Sortuj według ',label)
    s = s if s>-1 else 0
    my_adoon.setSetting(filtrSetFili+'V',value[s])
    my_adoon.setSetting(filtrSetFili+'N',label[s] )
    xbmc.executebuiltin('XBMC.Container.Refresh')
elif mode[0].startswith('scanMain'):
    outItems1,outItems2=filiser.scanMain(id=ex_link)
    filtrSetFili = mode[0].split(':')[-1]
    if 'f' in filtrSetFili:
        items=outItems1
        isFolder = False
        IsPlayable = True
        my_mode = 'getLinks'
    else:
        items=outItems2
        isFolder = True
        IsPlayable = False
        my_mode = 'getEpisodes'
    for f in items: addDir(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,itemcount=len(items))
elif mode[0]=='getContent':
    if 'filmy' in ex_link:
        isFolder = False
        IsPlayable = True
        my_mode = 'getLinks'
        sortowanieFili = '&'.join([fverV,fsortV]) if fverV or fsortV else ''
    else:
        isFolder = True
        IsPlayable = False
        my_mode = 'getEpisodes'
        sortowanieFili = '&'.join([sverV,ssortV]) if sverV or ssortV else ''
    url = ex_link+'?'+sortowanieFili if sortowanieFili and 'page' not in ex_link else ex_link
    items,hrefFili =  filiser.getFilmyFili(url)
    if hrefFili[0]:addDir(name='[COLOR gold]<< poprzednia strona <<[/COLOR]', url=hrefFili[0], mode='__page:getContent', page=1, IsPlayable=False)
    for f in items: addDir(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,itemcount=len(items))
    if hrefFili[1]: addDir(name='[COLOR gold]>> następna strona >>[/COLOR]', url=hrefFili[1], mode='__page:getContent', page=1, IsPlayable=False)
elif mode[0]=='search':
    query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu/serialu', type=xbmcgui.INPUT_ALPHANUM)
    if query:  	
        moviesFili,serialsFili=filiser.search(query.replace(' ','+') )
        isFolder = False
        IsPlayable = True
        my_mode = 'getLinks'
        for f in moviesFili: addDir(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,itemcount=len(moviesFili))
        isFolder = True
        IsPlayable = False
        my_mode = 'getEpisodes'
        for f in serialsFili: addDir(name=f.get('title'), url=f.get('href'), mode=my_mode, iconimage=f.get('img'), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,itemcount=len(serialsFili))
elif mode[0]=='getEpisodes':
    getEpisodes(ex_link)
elif mode[0]=='getEpisodesGrouped':
    getEpisodesGrouped(ex_link)
elif mode[0].startswith('__page:'):
    url = build_url({'mode': mode[0].split(':')[-1], 'foldername': '', 'ex_link' : ex_link, 'page': page})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
elif mode[0] == 'Opcje':
    my_adoon.openSettings()
    xbmc.executebuiltin('XBMC.Container.Refresh()')
elif mode[0] == 'getLinks':
    getLinksFili(ex_link)
else:
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
xbmcplugin.endOfDirectory(addon_handle)

