# -*- coding: utf-8 -*-
import urllib2,urllib
import re,os
import json
import cookielib
from urlparse import urlparse

BASEURL = 'https://zalukaj.com'
TIMEOUT = 10
UA      = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'

class NoRedirection(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response

def getUrl(url,data=None,header={},useCookies=True,saveCookie=True):
    if COOKIEFILE and (useCookies or saveCookie):
        cj = cookielib.LWPCookieJar()

        if useCookies==True and os.path.exists(COOKIEFILE):
            cj.load(COOKIEFILE)

        opener = urllib2.build_opener(NoRedirection,urllib2.HTTPCookieProcessor(cj))
        urllib2.install_opener(opener)

    if not header:
        header = {'User-Agent':UA,'referer':'https://zalukaj.com/index.html'}

    if useCookies:
        header.update({"Cookie": cookieString(COOKIEFILE)})

    req = urllib2.Request(url,data,headers=header)

    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link =  response.read()
        response.close()

        if COOKIEFILE and saveCookie:
            dataPath=os.path.dirname(COOKIEFILE)
            if not os.path.exists(dataPath): os.makedirs(dataPath)
            if cj: cj.save(COOKIEFILE)

    except urllib2.HTTPError as e:
        link = ''

    return link

def cookieString(COOKIEFILE):
    sc=''
    if os.path.isfile(COOKIEFILE):
        cj = cookielib.LWPCookieJar()
        cj.load(COOKIEFILE)
        sc=''.join(['%s=%s;'%(c.name, c.value) for c in cj])
    return sc

def getLogin(u='',p=''):
    data='login=%s&password=%s'%(u,p)
    content=getUrl('https://zalukaj.com/account.php',data=data)
    content=getUrl('https://zalukaj.com/libs/ajax/login.php?login=1&x=2043')

    if 'Wyloguj' in content:
        user = re.compile('<a style="text-decoration:underline;" href="#">(.*?)</a>').findall(content)
        info = re.compile('<p>(.*?)<a.*>(.*?)</a>').findall(content)
        info = '\n'.join([''.join(x) for x in info]).replace('&raquo;','').replace('&laquo;','')
        img = re.compile('<img src="(.*?)"').findall(content)
        img = 'https:'+img[0] if img else ''
        href = re.compile('<a href="(.*?)">Ulubione</a>').findall(content)
        href = BASEURL + href[0] if href else ''
        return {'title':'[B]%s - Ulubione[/B]'%user[0],'plot':info,'img':img,'url':href}

    return {'msg':'Problem z logowaniem'}

def scanMainpage(url='https://zalukaj.com',data=None):
    content = getUrl(url,data,useCookies=True)
    prevPage = False
    nextPage = False

    if 'strona-' in url:
        cpage=int(re.search('strona-(\d+)',url).group(1))

        if content.find(',strona-%d'%(cpage+1)):
            nextPage=re.sub('strona-\d+','strona-%d'%(cpage+1),url)

        if cpage > 1:
            prevPage=re.sub('strona-\d+','strona-%d'%(cpage-1),url)

    ids = [(a.start(), a.end()) for a in re.finditer('<div class="tivief\d">', content)]
    ids.append( (-1,-1) )
    out=[]

    for i in range(len(ids[:-1])):
        subset = content[ ids[i][1]:ids[i+1][0] ]
        img = re.compile('<img.*?src="(.*?)"').search(subset)

        if not img:
            img = re.compile('style="background-image:url\((.*?)\);">').search(subset)

        href = re.compile('<a.*href="(.*?)" title="(.*?)"').search(subset)
        plot = re.compile('<div style="min-height:110px;font-size:10px;"(.*?)"').findall(subset)

        if not plot:
            plot = re.compile('<div style="min-height:110px"(.*?)"').findall(subset)

        plot = re.compile('>(.*?)<').findall(plot[0]) if plot else ''

        if href and img:
            h= href.group(1)
            h= 'https:'+h if h[0:2]=='//' else h
            t= href.group(2).strip()
            year = re.search('(\d{4})',t)
            t,code = t.split('|') if '|' in t else (t,'')
            p= plot[0].strip() if plot else ''
            im = img.group(1)
            im = 'https:'+im if im[0:2]=='//' else im
            one = {'url'   : h,
                'title'  : unicodePLchar(t.strip()),
                'plot'   : unicodePLchar(p),
                'img'    : im,
                'year'   : year.group(1) if year else '',
                'code'   : code.strip(),
                'isFolder':False,
                }
            out.append(one)

    return out,(prevPage,nextPage)

def getSeriale(type=''):
    if type=='all':
        return getSerialeAll()
    else:
        return getSerialeLatest()

def getSerialeLatest(url='https://zalukaj.com/seriale'):
    content = getUrl(url,useCookies=True)
    out=[]
    ids = [(a.start(), a.end()) for a in re.finditer('<div class="latest tooltip">', content)]
    ids.append( (-1,-1) )
    out=[]

    for i in range(len(ids[:-1])):
        subset = content[ ids[i][1]:ids[i+1][0] ]
        href_src =re.compile('<a href="(/kategoria-serialu.*?)" title="(.*?)"><img alt=".+" src="(.*?)">').findall(subset)
        title_e = re.compile('<span style="font-weight:bold;">(.*?)</span>').findall(subset)
        code = re.compile('<span class="datelts">(.*?)</span>').findall(subset)

        if href_src and title_e:
            h=BASEURL+href_src[0][0]
            img = href_src[0][-1]
            t = '%s (%s)'%(href_src[0][1],title_e[0])
            out.append(
                {'url':h,
                 'title'  : unicodePLchar(t.strip()),
                 'img'  : img,
                 'code'   : unicodePLchar(code[0].strip()) if code else '',
                 'plot'   : unicodePLchar(code[0].strip()) if code else '',
                })

    return out

def getSerialeAll():
    content = getUrl(BASEURL,useCookies=True)
    out=[]
    seriale = re.compile('<a href="(/sezon-serialu/.*?)" title="(.*?)">(.*?)</a>').findall(content)

    for s in seriale:
        out.append({
            'url': BASEURL+s[0],
            'title': unicodePLchar(s[1].strip()).decode('utf-8')
            }
            )

    return out

def getSeasons(url='https://zalukaj.com/kategoria-serialu/2727,1/the_walking_dead_the_walking_dead_sezon_7/'):
    content = getUrl(url,useCookies=True)
    out=[]
    img = re.compile('<div id="sezony" align="center"><img src="(.*?)"',re.DOTALL).findall(content)
    img = img[0] if img else ''
    img = 'https:'+img if img[0:2]=='//' else img
    seasons = re.compile('<a class="sezon" href="(.*?)" >(.*?)</a>').findall(content)

    for s in seasons:
        out.append({
            'url': BASEURL+s[0],
            'title': unicodePLchar(s[1].strip()).decode('utf-8'),
            'img':img,
            })

    return out

def getEpisodes(url):
    content = getUrl(url,useCookies=True)
    out=[]
    img = re.compile('<div align="center"><img src="(.*?)"',re.DOTALL).findall(content)
    img = img[0] if img else ''
    img = 'https:'+img if img[0:2]=='//' else img
    episodes = re.compile('<div align="left" id="sezony"[^>]*>(.*?)<a href="(.*?)" title="(.*?)">(.*?)</a></div>').findall(content)

    for s in episodes:
        h= s[1]
        h= 'https:'+h if h[0:2]=='//' else h
        t= '%s %s'%(s[0].strip(),s[2].strip())
        out.append({
            'url': h,
            'title': unicodePLchar(t).decode('utf-8'),
            'img':img,
            })

    return out

def getVideoUrl(url):
    video=[{}]
    href=''
    content = getUrl(url,useCookies=True,saveCookie=False)
    iframe = re.compile('<iframe(.*?)</iframe>',re.DOTALL).findall(content)

    if iframe:
        src = re.compile('src="(.*?)"').findall(iframe[0])
        if src:
            src = src[0]
            urlp = src.split('&')[0]+'&x=1&'+'&'.join(src.split('&')[1:])
            urlp = BASEURL + urlp if urlp[0]=='/' else urlp
            data = getUrl(urlp,useCookies=True)
            href =re.compile('<iframe src="(.*?)" .+?></iframe>').findall(data)
            if href:
                href='https:'+href[0] if href[0][0:2]=='//' else href[0]
                video=[{'href':href,'label':'you should not see this'}]
    else:
        if 'Duze obciazenie!' in content:
            video=[{'url':'','label':'[COLOR red]Duze obciazenie! [/COLOR]'}]

    if len(video) == 1 and video[0] == {} and href:
        video=[{'href': href, 'label': 'link'}]

    return video

def Gatunek(url=''):
    out=[
        {'url':"https://zalukaj.com/gatunek,22/",'title':"Akcja",},
        {'url':"https://zalukaj.com/gatunek,2/",'title':"Animowane",},
        {'url':"https://zalukaj.com/gatunek,21/",'title':"Biografie",},
        {'url':"https://zalukaj.com/gatunek,3/",'title':"Dokumentalne",},
        {'url':"https://zalukaj.com/gatunek,4/",'title':"Dramat",},
        {'url':"https://zalukaj.com/gatunek,25/",'title':"Familijne",},
        {'url':"https://zalukaj.com/gatunek,30/",'title':"Fantasty",},
        {'url':"https://zalukaj.com/gatunek,27/",'title':"Historyczne",},
        {'url':"https://zalukaj.com/gatunek,7/",'title':"Horror",},
        {'url':"https://zalukaj.com/gatunek,29/",'title':"Katastroficzne",},
        {'url':"https://zalukaj.com/gatunek,8/",'title':"Komedia",},
        {'url':"https://zalukaj.com/gatunek,23/",'title':"Kostiumowe",},
        {'url':"https://zalukaj.com/gatunek,28/",'title':"Musical",},
        {'url':"https://zalukaj.com/gatunek,20/",'title':"Obyczajowy",},
        {'url':"https://zalukaj.com/gatunek,24/",'title':"Polskie",},
        {'url':"https://zalukaj.com/gatunek,10/",'title':"Przygodowe",},
        {'url':"https://zalukaj.com/gatunek,12/",'title':"Sci-Fi",},
        {'url':"https://zalukaj.com/gatunek,13/",'title':"Sensacyjne",},
        {'url':"https://zalukaj.com/gatunek,26/",'title':"Sport",},
        {'url':"https://zalukaj.com/gatunek,14/",'title':"Thriller",},
        {'url':"https://zalukaj.com/gatunek,15/",'title':"Wojenne",},
        ]
    return out,(False, False)

def unicodePLchar(txt):
    if type(txt) is not str:
        txt=txt.encode('utf-8')
    txt = txt.replace('&nbsp;','')
    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')
    return txt
