# -*- coding: utf-8 -*-
import urllib2,urllib,json
import re,os
import urlparse

BASEURL = "http://ekstraklasa.tv/"
TIMEOUT = 10
UA = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'
iteppp = 25
GATE = 'http://www.bramka-proxy.pl'
cookies = ''

def getUrl(url,data=None,header={}):
    headers={'User-Agent': UA}

    if header:
        headers.update(header)
    req = urllib2.Request(url,data,headers)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        out = response.read()
        response.close()
    except:
        out=''
    return out

def getContent(url,type='skroty',page=1, category=7,**args):
	data=None
	if '?ajax=1' in url:
	    page=int(re.findall('[?]ajax=1&page=(\d+)',url,re.DOTALL)[0])
	    a=page
	    url = re.sub(r'&page=\d+','&page=%d' %page,url)
	content = getUrl(url,data)
	np=False
	pp=False
	out = _getContent(content)
	if out:	
		if '?ajax=1' in url:
			if a>10:
				np=False			
			else:
				page+=1
				np = {'urlp': re.sub(r'&page=\d+','&page=%d' %page,url)}
			if a<1:
				pp=False
			else:
				page-=2
				pp = {'urlp': re.sub(r'&page=\d+','&page=%d' %page,url)}
	return out,(pp,np)

def _getContent(content):
    content = content.decode('utf-8')
    ids = [(a.start(), a.end()) for a in re.finditer('<div class="listItem ', content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        cc = content[ ids[i][1]:ids[i+1][0] ].replace('\\','').encode('utf-8')
        pub = re.findall('<div class="datePublished">(.*?)</div>',cc,re.DOTALL)
        iimg = re.findall('<img class="itemImage".*data-original="(.*?)"',cc,re.DOTALL)
        title = re.compile('<a href="(.*?)" title="(.*?)"').findall(cc)
        item = re.findall('<div class="itemLead hyphenate">(.*?)</div>',cc,re.DOTALL)
        if title:
            h = title[0][0]
            t = unicodePLchar(title[0][1].strip())
            i = iimg[0] if iimg else ''
            p = unicodePLchar(item[0].strip()) if item else ''
            c = unicodePLchar(pub[0].strip()) if pub else ''
            out.append({'url':h,'title':t,'img':i,'plot':p,'code':c})
    return out

url='http://ekstraklasa.tv/skroty/arka-wisla-p-1-1-zobacz-skrot-meczu/y2rn1e'
url='http://ekstraklasa.tv/skroty/lech-korona-3-2-zobacz-skrot-meczu/nshz2k'
url='http://ekstraklasa.tv/skroty/legia-warszawa-lech-poznan-skrot-meczu-i-bramki-lotto-ekstraklasa/mznnvg'
url='http://ekstraklasa.tv/arka-wisla-p-0-0-merebaszwili-minal-kilku-rywali-ale-zamiast-strzelac-upadl-w-polu/95vs5k'
url='http://onet.tv/s/ekstraklasa/legia-lech-2-0-zobacz-skrot-meczu/sqt3s4'

def getVideos(url):

    content = getUrl(url)
    content=content.replace('\&quot;','"').replace('&quot;','"')
    out=[]
    mvp = re.compile('mvp="(\d+\.\d+)"').findall(content)
    if not mvp:
        mvp = re.compile('"mvp:(\d+\.\d+)"').findall(content)
    if not mvp:
        embed=re.compile('data-src="(.*?)"').findall(content)
        embed='http:'+embed[0] if embed else ''
        if embed:
            data = getUrl(embed,header={'Referer':url})
            mvp = re.compile('-mvp="(\d+\.\d+)"').findall(data)
            if not mvp:
                mvp = re.compile('"mvp:(\d+\.\d+)"').findall(content)
    if mvp:
        print mvp
        u2='http://qi.ckm.onetapi.pl/?body%5Bid%5D={0}&body%5Bjsonrpc%5D=2.0&body%5Bmethod%5D=get_asset_detail&body%5Bparams%5D%5BID_Publikacji%5D={1}&body%5Bparams%5D%5BService%5D=onet.onet.pl&body%5Bparams%5D%5Btarget%5D=ONETTV%2Fexclusive%3Asport_100&body%5Bparams%5D%5Bkwrd%5D=%5B%22SEGR%22%5D&content-type=application%2Fjsonp&x-onet-app=player.front.onetapi.pl&callback='
        data = getUrl(u2.format(mvp[0],mvp[0]))
        jdata = json.loads(data)
        out = jdata['result']['0']['formats']['wideo']['mp4']
        for i in out:
            i['title']=i.get('vertical_resolution','')
            i['resolved']=True
            print i
    else:
        out=[{'msg':'Sorry, but this video clip is presently unavailable to users outside of Poland'}]
    return out

def getUrlh(url,header={}):
    out=''
    global cookies
    if not cookies:
        req = urllib2.Request(GATE,data=None,headers={'User-Agent': UA,'Upgrade-Insecure-Requests':1})
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        cookies=response.headers.get('set-cookie',' ').split(' ')[0]
        response.close()
        cookies = cookies
    else:
        cookies=cookies
    data = 'u=%s&allowCookies=on'%urllib.quote_plus(url)
    gurl = GATE+'/includes/process.php?action=update'
    headers={'User-Agent': UA,'Upgrade-Insecure-Requests':1,'Cookie':cookies}
    headers.update(header)
    req = urllib2.Request(gurl,data,headers)
    response = urllib2.urlopen(req,timeout=TIMEOUT)
    out=response.read()
    if 'sslagree' in out:
        print 'sslagree'
        gurl = GATE+'/includes/process.php?action=sslagree'
        req = urllib2.Request(gurl,data,headers)
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        out=response.read()
    response.close()
    print 'GATE in USE'
    return out

def getMain():
    out=[
	    {'title':'Skróty','url':'https://ekstraklasa.tv/skroty?ajax=1&page=0','params':{'type':'','page':0}},
		{'title':'Bramki','url':'https://ekstraklasa.tv/bramki?ajax=1&page=0','params':{'type':'','page':0}},
		{'title':'Akcje z meczów','url':'https://ekstraklasa.tv/akcje?ajax=1&page=0','params':{'type':'','page':0}},
		{'title':'Kontrowersje z meczów','url':'https://ekstraklasa.tv/kontrowersje?ajax=1&page=0','params':{'type':'','page':0}},
        {'title':'Bramka kolejki','url':'https://ekstraklasa.tv/bramka-kolejki?ajax=1&page=0','params':{'type':'','page':0}},
		{'title':'Bohater kolejki','url':'https://ekstraklasa.tv/bohater-kolejki?ajax=1&page=0','params':{'type':'','page':0}},
		{'title':'Interwencja kolejki','url':'https://ekstraklasa.tv/interwencja-kolejki?ajax=1&page=0','params':{'type':'','page':0}},
		{'title':'Magazyn Ekstraklasy','url':'https://ekstraklasa.tv/magazyny/magazyn-ekstraklasy?ajax=1&page=0','params':{'type':'','page':0}},
		{'title':'EkstraRadar','url':'https://ekstraklasa.tv/ekstraradar?ajax=1&page=0','params':{'type':'','page':0}},
        ]
    return out

def unicodePLchar(txt):
    s='JiNcZCs7'
    txt = re.sub(s.decode('base64'),'',txt)
    txt = re.sub('&quot;','"',txt)
    txt = re.sub('&.*;','',txt)
    txt = txt.replace('&nbsp;','')
    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&ndash;','-')
    txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')
    return txt
