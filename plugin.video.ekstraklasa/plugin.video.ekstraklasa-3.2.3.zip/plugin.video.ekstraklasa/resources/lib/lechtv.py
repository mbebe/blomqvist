# -*- coding: utf-8 -*-
import urllib2,urllib,json
import re,os
import urlparse
BASEURLTAB = 'https://sportowefakty.wp.pl/pilka-nozna/ekstraklasa/tabele'
TIMEOUT = 10
UA      = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'
iteppp  = 25

def getUrl(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)

    if cookies:
        req.add_header("Cookie", cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()
        response.close()
    except:
        link=''

    return link

def tabela_ekstraklasy():
    content= getUrl(BASEURLTAB)
    tabela = re.compile('<tr class="podium-first">(.*?)</tbody>',re.DOTALL).findall(content)
    out = []

    if tabela:
	
        pos = re.compile('<td class="align--left"><span>(.*?)</span></td>').findall(tabela[0])
        pts = re.compile('<td class="align--left"><b>(.*?)</b></td>').findall(tabela[0])
        team = re.compile('<td class="align--left"><a href=".*?">(.*?)</a></td>').findall(tabela[0])
        for p,pt,name in zip(pos,pts,team):
            out.append({'title':'%s. [B]%s[/B]'%(p,name),'code':'[COLOR gold][B]%s[/B][/COLOR]'%unicodePLchar(pt)} )

    return out

def unicodePLchar(txt):
    s='JiNcZCs7'
    txt = re.sub(s.decode('base64'),'',txt)
    txt = re.sub('&nbsp;','',txt)
    txt = re.sub('&.*;','',txt)
    txt = txt.replace('&nbsp;','')
    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&ndash;','-')
    txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')

    return txt
