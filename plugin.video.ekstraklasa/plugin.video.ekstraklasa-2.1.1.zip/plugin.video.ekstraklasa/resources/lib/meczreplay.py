# -*- coding: utf-8 -*-
import urllib2,urllib,json
import re,os
from urlparse import urlparse
import base64
import cookielib

BASEURL = "https://meczreplay.wordpress.com/"
TIMEOUT = 20
UA      = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'

def getUrl(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)

    if cookies:
        req.add_header("Cookie", cookies)

    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()
        response.close()
    except:
        link = ''

    return link

def getMain(url='https://meczreplay.wordpress.com/'):
    content = getUrl(url)
    divs = re.compile('<li class="cat-item cat-item-\d+"><a href="(https://meczreplay.wordpress.com/category/.*?)" >(.*?)</a>',re.DOTALL).findall(content)
    out=[]

    for div in divs:
        out.append({'url':div[0],'title':div[1]})

    if out:
        out.insert(0,{'url':'https://meczreplay.wordpress.com/','title':'[COLOR blue]Ostatnion dodane[/COLOR]'})

    return out

def getContent(url,**kwargs):
    content = getUrl(url)
    tds = re.compile('<article(.*?)</article>',re.DOTALL).findall(content)
    out = []
    nextPage = False
    prevPage = False

    for td in tds:
        href = re.compile('<a href="(https://meczreplay.wordpress.com/.*?)" rel="bookmark">(.*?)</a>',).findall(td)
        title = re.compile('data-medium-file="(.*?)"').findall(td)

        if href:
            h = href[0][0]
            t = href[0][1].strip()
            title = title[0] if title else ''
            out.append({'url':h,'title':unicodePLchar(t),'img':title})

    if out and len(out)>6:
        page = re.findall('/page/(\d+)',url)
        nextPage = re.sub('/page/%s'%page[0],'/page/%d'%(int(page[0])+1),url) if page else url+'page/2'
        if nextPage:
            nextPage = {'urlp':nextPage}
        prevPage = re.sub('/page/%s'%page[0],'/page/%d'%(int(page[0])-1),url) if page else False
        if prevPage:
            prevPage = {'urlp':prevPage}

    return (out,(prevPage,nextPage))

def getVideos(url):
    content = getUrl(url)
    v=[]
    pc = re.compile('<div class="post-content">(.*?)div',re.DOTALL).findall(content)
    href = re.compile('([^>]*)<a class="postlink" href="(http.*?)" rel="nofollow">').findall(content)

    for link in href:
        t = link[0].strip()
        v.append({'title':unicodePLchar(t),'url':link[1].strip()})

    if not v and pc:
        href = re.findall('href="(.*?)"',pc[0])
        title =  re.findall('>[\n\s]*(.*?)<a',pc[0])
        if len(title)==len(href):
            for t,h in zip(title,href):
                v.append({'title':unicodePLchar(t.strip().replace(':','')),'url':h.strip()})
        else:
            for i,h in enumerate(href):
                v.append({'title':'Link %d'%(i+1),'url':h.strip()})

    if not v:
        v={'msg':'Video link not found or not supported yet'}

    return v

def unicodePLchar(txt):
    if type(txt) is not str:
        txt=txt.encode('utf-8')

    txt = txt.replace('''&nbsp;''','')
    txt = txt.replace('''&quot;''','"')
    txt = txt.replace('''&bdquo;''','\'')
    txt = txt.replace('''&rdquo;''','\'')
    txt = txt.replace('''&oacute;''','ó').replace('''&Oacute;''','Ó')
    s='26235c642b3b'
    t='265b5e3b5d3b'
    txt = re.sub(s.decode('hex'),'',txt)
    txt = re.sub(t.decode('hex'),'',txt)
    txt = txt.replace('''&amp;''','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')

    return txt
