# -*- coding: utf-8 -*-
import urllib2,urllib,json
import re,os
from urlparse import urlparse,urljoin
import base64
import cookielib

BASEURL = "https://api.dailymotion.com"
TIMEOUT = 15
UA = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'
GATE=''
GATE='http://invisiblesurf.review'
cookies = ''

def getUrl(url,data=None,cookies=None):
    link=''
    if GATE:
        link = getUrlh(url)
    if not link:
        req = urllib2.Request(url,data)
        req.add_header('User-Agent', UA)
        if cookies:
            req.add_header("Cookie", cookies)
        try:
            response = urllib2.urlopen(req,timeout=TIMEOUT)
            link = response.read()
            response.close()
        except:
            link=''
    return link

def getUrlh(url,blink='http://invisiblesurf.review'):
    link = ''
    global cookies

    if not cookies:
        req = urllib2.Request(blink,data=None,headers={'User-Agent': UA,'Upgrade-Insecure-Requests':1})
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        cookies=response.headers.get('set-cookie',' ').split(' ')[0]
        response.close()
        cookies = cookies
    else:
        cookies = cookies

    data = 'u=%s&allowCookies=on'%urllib.quote_plus(url)
    alink = urljoin(blink,'includes/process.php?action=update')
    headers={'User-Agent': UA,'Upgrade-Insecure-Requests':1,'Cookie':cookies}
    req = urllib2.Request(alink,data,headers)
    response = urllib2.urlopen(req,timeout=TIMEOUT)
    link=response.read()

    if 'sslagree' in link:
        alink = urljoin(blink,'includes/process.php?action=sslagree')
        req = urllib2.Request(alink,data,headers)
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link=response.read()

    response.close()
    print 'GATE in USE'
    return link

def getLive(user):
    url = BASEURL+"/user/"+user+"/videos?flags=live_onair&fields="+urllib.quote('id,duration,title,onair,private,thumbnail_240_url')
    content = getUrl(url)
    L=[]
    if content:
        try:
            data = json.loads(content)
            L = data.get('list',[])
        except:
            L = []
    return L

def getVideos(user,sort='recent',page='1'):
    fields='id,uri,duration,record_status,duration_formatted,title,onair,private,views_total,created_time,thumbnail_240_url'
    query = {  'fields':fields,
               'page':page,
               'thumbnail_ratio':'widescreen',
               'sort':sort,
               'limit':50,
               'localization':'pl_PL'
            }
    nextPage=False
    prevPage=False
    L=[]
    if sort =='live':
        L = getLive(user)
    else:
        url = BASEURL+"/user/"+user+"/videos?"+urllib.urlencode(query)
        content = getUrl(url)
        try:
            data = json.loads(content)
            L = data.get('list',[])
        except:
            L=[]
        nextPage = {'user':user,'sort':sort,'page':data.get('page',page)+1} if data.get('has_more',False) else False
        prevPage = {'user':user,'sort':sort,'page':data.get('page',page)-1} if data.get('page',page)>1 else False
    return (L,(prevPage,nextPage))

def getVideoLinks__(media_id='x2yclwl'):
    out = []
    content = getUrl('http://www.dailymotion.com/embed/video/%s' % media_id)
    match = re.search('var\s+config\s*=\s*(.*?}});', content)
    if match:
        try: al = json.loads(match.group(1))
        except: al = {}
        la = al.get('metadata', {}).get('qualities', {})
        for quality, links in la.iteritems():
            for link in links:
                if quality.isdigit() and link.get('type', '').startswith('video'):
                    out.append({'label':quality,'url':link['url']})
                elif quality == 'auto':
                    out.append({'label':quality,'url':link['url']})
    return out

def getVideoLinks(media_id='x2ycmu1'):
    global GATE
    content = getUrl('http://www.dailymotion.com/embed/video/%s' % media_id)
    srcs=re.compile('"(1080|720|480|380)":(\[{[^\]]*\])',re.DOTALL).findall(content)
    out=[]

    if not GATE:
        for quality,links in srcs:
            url=''
            for type,href in re.compile('"type":"(.*?)","url":"(.*?)"').findall(links):
                if 'video' in type:
                    url= href
                    out.append({'label':quality,'url':url.replace('\\','')})

    if not out:
        srcs=re.compile('"(auto)":\[{"type":"(.*?)","url":"(.*?)"}\]',re.DOTALL).findall(content)
        for quality,type,url in srcs:
            url = url.replace('\\','')
            m3u = getUrl(url + '&redirect=0')
            if not m3u:
                GATE = ''
                m3u = getUrl(url + '&redirect=0')
            if '#EXTM3U' in m3u:
                qq=re.compile('NAME="(.*?)"\n(.*?)\n').findall(m3u)
                for label,url in qq:
                    out.append({'label':label,'url':url})
            else:
                if m3u and not m3u.startswith('http:'):
                    m3u = re.findall('(http://.*?)$', m3u)[0]
                burl = m3u.split('live.m3u8')[0]
                try: cw = getUrl(url)
                except: cw=''
                if not cw:
                    cw = 'I0VYVE0zVQojRVhULVgtVkVSU0lPTjogMQojRVhULVgtU1RSRUFNLUlORjpSRVNPTFVUSU9OPTMy\nMHgxODAsRlJBTUUtUkFURT0yNS4wMDAwMDAsQkFORFdJRFRIPTQ3NTEzNixDT0RFQ1M9ImF2YzEu\nNDIwMDBjLG1wNGEuNDAuNSIsTkFNRT0iMjQwIgpsaXZlLTAubTN1OAojRVhULVgtU1RSRUFNLUlO\nRjpSRVNPTFVUSU9OPTUxMngyODgsRlJBTUUtUkFURT0yNS4wMDAwMDAsQkFORFdJRFRIPTg0Nzg3\nMixDT0RFQ1M9ImF2YzEuNDIwMDE1LG1wNGEuNDAuMiIsTkFNRT0iMzgwIgpsaXZlLTEubTN1OAoj\nRVhULVgtU1RSRUFNLUlORjpSRVNPTFVUSU9OPTg0OHg0NzcsRlJBTUUtUkFURT0yNS4wMDAwMDAs\nQkFORFdJRFRIPTEzNTk4NzIsQ09ERUNTPSJhdmMxLjQyMDAxZSxtcDRhLjQwLjIiLE5BTUU9IjQ4\nMCIKbGl2ZS0yLm0zdTgKI0VYVC1YLVNUUkVBTS1JTkY6UkVTT0xVVElPTj0xMjgweDcyMCxGUkFN\nRS1SQVRFPTI1LjAwMDAwMCxCQU5EV0lEVEg9MjE3OTA3MixDT0RFQ1M9ImF2YzEuNjQwMDFmLG1w\nNGEuNDAuMiIsTkFNRT0iNzIwIgpsaXZlLTMubTN1OAojRVhULVgtU1RSRUFNLUlORjpSRVNPTFVU\nSU9OPTE5MjB4MTA4MCxGUkFNRS1SQVRFPTI1LjAwMDAwMCxCQU5EV0lEVEg9NjI3NTA3MixDT0RF\nQ1M9ImF2YzEuNjQwMDI4LG1wNGEuNDAuMiIsTkFNRT0iMTA4MCIKbGl2ZS00Lm0zdTgK\n'.decode('base64')
                if '#EXTM3U' in cw:
                    qq=re.compile('RESOLUTION=(.*?)\n(.*?)\n').findall(cw)
                    for label,pp in qq:
                        out.append({'label':label,'url':burl+pp})
    return out
