# -*- coding: utf-8 -*-
import urllib2,urllib
import re,random,json
import cookielib

TIMEOUT=10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'

def getUrl(url,data=None,header={},l1lllll111ll11l1l11_nktv_=True):
    l11lllll1ll11l1l11_nktv_=''
    cookie=[]
    if l1lllll111ll11l1l11_nktv_:
        cookie = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookie))
        urllib2.install_opener(opener)
    if not header:
        header = {'User-Agent':UA}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        l1ll11l1ll11l1l11_nktv_ =  response.read()
        response.close()
        l11lllll1ll11l1l11_nktv_ = ''.join(['%s=%s;'%(c.name, c.value) for c in cookie])
    except urllib2.HTTPError as e:
        l1ll11l1ll11l1l11_nktv_ = ''
    return l1ll11l1ll11l1l11_nktv_,l11lllll1ll11l1l11_nktv_

url = 'https://www.rapidvideo.com/embed/V2VsVKXP'
url = 'https://www.rapidvideo.com/embed/ECcyARgM'

def getVideos(url):
    url = url.replace('http:','https:').replace('/embed/','/?v=')
    content,c = getUrl(url)
    match = re.findall('''["']?sources['"]?\s*:\s*(\[.*?\])''', content)
    l1lllll11lll11l1l11_nktv_=''
    if not match:
        data = {}
        data['confirm.y'] = random.randint(0, 120)
        data['confirm.x'] = random.randint(0, 120)
        header={'User-Agent':UA,'Referer':url}
        l1lllll1llll11l1l11_nktv_ = url + '#'
        content,c = getUrl(l1lllll1llll11l1l11_nktv_,urllib.urlencode(data),header=header)
        match = re.findall('''["']?sources['"]?\s*:\s*(\[.*?\])''', content)
    if match:
        try:
            data = json.loads(match[0])
            l1lllll11lll11l1l11_nktv_=[]
            for d in data:
                if isinstance(d,dict):
                    l1lllll1l1ll11l1l11_nktv_ = d.get('file','')+'|User-Agent=%s&Referer=%s'%(UA,url)
                    l1lllll11lll11l1l11_nktv_.append((d.get('label',''),l1lllll1l1ll11l1l11_nktv_))
        except:
            l1lllll11lll11l1l11_nktv_ = re.findall('''['"]?file['"]?\s*:\s*['"]?([^'"]+)''', match[0])
            if l1lllll11lll11l1l11_nktv_:
                l1lllll11lll11l1l11_nktv_ = l1lllll11lll11l1l11_nktv_[0].replace('\/', '/')
                l1lllll11lll11l1l11_nktv_ += '|User-Agent=%s&Referer=%s'%(UA,url)
    return l1lllll11lll11l1l11_nktv_
