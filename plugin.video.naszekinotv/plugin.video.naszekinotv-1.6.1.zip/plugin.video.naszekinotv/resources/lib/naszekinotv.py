# -*- coding: utf-8 -*-
import urllib2,urllib
import re,os,json,base64
import cookielib
import xbmcaddon, xbmcgui
from urlparse import urlparse
import subprocess,requests

try:
    import mc
except:
    pass

my_addon     = xbmcaddon.Addon()
TIMEOUT      = 10
UA           = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'
base_url     = 'https://www.nasze-kino.tv/'
sess         = requests.session()
content      = sess.get(base_url).text

if str(content).find('cloudflare') >= 0:
   cloudflare_active = True
else:
   cloudflare_active = False

if cloudflare_active == True:
   try: 
       import cfscrape
   except:
       pass
   try:
       scraper = cfscrape.create_scraper(sess)
   except:
       pass

def getUrl(url,data=None,header={}):
    if cloudflare_active == True:
       sess.headers = {'User-Agent': UA, 'Referer': base_url}
       out = scraper.get(url, headers=sess.headers).content
    else:
       cookies=''
       out=''
       cookie = cookielib.LWPCookieJar()
       try:
          if COOKIEFILE and os.path.exists(COOKIEFILE):
             cookie.load(COOKIEFILE,True,True)
             cookies = ';'.join(['%s=%s'%(c.name,c.value) for c in cookie])
       except:
             cookie = cookielib.LWPCookieJar()
       opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookie))
       urllib2.install_opener(opener)
       headers={'User-Agent': UA}
       headers.update(header)
       req = urllib2.Request(url,data,headers)
       if cookies:
          req.add_header("Cookie", cookies)
       try:
          response = urllib2.urlopen(req,timeout=TIMEOUT)
          out = response.read()
          response.close()
          cookie.save(COOKIEFILE, ignore_discard = True)
       except:
          pass
    return out

def _getUrl(url,data=None,header={}):
    if cloudflare_active == True:
       sess.headers = {'User-Agent': UA, 'Referer': base_url}
       out = scraper.get(url, headers=sess.headers).content
    else:
       out=''
       headers={'User-Agent': UA}
       headers.update(header)
       req = urllib2.Request(url,data,headers)
       try:
           response = urllib2.urlopen(req,timeout=TIMEOUT)
           out = response.read()
           response.close()
       except:
           pass
    return out

def getMovies(url,page=1,group=''):
    if '?page=' in url:
        url = url.replace('?page=','?page=%d' %page)
    else:
        url += '/' if url[-1] != '/' else ''
        url = url + '?page=%d' %page

    if group:
        url=url.split('?')[0]

    content = getUrl(url) 

    out=[]
    gr=False
    pr=False
    ids = []

    if group:
        idx = [(m.start(0), m.end(0)) for m in re.finditer('<h3>', content,re.IGNORECASE) ]
        idx.append( (content.find('<footer>'),content.find('<footer>')) )
        for i in range(len(idx[:-1])):
            match=content[ idx[i][0]:idx[i+1][0] ]
            if group in match:
                content = match
                ids = [(a.start(), a.end()) for a in re.finditer('<div class="col-xs-\d+', content)]
                ids.append( (-1,-1) )
                break

        for i in range(len(ids[:-1])):
            match = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile('<a href="(.*?)"',re.DOTALL).search(match)
            title = re.compile('title="(.*?)"',re.DOTALL).search(match)
            src = re.compile('<img src="(.*?)"',re.DOTALL).search(match)
            rating = re.compile('<div class="rate">(.*?)</div>',re.DOTALL).search(match)
            year =  re.compile('<div class="year">(.*?)<',re.DOTALL).search(match)

            if 'true' in my_addon.getSetting('searchDescription'):
               wc = _getUrl(href.group(1))
               description = re.compile('<p class="description">(.*?)<',re.DOTALL).search(wc)
            else:
               description = ''

            if href and title:
                src = src.group(1) if src else ''
                if src.startswith('//'):
                    src = 'http:'+src
                film = {
                    'href'   : href.group(1),
                    'title'  : fixSC(title.group(1)),
                    'plot'   : description.group(1) if description else '',
                    'img'    : src,
                    'rating' : rating.group(1) if rating else '',
                    'year'   : year.group(1) if year else '',
                        }
                out.append(film)

    else:
        mdata = re.compile('<ul class=["\']clearfix pagination["\']>(.*?)</ul>',re.DOTALL).findall(content)
        mdata = urllib.unquote(mdata[0]) if mdata else content
        gr=False

        if mdata.find( '?page=%d' %(page+1))>-1:
            gr = page+1

        idx = content.find('<h3>')
        if idx: content = content[0:idx]
        ids = [(a.start(), a.end()) for a in re.finditer('<div class="col-xs-\d col-sm-\d col-lg-\d', content)]
        ids.append( (-1,-1) )

        for i in range(len(ids[:-1])):
            match = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile('<a href="(.*?)"',re.DOTALL).search(match)
            title = re.compile('title="(.*?)"',re.DOTALL).search(match)
            src = re.compile('<img src="(.*?)"',re.DOTALL).search(match)
            rating = re.compile('<div class="rate">(.*?)</div>',re.DOTALL).search(match)
            year =  re.compile('<div class="year">(.*?)<',re.DOTALL).search(match)

            if 'true' in my_addon.getSetting('searchDescription'):
               wc = _getUrl(href.group(1))
               description = re.compile('<p class="description">(.*?)<',re.DOTALL).search(wc)
            else:
               description = ''

            if href and title:
                src = src.group(1) if src else ''
                if src.startswith('//'):
                    src = 'http:'+src
                film = {
                    'href'   : href.group(1),
                    'title'  : fixSC(title.group(1)),
                    'plot'   : description.group(1) if description else '',
                    'img'    : src,
                    'rating' : rating.group(1) if rating else '',
                    'year'   : year.group(1) if year else '',
                        }
                out.append(film)

        pr = page-1 if page>1 else False

    return (out, (pr,gr))

def getSeries(url, page = 1,group = ''):
    if '?page=' in url:
        url = url.replace('?page=','?page=%d' %page)
    else:
        url += '/' if url[-1] != '/' else ''
        url = url + '?page=%d' %page

    if group:
        url=url.split('?')[0]

    content = getUrl(url)

    out=[]
    gr=False
    pr=False
    ids = []

    if group:
        idx = [(m.start(0), m.end(0)) for m in re.finditer('<h3>', content,re.IGNORECASE) ]
        idx.append( (content.find('<footer>'),content.find('<footer>')) )
        for i in range(len(idx[:-1])):
            match=content[ idx[i][0]:idx[i+1][0] ]
            if group in match:
                content = match
                ids = [(a.start(), a.end()) for a in re.finditer('<div class="col-xs-\d+', content)]
                ids.append( (-1,-1) )
                break

        for i in range(len(ids[:-1])):
            match = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile('<a href="(.*?)"',re.DOTALL).search(match)
            title = re.compile('title="(.*?)"',re.DOTALL).search(match)
            src = re.compile('<img src="(.*?)"',re.DOTALL).search(match)
            rating = re.compile('<div class="rate">(.*?)</div>',re.DOTALL).search(match)
            year =  re.compile('<div class="year">(.*?)<',re.DOTALL).search(match)

            if 'true' in my_addon.getSetting('searchDescription'):
               wc = _getUrl(href.group(1))
               description = re.compile('<p class="description">(.*?)<',re.DOTALL).search(wc)
            else:
               description = ''

            if href and title:
                src = src.group(1) if src else ''
                if src.startswith('//'):
                    src = 'http:'+src
                film = {'href'   : href.group(1),
                    'title'  : fixSC(title.group(1)),
                    'plot'   : description.group(1) if description else '',
                    'img'    : src,
                    'rating' : rating.group(1) if rating else '',
                    'year'   : year.group(1) if year else '',
                        }
                out.append(film)
    else: 
        mdata = re.compile('<ul id=["\']series-list["\'] class=["\']filter["\']>(.*?)</ul>',re.DOTALL).findall(content)
        mdata = urllib.unquote(mdata[0]) if mdata else content
        gr = False

        if mdata.find( '?page=%d' %(page+1))>-1:
            gr = page+1

        ids = [(a.start(), a.end()) for a in re.finditer('<li>', mdata)]
        ids.append( (-1,-1) )

        for i in range(len(ids[:-1])):
            match = mdata[ ids[i][1]:ids[i+1][0] ]
            href = re.compile('<a href="(.*?)"',re.DOTALL).search(match)
            title = re.compile('title="(.*?)"',re.DOTALL).search(match)
            rating = ''
            year = ''
            src = ''

#            if 'true' in my_addon.getSetting('searchDescription'):
#               wc = _getUrl(href.group(1))
#               description = re.compile('<p class="description">(.*?)<',re.DOTALL).search(wc)
#            else:
#               description = ''

            if href and title:
                src = src.group(1) if src else ''
                if src.startswith('//'):
                    src = 'http:'+src
                film = {
                    'href'   : href.group(1),
                    'title'  : fixSC(title.group(1)),
                    #'plot'   : description.group(1) if description else '',
                    'img'    : src,
                    'rating' : rating.group(1) if rating else '',
                    'year'   : year.group(1) if year else '',
                        }
                out.append(film)

        pr = page-1 if page > 1 else False

    return (out, (pr,gr))

def getCaptcha(url,content,curl='https://nasze-kino.tv/captcha.jpg'):
    data = getUrl(curl)
    r=mc.keyboard(data)
    header={'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'upgrade-insecure-requests':1,
        'referer':url}
    suffix = 'captcha=%s&submit='%(r)
    data = getUrl(url,suffix,header)
    content = getUrl(url)
    if not content: content = scraper.get(url).content
    if re.search('<img src="(http.+?nasze-kino.tv/captcha.jpg)">',content):
        mc.getDialog('[COLOR red]Błąd captcha[/COLOR]','Nie o taki tekst chodziło!','Czy na pewno jestes człowiekiem?')
        content=''

    return content

def parseVideoLink(url, host = ''):
    if 'cda' in host:
        return 'http://www.cda.pl/video/%s'%(url.split('id=')[-1])
    elif 'alltube' in url:
        content = getUrl(url)
        outurl=''
        href= re.compile('src="(.*?)"').findall(content)
        if href:
            href = [h for h in href if BRAMKA not in h]
            outurl = getHref(href[0])
            if outurl.startswith('//'):
                outurl = 'http:'+outurl
        return outurl
    elif str(host) in url:
        if url.startswith('//'):
            url = 'http:' + url
        return url
    else:
        return url

def getVideos(url):
    content = getUrl(url)
    captcha = re.search('<img src="(http.+?nasze-kino.tv/captcha.jpg)">',content)

    if captcha:
        content = getCaptcha(url,content,captcha.group(1))

    data = re.compile('<tbody>(.*?)</tbody>',re.DOTALL).findall(content)
    data = data[0] if data else ''
    ids = [(a.start(), a.end()) for a in re.finditer('<tr>', data)]
    ids.append( (-1,-1) )
    out=[]

    for i in range(len(ids[:-1])):
        wc = data[ ids[i][1]:ids[i+1][0] ]
        href=re.compile('href="(.*?)"').search(wc)
        iframe = re.compile('data-iframe="(.*?)"').search(wc)
        info = ''.join(re.compile('>(.*?)<',re.DOTALL).findall(wc))
        info = re.sub(' +',' ',fixSC(info)).strip()
        if href:
            film = {'url' : href.group(1),'title': info,}
            out.append(film)

    return out

def scanEpisodes(url):
    content = getUrl(url)
    src = re.compile('<ul id="episode-list">(.*?)</ul>').findall(content)
    src = src[-1] if src else ''
    out=[]
    odcinki = content.find('Odcinki')
    odcinek = content.find('Dodaj odcinek')
    links = re.compile('<a href="(.*?)">(.*?)</a>',re.DOTALL).findall(content[odcinki:odcinek])
    imgsrc = re.compile('<div id="single-poster" class="col-sm-3">(.*?)</div>').search(content)
    imgsrc = imgsrc[-1] if imgsrc else ''
    imgsrc = re.compile('<img src="(.*?)"',re.DOTALL).search(imgsrc)

    for h,t in links:
        t= fixSC(t.strip())
        t=re.sub(' +',' ',t)
        data = re.compile('[sS](\d+)[Ee](\d+)').findall(t)
        film = {
            'href'  : h.strip(),
            'plot' : t,
            'title' : t,
            'img' : imgsrc,
            'season' : int(data[0][0]) if data else '',
            'episode' : int(data[0][1]) if data else '',
            'aired' : ''}
        out.append(film)

    return out

def splitToSeasons(out):
    out_s={}
    seasons = [x.get('season') for x in out]
    for s in set(seasons):
        out_s['Sezon %02d'%s]=[out[i] for i, j in enumerate(seasons) if j == s]

    return out_s

def getSort(mv='film',sc='category'):
    label=[]
    value=[]
    url = 'https://nasze-kino.tv/filmy-online/'

    if mv=='film':
        content = getUrl(url)

        if sc=='category':
            sp = re.compile('<ul id="filter-category" class="filter multiple-select term-list">(.*?)</ul',re.DOTALL).findall(content)[0]
            value = re.compile('data-id="(\d+)"').findall(sp)
            label = re.compile('<a href="#">(.+?)<').findall(sp)
        elif sc=='year':
            sp = re.compile('<ul id="filter-year" class="filter multiple-select term-list">(.*?)</ul',re.DOTALL).findall(content)[0]
            value = re.compile('data-id="(\d+)"').findall(sp)
            label = re.compile('<a href="#">(.+?)<').findall(sp)
        elif sc=='country': 
            sp = re.compile('<ul id="filter-country" class="filter multiple-select term-list">(.*?)</ul',re.DOTALL).findall(content)[0]
            value = re.compile('data-id="(\d+)"').findall(sp)
            sp = re.sub('	HiszpaniaWielka Brytania', 'Hiszpania/Wielka Brytania', sp)
            sp = re.sub(r'\s+', ' ', sp)
            label = re.compile('<a href="#">(.+?)<').findall(sp)
    elif mv=='serial':
        pass

    return (label,value)

def fixSC(pharse):
    if isinstance(pharse, unicode):
        pharse = pharse.encode('utf-8')

    pharse = pharse.replace('&lt;br/&gt;',' ')
    s='JiNcZCs7'
    pharse = re.sub(s.decode('base64'),'',pharse)
    pharse = pharse.replace('\n','').replace('\r','')
    pharse = pharse.replace('&nbsp;','')
    pharse = pharse.replace('&quot;','"').replace('&amp;quot;','"')
    pharse = pharse.replace('&oacute;','ó').replace('&Oacute;','Ó')
    pharse = pharse.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    pharse = pharse.replace('&amp;','&')
    pharse = pharse.replace('\u0105','ą').replace('\u0104','Ą')
    pharse = pharse.replace('\u0107','ć').replace('\u0106','Ć')
    pharse = pharse.replace('\u0119','ę').replace('\u0118','Ę')
    pharse = pharse.replace('\u0142','ł').replace('\u0141','Ł')
    pharse = pharse.replace('\u0144','ń').replace('\u0144','Ń')
    pharse = pharse.replace('\u00f3','ó').replace('\u00d3','Ó')
    pharse = pharse.replace('\u015b','ś').replace('\u015a','Ś')
    pharse = pharse.replace('\u017a','ź').replace('\u0179','Ź')
    pharse = pharse.replace('\u017c','ż').replace('\u017b','Ż')

    return pharse

def search(pharse='dom'):
    url='https://nasze-kino.tv/wyszukiwarka?phrase='+pharse
    content=getUrl(url)
    out1=[]
    out2=[]
    ids = [(a.start(), a.end()) for a in re.finditer('<div class="col-sm-\d+', content)]
    ids.append( (-1,-1) )

    for i in range(len(ids[:-1])):
        wc = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile('<a href="(.*?)"',re.DOTALL).search(wc)
        title = re.compile('title="(.*?)"',re.DOTALL).search(wc)
        description = re.compile('class="description text-justify">(.*?)<',re.DOTALL).search(wc)
        src = re.compile('src="(.*?)"',re.DOTALL).search(wc)
        rating = re.compile('</b>\s*(\d\.\d)</span>',re.DOTALL).search(wc)
        year =  re.compile('<div class="year">(.*?)<',re.DOTALL).search(wc)

        if href and title:
            src = src.group(1).replace('/thumb/','/big/') if src else ''
            film = {
                'href'   : href.group(1),
                'title'  : fixSC(title.group(1)),
                'plot'   : fixSC(description.group(1)) if description else '',
                'img'    : src,
                'rating' : rating.group(1) if rating else '',
                'year'   : year.group(1) if year else '',
                    }

            if '/film' in film['href']:
                out1.append(film)
            elif '/serial'in film['href']:
                out2.append(film)

    return out1,out2
