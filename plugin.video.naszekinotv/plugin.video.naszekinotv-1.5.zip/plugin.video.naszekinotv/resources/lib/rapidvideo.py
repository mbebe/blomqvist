# -*- coding: utf-8 -*-
import urllib2,urllib
import re,random,json
import cookielib

TIMEOUT=10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'

def getUrl(url,data=None,header={},useCookies=True):
    out=''
    cookie=[]
    if useCookies:
        cookie = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookie))
        urllib2.install_opener(opener)

    if not header:
        header = {'User-Agent':UA}
    req = urllib2.Request(url,data,headers=header)

    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        out =  response.read()
        response.close()
        cout = ''.join(['%s=%s;'%(c.name, c.value) for c in cookie])
    except urllib2.HTTPError as e:
        out = ''

    return out,cout

url = 'https://www.rapidvideo.com/embed/V2VsVKXP'
url = 'https://www.rapidvideo.com/embed/ECcyARgM'

def getVideos(url):
    url = url.replace('http:','https:').replace('/embed/','/?v=')
    content,c = getUrl(url)
    match = re.findall('''["']?sources['"]?\s*:\s*(\[.*?\])''', content)
    out=''

    if not match:
        data = {}
        data['confirm.y'] = random.randint(0, 120)
        data['confirm.x'] = random.randint(0, 120)
        header={'User-Agent':UA,'Referer':url}
        curl = url + '#'
        content,c = getUrl(curl,urllib.urlencode(data),header=header)
        match = re.findall('''["']?sources['"]?\s*:\s*(\[.*?\])''', content)

    if match:
        try:
            data = json.loads(match[0])
            out=[]
            for d in data:
                if isinstance(d,dict):
                    hd = d.get('file','')+'|User-Agent=%s&Referer=%s'%(UA,url)
                    out.append((d.get('label',''),hd))
        except:
            out = re.findall('''['"]?file['"]?\s*:\s*['"]?([^'"]+)''', match[0])
            if out:
                out = out[0].replace('\/', '/')
                out += '|User-Agent=%s&Referer=%s'%(UA,url)

    return out
