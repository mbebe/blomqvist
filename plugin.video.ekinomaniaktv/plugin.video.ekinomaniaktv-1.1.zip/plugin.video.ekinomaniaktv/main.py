# -*- coding: utf-8 -*-

import urlparse,sys,urllib
params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
mode = params.get('mode')
fname = params.get('foldername')
ex_link = params.get('ex_link')
page = params.get('page')

import xbmcgui,xbmc
import time,os
dialog = xbmcgui.Dialog()
import time,threading

if mode is None:
    from resources.lib import default
    default.default().root()
elif mode.startswith('__page__:'):
    from resources.lib import default
    default.default().page(mode,ex_link)
elif mode == 'mainP':
    from resources.lib import default
    default.default().mainP(ex_link)
elif mode == 'content':
    from resources.lib import default
    default.default().content(ex_link)
elif mode == 'getSeasons':
    from resources.lib import default
    default.default().getSeasons(ex_link)
elif mode == 'getEpisodes':
    from resources.lib import default
    default.default().getEpisodes(ex_link)
elif mode == 'getLink':
    from resources.lib import default
    default.default().getLink(ex_link)
elif mode.startswith('search'):
    from resources.lib import default
    default.default().search(mode,ex_link)
elif mode == 'user_content':
    from resources.lib import default
    default.default().usrContent(ex_link)
elif mode == 'AddToLibrary':
    from resources.lib import default
    default.default().addToLibrOk(ex_link)