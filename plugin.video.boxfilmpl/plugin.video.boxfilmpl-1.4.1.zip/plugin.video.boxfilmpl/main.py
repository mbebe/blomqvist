# -*- coding: utf-8 -*-
import urlparse,sys

params  = dict(urlparse.parse_qsl(sys.argv[2].replace('?', '')))
mode    = params.get('mode')
ex_link = params.get('ex_link')

if mode is None:
    from resources.lib import default
    default.boxfilm().root()
elif mode == 'kategorie':
    from resources.lib import default
    default.boxfilm().category()
elif mode == 'content':
    from resources.lib import default
    default.boxfilm().content(ex_link)
elif mode.startswith('__page__:'):
    from resources.lib import default
    default.boxfilm().page(mode, ex_link)
elif mode.startswith('search'):
    from resources.lib import default
    default.boxfilm().search(mode, ex_link)
elif mode == 'playboxfilm':
    from resources.lib import default
    default.boxfilm().playboxfilm(ex_link)
