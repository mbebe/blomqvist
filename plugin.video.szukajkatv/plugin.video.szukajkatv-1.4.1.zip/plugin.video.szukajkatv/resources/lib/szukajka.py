# -*- coding: utf-8 -*-
import urllib2,urllib
import re,os,sys
import json
import cookielib
import time
from urlparse import urlparse, urljoin

TIMEOUT = 15
UA = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'

def getUrl(url,data=None,header={},useCookies=True,NC=True):
    if COOKIEFILE and useCookies:
        cookie = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookie),urllib2.HTTPRedirectHandler())
        urllib2.install_opener(opener)
    if not header:
        header = {'User-Agent':UA}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        out =  response.read()
        response.close()
        if COOKIEFILE and NC and useCookies:
            cp=os.path.dirname(COOKIEFILE)
            if not os.path.exists(cp): os.makedirs(cp)
            if cookie: cookie.save(COOKIEFILE, True, True)
    except urllib2.HTTPError as e:
        out = ''
    return out

def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        out_dict[k] = v
    return out_dict

def getSearch(url='http://szukajka.tv',data='?q=&s=5&h=0&v=0&a='):
    content = ''
    if isinstance(data,dict):
        data = urllib.urlencode(encoded_dict(data)).replace('+','%20')

    content = getUrl(url,data=data,useCookies=True)
    items = re.compile('<a class="link"(.*?)</a>',re.DOTALL).findall(content)
    out=[]

    for it in items:
        href = re.compile('href="(.*?)" target="_blank">',re.DOTALL).search(it)
        href = href.group(1).strip() if href else ''
        image = re.compile('src="(.*?)"',re.DOTALL).search(it)
        image = image.group(1).strip() if image else ''
        title = re.compile('<(?:span|div) class="title">(.*?)</(?:span|div)>',re.DOTALL).search(it)
        title = title.group(1) if title else ''
        wc = re.compile('<div class="bottom">(.*?)</div>',re.DOTALL).findall(it)
        wc = wc[0] if wc else ''
        version = re.compile('<span class="version"><i class=.*></i>(.*?)</span>').findall(wc)
        version = version[0].strip() if version else ''
        duration = re.compile('<span class="duration"><i class=.*></i>(.*?)</span>').findall(wc)
        duration = duration[0].strip() if duration else ''
        size = re.compile('<span class="size"><i class="fa fa-database" aria-hidden="true"></i>(.*?)</span>').findall(wc)
        size = size[0].strip() if size else ''
        host = re.search('<span class="host">.*alt="(.*?)"/>',wc)
        host = '[COLOR blue]%s[/COLOR]'%host.group(1) if host else ''
        plot = 'Host:%s\nWersja:%s\nCzas:%s\nRozmiar:%s\n'%(host,version,duration,size)
        if href and title:
            df = {
                'url'   : href,
                'title'  : unicodePLchar(title),
                'plot'   : plot,
                'img'    : image,
                'code'   : host+','+version}
            out.append(df)
    return out

def jsVerify(url):
    vout=''
    if COOKIEFILE:
        import decabc
        cookie = cookielib.LWPCookieJar()
        cookie.load(COOKIEFILE,True,True)
        cv = ';'.join(['%s=%s'%(c.name,c.value) for c in cookie])
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookie))
        urllib2.install_opener(opener)
        header = {'User-Agent':UA,'X-Requested-With':'XMLHttpRequest','Cookie':cv,'Referer':url}
        req = urllib2.Request('http://szukajka.tv/jsverify.php?op=tag',None,headers=header)
        try:
            response = urllib2.urlopen(req,timeout=TIMEOUT)
            data =  json.loads(response.read())
            response.close()
            d = {}
            for i in range(len(data['key'])):
                d[data['key'][i]] = data['hash'][i]
            in_abc = ''
            for k in sorted(d.keys()):
                in_abc += d[k]
            vout = 'tmvh=%s;%s' % (decabc.abc(in_abc), cv)
        except:
            pass

    return vout

def getLink(url):
    out=''
    link = url.split('-')[0].split('/')[-1]
    cv = jsVerify(url)
    if cv:
        header={'User-Agent':UA,
            'Referer':url,
            'Cookie':cv,
            }
        content = getUrl('http://szukajka.tv/link/'+link,header=header,useCookies=False,NC=False)
        iframe = re.compile('<iframe(.*?)</iframe>',re.DOTALL).findall(content)
        if iframe:
            out = re.compile('src=[\'"](.*?)[\'"]').findall(iframe[0])
            out = out[0] if out else ''
            if 'cda.pl' in out: out = out.replace('[width]x[height]','700x400')
    return out

def getVideos(url):
    content = getUrl(url,useCookies=True,NC=False)
    element= re.compile('<div class="element">(.*?)</div>',re.DOTALL).findall(content)
    out=[]
    for e in element:
        href = re.search('href="(.*?)"',e)
        title = re.compile('>(.*?)<',re.DOTALL).findall(e)
        title = ''.join([' '+x.strip() for x in title if x.strip()]).strip()
        image = re.compile('<img src="(.*?)"').findall(e)
        host = '[COLOR blue]%s[/COLOR]'%image[0].split('/')[-1].split('.')[0] if image else ''
        if href and title:
            df = {
            'url'   : href.group(1),
            'img' : 'img',
            'title' : '[I]'+unicodePLchar(title)+'[/I]',
            'code'  : host}
            out.append(df)
    return out

def getHost(host='host'):
    content = getUrl('http://szukajka.tv/?q=')
    value=[]
    label=[]
    select=re.compile('<select name="%s" id="%s">(.*?)</select>'%(host,host),re.DOTALL).findall(content)

    if select:
        out = re.compile('<option value="(.*?)">(.*?)</option>').findall(select[0])
        value = [x[0] for x in out]
        label= [unicodePLchar(x[1]) for x in out]

    return (value,label)

def unicodePLchar(txt):
    if type(txt) is not str:
        txt=txt.encode('utf-8')

    txt = txt.replace('''&nbsp;''','')
    txt = txt.replace('''&quot;''','"')
    txt = txt.replace('''&bdquo;''','\'')
    txt = txt.replace('''&rdquo;''','\'')
    txt = txt.replace('''&oacute;''','ó').replace('''&Oacute;''','Ó')
    txt = txt.replace('''&rsquo;''','\'')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    s='26235c642b3b'
    t='265b5e3b5d3b'
    txt = re.sub(s.decode('hex'),'',txt)
    txt = re.sub(t.decode('hex'),'',txt)
    txt = txt.replace('''&amp;''','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')

    return txt


