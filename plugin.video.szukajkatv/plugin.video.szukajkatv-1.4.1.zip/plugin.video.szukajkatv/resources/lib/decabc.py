# -*- coding: utf-8 -*-

def abc(in_abc):
    def rhex(a):
        hex_chr = '0123456789abcdef'
        ret = ''
        for i in range(4):
            ret += hex_chr[(a >> (i * 8 + 4)) & 0x0F] + hex_chr[(a >> (i * 8)) & 0x0F]
        return ret
    def hex(text):
        ret = ''
        for i in range(len(text)):
            ret += rhex(text[i])
        return ret
    def add32(a, b):
        return (a + b) & 0xFFFFFFFF
    def cmn(a, b, c, d, e, f):
        b = add32(add32(b, a), add32(d, f));
        return add32((b << e) | (b >> (32 - e)), c)
    def ff(a, b, c, d, e, f, g):
        return cmn((b & c) | ((~b) & d), a, b, e, f, g)
    def gg(a, b, c, d, e, f, g):
        return cmn((b & d) | (c & (~d)), a, b, e, f, g)
    def hh(a, b, c, d, e, f, g):
        return cmn(b ^ c ^ d, a, b, e, f, g)
    def ii(a, b, c, d, e, f, g):
        return cmn(c ^ (b | (~d)), a, b, e, f, g)
    def cryptcycle(tabA, tabB):
        a = tabA[0]
        b = tabA[1]
        c = tabA[2]
        d = tabA[3]
        a = ff(a, b, c, d, tabB[0], 7, -680876936);
        d = ff(d, a, b, c, tabB[1], 12, -389564586);
        c = ff(c, d, a, b, tabB[2], 17, 606105819);
        b = ff(b, c, d, a, tabB[3], 22, -1044525330);
        a = ff(a, b, c, d, tabB[4], 7, -176418897);
        d = ff(d, a, b, c, tabB[5], 12, 1200080426);
        c = ff(c, d, a, b, tabB[6], 17, -1473231341);
        b = ff(b, c, d, a, tabB[7], 22, -45705983);
        a = ff(a, b, c, d, tabB[8], 7, 1770035416);
        d = ff(d, a, b, c, tabB[9], 12, -1958414417);
        c = ff(c, d, a, b, tabB[10], 17, -42063);
        b = ff(b, c, d, a, tabB[11], 22, -1990404162);
        a = ff(a, b, c, d, tabB[12], 7, 1804603682);
        d = ff(d, a, b, c, tabB[13], 12, -40341101);
        c = ff(c, d, a, b, tabB[14], 17, -1502002290);
        b = ff(b, c, d, a, tabB[15], 22, 1236535329);
        a = gg(a, b, c, d, tabB[1], 5, -165796510);
        d = gg(d, a, b, c, tabB[6], 9, -1069501632);
        c = gg(c, d, a, b, tabB[11], 14, 643717713);
        b = gg(b, c, d, a, tabB[0], 20, -373897302);
        a = gg(a, b, c, d, tabB[5], 5, -701558691);
        d = gg(d, a, b, c, tabB[10], 9, 38016083);
        c = gg(c, d, a, b, tabB[15], 14, -660478335);
        b = gg(b, c, d, a, tabB[4], 20, -405537848);
        a = gg(a, b, c, d, tabB[9], 5, 568446438);
        d = gg(d, a, b, c, tabB[14], 9, -1019803690);
        c = gg(c, d, a, b, tabB[3], 14, -187363961);
        b = gg(b, c, d, a, tabB[8], 20, 1163531501);
        a = gg(a, b, c, d, tabB[13], 5, -1444681467);
        d = gg(d, a, b, c, tabB[2], 9, -51403784);
        c = gg(c, d, a, b, tabB[7], 14, 1735328473);
        b = gg(b, c, d, a, tabB[12], 20, -1926607734);
        a = hh(a, b, c, d, tabB[5], 4, -378558);
        d = hh(d, a, b, c, tabB[8], 11, -2022574463);
        c = hh(c, d, a, b, tabB[11], 16, 1839030562);
        b = hh(b, c, d, a, tabB[14], 23, -35309556);
        a = hh(a, b, c, d, tabB[1], 4, -1530992060);
        d = hh(d, a, b, c, tabB[4], 11, 1272893353);
        c = hh(c, d, a, b, tabB[7], 16, -155497632);
        b = hh(b, c, d, a, tabB[10], 23, -1094730640);
        a = hh(a, b, c, d, tabB[13], 4, 681279174);
        d = hh(d, a, b, c, tabB[0], 11, -358537222);
        c = hh(c, d, a, b, tabB[3], 16, -722521979);
        b = hh(b, c, d, a, tabB[6], 23, 76029189);
        a = hh(a, b, c, d, tabB[9], 4, -640364487);
        d = hh(d, a, b, c, tabB[12], 11, -421815835);
        c = hh(c, d, a, b, tabB[15], 16, 530742520);
        b = hh(b, c, d, a, tabB[2], 23, -995338651);
        a = ii(a, b, c, d, tabB[0], 6, -198630844);
        d = ii(d, a, b, c, tabB[7], 10, 1126891415);
        c = ii(c, d, a, b, tabB[14], 15, -1416354905);
        b = ii(b, c, d, a, tabB[5], 21, -57434055);
        a = ii(a, b, c, d, tabB[12], 6, 1700485571);
        d = ii(d, a, b, c, tabB[3], 10, -1894986606);
        c = ii(c, d, a, b, tabB[10], 15, -1051523);
        b = ii(b, c, d, a, tabB[1], 21, -2054922799);
        a = ii(a, b, c, d, tabB[8], 6, 1873313359);
        d = ii(d, a, b, c, tabB[15], 10, -30611744);
        c = ii(c, d, a, b, tabB[6], 15, -1560198380);
        b = ii(b, c, d, a, tabB[13], 21, 1309151649);
        a = ii(a, b, c, d, tabB[4], 6, -145523070);
        d = ii(d, a, b, c, tabB[11], 10, -1120210379);
        c = ii(c, d, a, b, tabB[2], 15, 718787259);
        b = ii(b, c, d, a, tabB[9], 21, -343485551);
        tabA[0] = add32(a, tabA[0]);
        tabA[1] = add32(b, tabA[1]);
        tabA[2] = add32(c, tabA[2]);
        tabA[3] = add32(d, tabA[3])
    def cryptblk(text):
        ret = []
        for i in range(0, 64, 4):
            ret.append(ord(text[i]) + (ord(text[i+1]) << 8) + (ord(text[i+2]) << 16) + (ord(text[i+3]) << 24))
        return ret
    def jcsys(text):
        txt = '';
        txtLen = len(text)
        ret = [1732584193, -271733879, -1732584194, 271733878]
        i = 64
        while i <= len(text):
            cryptcycle(ret, cryptblk(text['substring'](i - 64, i)))
            i += 64
        text = text[i - 64:]
        tmp = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        i = 0
        while i < len(text):
            tmp[i >> 2] |= ord(text[i]) << ((i % 4) << 3)
            i += 1
        tmp[i >> 2] |= 0x80 << ((i % 4) << 3)
        if i > 55:
            cryptcycle(ret, tmp);
            for i in range(16):
                tmp[i] = 0
        tmp[14] = txtLen * 8;
        cryptcycle(ret, tmp);
        return ret

    def rezedowa(text):
        return hex(jcsys(text))
    return rezedowa(in_abc)
