# -*- coding: utf-8 -*-
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import time,threading

try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
   
cache = StorageServer.StorageServer("szukajkatv")

base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonName       = my_addon.getAddonInfo('name')
PATH            = my_addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'

import resources.lib.szukajka as sz

sz.COOKIEFILE = os.path.join(DATAPATH,'sz.cookie')
FANART = ''

def addLinkItem(name, url, mode, params={}, iconimage='DefaultFolder.png', infoLabels=False, isFolder=False, IsPlayable=True,fanart=FANART,contextmenu=1):
    u = buildUrl({'mode': mode, 'foldername': name, 'ex_link' : url, 'params':params})
    liz = xbmcgui.ListItem(name)
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconimage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    art['fanart'] = fanart if fanart else art['landscape']
    liz.setArt(art)

    if not infoLabels:
        infoLabels={"title": name}

    liz.setInfo(type="video", infoLabels=infoLabels)

    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')

    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=isFolder,totalItems=contextmenu)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
    return ok

def addDir(name,ex_link=None, params={}, mode='folder',iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART,contextmenu=None):
    url = buildUrl({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'params' : params})
    li = xbmcgui.ListItem(name)

    if infoLabels:
        li.setInfo(type="video", infoLabels=infoLabels)

    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconImage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    art['fanart'] = fanart if fanart else art['landscape']
    li.setArt(art)

    if contextmenu:
        info=contextmenu
        li.addContextMenuItems(info, replaceItems=True)

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        out_dict[k] = v
    return out_dict

def buildUrl(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))

def ListItems(ex_link,params):
    data = sz.getSearch(url=ex_link,data=params)
    gp = int(params.get('p','0'))

    if gp > 0:
        lpar = params
        lpar['p']=gp-1
        addLinkItem(name='[COLOR orange]<< Poprzednia strona <<[/COLOR]', url=ex_link, params=lpar, mode='page:ListItems', IsPlayable=False)

    items=len(data)

    for f in data:
        addLinkItem(name=f.get('title'), url=f.get('url',''), mode='getContent', params=f,iconimage=f.get('img'), infoLabels=f, isFolder=True, IsPlayable=False,contextmenu=items)

    if items > 40:
        lpar = params
        lpar['p']=gp+1
        addLinkItem(name='[COLOR orange]>> Następna strona >>[/COLOR]', url=ex_link, params=lpar, mode='page:ListItems', IsPlayable=False)

def getContent(ex_link):
    f=params
    addLinkItem(name='[B]%s[/B]'%f.get('title'), url=f.get('url',''), mode='getLink', iconimage=f.get('img'), infoLabels=f, isFolder=False, IsPlayable=True,contextmenu=1)
    data = sz.getVideos(ex_link)

    for f in data:
        addLinkItem(name=f.get('title'), url=f.get('url',''), mode='getLink', iconimage=f.get('img'), infoLabels=f, isFolder=False, IsPlayable=True,contextmenu=1)

def _getLink(mlin):
    import resolveurl as urlresolver
    glin = ''

    if not glin:
        try:
            glin = urlresolver.resolve(mlin)
        except Exception,e:
            glin=''
            xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link będzie działał?','ERROR: %s'%str(e))
    return glin

def getLink(ex_link):
    mlin = sz.getLink(ex_link)
    glin = _getLink(mlin)

    if glin:
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=glin))
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

def getCache():
    return cache.get('history').split(';')

def getNew(flin):
    inca = getCache()

    if inca == ['']:
        cache.delete('history')
        inca = []

    inca.insert(0, flin )
    newdata = ';'.join([ h.encode('utf8') if isinstance(h, unicode) else h.decode('utf8')  for h in inca[:50]] )

    try:
        newdata = newdata.encode('utf-8')
    except:
        pass

    cache.set('history',newdata)

def setCache(flin):
    inca = getCache()
    if inca:
        cache.set('history',';'.join(inca[:50]))
    else:
        delHistory()

def delHistory():
    cache.delete('history')

mode     = args.get('mode', None)
fname    = args.get('foldername',[''])[0]
ex_link  = args.get('ex_link',[''])[0]
params   = args.get('params',[{}])[0]
params   = eval(params) if params else {}
sortv    = my_addon.getSetting('sortV')
sortn    = my_addon.getSetting('sortN') if sortv else 'Brak'
hostv    = my_addon.getSetting('hostV')
hostn    = my_addon.getSetting('hostN') if hostv else 'Malejąco'
versionv = my_addon.getSetting('versionV')
versionn = my_addon.getSetting('versionN') if versionv else 'Wszystkie'

def getSort():
    s=sortv if sortv else ''
    h=hostv if hostv else '0'
    v=versionv if versionv else '0'
    return {'s':s ,'h':h,'v':v}

if mode is None:
    addLinkItem("[COLOR blue]Sortowanie:[/COLOR] [B]"+sortn+"[/B]",'',mode='filtr:sort',iconimage='',IsPlayable=False)
    addLinkItem("[COLOR blue]Host:[/COLOR] [B]"+hostn+"[/B]",'',mode='filtr:host',iconimage='',IsPlayable=False)
    addLinkItem("[COLOR blue]Wersje:[/COLOR] [B]"+versionn+"[/B]",'',mode='filtr:version',iconimage='', IsPlayable=False)
    addDir(name="Szukajka",ex_link='http://szukajka.tv/szukaj',params={'q':'','p':'0','a':''}, mode='ListItems',iconImage='')
    addDir('[COLOR lightblue]Szukaj[/COLOR]',ex_link='http://szukajka.tv/szukaj',params={'q':'','p':'0','a':''},infoLabels={'plot':'Szukanie uwzględnia opcje: [B]Sortowanie|Host|Wersja[/B]'},mode='Szukaj')

elif 'filtr' in mode[0]:
    ws = mode[0].split(":")[-1]

    if ws=='sort':
        label=['Brak','Najlepsza trafność','Ostatnio dodane','Najczęśniej komentowane','Ostatnio skomentowane','Alfabetycznie']
        value=['','5','1','2','3','4']
        msg = 'Sortowanie'

    elif ws=='host':
        value,label = sz.l111lll_sz_(ws)
        msg = ws.title()

    elif ws=='version':
        label=['Wszystkie wersje','Oryginalny','Polski','Napisy','Lektor','Lektor IVO','Dubbing']
        value=['0','1','2','3','4','5','6']
        msg = 'Wersje'

    s = xbmcgui.Dialog().select(msg,label)
    s = s if s>-1 else 0
    my_addon.setSetting(ws+'V',value[s])
    my_addon.setSetting(ws+'N',label[s])
    xbmc.executebuiltin('XBMC.Container.Refresh')

elif mode[0] =='Szukaj':
    addDir('[COLOR blue]Nowe Szukanie[/COLOR]',ex_link=ex_link,params=params,mode='SzukajNowe')
    data = getCache()
    if not data == ['']:
        for flin in data:
            contextmenu = []
            contextmenu.append(('Usuń', 'XBMC.Container.Refresh(%s)'% buildUrl({'mode': 'SzukajUsun', 'ex_link' : flin})),)
            contextmenu.append(('Usuń całą historię', 'XBMC.Container.Update(%s)' % buildUrl({'mode': 'SzukajUsunAll'})),)
            addDir(name=flin, ex_link='http://szukajka.tv/szukaj',params={'q':flin,'p':'0','a':''} , mode='ListItems', contextmenu=contextmenu)

elif mode[0] =='SzukajNowe':
    d = xbmcgui.Dialog().input('Szukaj, Podaj nazwę pliku', type=xbmcgui.INPUT_ALPHANUM)
    if d:
        flin = d.encode('utf8') if isinstance(d, unicode) else d.decode('utf8')
        getNew(flin)
        params = {'q':flin,'p':'0','a':''}
        params.update(getSort())
        url = buildUrl({'mode': 'ListItems', 'foldername': '', 'ex_link' : 'http://szukajka.tv/szukaj', 'params':params})
        xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] =='SzukajUsun':
    setCache(ex_link)
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  buildUrl({'mode': 'Szukaj'}))

elif mode[0] == 'SzukajUsunAll':
    delHistory()
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  buildUrl({'mode': 'Szukaj'}))

elif mode[0].startswith('page'):
    nc,no = mode[0].split(':')
    url = buildUrl({'mode': no, 'foldername': '', 'ex_link' : ex_link, 'params':str(params)})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == 'ListItems':
    params = eval(params) if not isinstance(params,dict) else params
    params.update(getSort())
    ListItems(ex_link,params)

elif mode[0] == 'getContent':
    getContent(ex_link)

elif mode[0] =='getLink':
    getLink(ex_link)

else:
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
xbmcplugin.endOfDirectory(addon_handle)
