# coding: UTF-8
import sys
l11ll_sz_ = sys.version_info [0] == 2
l111_sz_ = 2048
l1lll_sz_ = 7
def l111l_sz_ (ll_sz_):
	global l11l1l_sz_
	l11l11_sz_ = ord (ll_sz_ [-1])
	l1111_sz_ = ll_sz_ [:-1]
	l1l1l1_sz_ = l11l11_sz_ % len (l1111_sz_)
	l1ll_sz_ = l1111_sz_ [:l1l1l1_sz_] + l1111_sz_ [l1l1l1_sz_:]
	if l11ll_sz_:
		l1l1ll_sz_ = unicode () .join ([unichr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	else:
		l1l1ll_sz_ = str () .join ([chr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	return eval (l1l1ll_sz_)