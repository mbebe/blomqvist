# -*- coding: utf-8 -*-

HEADER = { 'User-Agent': 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.69 Safari/537.36'}
TIMEOUT_ = 10

def getUrl(url,data={},headers={}):
    req = urllib2.Request(url,json.dumps(data),headers=headers)
    try:
        response = urllib2.urlopen(req, timeout=10)
        link = response.read()
        response.close()
    except:
        link=''
    return link

def getSess_(url):
    if 'sh.st/' in url:
        url = getDestUrl(url)
    elif 'safelinking.net' in url:
        url = _getUrl_(url)
    elif 'viid.me' in url:
        url = _getUri_(url)
    return url

def _getUri_(uri):
    destURL_=''
    html = getUrl(uri, headers=HEADER)
    sessID_ = re.findall('sessionId\:(.*?)\"\,', html)
    if len(sessID_) > 0:
        sessID_ = re.sub('\s\"', '', sessID_[0])
        headers_ = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.46 Safari/535.11',
            'Accept-Encoding': 'gzip,deflate,sdch',
            'Accept-Language': 'en-US,en;,q=0.8',
            'Connection': 'keep-alive',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Host': 'sh.st',
            'Referer': uri,
            'Origin': 'http://viid.me',
            'X-Requested-With': 'XMLHttpRequest'
        }
        time.sleep(5)
        urlSESS_ = 'http://viid.me/shortest-url/end-adsession?adSessionId=%s&adbd=1&callback=c'%sessID_
        response = getUrl(urlSESS_, headers=headers_)
        destURL_=re.search('"destinationUrl":"(.*?)"',response)
        if destURL_:
            destURL_=destURL_.group(1).replace('\\','')
    return destURL_

def _getUrl_(url):
    hash = url.split('/')[-1]
    liczba_ = {'hash': hash}
    headers = { 'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'}
    response = getUrl('http://safelinking.net/v1/protected',data=liczba_,headers=headers)
    jsonLoad = json.loads( response)
    if jsonLoad:
        streams=jsonLoad.get('links',[])
        if len(streams):
            url=streams[0].get('url','')
    return url

def getDestUrl(uri):
    destURL_=''
    html = getUrl(uri, headers=HEADER)
    sessID_ = re.findall('sessionId\:(.*?)\"\,', html)
    if len(sessID_) > 0:
        sessID_ = re.sub('\s\"', '', sessID_[0])
        headers_ = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.46 Safari/535.11',
            'Accept-Encoding': 'gzip,deflate,sdch',
            'Accept-Language': 'en-US,en;,q=0.8',
            'Connection': 'keep-alive',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Host': 'sh.st',
            'Referer': uri,
            'Origin': 'http://sh.st',
            'X-Requested-With': 'XMLHttpRequest'
        }
        time.sleep(5)
        urlSESS_ = 'http://sh.st/shortest-url/end-adsession?adSessionId=%s&adbd=1&callback=c'%sessID_
        response = getUrl(urlSESS_, headers=headers_)
        destURL_=re.search('"destinationUrl":"(.*?)"',response)
        if destURL_:
            destURL_=destURL_.group(1).replace('\\','')
    return destURL_


