# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2
import re,json
#from ramic import go as l1l1lllllll11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡦ࡬ࡰ࠲ࡵࡲ࠯ࡔࡧ࡭ࡱ࠽࠴࡮ࡴࡨ࠲ࡸࡷࡧ࡮ࡴ࡯࡬ࡷ࡯࡫࠮ࡹࡵࡳࠫᗟ")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ᗠ")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᗡ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠩࠪᗢ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(Variable4 (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤ࡭ࡷࡴࡴࠠࡩ࡫ࡧࡨࡪࡴࠢ࠿ࠪࡾ࠲࠯ࡅࡽࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩᗣ")).findall(content)
    l1l1llll11l11l111_tv_=[]
    for data in l1lll1lllll11l111_tv_:
        data = json.loads(data)
        code = Variable4 (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡱ࡯ࡧࡩࡶࡪࡶࡪ࡫࡮࡞ࡎ࡬ࡺࡪࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᗤ") if Variable4 (u"ࠬ࡜ࡉࡅࡇࡒࡣࡕࡒࡁ࡚ࡋࡑࡋࠬᗥ") in data.get(Variable4 (u"࠭ࡳࡵࡣࡷࡹࡸ࠭ᗦ"),Variable4 (u"ࠧࠨᗧ")) else Variable4 (u"ࠨࠩᗨ")
        href = data.get(Variable4 (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩᗩ"),{}).get(Variable4 (u"ࠪࡪ࡮ࡲࡥࠨᗪ"),Variable4 (u"ࠫࠬᗫ"))
        title = data.get(Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫᗬ"))
        l1ll1ll11l1l11l111_tv_ = Variable4 (u"࠭ࠥࡴ࡞ࡱࠩࡸࡢ࡮ࠦࡵ࡟ࡲࠪࡹࠧᗭ")%(data.get(Variable4 (u"ࠧࡥࡧࡶࡧࠬᗮ"),Variable4 (u"ࠨࠩᗯ")),data.get(Variable4 (u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫᗰ"),Variable4 (u"ࠪࠫᗱ")),data.get(Variable4 (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫᗲ"),{}).get(Variable4 (u"ࠬࡹࡴࡢࡴࡷࠫᗳ"),Variable4 (u"࠭ࠧᗴ")),data.get(Variable4 (u"ࠧࡱࡣࡵࡥࡲࡹࠧᗵ"),{}).get(Variable4 (u"ࠨࡵࡷࡳࡵ࠭ᗶ"),Variable4 (u"ࠩࠪᗷ")))
        title = l1l1lllllll11l111_tv_[Variable4 (u"ࠪࡨࡪࡩ࡯ࡥࡧࡋࡘࡒࡒࡥ࡯ࡶࡵ࡭ࡪࡹࠧᗸ")](title)
        l1ll1ll11l1l11l111_tv_ = l1l1lllllll11l111_tv_[Variable4 (u"ࠫࡩ࡫ࡣࡰࡦࡨࡌ࡙ࡓࡌࡦࡰࡷࡶ࡮࡫ࡳࠨᗹ")](l1ll1ll11l1l11l111_tv_)
        l1l1l1ll11l111_tv_ = {Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫᗺ"):title.strip(),Variable4 (u"࠭ࡰ࡭ࡱࡷࠫᗻ"):l1ll1ll11l1l11l111_tv_,Variable4 (u"ࠧࡶࡴ࡯ࠫᗼ"):href,Variable4 (u"ࠨࡥࡲࡨࡪ࠭ᗽ"):code}
        if code:l1l1llll11l11l111_tv_.append(l1l1l1ll11l111_tv_)
    if not l1l1llll11l11l111_tv_:
        l1l1llll11l11l111_tv_=[{Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨᗾ"):Variable4 (u"ࠪࡅࡰࡺࡵࡢ࡮ࡱ࡭ࡪࠦࡢࡳࡣ࡮ࠤࡹࡸࡡ࡯ࡵࡰ࡭ࡸࡰࡩࠡࡰࡤࠤঁࡿࡷࡰࠩᗿ"),Variable4 (u"ࠫࡺࡸ࡬ࠨᘀ"):Variable4 (u"ࠬ࠭ᘁ")}]
    return l1l1llll11l11l111_tv_
def l111l1lll11l111_tv_(url):
    url = url.replace(Variable4 (u"࠭࠯࡯ࡸࡵ࠳ࠬᘂ"), Variable4 (u"ࠧ࠰࡮࡬ࡺࡪ࡮࡬ࡴ࠱ࠪᘃ")) + Variable4 (u"ࠣ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡲ࠹ࡵ࠹ࠤᘄ")
    return [{Variable4 (u"ࠩࡸࡶࡱ࠭ᘅ"):url,Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᘆ"):Variable4 (u"ࠫࡸࡺࡲࡦࡣࡰࠫᘇ")}]
