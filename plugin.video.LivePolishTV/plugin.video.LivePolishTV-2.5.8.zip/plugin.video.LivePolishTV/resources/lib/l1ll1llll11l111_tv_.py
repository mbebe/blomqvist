# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
import time
import l1ll11ll1ll11l111_tv_
import urlparse
import cookielib
import threading
__all__=[Variable4 (u"࠭ࡧࡦࡶࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ᭗"),Variable4 (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯࡚࡮ࡪࡥࡰࠩ᭘")]
l1llll111ll11l111_tv_=Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡨࡰࡪࡽࡩࡻ࡬ࡤ࠱ࡱ࡯ࡶࡦ࠰ࡦࡳࡲ࠵ࠧ᭙")
l1lll1l1lll11l111_tv_ = Variable4 (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠼࠮࠲࠽ࠣࡶࡻࡀ࠲࠳࠰࠳࠭ࠥࡍࡥࡤ࡭ࡲ࠳࠷࠶࠱࠱࠲࠴࠴࠶ࠦࡆࡪࡴࡨࡪࡴࡾ࠯࠳࠴࠱࠴ࠬ᭚")
fix={
Variable4 (u"ࠪࡘࡻࡶ࠱ࠨ᭛"):Variable4 (u"࡙ࠫ࡜ࡐࠡ࠳ࠪ᭜"),
 Variable4 (u"࡚ࠬࡶࡱ࠴ࠪ᭝"):Variable4 (u"࠭ࡔࡗࡒࠣ࠶ࠬ᭞"),
 Variable4 (u"ࠧࡕࡸࡳ࡬ࡩ࠭᭟"):Variable4 (u"ࠨࡖ࡙ࡔࠥࡎࡄࠨ᭠"),
 Variable4 (u"ࠩࡗࡺࡳ࠭᭡"):Variable4 (u"ࠪࡘ࡛ࡔࠧ᭢"),
 Variable4 (u"࡙ࠫࡼ࡮࠳࠶ࠪ᭣"):Variable4 (u"࡚ࠬࡖࡏ࠴࠷ࠫ᭤"),
 Variable4 (u"࠭ࡁࡹࡰࠪ᭥"):Variable4 (u"ࠧࡂ࡚ࡑࠫ᭦"),
 Variable4 (u"ࠨࡊࡥࡳ࠷࠭᭧"):Variable4 (u"ࠩࡋࡆࡔ࠸ࠧ᭨"),
 Variable4 (u"ࠪࡔࡦࡸࡡࠨ᭩"):Variable4 (u"ࠫࡕࡧࡲࡢࠩ᭪"),
 Variable4 (u"ࠬࡌࡩ࡭࡯ࡥࡳࡽ࠭᭫"):Variable4 (u"࠭ࡆࡪ࡮ࡰࡦࡴࡾ᭬ࠧ"),
 Variable4 (u"ࠧࡄࡱࡰࡩࡩࡿࡣࡦࡰࡷࡩࡷ࠭᭭"):Variable4 (u"ࠨࡅࡲࡱࡪࡪࡹࠡࡅࡨࡲࡹ࡫ࡲࠨ᭮"),
 Variable4 (u"ࠩࡄࡲ࡮ࡳࡡ࡭ࡲ࡯ࡥࡳ࡫ࡴࠨ᭯"):Variable4 (u"ࠪࡅࡳ࡯࡭ࡢ࡮ࠣࡔࡱࡧ࡮ࡦࡶࠪ᭰"),
 Variable4 (u"ࠫࡈࡧ࡮ࡢ࡮ࡧ࡭ࡸࡩ࡯ࡷࡧࡵࡽࠬ᭱"):Variable4 (u"ࠬࡊࡩࡴࡥࡲࡺࡪࡸࡹࠡࡅࡤࡲࡦࡲࠧ᭲"),
 Variable4 (u"࠭ࡄࡪࡵࡦࡳࡻ࡫ࡲࡺࡶࡸࡶࡧࡵࠧ᭳"):Variable4 (u"ࠧࡅ࡫ࡶࡧࡴࡼࡥࡳࡻࠣࡸࡺࡸࡢࡰࠩ᭴"),
 Variable4 (u"ࠨࡊ࡬ࡷࡹࡵࡲࡺࠩ᭵"):Variable4 (u"ࠩࡋ࡭ࡸࡺ࡯ࡳࡻࠪ᭶"),
 Variable4 (u"ࠪࡌ࠷࠭᭷"):Variable4 (u"ࠫࡍ࠸ࠧ᭸"),
 Variable4 (u"ࠬࡔࡡࡵࡩࡨࡳࡼ࡯࡬ࡥࠩ᭹"):Variable4 (u"࠭ࡎࡢࡶࡪࡩࡴࡽࡩ࡭ࡦࠪ᭺"),
 Variable4 (u"ࠧࡕࡸࡱࡷࡹࡿ࡬ࡦࠩ᭻"):Variable4 (u"ࠨࡖࡹࡲ࡙ࠥࡴࡺ࡮ࡨࠫ᭼"),
 Variable4 (u"ࠩࡗࡰࡨ࠭᭽"):Variable4 (u"ࠪࡘࡑࡉࠧ᭾"),
 Variable4 (u"ࠫࡊࡻࡲࡰࡵࡳࡳࡷࡺࠧ᭿"):Variable4 (u"ࠬࡋࡵࡳࡱࡶࡴࡴࡸࡴࠨᮀ"),
 Variable4 (u"࠭ࡅ࡭ࡧࡹࡩࡳࡹࡰࡰࡴࡷࡷࠬᮁ"):Variable4 (u"ࠧࡆ࡮ࡨࡺࡪࡴࠠࡴࡲࡲࡶࡹࡹࠧᮂ"),
 Variable4 (u"ࠨࡒࡲࡰࡸࡧࡴࡴࡲࡲࡶࡹ࠭ᮃ"):Variable4 (u"ࠩࡓࡳࡱࡹࡡࡵࠢࡶࡴࡴࡸࡴࠨᮄ")}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠪࡸࡻ࡯ࡤࠨᮅ")),Variable4 (u"ࠫࠬᮆ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫᮇ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[Variable4 (u"࠭ࡴࡷ࡫ࡧࠫᮈ")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᮉ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=20)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠨࠩᮊ")
    return l11ll11ll11l111_tv_
def l1l1lll111l11l111_tv_(l11ll1lllll11l111_tv_, l1ll111l1ll11l111_tv_, index):
    out = l11lll11l1l11l111_tv_(url=l11ll1lllll11l111_tv_)
    l1ll111l1ll11l111_tv_[index]=out
def l11l11l1l11l111_tv_(addheader=False):
    out=[]
    l11lll1ll1l11l111_tv_ =[Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥ࠲ࡲࡩࡷࡧ࠱ࡧࡴࡳ࠯ࡰࡩࡲࡰࡳ࡫࠮ࡩࡶࡰࡰࠬᮋ"),
            Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡪࡲࡥࡸ࡫ࡽ࡮ࡦ࠳࡬ࡪࡸࡨ࠲ࡨࡵ࡭࠰࡫ࡱࡪࡴࡸ࡭ࡢࡥࡼ࡮ࡳ࡫࠮ࡩࡶࡰࡰࠬᮌ"),
            Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠭࡭࡫ࡹࡩ࠳ࡩ࡯࡮࠱ࡩ࡭ࡱࡳ࡯ࡸࡧ࠱࡬ࡹࡳ࡬ࠨᮍ"),
            Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡥ࡭ࡧࡺ࡭ࡿࡰࡡ࠮࡮࡬ࡺࡪ࠴ࡣࡰ࡯࠲ࡲࡦࡻ࡫ࡰࡹࡨ࠲࡭ࡺ࡭࡭ࠩᮎ"),
            Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴࡦ࡮ࡨࡻ࡮ࢀࡪࡢ࠯࡯࡭ࡻ࡫࠮ࡤࡱࡰ࠳ࡸࡶ࡯ࡳࡶࡲࡻࡪ࠴ࡨࡵ࡯࡯ࠫᮏ"),
            Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠰ࡰ࡮ࡼࡥ࠯ࡥࡲࡱ࠴ࡳࡵࡻࡻࡦࡾࡳ࡫࠮ࡩࡶࡰࡰࠬᮐ"),
            Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡨࡰࡪࡽࡩࡻ࡬ࡤ࠱ࡱ࡯ࡶࡦ࠰ࡦࡳࡲ࠵ࡢࡢ࡬࡮ࡳࡼ࡫࠮ࡩࡶࡰࡰࠬᮑ")]
    l1l111lllll11l111_tv_ = []
    l1ll111l1ll11l111_tv_ = [[] for x in l11lll1ll1l11l111_tv_]
    for i,l11ll1lllll11l111_tv_ in enumerate(l11lll1ll1l11l111_tv_):
        thread = threading.Thread(name=Variable4 (u"ࠩࡗ࡬ࡷ࡫ࡡࡥࠧࡧࠫᮒ")%i, target = l1l1lll111l11l111_tv_, args=[l11ll1lllll11l111_tv_,l1ll111l1ll11l111_tv_,i])
        l1l111lllll11l111_tv_.append(thread)
        thread.start()
    while any([i.isAlive() for i in l1l111lllll11l111_tv_]): time.sleep(0.1)
    del l1l111lllll11l111_tv_[:]
    for l1l1l1ll11l111_tv_ in l1ll111l1ll11l111_tv_:
        out.extend(l1l1l1ll11l111_tv_)
    if len(out)>0 and addheader:
        t=Variable4 (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡽࡪࡲ࡬ࡰࡹࡠ࡙ࡵࡪࡡࡵࡧࡧ࠾ࠥࠫࡳࠡࠪࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥ࠲ࡲࡩࡷࡧ࠱ࡧࡴࡳࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᮓ") %time.strftime(Variable4 (u"ࠦࠪࡪ࠯ࠦ࡯࠲ࠩ࡞ࡀࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠤᮔ"))
        out.insert(0,{Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫᮕ"):t,Variable4 (u"࠭ࡴࡷ࡫ࡧࠫᮖ"):Variable4 (u"ࠧࠨᮗ"),Variable4 (u"ࠨ࡫ࡰ࡫ࠬᮘ"):Variable4 (u"ࠩࠪᮙ"),Variable4 (u"ࠪࡹࡷࡲࠧᮚ"):Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠭࡭࡫ࡹࡩ࠳ࡩ࡯࡮࠱ࠪᮛ"),Variable4 (u"ࠬ࡭ࡲࡰࡷࡳࠫᮜ"):Variable4 (u"࠭ࠧᮝ"),Variable4 (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧᮞ"):Variable4 (u"ࠨࠩᮟ")})
    return out
def l11lll11l1l11l111_tv_(url=Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥ࠲ࡲࡩࡷࡧ࠱ࡧࡴࡳ࠯࡯ࡣࡸ࡯ࡴࡽࡥ࠯ࡪࡷࡱࡱ࠭ᮠ")):
    content = l111111l11l111_tv_(url)
    out=[]
    l11lll1l11l11l111_tv_ = re.compile(Variable4 (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡩ࡬ࡢࡵࡶࡁࠧࡲࡩ࡯࡭ࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࡛࡟࠾ࡠ࠮ࠬᮡ"),re.DOTALL).findall(content)
    group=url.split(Variable4 (u"ࠫ࠴࠭ᮢ"))[-1].split(Variable4 (u"ࠬ࠴ࠧᮣ"))[0]
    for href,title in l11lll1l11l11l111_tv_:
        t=title.split(Variable4 (u"࠭࠯ࠨᮤ"))[-1].split(Variable4 (u"ࠧ࠯ࠩᮥ"))[0].strip()
        h=urllib.unquote(l1llll111ll11l111_tv_+href)
        l1llll11lll11l111_tv_=urllib.unquote(l1llll111ll11l111_tv_+title)
        out.append(l1lll1l1l1l11l111_tv_({Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᮦ"):t,Variable4 (u"ࠩࡷࡺ࡮ࡪࠧᮧ"):t,Variable4 (u"ࠪ࡭ࡲ࡭ࠧᮨ"):l1llll11lll11l111_tv_,Variable4 (u"ࠫࡺࡸ࡬ࠨᮩ"):h,Variable4 (u"ࠬ࡭ࡲࡰࡷࡳ᮪ࠫ"):group,Variable4 (u"࠭ࡵࡳ࡮ࡨࡴ࡬᮫࠭"):Variable4 (u"ࠧࠨᮬ"),Variable4 (u"ࠨࡥࡲࡨࡪ࠭ᮭ"):group}))
    return out
def l111l1lll11l111_tv_(url=Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥ࠲ࡲࡩࡷࡧ࠱ࡧࡴࡳ࠯ࡧ࡫࡯ࡱ࡮ࡱ࠯࠹࠵࠲ࡸࡻࡶ࠱࠮ࡪࡧࠫᮮ")):
    l1lll1ll11l11l111_tv_=[]
    content = l111111l11l111_tv_(url)
    l1ll1l1111l11l111_tv_ = re.compile(Variable4 (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠬ࠳࠰࠿ࠪ࠾࠲࡭࡫ࡸࡡ࡮ࡧࡁࠫᮯ"),re.DOTALL).findall(content)
    if l1ll1l1111l11l111_tv_:
        l1ll1l11l1l11l111_tv_ = re.compile(Variable4 (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᮰")).findall(l1ll1l1111l11l111_tv_[0])
        if l1ll1l11l1l11l111_tv_:
            data = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
            l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠬࡻࡲ࡭ࠩ᮱"):l1ll11lll1l11l111_tv_}]
            print Variable4 (u"࠭ࠤࠥࠦࠧࠨࠩࠪࠤࠥࠦࠧࠨࠩࠪࠤࠥࠦࠧࠨࠩࠪࠤࠥࠩ᮲"),l1ll11lll1l11l111_tv_
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print Variable4 (u"ࠧ࡝ࡰࠪ᮳"),l1l1l1ll11l111_tv_.get(Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ᮴"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠩࡸࡶࡱ࠭᮵")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ᮶")))
        print l1lll1ll11l11l111_tv_
