# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import sys,re,os,json,time
from copy import deepcopy
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
def l1ll1l1l11l111_tv_(hour,l1lll111l11l11l111_tv_):
    try:
        from cron import CronManager,CronJob
        l1ll1llll1ll11l111_tv_ = CronManager()
        l1lll1111lll11l111_tv_ = l1ll1llll1ll11l111_tv_.getJobs()
        for job in l1lll1111lll11l111_tv_:
            print job.name
            if Variable4 (u"ࠫࡑ࡯ࡶࡦࡒࡲࡰ࡮ࡹࡨࡕࡘࠪᖂ") in job.name:
                l1ll1llll1ll11l111_tv_.deleteJob(job.id)
    except:
        xbmcgui.Dialog().ok(Variable4 (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟ࡓࡶࡴࡨ࡬ࡦ࡯࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠬᖃ"),Variable4 (u"࠭ࡗࡵࡻࡦࡾࡰࡧࠠ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡹࡥࡳࡸ࡬ࡧࡪ࠴ࡣࡳࡱࡱࡼࡧࡳࡣ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࡱ࡭ࡪࠦࡪࡦࡵࡷࠤࡿࡧࡩ࡯ࡵࡷࡥࡱࡵࡷࡢࡰࡤࠫᖄ"), Variable4 (u"ࠧࡇࡷࡱ࡯ࡨࡰࡡࠡࡣࡸࡸࡴࡳࡡࡵࡻࡦࡾࡳ࡫ࡪࠡࡣ࡮ࡸࡺࡧ࡬ࡪࡼࡤࡧ࡯࡯ࠠ࡯࡫ࡨࠤࡧटࡤࡻ࡫ࡨࠤࡩࢀࡩࡢॄࡤऋ࠳࠭ᖅ"))
        return False
    if l1lll111l11l11l111_tv_==Variable4 (u"ࠨࡶࡵࡹࡪ࠭ᖆ"):
        job = CronJob()
        job.name = Variable4 (u"ࠤࡏ࡭ࡻ࡫ࡐࡰ࡮࡬ࡷ࡭࡚ࡖࠣᖇ")
        job.command = Variable4 (u"ࠪࡖࡺࡴࡐ࡭ࡷࡪ࡭ࡳ࠮ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡍ࡫ࡹࡩࡕࡵ࡬ࡪࡵ࡫ࡘ࡛ࡅ࡭ࡰࡦࡨࡁࡆ࡛ࡔࡐ࡯࠶ࡹ࠮࠭ᖈ")
        job.expression = Variable4 (u"ࠦ࠵ࠦࠥࡴࠢ࠭ࠤ࠯ࠦࠪࠣᖉ")%(hour)
        job.show_notification = Variable4 (u"ࠧࡺࡲࡶࡧࠥᖊ")
        l1ll1llll1ll11l111_tv_.addJob(job)
        xbmcgui.Dialog().ok(Variable4 (u"࠭ࡣࡳࡱࡱࡼࡧࡳࡣࠨᖋ"),Variable4 (u"ࠧࡂࡷࡷࡳࡲࡧࡴࡺࡥࡽࡲࡦࠦࡡ࡬ࡶࡸࡥࡱ࡯ࡺࡢࡥ࡭࡭ࠥࡰࡥࡴࡶࠣ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࡃࡎࡘ࡞࡝ࡎࡂ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᖌ"),Variable4 (u"ࠨࡎ࡬ࡷࡹࡧࠠ࡮࠵ࡸࠤࡧटࡤࡻ࡫ࡨࠤࡴࡪज़ࡸ࡫ࡨঀࡦࡴࡡࠡࡥࡲࡨࡿ࡯ࡥ࡯ࡰ࡬ࡩࠥࡵࠠࡨࡱࡧࡾ࡮ࡴࡩࡦࠢࠨࡷ࠿࠶࠰ࠨᖍ")%hour)
    else:
        xbmcgui.Dialog().ok(Variable4 (u"ࠩࡦࡶࡴࡴࡸࡣ࡯ࡦࠫᖎ"),Variable4 (u"ࠪࡅࡺࡺ࡯࡮ࡣࡷࡽࡨࢀ࡮ࡢࠢࡤ࡯ࡹࡻࡡ࡭࡫ࡽࡥࡨࡰࡩࠡ࡬ࡨࡷࡹ࡛ࠦࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠ࡛࡞ेऄࡄ࡜ࡒࡒࡆࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᖏ"))
    return True
def l1ll1lll111l11l111_tv_(l1ll1lll11ll11l111_tv_=Variable4 (u"ࠫࡵࡼࡲ࠯࡫ࡳࡸࡻࡹࡩ࡮ࡲ࡯ࡩࠬᖐ"),l1lll1l11l111_tv_={Variable4 (u"ࠬࡳ࠳ࡶࡒࡤࡸ࡭࠭ᖑ"): Variable4 (u"࠭ࡤࡶࡲࡤࠫᖒ")}):
    xbmc.executeJSONRPC(Variable4 (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠨࡷࠧ࠲ࠠࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪᖓ")%l1ll1lll11ll11l111_tv_ )
    xbmc.sleep(500)
    l1ll1ll1l1ll11l111_tv_=1
    msg=Variable4 (u"ࠨࠩᖔ")
    try:
        l1ll1ll1l11l11l111_tv_ = xbmcaddon.Addon(l1ll1lll11ll11l111_tv_)
        l1ll1ll1l11l11l111_tv_.setSetting(Variable4 (u"ࠩࡰ࠷ࡺࡖࡡࡵࡪࠪᖕ"),str(l1lll1l11l111_tv_.get(Variable4 (u"ࠪࡱ࠸ࡻࡐࡢࡶ࡫ࠫᖖ"),Variable4 (u"ࠫࠬᖗ"))))
        msg=Variable4 (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡭ࡲࡦࡧࡱࡡࡔࡑ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡࡗࡵࡹࡨ࡮࡯࡮ࠢࡳࡳࡳࡵࡷ࡯࡫ࡨࠤࡐࡵࡤࡪࠢ࡭ࡩॠࡲࡩࠡ࡮࡬ࡷࡹࡧࠠ࡬ࡣࡱࡥेࣹࡷࠡࡒ࡙ࡖࠥࡹࡩचࠢࡱ࡭ࡪࠦࡵࡢ࡭ࡷࡹࡦࡲ࡮ࡪॄࡤࠫᖘ")
    except:
        msg=Variable4 (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠࡉࡗࡘࡏࡓ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࡒ࡮࡫ࡵࡥࡣࡱࡥࠥࡧ࡫ࡵࡷࡤࡰ࡮ࢀࡡࡤ࡬ࡤࠤࡺࡹࡴࡢࡹ࡬ࡩॉࠦࡐࡗࡔࠪᖙ")
    l1ll1ll1l11l11l111_tv_ = xbmcaddon.Addon(l1ll1lll11ll11l111_tv_)
    l1ll1ll1ll1l11l111_tv_ = xbmc.translatePath(l1ll1ll1l11l11l111_tv_.getAddonInfo(Variable4 (u"ࠧࡱࡴࡲࡪ࡮ࡲࡥࠨᖚ"))).decode(Variable4 (u"ࠨࡷࡷࡪ࠲࠾ࠧᖛ"))
    l111l11111l11l111_tv_=Variable4 (u"ࠩࠪࠫࠒࠐ࠼ࡴࡧࡷࡸ࡮ࡴࡧࡴࡀࠐࠎࠥࠦࠠࠡ࠾ࡶࡩࡹࡺࡩ࡯ࡩࠣ࡭ࡩࡃࠢࡦࡲࡪࡇࡦࡩࡨࡦࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡸࡷࡻࡥࠣࠢ࠲ࡂࠒࠐࠠࠡࠢࠣࡀࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯ࡤ࠾ࠤࡨࡴ࡬ࡖࡡࡵࡪࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࠧࠦ࠯࠿ࠏࠍࠤࠥࠦࠠ࠽ࡵࡨࡸࡹ࡯࡮ࡨࠢ࡬ࡨࡂࠨࡥࡱࡩࡓࡥࡹ࡮ࡔࡺࡲࡨࠦࠥࡼࡡ࡭ࡷࡨࡁࠧࢁࡥࡱࡩࡓࡥࡹ࡮ࡔࡺࡲࡨࢁࠧࠦ࠯࠿ࠏࠍࠤࠥࠦࠠ࠽ࡵࡨࡸࡹ࡯࡮ࡨࠢ࡬ࡨࡂࠨࡥࡱࡩࡗࡗࡔࡼࡥࡳࡴ࡬ࡨࡪࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࡵࡴࡸࡩࠧࠦ࠯࠿ࠏࠍࠤࠥࠦࠠ࠽ࡵࡨࡸࡹ࡯࡮ࡨࠢ࡬ࡨࡂࠨࡥࡱࡩࡗ࡭ࡲ࡫ࡓࡩ࡫ࡩࡸࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࡻࡦࡲࡪࡘ࡮ࡳࡥࡔࡪ࡬ࡪࡹࢃࠢࠡ࠱ࡁࠑࠏࠦࠠࠡࠢ࠿ࡷࡪࡺࡴࡪࡰࡪࠤ࡮ࡪ࠽ࠣࡧࡳ࡫࡚ࡸ࡬ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࡾࡩࡵ࡭ࡕࡳ࡮ࢀࠦࠥ࠵࠾ࠎࠌࠣࠤࠥࠦ࠼ࡴࡧࡷࡸ࡮ࡴࡧࠡ࡫ࡧࡁࠧࡲ࡯ࡨࡱࡅࡥࡸ࡫ࡕࡳ࡮ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࠧࠦ࠯࠿ࠏࠍࠤࠥࠦࠠ࠽ࡵࡨࡸࡹ࡯࡮ࡨࠢ࡬ࡨࡂࠨ࡬ࡰࡩࡲࡊࡷࡵ࡭ࡆࡲࡪࠦࠥࡼࡡ࡭ࡷࡨࡁࠧࢁ࡬ࡰࡩࡲࡊࡷࡵ࡭ࡆࡲࡪࢁࠧࠦ࠯࠿ࠏࠍࠤࠥࠦࠠ࠽ࡵࡨࡸࡹ࡯࡮ࡨࠢ࡬ࡨࡂࠨ࡬ࡰࡩࡲࡔࡦࡺࡨࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠥࠤ࠴ࡄࠍࠋࠢࠣࠤࠥࡂࡳࡦࡶࡷ࡭ࡳ࡭ࠠࡪࡦࡀࠦࡱࡵࡧࡰࡒࡤࡸ࡭࡚ࡹࡱࡧࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠶ࠨࠠ࠰ࡀࠐࠎࠥࠦࠠࠡ࠾ࡶࡩࡹࡺࡩ࡯ࡩࠣ࡭ࡩࡃࠢ࡮࠵ࡸࡇࡦࡩࡨࡦࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡸࡷࡻࡥࠣࠢ࠲ࡂࠒࠐࠠࠡࠢࠣࡀࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯ࡤ࠾ࠤࡰ࠷ࡺࡖࡡࡵࡪࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࢀࡳ࠳ࡶࡒࡤࡸ࡭ࢃࠢࠡ࠱ࡁࠑࠏࠦࠠࠡࠢ࠿ࡷࡪࡺࡴࡪࡰࡪࠤ࡮ࡪ࠽ࠣ࡯࠶ࡹࡕࡧࡴࡩࡖࡼࡴࡪࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࡼ࡯࠶ࡹࡕࡧࡴࡩࡖࡼࡴࡪࢃࠢࠡ࠱ࡁࠑࠏࠦࠠࠡࠢ࠿ࡷࡪࡺࡴࡪࡰࡪࠤ࡮ࡪ࠽ࠣ࡯࠶ࡹ࡚ࡸ࡬ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠥࠤ࠴ࡄࠍࠋࠢࠣࠤࠥࡂࡳࡦࡶࡷ࡭ࡳ࡭ࠠࡪࡦࡀࠦࡸ࡫ࡰ࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠦࠥ࠵࠾ࠎࠌࠣࠤࠥࠦ࠼ࡴࡧࡷࡸ࡮ࡴࡧࠡ࡫ࡧࡁࠧࡹࡥࡱ࠴ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࠧࠦ࠯࠿ࠏࠍࠤࠥࠦࠠ࠽ࡵࡨࡸࡹ࡯࡮ࡨࠢ࡬ࡨࡂࠨࡳࡦࡲ࠶ࠦࠥࡼࡡ࡭ࡷࡨࡁࠧࠨࠠ࠰ࡀࠐࠎࠥࠦࠠࠡ࠾ࡶࡩࡹࡺࡩ࡯ࡩࠣ࡭ࡩࡃࠢࡴࡶࡤࡶࡹࡔࡵ࡮ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥ࠵ࠧࠦ࠯࠿ࠏࠍࡀ࠴ࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠾ࠨࠩࠪᖜ")
    l111l11111l11l111_tv_ = l111l11111l11l111_tv_.format(**l1lll1l11l111_tv_)
    print(Variable4 (u"ࠪࡥࡩࡪ࡯࡯ࡡࡨࡲࡦࡨ࡬ࡦࡡࡤࡲࡩࡥࡳࡦࡶࠪᖝ"),Variable4 (u"ࠫࡵࡸ࡯ࡧ࡫࡯ࡩࡕࡧࡴࡩࠩᖞ"))
    print l1ll1ll1ll1l11l111_tv_
    print l1lll1l11l111_tv_
    print l111l11111l11l111_tv_
    try:
        if not os.path.exists(l1ll1ll1ll1l11l111_tv_):
            os.makedirs(l1ll1ll1ll1l11l111_tv_)
    except:
        pass
    with open(os.path.join(l1ll1ll1ll1l11l111_tv_,Variable4 (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫᖟ")),Variable4 (u"࠭ࡷࠨᖠ")) as l1l111ll1ll11l111_tv_:
        print(Variable4 (u"ࠧࡢࡦࡧࡳࡳࡥࡥ࡯ࡣࡥࡰࡪࡥࡡ࡯ࡦࡢࡷࡪࡺࠧᖡ"),Variable4 (u"ࠨࡹࡵ࡭ࡹ࡯࡮ࡨࠢࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨᖢ"))
        l1l111ll1ll11l111_tv_.write(l111l11111l11l111_tv_)
    return msg
def l1ll1lll11l111_tv_(fname,path,l1l1l1l1l11l111_tv_,l111111ll11l111_tv_):
    l1ll1llll11l11l111_tv_ = os.path.join(path,fname)
    if os.path.exists(l1ll1llll11l11l111_tv_):
        xbmc.executebuiltin(Variable4 (u"ࠩࡖࡸࡴࡶࡐࡗࡔࡐࡥࡳࡧࡧࡦࡴࠪᖣ"))
        xbmc.executebuiltin(Variable4 (u"ࠪࡔ࡛ࡘ࠮ࡔࡶࡲࡴࡒࡧ࡮ࡢࡩࡨࡶࠬᖤ"))
        l1lll1111l1l11l111_tv_={Variable4 (u"ࠫࡲ࠹ࡵࡑࡣࡷ࡬ࠬᖥ"): l1ll1llll11l11l111_tv_,Variable4 (u"ࠬࡳ࠳ࡶࡒࡤࡸ࡭࡚ࡹࡱࡧࠪᖦ"):Variable4 (u"࠭࠰ࠨᖧ"),Variable4 (u"ࠧࡦࡲࡪ࡙ࡷࡲࠧᖨ"):l111111ll11l111_tv_,Variable4 (u"ࠨࡧࡳ࡫࡙࡯࡭ࡦࡕ࡫࡭࡫ࡺࠧᖩ"):l1l1l1l1l11l111_tv_,Variable4 (u"ࠩࡨࡴ࡬ࡖࡡࡵࡪࡗࡽࡵ࡫ࠧᖪ"):Variable4 (u"ࠪ࠵ࠬᖫ"),Variable4 (u"ࠫࡱࡵࡧࡰࡈࡵࡳࡲࡋࡰࡨࠩᖬ"):Variable4 (u"ࠬ࠸ࠧᖭ")}
        msg=l1ll1lll111l11l111_tv_(l1ll1lll11ll11l111_tv_=Variable4 (u"࠭ࡰࡷࡴ࠱࡭ࡵࡺࡶࡴ࡫ࡰࡴࡱ࡫ࠧᖮ"),l1lll1l11l111_tv_=l1lll1111l1l11l111_tv_)
        xbmcgui.Dialog().notification(Variable4 (u"ࠧࠨᖯ"), msg, xbmcgui.NOTIFICATION_INFO, 1000)
        version = int(xbmc.getInfoLabel(Variable4 (u"ࠣࡕࡼࡷࡹ࡫࡭࠯ࡄࡸ࡭ࡱࡪࡖࡦࡴࡶ࡭ࡴࡴࠢᖰ") )[0:2])
        print Variable4 (u"ࠩࡎࡳࡩ࡯ࠠࡷࡧࡵࡷ࡮ࡵ࡮࠻ࠢࠨࡨ࠱ࠦࡣࡩࡧࡦ࡯࡮ࡴࡧࠡ࡫ࡩࠤࡕ࡜ࡒࠡ࡫ࡶࠤࡦࡩࡴࡪࡸࡨࠫᖱ") % version
        if version<17:
            try:
                l1lll111l1ll11l111_tv_ = xbmc.executeJSONRPC(Variable4 (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢࡱࡸࡵࡱࡦࡴࡡࡨࡧࡵ࠲ࡪࡴࡡࡣ࡮ࡨࡨࠧࢃࠬࠣ࡫ࡧࠦ࠿࠿ࡽࠨᖲ"))
                l1ll1lllllll11l111_tv_ = json.loads(l1lll111l1ll11l111_tv_)
                l1ll1ll11lll11l111_tv_ = l1ll1lllllll11l111_tv_.get(Variable4 (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫᖳ"),{}).get(Variable4 (u"ࠬࡼࡡ࡭ࡷࡨࠫᖴ"),Variable4 (u"࠭ࠧᖵ"))
                if not l1ll1ll11lll11l111_tv_:
                    xbmcgui.Dialog().ok(Variable4 (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡ࡙࡫࡬ࡦࡹ࡬ࡾ࡯ࡧࠠ࡯࡫ࡨࠤ࡯࡫ࡳࡵࠢࡤ࡯ࡹࡿࡷ࡯ࡣࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠥ࠭ᖶ"),Variable4 (u"ࠨࡖࡨࡰࡪࡽࡩࡻ࡬ࡤࠤࡕ࡜ࡒࠡࡰ࡬ࡩࠥࡰࡥࡴࡶࠣࡥࡰࡺࡹࡸࡣࡲࡻࡦࡴࡡࠨᖷ"), Variable4 (u"ࠩࡄ࡯ࡹࡿࡷࡶ࡬ࠣ࡭ࠥࡻࡲࡶࡥ࡫ࡳࡲࠦࡰࡰࡰࡲࡻࡳ࡯ࡥࠡ࡬ࡤ࡯࡚ࠥࡥ࡭ࡧࡺ࡭ࡿࡰࡡࠡࡵ࡬झࠥࡴࡩࡦࠢࡳࡳ࡯ࡧࡷࡪࠩᖸ"))
                    xbmc.executebuiltin(Variable4 (u"ࠪࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬ࠶࠶࠰࠳࠳ࠬࠫᖹ"))
            except:
                pass
        else:
            pass
    else:
        xbmcgui.Dialog().notification(Variable4 (u"ࠫࡊࡘࡒࡐࡔࠪᖺ"), Variable4 (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡝ࡏ࡭ࡸࡺࡡࠡ࡯࠶ࡹࠥࡰࡥࡴࡼࡦࡾࡪࠦ࡮ࡪࡧࠣ࡭ࡸࡺ࡮ࡪࡧ࡭ࡩࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᖻ"), xbmcgui.NOTIFICATION_ERROR, 3000)
def l11l1l1ll11l111_tv_(fname,path,l1l11l1ll11l111_tv_,l1l111ll11l11l111_tv_=None):
    l1lll111111l11l111_tv_ = os.path.join(path,fname)
    l1lll11111ll11l111_tv_ = xbmcgui.DialogProgressBG()
    l1lll11111ll11l111_tv_.create(Variable4 (u"࠭ࡔࡸࡱࡵࡾञࠦ࡬ࡪࡵࡷझࠥࡶࡲࡰࡩࡵࡥࡲࣹࡷࠡࡖ࡙ࠤࡠࠫࡳ࡞ࠩᖼ")%(fname), Variable4 (u"ࠧࡖॾࡼࡻࡦࡰࠠࡻࠢ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࡑࡘࡕࠤࡎࡖࡔࡗࠢࡖ࡭ࡲࡶ࡬ࡦࠢࡆࡰ࡮࡫࡮ࡵ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᖽ"))
    l1lll11111ll11l111_tv_.update(0,message=Variable4 (u"ࠨࡕࡽࡹࡰࡧ࡭ࠡ࡭ࡤࡲࡦैࣳࡸࠢ࠱࠲࠳࠭ᖾ"))
    if l1l111ll11l11l111_tv_:
        mod = l1l111ll11l11l111_tv_(l1l11l1ll11l111_tv_)
    else:
        mod = __import__(l1l11l1ll11l111_tv_)
    l1ll1lllll1l11l111_tv_ = mod.l11l11l1l11l111_tv_(addheader=True)
    N=len(l1ll1lllll1l11l111_tv_)
    l11l1ll1l11l111_tv_=[]
    l1lll11111ll11l111_tv_.update(0,message= Variable4 (u"ࠩ࡝ࡲࡦࡲࡡࡻॄࡨࡱࠥࠫࡤࠨᖿ") % N  )
    l1l111lllll11l111_tv_ = []
    l1ll111l1ll11l111_tv_ = [[] for x in range(N)]
    def l1l1lll111l11l111_tv_(l1l1l1ll11l111_tv_, l1ll111l1ll11l111_tv_, index,N):
        l1ll1l11l11l111_tv_ = mod.l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠪࡹࡷࡲࠧᗀ"),Variable4 (u"ࠫࠬᗁ")))
        l1ll111l1ll11l111_tv_[index]=l1ll1l11l11l111_tv_
        l1ll1lll1lll11l111_tv_ = sum([1 for x in l1ll111l1ll11l111_tv_ if x ])
        message = Variable4 (u"ࠬࠫࡤ࠰ࠧࡧࠤࠪࡹࠧᗂ")%(l1ll1lll1lll11l111_tv_,N-1,l1l1l1ll11l111_tv_.get(Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬᗃ"),Variable4 (u"ࠧࠨᗄ")))
        l1ll1ll1llll11l111_tv_ = int(l1ll1lll1lll11l111_tv_*100.0/N)
        l1lll11111ll11l111_tv_.update(l1ll1ll1llll11l111_tv_, message=message)
    try:
        xbmc.log(Variable4 (u"ࠨࡔࡸࡲࡳ࡯࡮ࡨ࡚ࠢࡳࡷࡱࡥࡳࠢࡗ࡬ࡷ࡫ࡡࡥࡵࠣࡔࡴࡵ࡬ࠨᗅ"))
        import l1ll11l11ll11l111_tv_
        pool = l1ll11l11ll11l111_tv_.ThreadPool(10)
        for i,l1l1l1ll11l111_tv_ in enumerate(l1ll1lllll1l11l111_tv_):
            time.sleep(0.1)
            pool.l1ll11l1lll11l111_tv_(l1l1lll111l11l111_tv_, *(l1l1l1ll11l111_tv_,l1ll111l1ll11l111_tv_,i,N-1))
        pool.l1ll11111ll11l111_tv_()
        xbmc.log(Variable4 (u"ࠩࡕࡹࡳࡴࡩ࡯ࡩ࡛ࠣࡴࡸ࡫ࡦࡴࠣࡘ࡭ࡸࡥࡢࡦࡶࠤࡕࡵ࡯࡭࠼ࠣࡈࡔࡔࡅࠨᗆ"))
        for l1l1l1ll11l111_tv_,l1ll1l11l11l111_tv_ in zip(l1ll1lllll1l11l111_tv_,l1ll111l1ll11l111_tv_):
            for stream in l1ll1l11l11l111_tv_:
                l11ll11ll11l111_tv_ = stream.get(Variable4 (u"ࠪࡹࡷࡲࠧᗇ"),Variable4 (u"ࠫࠬᗈ"))
                if l11ll11ll11l111_tv_:
                    l1l1l1ll11l111_tv_[Variable4 (u"ࠬࡻࡲ࡭ࠩᗉ")]=l11ll11ll11l111_tv_
                    l11l1ll1l11l111_tv_.append(deepcopy(l1l1l1ll11l111_tv_))
    except:
        xbmc.log(Variable4 (u"࠭ࡒࡶࡰࡱ࡭ࡳ࡭ࠠࡕࡪࡵࡩࡦࡪࡳࠨᗊ"))
        for i,l1l1l1ll11l111_tv_ in enumerate(l1ll1lllll1l11l111_tv_):
            l1ll1ll1llll11l111_tv_ = int((i)*100.0/N)
            message = Variable4 (u"ࠧࠦࡦ࠲ࠩࡩࠦࠥࡴࠩᗋ")%(i,N-1,l1l1l1ll11l111_tv_.get(Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᗌ"),Variable4 (u"ࠩࠪᗍ")))
            l1lll11111ll11l111_tv_.update(l1ll1ll1llll11l111_tv_, message=message)
            l1ll1l11l11l111_tv_ = mod.l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠪࡹࡷࡲࠧᗎ"),Variable4 (u"ࠫࠬᗏ")))
            for stream in l1ll1l11l11l111_tv_:
                l11ll11ll11l111_tv_ = stream.get(Variable4 (u"ࠬࡻࡲ࡭ࠩᗐ"),Variable4 (u"࠭ࠧᗑ"))
                msg = stream.get(Variable4 (u"ࠧ࡮ࡵࡪࠫᗒ"),Variable4 (u"ࠨࠩᗓ"))
                if l11ll11ll11l111_tv_:
                    l1l1l1ll11l111_tv_[Variable4 (u"ࠩࡸࡶࡱ࠭ᗔ")]=l11ll11ll11l111_tv_
                    l11l1ll1l11l111_tv_.append(deepcopy(l1l1l1ll11l111_tv_))
                elif msg: l1lll11111ll11l111_tv_.update(l1ll1ll1llll11l111_tv_, message=stream.get(Variable4 (u"ࠪࡱࡸ࡭ࠧᗕ")))
    l1lll11111ll11l111_tv_.close()
    if l11l1ll1l11l111_tv_:
        if len(l1ll1lllll1l11l111_tv_)>0:
            l11l1ll1l11l111_tv_.insert(0,l1ll1lllll1l11l111_tv_[0])
        if l1ll1lll1l1l11l111_tv_(l11l1ll1l11l111_tv_,l1lll111111l11l111_tv_):
            xbmcgui.Dialog().notification(Variable4 (u"ࠫࡑ࡯ࡳࡵࡣࠣࡾࡦࡶࡩࡴࡣࡱࡥࠬᗖ"), l1lll111111l11l111_tv_, xbmcgui.NOTIFICATION_INFO, 10000)
        else:
            xbmcgui.Dialog().notification(Variable4 (u"ࠬࡖࡲࡰࡤ࡯ࡩࡲࠦࡺࠡࡼࡤࡴ࡮ࡹࡥ࡮ࠢࡧࡳࠥࡶࡩ࡭࡭ࡸࠫᗗ"), l1lll111111l11l111_tv_, xbmcgui.NOTIFICATION_ERROR, 10000)
    return l11l1ll1l11l111_tv_
def l1ll1lll1l1l11l111_tv_(out,fname=Variable4 (u"࠭ࡴࡦ࡮ࡨࡻ࡮ࢀࡪࡢࡦࡤࡸࡻ࠴࡭࠴ࡷࠪᗘ")):
    try:
        l1lllllllll11l111_tv_=Variable4 (u"ࠧࡊ࠲࡙࡝࡛ࡋ࡬ࡐࡔࡪࡁࡂ࠭ᗙ").decode(Variable4 (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨᗚ")) +Variable4 (u"ࠩ࠽࠱࠶ࠦࡴࡷࡩ࠰࡭ࡩࡃࠢࡼࡶࡹ࡭ࡩࢃࠢࠡࡩࡵࡳࡺࡶ࠭ࡵ࡫ࡷࡰࡪࡃࠢࡑࡱࡳࡹࡱࡧࡲ࡯ࡻࠥࠤࡹࡼࡧ࠮࡮ࡲ࡫ࡴࡃࠢࡼ࡫ࡰ࡫ࢂࠨࠠࡶࡴ࡯࠱ࡪࡶࡧ࠾ࠤࡾࡹࡷࡲࡥࡱࡩࢀࠦࠥ࡭ࡲࡰࡷࡳ࠱ࡹ࡯ࡴ࡭ࡧࡀࠦࢀ࡭ࡲࡰࡷࡳࢁࠧ࠲ࡻࡵ࡫ࡷࡰࡪࢃ࡜࡯ࡽࡸࡶࡱࢃ࡜࡯࡞ࡱࠫᗛ")
        l1l11ll1l1l11l111_tv_=Variable4 (u"ࠪࡍ࠵࡜࡙ࡗࡇ࠳ࡾ࡛ࡗ࡯࠾ࠩᗜ").decode(Variable4 (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫᗝ"))
        for l1l1l1ll11l111_tv_ in out:
            l1l11ll1l1l11l111_tv_=l1l11ll1l1l11l111_tv_+l1lllllllll11l111_tv_.format(**l1l1l1ll11l111_tv_)
        with  open(fname,Variable4 (u"ࠬࡽࠧᗞ")) as l1l111ll1ll11l111_tv_:
            l1l111ll1ll11l111_tv_.write(l1l11ll1l1l11l111_tv_)
        ret=True
    except:
        ret=False
    return ret
