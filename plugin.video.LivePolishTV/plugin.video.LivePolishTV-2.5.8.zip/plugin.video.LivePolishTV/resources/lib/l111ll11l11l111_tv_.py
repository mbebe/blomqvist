# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
import cookielib
import urlparse
import l1ll11ll1ll11l111_tv_
import l1ll1ll111l11l111_tv_
import time
l1llll111ll11l111_tv_=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡺࡰࡤࡤࡧࡿࡺࡶ࠯࡫ࡱࡪࡴ࠵ࠧ⁑")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭⁒")
local={Variable4 (u"ࠣࡆ࡬ࡷࡨࡵࡶࡦࡴࡼࠤ࡙ࡻࡲࡣࡱࠣ࡜ࡹࡸࡡࠣ⁓") 						:Variable4 (u"ࠤࡇ࡭ࡸࡩ࡯ࡷࡧࡵࡽࠥࡾࡴࡳࡣࠥ⁔"),}
def l111111l11l111_tv_(url,data=None,header={}):
    l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
    urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ⁕"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except: l11ll11ll11l111_tv_=Variable4 (u"ࠫࠬ⁖")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    names=[]
    l11llll11ll11l111_tv_ = re.compile(Variable4 (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠮ࡃ࠮ࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠨ⁗")).findall(content)
    for href,t in l11llll11ll11l111_tv_:
        if t not in names:
            out.append({Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬ⁘"):t,Variable4 (u"ࠧࡵࡸ࡬ࡨࠬ⁙"):t,Variable4 (u"ࠨ࡫ࡰ࡫ࠬ⁚"):Variable4 (u"ࠩࠪ⁛"),Variable4 (u"ࠪࡹࡷࡲࠧ⁜"):href,Variable4 (u"ࠫ࡬ࡸ࡯ࡶࡲࠪ⁝"):Variable4 (u"ࠬ࠭⁞"),Variable4 (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭ "):Variable4 (u"ࠧࠨ⁠"),Variable4 (u"ࠨࡲ࡯ࡳࡹ࠭⁡"):Variable4 (u"ࠩࠪ⁢"),Variable4 (u"ࠪࡧࡴࡪࡥࠨ⁣"):Variable4 (u"ࠫࠬ⁤")})
            names.append(t)
    if addheader and len(out):
        t=Variable4 (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡿࡥ࡭࡮ࡲࡻࡢ࡛ࡰࡥࡣࡷࡩࡩࡀࠠࠦࡵࠣࠬࡿࡵࡢࡢࡥࡽࡸࡻ࠯࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⁥") %time.strftime(Variable4 (u"ࠨࠥࡥ࠱ࠨࡱ࠴࡙ࠫ࠻ࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦ⁦"))
        out.insert(0,{Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭⁧"):t,Variable4 (u"ࠨࡶࡹ࡭ࡩ࠭⁨"):Variable4 (u"ࠩࠪ⁩"),Variable4 (u"ࠪ࡭ࡲ࡭ࠧ⁪"):Variable4 (u"ࠫࠬ⁫"),Variable4 (u"ࠬࡻࡲ࡭ࠩ⁬"):l1llll111ll11l111_tv_,Variable4 (u"࠭ࡧࡳࡱࡸࡴࠬ⁭"):Variable4 (u"ࠧࠨ⁮"),Variable4 (u"ࠨࡷࡵࡰࡪࡶࡧࠨ⁯"):Variable4 (u"ࠩࠪ⁰")})
    return l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local)
def l1l1111lllll11l111_tv_():
    out= l11l11l1l11l111_tv_()
    l1l1111ll1ll11l111_tv_= l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local)
    for l1l1l1ll11l111_tv_,l1l1111lll1l11l111_tv_ in zip(out,l1l1111ll1ll11l111_tv_):
        print Variable4 (u"ࠪࠩࡸࠦࠠࠡࠧࡶࠫⁱ")%(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ⁲")),l1l1111lll1l11l111_tv_.get(Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫ⁳")))
def l111l1lll11l111_tv_(url=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡺࡰࡤࡤࡧࡿࡺࡶ࠯࡫ࡱࡪࡴ࠵ࡲࡦࡲࡸࡦࡱ࡯࡫ࡢ࠱ࠪ⁴")):
    l1lll1ll11l11l111_tv_=[]
    content = l111111l11l111_tv_(url)
    src = re.compile(Variable4 (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯ࡦࡳࡣࡰࡩࠬ⁵"),re.DOTALL|re.I).findall(content)
    if src:
        data = l111111l11l111_tv_(src[0])
        l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src[0],data)
        if l1ll11lll1l11l111_tv_:
            l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠨࡷࡵࡰࠬ⁶"):l1ll11lll1l11l111_tv_,Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨ⁷"):Variable4 (u"ࠪࡐ࡮ࡼࡥࠡࠩ⁸")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,Variable4 (u"ࠫࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭⁹"):1})
        else:
            l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠬࡳࡳࡨࠩ⁺"):Variable4 (u"࠭ࡐࡳࡱࡥࡰࡪࡳࠠࡻࠢࡺࡽࡸࢀࡵ࡬ࡣࡱ࡭ࡪࡳࠠॻࡴࣶࡨेࡧࠧ⁻")}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print Variable4 (u"ࠧ࡝ࡰࠪ⁼"),l1l1l1ll11l111_tv_.get(Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ⁽"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠩࡸࡶࡱ࠭⁾")))
        print l1lll1ll11l11l111_tv_
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠪࡹࡷࡲࠧⁿ")))
        print l1lll1ll11l11l111_tv_
