# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re,time
import l1ll11ll1ll11l111_tv_
import l1ll1ll111l11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡪࡡࡳ࡯ࡲࡻࡦ࠳ࡴࡷ࠰ࡳࡰࠬග")
l1lll1l1lll11l111_tv_=Variable4 (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬඝ")
__all__=[Variable4 (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬඞ"),Variable4 (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰ࡛࡯ࡤࡦࡱࠪඟ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ච"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠪࠫඡ")
    return l11ll11ll11l111_tv_
locals={
Variable4 (u"ࠦࡕࡵ࡬ࡴࡣࡷࠤ࠷ࠨජ") 									:Variable4 (u"ࠧ࠮ࡐࡰ࡮࡞ࡰࡢ࠰ࡳࡢࡶ࡞ࡠࡸ࠳࡝ࠫ࠴ࠫ࡟ࡡࡹ࠭࡞ࠬࡗ࡚࠮ࡅࠨ࡜࡞ࡶ࠱ࡢ࠰ࡈࡅࠫࡂ࠭ࠧඣ"),
Variable4 (u"ࠨࡐࡰ࡮ࡶࡥࡹࠦࡓࡱࡱࡵࡸࠧඤ") 								:Variable4 (u"ࠢࠩࡒࡲࡰࡠࡲ࡝ࠫࡵࡤࡸࡠࡢࡳ࠮࡟࠭ࡗࡵࡵࡲࡵࠪ࡞ࡠࡸ࠳࡝ࠫ࠳ࠬࡃ࠭ࡡ࡜ࡴ࠯ࡠ࠮࡙࡜ࠩࡀࠪ࡞ࡠࡸ࠳࡝ࠫࡊࡇ࠭ࡄ࠯ࠢඥ"),
}
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡦࡤࡶࡲࡵࡷࡢ࠯ࡷࡺ࠳ࡶ࡬ࠨඦ"))
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(Variable4 (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴ࡪࡡࡳ࡯ࡲࡻࡦ࠳ࡴࡷ࠰ࡳࡰ࠴࠴ࠫࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠬට")).findall(content)
    for href,title in l1lll1lllll11l111_tv_:
        out.append({Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩඨ"):title.strip(),Variable4 (u"ࠫࡹࡼࡩࡥࠩඩ"):title.strip(),Variable4 (u"ࠬ࡯࡭ࡨࠩඪ"):Variable4 (u"࠭ࠠࠨණ"),Variable4 (u"ࠧࡶࡴ࡯ࠫඬ"):href,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧත"):Variable4 (u"ࠩࠣࠫථ"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪද"):Variable4 (u"ࠫࠥ࠭ධ")})
    if addheader and len(out):
        t=Variable4 (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡿࡥ࡭࡮ࡲࡻࡢ࡛ࡰࡥࡣࡷࡩࡩࡀࠠࠦࡵࠣࠬࡩࡧࡲ࡮ࡱࡺࡥ࠲ࡺࡶ࠯ࡲ࡯࠭ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭න") %time.strftime(Variable4 (u"ࠨࠥࡥ࠱ࠨࡱ࠴࡙ࠫ࠻ࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦ඲"))
        out.insert(0,{Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ඳ"):t,Variable4 (u"ࠨࡶࡹ࡭ࡩ࠭ප"):Variable4 (u"ࠩࠪඵ"),Variable4 (u"ࠪ࡭ࡲ࡭ࠧබ"):Variable4 (u"ࠫࠬභ"),Variable4 (u"ࠬࡻࡲ࡭ࠩම"):l1llll111ll11l111_tv_,Variable4 (u"࠭ࡧࡳࡱࡸࡴࠬඹ"):Variable4 (u"ࠧࠨය"),Variable4 (u"ࠨࡷࡵࡰࡪࡶࡧࠨර"):Variable4 (u"ࠩࠪ඼")})
    return l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,locals)
def l111l1lll11l111_tv_(url=Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡨࡦࡸ࡭ࡰࡹࡤ࠱ࡹࡼ࠮ࡱ࡮࠲ࡴࡴࡲࡳࡢࡶ࠰࡬ࡩ࠵ࠧල")):
    l1lll1ll11l11l111_tv_=[]
    if Variable4 (u"ࠫࡰࡧ࡮ࡢ࡮ࡼࠫ඾") in url:
        data = l111111l11l111_tv_(url.replace(Variable4 (u"ࠬࠦࠧ඿"),Variable4 (u"࠭ࠥ࠳࠲ࠪව")))
        l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
        if l1ll11lll1l11l111_tv_:
            l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠧࡶࡴ࡯ࠫශ"):l1ll11lll1l11l111_tv_}]
    else:
        content = l111111l11l111_tv_(url)
        l1ll1l1111l11l111_tv_ = re.compile(Variable4 (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠪ࠱࠯ࡰࡧ࡮ࡢ࡮ࡼ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪෂ")).findall(content)
        if l1ll1l1111l11l111_tv_:
            src = re.compile(Variable4 (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧස"),re.IGNORECASE).findall(l1ll1l1111l11l111_tv_[0])
            if src:
                data = l111111l11l111_tv_(src[0].replace(Variable4 (u"ࠪࠤࠬහ"),Variable4 (u"ࠫࠪ࠸࠰ࠨළ")))
                l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src[0],data)
                if l1ll11lll1l11l111_tv_:
                    l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠬࡻࡲ࡭ࠩෆ"):l1ll11lll1l11l111_tv_}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print Variable4 (u"࠭࡜࡯ࠩ෇"),l1l1l1ll11l111_tv_.get(Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭෈"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠨࡷࡵࡰࠬ෉")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨ්")))
        print l1lll1ll11l11l111_tv_
