# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡸࡾࡶࡥࡳࡶࡹ࠲ࡨࡵ࡭࠯ࡲ࡯ࠫḨ")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ḩ")
__all__=[Variable4 (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭Ḫ"),Variable4 (u"ࠩࡪࡩࡹࡉࡨࡢࡰࡱࡩࡱ࡜ࡩࡥࡧࡲࠫḫ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧḬ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠫࠬḭ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(Variable4 (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃ࠭Ḯ")).findall(content)
    for href,title in l1lll1lllll11l111_tv_:
        out.append({Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬḯ"):title.strip(),Variable4 (u"ࠧࡵࡸ࡬ࡨࠬḰ"):title.strip(),Variable4 (u"ࠨ࡫ࡰ࡫ࠬḱ"):Variable4 (u"ࠩࠪḲ"),Variable4 (u"ࠪࡹࡷࡲࠧḳ"):href,Variable4 (u"ࠫ࡬ࡸ࡯ࡶࡲࠪḴ"):Variable4 (u"ࠬ࠭ḵ"),Variable4 (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭Ḷ"):Variable4 (u"ࠧࠨḷ")})
    if addheader and len(out):
        t=Variable4 (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࡗࡳࡨࡦࡺࡥࡥ࠼ࠣࠩࡸࠦࠨࡱࡵࡤ࠱ࡹࡼࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩḸ") %time.strftime(Variable4 (u"ࠤࠨࡨ࠴ࠫ࡭࠰ࠧ࡜࠾ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢḹ"))
        out.insert(0,{Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩḺ"):t,Variable4 (u"ࠫࡹࡼࡩࡥࠩḻ"):Variable4 (u"ࠬ࠭Ḽ"),Variable4 (u"࠭ࡩ࡮ࡩࠪḽ"):Variable4 (u"ࠧࠨḾ"),Variable4 (u"ࠨࡷࡵࡰࠬḿ"):l1llll111ll11l111_tv_,Variable4 (u"ࠩࡪࡶࡴࡻࡰࠨṀ"):Variable4 (u"ࠪࠫṁ"),Variable4 (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫṂ"):Variable4 (u"ࠬ࠭ṃ")})
    return out
url=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡸࡾࡶࡥࡳࡶࡹ࠲ࡨࡵ࡭࠯ࡲ࡯࠳ࡹࡼ࠭࠳ࠩṄ")
def l111l1lll11l111_tv_(url=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡹࡿࡰࡦࡴࡷࡺ࠳ࡩ࡯࡮࠰ࡳࡰ࠴ࡺࡶ࡯ࠩṅ")):
    l1lll1ll11l11l111_tv_=[]
    if Variable4 (u"ࠨࡶࡼࡴࡪࡸࡴࡷࠩṆ") in url:
        content = l111111l11l111_tv_(url)
        l1ll1l1111l11l111_tv_ = re.compile(Variable4 (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪṇ")).findall(content)
        if l1ll1l1111l11l111_tv_:
            src = re.compile(Variable4 (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨṈ"),re.IGNORECASE).findall(l1ll1l1111l11l111_tv_[0])
            if src:
                data = l111111l11l111_tv_(src[0])
                l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src[0],data)
                if l1ll11lll1l11l111_tv_: l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠫࡺࡸ࡬ࠨṉ"):l1ll11lll1l11l111_tv_}]
    return l1lll1ll11l11l111_tv_
