# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re,time
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡰࡰ࡮ࡲࡲ࠲ࡺࡶ࠯ࡤ࡯ࡳ࡬ࡹࡰࡰࡶ࠱ࡧࡴࡳ࠯ࠨᓸ")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ᓹ")
__all__=[Variable4 (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᓺ"),Variable4 (u"ࠩࡪࡩࡹࡉࡨࡢࡰࡱࡩࡱ࡜ࡩࡥࡧࡲࠫᓻ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᓼ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠫࠬᓽ")
    return l11ll11ll11l111_tv_
def l1ll1l1l1ll11l111_tv_(url):
    l1lll1lll1l11l111_tv_=url
    try:
        req = urllib2.Request(url,headers={Variable4 (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᓾ"):l1lll1l1lll11l111_tv_})
        response = urllib2.urlopen(req, timeout=15)
        l1lll1lll1l11l111_tv_=response.geturl()
        response.close()
    except: pass
    return l1lll1lll1l11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(Variable4 (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠧᓿ")).findall(content)
    for href,title in l1lll1lllll11l111_tv_:
        out.append({Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᔀ"):title.strip(),Variable4 (u"ࠨࡶࡹ࡭ࡩ࠭ᔁ"):title.strip(),Variable4 (u"ࠩ࡬ࡱ࡬࠭ᔂ"):Variable4 (u"ࠪࠫᔃ"),Variable4 (u"ࠫࡺࡸ࡬ࠨᔄ"):href,Variable4 (u"ࠬ࡭ࡲࡰࡷࡳࠫᔅ"):Variable4 (u"࠭ࠧᔆ"),Variable4 (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧᔇ"):Variable4 (u"ࠨࠩᔈ")})
    if addheader and len(out):
        t=Variable4 (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡼࡩࡱࡲ࡯ࡸ࡟ࡘࡴࡩࡧࡴࡦࡦ࠽ࠤࠪࡹࠠࠩࡲࡲࡰࡴࡴ࠭ࡵࡸࠬ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᔉ") %time.strftime(Variable4 (u"ࠥࠩࡩ࠵ࠥ࡮࠱ࠨ࡝࠿ࠦࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣᔊ"))
        out.insert(0,{Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᔋ"):t,Variable4 (u"ࠬࡺࡶࡪࡦࠪᔌ"):Variable4 (u"࠭ࠧᔍ"),Variable4 (u"ࠧࡪ࡯ࡪࠫᔎ"):Variable4 (u"ࠨࠩᔏ"),Variable4 (u"ࠩࡸࡶࡱ࠭ᔐ"):l1llll111ll11l111_tv_,Variable4 (u"ࠪ࡫ࡷࡵࡵࡱࠩᔑ"):Variable4 (u"ࠫࠬᔒ"),Variable4 (u"ࠬࡻࡲ࡭ࡧࡳ࡫ࠬᔓ"):Variable4 (u"࠭ࠧᔔ")})
    return out
def l111l1lll11l111_tv_(url=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡱࡱ࡯ࡳࡳ࠳ࡴࡷ࠰ࡥࡰࡴ࡭ࡳࡱࡱࡷ࠲ࡨࡵ࡭࠰ࡲ࠲ࡸࡻࡴ࠮ࡩࡶࡰࡰࠬᔕ")):
    l1lll1ll11l11l111_tv_=[]
    if Variable4 (u"ࠨࡤ࡯ࡳ࡬ࡹࡰࡰࡶࠪᔖ") in url:
        content = l111111l11l111_tv_(url)
        l1111l111ll11l111_tv_ = re.compile(Variable4 (u"ࠩࡸࡲࡪࡹࡣࡢࡲࡨࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࡝ࠫࠪᔗ")).findall(content)
        l1111l111ll11l111_tv_ = urllib.unquote(l1111l111ll11l111_tv_[0]) if l1111l111ll11l111_tv_ else Variable4 (u"ࠪࠫᔘ")
        src = re.compile(Variable4 (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᔙ"),re.IGNORECASE).findall(l1111l111ll11l111_tv_)
        if src:
            src=src[0]
            if not Variable4 (u"ࠬࡨ࡬ࡰࡩࡶࡴࡴࡺࠧᔚ") in src:
                src = l1ll1l1l1ll11l111_tv_(src)
            content = l111111l11l111_tv_(src)
            l1111l111ll11l111_tv_ = re.compile(Variable4 (u"࠭ࡤࡰࡥࡸࡱࡪࡴࡴ࠯ࡹࡵ࡭ࡹ࡫࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࡠ࠮࠭ᔛ")).findall(content)
            if l1111l111ll11l111_tv_:
                l1111l111ll11l111_tv_ = l1111l111ll11l111_tv_[0].replace(Variable4 (u"ࠧ࡝࡞ࡸ࠴࠵࠭ᔜ"),Variable4 (u"ࠨࠩᔝ")).decode(Variable4 (u"ࠩ࡫ࡩࡽ࠭ᔞ"))
                if Variable4 (u"ࠪࡨࡴࡩࡵ࡮ࡧࡱࡸ࠳ࡽࡲࡪࡶࡨࠫᔟ") in l1111l111ll11l111_tv_:
                    l1111l111ll11l111_tv_ = re.compile(Variable4 (u"ࠫࡩࡵࡣࡶ࡯ࡨࡲࡹ࠴ࡷࡳ࡫ࡷࡩࡡ࠮ࡵ࡯ࡧࡶࡧࡦࡶࡥ࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࡡ࠯ࠧᔠ")).findall(l1111l111ll11l111_tv_)
                    l1111l111ll11l111_tv_ = urllib.unquote(l1111l111ll11l111_tv_[0]) if l1111l111ll11l111_tv_ else Variable4 (u"ࠬ࠭ᔡ")
                src = re.compile(Variable4 (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᔢ"),re.IGNORECASE).findall(l1111l111ll11l111_tv_)
                if src:
                    src = src[0].replace(Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡯ࡷ࡯ࡰࡷ࡫ࡦࡦࡴ࠱ࡧࡴࡳ࠯ࡀࠩᔣ"),Variable4 (u"ࠨࠩᔤ"))
                    data = l111111l11l111_tv_(src)
                    l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src,data)
                    if l1ll11lll1l11l111_tv_: return [{Variable4 (u"ࠩࡸࡶࡱ࠭ᔥ"):l1ll11lll1l11l111_tv_}]
                else:
                    l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src,l1111l111ll11l111_tv_)
                    if l1ll11lll1l11l111_tv_: return [{Variable4 (u"ࠪࡹࡷࡲࠧᔦ"):l1ll11lll1l11l111_tv_}]
            l1111l111ll11l111_tv_ = re.compile(Variable4 (u"ࠫࡩࡵࡣࡶ࡯ࡨࡲࡹ࠴ࡷࡳ࡫ࡷࡩࡡ࠮ࡵ࡯ࡧࡶࡧࡦࡶࡥ࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࡡ࠯ࠧᔧ")).findall(content)
            if l1111l111ll11l111_tv_:
                data = urllib.unquote(l1111l111ll11l111_tv_[0]) if l1111l111ll11l111_tv_ else Variable4 (u"ࠬ࠭ᔨ")
                l1lll1ll11l11l111_tv_ = l1lll11l11ll11l111_tv_(data)
            else:
                l1lll1ll11l11l111_tv_ = l1lll11l11ll11l111_tv_(content)
    return l1lll1ll11l11l111_tv_
def l1lll11l11ll11l111_tv_(data):
    l1lll1ll11l11l111_tv_=[]
    l111111llll11l111_tv_ = re.compile(Variable4 (u"࠭ࡻࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᔩ")).findall(data)
    l1l1ll1ll1l11l111_tv_=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡱ࠰࡭ࡻࡵࡩࡤ࡯࠰ࡦࡳࡲ࠵࠶࠰࠳࠵࠳࡯ࡽࡰ࡭ࡣࡼࡩࡷ࠴ࡦ࡭ࡣࡶ࡬࠳ࡹࡷࡧࠩᔪ")
    l1ll1l11l1l11l111_tv_ = re.compile(Variable4 (u"ࠨ࠾ࡰࡩࡹࡧࠠࡤࡱࡱࡸࡪࡴࡴ࠾࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠣࡴࡷࡵࡰࡦࡴࡷࡽࡂࡡࠢ࡝ࠩࡠࡳ࡬ࡀࡵࡳ࡮࡞ࠦࡡ࠭࡝࠰ࡀࠪᔫ")).findall(data)
    if l111111llll11l111_tv_ and l111111llll11l111_tv_[0].endswith(Variable4 (u"ࠩࡰ࠷ࡺ࠾ࠧᔬ")):
        l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠪࡹࡷࡲࠧᔭ"):l111111llll11l111_tv_[0]}]
    elif l111111llll11l111_tv_ and l1ll1l11l1l11l111_tv_:
        href = l111111llll11l111_tv_[0]+ Variable4 (u"ࠫࠥࡹࡷࡧࡗࡵࡰࡂࠫࡳࠡࡲࡤ࡫ࡪ࡛ࡲ࡭࠿ࠨࡷࠥࡲࡩࡷࡧࡀ࠵ࠥࡺࡩ࡮ࡧࡲࡹࡹࡃ࠱࠱ࠩᔮ")%(l1l1ll1ll1l11l111_tv_,l1ll1l11l1l11l111_tv_[0])
        l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠬࡻࡲ࡭ࠩᔯ"):href}]
    else:
        l1ll1l1111l11l111_tv_ = re.compile(Variable4 (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡩࡧࡴࡤࡱࡪࡄࠧᔰ"),re.DOTALL|re.IGNORECASE).findall(data)
        if l1ll1l1111l11l111_tv_:
            connection = re.compile(Variable4 (u"ࠧ࡯ࡧࡷࡇࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴ࠽ࠩࡴࡷࡱࡵ࠴ࠪࡀࠫࠥࠫᔱ")).findall(l1ll1l1111l11l111_tv_[0])
            if connection:
                source = re.compile(Variable4 (u"ࠨࡵࡲࡹࡷࡩࡥ࠾ࠪ࡞ࡢࠫࡣࠫࠪࠩᔲ")).findall(connection[0])
                if source:
                    href = source[0] + Variable4 (u"ࠩࠣࡷࡼ࡬ࡕࡳ࡮ࡀࠩࡸࠦࡰࡢࡩࡨ࡙ࡷࡲ࠽ࠦࡵࠣࡰ࡮ࡼࡥ࠾࠳ࠣࡸ࡮ࡳࡥࡰࡷࡷࡁ࠶࠶ࠧᔳ")%(l1l1ll1ll1l11l111_tv_,l1ll1l11l1l11l111_tv_[0])
                    l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠪࡹࡷࡲࠧᔴ"):href}]
            else:
                href = l1ll11ll1ll11l111_tv_.decode(l1ll1l11l1l11l111_tv_[0],l1ll1l1111l11l111_tv_[0])
                if href : l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠫࡺࡸ࡬ࠨᔵ"):href}]
    return l1lll1ll11l11l111_tv_
