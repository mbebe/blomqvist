# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
import urlparse
l1lll1l1lll11l111_tv_=Variable4 (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧὉ")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭Ὂ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠪࠫὋ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(Variable4 (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡲࡦࡣ࡯ࡹ࠷࠺࠮ࡵࡸ࠲ࠫὌ"))
    l1l111l1llll11l111_tv_ = re.compile(Variable4 (u"ࠬࡂࡨ࠲ࡀࠫ࠲࠰ࡅࠩ࠽࠱࡫࠵ࡃ࠴ࠫࡀ࠾࡫࠶ࡃ࠮࠮ࠬࡁࠬࡀ࠴࡮࠲࠿࠰࠮ࡃࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠰ࡰࡤ࠱ࡿࡿࡷࡰ࠱࡞ࡢࠧࡣࠪࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࡜ࡠࠥࡡ࠰࠯ࠢࠨὍ"),re.DOTALL).findall(content)
    out=[]
    for title,code,href,l1llll11lll11l111_tv_ in l1l111l1llll11l111_tv_:
        l1llll11lll11l111_tv_ = urlparse.urljoin(Variable4 (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡴࡨࡥࡱࡻ࠲࠵࠰ࡷࡺ࠴࠭὎"),l1llll11lll11l111_tv_)
        href = urlparse.urljoin(Variable4 (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡵࡩࡦࡲࡵ࠳࠶࠱ࡸࡻ࠵ࠧ὏"),href)
        out.append({Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧὐ"):title.strip(),Variable4 (u"ࠩࡷࡺ࡮ࡪࠧὑ"):title.strip(),Variable4 (u"ࠪ࡭ࡲ࡭ࠧὒ"):l1llll11lll11l111_tv_,Variable4 (u"ࠫࡺࡸ࡬ࠨὓ"):href,Variable4 (u"ࠬࡩ࡯ࡥࡧࠪὔ"):code,Variable4 (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭ὕ"):Variable4 (u"ࠧࠨὖ")})
    l1l111ll111l11l111_tv_ = re.findall(Variable4 (u"ࠨ࠾ࡤࠤࡨࡲࡡࡴࡵࡀࠦࡻ࡯ࡤࡦࡱ࠰ࡸ࡭ࡻ࡭ࡣࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬὗ"),content,re.DOTALL)
    for l1l1l1ll11l111_tv_ in l1l111ll111l11l111_tv_:
        href = re.findall(Variable4 (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ὘"),l1l1l1ll11l111_tv_)
        href = urlparse.urljoin(Variable4 (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡸࡥࡢ࡮ࡸ࠶࠹࠴ࡴࡷ࠱ࠪὙ"),href[0]) if href else Variable4 (u"ࠫࠬ὚")
        l1llll11lll11l111_tv_ = re.findall(Variable4 (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪὛ"),l1l1l1ll11l111_tv_)
        l1llll11lll11l111_tv_ = urlparse.urljoin(Variable4 (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡴࡨࡥࡱࡻ࠲࠵࠰ࡷࡺ࠴࠭὜"),l1llll11lll11l111_tv_[-1])if l1llll11lll11l111_tv_ else Variable4 (u"ࠧࠨὝ")
        title = re.findall(Variable4 (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭὞"),l1l1l1ll11l111_tv_)
        title = title[0].strip() if title else Variable4 (u"ࠩࠪὟ")
        code = re.findall(Variable4 (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡨࡰࡪࡧࡳࡦࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࠬὠ"),l1l1l1ll11l111_tv_)
        code = code[0].strip() if code else Variable4 (u"ࠫࠬὡ")
        if href and title and l1llll11lll11l111_tv_:
            out.append({Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫὢ"):title.strip(),Variable4 (u"࠭ࡴࡷ࡫ࡧࠫὣ"):title.strip(),Variable4 (u"ࠧࡪ࡯ࡪࠫὤ"):l1llll11lll11l111_tv_,Variable4 (u"ࠨࡷࡵࡰࠬὥ"):href,Variable4 (u"ࠩࡦࡳࡩ࡫ࠧὦ"):code,Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪὧ"):Variable4 (u"ࠫࠬὨ")})
    if addheader and len(out):
        t=Variable4 (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡿࡥ࡭࡮ࡲࡻࡢ࡛ࡰࡥࡣࡷࡩࡩࡀࠠࠦࡵࠣࠬࡼࡸࡥࡢ࡮ࡸ࠶࠹࠯࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨὩ") %time.strftime(Variable4 (u"ࠨࠥࡥ࠱ࠨࡱ࠴࡙ࠫ࠻ࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦὪ"))
        out.insert(0,{Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭Ὣ"):t,Variable4 (u"ࠨࡶࡹ࡭ࡩ࠭Ὤ"):Variable4 (u"ࠩࠪὭ"),Variable4 (u"ࠪ࡭ࡲ࡭ࠧὮ"):Variable4 (u"ࠫࠬὯ"),Variable4 (u"ࠬࡻࡲ࡭ࠩὰ"):l1llll111ll11l111_tv_,Variable4 (u"࠭ࡧࡳࡱࡸࡴࠬά"):Variable4 (u"ࠧࠨὲ"),Variable4 (u"ࠨࡷࡵࡰࡪࡶࡧࠨέ"):Variable4 (u"ࠩࠪὴ")})
    return out
def l111l1lll11l111_tv_(url):
    l1lll1ll11l11l111_tv_=[]
    content = l111111l11l111_tv_(url)
    src  = re.compile(Variable4 (u"ࠪࡷࡷࡩ࡜ࡴࠬࡀࡠࡸ࠰ࠢࠩࡪࡷࡸࡵ࠴ࠫ࠯࡯࠶ࡹ࠽࠯ࠢࠡࡶࡼࡴࡪࡃࠢࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠬή")).findall(content)
    if src:
        l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠫࡺࡸ࡬ࠨὶ"):src[-1]+Variable4 (u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠩࡸࠬࡒࡦࡨࡨࡶࡪࡃࠥࡴࠩί")%(l1lll1l1lll11l111_tv_,url),Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬὸ"):Variable4 (u"ࠧࡍ࡫ࡱ࡯ࠥ࠭ό")})
    else:
        src  = re.compile(Variable4 (u"ࠨࡵࡵࡧࡡࡹࠪ࠾࡞ࡶ࠮ࠧ࠮ࡨࡵࡶࡳ࠲࠰ࡅࠩࠣࠢࡷࡽࡵ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨὺ")).findall(content)
        for l11ll11ll11l111_tv_, t,q in src:
            if Variable4 (u"ࠤࠪ࠯ࡸࡸࡶࠬࠩࠥύ") in l11ll11ll11l111_tv_: continue
            l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠪࡹࡷࡲࠧὼ"):l11ll11ll11l111_tv_+Variable4 (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠨࡷࠫࡘࡥࡧࡧࡵࡩࡂࠫࡳࠨώ")%(l1lll1l1lll11l111_tv_,url),Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫ὾"):q})
    return l1lll1ll11l11l111_tv_
