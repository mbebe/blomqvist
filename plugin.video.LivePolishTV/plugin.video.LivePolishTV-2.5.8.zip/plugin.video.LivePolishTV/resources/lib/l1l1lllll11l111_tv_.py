# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
import time,json
l1llll111ll11l111_tv_=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸ࡫ࡽ࡮ࡦ࠴ࡴࡷ࠱ࠪẋ")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧẌ")
__all__=[Variable4 (u"ࠩࡪࡩࡹࡉࡨࡢࡰࡱࡩࡱࡹࠧẍ"),Variable4 (u"ࠪ࡫ࡪࡺࡃࡩࡣࡱࡲࡪࡲࡖࡪࡦࡨࡳࠬẎ")]
fix={
Variable4 (u"ࠫࡆࡲࡥ࡬࡫ࡱࡳࠬẏ"):Variable4 (u"ࠬࡧ࡬ࡦࠢ࡮࡭ࡳࡵࠫࠨẐ"),
Variable4 (u"࠭ࡁ࡯࡫ࡰࡥࡱ࠭ẑ"):Variable4 (u"ࠧࡂࡰ࡬ࡱࡦࡲࠠࡑ࡮ࡤࡲࡪࡺࠧẒ"),
Variable4 (u"ࠨࡅࡤࡲࡦࡲࠧẓ"):Variable4 (u"ࠩࡆࡥࡳࡧ࡬ࠬࠩẔ"),
Variable4 (u"ࠪࡇࡦࡴࡡ࡭ࡦ࡬ࡷࡨࡵࡶࡦࡴࡼࠫẕ"):Variable4 (u"ࠫࡈࡧ࡮ࡢ࡮࠮ࠤࡉ࡯ࡳࡤࡱࡹࡩࡷࡿࠠࡉࡆࠪẖ"),
Variable4 (u"ࠬࡉࡡ࡯ࡣ࡯ࡪࡦࡳࡩ࡭ࡻࠪẗ"):Variable4 (u"࠭ࡃࡢࡰࡤࡰ࠰ࠦࡆࡢ࡯࡬ࡰࡾ࠭ẘ"),
Variable4 (u"ࠧࡄࡣࡱࡥࡱ࡬ࡩ࡭࡯ࠪẙ"):Variable4 (u"ࠨࡅࡤࡲࡦࡲࠫࠡࡈ࡬ࡰࡲ࠭ẚ"),
Variable4 (u"ࠩࡆࡥࡳࡧ࡬ࡴࡲࡲࡶࡹ࠭ẛ"):Variable4 (u"ࠪࡇࡦࡴࡡ࡭࠭ࠣࡗࡵࡵࡲࡵࠩẜ"),
Variable4 (u"ࠫࡈࡧ࡮ࡢ࡮ࡶࡴࡴࡸࡴ࠳ࠩẝ"):Variable4 (u"ࠬࡉࡡ࡯ࡣ࡯࠯࡙ࠥࡰࡰࡴࡷࠤ࠷࠭ẞ"),
Variable4 (u"࠭ࡃࡢࡴࡷࡳࡴࡴࠧẟ"):Variable4 (u"ࠧࡄࡣࡵࡸࡴࡵ࡮ࠡࡐࡨࡸࡼࡵࡲ࡬ࠩẠ"),
Variable4 (u"ࠨࡅ࡬ࡲࡪࡳࡡࡹࠩạ"):Variable4 (u"ࠩࡆ࡭ࡳ࡫࡭ࡢࡺࠪẢ"),
Variable4 (u"ࠪࡇࡴࡳࡥࡥࡻࠪả"):Variable4 (u"ࠫࡈࡵ࡭ࡦࡦࡼࠤࡈ࡫࡮ࡵࡴࡤࡰࠬẤ"),
Variable4 (u"ࠬࡊࡩࡴࡥࡲࡺࡪࡸࡹࠨấ"):Variable4 (u"࠭ࡄࡪࡵࡦࡳࡻ࡫ࡲࡺࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ࠪẦ"),
Variable4 (u"ࠧࡅ࡫ࡶࡧࡴࡼࡥࡳࡻ࡫࡭ࡸࡺ࡯ࡳ࡫ࡤࠫầ"):Variable4 (u"ࠨࡆ࡬ࡷࡨࡵࡶࡦࡴࡼࠤࡍ࡯ࡳࡵࡱࡵ࡭ࡦ࠭Ẩ"),
Variable4 (u"ࠩࡇ࡭ࡸࡩ࡯ࡷࡧࡵࡽࡸࡩࡩࡦࡰࡦࡩࠬẩ"):Variable4 (u"ࠪࡈ࡮ࡹࡣࡰࡸࡨࡶࡾࠦࡓࡤ࡫ࡨࡲࡨ࡫ࠧẪ"),
Variable4 (u"ࠫࡉ࡯ࡳ࡯ࡧࡼ࡮ࡺࡴࡩࡰࡴࠪẫ"):Variable4 (u"ࠬࡊࡩࡴࡰࡨࡽࠥࡐࡵ࡯࡫ࡲࡶࠬẬ"),
Variable4 (u"࠭ࡅ࡭ࡧࡹࡩࡳ࠭ậ"):Variable4 (u"ࠧࡆ࡮ࡨࡺࡪࡴࠧẮ"),
Variable4 (u"ࠨࡇ࡯ࡩࡻ࡫࡮ࡦࡺࡷࡶࡦ࠭ắ"):Variable4 (u"ࠩࡈࡰࡪࡼࡥ࡯ࠢࡈࡼࡹࡸࡡࠨẰ"),
Variable4 (u"ࠪࡉࡱ࡫ࡶࡦࡰࡶࡴࡴࡸࡴࡴࠩằ"):Variable4 (u"ࠫࡊࡲࡥࡷࡧࡱࠤࡘࡶ࡯ࡳࡶࡶࠫẲ"),
Variable4 (u"ࠬࡋࡳ࡬ࡣࠪẳ"):Variable4 (u"࠭ࡅࡴ࡭ࡤࠤ࡙࡜ࠧẴ"),
Variable4 (u"ࠧࡆࡷࡵࡳࡸࡶ࡯ࡳࡶ࠴ࠫẵ"):Variable4 (u"ࠨࡇࡸࡶࡴࡹࡰࡰࡴࡷࠫẶ"),
Variable4 (u"ࠩࡈࡹࡷࡵࡳࡱࡱࡵࡸ࠷࠭ặ"):Variable4 (u"ࠪࡉࡺࡸ࡯ࡴࡲࡲࡶࡹࠦ࠲ࠨẸ"),
Variable4 (u"ࠫࡋ࡯࡬࡮ࡤࡲࡼࠬẹ"):Variable4 (u"ࠬࡌࡩ࡭࡯ࡥࡳࡽ࠭Ẻ"),
Variable4 (u"࠭ࡈࡣࡱࠪẻ"):Variable4 (u"ࠧࡉࡄࡒࠫẼ"),
Variable4 (u"ࠨࡊࡥࡳ࠷࠭ẽ"):Variable4 (u"ࠩࡋࡆࡔ࠸ࠧẾ"),
Variable4 (u"ࠪࡌࡧࡵ࠳ࠨế"):Variable4 (u"ࠫࡍࡈࡏ࠴ࠩỀ"),
Variable4 (u"ࠬࡎࡩࡴࡶࡲࡶࡾ࠭ề"):Variable4 (u"࠭ࡈࡪࡵࡷࡳࡷࡿࠧỂ"),
Variable4 (u"ࠧࡌ࡫ࡱࡳࡵࡵ࡬ࡴ࡭ࡤࠫể"):Variable4 (u"ࠨࡍ࡬ࡲࡴࠦࡐࡰ࡮ࡶ࡯ࡦ࠭Ễ"),
Variable4 (u"ࠩࡐࡸࡻ࠭ễ"):Variable4 (u"ࠪࡑ࡙࡜ࠠࡑࡱ࡯ࡷࡰࡧࠧỆ"),
Variable4 (u"ࠫࡓࡧࡴࡨࡧࡲࠫệ"):Variable4 (u"ࠬࡔࡡࡵ࡫ࡲࡲࡦࡲࠠࡈࡧࡲ࡫ࡷࡧࡰࡩ࡫ࡦࠤࡈ࡮ࡡ࡯ࡰࡨࡰࠬỈ"),
Variable4 (u"࠭ࡎࡢࡶࡪࡩࡴࡽࡩ࡭ࡦࠪỉ"):Variable4 (u"ࠧࡏࡣࡷࠤࡌ࡫࡯࡙ࠡ࡬ࡰࡩ࠭Ị"),
Variable4 (u"ࠨࡐࡶࡴࡴࡸࡴࠨị"):Variable4 (u"ࠩࡱࡗࡵࡵࡲࡵࠩỌ"),
Variable4 (u"ࠪࡔࡴࡲࡳࡢࡶࠪọ"):Variable4 (u"ࠫࡕࡵ࡬ࡴࡣࡷࠫỎ"),
Variable4 (u"ࠬࡖ࡯࡭ࡵࡤࡸࡳ࡫ࡷࡴࠩỏ"):Variable4 (u"࠭ࡐࡰ࡮ࡶࡥࡹࠦࡎࡦࡹࡶࠫỐ"),
Variable4 (u"ࠧࡑࡱ࡯ࡷࡦࡺࡰ࡭ࡣࡼࠫố"):Variable4 (u"ࠨࡒࡲࡰࡸࡧࡴࠡࡒ࡯ࡥࡾ࠭Ồ"),
Variable4 (u"ࠩࡓࡳࡱࡹࡡࡵࡵࡳࡳࡷࡺࠧồ"):Variable4 (u"ࠪࡔࡴࡲࡳࡢࡶࠣࡗࡵࡵࡲࡵࠩỔ"),
Variable4 (u"ࠫࡕࡵ࡬ࡴࡣࡷࡷࡵࡵࡲࡵࡧࡻࡸࡷࡧࠧổ"):Variable4 (u"ࠬࡖ࡯࡭ࡵࡤࡸ࡙ࠥࡰࡰࡴࡷࠤࡊࡾࡴࡳࡣࠪỖ"),
Variable4 (u"࠭ࡐࡰ࡮ࡶࡥࡹࡹࡰࡰࡴࡷࡲࡪࡽࡳࠨỗ"):Variable4 (u"ࠧࡑࡱ࡯ࡷࡦࡺࠠࡔࡲࡲࡶࡹࠦࡎࡦࡹࡶࠫỘ"),
Variable4 (u"ࠨࡖ࡯ࡧࠬộ"):Variable4 (u"ࠩࡗࡐࡈ࠭Ớ"),
Variable4 (u"ࠪࡘࡷࡧࡶࡦ࡮ࠪớ"):Variable4 (u"࡙ࠫࡸࡡࡷࡧ࡯ࠤࡈ࡮ࡡ࡯ࡰࡨࡰࠬỜ"),
Variable4 (u"࡚ࠬࡶ࠵ࠩờ"):Variable4 (u"࠭ࡔࡗࠢ࠷ࠫỞ"),
Variable4 (u"ࠧࡕࡸࡱࠫở"):Variable4 (u"ࠨࡖ࡙ࡒࠬỠ"),
Variable4 (u"ࠩࡗࡺࡳ࠸࠴ࠨỡ"):Variable4 (u"ࠪࡘ࡛ࡔࠠ࠳࠶ࠪỢ"),
Variable4 (u"࡙ࠫࡼ࡮࠸ࠩợ"):Variable4 (u"࡚ࠬࡖࡏࠢ࠺ࠫỤ"),
Variable4 (u"࠭ࡔࡷࡰࡶࡸࡾࡲࡥࠨụ"):Variable4 (u"ࠧࡕࡘࡑࠤࡘࡺࡹ࡭ࡧࠪỦ"),
Variable4 (u"ࠨࡖࡹࡲࡹࡻࡲࡣࡱࠪủ"):Variable4 (u"ࠩࡗ࡚ࡓࠦࡔࡶࡴࡥࡳࠬỨ"),
Variable4 (u"ࠪࡘࡻࡶ࠱ࠨứ"):Variable4 (u"࡙ࠫ࡜ࡐࠡ࠳ࠪỪ"),
Variable4 (u"࡚ࠬࡶࡱ࠴ࠪừ"):Variable4 (u"࠭ࡔࡗࡒࠣ࠶ࠬỬ"),
Variable4 (u"ࠧࡕࡸࡳࡷࡪࡸࡩࡢ࡮ࡨࠫử"):Variable4 (u"ࠨࡖ࡙ࡔ࡙ࠥࡥࡳ࡫ࡤࡰࡪ࠭Ữ"),
Variable4 (u"ࠩࡗࡺࡵࡹࡰࡰࡴࡷࠫữ"):Variable4 (u"ࠪࡘ࡛ࡖࠠࡔࡲࡲࡶࡹ࠭Ự"),
Variable4 (u"࡙ࠫࡼࡰࡶ࡮ࡶࠫự"):Variable4 (u"࡚ࠬࡖࠡࡒࡸࡰࡸ࠭Ỳ"),
Variable4 (u"࠭ࡖࡪࡸࡤࠫỳ"):Variable4 (u"ࠧࡗࡋ࡙ࡅࠥࡖ࡯࡭ࡵ࡮ࡥࠬỴ"),
}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠨࡶࡹ࡭ࡩ࠭ỵ")),Variable4 (u"ࠩࠪỶ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩỷ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[Variable4 (u"ࠫࡹࡼࡩࡥࠩỸ")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩỹ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"࠭ࠧỺ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    url=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸ࡫ࡽ࡮ࡦ࠴ࡴࡷ࠱ࠪỻ")
    content = l111111l11l111_tv_(url)
    l11llll11ll11l111_tv_=re.compile(Variable4 (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬࡼࡧࡴࡤࡪ࠱࠮ࡄ࠯ࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁ࠵ࡡ࠿ࠩỼ")).findall(content)
    out=[]
    for ch in l11llll11ll11l111_tv_:
        t = ch[1].split(Variable4 (u"ࠩ࠲ࠫỽ"))[-1].split(Variable4 (u"ࠪ࠲ࠬỾ"))[0].title()
        i = l1llll111ll11l111_tv_ + ch[1]
        h = l1llll111ll11l111_tv_ + ch[0]
        out.append(l1lll1l1l1l11l111_tv_({Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪỿ"):t,Variable4 (u"ࠬࡺࡶࡪࡦࠪἀ"):t,Variable4 (u"࠭ࡩ࡮ࡩࠪἁ"):i,Variable4 (u"ࠧࡶࡴ࡯ࠫἂ"):h,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧἃ"):Variable4 (u"ࠩࠪἄ"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪἅ"):Variable4 (u"ࠫࠬἆ")}))
    out = sorted(out, key=lambda k: k[Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫἇ")],reverse=False)
    if out and addheader:
        t=Variable4 (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡽࡩࡻ࡬ࡤ࠲ࡹࡼࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩἈ") %time.strftime(Variable4 (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠧἉ"))
        out.append({Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧἊ"):t,Variable4 (u"ࠩࡷࡺ࡮ࡪࠧἋ"):Variable4 (u"ࠪࠫἌ"),Variable4 (u"ࠫ࡮ࡳࡧࠨἍ"):Variable4 (u"ࠬ࠭Ἆ"),Variable4 (u"࠭ࡵࡳ࡮ࠪἏ"):Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸ࡫ࡽ࡮ࡦ࠴ࡴࡷ࠱ࠪἐ"),Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧἑ"):Variable4 (u"ࠩࠪἒ"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪἓ"):Variable4 (u"ࠫࠬἔ")})
    return out
def l11l1llll1l11l111_tv_(url,params=None,header={}):
    req = urllib2.Request(url,params,headers=header)
    sock=urllib2.urlopen(req)
    cookies=sock.info()[Variable4 (u"࡙ࠬࡥࡵ࠯ࡆࡳࡴࡱࡩࡦࠩἕ")]
    sock.close()
    return cookies
def l1llll1l1lll11l111_tv_(cookies=Variable4 (u"࠭ࠧ἖"),value=Variable4 (u"ࠧࡴࡧࡶࡷࡸ࡯ࡤࠨ἗")):
    l1l11l111ll11l111_tv_=cookies.find(value+Variable4 (u"ࠨ࠿ࠪἘ"))
    if l1l11l111ll11l111_tv_==-1:
        l1l11l111lll11l111_tv_ (u"ࠩࠪἙ")
    else:
        l1l11l11l1l11l111_tv_=cookies.find(Variable4 (u"ࠪ࠿ࠬἚ"),l1l11l111ll11l111_tv_+1)
    return cookies[l1l11l111ll11l111_tv_:l1l11l11l1l11l111_tv_]
def l111l1lll11l111_tv_(url=Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼ࡯ࡺ࡫ࡣ࠱ࡸࡻ࠵ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱࡁ࡬ࡨࡂ࠷࠲࠳ࠩἛ")):
    l1lll1ll11l11l111_tv_=[]
    if Variable4 (u"ࠬࡽࡩࡻ࡬ࡤ࠲ࡹࡼࠧἜ") in url:
        id = re.search(Variable4 (u"࠭ࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩἝ"),url)
        if id:
            id = id.group(1)
        elif Variable4 (u"ࠧࡪࡦࡀࠫ἞")in url:
            id=url.l1l111lll1ll11l111_tv_(Variable4 (u"ࠨ࡫ࡧࡁࠬ἟"))[-1]
        else:
            id=Variable4 (u"ࠩ࠴࠶࠷࠭ἠ")
        l1l11l11111l11l111_tv_=Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻ࡮ࢀࡪࡢ࠰ࡷࡺ࠴ࡶ࡯ࡳࡶࡨࡶ࠳ࡶࡨࡱࡁࡦ࡬ࡂࠫࡳࠨἡ")%id
        l1l111llllll11l111_tv_=Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼ࡯ࡺ࡫ࡣ࠱ࡸࡻ࠵ࡰ࡭ࡣࡼࡩࡷ࠴ࡰࡩࡲࡂࡸࡦࡸࡧࡦࡶࡀࡩࡵࡵ࡮ࡢ࠵ࠩࡧ࡭ࡃࠥࡴࠩἢ")%id
        l1l111llllll11l111_tv_=Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡩࡻ࡬ࡤ࠲ࡹࡼ࠯ࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࡃࠫࡩࡨ࠾ࠧࡶࠫἣ")%id
        print l1l111llllll11l111_tv_
        header={
                Variable4 (u"࠭ࡁࡤࡥࡨࡴࡹ࠭ἤ"):Variable4 (u"ࠧࡵࡧࡻࡸ࠴࡮ࡴ࡮࡮࠯ࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࡫ࡸࡲࡲࠫࡹ࡯࡯࠰ࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻࡱࡱࡁࡱ࠾࠲࠱࠽࠱࡯࡭ࡢࡩࡨ࠳ࡼ࡫ࡢࡱ࠮࠭࠳࠯ࡁࡱ࠾࠲࠱࠼ࠬἥ"),
                Variable4 (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬἦ"):Variable4 (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠷࠳࠲࠵࠴࠲࠷࠸࠴࠲࠶࠶࠲ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨἧ"),
                Variable4 (u"ࠪࡌࡴࡹࡴࠨἨ"):Variable4 (u"ࠫࡼ࡯ࡺ࡫ࡣ࠱ࡸࡻ࠭Ἡ"),
                Variable4 (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭Ἢ"):url,
                Variable4 (u"࠭ࡃࡢࡥ࡫ࡩ࠲ࡉ࡯࡯ࡶࡵࡳࡱ࠭Ἣ"):Variable4 (u"ࠧ࡮ࡣࡻ࠱ࡦ࡭ࡥ࠾࠲ࠪἬ"),
                Variable4 (u"ࠣࡅࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠧἭ"):Variable4 (u"ࠤ࡮ࡩࡪࡶ࠭ࡢ࡮࡬ࡺࡪࠨἮ"),
                Variable4 (u"࡙ࠪࡵ࡭ࡲࡢࡦࡨ࠱ࡎࡴࡳࡦࡥࡸࡶࡪ࠳ࡒࡦࡳࡸࡩࡸࡺࡳࠨἯ"):Variable4 (u"ࠫ࠶࠭ἰ"),
                }
        c=l11l1llll1l11l111_tv_(url,header=header)
        l1llll1l11l11l111_tv_=Variable4 (u"ࠬࠦࠧἱ").join([Variable4 (u"࠭ࠥࡴ࠽ࠪἲ")%l1llll1l1lll11l111_tv_(c,s) for s in [Variable4 (u"ࠧࡠࡡࡦࡪࡩࡻࡩࡥࠩἳ"),Variable4 (u"ࠨࡒࡋࡔࡘࡋࡓࡔࡋࡇࠫἴ")]])
        header[Variable4 (u"ࠩࡆࡳࡴࡱࡩࡦࠩἵ")]=l1llll1l11l11l111_tv_
        data = l111111l11l111_tv_(l1l11l11111l11l111_tv_,header=header)
        l1l11l11l11l11l111_tv_ = re.compile(Variable4 (u"ࠪࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩἶ")).findall(data)
        if len(l1l11l11l11l11l111_tv_)>0:
            l1l111llll1l11l111_tv_ = re.compile(Variable4 (u"ࠫࡪࡳࡢࡦࡦࡖ࡛ࡋࡢࡳࠫ࡞ࠫࡠࡸ࠰࡛ࠣ࡞ࠪࡡ࠭࠴ࠪ࠯ࡵࡺࡪ࠮ࡡࠢ࡝ࠩࡠࠫἷ")).findall(data)
            l1l11l111l1l11l111_tv_ = urllib.unquote(l1l11l11l11l11l111_tv_[0]).decode(Variable4 (u"ࠬࡻࡴࡧ࠯࠻ࠫἸ"))
            l1l11l1111ll11l111_tv_ = re.compile(Variable4 (u"࠭ࡲࡵ࡯ࡳ࠾࠴࠵ࠨ࠯ࠬࡂ࠭࠴࠮࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫ࡟ࡃ࠭࠴ࠪࡀࠫ࡟ࠪࡸࡺࡲࡦࡣࡰࡘࡾࡶࡥࠨἹ")).findall(l1l11l111l1l11l111_tv_)
            l1ll11lll1l11l111_tv_ = Variable4 (u"ࠧࡳࡶࡰࡴ࠿࠵࠯ࠨἺ") + l1l11l1111ll11l111_tv_[0][0] + Variable4 (u"ࠨ࠱ࠪἻ") + l1l11l1111ll11l111_tv_[0][1] + Variable4 (u"ࠩࡂࠫἼ") + l1l11l1111ll11l111_tv_[0][3] + Variable4 (u"ࠪࠤࡵࡲࡡࡺࡲࡤࡸ࡭ࡃࠧἽ") + l1l11l1111ll11l111_tv_[0][2] + Variable4 (u"ࠫࡄ࠭Ἶ") + l1l11l1111ll11l111_tv_[0][3] +  Variable4 (u"ࠬࠦࡴࡪ࡯ࡨࡳࡺࡺ࠽࠳࠷ࠣࡷࡼ࡬ࡕࡳ࡮ࡀ࡬ࡹࡺࡰ࠻࠱࠲ࡻ࡮ࢀࡪࡢ࠰ࡷࡺ࠴ࡶ࡬ࡢࡻࡨࡶ࠴࡙ࡴࡳࡱࡥࡩࡒ࡫ࡤࡪࡣࡓࡰࡦࡿࡢࡢࡥ࡮ࡣࡻ࠺࠮ࡴࡹࡩࠤࡱ࡯ࡶࡦ࠿ࡷࡶࡺ࡫ࠠࡱࡣࡪࡩ࡚ࡸ࡬࠾ࠩἿ") + l1l111llllll11l111_tv_
            l1lll1ll11l11l111_tv_=[{Variable4 (u"࠭ࡵࡳ࡮ࠪὀ"):l1ll11lll1l11l111_tv_}]
        else:
            l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠧ࡮ࡵࡪࠫὁ"):Variable4 (u"ࠨ࡝ࡅࡡࡇࡸࡡ࡬ࠢࡺࡳࡱࡴࡹࡤࡪࠣࡱ࡮࡫ࡪࡴࡥࠤ࡟࠴ࡈ࡝࡝ࡰ࡝ࡩࠥࡽࡺࡨ࡮जࡨࡺࠦ࡮ࡢࠢࡧࡹঁࡧࠠࡪ࡮ࡲय़ऌࠦ࡯ࡨ࡮ईࡨࡦࡰअࡤࡻࡦ࡬ࠥࡵࡳࣴࡤࠣ࠱ࠥࡪ࡯ࡴࡶजࡴࠥࡺࡹ࡭࡭ࡲࠤࡩࡲࡡࠡࡷॿࡽࡹࡱ࡯ࡸࡰ࡬࡯ࣸࡽࠠࡑࡴࡨࡱ࡮ࡻ࡭࠯࡞ࡱ࡟ࡇࡣࡋࡰࡰࡷࡥࠥࡖࡲࡦ࡯࡬ࡹࡲࠦ࡮ࡪࡧࠣࡦञࡪअࠡࡶࡸࠤࡴࡨࡳृࡷࡪ࡭ࡼࡧ࡮ࡦࠣ࠱࡟࠴ࡈ࡝ࠨὂ")}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_()
    for o in out:
        print o.get(Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨὃ"))
