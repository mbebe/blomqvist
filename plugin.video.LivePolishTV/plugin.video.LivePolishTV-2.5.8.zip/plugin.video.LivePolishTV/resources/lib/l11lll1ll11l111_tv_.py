# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
import time
import sys,os
import json
import cookielib
import threading
l1llll111ll11l111_tv_=Variable4 (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡬ࡰࡱ࡮ࡲ࡮ࡰ࠮ࡪࡰࠪṊ")
l1lll1l1lll11l111_tv_=Variable4 (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬṋ")
l1lll1ll1ll11l111_tv_ = Variable4 (u"ࠧ࠲࠲ࠪṌ")
fix={}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠨࡶࡹ࡭ࡩ࠭ṍ")),Variable4 (u"ࠩࠪṎ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩṏ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[Variable4 (u"ࠫࡹࡼࡩࡥࠩṐ")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},cookies=None,l1llll1l1l11l111_tv_=True):
    if l1llll1l1l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩṑ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    if cookies:
        req.add_header(Variable4 (u"ࠨࡣࡰࡱ࡮࡭ࡪࠨṒ"), cookies)
    try:
        response = urllib2.urlopen(req, timeout=10)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠧࠨṓ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(Variable4 (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡩࡪࡨ࠮ࡵࡸ࠲࡮ࡸࡵ࡮࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡳࡵࡺࡩࡰࡰࡀࡳࡳࡲࡩ࡯ࡧ࠰ࡥࡱࡶࡨࡢࡤࡨࡸ࡮ࡩࡡ࡭ࠩṔ"))
    try:
        data = json.loads(content)
    except:
        data = {}
    out=[]
    for k,v in data.items():
        print v.keys()
        group=Variable4 (u"ࠩࠪṕ")
        t=v.get(Variable4 (u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣࡹ࡯ࡴ࡭ࡧࠪṖ"))
        i=v.get(Variable4 (u"ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡤࡲ࡯ࡨࡱࡢࡹࡷࡲࠧṗ"))
        h=v.get(Variable4 (u"ࠬࡩࡨࡢࡰࡱࡩࡱࡥ࡮ࡢ࡯ࡨࠫṘ"))
        if h:
            out.append(l1lll1l1l1l11l111_tv_({Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬṙ"):t,Variable4 (u"ࠧࡵࡸ࡬ࡨࠬṚ"):t,Variable4 (u"ࠨ࡫ࡰ࡫ࠬṛ"):i,Variable4 (u"ࠩࡸࡶࡱ࠭Ṝ"):h,Variable4 (u"ࠪ࡫ࡷࡵࡵࡱࠩṝ"):group,Variable4 (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫṞ"):Variable4 (u"ࠬ࠭ṟ")}))
    if len(out)>0 and addheader:
        t=Variable4 (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡽࡥࡦࡤ࠱ࡸࡻ࠯࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨṠ") %time.strftime(Variable4 (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠧṡ"))
        out.insert(0,{Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧṢ"):t,Variable4 (u"ࠩࡷࡺ࡮ࡪࠧṣ"):Variable4 (u"ࠪࠫṤ"),Variable4 (u"ࠫ࡮ࡳࡧࠨṥ"):Variable4 (u"ࠬ࠭Ṧ"),Variable4 (u"࠭ࡵࡳ࡮ࠪṧ"):Variable4 (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡨࡩࡧ࠴ࡴࡷ࠱ࠪṨ"),Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧṩ"):Variable4 (u"ࠩࠪṪ"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪṫ"):Variable4 (u"ࠫࠬṬ")})
    return out
def l1l11l1ll11l11l111_tv_(l1l11l11l1ll11l111_tv_):
    param=[]
    if len(l1l11l11l1ll11l111_tv_) >= 2:
        params = l1l11l11l1ll11l111_tv_
        l1l11l1l11ll11l111_tv_ = params.replace(Variable4 (u"ࠬࡅࠧṭ"), Variable4 (u"࠭ࠧṮ"))
        if (params[len(params)-1] == Variable4 (u"ࠧ࠰ࠩṯ")):
            params = params[0:len(params)-2]
        l1l11l1l1l1l11l111_tv_ = l1l11l1l11ll11l111_tv_.split(Variable4 (u"ࠨࠨࠪṰ"))
        param = {}
        for i in range(len(l1l11l1l1l1l11l111_tv_)):
            l1l11l1l1lll11l111_tv_ = {}
            l1l11l1l1lll11l111_tv_ = l1l11l1l1l1l11l111_tv_[i].split(Variable4 (u"ࠩࡀࠫṱ"))
            if (len(l1l11l1l1lll11l111_tv_)) == 2:
                param[l1l11l1l1lll11l111_tv_[0]] = l1l11l1l1lll11l111_tv_[1]
        return param
def l111l1lll11l111_tv_(l1l11l11ll1l11l111_tv_=Variable4 (u"ࠪࡸࡻࡶ࠲ࡩࡦࡧࡻࡴࡰ࡫ࡢࠩṲ")):
    l1lll1ll11l11l111_tv_=[]
    url=Variable4 (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡥࡦࡤ࠱ࡸࡻ࠵ࡡࡱ࡫࠲ࡷࡪࡺࡰ࡭ࡣࡼࡩࡷ࠭ṳ")
    data = l111111l11l111_tv_(url,Variable4 (u"ࠬࡩࡨࡢࡰࡱࡩࡱࡃࠥࡴࠩṴ")%l1l11l11ll1l11l111_tv_)
    if data:
        data = urllib.unquote(data)
        param=l1l11l1ll11l11l111_tv_(data)
        l1l11l1l111l11l111_tv_ = param.get(Variable4 (u"࠭࠱࠱ࠩṵ"))
        l1l11l1ll1ll11l111_tv_ = param.get(Variable4 (u"ࠧ࠲࠳ࠪṶ"))
        l1l11l11llll11l111_tv_ = param.get( Variable4 (u"ࠨ࠴࠳ࠫṷ"))
        token = param.get( Variable4 (u"ࠩ࠺࠷ࠬṸ"))
        l1l1ll1ll1l11l111_tv_=Variable4 (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡺࡡࡵ࡫ࡦ࠲ࡼ࡫ࡥࡣ࠰ࡷࡺ࠴ࡶ࡬ࡢࡻࡨࡶ࠳ࡹࡷࡧࠩṹ")
        if  l1l11l11llll11l111_tv_ == Variable4 (u"ࠫ࠶࠭Ṻ"):
            l1l11l1ll1ll11l111_tv_ = l1l11l1ll1ll11l111_tv_ + Variable4 (u"ࠬࡎࡉࠨṻ")
        else:
            l1l11l1ll1ll11l111_tv_ = l1l11l1ll1ll11l111_tv_ + Variable4 (u"࠭ࡌࡐ࡙ࠪṼ")
        l111111llll11l111_tv_ = str(l1l11l1l111l11l111_tv_) + Variable4 (u"ࠧ࠰ࠩṽ") + str(l1l11l1ll1ll11l111_tv_) + Variable4 (u"ࠨࠢ࡯࡭ࡻ࡫࠽ࡵࡴࡸࡩࠥࡶࡡࡨࡧࡘࡶࡱࡃࡴࡰ࡭ࡨࡲࠥࡹࡷࡧࡗࡵࡰࡂ࠭Ṿ") + str(token)
        l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠩࡸࡶࡱ࠭ṿ"):l111111llll11l111_tv_}]
    else:
        l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠪࡱࡸ࡭ࠧẀ"):Variable4 (u"ࠫ࡜࡫ࠠࡢࡴࡨࠤ࡭ࡧࡶࡪࡰࡪࠤࡦࠦࡰࡳࡱࡥࡰࡪࡳࠧẁ")}]
    print(Variable4 (u"ࠬࡽࡥࡦࡤࡷࡺࠬẂ"),Variable4 (u"࠭ࡧࡦࡶࡆ࡬ࡦࡴ࡮ࡦ࡮࡙࡭ࡩ࡫࡯ࠨẃ"),l1lll1ll11l11l111_tv_)
    return l1lll1ll11l11l111_tv_
def test():
    out=l11l11l1l11l111_tv_(addheader=False)
    o = out[0]
    for o in out:
        url= o.get(Variable4 (u"ࠧࡶࡴ࡯ࠫẄ"))
        title= o.get(Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧẅ"))
        print title
        o[Variable4 (u"ࠩࡸࡶࡱ࠭Ẇ")]=l111l1lll11l111_tv_(o.get(Variable4 (u"ࠪࡹࡷࡲࠧẇ")))
        print o[Variable4 (u"ࠫࡺࡸ࡬ࠨẈ")]
    with open(Variable4 (u"ࠬࡲ࡯ࡰ࡭ࡱ࡭࡯࠴ࡪࡴࡱࡱࠫẉ"), Variable4 (u"࠭ࡷࠨẊ")) as l11lll1l1ll11l111_tv_:
        json.dump(out, l11lll1l1ll11l111_tv_, indent=2, sort_keys=True)
