# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re,json,time
import cookielib
import l1ll11ll1ll11l111_tv_
import urlparse
l1llll111ll11l111_tv_=Variable4 (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡪࡰࡷࡩࡽ࠴࡬ࡪ࡯ࡤ࠱ࡨ࡯ࡴࡺ࠰ࡧࡩࠬ࿨")
l1lll1ll1ll11l111_tv_=10
l1lll1l1lll11l111_tv_=Variable4 (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬ࿩")
__all__=[Variable4 (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ࿪"),Variable4 (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰ࡛࡯ࡤࡦࡱࠪ࿫")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭࿬"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠪࠫ࿭")
    return l11ll11ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=Variable4 (u"ࠫࠬ࿮")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ࿯"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = Variable4 (u"࠭ࠧ࿰").join([Variable4 (u"ࠧࠦࡵࡀࠩࡸࡁࠧ࿱")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except urllib2.HTTPError as e:
        l11ll11ll11l111_tv_ = Variable4 (u"ࠨࠩ࿲")
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content,c = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    l11llll11ll11l111_tv_ = re.compile(Variable4 (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪࡧࡳ࠳࠰࠿ࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭࿳")).findall(content)
    out=[]
    for h,i in l11llll11ll11l111_tv_:
        l1llll11lll11l111_tv_= urlparse.urljoin(l1llll111ll11l111_tv_,i)
        title=h.split(Variable4 (u"ࠪ࠳ࠬ࿴"))[-1].split(Variable4 (u"ࠫ࠳࠭࿵"))[0]
        href=urlparse.urljoin(l1llll111ll11l111_tv_,h)
        out.append({Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫ࿶"):title.strip(),Variable4 (u"࠭ࡴࡷ࡫ࡧࠫ࿷"):title.strip(),Variable4 (u"ࠧࡪ࡯ࡪࠫ࿸"):l1llll11lll11l111_tv_,Variable4 (u"ࠨࡷࡵࡰࠬ࿹"):href,Variable4 (u"ࠩࡪࡶࡴࡻࡰࠨ࿺"):Variable4 (u"ࠪࠫ࿻"),Variable4 (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫ࿼"):Variable4 (u"ࠬ࠭࿽")})
    if addheader and len(out):
        t=Variable4 (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡽࡩ࡯ࡶࡨࡼ࠮ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࿾") %time.strftime(Variable4 (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠧ࿿"))
        out.insert(0,{Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧက"):t,Variable4 (u"ࠩࡷࡺ࡮ࡪࠧခ"):Variable4 (u"ࠪࠫဂ"),Variable4 (u"ࠫ࡮ࡳࡧࠨဃ"):Variable4 (u"ࠬ࠭င"),Variable4 (u"࠭ࡵࡳ࡮ࠪစ"):l1llll111ll11l111_tv_,Variable4 (u"ࠧࡨࡴࡲࡹࡵ࠭ဆ"):Variable4 (u"ࠨࠩဇ"),Variable4 (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩဈ"):Variable4 (u"ࠪࠫဉ")})
    return out
def l111l1lll11l111_tv_(url):
    l1lll1ll11l11l111_tv_=[]
    content,c = l111111l11l111_tv_(url)
    data = l11llll11ll11l111_tv_ = re.compile(Variable4 (u"ࠫࡸࡵࡵࡳࡥࡨ࠾ࡡࡹࠪ࡜࡞ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭ࠢ࡞ࠩည")).findall(content)
    if data:
        l11llll111l11l111_tv_=data[0]+Variable4 (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠦࡵ࡙ࠩࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠦࡵࠪဋ")%(url,l1lll1l1lll11l111_tv_)
        l1lll1ll11l11l111_tv_=[{Variable4 (u"࠭ࡵࡳ࡮ࠪဌ"):l11llll111l11l111_tv_}]
    else:
        l1lll1ll11l11l111_tv_=l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠧ࡮ࡵࡪࠫဍ"):Variable4 (u"ࠨࡐࡲࡸ࡭࡯࡮ࡨࠢࡩࡳࡺࡴࡤࠨဎ")}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print Variable4 (u"ࠩ࡟ࡲࠬဏ"),l1l1l1ll11l111_tv_.get(Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩတ"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡺࡸ࡬ࠨထ")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫဒ")))
        print l1lll1ll11l11l111_tv_
