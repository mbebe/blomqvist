# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import cookielib
import threading
import re
import time
l1llll111ll11l111_tv_=Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡳࡳࡷࡺ࠮ࡵࡸࡳ࠲ࡵࡲࠧᢈ")
proxy={}
l1lll1ll1ll11l111_tv_ = 10
l11lll1llll11l111_tv_=Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡳࡣࡰ࡯ࡦ࠴ࡰࡳࡱࡻࡽ࠳ࡴࡥࡵ࠰ࡳࡰ࠴࡯࡮ࡥࡧࡻ࠲ࡵ࡮ࡰࡀࡳࡀࠫᢉ")
l1ll111l111l11l111_tv_=Variable4 (u"ࠪࠫᢊ")
def l111111l11l111_tv_(url,proxy={},timeout=l1lll1ll1ll11l111_tv_,l1llll1111l11l111_tv_=True):
    global l1ll111l111l11l111_tv_
    l1llll1ll1l11l111_tv_=[]
    if proxy:
        urllib2.install_opener(urllib2.build_opener(urllib2.ProxyHandler(proxy)))
    elif l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    req = urllib2.Request(url)
    req.add_header(Variable4 (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᢋ"), Variable4 (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠺࠹࠮࠱࠰࠵࠻࠽࠻࠮࠲࠳࠹ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫᢌ"))
    try:
        response = urllib2.urlopen(req,timeout=timeout)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"࠭ࠧᢍ")
    l1ll111l111l11l111_tv_ = Variable4 (u"ࠧࠨᢎ").join([Variable4 (u"ࠨࠧࡶࡁࠪࡹ࠻ࠨᢏ")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(url=Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡴࡴࡸࡴ࠯ࡶࡹࡴ࠳ࡶ࡬࠰ࡶࡵࡥࡳࡹ࡭ࡪࡵ࡭ࡩࠬᢐ")):
    out=[]
    content=l111111l11l111_tv_(Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡵࡵࡲࡵ࠰ࡷࡺࡵ࠴ࡰ࡭࠱ࡷࡶࡦࡴࡳ࡮࡫ࡶ࡮ࡪ࠭ᢑ"))
    ids = [(a.start(), a.end()) for a in re.finditer(Variable4 (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡧࡥࡹ࡫ࠢ࠿ࠩᢒ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l1l1lll1lll11l111_tv_ = content[ ids[i][1]:ids[i+1][0] ]
        l1l1llllllll11l111_tv_ = re.compile(Variable4 (u"ࠬࡂࡳࡱࡣࡱࡂ࠭ࡊ࡚ࡊ࠰࠭࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬᢓ")).findall(l1l1lll1lll11l111_tv_)
        if l1l1llllllll11l111_tv_:
            l1ll1111l1ll11l111_tv_=Variable4 (u"࠭ࠧᢔ")
        else:
            l1ll1111l1ll11l111_tv_=re.compile(Variable4 (u"ࠧ࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬᢕ")).findall(l1l1lll1lll11l111_tv_)
            l1ll1111l1ll11l111_tv_ = l1ll1111l1ll11l111_tv_[0]+Variable4 (u"ࠨࠢࠪᢖ") if l1ll1111l1ll11l111_tv_ else Variable4 (u"ࠩࠪᢗ")
        l1l1llllll1l11l111_tv_ = [(a.start(), a.end()) for a in re.finditer(Variable4 (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡷࡩࡲ࠳ࡴࡪ࡯ࡨࠤࡱ࡯ࡶࡦࠤࡁࠫᢘ"), l1l1lll1lll11l111_tv_)]
        l1l1llllll1l11l111_tv_.append( (-1,-1) )
        for j in range(len(l1l1llllll1l11l111_tv_[:-1])):
            item = l1l1lll1lll11l111_tv_[ l1l1llllll1l11l111_tv_[j][1]:l1l1llllll1l11l111_tv_[j+1][0] ]
            href=[]
            time = re.compile(Variable4 (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨᢙ")).findall(item)
            title= re.compile(Variable4 (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡹ࡫࡭࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࡞ࡢࡁࡣࠫࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᢚ"),re.DOTALL).findall(item)
            if not title:
                l1ll111111ll11l111_tv_ = re.compile(Variable4 (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮࠯ࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᢛ"),re.DOTALL).findall(item)
                l1ll111111ll11l111_tv_ = l1ll111111ll11l111_tv_[0] if l1ll111111ll11l111_tv_ else Variable4 (u"ࠧࠨᢜ")
                href  = re.compile(Variable4 (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᢝ")).findall(l1ll111111ll11l111_tv_)
                title = re.compile(Variable4 (u"ࠩࡁࠬ࠳࠰࠿ࠪ࠾ࠪᢞ")).findall(l1ll111111ll11l111_tv_)
            if title and time:
                t = Variable4 (u"ࠪࠩࡸࠫࡳ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࠦࡵ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᢟ")%(l1ll1111l1ll11l111_tv_,time[0],title[0].strip())
                code=Variable4 (u"ࠫࡠࡈ࡝࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡪ࡬ࡹ࡭ࡲࡦࡧࡱࡡࡑ࡯ࡶࡦ࡝࠲ࡇࡔࡒࡏࡓ࡟࡞࠳ࡇࡣࠧᢠ") if href else Variable4 (u"ࠬ࠭ᢡ")
                href = l1ll1111ll1l11l111_tv_(href[0]) if href else Variable4 (u"࠭ࠧᢢ")
                out.append({Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᢣ"):t,Variable4 (u"ࠨࡶࡹ࡭ࡩ࠭ᢤ"):Variable4 (u"ࠩࠪᢥ"),Variable4 (u"ࠪࡹࡷࡲࠧᢦ"):href,Variable4 (u"ࠫ࡬ࡸ࡯ࡶࡲࠪᢧ"):Variable4 (u"ࠬ࠭ᢨ"),Variable4 (u"࠭ࡵࡳ࡮ࡨࡴ࡬ᢩ࠭"):Variable4 (u"ࠧࠨᢪ"),Variable4 (u"ࠨࡥࡲࡨࡪ࠭᢫"):code})
    return out
def l1lll1l11l1l11l111_tv_():
    content=l111111l11l111_tv_(Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡩࡥࡥ࡯ࡳࡦࡱ࠮ࡤࡱࡰ࠳ࡵࡸ࡯ࡹࡻ࡯࡭ࡸࡺ࠯ࡧࡴࡨࡩ࠲ࡶࡲࡰࡺࡼ࠱ࡱ࡯ࡳࡵ࠯ࡳࡳࡱࡧ࡮ࡥ࠰࡫ࡸࡲࡲࠧ᢬"))
    l1lll1lll1ll11l111_tv_ = re.compile(Variable4 (u"ࠪࡀࡩ࡯ࡶࠡࡵࡷࡽࡱ࡫࠽ࠣࡹ࡬ࡨࡹ࡮࠺࡝ࡦ࠮ࠩࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࡝ࡦ࠮࠭ࠪࠨ࠾࠽࠱ࡧ࡭ࡻࡄࠧ᢭")).findall(content)
    l1lll1l1l11l11l111_tv_ = re.compile(Variable4 (u"ࠫࡁࡺࡤ࠿ࠪ࡫ࡸࡹࡶ࡛ࡴ࡟࠭࠭ࡁ࠵ࡴࡥࡀ࠿ࡸࡩࡄࠨ࡝ࡦ࠮࠭ࡁ࠵ࡴࡥࡀ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡥࡀࠪ᢮"),re.DOTALL).findall(content)
    proxies=[{x[0]: Variable4 (u"ࠬࠫࡳ࠻ࠧࡶࠫ᢯")%(x[2],x[1])} for x in l1lll1l1l11l11l111_tv_]
    return proxies
def l1ll1111ll1l11l111_tv_(url):
    l1ll111l1lll11l111_tv_=url
    return l1ll111l1lll11l111_tv_
    if url==Variable4 (u"࠭ࠧᢰ"):
        return l1ll111l1lll11l111_tv_
    if url.startswith(Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡲࡲࡶࡹ࠴ࡴࡷࡲ࠱ࡴࡱ࠭ᢱ")):
        content = l111111l11l111_tv_(url)
    else:
        content = l111111l11l111_tv_(l1llll111ll11l111_tv_+url)
    l1ll1l1111l11l111_tv_ = re.compile(Variable4 (u"ࠣ࠾࡬ࡪࡷࡧ࡭ࡦࠪ࠱࠮ࡄ࠯࠼࠰࡫ࡩࡶࡦࡳࡥ࠿ࠤᢲ"), re.DOTALL).findall(content)
    for frame in l1ll1l1111l11l111_tv_:
        src = re.compile(Variable4 (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᢳ"), re.DOTALL).findall(frame)
        if src:
            l1ll111l1lll11l111_tv_=Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡻࡶࡳࡵࡴࡨࡥࡲ࠴ࡴࡷࡲ࠱ࡴࡱ࠭ᢴ")+src[0]
    return l1ll111l1lll11l111_tv_
def l111l1lll11l111_tv_(ex_link):
    if Variable4 (u"ࠫࡸ࡫ࡳࡴ࠱ࡷࡺࡵࡲࡡࡺࡧࡵ࠲ࡵ࡮ࡰࠨᢵ") in ex_link:
        url = ex_link.replace(Variable4 (u"ࠬࡺࡶࡱࡵࡷࡶࡪࡧ࡭࠯ࡶࡹࡴ࠳ࡶ࡬ࠨᢶ"),Variable4 (u"࠭ࡳࡱࡱࡵࡸ࠳ࡺࡶࡱ࠰ࡳࡰࠬᢷ"))
    else:
        id = re.compile(Variable4 (u"ࠧ࠰ࠪ࡟ࡨ࠰࠯࠯ࠨᢸ")).findall(ex_link)
        url = Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡳࡳࡷࡺ࠮ࡵࡸࡳ࠲ࡵࡲ࠯ࡴࡧࡶࡷ࠴ࡺࡶࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࡃࡨࡵࡰࡺࡡ࡬ࡨࡂࠫࡳࠧࡱࡥ࡮ࡪࡩࡴࡠ࡫ࡧࡁࠪࡹࠦࡢࡷࡷࡳࡵࡲࡡࡺ࠿ࡷࡶࡺ࡫ࠧᢹ")%(id[0],id[0]) if id else Variable4 (u"ࠩࠪᢺ")
    l1ll11l1l11l111_tv_ = l1l11l1111l11l111_tv_(url)
    if not l1ll11l1l11l111_tv_ or Variable4 (u"ࠪࡱࡦࡺࡥࡳ࡫ࡤࡰࡤࡴࡩࡦࡦࡲࡷࡹ࡫ࡰ࡯ࡻࠪᢻ") in l1ll11l1l11l111_tv_ :
        l1ll11l1l11l111_tv_ = l1l11l1111l11l111_tv_(url,use=Variable4 (u"ࠫࡵ࡭ࡡࡵࡧ࠵ࠫᢼ"))
        if not l1ll11l1l11l111_tv_:
            l1ll11l1l11l111_tv_ = l1l11l1111l11l111_tv_(url,use=Variable4 (u"ࠬࡶࡲࡰࡺࡼࠫᢽ"))
    if not isinstance(l1ll11l1l11l111_tv_,list) and Variable4 (u"࠭࡭ࡢࡰ࡬ࡪࡪࡹࡴ࠯࡯࠶ࡹ࠽࠭ᢾ") in l1ll11l1l11l111_tv_:
        l1ll11l1l11l111_tv_ = l1ll1111l11l11l111_tv_(l1ll11l1l11l111_tv_.strip())
    if not l1ll11l1l11l111_tv_:
        l1ll11l1l11l111_tv_=[{Variable4 (u"ࠧ࡮ࡵࡪࠫᢿ"):Variable4 (u"ࠨࡏࡤࡸࡪࡸࡩࡢॄࠣ࡮ࡪࡹࡴࠡࡰ࡬ࡩࡩࡵࡳࡵछࡳࡲࡾ࠭ᣀ")}]
    return l1ll11l1l11l111_tv_
def l1ll11111l1l11l111_tv_(url):
    try:
        l1l1llll1lll11l111_tv_ =Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡥࡶࡦࡳ࡫ࡢ࠰ࡳࡶࡴࡾࡹ࠯ࡰࡨࡸ࠳ࡶ࡬࠰࡫ࡱࡨࡪࡾ࠮ࡱࡪࡳࡃࡶࡃࠥࡴࠨ࡫ࡰࡂ࠶ࠧᣁ")%urllib.quote_plus(url)
        headers={Variable4 (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᣂ"): Variable4 (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡪࡰ࠹࠸ࡀࠦࡸ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠸࠴࠲࠵࠴࠳࠲࠸࠶࠲࠶࠶࠰ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨᣃ"),Variable4 (u"࡛ࠬࡰࡨࡴࡤࡨࡪ࠳ࡉ࡯ࡵࡨࡧࡺࡸࡥ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡵࠪᣄ"):1,
        Variable4 (u"࠭ࡁࡤࡥࡨࡴࡹ࠭ᣅ"):Variable4 (u"ࠧࡵࡧࡻࡸ࠴࡮ࡴ࡮࡮࠯ࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࡫ࡸࡲࡲࠫࡹ࡯࡯࠰ࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻࡱࡱࡁࡱ࠾࠲࠱࠽࠱࡯࡭ࡢࡩࡨ࠳ࡼ࡫ࡢࡱ࠮࡬ࡱࡦ࡭ࡥ࠰ࡣࡳࡲ࡬࠲ࠪ࠰ࠬ࠾ࡵࡂ࠶࠮࠹ࠩᣆ")}
        req = urllib2.Request(l1l1llll1lll11l111_tv_,None,headers)
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_=response.read()
        response.close()
        print Variable4 (u"ࠨࡉࡄࡘࡊ࠸ࠠࡪࡰ࡙ࠣࡘࡋࠧᣇ")
    except:
        print Variable4 (u"ࠩࡊࡅ࡙ࡋࠠࡪࡰ࡙ࠣࡘࡋࠠࡆࡔࡕࡓࡗ࠭ᣈ")
        l11ll11ll11l111_tv_=Variable4 (u"ࠪࠫᣉ")
    return l11ll11ll11l111_tv_
def l1l11l1111l11l111_tv_(url=Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡶ࡯ࡳࡶ࠱ࡸࡻࡶ࠮ࡱ࡮࠲ࡷࡪࡹࡳ࠰ࡶࡹࡴࡱࡧࡹࡦࡴ࠱ࡴ࡭ࡶ࠿ࡤࡱࡳࡽࡤ࡯ࡤ࠾࠵࠸࠼࠷࠾࠲࠸࠲ࠩࡳࡧࡰࡥࡤࡶࡢ࡭ࡩࡃ࠳࠶࠺࠵࠼࠷࠽࠰ࠧࡣࡸࡸࡴࡶ࡬ࡢࡻࡀࡸࡷࡻࡥࠨᣊ"),use=Variable4 (u"ࠬ࠭ᣋ")):
    l1ll111l1lll11l111_tv_=Variable4 (u"࠭ࠧᣌ")
    if not url: return l1ll111l1lll11l111_tv_
    if use==Variable4 (u"ࠧࡱࡩࡤ࡫ࡪ࠭ᣍ"):
        data = l111111l11l111_tv_(l11lll1llll11l111_tv_+urllib.quote_plus(url)+Variable4 (u"ࠨࠨ࡫ࡰࡂ࠸ࡡ࠶ࠩᣎ"))
        l1ll111l1lll11l111_tv_ = l1ll1111l11l11l111_tv_(_1ll11111lll11l111_tv_(data))
    elif use==Variable4 (u"ࠩࡳ࡫ࡦࡺࡥ࠳ࠩᣏ"):
        data = l1ll11111l1l11l111_tv_(url)
        l1ll111l1lll11l111_tv_ = l1ll1111l11l11l111_tv_(_1ll11111lll11l111_tv_(data))
    elif use==Variable4 (u"ࠪࡴࡷࡵࡸࡺࠩᣐ"):
        proxies = l1lll1l11l1l11l111_tv_()
        l1l111lllll11l111_tv_ = list()
        l1ll111l1ll11l111_tv_ = [[] for x in proxies]
        for i,proxy in enumerate(proxies):
            thread = threading.Thread(name=Variable4 (u"࡙ࠫ࡮ࡲࡦࡣࡧࠩࡩ࠭ᣑ")%i, target = l1l1lll111l11l111_tv_, args=[url,proxy,l1ll111l1ll11l111_tv_,i])
            l1l111lllll11l111_tv_.append(thread)
            thread.start()
        while any([i.isAlive() for i in l1l111lllll11l111_tv_]) and len(l1ll111l1lll11l111_tv_)==0:
            for l in l1ll111l1ll11l111_tv_:
                l = l1ll111l1ll11l111_tv_[3]
                if isinstance(l,list):
                    l1ll111l1lll11l111_tv_ = l
                    break
            time.sleep(0.1)
        del l1l111lllll11l111_tv_[:]
    else:
        data = l111111l11l111_tv_(url)
        l1ll111l1lll11l111_tv_ = _1ll11111lll11l111_tv_(data)
    return l1ll111l1lll11l111_tv_
def _1ll11111lll11l111_tv_(data):
    l1ll111l1lll11l111_tv_ = re.compile(Variable4 (u"ࠬ࠷࠺ࡼࡵࡵࡧࡠࡀ࡜ࡴ࡟࠮࡟ࡡ࠭ࠢ࡞ࠪ࠱࠯ࡄ࠯࡛࡝ࠩࠥࡡࠬᣒ"), re.DOTALL).findall(data)
    if not l1ll111l1lll11l111_tv_:
        l1ll111l1lll11l111_tv_ = re.compile(Variable4 (u"ࠨ࠰࠻ࡽࡶࡶࡨࡀ࡜ࠨࠪ࠱࠯ࡄ࠯࡜ࠨࠤᣓ"), re.DOTALL).findall(data)
    l1ll111l1lll11l111_tv_ = l1ll111l1lll11l111_tv_[0] if l1ll111l1lll11l111_tv_ else Variable4 (u"ࠧࠨᣔ")
    return l1ll111l1lll11l111_tv_
def l1l1lll111l11l111_tv_(ex_link ,proxy, l1ll111l1ll11l111_tv_, index):
    data = l111111l11l111_tv_(ex_link,proxy,timeout=10)
    l11ll11ll11l111_tv_ = l1ll1111l11l11l111_tv_(_1ll11111lll11l111_tv_(data))
    l1ll111l1ll11l111_tv_[index]= l11ll11ll11l111_tv_ if not Variable4 (u"ࠨ࡯ࡤࡸࡪࡸࡩࡢ࡮ࡢࡲ࡮࡫ࡤࡰࡵࡷࡩࡵࡴࡹࠨᣕ") in l11ll11ll11l111_tv_ else Variable4 (u"ࠩࠪᣖ")
def l1ll1111l11l11l111_tv_(url):
    out=url
    if url and url.endswith(Variable4 (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩᣗ")):
        l1l1lllll11l11l111_tv_ = re.search(Variable4 (u"ࠫ࠴࠮࡜ࡸ࠭ࠬࡠ࠳ࡳ࠳ࡶ࠺ࠪᣘ"),url)
        l1l1lllll11l11l111_tv_ = l1l1lllll11l11l111_tv_.group(1) if l1l1lllll11l11l111_tv_ else Variable4 (u"ࠬࡳࡡ࡯࡫ࡩࡩࡸࡺࠧᣙ")
        content = l111111l11l111_tv_(url)
        matches=re.compile(Variable4 (u"࠭ࡒࡆࡕࡒࡐ࡚࡚ࡉࡐࡐࡀࠬ࠳࠰࠿ࠪ࡞ࡵࡠࡳ࠮ࡑࡶࡣ࡯࡭ࡹࡿࡌࡦࡸࡨࡰࡸࡢࠨ࠯ࠬ࡟࠭࠴ࡳࡡ࡯࡫ࡩࡩࡸࡺ࡜ࠩࡨࡲࡶࡲࡧࡴ࠾࡯࠶ࡹ࠽࠳ࡡࡢࡲ࡯ࡠ࠮࠯ࠧᣚ")).findall(content)
        if matches:
            out=[{Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᣛ"):Variable4 (u"ࠨࡣࡸࡸࡴ࠭ᣜ"),Variable4 (u"ࠩࡸࡶࡱ࠭ᣝ"):url}]
            for title, part in matches:
                l1l1l1ll11l111_tv_={Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᣞ"):title,Variable4 (u"ࠫࡺࡸ࡬ࠨᣟ"):url.replace(l1l1lllll11l11l111_tv_,part)}
                out.append(l1l1l1ll11l111_tv_)
    return out
def l1l1lllll1ll11l111_tv_():
    content = l111111l11l111_tv_(Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡰࡰࡴࡷ࠲ࡹࡼࡰ࠯ࡲ࡯࠳ࡷ࡯࡯࠰࠴࠸࠼࠺࠷࠷࠸࠳࠲ࡴࡷࡵࡧࡳࡣࡰࠫᣠ"))
    l1ll111l11ll11l111_tv_ = re.compile(Variable4 (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧ࡫ࡰࡨ࠯࡬ࡸࡪࡳࠨ࠯ࠬࡂ࠭ࡡࡴ࡜ࡵ࡞ࡷࡠࡹࡂ࠯ࡴࡲࡤࡲࡃ࠭ᣡ"),re.DOTALL).findall(content)
    out=[]
    for item in l1ll111l11ll11l111_tv_:
        l1ll111ll11l11l111_tv_=re.compile(Variable4 (u"ࠧࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᣢ")).findall(item)
        l1ll1111llll11l111_tv_=re.compile(Variable4 (u"ࠨࡦࡤࡸࡦ࠳ࡲࡦࡦ࡬ࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᣣ")).findall(item)
        times=re.compile(Variable4 (u"ࠩࠥࡸ࡮ࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᣤ")).findall(item)
        title=re.compile(Variable4 (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᣥ")).findall(item)
        category=re.compile(Variable4 (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡧࡴࡦࡩࡲࡶࡾࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᣦ")).findall(item)
        l1ll111l1l1l11l111_tv_=re.compile(Variable4 (u"ࠬࡪࡡࡵࡣ࠰ࡦࡷࡵࡡࡥࡥࡤࡷࡹ࠳ࡳࡵࡣࡵࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᣧ")).findall(item)
        l1ll111l1l1l11l111_tv_ = float(l1ll111l1l1l11l111_tv_[0])/1000 if l1ll111l1l1l11l111_tv_ else 0
        l1l1llll1l1l11l111_tv_=re.compile(Variable4 (u"࠭ࡤࡢࡶࡤ࠱ࡧࡸ࡯ࡢࡦࡦࡥࡸࡺ࠭ࡦࡰࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᣨ")).findall(item)
        l1l1llll1l1l11l111_tv_ = float(l1l1llll1l1l11l111_tv_[0])/1000 if l1l1llll1l1l11l111_tv_ else 0
        if item.find(Variable4 (u"ࠧࡷ࡫ࡧࡩࡴ࠳ࡩࡤࡱࡱࠫᣩ")) and l1ll1111llll11l111_tv_ and times and title and category:
            if time.localtime().tm_yday==time.localtime(l1ll111l1l1l11l111_tv_).tm_yday:
                print Variable4 (u"ࠨࡖࡒࡈࡆ࡟ࠧᣪ")
                times = [time.strftime(Variable4 (u"ࠤࠨࡥࠥࠫࡈ࠻ࠧࡐࠦᣫ"), time.localtime(l1ll111l1l1l11l111_tv_))]
            else:
                times = [time.strftime(Variable4 (u"ࠥࠩࡦࠦࠥࡉ࠼ࠨࡑࠧᣬ"), time.localtime(l1ll111l1l1l11l111_tv_))]
            id = re.compile(Variable4 (u"ࠫ࠴࠮࡜ࡥ࠭ࠬ࠳ࠬᣭ")).findall(l1ll1111llll11l111_tv_[0]) if l1ll1111llll11l111_tv_ else Variable4 (u"ࠬ࠭ᣮ")
            href = Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴࡷࡲࡶࡸࡷ࡫ࡡ࡮࠰ࡷࡺࡵ࠴ࡰ࡭࠱ࡶࡩࡸࡹ࠯ࡵࡸࡳࡰࡦࡿࡥࡳ࠰ࡳ࡬ࡵࡅ࡯ࡣ࡬ࡨࡧࡹࡥࡩࡥ࠿ࠪᣯ")+id[0] if id else Variable4 (u"ࠧࠨᣰ")
            code=Variable4 (u"ࠨ࡝ࡅࡡࡠࡉࡏࡍࡑࡕࠤ࡬ࡸࡥࡦࡰࡠࡺ࡮ࡪࡥࡰ࡝࠲ࡇࡔࡒࡏࡓ࡟࡞࠳ࡇࡣࠧᣱ") if href else Variable4 (u"ࠩࠪᣲ")
            if time.time() <= l1l1llll1l1l11l111_tv_:
                l1ll111l1l1l11l111_tv_=l1ll111l1l1l11l111_tv_/10
                code=Variable4 (u"ࠪ࡟ࡇࡣ࡛ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸ࡬ࡸࡥࡦࡰࡠࡐ࡮ࡼࡥ࡜࠱ࡆࡓࡑࡕࡒ࡞࡝࠲ࡆࡢ࠭ᣳ")
                times = [times[0].split(Variable4 (u"ࠫࠥ࠭ᣴ"))[-1]]
            t = Variable4 (u"ࠬࠫࡳ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࠦࡵ࠯ࠤࠪࡹ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨᣵ")%(times[0],title[0].strip(),category[0].strip())
            print times[0]
            out.append({Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬ᣶"):t,Variable4 (u"ࠧࡵࡸ࡬ࡨࠬ᣷"):Variable4 (u"ࠨࠩ᣸"),Variable4 (u"ࠩ࡬ࡱ࡬࠭᣹"):Variable4 (u"ࠪࠫ᣺"),Variable4 (u"ࠫࡺࡸ࡬ࠨ᣻"):href,Variable4 (u"ࠬ࡭ࡲࡰࡷࡳࠫ᣼"):Variable4 (u"࠭ࠧ᣽"),Variable4 (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧ᣾"):Variable4 (u"ࠨࠩ᣿"),Variable4 (u"ࠩࡦࡳࡩ࡫ࠧᤀ"):code,Variable4 (u"ࠪࡸࡹ࡯࡭ࡦࠩᤁ"):l1ll111l1l1l11l111_tv_})
    out = sorted(out, key=lambda x: x[Variable4 (u"ࠫࡹࡺࡩ࡮ࡧࠪᤂ")])
    return out
def test():
    out=l1ll1111111l11l111_tv_()
    out=l1l1lllll1ll11l111_tv_()
