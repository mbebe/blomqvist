# coding: UTF-8
from __future__ import absolute_import
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
Variable4 (u"ࠧࠨࠢࡖࡶ࡬ࡰ࡮ࡺࡩࡦࡵࠣࡪࡴࡸࠠࡸࡴ࡬ࡸ࡮ࡴࡧࠡࡥࡲࡨࡪࠦࡴࡩࡣࡷࠤࡷࡻ࡮ࡴࠢࡲࡲࠥࡖࡹࡵࡪࡲࡲࠥ࠸ࠠࡢࡰࡧࠤ࠸ࠨࠢࠣᘈ")
import functools
import itertools
import operator
import sys
import types
__author__ = Variable4 (u"ࠨࡂࡦࡰ࡭ࡥࡲ࡯࡮ࠡࡒࡨࡸࡪࡸࡳࡰࡰࠣࡀࡧ࡫࡮࡫ࡣࡰ࡭ࡳࡆࡰࡺࡶ࡫ࡳࡳ࠴࡯ࡳࡩࡁࠦᘉ")
__version__ = Variable4 (u"ࠢ࠲࠰࠴࠴࠳࠶ࠢᘊ")
PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3
PY34 = sys.version_info[0:2] >= (3, 4)
if PY3:
    string_types = str,
    integer_types = int,
    class_types = type,
    text_type = str
    binary_type = bytes
    MAXSIZE = sys.maxsize
else:
    string_types = basestring,
    integer_types = (int, long)
    class_types = (type, types.ClassType)
    text_type = unicode
    binary_type = str
    if sys.platform.startswith(Variable4 (u"ࠣ࡬ࡤࡺࡦࠨᘋ")):
        MAXSIZE = int((1 << 31) - 1)
    else:
        class X(object):
            def __len__(self):
                return 1 << 31
        try:
            len(X())
        except OverflowError:
            MAXSIZE = int((1 << 31) - 1)
        else:
            MAXSIZE = int((1 << 63) - 1)
        del X
def _add_doc(func, doc):
    Variable4 (u"ࠤࠥࠦࡆࡪࡤࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡࡶࡲࠤࡦࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮࠯ࠤࠥࠦᘌ")
    func.__doc__ = doc
def _import_module(name):
    Variable4 (u"ࠥࠦࠧࡏ࡭ࡱࡱࡵࡸࠥࡳ࡯ࡥࡷ࡯ࡩ࠱ࠦࡲࡦࡶࡸࡶࡳ࡯࡮ࡨࠢࡷ࡬ࡪࠦ࡭ࡰࡦࡸࡰࡪࠦࡡࡧࡶࡨࡶࠥࡺࡨࡦࠢ࡯ࡥࡸࡺࠠࡥࡱࡷ࠲ࠧࠨࠢᘍ")
    __import__(name)
    return sys.modules[name]
class _LazyDescr(object):
    def __init__(self, name):
        self.name = name
    def __get__(self, obj, tp):
        result = self._resolve()
        setattr(obj, self.name, result)
        try:
            delattr(obj.__class__, self.name)
        except AttributeError:
            pass
        return result
class MovedModule(_LazyDescr):
    def __init__(self, name, old, new=None):
        super(MovedModule, self).__init__(name)
        if PY3:
            if new is None:
                new = name
            self.mod = new
        else:
            self.mod = old
    def _resolve(self):
        return _import_module(self.mod)
    def __getattr__(self, attr):
        _module = self._resolve()
        value = getattr(_module, attr)
        setattr(self, attr, value)
        return value
class _LazyModule(types.ModuleType):
    def __init__(self, name):
        super(_LazyModule, self).__init__(name)
        self.__doc__ = self.__class__.__doc__
    def __dir__(self):
        attrs = [Variable4 (u"ࠦࡤࡥࡤࡰࡥࡢࡣࠧᘎ"), Variable4 (u"ࠧࡥ࡟࡯ࡣࡰࡩࡤࡥࠢᘏ")]
        attrs += [attr.name for attr in self._moved_attributes]
        return attrs
    _moved_attributes = []
class MovedAttribute(_LazyDescr):
    def __init__(self, name, old_mod, new_mod, old_attr=None, new_attr=None):
        super(MovedAttribute, self).__init__(name)
        if PY3:
            if new_mod is None:
                new_mod = name
            self.mod = new_mod
            if new_attr is None:
                if old_attr is None:
                    new_attr = name
                else:
                    new_attr = old_attr
            self.attr = new_attr
        else:
            self.mod = old_mod
            if old_attr is None:
                old_attr = name
            self.attr = old_attr
    def _resolve(self):
        module = _import_module(self.mod)
        return getattr(module, self.attr)
class _SixMetaPathImporter(object):
    Variable4 (u"ࠨࠢࠣࠌࠣࠤࠥࠦࡁࠡ࡯ࡨࡸࡦࠦࡰࡢࡶ࡫ࠤ࡮ࡳࡰࡰࡴࡷࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡵࡲࡵࠢࡶ࡭ࡽ࠴࡭ࡰࡸࡨࡷࠥࡧ࡮ࡥࠢ࡬ࡸࡸࠦࡳࡶࡤࡰࡳࡩࡻ࡬ࡦࡵ࠱ࠎࠏࠦࠠࠡࠢࡗ࡬࡮ࡹࠠࡤ࡮ࡤࡷࡸࠦࡩ࡮ࡲ࡯ࡩࡲ࡫࡮ࡵࡵࠣࡥࠥࡖࡅࡑ࠵࠳࠶ࠥ࡬ࡩ࡯ࡦࡨࡶࠥࡧ࡮ࡥࠢ࡯ࡳࡦࡪࡥࡳ࠰ࠣࡍࡹࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡦࡳࡲࡶࡡࡵ࡫ࡥࡰࡪࠐࠠࠡࠢࠣࡻ࡮ࡺࡨࠡࡒࡼࡸ࡭ࡵ࡮ࠡ࠴࠱࠹ࠥࡧ࡮ࡥࠢࡤࡰࡱࠦࡥࡹ࡫ࡶࡸ࡮ࡴࡧࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣࡳ࡫ࠦࡐࡺࡶ࡫ࡳࡳ࠹ࠊࠡࠢࠣࠤࠧࠨࠢᘐ")
    def __init__(self, six_module_name):
        self.name = six_module_name
        self.known_modules = {}
    def _add_module(self, mod, *fullnames):
        for fullname in fullnames:
            self.known_modules[self.name + Variable4 (u"ࠢ࠯ࠤᘑ") + fullname] = mod
    def _get_module(self, fullname):
        return self.known_modules[self.name + Variable4 (u"ࠣ࠰ࠥᘒ") + fullname]
    def find_module(self, fullname, path=None):
        if fullname in self.known_modules:
            return self
        return None
    def __get_module(self, fullname):
        try:
            return self.known_modules[fullname]
        except KeyError:
            raise ImportError(Variable4 (u"ࠤࡗ࡬࡮ࡹࠠ࡭ࡱࡤࡨࡪࡸࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢ࡮ࡲࡴࡽࠠ࡮ࡱࡧࡹࡱ࡫ࠠࠣᘓ") + fullname)
    def load_module(self, fullname):
        try:
            return sys.modules[fullname]
        except KeyError:
            pass
        mod = self.__get_module(fullname)
        if isinstance(mod, MovedModule):
            mod = mod._resolve()
        else:
            mod.__loader__ = self
        sys.modules[fullname] = mod
        return mod
    def is_package(self, fullname):
        Variable4 (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡓࡧࡷࡹࡷࡴࠠࡵࡴࡸࡩ࠱ࠦࡩࡧࠢࡷ࡬ࡪࠦ࡮ࡢ࡯ࡨࡨࠥࡳ࡯ࡥࡷ࡯ࡩࠥ࡯ࡳࠡࡣࠣࡴࡦࡩ࡫ࡢࡩࡨ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡘࡧࠣࡲࡪ࡫ࡤࠡࡶ࡫࡭ࡸࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡴࡰࠢࡪࡩࡹࠦࡣࡰࡴࡵࡩࡨࡺࠠࡴࡲࡨࡧࠥࡵࡢ࡫ࡧࡦࡸࡸࠦࡷࡪࡶ࡫ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡖࡹࡵࡪࡲࡲࠥ࠹࠮࠵ࠢࠫࡷࡪ࡫ࠠࡑࡇࡓ࠸࠺࠷ࠩࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧᘔ")
        return hasattr(self.__get_module(fullname), Variable4 (u"ࠦࡤࡥࡰࡢࡶ࡫ࡣࡤࠨᘕ"))
    def get_code(self, fullname):
        Variable4 (u"ࠧࠨࠢࡓࡧࡷࡹࡷࡴࠠࡏࡱࡱࡩࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡓࡧࡴࡹ࡮ࡸࡥࡥ࠮ࠣ࡭࡫ࠦࡩࡴࡡࡳࡥࡨࡱࡡࡨࡧࠣ࡭ࡸࠦࡩ࡮ࡲ࡯ࡩࡲ࡫࡮ࡵࡧࡧࠦࠧࠨᘖ")
        self.__get_module(fullname)
        return None
    get_source = get_code
_importer = _SixMetaPathImporter(__name__)
class _MovedItems(_LazyModule):
    Variable4 (u"ࠨࠢࠣࡎࡤࡾࡾࠦ࡬ࡰࡣࡧ࡭ࡳ࡭ࠠࡰࡨࠣࡱࡴࡼࡥࡥࠢࡲࡦ࡯࡫ࡣࡵࡵࠥࠦࠧᘗ")
    __path__ = []
_moved_attributes = [
    MovedAttribute(Variable4 (u"ࠢࡤࡕࡷࡶ࡮ࡴࡧࡊࡑࠥᘘ"), Variable4 (u"ࠣࡥࡖࡸࡷ࡯࡮ࡨࡋࡒࠦᘙ"), Variable4 (u"ࠤ࡬ࡳࠧᘚ"), Variable4 (u"ࠥࡗࡹࡸࡩ࡯ࡩࡌࡓࠧᘛ")),
    MovedAttribute(Variable4 (u"ࠦ࡫࡯࡬ࡵࡧࡵࠦᘜ"), Variable4 (u"ࠧ࡯ࡴࡦࡴࡷࡳࡴࡲࡳࠣᘝ"), Variable4 (u"ࠨࡢࡶ࡫࡯ࡸ࡮ࡴࡳࠣᘞ"), Variable4 (u"ࠢࡪࡨ࡬ࡰࡹ࡫ࡲࠣᘟ"), Variable4 (u"ࠣࡨ࡬ࡰࡹ࡫ࡲࠣᘠ")),
    MovedAttribute(Variable4 (u"ࠤࡩ࡭ࡱࡺࡥࡳࡨࡤࡰࡸ࡫ࠢᘡ"), Variable4 (u"ࠥ࡭ࡹ࡫ࡲࡵࡱࡲࡰࡸࠨᘢ"), Variable4 (u"ࠦ࡮ࡺࡥࡳࡶࡲࡳࡱࡹࠢᘣ"), Variable4 (u"ࠧ࡯ࡦࡪ࡮ࡷࡩࡷ࡬ࡡ࡭ࡵࡨࠦᘤ"), Variable4 (u"ࠨࡦࡪ࡮ࡷࡩࡷ࡬ࡡ࡭ࡵࡨࠦᘥ")),
    MovedAttribute(Variable4 (u"ࠢࡪࡰࡳࡹࡹࠨᘦ"), Variable4 (u"ࠣࡡࡢࡦࡺ࡯࡬ࡵ࡫ࡱࡣࡤࠨᘧ"), Variable4 (u"ࠤࡥࡹ࡮ࡲࡴࡪࡰࡶࠦᘨ"), Variable4 (u"ࠥࡶࡦࡽ࡟ࡪࡰࡳࡹࡹࠨᘩ"), Variable4 (u"ࠦ࡮ࡴࡰࡶࡶࠥᘪ")),
    MovedAttribute(Variable4 (u"ࠧ࡯࡮ࡵࡧࡵࡲࠧᘫ"), Variable4 (u"ࠨ࡟ࡠࡤࡸ࡭ࡱࡺࡩ࡯ࡡࡢࠦᘬ"), Variable4 (u"ࠢࡴࡻࡶࠦᘭ")),
    MovedAttribute(Variable4 (u"ࠣ࡯ࡤࡴࠧᘮ"), Variable4 (u"ࠤ࡬ࡸࡪࡸࡴࡰࡱ࡯ࡷࠧᘯ"), Variable4 (u"ࠥࡦࡺ࡯࡬ࡵ࡫ࡱࡷࠧᘰ"), Variable4 (u"ࠦ࡮ࡳࡡࡱࠤᘱ"), Variable4 (u"ࠧࡳࡡࡱࠤᘲ")),
    MovedAttribute(Variable4 (u"ࠨࡧࡦࡶࡦࡻࡩࠨᘳ"), Variable4 (u"ࠢࡰࡵࠥᘴ"), Variable4 (u"ࠣࡱࡶࠦᘵ"), Variable4 (u"ࠤࡪࡩࡹࡩࡷࡥࡷࠥᘶ"), Variable4 (u"ࠥ࡫ࡪࡺࡣࡸࡦࠥᘷ")),
    MovedAttribute(Variable4 (u"ࠦ࡬࡫ࡴࡤࡹࡧࡦࠧᘸ"), Variable4 (u"ࠧࡵࡳࠣᘹ"), Variable4 (u"ࠨ࡯ࡴࠤᘺ"), Variable4 (u"ࠢࡨࡧࡷࡧࡼࡪࠢᘻ"), Variable4 (u"ࠣࡩࡨࡸࡨࡽࡤࡣࠤᘼ")),
    MovedAttribute(Variable4 (u"ࠤࡵࡥࡳ࡭ࡥࠣᘽ"), Variable4 (u"ࠥࡣࡤࡨࡵࡪ࡮ࡷ࡭ࡳࡥ࡟ࠣᘾ"), Variable4 (u"ࠦࡧࡻࡩ࡭ࡶ࡬ࡲࡸࠨᘿ"), Variable4 (u"ࠧࡾࡲࡢࡰࡪࡩࠧᙀ"), Variable4 (u"ࠨࡲࡢࡰࡪࡩࠧᙁ")),
    MovedAttribute(Variable4 (u"ࠢࡳࡧ࡯ࡳࡦࡪ࡟࡮ࡱࡧࡹࡱ࡫ࠢᙂ"), Variable4 (u"ࠣࡡࡢࡦࡺ࡯࡬ࡵ࡫ࡱࡣࡤࠨᙃ"), Variable4 (u"ࠤ࡬ࡱࡵࡵࡲࡵ࡮࡬ࡦࠧᙄ") if PY34 else Variable4 (u"ࠥ࡭ࡲࡶࠢᙅ"), Variable4 (u"ࠦࡷ࡫࡬ࡰࡣࡧࠦᙆ")),
    MovedAttribute(Variable4 (u"ࠧࡸࡥࡥࡷࡦࡩࠧᙇ"), Variable4 (u"ࠨ࡟ࡠࡤࡸ࡭ࡱࡺࡩ࡯ࡡࡢࠦᙈ"), Variable4 (u"ࠢࡧࡷࡱࡧࡹࡵ࡯࡭ࡵࠥᙉ")),
    MovedAttribute(Variable4 (u"ࠣࡵ࡫ࡰࡪࡾ࡟ࡲࡷࡲࡸࡪࠨᙊ"), Variable4 (u"ࠤࡳ࡭ࡵ࡫ࡳࠣᙋ"), Variable4 (u"ࠥࡷ࡭ࡲࡥࡹࠤᙌ"), Variable4 (u"ࠦࡶࡻ࡯ࡵࡧࠥᙍ")),
    MovedAttribute(Variable4 (u"࡙ࠧࡴࡳ࡫ࡱ࡫ࡎࡕࠢᙎ"), Variable4 (u"ࠨࡓࡵࡴ࡬ࡲ࡬ࡏࡏࠣᙏ"), Variable4 (u"ࠢࡪࡱࠥᙐ")),
    MovedAttribute(Variable4 (u"ࠣࡗࡶࡩࡷࡊࡩࡤࡶࠥᙑ"), Variable4 (u"ࠤࡘࡷࡪࡸࡄࡪࡥࡷࠦᙒ"), Variable4 (u"ࠥࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴࡳࠣᙓ")),
    MovedAttribute(Variable4 (u"࡚ࠦࡹࡥࡳࡎ࡬ࡷࡹࠨᙔ"), Variable4 (u"࡛ࠧࡳࡦࡴࡏ࡭ࡸࡺࠢᙕ"), Variable4 (u"ࠨࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰࡶࠦᙖ")),
    MovedAttribute(Variable4 (u"ࠢࡖࡵࡨࡶࡘࡺࡲࡪࡰࡪࠦᙗ"), Variable4 (u"ࠣࡗࡶࡩࡷ࡙ࡴࡳ࡫ࡱ࡫ࠧᙘ"), Variable4 (u"ࠤࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳࡹࠢᙙ")),
    MovedAttribute(Variable4 (u"ࠥࡼࡷࡧ࡮ࡨࡧࠥᙚ"), Variable4 (u"ࠦࡤࡥࡢࡶ࡫࡯ࡸ࡮ࡴ࡟ࡠࠤᙛ"), Variable4 (u"ࠧࡨࡵࡪ࡮ࡷ࡭ࡳࡹࠢᙜ"), Variable4 (u"ࠨࡸࡳࡣࡱ࡫ࡪࠨᙝ"), Variable4 (u"ࠢࡳࡣࡱ࡫ࡪࠨᙞ")),
    MovedAttribute(Variable4 (u"ࠣࡼ࡬ࡴࠧᙟ"), Variable4 (u"ࠤ࡬ࡸࡪࡸࡴࡰࡱ࡯ࡷࠧᙠ"), Variable4 (u"ࠥࡦࡺ࡯࡬ࡵ࡫ࡱࡷࠧᙡ"), Variable4 (u"ࠦ࡮ࢀࡩࡱࠤᙢ"), Variable4 (u"ࠧࢀࡩࡱࠤᙣ")),
    MovedAttribute(Variable4 (u"ࠨࡺࡪࡲࡢࡰࡴࡴࡧࡦࡵࡷࠦᙤ"), Variable4 (u"ࠢࡪࡶࡨࡶࡹࡵ࡯࡭ࡵࠥᙥ"), Variable4 (u"ࠣ࡫ࡷࡩࡷࡺ࡯ࡰ࡮ࡶࠦᙦ"), Variable4 (u"ࠤ࡬ࡾ࡮ࡶ࡟࡭ࡱࡱ࡫ࡪࡹࡴࠣᙧ"), Variable4 (u"ࠥࡾ࡮ࡶ࡟࡭ࡱࡱ࡫ࡪࡹࡴࠣᙨ")),
    MovedModule(Variable4 (u"ࠦࡧࡻࡩ࡭ࡶ࡬ࡲࡸࠨᙩ"), Variable4 (u"ࠧࡥ࡟ࡣࡷ࡬ࡰࡹ࡯࡮ࡠࡡࠥᙪ")),
    MovedModule(Variable4 (u"ࠨࡣࡰࡰࡩ࡭࡬ࡶࡡࡳࡵࡨࡶࠧᙫ"), Variable4 (u"ࠢࡄࡱࡱࡪ࡮࡭ࡐࡢࡴࡶࡩࡷࠨᙬ")),
    MovedModule(Variable4 (u"ࠣࡥࡲࡴࡾࡸࡥࡨࠤ᙭"), Variable4 (u"ࠤࡦࡳࡵࡿ࡟ࡳࡧࡪࠦ᙮")),
    MovedModule(Variable4 (u"ࠥࡨࡧࡳ࡟ࡨࡰࡸࠦᙯ"), Variable4 (u"ࠦ࡬ࡪࡢ࡮ࠤᙰ"), Variable4 (u"ࠧࡪࡢ࡮࠰ࡪࡲࡺࠨᙱ")),
    MovedModule(Variable4 (u"ࠨ࡟ࡥࡷࡰࡱࡾࡥࡴࡩࡴࡨࡥࡩࠨᙲ"), Variable4 (u"ࠢࡥࡷࡰࡱࡾࡥࡴࡩࡴࡨࡥࡩࠨᙳ"), Variable4 (u"ࠣࡡࡧࡹࡲࡳࡹࡠࡶ࡫ࡶࡪࡧࡤࠣᙴ")),
    MovedModule(Variable4 (u"ࠤ࡫ࡸࡹࡶ࡟ࡤࡱࡲ࡯࡮࡫ࡪࡢࡴࠥᙵ"), Variable4 (u"ࠥࡧࡴࡵ࡫ࡪࡧ࡯࡭ࡧࠨᙶ"), Variable4 (u"ࠦ࡭ࡺࡴࡱ࠰ࡦࡳࡴࡱࡩࡦ࡬ࡤࡶࠧᙷ")),
    MovedModule(Variable4 (u"ࠧ࡮ࡴࡵࡲࡢࡧࡴࡵ࡫ࡪࡧࡶࠦᙸ"), Variable4 (u"ࠨࡃࡰࡱ࡮࡭ࡪࠨᙹ"), Variable4 (u"ࠢࡩࡶࡷࡴ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨᙺ")),
    MovedModule(Variable4 (u"ࠣࡪࡷࡱࡱࡥࡥ࡯ࡶ࡬ࡸ࡮࡫ࡳࠣᙻ"), Variable4 (u"ࠤ࡫ࡸࡲࡲࡥ࡯ࡶ࡬ࡸࡾࡪࡥࡧࡵࠥᙼ"), Variable4 (u"ࠥ࡬ࡹࡳ࡬࠯ࡧࡱࡸ࡮ࡺࡩࡦࡵࠥᙽ")),
    MovedModule(Variable4 (u"ࠦ࡭ࡺ࡭࡭ࡡࡳࡥࡷࡹࡥࡳࠤᙾ"), Variable4 (u"ࠧࡎࡔࡎࡎࡓࡥࡷࡹࡥࡳࠤᙿ"), Variable4 (u"ࠨࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠦ ")),
    MovedModule(Variable4 (u"ࠢࡩࡶࡷࡴࡤࡩ࡬ࡪࡧࡱࡸࠧᚁ"), Variable4 (u"ࠣࡪࡷࡸࡵࡲࡩࡣࠤᚂ"), Variable4 (u"ࠤ࡫ࡸࡹࡶ࠮ࡤ࡮࡬ࡩࡳࡺࠢᚃ")),
    MovedModule(Variable4 (u"ࠥࡩࡲࡧࡩ࡭ࡡࡰ࡭ࡲ࡫࡟࡮ࡷ࡯ࡸ࡮ࡶࡡࡳࡶࠥᚄ"), Variable4 (u"ࠦࡪࡳࡡࡪ࡮࠱ࡑࡎࡓࡅࡎࡷ࡯ࡸ࡮ࡶࡡࡳࡶࠥᚅ"), Variable4 (u"ࠧ࡫࡭ࡢ࡫࡯࠲ࡲ࡯࡭ࡦ࠰ࡰࡹࡱࡺࡩࡱࡣࡵࡸࠧᚆ")),
    MovedModule(Variable4 (u"ࠨࡥ࡮ࡣ࡬ࡰࡤࡳࡩ࡮ࡧࡢࡲࡴࡴ࡭ࡶ࡮ࡷ࡭ࡵࡧࡲࡵࠤᚇ"), Variable4 (u"ࠢࡦ࡯ࡤ࡭ࡱ࠴ࡍࡊࡏࡈࡒࡴࡴࡍࡶ࡮ࡷ࡭ࡵࡧࡲࡵࠤᚈ"), Variable4 (u"ࠣࡧࡰࡥ࡮ࡲ࠮࡮࡫ࡰࡩ࠳ࡴ࡯࡯࡯ࡸࡰࡹ࡯ࡰࡢࡴࡷࠦᚉ")),
    MovedModule(Variable4 (u"ࠤࡨࡱࡦ࡯࡬ࡠ࡯࡬ࡱࡪࡥࡴࡦࡺࡷࠦᚊ"), Variable4 (u"ࠥࡩࡲࡧࡩ࡭࠰ࡐࡍࡒࡋࡔࡦࡺࡷࠦᚋ"), Variable4 (u"ࠦࡪࡳࡡࡪ࡮࠱ࡱ࡮ࡳࡥ࠯ࡶࡨࡼࡹࠨᚌ")),
    MovedModule(Variable4 (u"ࠧ࡫࡭ࡢ࡫࡯ࡣࡲ࡯࡭ࡦࡡࡥࡥࡸ࡫ࠢᚍ"), Variable4 (u"ࠨࡥ࡮ࡣ࡬ࡰ࠳ࡓࡉࡎࡇࡅࡥࡸ࡫ࠢᚎ"), Variable4 (u"ࠢࡦ࡯ࡤ࡭ࡱ࠴࡭ࡪ࡯ࡨ࠲ࡧࡧࡳࡦࠤᚏ")),
    MovedModule(Variable4 (u"ࠣࡄࡤࡷࡪࡎࡔࡕࡒࡖࡩࡷࡼࡥࡳࠤᚐ"), Variable4 (u"ࠤࡅࡥࡸ࡫ࡈࡕࡖࡓࡗࡪࡸࡶࡦࡴࠥᚑ"), Variable4 (u"ࠥ࡬ࡹࡺࡰ࠯ࡵࡨࡶࡻ࡫ࡲࠣᚒ")),
    MovedModule(Variable4 (u"ࠦࡈࡍࡉࡉࡖࡗࡔࡘ࡫ࡲࡷࡧࡵࠦᚓ"), Variable4 (u"ࠧࡉࡇࡊࡊࡗࡘࡕ࡙ࡥࡳࡸࡨࡶࠧᚔ"), Variable4 (u"ࠨࡨࡵࡶࡳ࠲ࡸ࡫ࡲࡷࡧࡵࠦᚕ")),
    MovedModule(Variable4 (u"ࠢࡔ࡫ࡰࡴࡱ࡫ࡈࡕࡖࡓࡗࡪࡸࡶࡦࡴࠥᚖ"), Variable4 (u"ࠣࡕ࡬ࡱࡵࡲࡥࡉࡖࡗࡔࡘ࡫ࡲࡷࡧࡵࠦᚗ"), Variable4 (u"ࠤ࡫ࡸࡹࡶ࠮ࡴࡧࡵࡺࡪࡸࠢᚘ")),
    MovedModule(Variable4 (u"ࠥࡧࡕ࡯ࡣ࡬࡮ࡨࠦᚙ"), Variable4 (u"ࠦࡨࡖࡩࡤ࡭࡯ࡩࠧᚚ"), Variable4 (u"ࠧࡶࡩࡤ࡭࡯ࡩࠧ᚛")),
    MovedModule(Variable4 (u"ࠨࡱࡶࡧࡸࡩࠧ᚜"), Variable4 (u"ࠢࡒࡷࡨࡹࡪࠨ᚝")),
    MovedModule(Variable4 (u"ࠣࡴࡨࡴࡷࡲࡩࡣࠤ᚞"), Variable4 (u"ࠤࡵࡩࡵࡸࠢ᚟")),
    MovedModule(Variable4 (u"ࠥࡷࡴࡩ࡫ࡦࡶࡶࡩࡷࡼࡥࡳࠤᚠ"), Variable4 (u"ࠦࡘࡵࡣ࡬ࡧࡷࡗࡪࡸࡶࡦࡴࠥᚡ")),
    MovedModule(Variable4 (u"ࠧࡥࡴࡩࡴࡨࡥࡩࠨᚢ"), Variable4 (u"ࠨࡴࡩࡴࡨࡥࡩࠨᚣ"), Variable4 (u"ࠢࡠࡶ࡫ࡶࡪࡧࡤࠣᚤ")),
    MovedModule(Variable4 (u"ࠣࡶ࡮࡭ࡳࡺࡥࡳࠤᚥ"), Variable4 (u"ࠤࡗ࡯࡮ࡴࡴࡦࡴࠥᚦ")),
    MovedModule(Variable4 (u"ࠥࡸࡰ࡯࡮ࡵࡧࡵࡣࡩ࡯ࡡ࡭ࡱࡪࠦᚧ"), Variable4 (u"ࠦࡉ࡯ࡡ࡭ࡱࡪࠦᚨ"), Variable4 (u"ࠧࡺ࡫ࡪࡰࡷࡩࡷ࠴ࡤࡪࡣ࡯ࡳ࡬ࠨᚩ")),
    MovedModule(Variable4 (u"ࠨࡴ࡬࡫ࡱࡸࡪࡸ࡟ࡧ࡫࡯ࡩࡩ࡯ࡡ࡭ࡱࡪࠦᚪ"), Variable4 (u"ࠢࡇ࡫࡯ࡩࡉ࡯ࡡ࡭ࡱࡪࠦᚫ"), Variable4 (u"ࠣࡶ࡮࡭ࡳࡺࡥࡳ࠰ࡩ࡭ࡱ࡫ࡤࡪࡣ࡯ࡳ࡬ࠨᚬ")),
    MovedModule(Variable4 (u"ࠤࡷ࡯࡮ࡴࡴࡦࡴࡢࡷࡨࡸ࡯࡭࡮ࡨࡨࡹ࡫ࡸࡵࠤᚭ"), Variable4 (u"ࠥࡗࡨࡸ࡯࡭࡮ࡨࡨ࡙࡫ࡸࡵࠤᚮ"), Variable4 (u"ࠦࡹࡱࡩ࡯ࡶࡨࡶ࠳ࡹࡣࡳࡱ࡯ࡰࡪࡪࡴࡦࡺࡷࠦᚯ")),
    MovedModule(Variable4 (u"ࠧࡺ࡫ࡪࡰࡷࡩࡷࡥࡳࡪ࡯ࡳࡰࡪࡪࡩࡢ࡮ࡲ࡫ࠧᚰ"), Variable4 (u"ࠨࡓࡪ࡯ࡳࡰࡪࡊࡩࡢ࡮ࡲ࡫ࠧᚱ"), Variable4 (u"ࠢࡵ࡭࡬ࡲࡹ࡫ࡲ࠯ࡵ࡬ࡱࡵࡲࡥࡥ࡫ࡤࡰࡴ࡭ࠢᚲ")),
    MovedModule(Variable4 (u"ࠣࡶ࡮࡭ࡳࡺࡥࡳࡡࡷ࡭ࡽࠨᚳ"), Variable4 (u"ࠤࡗ࡭ࡽࠨᚴ"), Variable4 (u"ࠥࡸࡰ࡯࡮ࡵࡧࡵ࠲ࡹ࡯ࡸࠣᚵ")),
    MovedModule(Variable4 (u"ࠦࡹࡱࡩ࡯ࡶࡨࡶࡤࡺࡴ࡬ࠤᚶ"), Variable4 (u"ࠧࡺࡴ࡬ࠤᚷ"), Variable4 (u"ࠨࡴ࡬࡫ࡱࡸࡪࡸ࠮ࡵࡶ࡮ࠦᚸ")),
    MovedModule(Variable4 (u"ࠢࡵ࡭࡬ࡲࡹ࡫ࡲࡠࡥࡲࡲࡸࡺࡡ࡯ࡶࡶࠦᚹ"), Variable4 (u"ࠣࡖ࡮ࡧࡴࡴࡳࡵࡣࡱࡸࡸࠨᚺ"), Variable4 (u"ࠤࡷ࡯࡮ࡴࡴࡦࡴ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸࠨᚻ")),
    MovedModule(Variable4 (u"ࠥࡸࡰ࡯࡮ࡵࡧࡵࡣࡩࡴࡤࠣᚼ"), Variable4 (u"࡙ࠦࡱࡤ࡯ࡦࠥᚽ"), Variable4 (u"ࠧࡺ࡫ࡪࡰࡷࡩࡷ࠴ࡤ࡯ࡦࠥᚾ")),
    MovedModule(Variable4 (u"ࠨࡴ࡬࡫ࡱࡸࡪࡸ࡟ࡤࡱ࡯ࡳࡷࡩࡨࡰࡱࡶࡩࡷࠨᚿ"), Variable4 (u"ࠢࡵ࡭ࡆࡳࡱࡵࡲࡄࡪࡲࡳࡸ࡫ࡲࠣᛀ"),
                Variable4 (u"ࠣࡶ࡮࡭ࡳࡺࡥࡳ࠰ࡦࡳࡱࡵࡲࡤࡪࡲࡳࡸ࡫ࡲࠣᛁ")),
    MovedModule(Variable4 (u"ࠤࡷ࡯࡮ࡴࡴࡦࡴࡢࡧࡴࡳ࡭ࡰࡰࡧ࡭ࡦࡲ࡯ࡨࠤᛂ"), Variable4 (u"ࠥࡸࡰࡉ࡯࡮࡯ࡲࡲࡉ࡯ࡡ࡭ࡱࡪࠦᛃ"),
                Variable4 (u"ࠦࡹࡱࡩ࡯ࡶࡨࡶ࠳ࡩ࡯࡮࡯ࡲࡲࡩ࡯ࡡ࡭ࡱࡪࠦᛄ")),
    MovedModule(Variable4 (u"ࠧࡺ࡫ࡪࡰࡷࡩࡷࡥࡴ࡬ࡨ࡬ࡰࡪࡪࡩࡢ࡮ࡲ࡫ࠧᛅ"), Variable4 (u"ࠨࡴ࡬ࡈ࡬ࡰࡪࡊࡩࡢ࡮ࡲ࡫ࠧᛆ"), Variable4 (u"ࠢࡵ࡭࡬ࡲࡹ࡫ࡲ࠯ࡨ࡬ࡰࡪࡪࡩࡢ࡮ࡲ࡫ࠧᛇ")),
    MovedModule(Variable4 (u"ࠣࡶ࡮࡭ࡳࡺࡥࡳࡡࡩࡳࡳࡺࠢᛈ"), Variable4 (u"ࠤࡷ࡯ࡋࡵ࡮ࡵࠤᛉ"), Variable4 (u"ࠥࡸࡰ࡯࡮ࡵࡧࡵ࠲࡫ࡵ࡮ࡵࠤᛊ")),
    MovedModule(Variable4 (u"ࠦࡹࡱࡩ࡯ࡶࡨࡶࡤࡳࡥࡴࡵࡤ࡫ࡪࡨ࡯ࡹࠤᛋ"), Variable4 (u"ࠧࡺ࡫ࡎࡧࡶࡷࡦ࡭ࡥࡃࡱࡻࠦᛌ"), Variable4 (u"ࠨࡴ࡬࡫ࡱࡸࡪࡸ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡣࡱࡻࠦᛍ")),
    MovedModule(Variable4 (u"ࠢࡵ࡭࡬ࡲࡹ࡫ࡲࡠࡶ࡮ࡷ࡮ࡳࡰ࡭ࡧࡧ࡭ࡦࡲ࡯ࡨࠤᛎ"), Variable4 (u"ࠣࡶ࡮ࡗ࡮ࡳࡰ࡭ࡧࡇ࡭ࡦࡲ࡯ࡨࠤᛏ"),
                Variable4 (u"ࠤࡷ࡯࡮ࡴࡴࡦࡴ࠱ࡷ࡮ࡳࡰ࡭ࡧࡧ࡭ࡦࡲ࡯ࡨࠤᛐ")),
    MovedModule(Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤࡢࡴࡦࡸࡳࡦࠤᛑ"), __name__ + Variable4 (u"ࠦ࠳ࡳ࡯ࡷࡧࡶ࠲ࡺࡸ࡬࡭࡫ࡥࡣࡵࡧࡲࡴࡧࠥᛒ"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡶࡡࡳࡵࡨࠦᛓ")),
    MovedModule(Variable4 (u"ࠨࡵࡳ࡮࡯࡭ࡧࡥࡥࡳࡴࡲࡶࠧᛔ"), __name__ + Variable4 (u"ࠢ࠯࡯ࡲࡺࡪࡹ࠮ࡶࡴ࡯ࡰ࡮ࡨ࡟ࡦࡴࡵࡳࡷࠨᛕ"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡧࡵࡶࡴࡸࠢᛖ")),
    MovedModule(Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣࠤᛗ"), __name__ + Variable4 (u"ࠥ࠲ࡲࡵࡶࡦࡵ࠱ࡹࡷࡲ࡬ࡪࡤࠥᛘ"), __name__ + Variable4 (u"ࠦ࠳ࡳ࡯ࡷࡧࡶ࠲ࡺࡸ࡬࡭࡫ࡥࠦᛙ")),
    MovedModule(Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦࡤࡸ࡯ࡣࡱࡷࡴࡦࡸࡳࡦࡴࠥᛚ"), Variable4 (u"ࠨࡲࡰࡤࡲࡸࡵࡧࡲࡴࡧࡵࠦᛛ"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡳࡱࡥࡳࡹࡶࡡࡳࡵࡨࡶࠧᛜ")),
    MovedModule(Variable4 (u"ࠣࡺࡰࡰࡷࡶࡣࡠࡥ࡯࡭ࡪࡴࡴࠣᛝ"), Variable4 (u"ࠤࡻࡱࡱࡸࡰࡤ࡮࡬ࡦࠧᛞ"), Variable4 (u"ࠥࡼࡲࡲࡲࡱࡥ࠱ࡧࡱ࡯ࡥ࡯ࡶࠥᛟ")),
    MovedModule(Variable4 (u"ࠦࡽࡳ࡬ࡳࡲࡦࡣࡸ࡫ࡲࡷࡧࡵࠦᛠ"), Variable4 (u"࡙ࠧࡩ࡮ࡲ࡯ࡩ࡝ࡓࡌࡓࡒࡆࡗࡪࡸࡶࡦࡴࠥᛡ"), Variable4 (u"ࠨࡸ࡮࡮ࡵࡴࡨ࠴ࡳࡦࡴࡹࡩࡷࠨᛢ")),
]
if sys.platform == Variable4 (u"ࠢࡸ࡫ࡱ࠷࠷ࠨᛣ"):
    _moved_attributes += [
        MovedModule(Variable4 (u"ࠣࡹ࡬ࡲࡷ࡫ࡧࠣᛤ"), Variable4 (u"ࠤࡢࡻ࡮ࡴࡲࡦࡩࠥᛥ")),
    ]
for attr in _moved_attributes:
    setattr(_MovedItems, attr.name, attr)
    if isinstance(attr, MovedModule):
        _importer._add_module(attr, Variable4 (u"ࠥࡱࡴࡼࡥࡴ࠰ࠥᛦ") + attr.name)
del attr
_MovedItems._moved_attributes = _moved_attributes
moves = _MovedItems(__name__ + Variable4 (u"ࠦ࠳ࡳ࡯ࡷࡧࡶࠦᛧ"))
_importer._add_module(moves, Variable4 (u"ࠧࡳ࡯ࡷࡧࡶࠦᛨ"))
class Module_six_moves_urllib_parse(_LazyModule):
    Variable4 (u"ࠨࠢࠣࡎࡤࡾࡾࠦ࡬ࡰࡣࡧ࡭ࡳ࡭ࠠࡰࡨࠣࡱࡴࡼࡥࡥࠢࡲࡦ࡯࡫ࡣࡵࡵࠣ࡭ࡳࠦࡳࡪࡺ࠱ࡱࡴࡼࡥࡴ࠰ࡸࡶࡱࡲࡩࡣࡡࡳࡥࡷࡹࡥࠣࠤࠥᛩ")
_urllib_parse_moved_attributes = [
    MovedAttribute(Variable4 (u"ࠢࡑࡣࡵࡷࡪࡘࡥࡴࡷ࡯ࡸࠧᛪ"), Variable4 (u"ࠣࡷࡵࡰࡵࡧࡲࡴࡧࠥ᛫"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡳࡥࡷࡹࡥࠣ᛬")),
    MovedAttribute(Variable4 (u"ࠥࡗࡵࡲࡩࡵࡔࡨࡷࡺࡲࡴࠣ᛭"), Variable4 (u"ࠦࡺࡸ࡬ࡱࡣࡵࡷࡪࠨᛮ"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡶࡡࡳࡵࡨࠦᛯ")),
    MovedAttribute(Variable4 (u"ࠨࡰࡢࡴࡶࡩࡤࡷࡳࠣᛰ"), Variable4 (u"ࠢࡶࡴ࡯ࡴࡦࡸࡳࡦࠤᛱ"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡲࡤࡶࡸ࡫ࠢᛲ")),
    MovedAttribute(Variable4 (u"ࠤࡳࡥࡷࡹࡥࡠࡳࡶࡰࠧᛳ"), Variable4 (u"ࠥࡹࡷࡲࡰࡢࡴࡶࡩࠧᛴ"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡵࡧࡲࡴࡧࠥᛵ")),
    MovedAttribute(Variable4 (u"ࠧࡻࡲ࡭ࡦࡨࡪࡷࡧࡧࠣᛶ"), Variable4 (u"ࠨࡵࡳ࡮ࡳࡥࡷࡹࡥࠣᛷ"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡱࡣࡵࡷࡪࠨᛸ")),
    MovedAttribute(Variable4 (u"ࠣࡷࡵࡰ࡯ࡵࡩ࡯ࠤ᛹"), Variable4 (u"ࠤࡸࡶࡱࡶࡡࡳࡵࡨࠦ᛺"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡴࡦࡸࡳࡦࠤ᛻")),
    MovedAttribute(Variable4 (u"ࠦࡺࡸ࡬ࡱࡣࡵࡷࡪࠨ᛼"), Variable4 (u"ࠧࡻࡲ࡭ࡲࡤࡶࡸ࡫ࠢ᛽"), Variable4 (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡰࡢࡴࡶࡩࠧ᛾")),
    MovedAttribute(Variable4 (u"ࠢࡶࡴ࡯ࡷࡵࡲࡩࡵࠤ᛿"), Variable4 (u"ࠣࡷࡵࡰࡵࡧࡲࡴࡧࠥᜀ"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡳࡥࡷࡹࡥࠣᜁ")),
    MovedAttribute(Variable4 (u"ࠥࡹࡷࡲࡵ࡯ࡲࡤࡶࡸ࡫ࠢᜂ"), Variable4 (u"ࠦࡺࡸ࡬ࡱࡣࡵࡷࡪࠨᜃ"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡶࡡࡳࡵࡨࠦᜄ")),
    MovedAttribute(Variable4 (u"ࠨࡵࡳ࡮ࡸࡲࡸࡶ࡬ࡪࡶࠥᜅ"), Variable4 (u"ࠢࡶࡴ࡯ࡴࡦࡸࡳࡦࠤᜆ"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡲࡤࡶࡸ࡫ࠢᜇ")),
    MovedAttribute(Variable4 (u"ࠤࡴࡹࡴࡺࡥࠣᜈ"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤࠥᜉ"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡵࡧࡲࡴࡧࠥᜊ")),
    MovedAttribute(Variable4 (u"ࠧࡷࡵࡰࡶࡨࡣࡵࡲࡵࡴࠤᜋ"), Variable4 (u"ࠨࡵࡳ࡮࡯࡭ࡧࠨᜌ"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡱࡣࡵࡷࡪࠨᜍ")),
    MovedAttribute(Variable4 (u"ࠣࡷࡱࡵࡺࡵࡴࡦࠤᜎ"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣࠤᜏ"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡴࡦࡸࡳࡦࠤᜐ")),
    MovedAttribute(Variable4 (u"ࠦࡺࡴࡱࡶࡱࡷࡩࡤࡶ࡬ࡶࡵࠥᜑ"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦࠧᜒ"), Variable4 (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡰࡢࡴࡶࡩࠧᜓ")),
    MovedAttribute(Variable4 (u"ࠢࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧ᜔ࠥ"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢ᜕ࠣ"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡳࡥࡷࡹࡥࠣ᜖")),
    MovedAttribute(Variable4 (u"ࠥࡷࡵࡲࡩࡵࡳࡸࡩࡷࡿࠢ᜗"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥࠦ᜘"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡶࡡࡳࡵࡨࠦ᜙")),
    MovedAttribute(Variable4 (u"ࠨࡳࡱ࡮࡬ࡸࡹࡧࡧࠣ᜚"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨࠢ᜛"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡲࡤࡶࡸ࡫ࠢ᜜")),
    MovedAttribute(Variable4 (u"ࠤࡶࡴࡱ࡯ࡴࡶࡵࡨࡶࠧ᜝"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤࠥ᜞"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡵࡧࡲࡴࡧࠥᜟ")),
    MovedAttribute(Variable4 (u"ࠧࡻࡳࡦࡵࡢࡪࡷࡧࡧ࡮ࡧࡱࡸࠧᜠ"), Variable4 (u"ࠨࡵࡳ࡮ࡳࡥࡷࡹࡥࠣᜡ"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡱࡣࡵࡷࡪࠨᜢ")),
    MovedAttribute(Variable4 (u"ࠣࡷࡶࡩࡸࡥ࡮ࡦࡶ࡯ࡳࡨࠨᜣ"), Variable4 (u"ࠤࡸࡶࡱࡶࡡࡳࡵࡨࠦᜤ"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡴࡦࡸࡳࡦࠤᜥ")),
    MovedAttribute(Variable4 (u"ࠦࡺࡹࡥࡴࡡࡳࡥࡷࡧ࡭ࡴࠤᜦ"), Variable4 (u"ࠧࡻࡲ࡭ࡲࡤࡶࡸ࡫ࠢᜧ"), Variable4 (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡰࡢࡴࡶࡩࠧᜨ")),
    MovedAttribute(Variable4 (u"ࠢࡶࡵࡨࡷࡤࡷࡵࡦࡴࡼࠦᜩ"), Variable4 (u"ࠣࡷࡵࡰࡵࡧࡲࡴࡧࠥᜪ"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡳࡥࡷࡹࡥࠣᜫ")),
    MovedAttribute(Variable4 (u"ࠥࡹࡸ࡫ࡳࡠࡴࡨࡰࡦࡺࡩࡷࡧࠥᜬ"), Variable4 (u"ࠦࡺࡸ࡬ࡱࡣࡵࡷࡪࠨᜭ"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡶࡡࡳࡵࡨࠦᜮ")),
]
for attr in _urllib_parse_moved_attributes:
    setattr(Module_six_moves_urllib_parse, attr.name, attr)
del attr
Module_six_moves_urllib_parse._moved_attributes = _urllib_parse_moved_attributes
_importer._add_module(Module_six_moves_urllib_parse(__name__ + Variable4 (u"ࠨ࠮࡮ࡱࡹࡩࡸ࠴ࡵࡳ࡮࡯࡭ࡧࡥࡰࡢࡴࡶࡩࠧᜯ")),
                      Variable4 (u"ࠢ࡮ࡱࡹࡩࡸ࠴ࡵࡳ࡮࡯࡭ࡧࡥࡰࡢࡴࡶࡩࠧᜰ"), Variable4 (u"ࠣ࡯ࡲࡺࡪࡹ࠮ࡶࡴ࡯ࡰ࡮ࡨ࠮ࡱࡣࡵࡷࡪࠨᜱ"))
class Module_six_moves_urllib_error(_LazyModule):
    Variable4 (u"ࠤࠥࠦࡑࡧࡺࡺࠢ࡯ࡳࡦࡪࡩ࡯ࡩࠣࡳ࡫ࠦ࡭ࡰࡸࡨࡨࠥࡵࡢ࡫ࡧࡦࡸࡸࠦࡩ࡯ࠢࡶ࡭ࡽ࠴࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦࡤ࡫ࡲࡳࡱࡵࠦࠧࠨᜲ")
_urllib_error_moved_attributes = [
    MovedAttribute(Variable4 (u"࡙ࠥࡗࡒࡅࡳࡴࡲࡶࠧᜳ"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠶᜴ࠧ"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳࡫ࡲࡳࡱࡵࠦ᜵")),
    MovedAttribute(Variable4 (u"ࠨࡈࡕࡖࡓࡉࡷࡸ࡯ࡳࠤ᜶"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠲ࠣ᜷"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡧࡵࡶࡴࡸࠢ᜸")),
    MovedAttribute(Variable4 (u"ࠤࡆࡳࡳࡺࡥ࡯ࡶࡗࡳࡴ࡙ࡨࡰࡴࡷࡉࡷࡸ࡯ࡳࠤ᜹"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤࠥ᜺"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡪࡸࡲࡰࡴࠥ᜻")),
]
for attr in _urllib_error_moved_attributes:
    setattr(Module_six_moves_urllib_error, attr.name, attr)
del attr
Module_six_moves_urllib_error._moved_attributes = _urllib_error_moved_attributes
_importer._add_module(Module_six_moves_urllib_error(__name__ + Variable4 (u"ࠧ࠴࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦ࠳࡫ࡲࡳࡱࡵࠦ᜼")),
                      Variable4 (u"ࠨ࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦࡤ࡫ࡲࡳࡱࡵࠦ᜽"), Variable4 (u"ࠢ࡮ࡱࡹࡩࡸ࠴ࡵࡳ࡮࡯࡭ࡧ࠴ࡥࡳࡴࡲࡶࠧ᜾"))
class Module_six_moves_urllib_request(_LazyModule):
    Variable4 (u"ࠣࠤࠥࡐࡦࢀࡹࠡ࡮ࡲࡥࡩ࡯࡮ࡨࠢࡲࡪࠥࡳ࡯ࡷࡧࡧࠤࡴࡨࡪࡦࡥࡷࡷࠥ࡯࡮ࠡࡵ࡬ࡼ࠳ࡳ࡯ࡷࡧࡶ࠲ࡺࡸ࡬࡭࡫ࡥࡣࡷ࡫ࡱࡶࡧࡶࡸࠧࠨࠢ᜿")
_urllib_request_moved_attributes = [
    MovedAttribute(Variable4 (u"ࠤࡸࡶࡱࡵࡰࡦࡰࠥᝀ"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠵ࠦᝁ"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡷ࡫ࡱࡶࡧࡶࡸࠧᝂ")),
    MovedAttribute(Variable4 (u"ࠧ࡯࡮ࡴࡶࡤࡰࡱࡥ࡯ࡱࡧࡱࡩࡷࠨᝃ"), Variable4 (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠸ࠢᝄ"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡳࡧࡴࡹࡪࡹࡴࠣᝅ")),
    MovedAttribute(Variable4 (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡰࡲࡨࡲࡪࡸࠢᝆ"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣ࠴ࠥᝇ"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡶࡪࡷࡵࡦࡵࡷࠦᝈ")),
    MovedAttribute(Variable4 (u"ࠦࡵࡧࡴࡩࡰࡤࡱࡪ࠸ࡵࡳ࡮ࠥᝉ"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦࠧᝊ"), Variable4 (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡲࡦࡳࡸࡩࡸࡺࠢᝋ")),
    MovedAttribute(Variable4 (u"ࠢࡶࡴ࡯࠶ࡵࡧࡴࡩࡰࡤࡱࡪࠨᝌ"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢࠣᝍ"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡵࡩࡶࡻࡥࡴࡶࠥᝎ")),
    MovedAttribute(Variable4 (u"ࠥ࡫ࡪࡺࡰࡳࡱࡻ࡭ࡪࡹࠢᝏ"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥࠦᝐ"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡸࡥࡲࡷࡨࡷࡹࠨᝑ")),
    MovedAttribute(Variable4 (u"ࠨࡒࡦࡳࡸࡩࡸࡺࠢᝒ"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠲ࠣᝓ"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡴࡨࡵࡺ࡫ࡳࡵࠤ᝔")),
    MovedAttribute(Variable4 (u"ࠤࡒࡴࡪࡴࡥࡳࡆ࡬ࡶࡪࡩࡴࡰࡴࠥ᝕"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠵ࠦ᝖"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡷ࡫ࡱࡶࡧࡶࡸࠧ᝗")),
    MovedAttribute(Variable4 (u"ࠧࡎࡔࡕࡒࡇࡩ࡫ࡧࡵ࡭ࡶࡈࡶࡷࡵࡲࡉࡣࡱࡨࡱ࡫ࡲࠣ᝘"), Variable4 (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠸ࠢ᝙"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡳࡧࡴࡹࡪࡹࡴࠣ᝚")),
    MovedAttribute(Variable4 (u"ࠣࡊࡗࡘࡕࡘࡥࡥ࡫ࡵࡩࡨࡺࡈࡢࡰࡧࡰࡪࡸࠢ᝛"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣ࠴ࠥ᝜"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡶࡪࡷࡵࡦࡵࡷࠦ᝝")),
    MovedAttribute(Variable4 (u"ࠦࡍ࡚ࡔࡑࡅࡲࡳࡰ࡯ࡥࡑࡴࡲࡧࡪࡹࡳࡰࡴࠥ᝞"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠷ࠨ᝟"), Variable4 (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡲࡦࡳࡸࡩࡸࡺࠢᝠ")),
    MovedAttribute(Variable4 (u"ࠢࡑࡴࡲࡼࡾࡎࡡ࡯ࡦ࡯ࡩࡷࠨᝡ"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠳ࠤᝢ"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡵࡩࡶࡻࡥࡴࡶࠥᝣ")),
    MovedAttribute(Variable4 (u"ࠥࡆࡦࡹࡥࡉࡣࡱࡨࡱ࡫ࡲࠣᝤ"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠶ࠧᝥ"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡸࡥࡲࡷࡨࡷࡹࠨᝦ")),
    MovedAttribute(Variable4 (u"ࠨࡈࡕࡖࡓࡔࡦࡹࡳࡸࡱࡵࡨࡒ࡭ࡲࠣᝧ"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠲ࠣᝨ"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡴࡨࡵࡺ࡫ࡳࡵࠤᝩ")),
    MovedAttribute(Variable4 (u"ࠤࡋࡘ࡙ࡖࡐࡢࡵࡶࡻࡴࡸࡤࡎࡩࡵ࡛࡮ࡺࡨࡅࡧࡩࡥࡺࡲࡴࡓࡧࡤࡰࡲࠨᝪ"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠵ࠦᝫ"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡷ࡫ࡱࡶࡧࡶࡸࠧᝬ")),
    MovedAttribute(Variable4 (u"ࠧࡇࡢࡴࡶࡵࡥࡨࡺࡂࡢࡵ࡬ࡧࡆࡻࡴࡩࡊࡤࡲࡩࡲࡥࡳࠤ᝭"), Variable4 (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠸ࠢᝮ"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡳࡧࡴࡹࡪࡹࡴࠣᝯ")),
    MovedAttribute(Variable4 (u"ࠣࡊࡗࡘࡕࡈࡡࡴ࡫ࡦࡅࡺࡺࡨࡉࡣࡱࡨࡱ࡫ࡲࠣᝰ"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣ࠴ࠥ᝱"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡶࡪࡷࡵࡦࡵࡷࠦᝲ")),
    MovedAttribute(Variable4 (u"ࠦࡕࡸ࡯ࡹࡻࡅࡥࡸ࡯ࡣࡂࡷࡷ࡬ࡍࡧ࡮ࡥ࡮ࡨࡶࠧᝳ"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠷ࠨ᝴"), Variable4 (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡲࡦࡳࡸࡩࡸࡺࠢ᝵")),
    MovedAttribute(Variable4 (u"ࠢࡂࡤࡶࡸࡷࡧࡣࡵࡆ࡬࡫ࡪࡹࡴࡂࡷࡷ࡬ࡍࡧ࡮ࡥ࡮ࡨࡶࠧ᝶"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠳ࠤ᝷"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡵࡩࡶࡻࡥࡴࡶࠥ᝸")),
    MovedAttribute(Variable4 (u"ࠥࡌ࡙࡚ࡐࡅ࡫ࡪࡩࡸࡺࡁࡶࡶ࡫ࡌࡦࡴࡤ࡭ࡧࡵࠦ᝹"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠶ࠧ᝺"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡸࡥࡲࡷࡨࡷࡹࠨ᝻")),
    MovedAttribute(Variable4 (u"ࠨࡐࡳࡱࡻࡽࡉ࡯ࡧࡦࡵࡷࡅࡺࡺࡨࡉࡣࡱࡨࡱ࡫ࡲࠣ᝼"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠲ࠣ᝽"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡴࡨࡵࡺ࡫ࡳࡵࠤ᝾")),
    MovedAttribute(Variable4 (u"ࠤࡋࡘ࡙ࡖࡈࡢࡰࡧࡰࡪࡸࠢ᝿"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠵ࠦក"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡷ࡫ࡱࡶࡧࡶࡸࠧខ")),
    MovedAttribute(Variable4 (u"ࠧࡎࡔࡕࡒࡖࡌࡦࡴࡤ࡭ࡧࡵࠦគ"), Variable4 (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠸ࠢឃ"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡳࡧࡴࡹࡪࡹࡴࠣង")),
    MovedAttribute(Variable4 (u"ࠣࡈ࡬ࡰࡪࡎࡡ࡯ࡦ࡯ࡩࡷࠨច"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣ࠴ࠥឆ"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡶࡪࡷࡵࡦࡵࡷࠦជ")),
    MovedAttribute(Variable4 (u"ࠦࡋ࡚ࡐࡉࡣࡱࡨࡱ࡫ࡲࠣឈ"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠷ࠨញ"), Variable4 (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡲࡦࡳࡸࡩࡸࡺࠢដ")),
    MovedAttribute(Variable4 (u"ࠢࡄࡣࡦ࡬ࡪࡌࡔࡑࡊࡤࡲࡩࡲࡥࡳࠤឋ"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠳ࠤឌ"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡵࡩࡶࡻࡥࡴࡶࠥឍ")),
    MovedAttribute(Variable4 (u"࡙ࠥࡳࡱ࡮ࡰࡹࡱࡌࡦࡴࡤ࡭ࡧࡵࠦណ"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠶ࠧត"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡸࡥࡲࡷࡨࡷࡹࠨថ")),
    MovedAttribute(Variable4 (u"ࠨࡈࡕࡖࡓࡉࡷࡸ࡯ࡳࡒࡵࡳࡨ࡫ࡳࡴࡱࡵࠦទ"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠲ࠣធ"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡴࡨࡵࡺ࡫ࡳࡵࠤន")),
    MovedAttribute(Variable4 (u"ࠤࡸࡶࡱࡸࡥࡵࡴ࡬ࡩࡻ࡫ࠢប"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤࠥផ"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡷ࡫ࡱࡶࡧࡶࡸࠧព")),
    MovedAttribute(Variable4 (u"ࠧࡻࡲ࡭ࡥ࡯ࡩࡦࡴࡵࡱࠤភ"), Variable4 (u"ࠨࡵࡳ࡮࡯࡭ࡧࠨម"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡳࡧࡴࡹࡪࡹࡴࠣយ")),
    MovedAttribute(Variable4 (u"ࠣࡗࡕࡐࡴࡶࡥ࡯ࡧࡵࠦរ"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣࠤល"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡶࡪࡷࡵࡦࡵࡷࠦវ")),
    MovedAttribute(Variable4 (u"ࠦࡋࡧ࡮ࡤࡻࡘࡖࡑࡵࡰࡦࡰࡨࡶࠧឝ"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦࠧឞ"), Variable4 (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡲࡦࡳࡸࡩࡸࡺࠢស")),
    MovedAttribute(Variable4 (u"ࠢࡱࡴࡲࡼࡾࡥࡢࡺࡲࡤࡷࡸࠨហ"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢࠣឡ"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡵࡩࡶࡻࡥࡴࡶࠥអ")),
]
for attr in _urllib_request_moved_attributes:
    setattr(Module_six_moves_urllib_request, attr.name, attr)
del attr
Module_six_moves_urllib_request._moved_attributes = _urllib_request_moved_attributes
_importer._add_module(Module_six_moves_urllib_request(__name__ + Variable4 (u"ࠥ࠲ࡲࡵࡶࡦࡵ࠱ࡹࡷࡲ࡬ࡪࡤ࠱ࡶࡪࡷࡵࡦࡵࡷࠦឣ")),
                      Variable4 (u"ࠦࡲࡵࡶࡦࡵ࠱ࡹࡷࡲ࡬ࡪࡤࡢࡶࡪࡷࡵࡦࡵࡷࠦឤ"), Variable4 (u"ࠧࡳ࡯ࡷࡧࡶ࠲ࡺࡸ࡬࡭࡫ࡥ࠲ࡷ࡫ࡱࡶࡧࡶࡸࠧឥ"))
class Module_six_moves_urllib_response(_LazyModule):
    Variable4 (u"ࠨࠢࠣࡎࡤࡾࡾࠦ࡬ࡰࡣࡧ࡭ࡳ࡭ࠠࡰࡨࠣࡱࡴࡼࡥࡥࠢࡲࡦ࡯࡫ࡣࡵࡵࠣ࡭ࡳࠦࡳࡪࡺ࠱ࡱࡴࡼࡥࡴ࠰ࡸࡶࡱࡲࡩࡣࡡࡵࡩࡸࡶ࡯࡯ࡵࡨࠦࠧࠨឦ")
_urllib_response_moved_attributes = [
    MovedAttribute(Variable4 (u"ࠢࡢࡦࡧࡦࡦࡹࡥࠣឧ"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢࠣឨ"), Variable4 (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡵࡩࡸࡶ࡯࡯ࡵࡨࠦឩ")),
    MovedAttribute(Variable4 (u"ࠥࡥࡩࡪࡣ࡭ࡱࡶࡩ࡭ࡵ࡯࡬ࠤឪ"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥࠦឫ"), Variable4 (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡸࡥࡴࡲࡲࡲࡸ࡫ࠢឬ")),
    MovedAttribute(Variable4 (u"ࠨࡡࡥࡦ࡬ࡲ࡫ࡵࠢឭ"), Variable4 (u"ࠢࡶࡴ࡯ࡰ࡮ࡨࠢឮ"), Variable4 (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡴࡨࡷࡵࡵ࡮ࡴࡧࠥឯ")),
    MovedAttribute(Variable4 (u"ࠤࡤࡨࡩ࡯࡮ࡧࡱࡸࡶࡱࠨឰ"), Variable4 (u"ࠥࡹࡷࡲ࡬ࡪࡤࠥឱ"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡷ࡫ࡳࡱࡱࡱࡷࡪࠨឲ")),
]
for attr in _urllib_response_moved_attributes:
    setattr(Module_six_moves_urllib_response, attr.name, attr)
del attr
Module_six_moves_urllib_response._moved_attributes = _urllib_response_moved_attributes
_importer._add_module(Module_six_moves_urllib_response(__name__ + Variable4 (u"ࠧ࠴࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦ࠳ࡸࡥࡴࡲࡲࡲࡸ࡫ࠢឳ")),
                      Variable4 (u"ࠨ࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦࡤࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ឴"), Variable4 (u"ࠢ࡮ࡱࡹࡩࡸ࠴ࡵࡳ࡮࡯࡭ࡧ࠴ࡲࡦࡵࡳࡳࡳࡹࡥࠣ឵"))
class Module_six_moves_urllib_robotparser(_LazyModule):
    Variable4 (u"ࠣࠤࠥࡐࡦࢀࡹࠡ࡮ࡲࡥࡩ࡯࡮ࡨࠢࡲࡪࠥࡳ࡯ࡷࡧࡧࠤࡴࡨࡪࡦࡥࡷࡷࠥ࡯࡮ࠡࡵ࡬ࡼ࠳ࡳ࡯ࡷࡧࡶ࠲ࡺࡸ࡬࡭࡫ࡥࡣࡷࡵࡢࡰࡶࡳࡥࡷࡹࡥࡳࠤࠥࠦា")
_urllib_robotparser_moved_attributes = [
    MovedAttribute(Variable4 (u"ࠤࡕࡳࡧࡵࡴࡇ࡫࡯ࡩࡕࡧࡲࡴࡧࡵࠦិ"), Variable4 (u"ࠥࡶࡴࡨ࡯ࡵࡲࡤࡶࡸ࡫ࡲࠣី"), Variable4 (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡷࡵࡢࡰࡶࡳࡥࡷࡹࡥࡳࠤឹ")),
]
for attr in _urllib_robotparser_moved_attributes:
    setattr(Module_six_moves_urllib_robotparser, attr.name, attr)
del attr
Module_six_moves_urllib_robotparser._moved_attributes = _urllib_robotparser_moved_attributes
_importer._add_module(Module_six_moves_urllib_robotparser(__name__ + Variable4 (u"ࠧ࠴࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦ࠳ࡸ࡯ࡣࡱࡷࡴࡦࡸࡳࡦࡴࠥឺ")),
                      Variable4 (u"ࠨ࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦࡤࡸ࡯ࡣࡱࡷࡴࡦࡸࡳࡦࡴࠥុ"), Variable4 (u"ࠢ࡮ࡱࡹࡩࡸ࠴ࡵࡳ࡮࡯࡭ࡧ࠴ࡲࡰࡤࡲࡸࡵࡧࡲࡴࡧࡵࠦូ"))
class Module_six_moves_urllib(types.ModuleType):
    Variable4 (u"ࠣࠤࠥࡇࡷ࡫ࡡࡵࡧࠣࡥࠥࡹࡩࡹ࠰ࡰࡳࡻ࡫ࡳ࠯ࡷࡵࡰࡱ࡯ࡢࠡࡰࡤࡱࡪࡹࡰࡢࡥࡨࠤࡹ࡮ࡡࡵࠢࡵࡩࡸ࡫࡭ࡣ࡮ࡨࡷࠥࡺࡨࡦࠢࡓࡽࡹ࡮࡯࡯ࠢ࠶ࠤࡳࡧ࡭ࡦࡵࡳࡥࡨ࡫ࠢࠣࠤួ")
    __path__ = []
    parse = _importer._get_module(Variable4 (u"ࠤࡰࡳࡻ࡫ࡳ࠯ࡷࡵࡰࡱ࡯ࡢࡠࡲࡤࡶࡸ࡫ࠢើ"))
    error = _importer._get_module(Variable4 (u"ࠥࡱࡴࡼࡥࡴ࠰ࡸࡶࡱࡲࡩࡣࡡࡨࡶࡷࡵࡲࠣឿ"))
    request = _importer._get_module(Variable4 (u"ࠦࡲࡵࡶࡦࡵ࠱ࡹࡷࡲ࡬ࡪࡤࡢࡶࡪࡷࡵࡦࡵࡷࠦៀ"))
    response = _importer._get_module(Variable4 (u"ࠧࡳ࡯ࡷࡧࡶ࠲ࡺࡸ࡬࡭࡫ࡥࡣࡷ࡫ࡳࡱࡱࡱࡷࡪࠨេ"))
    robotparser = _importer._get_module(Variable4 (u"ࠨ࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦࡤࡸ࡯ࡣࡱࡷࡴࡦࡸࡳࡦࡴࠥែ"))
    def __dir__(self):
        return [Variable4 (u"ࠧࡱࡣࡵࡷࡪ࠭ៃ"), Variable4 (u"ࠨࡧࡵࡶࡴࡸࠧោ"), Variable4 (u"ࠩࡵࡩࡶࡻࡥࡴࡶࠪៅ"), Variable4 (u"ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬំ"), Variable4 (u"ࠫࡷࡵࡢࡰࡶࡳࡥࡷࡹࡥࡳࠩះ")]
_importer._add_module(Module_six_moves_urllib(__name__ + Variable4 (u"ࠧ࠴࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦࠧៈ")),
                      Variable4 (u"ࠨ࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦࠧ៉"))
def add_move(move):
    Variable4 (u"ࠢࠣࠤࡄࡨࡩࠦࡡ࡯ࠢ࡬ࡸࡪࡳࠠࡵࡱࠣࡷ࡮ࡾ࠮࡮ࡱࡹࡩࡸ࠴ࠢࠣࠤ៊")
    setattr(_MovedItems, move.name, move)
def remove_move(name):
    Variable4 (u"ࠣࠤࠥࡖࡪࡳ࡯ࡷࡧࠣ࡭ࡹ࡫࡭ࠡࡨࡵࡳࡲࠦࡳࡪࡺ࠱ࡱࡴࡼࡥࡴ࠰ࠥࠦࠧ់")
    try:
        delattr(_MovedItems, name)
    except AttributeError:
        try:
            del moves.__dict__[name]
        except KeyError:
            raise AttributeError(Variable4 (u"ࠤࡱࡳࠥࡹࡵࡤࡪࠣࡱࡴࡼࡥ࠭ࠢࠨࡶࠧ៌") % (name,))
if PY3:
    _meth_func = Variable4 (u"ࠥࡣࡤ࡬ࡵ࡯ࡥࡢࡣࠧ៍")
    _meth_self = Variable4 (u"ࠦࡤࡥࡳࡦ࡮ࡩࡣࡤࠨ៎")
    _func_closure = Variable4 (u"ࠧࡥ࡟ࡤ࡮ࡲࡷࡺࡸࡥࡠࡡࠥ៏")
    _func_code = Variable4 (u"ࠨ࡟ࡠࡥࡲࡨࡪࡥ࡟ࠣ័")
    _func_defaults = Variable4 (u"ࠢࡠࡡࡧࡩ࡫ࡧࡵ࡭ࡶࡶࡣࡤࠨ៑")
    _func_globals = Variable4 (u"ࠣࡡࡢ࡫ࡱࡵࡢࡢ࡮ࡶࡣࡤࠨ្")
else:
    _meth_func = Variable4 (u"ࠤ࡬ࡱࡤ࡬ࡵ࡯ࡥࠥ៓")
    _meth_self = Variable4 (u"ࠥ࡭ࡲࡥࡳࡦ࡮ࡩࠦ។")
    _func_closure = Variable4 (u"ࠦ࡫ࡻ࡮ࡤࡡࡦࡰࡴࡹࡵࡳࡧࠥ៕")
    _func_code = Variable4 (u"ࠧ࡬ࡵ࡯ࡥࡢࡧࡴࡪࡥࠣ៖")
    _func_defaults = Variable4 (u"ࠨࡦࡶࡰࡦࡣࡩ࡫ࡦࡢࡷ࡯ࡸࡸࠨៗ")
    _func_globals = Variable4 (u"ࠢࡧࡷࡱࡧࡤ࡭࡬ࡰࡤࡤࡰࡸࠨ៘")
try:
    advance_iterator = next
except NameError:
    def advance_iterator(it):
        return it.next()
next = advance_iterator
try:
    callable = callable
except NameError:
    def callable(obj):
        return any(Variable4 (u"ࠣࡡࡢࡧࡦࡲ࡬ࡠࡡࠥ៙") in klass.__dict__ for klass in type(obj).__mro__)
if PY3:
    def get_unbound_function(unbound):
        return unbound
    create_bound_method = types.MethodType
    def create_unbound_method(func, cls):
        return func
    Iterator = object
else:
    def get_unbound_function(unbound):
        return unbound.im_func
    def create_bound_method(func, obj):
        return types.MethodType(func, obj, obj.__class__)
    def create_unbound_method(func, cls):
        return types.MethodType(func, None, cls)
    class Iterator(object):
        def next(self):
            return type(self).__next__(self)
    callable = callable
_add_doc(get_unbound_function,
         Variable4 (u"ࠤࠥࠦࡌ࡫ࡴࠡࡶ࡫ࡩࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡷࡷࠤࡴ࡬ࠠࡢࠢࡳࡳࡸࡹࡩࡣ࡮ࡼࠤࡺࡴࡢࡰࡷࡱࡨࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠢࠣࠤ៚"))
get_method_function = operator.attrgetter(_meth_func)
get_method_self = operator.attrgetter(_meth_self)
get_function_closure = operator.attrgetter(_func_closure)
get_function_code = operator.attrgetter(_func_code)
get_function_defaults = operator.attrgetter(_func_defaults)
get_function_globals = operator.attrgetter(_func_globals)
if PY3:
    def iterkeys(d, **kw):
        return iter(d.keys(**kw))
    def itervalues(d, **kw):
        return iter(d.values(**kw))
    def iteritems(d, **kw):
        return iter(d.items(**kw))
    def iterlists(d, **kw):
        return iter(d.lists(**kw))
    viewkeys = operator.methodcaller(Variable4 (u"ࠥ࡯ࡪࡿࡳࠣ៛"))
    viewvalues = operator.methodcaller(Variable4 (u"ࠦࡻࡧ࡬ࡶࡧࡶࠦៜ"))
    viewitems = operator.methodcaller(Variable4 (u"ࠧ࡯ࡴࡦ࡯ࡶࠦ៝"))
else:
    def iterkeys(d, **kw):
        return d.iterkeys(**kw)
    def itervalues(d, **kw):
        return d.itervalues(**kw)
    def iteritems(d, **kw):
        return d.iteritems(**kw)
    def iterlists(d, **kw):
        return d.iterlists(**kw)
    viewkeys = operator.methodcaller(Variable4 (u"ࠨࡶࡪࡧࡺ࡯ࡪࡿࡳࠣ៞"))
    viewvalues = operator.methodcaller(Variable4 (u"ࠢࡷ࡫ࡨࡻࡻࡧ࡬ࡶࡧࡶࠦ៟"))
    viewitems = operator.methodcaller(Variable4 (u"ࠣࡸ࡬ࡩࡼ࡯ࡴࡦ࡯ࡶࠦ០"))
_add_doc(iterkeys, Variable4 (u"ࠤࡕࡩࡹࡻࡲ࡯ࠢࡤࡲࠥ࡯ࡴࡦࡴࡤࡸࡴࡸࠠࡰࡸࡨࡶࠥࡺࡨࡦࠢ࡮ࡩࡾࡹࠠࡰࡨࠣࡥࠥࡪࡩࡤࡶ࡬ࡳࡳࡧࡲࡺ࠰ࠥ១"))
_add_doc(itervalues, Variable4 (u"ࠥࡖࡪࡺࡵࡳࡰࠣࡥࡳࠦࡩࡵࡧࡵࡥࡹࡵࡲࠡࡱࡹࡩࡷࠦࡴࡩࡧࠣࡺࡦࡲࡵࡦࡵࠣࡳ࡫ࠦࡡࠡࡦ࡬ࡧࡹ࡯࡯࡯ࡣࡵࡽ࠳ࠨ២"))
_add_doc(iteritems,
         Variable4 (u"ࠦࡗ࡫ࡴࡶࡴࡱࠤࡦࡴࠠࡪࡶࡨࡶࡦࡺ࡯ࡳࠢࡲࡺࡪࡸࠠࡵࡪࡨࠤ࠭ࡱࡥࡺ࠮ࠣࡺࡦࡲࡵࡦࠫࠣࡴࡦ࡯ࡲࡴࠢࡲࡪࠥࡧࠠࡥ࡫ࡦࡸ࡮ࡵ࡮ࡢࡴࡼ࠲ࠧ៣"))
_add_doc(iterlists,
         Variable4 (u"ࠧࡘࡥࡵࡷࡵࡲࠥࡧ࡮ࠡ࡫ࡷࡩࡷࡧࡴࡰࡴࠣࡳࡻ࡫ࡲࠡࡶ࡫ࡩࠥ࠮࡫ࡦࡻ࠯ࠤࡠࡼࡡ࡭ࡷࡨࡷࡢ࠯ࠠࡱࡣ࡬ࡶࡸࠦ࡯ࡧࠢࡤࠤࡩ࡯ࡣࡵ࡫ࡲࡲࡦࡸࡹ࠯ࠤ៤"))
if PY3:
    def b(s):
        return s.encode(Variable4 (u"ࠨ࡬ࡢࡶ࡬ࡲ࠲࠷ࠢ៥"))
    def u(s):
        return s
    unichr = chr
    import struct
    int2byte = struct.Struct(Variable4 (u"ࠢ࠿ࡄࠥ៦")).pack
    del struct
    byte2int = operator.itemgetter(0)
    indexbytes = operator.getitem
    iterbytes = iter
    import io
    StringIO = io.StringIO
    BytesIO = io.BytesIO
    _assertCountEqual = Variable4 (u"ࠣࡣࡶࡷࡪࡸࡴࡄࡱࡸࡲࡹࡋࡱࡶࡣ࡯ࠦ៧")
    if sys.version_info[1] <= 1:
        _assertRaisesRegex = Variable4 (u"ࠤࡤࡷࡸ࡫ࡲࡵࡔࡤ࡭ࡸ࡫ࡳࡓࡧࡪࡩࡽࡶࠢ៨")
        _assertRegex = Variable4 (u"ࠥࡥࡸࡹࡥࡳࡶࡕࡩ࡬࡫ࡸࡱࡏࡤࡸࡨ࡮ࡥࡴࠤ៩")
    else:
        _assertRaisesRegex = Variable4 (u"ࠦࡦࡹࡳࡦࡴࡷࡖࡦ࡯ࡳࡦࡵࡕࡩ࡬࡫ࡸࠣ៪")
        _assertRegex = Variable4 (u"ࠧࡧࡳࡴࡧࡵࡸࡗ࡫ࡧࡦࡺࠥ៫")
else:
    def b(s):
        return s
    def u(s):
        return unicode(s.replace(Variable4 (u"ࡸࠧ࡝࡞ࠪ៬"), Variable4 (u"ࡲࠨ࡞࡟ࡠࡡ࠭៭")), Variable4 (u"ࠣࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠤ៮"))
    unichr = unichr
    int2byte = chr
    def byte2int(bs):
        return ord(bs[0])
    def indexbytes(buf, i):
        return ord(buf[i])
    iterbytes = functools.partial(itertools.imap, ord)
    import StringIO
    StringIO = BytesIO = StringIO.StringIO
    _assertCountEqual = Variable4 (u"ࠤࡤࡷࡸ࡫ࡲࡵࡋࡷࡩࡲࡹࡅࡲࡷࡤࡰࠧ៯")
    _assertRaisesRegex = Variable4 (u"ࠥࡥࡸࡹࡥࡳࡶࡕࡥ࡮ࡹࡥࡴࡔࡨ࡫ࡪࡾࡰࠣ៰")
    _assertRegex = Variable4 (u"ࠦࡦࡹࡳࡦࡴࡷࡖࡪ࡭ࡥࡹࡲࡐࡥࡹࡩࡨࡦࡵࠥ៱")
_add_doc(b, Variable4 (u"ࠧࠨࠢࡃࡻࡷࡩࠥࡲࡩࡵࡧࡵࡥࡱࠨࠢࠣ៲"))
_add_doc(u, Variable4 (u"ࠨࠢࠣࡖࡨࡼࡹࠦ࡬ࡪࡶࡨࡶࡦࡲࠢࠣࠤ៳"))
def assertCountEqual(self, *args, **kwargs):
    return getattr(self, _assertCountEqual)(*args, **kwargs)
def assertRaisesRegex(self, *args, **kwargs):
    return getattr(self, _assertRaisesRegex)(*args, **kwargs)
def assertRegex(self, *args, **kwargs):
    return getattr(self, _assertRegex)(*args, **kwargs)
if PY3:
    exec_ = getattr(moves.builtins, Variable4 (u"ࠢࡦࡺࡨࡧࠧ៴"))
    def reraise(tp, value, tb=None):
        if value is None:
            value = tp()
        if value.__traceback__ is not tb:
            raise value.with_traceback(tb)
        raise value
else:
    def exec_(_code_, _globs_=None, _locs_=None):
        Variable4 (u"ࠣࠤࠥࡉࡽ࡫ࡣࡶࡶࡨࠤࡨࡵࡤࡦࠢ࡬ࡲࠥࡧࠠ࡯ࡣࡰࡩࡸࡶࡡࡤࡧ࠱ࠦࠧࠨ៵")
        if _globs_ is None:
            frame = sys._getframe(1)
            _globs_ = frame.f_globals
            if _locs_ is None:
                _locs_ = frame.f_locals
            del frame
        elif _locs_ is None:
            _locs_ = _globs_
        exec(Variable4 (u"ࠤࠥࠦࡪࡾࡥࡤࠢࡢࡧࡴࡪࡥࡠࠢ࡬ࡲࠥࡥࡧ࡭ࡱࡥࡷࡤ࠲ࠠࡠ࡮ࡲࡧࡸࡥࠢࠣࠤ៶"))
    exec_(Variable4 (u"ࠥࠦࠧࡪࡥࡧࠢࡵࡩࡷࡧࡩࡴࡧࠫࡸࡵ࠲ࠠࡷࡣ࡯ࡹࡪ࠲ࠠࡵࡤࡀࡒࡴࡴࡥࠪ࠼ࠍࠤࠥࠦࠠࡳࡣ࡬ࡷࡪࠦࡴࡱ࠮ࠣࡺࡦࡲࡵࡦ࠮ࠣࡸࡧࠐࠢࠣࠤ៷"))
if sys.version_info[:2] == (3, 2):
    exec_(Variable4 (u"ࠦࠧࠨࡤࡦࡨࠣࡶࡦ࡯ࡳࡦࡡࡩࡶࡴࡳࠨࡷࡣ࡯ࡹࡪ࠲ࠠࡧࡴࡲࡱࡤࡼࡡ࡭ࡷࡨ࠭࠿ࠐࠠࠡࠢࠣ࡭࡫ࠦࡦࡳࡱࡰࡣࡻࡧ࡬ࡶࡧࠣ࡭ࡸࠦࡎࡰࡰࡨ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦࡲࡢ࡫ࡶࡩࠥࡼࡡ࡭ࡷࡨࠎࠥࠦࠠࠡࡴࡤ࡭ࡸ࡫ࠠࡷࡣ࡯ࡹࡪࠦࡦࡳࡱࡰࠤ࡫ࡸ࡯࡮ࡡࡹࡥࡱࡻࡥࠋࠤࠥࠦ៸"))
elif sys.version_info[:2] > (3, 2):
    exec_(Variable4 (u"ࠧࠨࠢࡥࡧࡩࠤࡷࡧࡩࡴࡧࡢࡪࡷࡵ࡭ࠩࡸࡤࡰࡺ࡫ࠬࠡࡨࡵࡳࡲࡥࡶࡢ࡮ࡸࡩ࠮ࡀࠊࠡࠢࠣࠤࡷࡧࡩࡴࡧࠣࡺࡦࡲࡵࡦࠢࡩࡶࡴࡳࠠࡧࡴࡲࡱࡤࡼࡡ࡭ࡷࡨࠎࠧࠨࠢ៹"))
else:
    def raise_from(value, from_value):
        raise value
print_ = getattr(moves.builtins, Variable4 (u"ࠨࡰࡳ࡫ࡱࡸࠧ៺"), None)
if print_ is None:
    def print_(*args, **kwargs):
        Variable4 (u"ࠢࠣࠤࡗ࡬ࡪࠦ࡮ࡦࡹ࠰ࡷࡹࡿ࡬ࡦࠢࡳࡶ࡮ࡴࡴࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣࡪࡴࡸࠠࡑࡻࡷ࡬ࡴࡴࠠ࠳࠰࠷ࠤࡦࡴࡤࠡ࠴࠱࠹࠳ࠨࠢࠣ៻")
        fp = kwargs.pop(Variable4 (u"ࠣࡨ࡬ࡰࡪࠨ៼"), sys.stdout)
        if fp is None:
            return
        def write(data):
            if not isinstance(data, basestring):
                data = str(data)
            if (isinstance(fp, file) and
                    isinstance(data, unicode) and
                    fp.encoding is not None):
                errors = getattr(fp, Variable4 (u"ࠤࡨࡶࡷࡵࡲࡴࠤ៽"), None)
                if errors is None:
                    errors = Variable4 (u"ࠥࡷࡹࡸࡩࡤࡶࠥ៾")
                data = data.encode(fp.encoding, errors)
            fp.write(data)
        want_unicode = False
        sep = kwargs.pop(Variable4 (u"ࠦࡸ࡫ࡰࠣ៿"), None)
        if sep is not None:
            if isinstance(sep, unicode):
                want_unicode = True
            elif not isinstance(sep, str):
                raise TypeError(Variable4 (u"ࠧࡹࡥࡱࠢࡰࡹࡸࡺࠠࡣࡧࠣࡒࡴࡴࡥࠡࡱࡵࠤࡦࠦࡳࡵࡴ࡬ࡲ࡬ࠨ᠀"))
        end = kwargs.pop(Variable4 (u"ࠨࡥ࡯ࡦࠥ᠁"), None)
        if end is not None:
            if isinstance(end, unicode):
                want_unicode = True
            elif not isinstance(end, str):
                raise TypeError(Variable4 (u"ࠢࡦࡰࡧࠤࡲࡻࡳࡵࠢࡥࡩࠥࡔ࡯࡯ࡧࠣࡳࡷࠦࡡࠡࡵࡷࡶ࡮ࡴࡧࠣ᠂"))
        if kwargs:
            raise TypeError(Variable4 (u"ࠣ࡫ࡱࡺࡦࡲࡩࡥࠢ࡮ࡩࡾࡽ࡯ࡳࡦࠣࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠦࡴࡰࠢࡳࡶ࡮ࡴࡴࠩࠫࠥ᠃"))
        if not want_unicode:
            for arg in args:
                if isinstance(arg, unicode):
                    want_unicode = True
                    break
        if want_unicode:
            newline = unicode(Variable4 (u"ࠤ࡟ࡲࠧ᠄"))
            space = unicode(Variable4 (u"ࠥࠤࠧ᠅"))
        else:
            newline = Variable4 (u"ࠦࡡࡴࠢ᠆")
            space = Variable4 (u"ࠧࠦࠢ᠇")
        if sep is None:
            sep = space
        if end is None:
            end = newline
        for i, arg in enumerate(args):
            if i:
                write(sep)
            write(arg)
        write(end)
if sys.version_info[:2] < (3, 3):
    _print = print_
    def print_(*args, **kwargs):
        fp = kwargs.get(Variable4 (u"ࠨࡦࡪ࡮ࡨࠦ᠈"), sys.stdout)
        flush = kwargs.pop(Variable4 (u"ࠢࡧ࡮ࡸࡷ࡭ࠨ᠉"), False)
        _print(*args, **kwargs)
        if flush and fp is not None:
            fp.flush()
_add_doc(reraise, Variable4 (u"ࠣࠤࠥࡖࡪࡸࡡࡪࡵࡨࠤࡦࡴࠠࡦࡺࡦࡩࡵࡺࡩࡰࡰ࠱ࠦࠧࠨ᠊"))
if sys.version_info[0:2] < (3, 4):
    def wraps(wrapped, assigned=functools.WRAPPER_ASSIGNMENTS,
              updated=functools.WRAPPER_UPDATES):
        def wrapper(f):
            f = functools.wraps(wrapped, assigned, updated)(f)
            f.__wrapped__ = wrapped
            return f
        return wrapper
else:
    wraps = functools.wraps
def with_metaclass(meta, *bases):
    Variable4 (u"ࠤࠥࠦࡈࡸࡥࡢࡶࡨࠤࡦࠦࡢࡢࡵࡨࠤࡨࡲࡡࡴࡵࠣࡻ࡮ࡺࡨࠡࡣࠣࡱࡪࡺࡡࡤ࡮ࡤࡷࡸ࠴ࠢࠣࠤ᠋")
    class metaclass(meta):
        def __new__(cls, name, this_bases, d):
            return meta(name, bases, d)
    return type.__new__(metaclass, Variable4 (u"ࠪࡸࡪࡳࡰࡰࡴࡤࡶࡾࡥࡣ࡭ࡣࡶࡷࠬ᠌"), (), {})
def add_metaclass(metaclass):
    Variable4 (u"ࠦࠧࠨࡃ࡭ࡣࡶࡷࠥࡪࡥࡤࡱࡵࡥࡹࡵࡲࠡࡨࡲࡶࠥࡩࡲࡦࡣࡷ࡭ࡳ࡭ࠠࡢࠢࡦࡰࡦࡹࡳࠡࡹ࡬ࡸ࡭ࠦࡡࠡ࡯ࡨࡸࡦࡩ࡬ࡢࡵࡶ࠲ࠧࠨࠢ᠍")
    def wrapper(cls):
        orig_vars = cls.__dict__.copy()
        slots = orig_vars.get(Variable4 (u"ࠬࡥ࡟ࡴ࡮ࡲࡸࡸࡥ࡟ࠨ᠎"))
        if slots is not None:
            if isinstance(slots, str):
                slots = [slots]
            for slots_var in slots:
                orig_vars.pop(slots_var)
        orig_vars.pop(Variable4 (u"࠭࡟ࡠࡦ࡬ࡧࡹࡥ࡟ࠨ᠏"), None)
        orig_vars.pop(Variable4 (u"ࠧࡠࡡࡺࡩࡦࡱࡲࡦࡨࡢࡣࠬ᠐"), None)
        return metaclass(cls.__name__, cls.__bases__, orig_vars)
    return wrapper
def python_2_unicode_compatible(klass):
    Variable4 (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡃࠣࡨࡪࡩ࡯ࡳࡣࡷࡳࡷࠦࡴࡩࡣࡷࠤࡩ࡫ࡦࡪࡰࡨࡷࠥࡥ࡟ࡶࡰ࡬ࡧࡴࡪࡥࡠࡡࠣࡥࡳࡪࠠࡠࡡࡶࡸࡷࡥ࡟ࠡ࡯ࡨࡸ࡭ࡵࡤࡴࠢࡸࡲࡩ࡫ࡲࠡࡒࡼࡸ࡭ࡵ࡮ࠡ࠴࠱ࠎࠥࠦࠠࠡࡗࡱࡨࡪࡸࠠࡑࡻࡷ࡬ࡴࡴࠠ࠴ࠢ࡬ࡸࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࡨࡪࡰࡪ࠲ࠏࠐࠠࠡࠢࠣࡘࡴࠦࡳࡶࡲࡳࡳࡷࡺࠠࡑࡻࡷ࡬ࡴࡴࠠ࠳ࠢࡤࡲࡩࠦ࠳ࠡࡹ࡬ࡸ࡭ࠦࡡࠡࡵ࡬ࡲ࡬ࡲࡥࠡࡥࡲࡨࡪࠦࡢࡢࡵࡨ࠰ࠥࡪࡥࡧ࡫ࡱࡩࠥࡧࠠࡠࡡࡶࡸࡷࡥ࡟ࠡ࡯ࡨࡸ࡭ࡵࡤࠋࠢࠣࠤࠥࡸࡥࡵࡷࡵࡲ࡮ࡴࡧࠡࡶࡨࡼࡹࠦࡡ࡯ࡦࠣࡥࡵࡶ࡬ࡺࠢࡷ࡬࡮ࡹࠠࡥࡧࡦࡳࡷࡧࡴࡰࡴࠣࡸࡴࠦࡴࡩࡧࠣࡧࡱࡧࡳࡴ࠰ࠍࠤࠥࠦࠠࠣࠤࠥ᠑")
    if PY2:
        if Variable4 (u"ࠩࡢࡣࡸࡺࡲࡠࡡࠪ᠒") not in klass.__dict__:
            raise ValueError(Variable4 (u"ࠥࡄࡵࡿࡴࡩࡱࡱࡣ࠷ࡥࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡤࡱࡰࡴࡦࡺࡩࡣ࡮ࡨࠤࡨࡧ࡮࡯ࡱࡷࠤࡧ࡫ࠠࡢࡲࡳࡰ࡮࡫ࡤࠡࠤ᠓")
                             Variable4 (u"ࠦࡹࡵࠠࠦࡵࠣࡦࡪࡩࡡࡶࡵࡨࠤ࡮ࡺࠠࡥࡱࡨࡷࡳ࠭ࡴࠡࡦࡨࡪ࡮ࡴࡥࠡࡡࡢࡷࡹࡸ࡟ࡠࠪࠬ࠲ࠧ᠔") %
                             klass.__name__)
        klass.__unicode__ = klass.__str__
        klass.__str__ = lambda self: self.__unicode__().encode(Variable4 (u"ࠬࡻࡴࡧ࠯࠻ࠫ᠕"))
    return klass
__path__ = []
__package__ = __name__
if globals().get(Variable4 (u"ࠨ࡟ࡠࡵࡳࡩࡨࡥ࡟ࠣ᠖")) is not None:
    __spec__.submodule_search_locations = []
if sys.meta_path:
    for i, importer in enumerate(sys.meta_path):
        if (type(importer).__name__ == Variable4 (u"ࠢࡠࡕ࡬ࡼࡒ࡫ࡴࡢࡒࡤࡸ࡭ࡏ࡭ࡱࡱࡵࡸࡪࡸࠢ᠗") and
                importer.name == __name__):
            del sys.meta_path[i]
            break
    del i, importer
sys.meta_path.append(_importer)
