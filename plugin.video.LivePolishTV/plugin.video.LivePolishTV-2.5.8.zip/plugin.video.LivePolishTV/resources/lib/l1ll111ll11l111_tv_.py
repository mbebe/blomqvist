# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib,urlparse
import re
import l1ll11ll1ll11l111_tv_
import l1ll1ll111l11l111_tv_,time
l1llll111ll11l111_tv_=Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡨࡰࡪࡼࡨࡴ࠰ࡳࡰ࠴࠭ᥨ")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠷࠳࠲࠵࠴࠲࠷࠸࠴࠲࠶࠶࠲ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨᥩ")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᥪ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠫࠬᥫ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(Variable4 (u"ࠬࡂ࡬ࡪࠢ࡬ࡨࡂࠨ࡭ࡦࡰࡸ࠱࡮ࡺࡥ࡮࠯࡟ࡨ࠰ࠨࠠࡤ࡮ࡤࡷࡸࡃࠢ࡜ࡠࠥࡡ࠯ࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡪࡲࡥࡷࡪࡶ࠲ࡵࡲ࠯࠯ࠬࡂ࠳࠮ࠨ࠾ࠩ࠰࠮ࡃ࠮ࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠨᥬ")).findall(content)
    for href,title in l1lll1lllll11l111_tv_:
        out.append({Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬᥭ"):title.strip(),Variable4 (u"ࠧࡵࡸ࡬ࡨࠬ᥮"):title.strip(),Variable4 (u"ࠨ࡫ࡰ࡫ࠬ᥯"):Variable4 (u"ࠩࠪᥰ"),Variable4 (u"ࠪࡹࡷࡲࠧᥱ"):href,Variable4 (u"ࠫ࡬ࡸ࡯ࡶࡲࠪᥲ"):Variable4 (u"ࠬ࠭ᥳ"),Variable4 (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭ᥴ"):Variable4 (u"ࠧࠨ᥵")})
    if addheader and len(out):
        t=Variable4 (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࡗࡳࡨࡦࡺࡥࡥ࠼ࠣࠩࡸࠦࠨࡵࡧ࡯ࡩࡻ࡮ࡳࠪ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᥶") %time.strftime(Variable4 (u"ࠤࠨࡨ࠴ࠫ࡭࠰ࠧ࡜࠾ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢ᥷"))
        out.insert(0,{Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ᥸"):t,Variable4 (u"ࠫࡹࡼࡩࡥࠩ᥹"):Variable4 (u"ࠬ࠭᥺"),Variable4 (u"࠭ࡩ࡮ࡩࠪ᥻"):Variable4 (u"ࠧࠨ᥼"),Variable4 (u"ࠨࡷࡵࡰࠬ᥽"):l1llll111ll11l111_tv_,Variable4 (u"ࠩࡪࡶࡴࡻࡰࠨ᥾"):Variable4 (u"ࠪࠫ᥿"),Variable4 (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫᦀ"):Variable4 (u"ࠬ࠭ᦁ")})
    out = l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local={})
    return out
def l111l1lll11l111_tv_(url):
    l1lll1ll11l11l111_tv_=[]
    content = l111111l11l111_tv_(url)
    l1l1lll11ll11l111_tv_ = re.compile(Variable4 (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡩࡧࡴࡤࡱࡪࡄࠧᦂ"),re.DOTALL).findall(content)
    if l1l1lll11ll11l111_tv_:
        l1ll1l1111l11l111_tv_ = l1l1lll11ll11l111_tv_[0]
        l1ll1l11l1l11l111_tv_ = re.compile(Variable4 (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᦃ"),re.DOTALL|re.IGNORECASE).findall(l1ll1l1111l11l111_tv_)
        if l1ll1l11l1l11l111_tv_:
            l1111l11l1l11l111_tv_ = l1ll1l11l1l11l111_tv_[0]
            if l1111l11l1l11l111_tv_.startswith(Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡳࡰࡦࡿࡥࡳ࠰ࡨࡱࡧࡸࡡࡵࡱࡵ࡭ࡦ࠴ࡣࡰ࡯࠲ࡃࡸࡃࠧᦄ")):
                suffix = Variable4 (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨᦅ")+l1lll1l1lll11l111_tv_+Variable4 (u"ࠪࠪࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭ᦆ")+l1111l11l1l11l111_tv_
                l1ll11lll1l11l111_tv_ = l1111l11l1l11l111_tv_.replace(Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡶ࡬ࡢࡻࡨࡶ࠳࡫࡭ࡣࡴࡤࡸࡴࡸࡩࡢ࠰ࡦࡳࡲ࠵࠿ࡴ࠿ࠪᦇ"),Variable4 (u"ࠬ࠭ᦈ"))
                l1lll1ll11l11l111_tv_.append({Variable4 (u"࠭ࡵࡳ࡮ࠪᦉ"):l1ll11lll1l11l111_tv_+suffix,Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᦊ"):Variable4 (u"ࠨࡎ࡬ࡺࡪࠦࠧᦋ")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,Variable4 (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫᦌ"):1})
            else:
                l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠪࡹࡷࡲࠧᦍ"):Variable4 (u"ࠫࠬᦎ"),Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫᦏ"):Variable4 (u"࠭ࠧᦐ"),Variable4 (u"ࠧ࡮ࡵࡪࠫᦑ"):Variable4 (u"ࠨࡑࡧࡲࡴॡ࡮ࡪ࡭ࠣࡨࡴࠦࡳࡵࡴࡲࡲࡾࡀࠠ࡜ࡄࡠࡿࢂࡡ࠯ࡃ࡟ࠪᦒ").format(urlparse.urlparse(l1111l11l1l11l111_tv_).netloc)})
    if not l1lll1ll11l11l111_tv_:
        f1   = re.compile(Variable4 (u"ࠩࠫࡃ࠿ࡹ࡯ࡶࡴࡦࡩࢁ࡬ࡩ࡭ࡧࠬࡠࡸ࠰࠺࡝ࡵ࠭࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩࠥࡡࠬᦓ")).findall(content)
        if   f1:  l1ll11lll1l11l111_tv_ = f1[0]
        else:   l1ll11lll1l11l111_tv_=Variable4 (u"ࠪࠫᦔ")
        if l1ll11lll1l11l111_tv_:
            suffix = Variable4 (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪᦕ")+l1lll1l1lll11l111_tv_+Variable4 (u"ࠬࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࠨᦖ")+url
            l1lll1ll11l11l111_tv_.append({Variable4 (u"࠭ࡵࡳ࡮ࠪᦗ"):l1ll11lll1l11l111_tv_+suffix,Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᦘ"):Variable4 (u"ࠨࡎ࡬ࡺࡪࠦࠧᦙ")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,Variable4 (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫᦚ"):1})
    if not l1lll1ll11l11l111_tv_: l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠪࡹࡷࡲࠧᦛ"):Variable4 (u"ࠫࠬᦜ"),Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫᦝ"):Variable4 (u"࠭ࡎࡪࡥࠪᦞ"),Variable4 (u"ࠧ࡮ࡵࡪࠫᦟ"):Variable4 (u"ࠨࡐ࡬ࡧࠥࡴࡩࡦࠢࡽࡲࡦࡲࡥࡻ࡫ࡲࡲࡴ࠭ᦠ")})
    return l1lll1ll11l11l111_tv_
def test():
    out=l11l11l1l11l111_tv_(addheader=False)
