# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
from urlparse import urlparse
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡰࡤࡸࡻ࠴ࡰ࡭࠱ࠪᵥ")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧᵦ")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᵧ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠪࠫᵨ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    ids = [(a.start(), a.end()) for a in re.finditer(Variable4 (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭ࡨࡴࡲࡹࡵࠨ࠾ࠨᵩ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l1l1lll1lll11l111_tv_ = content[ ids[i][1]:ids[i+1][0] ]
        title = re.compile(Variable4 (u"ࠬࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠭ᵪ")).findall(l1l1lll1lll11l111_tv_)
        href = re.compile(Variable4 (u"࠭࠼ࡢࠢࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭ࡨࡴࡲࡹࡵ࠳ࡩࡵࡧࡰࠤࡰࡧࡴ࠮࡮࡬ࡷࡹࠦ࡭ࡰࡴࡨࡳ࡫ࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠧᵫ")).findall(l1l1lll1lll11l111_tv_)
        l1l11l1lllll11l111_tv_ = re.compile(Variable4 (u"ࠧ࠽࡫ࠣࡧࡱࡧࡳࡴ࠿ࠥࡪࡦࠦࡦࡢࠢࡩࡥ࠲ࡩࡡࡳࡧࡷ࠱ࡷ࡯ࡧࡩࡶࠣࡪࡦ࠳ࡦࡸࠤࡁࡀ࠴࡯࠾ࡍ࡫ࡱ࡯ࡡࡹࠪࠩ࡞ࡧ࠯࠮ࡢࡳࠫࠩᵬ")).findall(l1l1lll1lll11l111_tv_)
        if href and title:
            group = href[0].split(Variable4 (u"ࠨࡁࠪᵭ"))[-1] if Variable4 (u"ࠩࡂࠫᵮ") in href[0] else Variable4 (u"ࠪࠫᵯ")
            l1l11l1lllll11l111_tv_ = l1l11l1lllll11l111_tv_[0] if l1l11l1lllll11l111_tv_ else Variable4 (u"ࠫࡄ࠭ᵰ")
            t = title[0].replace(Variable4 (u"ࠬࠬ࡮ࡣࡵࡳ࠿ࠬᵱ"),Variable4 (u"࠭ࠧᵲ")).replace(Variable4 (u"ࠧࡐࡰ࡯࡭ࡳ࡫ࠧᵳ"),Variable4 (u"ࠨࠩᵴ")).strip()
            code = Variable4 (u"ࡷࠪ࡟ࡑ࡯࡮࡬ࣵࡺ࠾ࠪࡹ࡝ࠡࠧࡶࠫᵵ")%(l1l11l1lllll11l111_tv_,group)
            out.append({Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᵶ"):t,Variable4 (u"ࠫࡹࡼࡩࡥࠩᵷ"):t,Variable4 (u"ࠬ࡯࡭ࡨࠩᵸ"):Variable4 (u"࠭ࠧᵹ"),Variable4 (u"ࠧࡶࡴ࡯ࠫᵺ"):href[0],Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧᵻ"):group,Variable4 (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩᵼ"):Variable4 (u"ࠪࠫᵽ"),Variable4 (u"ࠫࡵࡲ࡯ࡵࠩᵾ"):Variable4 (u"ࠬ࠭ᵿ"),Variable4 (u"࠭ࡣࡰࡦࡨࠫᶀ"):code})
    if addheader and len(out):
        t=Variable4 (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡖࡲࡧࡥࡹ࡫ࡤ࠻ࠢࠨࡷࠥ࠮ࡰࡴࡣ࠰ࡸࡻ࠯࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨᶁ") %time.strftime(Variable4 (u"ࠣࠧࡧ࠳ࠪࡳ࠯࡛ࠦ࠽ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨᶂ"))
        out.insert(0,{Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨᶃ"):t,Variable4 (u"ࠪࡸࡻ࡯ࡤࠨᶄ"):Variable4 (u"ࠫࠬᶅ"),Variable4 (u"ࠬ࡯࡭ࡨࠩᶆ"):Variable4 (u"࠭ࠧᶇ"),Variable4 (u"ࠧࡶࡴ࡯ࠫᶈ"):l1llll111ll11l111_tv_,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧᶉ"):Variable4 (u"ࠩࠪᶊ"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪᶋ"):Variable4 (u"ࠫࠬᶌ")})
    return out
l11ll11l11l11l111_tv_=[Variable4 (u"ࠬࡼ࠲࠯ࡷࡶࡸࡷ࡫ࡡ࡮࡫ࡻ࠲ࡨࡵ࡭ࠨᶍ"),Variable4 (u"࠭ࡵࡴࡶࡵࡩࡦࡳࡩࡹ࠰ࡦࡳࡲ࠭ᶎ"),Variable4 (u"ࠧࡸ࡫ࡱࡸࡪࡾ࠮࡭࡫ࡰࡥ࠲ࡩࡩࡵࡻ࠱ࡨࡪ࠭ᶏ"),Variable4 (u"ࠨࡵࡷࡥࡹ࡯ࡣ࠯ࡷ࠰ࡴࡷࡵ࠮ࡧࡴࠪᶐ"),
    Variable4 (u"ࠩ࡯ࡳࡴࡱ࡮ࡪ࡬࠱࡭ࡳ࠭ᶑ"),Variable4 (u"ࠪࡻ࡮ࢀࡪࡢ࠰ࡷࡺࠬᶒ"),Variable4 (u"ࠫࡼࡽࡷ࠯ࡶࡹࡴ࠳ࡶ࡬ࠨᶓ"),Variable4 (u"ࠬࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢ࠰࡬ࡷࠬᶔ"),Variable4 (u"࠭ࡴࡦ࡮ࡨ࠱ࡼ࡯ࡺ࡫ࡣ࠱ࡧࡴࡳࠧᶕ"),Variable4 (u"ࠧࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠰ࡦࡱࡧࡣ࡬࠰ࡦࡳࡲ࠭ᶖ"),
    Variable4 (u"ࠨࡹࡺࡻ࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧᶗ"),Variable4 (u"ࠩࡧࡥࡷࡳ࡯ࡸࡣ࠰ࡸࡪࡲࡥࡸ࡫ࡽ࡮ࡦ࠴ࡩ࡯ࡨࡲࠫᶘ"),Variable4 (u"ࠪࡸࡻ࠳ࡷࡦࡧࡥ࠲ࡨࡵ࡭ࠨᶙ"),Variable4 (u"ࠫࡴࡪࡰࡢ࡮ࡷࡺ࠳ࡶ࡬ࠨᶚ"),Variable4 (u"ࠬࢀ࡯ࡣࡣࡦࡾࡹࡼ࠮ࡪࡰࡩࡳࠬᶛ"),Variable4 (u"࠭ࡤࡦ࡭ࡲࡨࡪࡸ࠮ࡸࡵ࠲ࡩࡲࡨࡥࡥࠩᶜ")]
def l1llll1ll11l111_tv_(url=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡰࡤࡸࡻ࠴ࡰ࡭࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ࡹࡼࡰ࠲࠯ࡲࡲࡱ࡯࡮ࡦ࠱ࠪᶝ")):
    out=[]
    content = l111111l11l111_tv_(url)
    l11ll1ll1ll11l111_tv_ =re.compile(Variable4 (u"ࠨ࠾ࡧࡸࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵࡣࡵ࡫ࡪࡺ࠽ࠣࡡࡥࡰࡦࡴ࡫ࠣࡀࠪᶞ")).findall(content)
    for l11ll11ll11l111_tv_ in l11ll1ll1ll11l111_tv_:
        l11ll11ll11l111_tv_=Variable4 (u"ࠩ࡫ࡸࡹࡶࠧᶟ")+urllib.unquote(l11ll11ll11l111_tv_).split(Variable4 (u"ࠪ࡬ࡹࡺࡰࠨᶠ"))[-1]
        title = urlparse(l11ll11ll11l111_tv_).netloc
        if Variable4 (u"ࠫࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠴ࡧࡰࡱࡪࡰࡪࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳࠧᶡ") in title:
            l11ll11ll11l111_tv_=Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭ᶢ")+l11ll11ll11l111_tv_.split(Variable4 (u"࠭࠺ࠨᶣ"))[-1]
            title = urlparse(l11ll11ll11l111_tv_).netloc
        if title in l11ll11l11l11l111_tv_:
            title = Variable4 (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡴࡨࡩࡳࡣࠥࡴ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᶤ")%title
        else:
            title = Variable4 (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࠫࡳ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᶥ")%title
        out.append({Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨᶦ"):title,Variable4 (u"ࠪࡸࡻ࡯ࡤࠨᶧ"):title,Variable4 (u"ࠫࡺࡸ࡬ࠨᶨ"):l11ll11ll11l111_tv_})
    return out
def l11ll11l1ll11l111_tv_(url):
    l1ll11lll1l11l111_tv_=Variable4 (u"ࠬ࠭ᶩ")
    try:
        if Variable4 (u"࠭ࡣࡳ࠰ࡳ࡬ࡵ࠭ᶪ") in url:
            content = l111111l11l111_tv_(url)
            data = re.compile(Variable4 (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷࡥࡷ࡭ࡥࡵ࠿ࠥࡣࡧࡲࡡ࡯࡭ࠥࡂࠬᶫ")).findall(content)
            if data:
                l11111l11ll11l111_tv_=Variable4 (u"ࠨࡵࡷࡶࡪࡧ࡭࠾ࠩᶬ")+data[0].split(Variable4 (u"ࠩ࡬ࡨࡂ࠭ᶭ"))[-1]
        else:
            l11111l11ll11l111_tv_=Variable4 (u"ࠪࡷࡹࡸࡥࡢ࡯ࡀࠫᶮ")+url.split(Variable4 (u"ࠫ࡮ࡪ࠽ࠨᶯ"))[-1]
        query = Variable4 (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡵࡴࡶࡵࡩࡦࡳࡩࡹ࠰ࡦࡳࡲ࠵ࠧᶰ")+l11111l11ll11l111_tv_.replace(Variable4 (u"࠭࠽ࠨᶱ"),Variable4 (u"ࠧ࠯ࡲ࡫ࡴࡄ࡯ࡤ࠾ࠩᶲ"))
        content = l111111l11l111_tv_(query,header = {Variable4 (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᶳ"): Variable4 (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡚ࠠࠩ࠴࠵ࡀࠦࡌࡪࡰࡸࡼࠥ࡯࠶࠹࠸࠾ࠤࡷࡼ࠺࠵࠶࠱࠴࠮ࠦࡇࡦࡥ࡮ࡳ࠴࠸࠰࠲࠲࠳࠵࠵࠷ࠠࡇ࡫ࡵࡩ࡫ࡵࡸ࠰࠶࠷࠲࠵ࠦࡉࡤࡧࡺࡩࡦࡹࡥ࡭࠱࠷࠸࠳࠶ࠧᶴ"), Variable4 (u"ࠪࡅࡨࡩࡥࡱࡶࠪᶵ"): Variable4 (u"ࠫ࠯࠵ࠪࠨᶶ")})
        l1lllll111ll11l111_tv_ = re.findall(Variable4 (u"ࠧࡾ࡟ࡧ࡫ࡵࡷࡹࡥࡩࡱ࠰࠮ࡃࠬ࠮࠮ࠫࡁࠬࠫࠧᶷ"), content)[0]
        l111ll111ll11l111_tv_ = [Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴ࡮ࡩ࠱ࡹࡸࡺࡲࡦࡣࡰ࡭ࡽ࠴ࡣࡰ࡯࠲ࠫᶸ"),Variable4 (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯࡬ࡶ࠳࡮ࡵ࡭࡭ࡩ࡭ࡱ࡫ࡳ࠯ࡥࡲࡱ࠴࠭ᶹ")]
        l1111lll1ll11l111_tv_=Variable4 (u"ࠨࠩᶺ")
        for l1llllll1l1l11l111_tv_ in l111ll111ll11l111_tv_:
            l1llllll1l1l11l111_tv_ = l111ll111ll11l111_tv_[0]
            l111l1l111l11l111_tv_ = l1llllll1l1l11l111_tv_ + Variable4 (u"ࠩࡶࡸࡦࡺࡳ࠯ࡲ࡫ࡴࡄࡶ࠽ࠨᶻ") + l1lllll111ll11l111_tv_
            source = l111111l11l111_tv_(l111l1l111l11l111_tv_, header = {Variable4 (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫᶼ"): query, Variable4 (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᶽ"): Variable4 (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡝࠷࠱࠼ࠢࡏ࡭ࡳࡻࡸࠡ࡫࠹࠼࠻ࡁࠠࡳࡸ࠽࠸࠹࠴࠰ࠪࠢࡊࡩࡨࡱ࡯࠰࠴࠳࠵࠵࠶࠱࠱࠳ࠣࡊ࡮ࡸࡥࡧࡱࡻ࠳࠹࠺࠮࠱ࠢࡌࡧࡪࡽࡥࡢࡵࡨࡰ࠴࠺࠴࠯࠲ࠪᶾ"), Variable4 (u"࠭ࡁࡤࡥࡨࡴࡹ࠭ᶿ"): Variable4 (u"ࠧࠫ࠱࠭ࠫ᷀")})
            l1111lll1ll11l111_tv_ = re.findall(Variable4 (u"ࠨࡸࡤࡶࠥࡰࡤࡵ࡭ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᷁"), source)
            if l1111lll1ll11l111_tv_:
                l1111lll1ll11l111_tv_=l1111lll1ll11l111_tv_[0]
                break
        if l1111lll1ll11l111_tv_:
            l1ll11lll1l11l111_tv_= l1llllll1l1l11l111_tv_ + Variable4 (u"ࠩࡷࡱ࡬࠴࡭࠴ࡷ࠻ࡃ᷂ࠬ") + l11111l11ll11l111_tv_.replace(Variable4 (u"ࠪ࠲ࡵ࡮ࡰࡀ࡫ࡧࠫ᷃"),Variable4 (u"ࠫࠬ᷄")) + Variable4 (u"ࠬࠬࡴࡰ࡭ࡨࡲࡂ࠭᷅") + l1111lll1ll11l111_tv_ +Variable4 (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱ࠢࠫ࡜࠶࠷࠻ࠡࡎ࡬ࡲࡺࡾࠠࡪ࠸࠻࠺ࡀࠦࡲࡷ࠼࠷࠸࠳࠶ࠩࠡࡉࡨࡧࡰࡵ࠯࠳࠲࠴࠴࠵࠷࠰࠲ࠢࡉ࡭ࡷ࡫ࡦࡰࡺ࠲࠸࠹࠴࠰ࠡࡋࡦࡩࡼ࡫ࡡࡴࡧ࡯࠳࠹࠺࠮࠱ࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ᷆")+url
    except:
        pass
    print(Variable4 (u"ࠧࡷ࡫ࡧࡳࡤࡻࡲ࡭ࠩ᷇"),l1ll11lll1l11l111_tv_)
    return l1ll11lll1l11l111_tv_
def l111l1lll11l111_tv_(item):
    host = item.get(Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ᷈"))
    url = item.get(Variable4 (u"ࠩࡸࡶࡱ࠭᷉"))
    l1lll1ll11l11l111_tv_=Variable4 (u"᷊ࠪࠫ")
    if Variable4 (u"ࠫࡸࡺࡡࡵ࡫ࡦ࠲ࡺ࠳ࡰࡳࡱ࠱ࡪࡷ࠭᷋") in host or Variable4 (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧ᷌") in url:
        data=Variable4 (u"࠭ࡳࡳࡥࡀࠦࠪࡹࠢࠨ᷍")%url
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif Variable4 (u"ࠧࡥࡧ࡮ࡳࡩ࡫ࡲ࠯ࡹࡶ࠳ࡪࡳࡢࡦࡦ᷎ࠪ") in url:
        from l1llll11l11l111_tv_ import l1ll1111l1l11l111_tv_
        l1lll1ll11l11l111_tv_ = l1ll1111l1l11l111_tv_(url)
    elif Variable4 (u"ࠨࡼࡲࡦࡦࡩࡺࡵࡸ࠱࡭ࡳ࡬࡯ࠨ᷏") in url:
        from l111ll11l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠩࡸࡶࡱ᷐࠭"),Variable4 (u"ࠪࠫ᷑")) if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠫࠬ᷒")
    elif Variable4 (u"ࠬࡵࡤࡱࡣ࡯ࡸࡻ࠴ࡰ࡭ࠩᷓ") in url:
        from l1lll111l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"࠭ࡵࡳ࡮ࠪᷔ"),Variable4 (u"ࠧࠨᷕ")) if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠨࠩᷖ")
    elif Variable4 (u"ࠩࡧࡥࡷࡳ࡯ࡸࡣ࠰ࡸࡻ࠴ࡰ࡭ࠩᷗ") in url:
        from l1llll111l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠪࡹࡷࡲࠧᷘ"),Variable4 (u"ࠫࠬᷙ")) if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠬ࠭ᷚ")
    elif Variable4 (u"࠭ࡴࡦ࡮ࡨࡺ࡭ࡹ࠮ࡱ࡮ࠪᷛ") in url:
        from l1ll111ll11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠧࡶࡴ࡯ࠫᷜ"),Variable4 (u"ࠨࠩᷝ")) if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠩࠪᷞ")
    if Variable4 (u"ࠪࡸࡻ࠳ࡷࡦࡧࡥ࠲ࡨࡵ࡭ࠨᷟ") in url:
        from l1llllll1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠫࡺࡸ࡬ࠨᷠ"),Variable4 (u"ࠬ࠭ᷡ")) if l1lll1ll11l11l111_tv_ else Variable4 (u"࠭ࠧᷢ")
    elif Variable4 (u"ࠧࡸ࡫ࡱࡸࡪࡾ࠮࡭࡫ࡰࡥ࠲ࡩࡩࡵࡻ࠱ࡨࡪ࠭ᷣ") in url:
        from l1l11ll1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠨࡷࡵࡰࠬᷤ"),Variable4 (u"ࠩࠪᷥ")) if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠪࠫᷦ")
    elif Variable4 (u"ࠫࡺࡹࡴࡳࡧࡤࡱ࡮ࡾࠧᷧ") in url:
        l1lll1ll11l11l111_tv_ = l11ll11l1ll11l111_tv_(url)
    elif Variable4 (u"ࠬࡺࡥ࡭ࡧࡺ࡭ࡿࡰࡡ࠮ࡤ࡯ࡥࡨࡱࠧᷨ") in host:
        from l11l111l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"࠭ࡵࡳ࡮ࠪᷩ"),Variable4 (u"ࠧࠨᷪ")) if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠨࠩᷫ")
    elif Variable4 (u"ࠩ࡯ࡳࡴࡱ࡮ࡪ࡬࠱࡭ࡳ࠭ᷬ") in host:
        from l1lll1l1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠪࡹࡷࡲࠧᷭ"),Variable4 (u"ࠫࠬᷮ")) if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠬ࠭ᷯ")
    elif Variable4 (u"࠭ࡷࡪࡼ࡭ࡥ࠳ࡺࡶࠨᷰ") in host:
        from l1l1lllll11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠧࡶࡴ࡯ࠫᷱ"),Variable4 (u"ࠨࠩᷲ"))  if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠩࠪᷳ")
    elif Variable4 (u"ࠪࡨࡦࡸ࡭ࡰࡹࡤ࠱ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠮ࡪࡰࡩࡳࠬᷴ") in host:
        from l11l11l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠫࡺࡸ࡬ࠨ᷵"),Variable4 (u"ࠬ࠭᷶")) if l1lll1ll11l11l111_tv_ else Variable4 (u"᷷࠭ࠧ")
    elif Variable4 (u"ࠧࡵࡧ࡯ࡩ࠲ࡽࡩࡻ࡬ࡤ᷸ࠫ") in host:
        from l11llll1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠨࡷࡵࡰ᷹ࠬ"),Variable4 (u"᷺ࠩࠪ")) if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠪࠫ᷻")
    elif Variable4 (u"ࠫࡼࡽࡷ࠯ࡶࡹࡴ࠳ࡶ࡬ࠨ᷼") in host:
        from l11ll1lll11l111_tv_ import _1l1l11l11l11l111_tv_
        l1lll1ll11l11l111_tv_ = _1l1l11l11l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠬࡻࡲ࡭᷽ࠩ"),Variable4 (u"࠭ࠧ᷾"))  if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠧࠨ᷿")
    return l1lll1ll11l11l111_tv_
