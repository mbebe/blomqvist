# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
from urlparse import urlparse
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡥ࡭ࡧࡺ࡭ࡿࡿࡪ࡬ࡣ࠱ࡴࡱ࠵ࠧᱼ")
l1lll1l1lll11l111_tv_=Variable4 (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬᱽ")
__all__=[Variable4 (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ᱾"),Variable4 (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰ࡛࡯ࡤࡦࡱࠪ᱿"),Variable4 (u"ࠩࡪࡩࡹ࡙ࡴࡳࡧࡤࡱࡸ࠭ᲀ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᲁ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except: l11ll11ll11l111_tv_=Variable4 (u"ࠫࠬᲂ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1l11ll1llll11l111_tv_ = Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡥ࡭ࡧࡺ࡭ࡿࡿࡪ࡬ࡣ࠱ࡴࡱ࠵ࡩ࡯ࡦࡨࡼ࠳ࡶࡨࡱࡁࡷࡺࡂ࠭ᲃ")
    l11llll11ll11l111_tv_ = re.compile(Variable4 (u"࠭࠼ࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨᲄ")).findall(content)
    for ch in l11llll11ll11l111_tv_:
        t=ch
        href=l1l11ll1llll11l111_tv_+urllib.quote_plus(ch)
        out.append({Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᲅ"):t,Variable4 (u"ࠨࡶࡹ࡭ࡩ࠭ᲆ"):t,Variable4 (u"ࠩ࡬ࡱ࡬࠭ᲇ"):Variable4 (u"ࠪࠫᲈ"),Variable4 (u"ࠫࡺࡸ࡬ࠨᲉ"):href,Variable4 (u"ࠬ࡭ࡲࡰࡷࡳࠫᲊ"):Variable4 (u"࠭ࠧ᲋"),Variable4 (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧ᲌"):Variable4 (u"ࠨࠩ᲍"),Variable4 (u"ࠩࡳࡰࡴࡺࠧ᲎"):Variable4 (u"ࠪࠫ᲏"),Variable4 (u"ࠫࡨࡵࡤࡦࠩᲐ"):Variable4 (u"ࠬ࠭Ბ")})
    if addheader and len(out):
        t=Variable4 (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡶࡳࡢ࠯ࡷࡺ࠮ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᲒ") %time.strftime(Variable4 (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠧᲓ"))
        out.insert(0,{Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᲔ"):t,Variable4 (u"ࠩࡷࡺ࡮ࡪࠧᲕ"):Variable4 (u"ࠪࠫᲖ"),Variable4 (u"ࠫ࡮ࡳࡧࠨᲗ"):Variable4 (u"ࠬ࠭Ი"),Variable4 (u"࠭ࡵࡳ࡮ࠪᲙ"):l1llll111ll11l111_tv_,Variable4 (u"ࠧࡨࡴࡲࡹࡵ࠭Ლ"):Variable4 (u"ࠨࠩᲛ"),Variable4 (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩᲜ"):Variable4 (u"ࠪࠫᲝ")})
    return out
l11ll11l11l11l111_tv_=[Variable4 (u"ࠫࡸࡺࡡࡵ࡫ࡦ࠲ࡺ࠳ࡰࡳࡱ࠱ࡪࡷ࠭Პ"),Variable4 (u"ࠬࡺࡥ࡭ࡧࡺ࡭ࡿࡰࡡ࠯࡯࡯ࠫᲟ"),Variable4 (u"࠭ࡴࡦ࡮ࡨࡱࡦࡴࡩࡢ࡭࠱ࡳࡷ࡭ࠧᲠ"),Variable4 (u"ࠧ࡯ࡱࡺࡥࡹࡼ࠮࡯ࡧࡷࠫᲡ"),Variable4 (u"ࠨࡶࡨࡰࡪࡽࡩࡻ࡬ࡤ࠱ࡱ࡯ࡶࡦ࠰ࡦࡳࡲ࠭Ტ"),Variable4 (u"ࠩࡸࡶ࡭ࡪ࠮ࡵࡸࠪᲣ"),
    Variable4 (u"ࠪ࡭ࡰࡲࡵࡣ࠰ࡱࡩࡹ࠭Ფ"),Variable4 (u"ࠫࡱࡵ࡯࡬ࡰ࡬࡮࠳࡯࡮ࠨᲥ"),Variable4 (u"ࠬࡽࡩࡻ࡬ࡤ࠲ࡹࡼࠧᲦ"),Variable4 (u"࠭ࡷࡸࡹ࠱ࡸࡻࡶ࠮ࡱ࡮ࠪᲧ"),Variable4 (u"ࠧࡵࡧ࡯ࡩ࠲ࡽࡩࡻ࡬ࡤ࠲ࡨࡵ࡭ࠨᲨ")]
def l1llll1ll11l111_tv_(url=Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡹ࠱ࡴࡴ࡬ࡪࡰࡨ࠲࡫ࡳ࠯ࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠱ࡴ࡭ࡶ࠿ࡵࡸ࠷ࡃࡵࡵࡤࡴࡶࡤࡻࡴࡽࡥࠨᲩ")):
    out=[]
    content = l111111l11l111_tv_(url)
    l11ll1ll1ll11l111_tv_ =re.compile(Variable4 (u"ࠩࡷࡥࡷ࡭ࡥࡵ࠿ࠥࡣࡧࡲࡡ࡯࡭ࠥࠤࡷ࡫࡬࠾ࠤࡱࡳ࡫ࡵ࡬࡭ࡱࡺࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᲪ")).findall(content)
    for l11ll11ll11l111_tv_ in l11ll1ll1ll11l111_tv_:
        title = urlparse(l11ll11ll11l111_tv_).netloc
        if title in l11ll11l11l11l111_tv_:
            title = Variable4 (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡷ࡫ࡥ࡯࡟ࠨࡷࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ძ")%title
        else:
            title = Variable4 (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࠧࡶ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᲬ")%title
        out.append({Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫᲭ"):title,Variable4 (u"࠭ࡴࡷ࡫ࡧࠫᲮ"):title,Variable4 (u"ࠧࡶࡴ࡯ࠫᲯ"):l11ll11ll11l111_tv_})
    return out
def l111l1lll11l111_tv_(item):
    host = item.get(Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᲰ"))
    url = item.get(Variable4 (u"ࠩࡸࡶࡱ࠭Ჱ"))
    l1lll1ll11l11l111_tv_=Variable4 (u"ࠪࠫᲲ")
    if Variable4 (u"ࠫࡸࡺࡡࡵ࡫ࡦ࠲ࡺ࠳ࡰࡳࡱ࠱ࡪࡷ࠭Ჳ") in host:
        data=Variable4 (u"ࠬࡹࡲࡤ࠿ࠥࠩࡸࠨࠧᲴ")%url
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif Variable4 (u"࠭ࡴࡦ࡮ࡨࡻ࡮ࢀࡪࡢ࠰ࡰࡰࠬᲵ") in url:
        data = l111111l11l111_tv_(url)
        tmp = re.compile(Variable4 (u"ࠧࡴࡴࡦࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩᲶ")).findall(data)
        if tmp:
            if Variable4 (u"ࠨࡶࡨࡰࡪ࠳ࡷࡪࡼ࡭ࡥ࠳ࡩ࡯࡮ࠩᲷ") in tmp[0] or Variable4 (u"ࠩࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥ࠲ࡲࡩࡷࡧ࠱ࡧࡴࡳࠧᲸ") in tmp[0]:
                data = l111111l11l111_tv_(tmp[0])
        l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif Variable4 (u"ࠪࡸࡪࡲࡥ࡮ࡣࡱ࡭ࡦࡱ࠮ࡰࡴࡪࠫᲹ") in url:
        from l1ll1ll1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url.replace(Variable4 (u"ࠫ࠴ࡲࡩࡷࡧ࠲ࠫᲺ"),Variable4 (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࠬ᲻")))
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"࠭ࡵࡳ࡮ࠪ᲼"),Variable4 (u"ࠧࠨᲽ"))
    elif Variable4 (u"ࠨࡰࡲࡻࡦࡺࡶ࠯ࡰࡨࡸࠬᲾ") in url:
        from l1ll1l1l1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url.replace(Variable4 (u"ࠩ࠲ࡰ࡮ࡼࡥ࠰ࠩᲿ"),Variable4 (u"ࠪ࠳ࡩࡧࡴࡢ࠱ࠪ᳀")))
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠫࡺࡸ࡬ࠨ᳁"),Variable4 (u"ࠬ࠭᳂"))
    elif Variable4 (u"࠭ࡵࡳࡪࡧ࠲ࡹࡼࠧ᳃") in host:
        data=Variable4 (u"ࠧࡴࡴࡦࡁࠧࠫࡳࠣࠩ᳄")%url
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif Variable4 (u"ࠨ࡫࡮ࡰࡺࡨ࠮࡯ࡧࡷࠫ᳅") in host:
        from l1l11llll11l111_tv_ import _1l1l11l11l11l111_tv_
        l1lll1ll11l11l111_tv_ = _1l1l11l11l11l111_tv_(url)
    elif Variable4 (u"ࠩ࡯ࡳࡴࡱ࡮ࡪ࡬࠱࡭ࡳ࠭᳆") in host:
        from l1lll1l1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠪࡹࡷࡲࠧ᳇"),Variable4 (u"ࠫࠬ᳈"))
    elif Variable4 (u"ࠬࡽࡩࡻ࡬ࡤ࠲ࡹࡼࠧ᳉") in host:
        from l1l1lllll11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"࠭ࡵࡳ࡮ࠪ᳊"),Variable4 (u"ࠧࠨ᳋"))
    elif Variable4 (u"ࠨࡶࡨࡰࡪࡽࡩࡻ࡬ࡤ࠱ࡱ࡯ࡶࡦ࠰ࡦࡳࡲ࠭᳌") in host:
        data = l111111l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif Variable4 (u"ࠩࡷࡩࡱ࡫࠭ࡸ࡫ࡽ࡮ࡦ࠭᳍") in host:
        data = l111111l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif Variable4 (u"ࠪࡻࡼࡽ࠮ࡵࡸࡳ࠲ࡵࡲࠧ᳎") in host:
        from l11ll1lll11l111_tv_ import _1l1l11l11l11l111_tv_
        l1lll1ll11l11l111_tv_ = _1l1l11l11l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠫࡺࡸ࡬ࠨ᳏"),Variable4 (u"ࠬ࠭᳐"))
    return l1lll1ll11l11l111_tv_
