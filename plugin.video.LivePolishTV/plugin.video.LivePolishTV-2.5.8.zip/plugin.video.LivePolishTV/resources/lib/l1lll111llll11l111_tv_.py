# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable2 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable2) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable2) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡶࡲࡪࡸࡤࡸࡪ࡮ࡤ࠯ࡲࡺࠫᔶ")
l1lll1l1lll11l111_tv_=Variable4 (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬᔷ")
__all__=[Variable4 (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬᔸ"),Variable4 (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰ࡛࡯ࡤࡦࡱࠪᔹ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᔺ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠪࠫᔻ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(Variable4 (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠬᔼ")).findall(content)
    for href,title in l1lll1lllll11l111_tv_:
        out.append({Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫᔽ"):title.strip(),Variable4 (u"࠭ࡴࡷ࡫ࡧࠫᔾ"):title.strip(),Variable4 (u"ࠧࡪ࡯ࡪࠫᔿ"):Variable4 (u"ࠨࠩᕀ"),Variable4 (u"ࠩࡸࡶࡱ࠭ᕁ"):href,Variable4 (u"ࠪ࡫ࡷࡵࡵࡱࠩᕂ"):Variable4 (u"ࠫࠬᕃ"),Variable4 (u"ࠬࡻࡲ࡭ࡧࡳ࡫ࠬᕄ"):Variable4 (u"࠭ࠧᕅ")})
    if addheader and len(out):
        t=Variable4 (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡖࡲࡧࡥࡹ࡫ࡤ࠻ࠢࠨࡷࠥ࠮ࡰࡴࡣ࠰ࡸࡻ࠯࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨᕆ") %time.strftime(Variable4 (u"ࠣࠧࡧ࠳ࠪࡳ࠯࡛ࠦ࠽ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨᕇ"))
        out.insert(0,{Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨᕈ"):t,Variable4 (u"ࠪࡸࡻ࡯ࡤࠨᕉ"):Variable4 (u"ࠫࠬᕊ"),Variable4 (u"ࠬ࡯࡭ࡨࠩᕋ"):Variable4 (u"࠭ࠧᕌ"),Variable4 (u"ࠧࡶࡴ࡯ࠫᕍ"):l1llll111ll11l111_tv_,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧᕎ"):Variable4 (u"ࠩࠪᕏ"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪᕐ"):Variable4 (u"ࠫࠬᕑ")})
    return out
def l111l1lll11l111_tv_(url=Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡷࡽࡵ࡫ࡲࡵࡸ࠱ࡧࡴࡳ࠮ࡱ࡮࠲ࡸࡻࡴࠧᕒ")):
    l1lll1ll11l11l111_tv_=[]
    if Variable4 (u"࠭ࡴࡺࡲࡨࡶࡹࡼࠧᕓ") in url:
        content = l111111l11l111_tv_(url)
        l1ll1l1111l11l111_tv_ = re.compile(Variable4 (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫࠾ࠨᕔ")).findall(content)
        if l1ll1l1111l11l111_tv_:
            src = re.compile(Variable4 (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᕕ"),re.IGNORECASE).findall(l1ll1l1111l11l111_tv_[0])
            if src:
                data = l111111l11l111_tv_(src[0])
                if file :
                    l111111llll11l111_tv_ = file[0].split(Variable4 (u"ࠩࠩࠫᕖ"))[0]
                    href = l111111llll11l111_tv_ + Variable4 (u"ࠪࠤࡸࡽࡦࡖࡴ࡯ࡁࠪࡹࠠ࡭࡫ࡹࡩࡂ࠷ࠠࡵ࡫ࡰࡩࡴࡻࡴ࠾࠳࠳ࠤࡵࡧࡧࡦࡗࡵࡰࡂࠫࡳࠨᕗ")%(src[0],url)
                    l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠫࡺࡸ࡬ࠨᕘ"):href}]
                else:
                    l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,l1111l111ll11l111_tv_)
                    if l1ll11lll1l11l111_tv_: l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠬࡻࡲ࡭ࠩᕙ"):l1ll11lll1l11l111_tv_}]
    return l1lll1ll11l11l111_tv_
