# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
import time
import l1ll11ll1ll11l111_tv_
import cookielib
import urlparse
import threading
import l1ll1ll111l11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡩࡱ࡫࠭ࡸ࡫ࡽ࡮ࡦ࠴ࡩࡴ࠱ࠪᦡ")
l1lll1l1lll11l111_tv_ = Variable4 (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠶࠯࠳࠾ࠤࡷࡼ࠺࠳࠴࠱࠴࠮ࠦࡇࡦࡥ࡮ࡳ࠴࠸࠰࠲࠲࠳࠵࠵࠷ࠠࡇ࡫ࡵࡩ࡫ࡵࡸ࠰࠴࠵࠲࠵࠭ᦢ")
l1lll1ll1ll11l111_tv_=15
__all__=[Variable4 (u"ࠫ࡬࡫ࡴࡄࡪࡤࡲࡳ࡫࡬ࡴࠩᦣ"),Variable4 (u"ࠬ࡭ࡥࡵࡅ࡫ࡥࡳࡴࡥ࡭ࡘ࡬ࡨࡪࡵࠧᦤ")]
fix={
 Variable4 (u"࠭ࡴࡷࡲ࠴ࠫᦥ"):Variable4 (u"ࠧࡕࡘࡓࠤ࠶࠭ᦦ"),
 Variable4 (u"ࠨࡶࡹࡴ࡭ࡪࠧᦧ"): Variable4 (u"ࠩࡗ࡚ࡕࠦࡈࡅࠩᦨ"),
 Variable4 (u"ࠪࡸࡻࡴ࠷ࠨᦩ"):Variable4 (u"࡙ࠫ࡜ࡎࠡ࠹ࠪᦪ"),
 Variable4 (u"ࠬࡶ࡯࡭ࡵࠪᦫ"):Variable4 (u"࠭ࡐࡰ࡮ࡶࡥࡹ࠭᦬"),
 Variable4 (u"ࠧࡢࡰ࡬ࡱࡦࡲࡰ࡭ࡣࡱࡩࡹ࠭᦭"): Variable4 (u"ࠨࡃࡱ࡭ࡲࡧ࡬ࠡࡒ࡯ࡥࡳ࡫ࡴࠨ᦮"),
 Variable4 (u"ࠩࡥࡳࡴࡳࡥࡳࡣࡱ࡫ࠬ᦯"): Variable4 (u"ࠪࡆࡴࡵ࡭ࡦࡴࡤࡲ࡬࠭ᦰ"),
 Variable4 (u"ࠫࡨࡧ࡮ࡢ࡮ࠪᦱ"): Variable4 (u"ࠬࡉࡡ࡯ࡣ࡯࠯ࠬᦲ"),
 Variable4 (u"࠭ࡣࡢࡰࡤࡰࡩ࡯ࡳࡤࡱࡹࡩࡷࡿࠧᦳ"): Variable4 (u"ࠧࡄࡣࡱࡥࡱ࠱ࠠࡅ࡫ࡶࡧࡴࡼࡥࡳࡻࠣࡌࡉ࠭ᦴ"),
 Variable4 (u"ࠨࡥࡤࡲࡦࡲࡦࡢ࡯࡬ࡰࡾ࠭ᦵ"): Variable4 (u"ࠩࡆࡥࡳࡧ࡬ࠬࠢࡉ࡭ࡱࡳࠧᦶ"),
 Variable4 (u"ࠪࡧࡦࡴࡡ࡭ࡵࡳࡳࡷࡺࠧᦷ"): Variable4 (u"ࠫࡈࡧ࡮ࡢ࡮࠮ࠤࡘࡶ࡯ࡳࡶࠪᦸ"),
 Variable4 (u"ࠬࡩࡡ࡯ࡣ࡯ࡷࡵࡵࡲࡵ࠴ࠪᦹ"): Variable4 (u"࠭ࡃࡢࡰࡤࡰ࠰ࠦࡓࡱࡱࡵࡸࠥ࠸ࠧᦺ"),
 Variable4 (u"ࠧࡤࡣࡵࡸࡴࡵ࡮ࠨᦻ"): Variable4 (u"ࠨࡅࡤࡶࡹࡵ࡯࡯ࠢࡑࡩࡹࡽ࡯ࡳ࡭ࠪᦼ"),
 Variable4 (u"ࠩࡦࡪ࡮ࡲ࡭ࠨᦽ"): Variable4 (u"ࠪࡇࡦࡴࡡ࡭࠭ࠣࡊ࡮ࡲ࡭ࠨᦾ"),
 Variable4 (u"ࠫࡨ࡯࡮ࡦ࡯ࡤࡼࠬᦿ"): Variable4 (u"ࠬࡉࡩ࡯ࡧࡰࡥࡽ࠭ᧀ"),
 Variable4 (u"࠭ࡣࡰ࡯ࡨࡨࡾࡩࡥ࡯ࡶࡨࡶࠬᧁ"): Variable4 (u"ࠧࡄࡱࡰࡩࡩࡿࠠࡄࡧࡱࡸࡷࡧ࡬ࠨᧂ"),
 Variable4 (u"ࠨࡦ࡬ࡷࡨࡵࡶࡦࡴࡼࠫᧃ"): Variable4 (u"ࠩࡇ࡭ࡸࡩ࡯ࡷࡧࡵࡽࠥࡉࡨࡢࡰࡱࡩࡱ࠭ᧄ"),
 Variable4 (u"ࠪࡨ࡮ࡹࡣࡰࡸࡨࡶࡾ࡮ࡩࡴࡶࡲࡶ࡮ࡧࠧᧅ"): Variable4 (u"ࠫࡉ࡯ࡳࡤࡱࡹࡩࡷࡿࠠࡉ࡫ࡶࡸࡴࡸࡩࡢࠩᧆ"),
 Variable4 (u"ࠬࡪࡩࡴࡥࡲࡺࡪࡸࡹ࡭࡫ࡩࡩࠬᧇ"): Variable4 (u"࠭ࡄࡪࡵࡦࡳࡻ࡫ࡲࡺࠢࡏ࡭࡫࡫ࠧᧈ"),
 Variable4 (u"ࠧࡥ࡫ࡶࡧࡴࡼࡥࡳࡻࡶࠫᧉ"): Variable4 (u"ࠨࡆ࡬ࡷࡨࡵࡶࡦࡴࡼࠤࡘࡩࡩࡦࡰࡦࡩࠬ᧊"),
 Variable4 (u"ࠩࡧ࡭ࡸࡴࡥࡺ࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࠪ᧋"): Variable4 (u"ࠪࡈ࡮ࡹ࡮ࡦࡻࠣࡇ࡭ࡧ࡮࡯ࡧ࡯ࠫ᧌"),
 Variable4 (u"ࠫࡪࡲࡥࡷࡧࡱࠫ᧍"): Variable4 (u"ࠬࡋ࡬ࡦࡸࡨࡲࠬ᧎"),
 Variable4 (u"࠭ࡥ࡭ࡧࡹࡩࡳࡹࡰࡰࡴࡷࠫ᧏"): Variable4 (u"ࠧࡆ࡮ࡨࡺࡪࡴࠠࡔࡲࡲࡶࡹࡹࠧ᧐"),
 Variable4 (u"ࠨࡧࡸࡶࡴࡹࡰࡰࡴࡷࠫ᧑"): Variable4 (u"ࠩࡈࡹࡷࡵࡳࡱࡱࡵࡸࠬ᧒"),
 Variable4 (u"ࠪࡩࡺࡸ࡯ࡴࡲࡲࡶࡹ࠸ࠧ᧓"): Variable4 (u"ࠫࡊࡻࡲࡰࡵࡳࡳࡷࡺࠠ࠳ࠩ᧔"),
 Variable4 (u"ࠬ࡬࡯ࡹࠩ᧕"): Variable4 (u"࠭ࡆࡰࡺࠪ᧖"),
 Variable4 (u"ࠧࡩ࠴ࠣࠫ᧗"): Variable4 (u"ࠨࡊ࡬ࡷࡹࡵࡲࡺࠢ࠵ࠤࠬ᧘"),
 Variable4 (u"ࠩ࡫ࡦࡴ࠭᧙"): Variable4 (u"ࠪࡌࡇࡕࠧ᧚"),
 Variable4 (u"ࠫ࡭ࡨ࡯࠳ࠩ᧛"): Variable4 (u"ࠬࡎࡂࡐ࠴ࠪ᧜"),
 Variable4 (u"࠭ࡨࡣࡱ࠶ࠫ᧝"): Variable4 (u"ࠧࡉࡄࡒ࠷ࠬ᧞"),
 Variable4 (u"ࠨ࡫ࡧࠫ᧟"): Variable4 (u"ࠩࡌࡈࠬ᧠"),
 Variable4 (u"ࠪ࡯࡮ࡴ࡯ࡱࡱ࡯ࡷࡰࡧࠧ᧡"): Variable4 (u"ࠫࡐ࡯࡮ࡰࠢࡓࡳࡱࡹ࡫ࡢࠩ᧢"),
 Variable4 (u"ࠬࡱࡵࡤࡪࡨࡲࡪ࠭᧣"): Variable4 (u"࠭ࡋࡶࡥ࡫ࡲ࡮ࡧࠫࠨ᧤"),
 Variable4 (u"ࠧ࡮࡫ࡱ࡭ࡲ࡯࡮ࡪࠩ᧥"): Variable4 (u"ࠨࡏ࡬ࡲ࡮ࡳࡩ࡯࡫࠮ࠫ᧦"),
 Variable4 (u"ࠩࡱࡥࡹ࡭ࡥࡰࠩ᧧"): Variable4 (u"ࠪࡒࡦࡺࡩࡰࡰࡤࡰࠥࡍࡥࡰࡩࡵࡥࡵ࡮ࡩࡤࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ࠪ᧨"),
 Variable4 (u"ࠫࡳࡧࡴࡨࡧࡲࡻ࡮ࡲࡤࠨ᧩"): Variable4 (u"ࠬࡔࡡࡵࠢࡊࡩࡴࠦࡗࡪ࡮ࡧࠫ᧪"),
 Variable4 (u"࠭࡮ࡴࡲࡲࡶࡹ࠭᧫"): Variable4 (u"ࠧ࡯ࡕࡳࡳࡷࡺࠧ᧬"),
 Variable4 (u"ࠨࡵࡷࡳࡵࡱ࡬ࡢࡶ࡮ࡥࠬ᧭"): Variable4 (u"ࠩࡖࡸࡴࡶ࡫࡭ࡣࡷ࡯ࡦࠦࡔࡗࠩ᧮"),
 Variable4 (u"ࠪࡸࡱࡩࠧ᧯"): Variable4 (u"࡙ࠫࡒࡃࠨ᧰"),
 Variable4 (u"ࠬࡺࡶ࡯ࠩ᧱"): Variable4 (u"࠭ࡔࡗࡐࠪ᧲"),
 Variable4 (u"ࠧࡵࡸࡱ࠶࠹࠭᧳"): Variable4 (u"ࠨࡖ࡙ࡒࠥ࠸࠴ࠨ᧴"),
 Variable4 (u"ࠩࡷࡺࡳ࠸࠴ࡣ࡫ࡶࠫ᧵"): Variable4 (u"ࠪࡘ࡛ࡔࠠ࠳࠶ࠣࡆࡎ࡙ࠧ᧶"),
 Variable4 (u"ࠫࡹࡼ࡮࠸ࠩ᧷"): Variable4 (u"࡚ࠬࡖࡏࠢ࠺ࠫ᧸"),
 Variable4 (u"࠭ࡴࡷࡰࡶࡸࡾࡲࡥࠨ᧹"): Variable4 (u"ࠧࡕࡘࡑࠤࡘࡺࡹ࡭ࡧࠪ᧺"),
 Variable4 (u"ࠨࡶࡹࡲࡹࡻࡲࡣࡱࠪ᧻"): Variable4 (u"ࠩࡗ࡚ࡓࠦࡔࡶࡴࡥࡳࠬ᧼"),
 Variable4 (u"ࠪࡸࡻࡶ࠱ࠨ᧽"): Variable4 (u"࡙ࠫ࡜ࡐࠡ࠳ࠪ᧾"),
 Variable4 (u"ࠬࡺࡶࡱ࠴ࠪ᧿"): Variable4 (u"࠭ࡔࡗࡒࠣ࠶ࠬᨀ"),
 Variable4 (u"ࠧࡵࡸࡳ࡬ࡩ࠭ᨁ"): Variable4 (u"ࠨࡖ࡙ࡔࠥࡎࡄࠨᨂ"),
 Variable4 (u"ࠩࡷࡺࡵ࡯࡮ࡧࡱ࠴ࠫᨃ"): Variable4 (u"ࠪࡘ࡛ࡖࠠࡊࡰࡩࡳࠬᨄ"),
 Variable4 (u"ࠫࡹࡼࡰࡴࡧࡵ࡭ࡦࡲࡥࠨᨅ"): Variable4 (u"࡚ࠬࡖࡑࠢࡖࡩࡷ࡯ࡡ࡭ࡧࠪᨆ"),
 Variable4 (u"࠭ࡴࡷࡲࡶࡴࡴࡸࡴࠨᨇ"): Variable4 (u"ࠧࡕࡘࡓࠤࡘࡶ࡯ࡳࡶࠪᨈ"),
 Variable4 (u"ࠨࡶࡹࡴࡺࡲࡳࠨᨉ"): Variable4 (u"ࠩࡗ࡚ࠥࡖࡵ࡭ࡵࠪᨊ"),
 Variable4 (u"ࠪࡸࡻࡸࡥࡱࡷࡥࡰ࡮ࡱࡡࠨᨋ"): Variable4 (u"࡙ࠫ࡜ࠠࡓࡧࡳࡹࡧࡲࡩ࡬ࡣࠪᨌ"),
 Variable4 (u"ࠬࡾࡴࡳࡣࠪᨍ"): Variable4 (u"࠭ࡄࡪࡵࡦࡳࡻ࡫ࡲࡺࠢࡗࡹࡷࡨ࡯࡚ࠡࡷࡶࡦ࠭ᨎ"),
 Variable4 (u"ࠧࡱࡵࠪᨏ"):Variable4 (u"ࠨࡒࡲࡰࡸࡧࡴࠡࡕࡳࡳࡷࡺࠧᨐ"),
 Variable4 (u"ࠩࡳࡷࡳ࠭ᨑ"):Variable4 (u"ࠪࡔࡴࡲࡳࡢࡶࠣࡗࡵࡵࡲࡵࠢࡑࡩࡼࡹࠧᨒ"),
 Variable4 (u"ࠫࡵࡹࡥࠨᨓ"):Variable4 (u"ࠬࡖ࡯࡭ࡵࡤࡸ࡙ࠥࡰࡰࡴࡷࠤࡊࡾࡴࡳࡣࠪᨔ"),
 Variable4 (u"࠭ࡳࡶࡲࡨࡶࡸࡺࡡࡤ࡬ࡤࠫᨕ"):Variable4 (u"ࠧࡔࡷࡳࡩࡷࡹࡴࡢࡥ࡭ࡥࠬᨖ"),
 Variable4 (u"ࠨࡲࡲࡰࡸ࠭ᨗ"):Variable4 (u"ࠩࡓࡳࡱࡹࡡࡵᨘࠩ"),
 Variable4 (u"ࠪࡸࡻࡼ࠴ࠨᨙ"):Variable4 (u"࡙ࠫ࡜ࠠ࠵ࠩᨚ"),
 Variable4 (u"ࠬࡶ࡯࡭ࡵ࠵ࠫᨛ"):Variable4 (u"࠭ࡐࡰ࡮ࡶࡥࡹࠦ࠲ࠨ᨜"),
 Variable4 (u"ࠧࡱࡱ࡯ࡷࡦࡺࡣࡢࡨࡨࠫ᨝"):Variable4 (u"ࠨࡒࡲࡰࡸࡧࡴࠡࡅࡤࡪࡪ࠭᨞"),
 Variable4 (u"ࠩࡳࡳࡱࡹࡡࡵࡲ࡯ࡥࡾ࠭᨟"):Variable4 (u"ࠪࡔࡴࡲࡳࡢࡶࠣࡔࡱࡧࡹࠨᨠ"),
 Variable4 (u"ࠫࡵࡵ࡬ࡴࡣࡷࡪ࡮ࡲ࡭ࠨᨡ"):Variable4 (u"ࠬࡖ࡯࡭ࡵࡤࡸࠥࡌࡩ࡭࡯ࠪᨢ"),
 Variable4 (u"࠭ࡰࡰ࡮ࡶࡥࡹࡴࡡࡵࡷࡵࡩࠬᨣ"):Variable4 (u"ࠧࡑࡱ࡯ࡷࡦࡺࠠࡏࡣࡷࡹࡷ࡫ࠧᨤ"),
 Variable4 (u"ࠨࡲࡲࡰࡸࡧࡴࡩ࡫ࡶࡸࡴࡸࡹࠨᨥ"):Variable4 (u"ࠩࡓࡳࡱࡹࡡࡵࠢࡋ࡭ࡸࡺ࡯ࡳࡻࠪᨦ"),
 Variable4 (u"ࠪࡴࡴࡲࡳࡢࡶࡨࡼࡵࡲ࡯ࡳࡧࠪᨧ"):Variable4 (u"ࠫࡕࡵ࡬ࡴࡣࡷࠤࡊࡾࡰ࡭ࡱࡵࡩࠬᨨ"),
 Variable4 (u"ࠬࡶ࡯࡭ࡵࡤࡸ࡫ࡵ࡯ࡥࠩᨩ"):Variable4 (u"࠭ࡐࡰ࡮ࡶࡥࡹࠦࡆࡰࡱࡧࠫᨪ"),
 Variable4 (u"ࠧࡱࡵࡩࠫᨫ"):Variable4 (u"ࠨࡒࡲࡰࡸࡧࡴࠡࡕࡳࡳࡷࡺࠠࡇ࡫ࡪ࡬ࡹ࠭ᨬ"),
 Variable4 (u"ࠩࡶࡹࡵ࡫ࡲࡱࡱ࡯ࡷࡦࡺࠧᨭ"):Variable4 (u"ࠪࡗࡺࡶࡥࡳࠢࡓࡳࡱࡹࡡࡵࠩᨮ"),
 Variable4 (u"ࠫࡼࡶࡴࡷࠩᨯ"):Variable4 (u"ࠬ࡝ࡐࡕࡘࠪᨰ"),
 Variable4 (u"࠭ࡰࡰ࡮ࡱࡩࡼࡹࠧᨱ"):Variable4 (u"ࠧࡑࡱ࡯ࡷࡦࡺࠠࡏࡧࡺࡷࠬᨲ"),
 Variable4 (u"ࠨࡲࡲࡰࡸࡧࡴ࡯ࡧࡺࡷ࠷࠭ᨳ"):Variable4 (u"ࠩࡓࡳࡱࡹࡡࡵࠢࡑࡩࡼࡹࠠ࠳ࠩᨴ"),
 Variable4 (u"ࠪࡸࡻࡺࡲࡸࡣࡰࠫᨵ"):Variable4 (u"࡙ࠫ࡜ࠠࡕࡴࡺࡥࡲ࠭ᨶ"),
 Variable4 (u"ࠬࡩࡡ࡯ࡣ࡯ࡷࡪࡸࡩࡢ࡮ࡨࠫᨷ"): Variable4 (u"࠭ࡃࡢࡰࡤࡰ࠰ࠦࡓࡦࡴ࡬ࡥࡱ࡫ࠧᨸ"),
 Variable4 (u"ࠧ࠲࠵ࡸࡰ࡮ࡩࡡࠨᨹ"):Variable4 (u"ࠨ࠳࠶ࠤ࡚ࡲࡩࡤࡣࠪᨺ"),
 Variable4 (u"ࠩࡩ࡭ࡱࡳࡢࡰࡺࠪᨻ"):Variable4 (u"ࠪࡊ࡮ࡲ࡭ࡣࡱࡻࠫᨼ"),
 Variable4 (u"ࠫ࡫࡯࡬࡮ࡤࡲࡼࡪࡾࡴࡳࡣࠪᨽ"):Variable4 (u"ࠬࡌࡩ࡭࡯ࡥࡳࡽࠦࡅࡹࡶࡵࡥࠬᨾ"),
 Variable4 (u"࠭ࡦࡪ࡮ࡰࡦࡴࡾࡰࡳࡧࡰ࡭ࡺࡳࠧᨿ"):Variable4 (u"ࠧࡇ࡫࡯ࡱࡧࡵࡸࠡࡒࡵࡩࡲ࡯ࡵ࡮ࠩᩀ"),
 Variable4 (u"ࠨࡨ࡬ࡰࡲࡨ࡯ࡹࡧࡻࡸࡷࡧࠧᩁ"):Variable4 (u"ࠩࡉ࡭ࡱࡳࡢࡰࡺࠣࡉࡽࡺࡲࡢࠩᩂ"),
 Variable4 (u"ࠪࡪ࡮ࡲ࡭ࡣࡱࡻࡥࡨࡺࡩࡰࡰࠪᩃ"):Variable4 (u"ࠫࡋ࡯࡬࡮ࡤࡲࡼࠥࡇࡣࡵ࡫ࡲࡲࠬᩄ"),
 Variable4 (u"ࠬ࡬ࡩ࡭࡯ࡥࡳࡽ࡬ࡡ࡮࡫࡯ࡽࠬᩅ"):Variable4 (u"࠭ࡆࡪ࡮ࡰࡦࡴࡾࠠࡇࡣࡰ࡭ࡱࡿࠧᩆ"),
 Variable4 (u"ࠧࡢࡺࡱࠫᩇ"):Variable4 (u"ࠣࡃ࡛ࡒࠧᩈ"),
 Variable4 (u"ࠩࡤࡼࡳࡹࡰࡪࡰࠪᩉ"):Variable4 (u"ࠪࡅ࡝ࡔࠠࡔࡲ࡬ࡲࠬᩊ"),
 Variable4 (u"ࠫࡦࡾ࡮ࡣ࡮ࡤࡧࡰ࠭ᩋ"):Variable4 (u"ࠬࡇࡘࡏࠢࡅࡰࡦࡩ࡫ࠨᩌ"),
 Variable4 (u"࠭ࡡࡹࡰࡺ࡬࡮ࡺࡥࠨᩍ"):Variable4 (u"ࠧࡂ࡚ࡑࠤ࡜࡮ࡩࡵࡧࠪᩎ"),
 Variable4 (u"ࠨࡥࡥࡷࡷ࡫ࡡ࡭࡫ࡷࡽࠬᩏ"):Variable4 (u"ࠩࡆࡆࡘࠦࡒࡦࡣ࡯࡭ࡹࡿࠧᩐ"),
 Variable4 (u"ࠪࡧࡧࡹࡡࡤࡶ࡬ࡳࡳ࠭ᩑ"):Variable4 (u"ࠫࡈࡈࡓࠡࡃࡦࡸ࡮ࡵ࡮ࠨᩒ"),
 Variable4 (u"ࠬࡩࡢࡴࡧࡸࡶࡴࡶࡡࠨᩓ"):Variable4 (u"࠭ࡃࡃࡕࠣࡉࡺࡸ࡯ࡱࡣࠪᩔ"),
 Variable4 (u"ࠧࡱࡣࡵࡥࠬᩕ"):Variable4 (u"ࠨࡒࡤࡶࡦࡳ࡯ࡶࡰࡷࠤࡈ࡮ࡡ࡯ࡰࡨࡰࠬᩖ"),
 Variable4 (u"ࠩࡷࡲࡹ࠭ᩗ"):Variable4 (u"ࠪࡘࡓ࡚ࠧᩘ"),
 Variable4 (u"ࠫ࡫ࡵࡸࡤࡱࡰࡩࡩࡿࠧᩙ"):Variable4 (u"ࠬࡌ࡯ࡹࠢࡆࡳࡲ࡫ࡤࡺࠩᩚ"),
 Variable4 (u"࠭ࡳࡤࡨ࡬࠵ࠬᩛ"):Variable4 (u"ࠧࡔࡥ࡬ࡊ࡮ࠦࡕ࡯࡫ࡹࡩࡷࡹࡡ࡭ࠩᩜ"),
 Variable4 (u"ࠨࡷࡱ࡭ࡻ࡫ࡲࡴࡣ࡯ࠫᩝ"):Variable4 (u"ࠩࡘࡲ࡮ࡼࡥࡳࡵࡤࡰࠥࡎࡄࠨᩞ"),
 Variable4 (u"ࠪࡦࡧࡩࠧ᩟"):Variable4 (u"ࠫࡇࡈࡃࠡࡊࡇ᩠ࠫ"),
 Variable4 (u"ࠬࡨࡢࡤࡧࡤࡶࡹ࡮ࠧᩡ"):Variable4 (u"࠭ࡂࡃࡅࠣࡉࡦࡸࡴࡩࠩᩢ"),
 Variable4 (u"ࠧࡩ࡫ࡶࡸࡴࡸࡹࠨᩣ"):Variable4 (u"ࠨࡊ࡬ࡷࡹࡵࡲࡺࠩᩤ"),
 Variable4 (u"ࠩࡩࡳࡨࡻࡳࡵࡸࠪᩥ"):Variable4 (u"ࠪࡊࡴࡱࡵࡴࠢࡗ࡚ࠬᩦ"),
 Variable4 (u"ࠫࡪࡲࡥࡷࡧࡱࡩࡽࡺࡲࡢࠩᩧ"):Variable4 (u"ࠬࡋ࡬ࡦࡸࡨࡲ࡙ࠥࡰࡰࡴࡷࡷࠬᩨ"),
 Variable4 (u"࠭ࡥࡹࡶࡵࡩࡲ࡫ࡳࡱࡱࡵࡸࡸ࠭ᩩ"):Variable4 (u"ࠧࡆࡺࡷࡶࡪࡳࡥࠡࡕࡳࡳࡷࡺࡳࠨᩪ"),
 Variable4 (u"ࠨࡶࡵࡥࡻ࡫࡬ࡤࡪࡤࡲࡳ࡫࡬ࠨᩫ"):Variable4 (u"ࠩࡗࡶࡦࡼࡥ࡭ࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ࠪᩬ"),
 Variable4 (u"ࠪࡨ࡮ࡹ࡮ࡦࡻࡻࡨࠬᩭ"):Variable4 (u"ࠫࡉ࡯ࡳ࡯ࡧࡼࠤ࡝ࡊࠧᩮ"),
 Variable4 (u"ࠬࡪࡩࡴࡰࡨࡽ࡯ࡻ࡮ࡪࡱࡵࠫᩯ"):Variable4 (u"࠭ࡄࡪࡵࡱࡩࡾࠦࡊࡶࡰ࡬ࡳࡷ࠭ᩰ"),
 Variable4 (u"ࠧࡥ࡫ࡶࡲࡪࡿࠧᩱ"):Variable4 (u"ࠨࡆ࡬ࡷࡳ࡫ࡹࠡࡅ࡫ࡥࡳࡴࡥ࡭ࠩᩲ"),
 Variable4 (u"ࠩࡱ࡭ࡨࡱࡥ࡭ࡱࡧࡩࡴࡴࠧᩳ"):Variable4 (u"ࠪࡒ࡮ࡩ࡫ࡦ࡮ࡲࡨࡪࡵ࡮ࠨᩴ"),
 Variable4 (u"ࠫࡨࡴࠧ᩵"):Variable4 (u"ࠬࡉࡡࡳࡶࡲࡳࡳࠦࡎࡦࡶࡺࡳࡷࡱࠧ᩶"),
 Variable4 (u"࠭ࡦࡪࡩ࡫ࡸࡧࡵࡸࠨ᩷"):Variable4 (u"ࠧࡇ࡫ࡪ࡬ࡹࠦࡂࡰࡺࠪ᩸"),
 }
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠨࡶࡹ࡭ࡩ࠭᩹")),Variable4 (u"ࠩࠪ᩺"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ᩻")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[Variable4 (u"ࠫࡹࡼࡩࡥࠩ᩼")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
local={
Variable4 (u"ࠧࡎ࠲ࠣ᩽"):Variable4 (u"ࠨࠨࡩࠪ࡞ࡠࡸ࠰࠭࡞࠴ࠬࡃ࠭ࡡ࡜ࡴࠬ࠰ࡡࡍࡊࠩࡀࠫࠥ᩾"),
Variable4 (u"ࠢࡑࡱ࡯ࡷࡦࡺ᩿ࠢ"):Variable4 (u"ࠣࠪࡓࡳࡠ࠳࡝࡭ࡵࡤࡸ࠭ࡡ࡜ࡴࠬ࠰ࡡ࡙࡜ࠩࡀࠪ࡞ࡠࡸ࠰࠭࡞ࡊࡇ࠭ࡄ࠯ࠢ᪀"),
}
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=Variable4 (u"ࠩࠪ᪁")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ᪂"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = Variable4 (u"ࠫࠬ᪃").join([Variable4 (u"ࠬࠫࡳ࠾ࠧࡶ࠿ࠬ᪄")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except:
        l11ll11ll11l111_tv_ = Variable4 (u"࠭ࠧ᪅")
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def l1l1lll111l11l111_tv_(url, l1ll111l1ll11l111_tv_, index):
    out = l1l1l1lllll11l111_tv_(url)
    l1ll111l1ll11l111_tv_[index]=out
def l11l11l1l11l111_tv_(addheader=False):
    out=[]
    l1l111lllll11l111_tv_ = list()
    l1l1llll111l11l111_tv_=[Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡵࡧ࡯ࡩ࠲ࡽࡩࡻ࡬ࡤ࠲࡮ࡹ࠯࠳ࡱࡪࡳࡱࡴࡥࠨ᪆"),Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡨࡰࡪ࠳ࡷࡪࡼ࡭ࡥ࠳࡯ࡳ࠰࡫ࡱࡪࡴ࠭᪇"),
            Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡩࡱ࡫࠭ࡸ࡫ࡽ࡮ࡦ࠴ࡩࡴ࠱ࡩ࡭ࡱࡳ࡯ࡸࡧࠪ᪈"),Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡪࡲࡥ࠮ࡹ࡬ࡾ࡯ࡧ࠮ࡪࡵ࠲ࡲࡦࡻ࡫ࡰࡹࡨࠫ᪉"),
            Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹ࡫࡬ࡦ࠯ࡺ࡭ࡿࡰࡡ࠯࡫ࡶ࠳ࡸࡶ࡯ࡳࡶࡲࡻࡪ࠭᪊"),Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢ࠰࡬ࡷ࠴ࡨࡡ࡫࡭ࡲࡻࡪ࠭᪋")]
    l1ll111l1ll11l111_tv_ = [[] for x in l1l1llll111l11l111_tv_]
    for i,url in enumerate(l1l1llll111l11l111_tv_):
        thread = threading.Thread(name=Variable4 (u"࠭ࡔࡩࡴࡨࡥࡩࠫࡤࠨ᪌")%i, target = l1l1lll111l11l111_tv_, args=[url,l1ll111l1ll11l111_tv_,i])
        l1l111lllll11l111_tv_.append(thread)
        thread.start()
    while any([i.isAlive() for i in l1l111lllll11l111_tv_]): time.sleep(0.1)
    del l1l111lllll11l111_tv_[:]
    for l1l1l1ll11l111_tv_ in l1ll111l1ll11l111_tv_:
        out.extend(l1l1l1ll11l111_tv_)
    if addheader and len(out):
        t=Variable4 (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡖࡲࡧࡥࡹ࡫ࡤ࠻ࠢࠨࡷࠥ࠮ࡴࡦ࡮ࡨ࠱ࡼ࡯ࡺ࡫ࡣࠬ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᪍") %time.strftime(Variable4 (u"ࠣࠧࡧ࠳ࠪࡳ࠯࡛ࠦ࠽ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨ᪎"))
        out.insert(0,{Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨ᪏"):t,Variable4 (u"ࠪࡸࡻ࡯ࡤࠨ᪐"):Variable4 (u"ࠫࠬ᪑"),Variable4 (u"ࠬ࡯࡭ࡨࠩ᪒"):Variable4 (u"࠭ࠧ᪓"),Variable4 (u"ࠧࡶࡴ࡯ࠫ᪔"):l1llll111ll11l111_tv_,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧ᪕"):Variable4 (u"ࠩࠪ᪖"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪ᪗"):Variable4 (u"ࠫࠬ᪘")})
    return out
def l1l1l1lllll11l111_tv_(url=Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢ࠰࡬ࡷ࠴࠸࡯ࡨࡱ࡯ࡲࡪ࠭᪙")):
    out=[]
    content,c = l111111l11l111_tv_(url)
    code=url.split(Variable4 (u"࠭࠯ࠨ᪚"))[-1].replace(Variable4 (u"ࠧ࠳ࠩ᪛"),Variable4 (u"ࠨࠩ᪜"))
    items = re.compile(Variable4 (u"ࠩ࠿ࡸࡩࠦࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮ࡸࡱࡳ࠴ࠫࡀࡪࡵࡩ࡫ࡃ࡛ࠣ࡞ࠪࡡ࠭ࡡ࡞ࠣ࡞ࠪࡡ࠰࠯࡛ࠣ࡞ࠪࡡ࠳࠱࠿࠽࡫ࡰ࡫ࡡࡹࠪࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᪝")).findall(content)
    for href,l1l1lll1llll11l111_tv_ in items:
        c = code
        t = l1l1lll1llll11l111_tv_.split(Variable4 (u"ࠪ࠳ࠬ᪞"))[-1].split(Variable4 (u"ࠫ࠳࠭᪟"))[0]
        i = l1l1lll1llll11l111_tv_
        h = href
        if Variable4 (u"ࠬࡂࠧ᪠") in h:
            continue
        out.append(l1lll1l1l1l11l111_tv_({Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬ᪡"):t,Variable4 (u"ࠧࡵࡸ࡬ࡨࠬ᪢"):t,Variable4 (u"ࠨ࡫ࡰ࡫ࠬ᪣"):i,Variable4 (u"ࠩࡸࡶࡱ࠭᪤"):h,Variable4 (u"ࠪ࡫ࡷࡵࡵࡱࠩ᪥"):Variable4 (u"ࠫࠬ᪦"),Variable4 (u"ࠬࡻࡲ࡭ࡧࡳ࡫ࠬᪧ"):Variable4 (u"࠭ࠧ᪨"),Variable4 (u"ࠧࡤࡱࡧࡩࠬ᪩"):c}))
    return out
class l1lll1111ll11l111_tv_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l1l1llll11ll11l111_tv_(l1ll1l1l11l11l111_tv_,l1111l11lll11l111_tv_=Variable4 (u"ࠨࠩ᪪")):
    try:
        header={Variable4 (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ᪫"):l1111l11lll11l111_tv_,
            Variable4 (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ᪬"):l1lll1l1lll11l111_tv_,
            Variable4 (u"ࠫࡆࡩࡣࡦࡲࡷࠫ᪭"):Variable4 (u"ࠬ࠰࠯ࠫࠩ᪮"),
            Variable4 (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ᪯"):Variable4 (u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧ᪰"),
            Variable4 (u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧࠪ᪱"):Variable4 (u"ࠩࡨࡲ࠲࡛ࡓ࠭ࡧࡱ࠿ࡶࡃ࠰࠯࠺ࠪ᪲"),
            Variable4 (u"ࠪࡇࡦࡩࡨࡦ࠯ࡆࡳࡳࡺࡲࡰ࡮ࠪ᪳"):Variable4 (u"ࠫࡳࡵ࠭ࡤࡣࡦ࡬ࡪ࠭᪴"),
            }
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(l1lll1111ll11l111_tv_,urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        opener.addheaders = header.items()
        response = opener.open(l1ll1l1l11l11l111_tv_,timeout=5)
        l11ll111lll11l111_tv_ = response.headers.get(Variable4 (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴ᪵ࠧ"),Variable4 (u"᪶࠭ࠧ"))
        response.close()
    except:
        l11ll111lll11l111_tv_=Variable4 (u"ࠧࠨ᪷")
    if l11ll111lll11l111_tv_:
        return l11ll111lll11l111_tv_
    else:
        return l1ll1l1l11l11l111_tv_
url=Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡨࡰࡪ࠳ࡷࡪࡼ࡭ࡥ࠳࡯ࡳ࠰ࡣࡻࡲ࠲ࡨ࡬ࡢࡥ࡮࠳᪸ࠬ")
url=Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡩࡱ࡫࠭ࡸ࡫ࡽ࡮ࡦ࠴ࡩࡴ࠱ࡷࡺࡳ࠳࠷࠰᪹ࠩ")
def l111l1lll11l111_tv_(url):
    l1lll1ll11l11l111_tv_=[]
    url = url.replace(Variable4 (u"ࠪࡸࡪࡲࡥ࠮ࡹ࡬ࡾ࡯ࡧ࠮ࡤࡱࡰ᪺ࠫ"),Variable4 (u"ࠫࡹ࡫࡬ࡦ࠯ࡺ࡭ࡿࡰࡡ࠯࡫ࡶࠫ᪻"))
    content,c = l111111l11l111_tv_(url)
    l1l1lll11ll11l111_tv_ = re.compile(Variable4 (u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠮࠮ࠫࡁࠬࡀ࠴࡯ࡦࡳࡣࡰࡩࡃ࠭᪼"),re.DOTALL).findall(content)
    for l1ll1l1111l11l111_tv_ in l1l1lll11ll11l111_tv_:
        l1ll1l11l1l11l111_tv_ = re.compile(Variable4 (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀ᪽ࠫࠥࠫ"),re.DOTALL|re.IGNORECASE).findall(l1ll1l1111l11l111_tv_)
        if l1ll1l11l1l11l111_tv_:
            l1111l11l1l11l111_tv_ = l1ll1l11l1l11l111_tv_[0]
            data,c = l111111l11l111_tv_(l1111l11l1l11l111_tv_)
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
            if l1ll11lll1l11l111_tv_:
                l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠧࡶࡴ࡯ࠫ᪾"):l1ll11lll1l11l111_tv_,Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ᪿࠧ"):Variable4 (u"ࠩࡏ࡭ࡻ࡫ࠠࠨᫀ")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,Variable4 (u"ࠪࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ᫁"):1})
                break
            else:
                l1ll1l1l11l11l111_tv_ = re.compile(Variable4 (u"ࠫࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂࡠ࠳ࡳ࠳ࡶ࡝࠻ࡡ࠮ࡡࠢ࡝ࠩࡠࠫ᫂")).findall(data)
                if l1ll1l1l11l11l111_tv_:
                    l1ll1l1l11l11l111_tv_ = l1ll1l1l11l11l111_tv_[0]+Variable4 (u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀ᫃ࠫ")+l1lll1l1lll11l111_tv_+Variable4 (u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾᫄ࠩ")+l1111l11l1l11l111_tv_
                    l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠧࡶࡴ࡯ࠫ᫅"):l1ll1l1l11l11l111_tv_,Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ᫆"):Variable4 (u"ࠩࡏ࡭ࡻ࡫ࠠࠩ࡯࠶ࡹ࠮࠭᫇"),Variable4 (u"ࠪࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ᫈"):1})
                    break
                else:
                    l1ll1l1111l11l111_tv_ = re.compile(Variable4 (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬ᫉"),re.DOTALL).findall(data)
                    l1ll1l1111l11l111_tv_ = l1ll1l1111l11l111_tv_[0] if l1ll1l1111l11l111_tv_ else Variable4 (u"᫊ࠬ࠭")
                    l1ll1l11l1l11l111_tv_ = re.compile(Variable4 (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᫋")).findall(l1ll1l1111l11l111_tv_)
                    if l1ll1l11l1l11l111_tv_:
                        data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0]) if l1ll1l11l1l11l111_tv_[0].startswith(Variable4 (u"ࠧࡩࡶࡷࡴࠬᫌ")) else (content,Variable4 (u"ࠨࠩᫍ"))
                    l1ll1l1l11l11l111_tv_ = re.compile(Variable4 (u"ࠩ࡞ࠦࡡ࠭࡝ࠩࡪࡷࡸࡵ࠴ࠪࡀ࡞࠱ࡱ࠸ࡻ࡛࠹࡟ࠬ࡟ࠧࡢࠧ࡞ࠩᫎ")).findall(data)
                    if l1ll1l1l11l11l111_tv_:
                        l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠪࡹࡷࡲࠧ᫏"):l1ll1l1l11l11l111_tv_[0],Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ᫐"):Variable4 (u"ࠬࡒࡩࡷࡧࠣࠬࡲ࠹ࡵࠪࠩ᫑"),Variable4 (u"࠭ࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ᫒"):1})
                        break
                    else:
                        l1l1l1ll11l11l111_tv_ = [x.strip() for x in re.findall(Variable4 (u"ࠧࡩࡴࡨࡪࡂࡡ࡜ࠨࠤࡠࠬࡡࡹࠪࡩࡶࡷࡴ࠿࠵࠯ࡵࡧ࡯ࡩ࠲ࡽࡩࡻ࡬ࡤ࠲࠰࠵ࡺࡢࡲࡤࡷ࠳࠰࠿ࠪ࡝࡟ࠫࠧࡣ࡜ࡴࠬࡁࠫ᫓"),content)]
                        for l1l1ll111ll11l111_tv_ in l1l1l1ll11l11l111_tv_:
                            data,c = l111111l11l111_tv_( l1l1ll111ll11l111_tv_ )
                            l1l1lll11ll11l111_tv_ = re.compile(Variable4 (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠪ࠱࠮ࡄ࠯࠼࠰࡫ࡩࡶࡦࡳࡥ࠿ࠩ᫔"),re.DOTALL).findall(data)
                            for l1ll1l1111l11l111_tv_ in l1l1lll11ll11l111_tv_:
                                l1ll11lll1l11l111_tv_=Variable4 (u"ࠩࠪ᫕")
                                l1ll1l11l1l11l111_tv_ = re.compile(Variable4 (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᫖")).findall(l1ll1l1111l11l111_tv_)
                                if l1ll1l11l1l11l111_tv_:
                                    data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
                                    l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
                                if l1ll11lll1l11l111_tv_:
                                    l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠫࡺࡸ࡬ࠨ᫗"):l1ll11lll1l11l111_tv_,Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫ᫘"):Variable4 (u"࠭ࡌࡪࡸࡨࠤࠬ᫙")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,Variable4 (u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࠩ᫚"):1})
                                    break
                        break
    return l1lll1ll11l11l111_tv_
def l1l1l1lll1l11l111_tv_():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[1]
    for l1l1l1ll11l111_tv_ in out:
        url=l1l1l1ll11l111_tv_.get(Variable4 (u"ࠨࡷࡵࡰࠬ᫛"))
        print Variable4 (u"ࠩ࡟ࡲࠬ᫜"),l1l1l1ll11l111_tv_.get(Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ᫝"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡺࡸ࡬ࠨ᫞")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠬࡻࡲ࡭ࠩ᫟")))
        print l1lll1ll11l11l111_tv_
