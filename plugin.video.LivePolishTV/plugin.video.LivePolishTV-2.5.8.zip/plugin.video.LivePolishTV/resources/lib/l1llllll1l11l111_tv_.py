# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib,urlparse
import re
import time
import l1ll11ll1ll11l111_tv_
import l1ll1ll111l11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡹ࠱ࡼ࡫ࡥࡣ࠰ࡦࡳࡲ࠵ࠧḀ")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠷࠳࠲࠵࠴࠲࠷࠸࠴࠲࠶࠶࠲ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨḁ")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧḂ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠫࠬḃ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(Variable4 (u"ࠬࡂࡡࠡࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡲࡰࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩḄ")).findall(content)
    for href,l1llll11lll11l111_tv_ in l1lll1lllll11l111_tv_:
        title = l1llll11lll11l111_tv_.split(Variable4 (u"࠭࠯ࠨḅ"))[-1].split(Variable4 (u"ࠧ࠯ࠩḆ"))[0]
        if title.startswith(Variable4 (u"ࠨࡶࡨࡷࡹ࠳ࠧḇ")): continue
        out.append({Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨḈ"):title.strip(),Variable4 (u"ࠪࡸࡻ࡯ࡤࠨḉ"):title.strip(),Variable4 (u"ࠫ࡮ࡳࡧࠨḊ"):l1llll11lll11l111_tv_,Variable4 (u"ࠬࡻࡲ࡭ࠩḋ"):href,Variable4 (u"࠭ࡧࡳࡱࡸࡴࠬḌ"):Variable4 (u"ࠧࠨḍ"),Variable4 (u"ࠨࡷࡵࡰࡪࡶࡧࠨḎ"):Variable4 (u"ࠩࠪḏ")})
    if addheader and len(out):
        t=Variable4 (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡽࡪࡲ࡬ࡰࡹࡠ࡙ࡵࡪࡡࡵࡧࡧ࠾ࠥࠫࡳࠡࠪࡷࡺ࠲ࡽࡥࡦࡤࠬ࡟࠴ࡉࡏࡍࡑࡕࡡࠬḐ") %time.strftime(Variable4 (u"ࠦࠪࡪ࠯ࠦ࡯࠲ࠩ࡞ࡀࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠤḑ"))
        out.insert(0,{Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫḒ"):t,Variable4 (u"࠭ࡴࡷ࡫ࡧࠫḓ"):Variable4 (u"ࠧࠨḔ"),Variable4 (u"ࠨ࡫ࡰ࡫ࠬḕ"):Variable4 (u"ࠩࠪḖ"),Variable4 (u"ࠪࡹࡷࡲࠧḗ"):l1llll111ll11l111_tv_,Variable4 (u"ࠫ࡬ࡸ࡯ࡶࡲࠪḘ"):Variable4 (u"ࠬ࠭ḙ"),Variable4 (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭Ḛ"):Variable4 (u"ࠧࠨḛ")})
    return l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local={})
def l111l1lll11l111_tv_(url=Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡹ࠱ࡼ࡫ࡥࡣ࠰ࡦࡳࡲ࠵ࡴࡷࡲ࠴࠱ࡰࡹࡴࡳࡧࡤࡱ࠶࠳ࡪࡢࡦࡽࡥ࠴࠭Ḝ")):
    l1lll1ll11l11l111_tv_=[]
    content = l111111l11l111_tv_(url)
    l1l1lll11ll11l111_tv_ = re.compile(Variable4 (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪḝ"),re.DOTALL).findall(content)
    for l1ll1l1111l11l111_tv_ in l1l1lll11ll11l111_tv_:
        l1ll1l11l1l11l111_tv_ = re.compile(Variable4 (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨḞ")).findall(l1ll1l1111l11l111_tv_)
        if l1ll1l11l1l11l111_tv_:
            data = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
            if l1ll11lll1l11l111_tv_:
                l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠫࡺࡸ࡬ࠨḟ"):l1ll11lll1l11l111_tv_,Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫḠ"):Variable4 (u"࠭ࡌࡪࡸࡨࠤࠬḡ")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,Variable4 (u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࠩḢ"):1})
                break
    return l1lll1ll11l11l111_tv_
def l1l1l1lll1l11l111_tv_():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        url=l1l1l1ll11l111_tv_.get(Variable4 (u"ࠨࡷࡵࡰࠬḣ"))
        print Variable4 (u"ࠩ࡟ࡲࠬḤ"),l1l1l1ll11l111_tv_.get(Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩḥ"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡺࡸ࡬ࠨḦ")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫḧ")))
        print l1lll1ll11l11l111_tv_
