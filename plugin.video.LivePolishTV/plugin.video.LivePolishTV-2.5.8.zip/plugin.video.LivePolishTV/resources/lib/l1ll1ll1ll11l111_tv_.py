# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re,json
import time
import l1ll11ll1ll11l111_tv_
import cookielib
import urlparse
import threading
import l1ll1ll111l11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡭࡫ࡪࡢ࠰ࡷࡺ࠴࠭น")
l1lll1l1lll11l111_tv_ = Variable4 (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠸࠱࠵ࡀࠦࡲࡷ࠼࠵࠶࠳࠶ࠩࠡࡉࡨࡧࡰࡵ࠯࠳࠲࠴࠴࠵࠷࠰࠲ࠢࡉ࡭ࡷ࡫ࡦࡰࡺ࠲࠶࠷࠴࠰ࠨบ")
l1lll1ll1ll11l111_tv_=15
fix={}
local={}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(Variable4 (u"࠭ࡴࡷ࡫ࡧࠫป")),Variable4 (u"ࠧࠨผ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧฝ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[Variable4 (u"ࠩࡷࡺ࡮ࡪࠧพ")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=Variable4 (u"ࠪࠫฟ")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨภ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = Variable4 (u"ࠬ࠭ม").join([Variable4 (u"࠭ࠥࡴ࠿ࠨࡷࡀ࠭ย")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except urllib2.HTTPError as e:
        l11ll11ll11l111_tv_ = Variable4 (u"ࠧࠨร")
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def l1l1lll111l11l111_tv_(url, l1ll111l1ll11l111_tv_, index):
    out = l1l1l1lllll11l111_tv_(url)
    l1ll111l1ll11l111_tv_[index]=out
def l11l11l1l11l111_tv_(addheader=False):
    out=[]
    content,c = l111111l11l111_tv_(Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡪࡨ࡮ࡦ࠴ࡴࡷ࠱ࡤ࡮ࡦࡾ࠯ࡈࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷ࠴࠭ฤ"))
    try:
        content = json.loads(content).get(Variable4 (u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫล"),Variable4 (u"ࠪࠫฦ"))
    except:
        content,c = l111111l11l111_tv_(Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡭࡫ࡪࡢ࠰ࡷࡺ࠴࠭ว"))
    ids = [(a.start(), a.end()) for a in re.finditer(Variable4 (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡧ࡭ࡧ࡮࡯ࡧ࡯ࠤࡧࡵࡸࠨศ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l1l1lll1lll11l111_tv_ = content[ ids[i][1]:ids[i+1][0] ]
        href  = re.compile(Variable4 (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬษ")).findall(l1l1lll1lll11l111_tv_)
        l1llll11lll11l111_tv_ = re.compile(Variable4 (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪส")).findall(l1l1lll1lll11l111_tv_)
        title = re.compile(Variable4 (u"ࠨ࠾࡫࠸ࠥࡩ࡬ࡢࡵࡶࡁࠧࡶ࡯ࡴࡶ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪห")).findall(l1l1lll1lll11l111_tv_)
        if re.search(Variable4 (u"ࠩ࠿࡭ࠥࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡣࡰࡰ࠰ࡩࡾ࡫࠭ࡰࡲࡨࡲࠧࡄࠧฬ"),l1l1lll1lll11l111_tv_) and href:
            t = title[0]
            i = l1llll11lll11l111_tv_[0] if l1llll11lll11l111_tv_ else Variable4 (u"ࠪࠫอ")
            h = href[0]
            out.append(l1lll1l1l1l11l111_tv_({Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪฮ"):t,Variable4 (u"ࠬࡺࡶࡪࡦࠪฯ"):t,Variable4 (u"࠭ࡩ࡮ࡩࠪะ"):i,Variable4 (u"ࠧࡶࡴ࡯ࠫั"):h,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧา"):Variable4 (u"ࠩ࡫ࡩࡾࡺࡶࠨำ"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪิ"):Variable4 (u"ࠫࠬี"),Variable4 (u"ࠬࡩ࡯ࡥࡧࠪึ"):Variable4 (u"࠭ࠧื")}))
    if addheader and len(out):
        t=Variable4 (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡖࡲࡧࡥࡹ࡫ࡤ࠻ࠢࠨࡷࠥ࠮ࡨࡦ࡬ࡤ࠲ࡹࡼࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ุࠩ") %time.strftime(Variable4 (u"ࠣࠧࡧ࠳ࠪࡳ࠯࡛ࠦ࠽ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨู"))
        out.insert(0,{Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨฺ"):t,Variable4 (u"ࠪࡸࡻ࡯ࡤࠨ฻"):Variable4 (u"ࠫࠬ฼"),Variable4 (u"ࠬ࡯࡭ࡨࠩ฽"):Variable4 (u"࠭ࠧ฾"),Variable4 (u"ࠧࡶࡴ࡯ࠫ฿"):l1llll111ll11l111_tv_,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧเ"):Variable4 (u"ࠩࠪแ"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪโ"):Variable4 (u"ࠫࠬใ")})
    return out
url=Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡮ࡥ࡫ࡣ࠱ࡸࡻ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࡷ࡫ࡨࡻ࠴ࡺࡶࡱ࠯࠴࠱࠻࠭ไ")
def l111l1lll11l111_tv_(url=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡨࡦ࡬ࡤ࠲ࡹࡼ࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࡸ࡬ࡩࡼ࠵ࡴࡷࡰ࠰࠹࠺࠶࠳ࠨๅ")):
    l1lll1ll11l11l111_tv_=[]
    content,c = l111111l11l111_tv_(url)
    header = {Variable4 (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫๆ"):l1lll1l1lll11l111_tv_,Variable4 (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ็"):c}
    l1l1ll11lll11l111_tv_ = re.compile(Variable4 (u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡉࡱࡸ࡛ࡲ࡭࠿ࠫࡶࡹࡳࡰ࡜ࡠࠩࡡ࠯࠯่ࠧ")).findall(content)
    l1l1lll1l1l11l111_tv_ = re.compile(Variable4 (u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡍࡩࡃࠨ࡜ࡠࠩࡡ࠯࠯้ࠧ")).findall(content)
    l1l1ll1ll1l11l111_tv_ = re.compile(Variable4 (u"ࠫࡁࡵࡢ࡫ࡧࡦࡸࠥ࠴ࠪࠡࡦࡤࡸࡦࡃࠢࠩࡪࡷࡸࡵࡀ࠯࠰࠰࠭ࡃࡸࡽࡦࠪࠤ๊ࠪ")).findall(content)
    l1l1ll1ll1l11l111_tv_ = l1l1ll1ll1l11l111_tv_[0] if l1l1ll1ll1l11l111_tv_ else Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡮ࡥ࡫ࡣ࠱ࡸࡻ࠵ࡶࡪࡧࡺࡩࡷࡔ࡯ࡄࡪࡤࡸ࠳ࡹࡷࡧ๋ࠩ")
    value=re.compile(Variable4 (u"࠭ࡶࡢ࡮ࡸࡩࡂࠨࠨࡳࡶࡰࡴ࡛࡯ࡤࡦࡱ࠱࠮ࡄࠨࠩࠨ์")).findall(content)
    value = value[0] if value else Variable4 (u"ࠧࠨํ")
    l1l1ll11l1l11l111_tv_ = re.findall( Variable4 (u"ࠨࡸࡤࡶࠥࡵ࡬ࡥࡗࡱ࡭ࡶࡏࡄࠡ࠿ࠣࡠࠬ࠮࠮ࠫࡁࠬࡠࠬࡁࠧ๎"),content)
    l1l1ll1llll11l111_tv_ = re.findall( Variable4 (u"ࠩࡸࡶࡱࡀࠠ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࡟࠯ࠥࡶ࡯ࡱࡗࡳ࡙ࡳ࡯ࡱࡊࡆ࠯ࠫ๏"),content)
    l1l1ll1llll11l111_tv_ = l1l1ll1llll11l111_tv_[0] if l1l1ll1llll11l111_tv_ else Variable4 (u"ࠪࠫ๐")
    l1l1ll11l1l11l111_tv_ = l1l1ll11l1l11l111_tv_[0] if l1l1ll11l1l11l111_tv_ else Variable4 (u"ࠫࠬ๑")
    l1l1l1ll1ll11l111_tv_,c = l111111l11l111_tv_(l1l1ll1llll11l111_tv_+l1l1ll11l1l11l111_tv_,header=header)
    l1l1l1ll1ll11l111_tv_ = json.loads(l1l1l1ll1ll11l111_tv_).get(Variable4 (u"ࠬࡻ࡮ࡪࡳࡌࡨࠬ๒"),Variable4 (u"࠭ࠧ๓"))
    l1l1ll1l11l11l111_tv_ = re.findall(Variable4 (u"ࠧࡶࡰ࡬ࡵࡎࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠧ๔"),value)
    l1l1ll1l11l11l111_tv_ = l1l1ll1l11l11l111_tv_[0] if l1l1ll1l11l11l111_tv_ else l1l1l1ll1ll11l111_tv_
    value = value.replace(l1l1ll1l11l11l111_tv_,l1l1l1ll1ll11l111_tv_)
    value=value.replace(Variable4 (u"ࠨࠨࡤࡱࡵࡁࠧ๕"),Variable4 (u"ࠩࠣࠫ๖")).replace(Variable4 (u"ࠪࠦࠬ๗"),Variable4 (u"ࠫࠬ๘"))
    value = Variable4 (u"ࠬࠦࠧ๙").join(value.split(Variable4 (u"࠭ࠠࠨ๚"))[3:])
    header.update({Variable4 (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ๛"):Variable4 (u"ࠨࡕ࡫ࡳࡨࡱࡷࡢࡸࡨࡊࡱࡧࡳࡩ࠱࠵࠻࠳࠶࠮࠱࠰࠴࠻࠵࠭๜"),
        Variable4 (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ๝"):url,
        })
    if l1l1ll11lll11l111_tv_ and l1l1lll1l1l11l111_tv_:
        src = urllib.unquote(l1l1ll11lll11l111_tv_[0])
        l1l1ll1111l11l111_tv_ = l1l1lll1l1l11l111_tv_[0]
        l1ll11lll1l11l111_tv_ =src+l1l1ll1111l11l111_tv_+Variable4 (u"ࠪࠤࡵࡲࡡࡺࡲࡤࡸ࡭ࡃࡳࡵࡴࡨࡥࡲࠦࡳࡸࡨࡘࡶࡱࡃࠧ๞")+l1l1ll1ll1l11l111_tv_ + Variable4 (u"ࠫࠥࡶࡡࡨࡧࡘࡶࡱࡃࠧ๟")+url + Variable4 (u"ࠬࠦࡵ࡯࡫ࡴࡍࡩࡃࠧ๠")+l1l1l1ll1ll11l111_tv_
        l1lll1ll11l11l111_tv_.append({Variable4 (u"࠭ࡵࡳ࡮ࠪ๡"):l1ll11lll1l11l111_tv_,Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭๢"):Variable4 (u"ࠨࠩ๣"),Variable4 (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ๤"):1})
    else:
        src=Variable4 (u"ࠪࡶࡹࡳࡰ࠻࠱࠲࠼࠼࠴࠱࠳࠲࠱࠷࠻࠴࠳࠴࠱ࡹ࡭ࡩ࡫࡯࠰ࠩ๥")
        l1l1ll1111l11l111_tv_=url.split(Variable4 (u"ࠫ࠲࠭๦"))[-1]
        l1ll11lll1l11l111_tv_ =src+l1l1ll1111l11l111_tv_+Variable4 (u"ࠬࠦࡰ࡭ࡣࡼࡴࡦࡺࡨ࠾ࡵࡷࡶࡪࡧ࡭ࠡࡵࡺࡪ࡚ࡸ࡬࠾ࠩ๧")+l1l1ll1ll1l11l111_tv_ + Variable4 (u"࠭ࠠࡱࡣࡪࡩ࡚ࡸ࡬࠾ࠩ๨")+url + Variable4 (u"ࠧࠡࡷࡱ࡭ࡶࡏࡤ࠾ࠩ๩")+l1l1l1ll1ll11l111_tv_
        l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠨࡷࡵࡰࠬ๪"):l1ll11lll1l11l111_tv_,Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨ๫"):Variable4 (u"ࠪࠫ๬"),Variable4 (u"ࠫࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭๭"):1})
    print l1lll1ll11l11l111_tv_
    l1lll1ll11l11l111_tv_ = [{Variable4 (u"ࠬࡻࡲ࡭ࠩ๮"):Variable4 (u"࠭ࡲࡵ࡯ࡳ࠾࠴࠵࠸࠸࠰࠴࠶࠵࠴࠳࠷࠰࠶࠷࠴ࡼࡩࡥࡧࡲ࠳࠺࠻࠰࠴ࠢࡳࡰࡦࡿࡰࡢࡶ࡫ࡁࡸࡺࡲࡦࡣࡰࠤࡸࡽࡦࡖࡴ࡯ࡁ࡭ࡺࡴࡱ࠼࠲࠳࡭࡫ࡪࡢ࠰ࡷࡺ࠴ࡼࡩࡦࡹࡨࡶࡓࡵࡃࡩࡣࡷ࠲ࡸࡽࡦࠡࡲࡤ࡫ࡪ࡛ࡲ࡭࠿࡫ࡸࡹࡶ࠺࠰࠱࡫ࡩ࡯ࡧ࠮ࡵࡸ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࡻ࡯ࡥࡸ࠱ࡷࡺࡳ࠳࠵࠶࠲࠶ࠤࡺࡴࡩࡲࡋࡧࡁ࠶࠻࠱࠳࠻࠵࠺࠵࠿࠶࠲࠸࠳࠹࠷࠻ࡡ࠳ࡦ࠹ࡦ࠾࠶࠵࠴ࡧࡥ࠻࠽࠹࠴࠺࠻࠻࠶࠾࠽ࠧ๯"),Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭๰"):Variable4 (u"ࠨࠩ๱"),Variable4 (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ๲"):1}]
    return l1lll1ll11l11l111_tv_
def l1l1ll1l1ll11l111_tv_(url=Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡻ࠴࡯ࡱࡧࡱ࡯ࡦࡺࡡ࡭ࡱࡪ࠲ࡲࡲ࠯ࡰࡩࡲࡰࡳ࡫࠯ࡱࡱ࡯ࡷࡦࡺ࠭ࡰࡰ࡯࡭ࡳ࡫࠯ࠨ๳")):
    l1lll1ll11l11l111_tv_=[]
    content,c = l111111l11l111_tv_(url)
    l1l1lll11ll11l111_tv_ = re.compile(Variable4 (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬ๴"),re.DOTALL).findall(content)
    for l1ll1l1111l11l111_tv_ in l1l1lll11ll11l111_tv_:
        l1ll1l11l1l11l111_tv_ = re.compile(Variable4 (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ๵")).findall(l1ll1l1111l11l111_tv_)
        if l1ll1l11l1l11l111_tv_:
            data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
            if l1ll11lll1l11l111_tv_:
                l1lll1ll11l11l111_tv_.append({Variable4 (u"࠭ࡵࡳ࡮ࠪ๶"):l1ll11lll1l11l111_tv_,Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭๷"):Variable4 (u"ࠨࡎ࡬ࡺࡪࠦࠧ๸")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,Variable4 (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ๹"):1})
                break
            else:
                l1ll1l1l11l11l111_tv_ = re.compile(Variable4 (u"ࠪ࡟ࠧࡢࠧ࡞ࠪ࡫ࡸࡹࡶ࠮ࠫࡁ࡟࠲ࡲ࠹ࡵ࡜࠺ࡠ࠭ࡠࠨ࡜ࠨ࡟ࠪ๺")).findall(data)
                if l1ll1l1l11l11l111_tv_:
                    l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠫࡺࡸ࡬ࠨ๻"):l1ll1l1l11l11l111_tv_[0],Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫ๼"):Variable4 (u"࠭ࡌࡪࡸࡨࠤ࠭ࡳ࠳ࡶࠫࠪ๽"),Variable4 (u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࠩ๾"):1})
                    break
                else:
                    l1ll1l1111l11l111_tv_ = re.compile(Variable4 (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠪ࠱࠮ࡄ࠯࠼࠰࡫ࡩࡶࡦࡳࡥ࠿ࠩ๿"),re.DOTALL).findall(data)
                    l1ll1l1111l11l111_tv_ = l1ll1l1111l11l111_tv_[0] if l1ll1l1111l11l111_tv_ else Variable4 (u"ࠩࠪ຀")
                    l1ll1l11l1l11l111_tv_ = re.compile(Variable4 (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨກ")).findall(l1ll1l1111l11l111_tv_)
                    if l1ll1l11l1l11l111_tv_:
                        data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
                    l1ll1l1l11l11l111_tv_ = re.compile(Variable4 (u"ࠫࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂࡠ࠳ࡳ࠳ࡶ࡝࠻ࡡ࠮ࡡࠢ࡝ࠩࡠࠫຂ")).findall(data)
                    if l1ll1l1l11l11l111_tv_:
                        l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠬࡻࡲ࡭ࠩ຃"):l1ll1l1l11l11l111_tv_[0],Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬຄ"):Variable4 (u"ࠧࡍ࡫ࡹࡩࠥ࠮࡭࠴ࡷࠬࠫ຅"),Variable4 (u"ࠨࡴࡨࡷࡴࡲࡶࡦࡦࠪຆ"):1})
                        break
                    else:
                        l1l1l1ll11l11l111_tv_ = [x.strip() for x in re.findall(Variable4 (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡟ࡷ࠯࡮ࡴࡵࡲ࠽࠳࠴ࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢ࠰ࡦࡳࡲ࠵ࡺࡢࡲࡤࡷ࠳࠰࠿ࠪࠤࠪງ"),content)]
                        for l1l1ll111ll11l111_tv_ in l1l1l1ll11l11l111_tv_:
                            print Variable4 (u"ࠪࡾࡦࡶࡡࡴࠩຈ")
                            data,c = l111111l11l111_tv_( l1l1ll111ll11l111_tv_ )
                            l1l1lll11ll11l111_tv_ = re.compile(Variable4 (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬຉ"),re.DOTALL).findall(data)
                            for l1ll1l1111l11l111_tv_ in l1l1lll11ll11l111_tv_:
                                l1ll11lll1l11l111_tv_=Variable4 (u"ࠬ࠭ຊ")
                                l1ll1l11l1l11l111_tv_ = re.compile(Variable4 (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ຋")).findall(l1ll1l1111l11l111_tv_)
                                if l1ll1l11l1l11l111_tv_:
                                    data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
                                    l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
                                if l1ll11lll1l11l111_tv_:
                                    l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠧࡶࡴ࡯ࠫຌ"):l1ll11lll1l11l111_tv_,Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧຍ"):Variable4 (u"ࠩࡏ࡭ࡻ࡫ࠠࠨຎ")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,Variable4 (u"ࠪࡶࡪࡹ࡯࡭ࡸࡨࡨࠬຏ"):1})
                                    break
    return l1lll1ll11l11l111_tv_
def l1l1l1lll1l11l111_tv_():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        url=l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡺࡸ࡬ࠨຐ"))
        print Variable4 (u"ࠬࡢ࡮ࠨຑ"),l1l1l1ll11l111_tv_.get(Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬຒ"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠧࡶࡴ࡯ࠫຓ")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧດ")))
        print l1lll1ll11l11l111_tv_
