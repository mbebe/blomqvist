# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
from urlparse import urlparse
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡵࡸ࠰ࡳࡳࡲࡩ࡯ࡧ࠱ࡪࡲ࠵ࠧᴟ")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧᴠ")
__all__=[Variable4 (u"ࠩࡪࡩࡹࡉࡨࡢࡰࡱࡩࡱࡹࠧᴡ"),Variable4 (u"ࠪ࡫ࡪࡺࡃࡩࡣࡱࡲࡪࡲࡖࡪࡦࡨࡳࠬᴢ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᴣ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠬ࠭ᴤ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    ids = [(a.start(), a.end()) for a in re.finditer(Variable4 (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮ࠤࡁࠫᴥ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l1l1lll1lll11l111_tv_ = content[ ids[i][1]:ids[i+1][0] ]
        title = re.compile(Variable4 (u"ࠧ࠽ࡤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡃ࠭ᴦ")).findall(l1l1lll1lll11l111_tv_)
        l1ll1ll11l1l11l111_tv_ = re.compile(Variable4 (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࠥࡃࠢࡱࡴࡲ࡫ࡹࡼ࡬ࡪࡵࡷࡥࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᴧ"),re.DOTALL).findall(l1l1lll1lll11l111_tv_)
        l1ll1ll11l1l11l111_tv_ = re.sub(Variable4 (u"ࡴࠪࡀ࠳࠰࠿࠿ࠩᴨ"),Variable4 (u"ࠪࠫᴩ"),l1ll1ll11l1l11l111_tv_[0]) if l1ll1ll11l1l11l111_tv_ else Variable4 (u"ࠫࠬᴪ")
        href = re.compile(Variable4 (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨᴫ")).findall(l1l1lll1lll11l111_tv_)
        l1l11l1lllll11l111_tv_ = re.compile(Variable4 (u"࠭࠼ࡣࡀ࡟ࡷ࠯࠮࡜ࡥ࠭ࠬࡠࡸ࠰࠼࠰ࡤࡁࠫᴬ")).findall(l1l1lll1lll11l111_tv_)
        if href and title:
            group = href[0].split(Variable4 (u"ࠧࡀࠩᴭ"))[-1] if Variable4 (u"ࠨࡁࠪᴮ") in href[0] else Variable4 (u"ࠩࠪᴯ")
            l1l11l1lllll11l111_tv_ = l1l11l1lllll11l111_tv_[0] if l1l11l1lllll11l111_tv_ else Variable4 (u"ࠪࡃࠬᴰ")
            t = title[0].strip()
            code = Variable4 (u"ࠫࡠࡒࡩ࡯࡭ࣶࡻ࠿ࠫࡳ࡞ࠢࠨࡷࠬᴱ")%(l1l11l1lllll11l111_tv_,group)
            out.append({Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫᴲ"):t,Variable4 (u"࠭ࡴࡷ࡫ࡧࠫᴳ"):t,Variable4 (u"ࠧࡪ࡯ࡪࠫᴴ"):Variable4 (u"ࠨࠩᴵ"),Variable4 (u"ࠩࡸࡶࡱ࠭ᴶ"):href[0],Variable4 (u"ࠪ࡫ࡷࡵࡵࡱࠩᴷ"):group,Variable4 (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫᴸ"):Variable4 (u"ࠬ࠭ᴹ"),Variable4 (u"࠭ࡰ࡭ࡱࡷࠫᴺ"):l1ll1ll11l1l11l111_tv_,Variable4 (u"ࠧࡤࡱࡧࡩࠬᴻ"):code})
    if addheader and len(out):
        t=Variable4 (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࡗࡳࡨࡦࡺࡥࡥ࠼ࠣࠩࡸࠦࠨࡱࡵࡤ࠱ࡹࡼࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᴼ") %time.strftime(Variable4 (u"ࠤࠨࡨ࠴ࠫ࡭࠰ࠧ࡜࠾ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢᴽ"))
        out.insert(0,{Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᴾ"):t,Variable4 (u"ࠫࡹࡼࡩࡥࠩᴿ"):Variable4 (u"ࠬ࠭ᵀ"),Variable4 (u"࠭ࡩ࡮ࡩࠪᵁ"):Variable4 (u"ࠧࠨᵂ"),Variable4 (u"ࠨࡷࡵࡰࠬᵃ"):l1llll111ll11l111_tv_,Variable4 (u"ࠩࡪࡶࡴࡻࡰࠨᵄ"):Variable4 (u"ࠪࠫᵅ"),Variable4 (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫᵆ"):Variable4 (u"ࠬ࠭ᵇ")})
    return out
l11ll11l11l11l111_tv_=[Variable4 (u"࠭ࡳࡵࡣࡷ࡭ࡨ࠴ࡵ࠮ࡲࡵࡳ࠳࡬ࡲࠨᵈ"),Variable4 (u"ࠧࡪ࡭࡯ࡹࡧ࠴࡮ࡦࡶࠪᵉ"),Variable4 (u"ࠨ࡮ࡲࡳࡰࡴࡩ࡫࠰࡬ࡲࠬᵊ"),Variable4 (u"ࠩࡺ࡭ࡿࡰࡡ࠯ࡶࡹࠫᵋ"),Variable4 (u"ࠪࡻࡼࡽ࠮ࡵࡸࡳ࠲ࡵࡲࠧᵌ"),Variable4 (u"ࠫࡹ࡫࡬ࡦ࠯ࡺ࡭ࡿࡰࡡ࠯ࡥࡲࡱࠬᵍ")]
def l1llll1ll11l111_tv_(url=Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡶ࠮ࡱࡱࡰ࡮ࡴࡥ࠯ࡨࡰ࠳ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠮ࡱࡪࡳࡃࡹࡼ࠴ࡀࡲࡲࡨࡸࡺࡡࡸࡱࡺࡩࠬᵎ")):
    out=[]
    content = l111111l11l111_tv_(url)
    l11ll1ll1ll11l111_tv_ =re.compile(Variable4 (u"࠭࠼ࡢࠢࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺࡡ࡭࡫ࡱ࡯ࡦࡲࡩ࡯࡭ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᵏ")).findall(content)
    for l11ll11ll11l111_tv_ in l11ll1ll1ll11l111_tv_:
        title = urlparse(l11ll11ll11l111_tv_).netloc
        if title in l11ll11l11l11l111_tv_:
            title = Variable4 (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡴࡨࡩࡳࡣࠥࡴ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᵐ")%title
        else:
            title = Variable4 (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࠫࡳ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᵑ")%title
        out.append({Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨᵒ"):title,Variable4 (u"ࠪࡸࡻ࡯ࡤࠨᵓ"):title,Variable4 (u"ࠫࡺࡸ࡬ࠨᵔ"):l11ll11ll11l111_tv_})
    return out
def l111l1lll11l111_tv_(item):
    host = item.get(Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫᵕ"))
    url = item.get(Variable4 (u"࠭ࡵࡳ࡮ࠪᵖ"))
    l1lll1ll11l11l111_tv_=Variable4 (u"ࠧࠨᵗ")
    if Variable4 (u"ࠨࡵࡷࡥࡹ࡯ࡣ࠯ࡷ࠰ࡴࡷࡵ࠮ࡧࡴࠪᵘ") in host:
        data=Variable4 (u"ࠩࡶࡶࡨࡃࠢࠦࡵࠥࠫᵙ")%url
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif Variable4 (u"ࠪ࡭ࡰࡲࡵࡣ࠰ࡱࡩࡹ࠭ᵚ") in host:
        from l1l11llll11l111_tv_ import _1l1l11l11l11l111_tv_
        l1lll1ll11l11l111_tv_ = _1l1l11l11l11l111_tv_(url)
    elif Variable4 (u"ࠫࡱࡵ࡯࡬ࡰ࡬࡮࠳࡯࡮ࠨᵛ") in host:
        from l1lll1l1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠬࡻࡲ࡭ࠩᵜ"),Variable4 (u"࠭ࠧᵝ"))
    elif Variable4 (u"ࠧࡸ࡫ࡽ࡮ࡦ࠴ࡴࡷࠩᵞ") in host:
        from l1l1lllll11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠨࡷࡵࡰࠬᵟ"),Variable4 (u"ࠩࠪᵠ"))
    elif Variable4 (u"ࠪࡸࡪࡲࡥ࠮ࡹ࡬ࡾ࡯ࡧࠧᵡ") in host:
        data = l111111l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif Variable4 (u"ࠫࡼࡽࡷ࠯ࡶࡹࡴ࠳ࡶ࡬ࠨᵢ") in host:
        from l11ll1lll11l111_tv_ import _1l1l11l11l11l111_tv_
        l1lll1ll11l11l111_tv_ = _1l1l11l11l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠬࡻࡲ࡭ࠩᵣ"),Variable4 (u"࠭ࠧᵤ"))
    return l1lll1ll11l11l111_tv_
